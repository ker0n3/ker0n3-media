# -*- coding: utf-8 -*-
"""Ajustes → Cuentas → «TorBox» / «Real-Debrid» (24-nov): poner, comprobar o quitar la clave, como MDBList
(flix_mdblist.py), con su misma pantalla de explicación (QR de la página de la clave, FlixTorbox.xml /
FlixRealdebrid.xml de tools/gen_telegram_dialog.py) y el mismo teclado (en la tele, «Escribir desde el móvil»; en la
táctil, la página local para pegar de flix_pelis).

La clave la guarda el módulo del addon (flix_torbox / flix_realdebrid: torbox.json / realdebrid.json en addon_data
de la skin, 0600), igual que la de AllDebrid; en Skin.String (k3_tb_user / k3_rd_user) solo va el nombre de la
cuenta. Se comprueba con UNA petición (la cuenta de esa clave). Es un secreto: ni al registro ni a un diálogo.
Uso: RunScript(special://skin/scripts/flix_debridkey.py,torbox|realdebrid)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re  # noqa: E402

import xbmc  # noqa: E402

CONTINUE, OPEN = 10, 11                 # botones de FlixTorbox.xml / FlixRealdebrid.xml
SERVICES = {
    "torbox": dict(module="flix_torbox", heading="TorBox", user="k3_tb_user", xml="FlixTorbox.xml",
                   site="https://torbox.app/settings", shown="torbox.app/settings",
                   ask="Pega aquí tu API key de TorBox",
                   bad="Esa clave no parece de TorBox: cópiala de torbox.app/settings (API Key), sin espacios.",
                   where="torbox.app/settings"),
    "realdebrid": dict(module="flix_realdebrid", heading="Real-Debrid", user="k3_rd_user", xml="FlixRealdebrid.xml",
                       site="https://real-debrid.com/apitoken", shown="real-debrid.com/apitoken",
                       ask="Pega aquí tu token de Real-Debrid",
                       bad="Ese token no parece de Real-Debrid: cópialo de real-debrid.com/apitoken, sin espacios.",
                       where="real-debrid.com/apitoken"),
}
WAIT_TEXT = "En el navegador se ha abierto una página: pega ahí la clave y pulsa «Enviar a Kodi». Luego vuelve aquí."


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[flix_debridkey] %s" % msg, level)


def parse(text, svc, api):
    """la clave limpia (sin espacios ni saltos al pegar). ValueError(svc bad) si no tiene su forma; nunca la repite"""
    key = re.sub(r"\s+", "", text or "")
    if not re.fullmatch(api.KEY_RE, key):
        raise ValueError(svc["bad"])
    return key


def verify(api, key):
    """(«ok» | «mala» | «sin_premium» | «sin_red», texto de la cuenta): UNA petición, la cuenta de esa clave"""
    try:
        return "ok", api.account(api.user(key=key))
    except api.ADError as e:
        log("comprobación: %s" % e.kind)
        return {"sin_clave": "mala", "no_premium": "sin_premium"}.get(e.kind, "sin_red"), ""


class Store:
    """la clave (módulo del addon) y el nombre de la cuenta (Skin.String)"""

    def __init__(self, api, svc, run=None):
        self.api, self.svc, self.run = api, svc, run or xbmc.executebuiltin

    def key(self):
        return self.api.load_key()

    def save(self, key, who=""):
        if key:
            self.api.save_key(key)
            self.run("Skin.SetString(%s,%s)" % (self.svc["user"], who or "Vinculado"))
        else:
            self.api.forget_key()
            self.run("Skin.Reset(%s)" % self.svc["user"])


def menu(ui, store, verify_key, svc):
    """el flujo entero: True si cambió algo"""
    h = svc["heading"]
    if store.key():
        pick = ui.select("%s: Vinculado" % h, ["Comprobar", "Desvincular"])
        if pick == 0:
            r, who = verify_key(store.key())
            if r == "ok":
                store.save(store.key(), who)
            ui.ok({"ok": "%s responde. Cuenta: %s" % (h, who),
                   "mala": "La clave guardada ya no vale. Desvincula y vuelve a vincular con la de %s." % svc["where"],
                   "sin_premium": "La clave vale, pero la cuenta no tiene premium: no se podrá reproducir.",
                   }.get(r, "No he podido hablar con %s. Prueba otra vez en un momento." % h))
        elif pick == 1 and ui.yesno("¿Desvincular %s en este aparato?[CR]Se borra la clave guardada aquí; en tu "
                                    "cuenta de %s no se toca nada." % (h, h)):
            store.save("")
            log("%s desvinculado" % h)
            ui.notify("%s desvinculado" % h)
            return True
        return False
    if not ui.intro(svc):
        return False
    while True:
        text = ui.input(svc["ask"], svc)
        if not (text or "").strip():
            return False
        try:
            key = parse(text, svc, store.api)
        except ValueError as e:
            log("clave con otra forma: no la guardo")
            ui.ok(str(e))
            continue
        r, who = verify_key(key)
        if r == "mala":
            ui.ok("%s dice que esa clave no vale. Cópiala otra vez de %s." % (h, svc["where"]))
            continue
        if r == "sin_red" and not ui.yesno("No he podido comprobar la clave (sin conexión con %s).[CR]"
                                           "¿Guardarla de todos modos?" % h):
            return False
        store.save(key, who)
        log("%s vinculado%s" % (h, "" if r == "ok" else " (sin comprobar)"))
        if r == "sin_premium":
            ui.ok("Vinculado, pero la cuenta no tiene premium: no se podrá reproducir hasta que lo tenga.")
        ui.notify("%s vinculado" % h)
        return True


class _UI:
    def __init__(self):
        import xbmcgui
        self.gui, self.d = xbmcgui, xbmcgui.Dialog()
        self.heading = ""

    def intro(self, svc):
        import xbmcvfs
        import flix_common
        import flix_phonekb
        gui = self.gui
        self.heading = svc["heading"]

        class Intro(gui.WindowXMLDialog):
            go = False

            def onInit(self):
                self.setProperty("dk_qr", self.qr)
                self.setProperty("dk_url", svc["shown"])

            def onClick(self, cid):
                if cid == OPEN:         # táctil: la página en el navegador del móvil
                    import flix_pelis
                    flix_pelis.open_web(svc["site"], svc["shown"], heading=svc["heading"])
                    return
                self.go = cid == CONTINUE
                self.close()

            def onAction(self, action):
                if action.getId() in flix_common.A_BACK:
                    self.close()
        w = Intro(svc["xml"], xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
        try:
            w.qr = flix_phonekb.make_qr(svc["site"])
        except Exception as e:  # noqa: BLE001  (sin QR la explicación vale igual: la web va escrita)
            log("sin QR: %s" % type(e).__name__)
            w.qr = ""
        w.doModal()
        go = w.go
        del w
        return go

    def input(self, heading, svc):
        if xbmc.getSkinDir().endswith(".touch"):
            import flix_pelis
            return flix_pelis.paste_input(heading, title=svc["heading"], text=WAIT_TEXT)
        return self.d.input(heading, type=self.gui.INPUT_ALPHANUM)

    def ok(self, text):
        self.d.ok(self.heading, text)

    def yesno(self, text):
        return self.d.yesno(self.heading, text)

    def select(self, heading, options):
        return self.d.select(heading, options)

    def notify(self, text):
        self.d.notification(self.heading, text, time=4000)


def run(which):
    """el asistente de esa cuenta, si no hay otro abierto. True si cambió algo"""
    import importlib
    import xbmcgui
    svc = SERVICES.get(which)
    if not svc:
        return False
    home = xbmcgui.Window(10000)
    if home.getProperty("flix_debridkey_open"):
        return False
    home.setProperty("flix_debridkey_open", "1")
    try:
        api = importlib.import_module(svc["module"])
        ui = _UI()
        ui.heading = svc["heading"]
        return menu(ui, Store(api, svc), lambda key: verify(api, key), svc)
    finally:
        home.clearProperty("flix_debridkey_open")


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "")
