# -*- coding: utf-8 -*-
"""Ajustes → Cuentas → «PeLis» (16-nov): poner, comprobar o quitar la dirección de PeLis de este aparato.

PeLis es la tercera fuente, opcional (flix_src_list): cada usuario tiene su dirección, que se genera en
pelis-addon.com desde el móvil. Lo abre «Cuentas» del addon (cuentas.py) con RunScript: aquí están el QR y la ventana.
Sin vincular: una pantalla que lo explica con el QR de la web (FlixPelis.xml), el teclado de Kodi para la dirección (en
la tele, el teclado de la skin ya enseña «Escribir desde el móvil», flix_phonekb: se puede PEGAR desde el móvil), se
mira la forma, se comprueba con UNA petición a <dirección>/manifest.json y se guarda (flix_src_list.save_pelis_url:
pelis.json en addon_data de la skin, permisos 600). Los enlaces la usan desde la siguiente búsqueda, sin reiniciar.
Vinculado: «Comprobar» y «Desvincular» (borra ese fichero y nada más).

La dirección es un secreto (lleva el usuario y, en el servidor de PeLis, su clave de AllDebrid): va del teclado al
fichero y a pelis-addon.com, y a ningún sitio más. Ni al registro, ni a un diálogo, ni a una propiedad, ni a un
ajuste de la skin; los fallos se apuntan por su tipo, sin texto."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import urllib.error
import urllib.parse
import urllib.request

import xbmc

HOST = "pelis-addon.com"
SITE = "https://pelis-addon.com"
SHOWN = "pelis-addon.com"
HEADING = "PeLis"
ASK = "Pega aquí la dirección de PeLis"
TIMEOUT = 6
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
CONTINUE, OPEN = 10, 11                 # botones de FlixPelis.xml (tools/gen_telegram_dialog.py)
# el código: un solo trozo de ruta, con las letras que caben en una dirección sin escapar nada raro
_CODE = re.compile(r"^[A-Za-z0-9._~=%-]{6,1024}$")
BAD = ("Esa dirección no vale. Tiene que ser la de pelis-addon.com que acaba en /manifest.json "
       "(https://pelis-addon.com/…/manifest.json) o solo el código de en medio.")


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[flix_pelis] %s" % msg, level)


def parse(text):
    """la dirección base (https://pelis-addon.com/<código>) de lo escrito: la dirección entera (con o sin
    /manifest.json, también stremio://) o solo el código. ValueError(BAD) si no tiene esa forma; el mensaje nunca
    repite lo escrito"""
    t = re.sub(r"\s+", "", text or "")
    if not t:
        raise ValueError(BAD)
    low = t.lower()
    if low.startswith("stremio://"):
        t = "https://" + t[len("stremio://"):]
    elif low.startswith(HOST + "/"):
        t = "https://" + t
    if "://" in t or "/" in t:
        try:
            u = urllib.parse.urlsplit(t)
            port = u.port
        except ValueError:
            raise ValueError(BAD)
        if u.scheme.lower() != "https" or u.netloc.lower() != HOST or port or u.query or u.fragment \
                or "?" in t or "#" in t:
            raise ValueError(BAD)
        path = u.path
        if path.endswith("/manifest.json"):
            path = path[:-len("/manifest.json")]
        segs = [x for x in path.split("/") if x]
        code = segs[0] if len(segs) == 1 and "//" not in path else ""       # un solo trozo: el código
    else:
        code = t
    if not _CODE.match(code) or set(code) <= set(".") or code == "manifest.json" or "/" in code:
        raise ValueError(BAD)
    return "%s/%s" % (SITE, code)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """PeLis no redirige el manifest: si lo hiciera, no se sigue a otro sitio"""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.URLError("redirección %s" % code)


def _open(req, timeout):
    return urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout)


def verify(base, opener=None):
    """UNA petición a <base>/manifest.json: «ok» (un manifest que se llama PeLis), «no_pelis» (contesta otra cosa o
    404: la dirección no vale) o «sin_red» (no se pudo preguntar). Solo habla con pelis-addon.com"""
    try:
        if parse(base) != base:
            return "no_pelis"
    except ValueError:
        return "no_pelis"
    req = urllib.request.Request(base + "/manifest.json", headers={"User-Agent": UA})
    try:
        with (opener or _open)(req, timeout=TIMEOUT) as r:
            raw = r.read(200000)
    except urllib.error.HTTPError as e:
        log("comprobación: HTTP %s" % e.code)
        return "no_pelis" if e.code in (400, 401, 403, 404, 410) else "sin_red"
    except Exception as e:  # noqa: BLE001  (sin red, lento, cortado: solo el tipo, el texto puede llevar la dirección)
        log("comprobación: %s" % type(e).__name__)
        return "sin_red"
    try:
        d = json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        d = None
    ok = isinstance(d, dict) and "pelis" in str(d.get("name") or "").lower()
    log("comprobación: %s" % ("es PeLis" if ok else "no es un manifest de PeLis"))
    return "ok" if ok else "no_pelis"


def menu(ui, store, verify):
    """el flujo entero. «vinculado», «desvinculado» o None"""
    if store.load_pelis_url():
        pick = ui.select("PeLis: Vinculado", ["Comprobar", "Desvincular"])
        if pick == 0:
            r = verify(store.load_pelis_url())
            ui.ok({"ok": "PeLis responde: la dirección guardada vale.",
                   "no_pelis": "La dirección guardada ya no vale. Desvincula y vuelve a vincular con una nueva.",
                   }.get(r, "No he podido hablar con PeLis. Prueba otra vez en un momento."))
        elif pick == 1 and ui.yesno("¿Desvincular PeLis en este aparato?[CR]Se borra la dirección guardada aquí; en "
                                    "pelis-addon.com no se toca nada."):
            store.forget_pelis_url()
            log("PeLis desvinculado")
            ui.notify("PeLis desvinculado")
            return "desvinculado"
        return None
    if not ui.intro():
        return None
    while True:
        text = ui.input(ASK)
        if not (text or "").strip():
            return None
        try:
            base = parse(text)
        except ValueError as e:
            log("dirección con otra forma: no la guardo")
            ui.ok(str(e))
            continue
        r = verify(base)
        if r == "no_pelis":
            ui.ok("Esa dirección no es de PeLis o ya no vale. Genera otra en pelis-addon.com y pégala entera.")
            continue
        if r != "ok" and not ui.yesno("No he podido comprobar la dirección (sin conexión con pelis-addon.com).[CR]"
                                      "¿Guardarla de todos modos?"):
            return None
        store.save_pelis_url(base)
        log("PeLis vinculado%s" % ("" if r == "ok" else " (sin comprobar)"))
        ui.notify("PeLis vinculado")
        return "vinculado"


LOCAL_URL = "flix_pelis_local"         # Window(home): la página local mientras se espera (solo dentro de Kodi)
WAIT_SECS = 600
WAIT_TEXT = ("En el navegador se ha abierto una página: pega ahí la dirección de PeLis y pulsa «Enviar a Kodi». "
             "Luego vuelve aquí.")


# iPad/iPhone (y cualquier Kodi que no sea Android; Carlos, 23-nov: en el iPad «no deja abrir el navegador» y PeLis y
# MDBList no se podían vincular): Kodi solo sabe abrir una web en Android (StartAndroidActivity); en iPadOS no hay
# orden para abrir Safari y, al cambiar de app, el iPad deja Kodi en pausa y la página local para pegar ya no
# contesta. Ahí: «Abrir la web» explica cómo abrirla a mano y «Continuar» saca el teclado normal, en el que el iPad sí
# deja pegar (mantener pulsado → Pegar). En Android, todo como siempre
NO_BROWSER = ("Desde aquí no puedo abrir el navegador. Abre Safari y entra en [B]%s[/B].[CR][CR]"
              "Copia lo que pide, vuelve aquí y pulsa «Continuar» para pegarlo.")


def can_open_web():
    """¿sabe Kodi abrir una web en este aparato? Solo en Android"""
    return bool(xbmc.getCondVisibility("System.Platform.Android"))


def open_web(url, shown, heading=None, dialog=None, text=NO_BROWSER):
    """la web en el navegador del aparato (Android) o, si no se puede, cómo abrirla a mano (text, con %s = shown)"""
    if can_open_web():
        xbmc.executebuiltin("StartAndroidActivity(,android.intent.action.VIEW,,%s)" % url)
        return True
    import xbmcgui
    (dialog or xbmcgui.Dialog()).ok(heading or HEADING, text % shown)
    return False


def paste_input(heading, title=HEADING, text=WAIT_TEXT, dialog=None):
    """donde pegar en la táctil: la página local en Android (su teclado no deja pegar); en los demás, el teclado de
    Kodi (en el iPad, el del sistema, que sí deja)"""
    if can_open_web():
        return browser_input(heading, title=title, text=text)
    import xbmcgui
    return (dialog or xbmcgui.Dialog()).input(heading, type=getattr(xbmcgui, "INPUT_ALPHANUM", 0))


def browser_input(heading, open_url=None, progress=None, keyboard=None, now=None, title=HEADING, text=WAIT_TEXT):
    """táctil (17-nov): el teclado de Kodi en Android no deja pegar y la dirección tiene cientos de letras («imposible
    vincular PeLis»). Kodi sirve una página solo dentro del móvil (127.0.0.1, flix_phonekb local) y la abre en el
    navegador; ahí se pega y llega aquí. Lo escrito o "" (cancelado, sin página o pasado el tiempo)"""
    import threading
    import time
    import xbmcgui
    import flix_phonekb
    now = now or time.time
    got, box = threading.Event(), []

    def on_text(text):
        if not got.is_set():
            box.append(text)
            got.set()
    home = xbmcgui.Window(10000)
    pk = (keyboard or flix_phonekb.PhoneKeyboard)(on_text, heading, props=home, qr_prop=LOCAL_URL + "_qr",
                                                  url_prop=LOCAL_URL, local=True).start()
    try:
        url = ""
        for _ in range(50):
            url = home.getProperty(LOCAL_URL)
            if url or got.wait(0.1):        # espera corta a que el servidor esté escuchando
                break
        if not url:
            log("sin página local para pegar")
            return ""
        (open_url or (lambda u: xbmc.executebuiltin("StartAndroidActivity(,android.intent.action.VIEW,,%s)" % u)))(url)
        dlg = progress or xbmcgui.DialogProgress()
        dlg.create(title, text)
        try:
            end = now() + WAIT_SECS
            while now() < end and not got.wait(0.5):
                if dlg.iscanceled():
                    return ""
                dlg.update(int(100 * max(0, end - now()) / WAIT_SECS))
        finally:
            dlg.close()
        return box[0] if box else ""
    finally:
        pk.stop()


def make_qr():
    """QR de la web de PeLis (la portada, sin nada del usuario)"""
    import flix_phonekb
    return flix_phonekb.make_qr(SITE)


class _UI:
    def __init__(self):
        import xbmcgui
        self.gui, self.d = xbmcgui, xbmcgui.Dialog()

    def intro(self):
        import xbmcvfs
        import flix_common
        gui = self.gui

        class Intro(gui.WindowXMLDialog):
            go = False

            def onInit(self):
                self.setProperty("pl_qr", self.qr)
                self.setProperty("pl_url", SHOWN)

            def onClick(self, cid):
                if cid == OPEN:         # táctil: la web en el navegador del móvil; la ventana sigue aquí al volver
                    open_web(SITE, SHOWN)
                    return
                self.go = cid == CONTINUE
                self.close()

            def onAction(self, action):
                if action.getId() in flix_common.A_BACK:
                    self.close()
        w = Intro("FlixPelis.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
        try:
            w.qr = make_qr()
        except Exception as e:  # noqa: BLE001  (sin QR la explicación vale igual: la web va escrita)
            log("sin QR: %s" % type(e).__name__)
            w.qr = ""
        w.doModal()
        go = w.go
        del w
        return go

    def input(self, heading):
        if xbmc.getSkinDir().endswith(".touch"):
            return paste_input(heading)
        return self.d.input(heading, type=self.gui.INPUT_ALPHANUM)

    def ok(self, text):
        self.d.ok(HEADING, text)

    def yesno(self, text):
        return self.d.yesno(HEADING, text)

    def select(self, heading, options):
        return self.d.select(heading, options)

    def notify(self, text):
        self.d.notification(HEADING, text, time=4000)


def main():
    import xbmcgui
    import flix_src_list
    home = xbmcgui.Window(10000)
    if home.getProperty("flix_pelis_open"):
        return
    home.setProperty("flix_pelis_open", "1")
    try:
        menu(_UI(), flix_src_list, verify)
    finally:
        home.clearProperty("flix_pelis_open")


if __name__ == "__main__":
    main()
