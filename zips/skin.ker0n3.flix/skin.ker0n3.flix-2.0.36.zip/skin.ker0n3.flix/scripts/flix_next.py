"""Botón "Siguiente capítulo" del OSD y del aviso: PARA el capítulo (no salta al final) y flix_follow pone el siguiente
(flix_upnext_choice = next) cuando Kodi ha cerrado de verdad el anterior (flix_follow.wait_player_free).

22-nov (Fire TV del cuarto, Kodi colgado al pulsar «Siguiente»): antes se saltaba a 2 s del final y el capítulo
acababa solo. Kodi procesa ese «acabado» cuando puede (con poca memoria, tarde) y, al hacerlo, cierra el reproductor
(ClosePlayer): si para entonces ya se había abierto el siguiente, cerraba EL NUEVO, mientras cambiaba la frecuencia
de pantalla, y los dos hilos se esperaban para siempre. stop() es síncrono: cuando vuelve, el anterior está cerrado.
Para que siga contando como visto (el salto al final lo dejaba al 100 %), se avisa al servicio del addon
(NEXT_STOP: la parada apunta el capítulo como acabado). Un único camino abre el siguiente: flix_follow."""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

NEXT_STOP = "k3_next_stop"      # Window(10000): = ker0n3.service.NEXT_STOP (test_siguiente_sin_cuelgue)
TAIL = 3.0                      # s: si queda menos, acaba solo (parar ahora podría caer sobre el siguiente)


def skip_to_next(player, home, now=time.time):
    """para el capítulo que suena para pasar al siguiente; True si lo ha hecho"""
    if not player.isPlayingVideo():
        return False
    total = player.getTotalTime()
    if total <= 10:
        return False
    try:
        left = total - player.getTime()
    except RuntimeError:
        left = total
    home.setProperty("flix_upnext_choice", "next")      # flix_follow pone el siguiente
    if left < TAIL:
        xbmc.log("[flix_next] quedan %.1f s: acaba solo -> siguiente capítulo" % left, xbmc.LOGINFO)
        return True
    home.setProperty(NEXT_STOP, "%.3f" % now())          # el servicio lo apunta como acabado (visto)
    xbmc.log("[flix_next] paro (quedaban %.0f s) -> siguiente capítulo" % left, xbmc.LOGINFO)
    player.stop()
    return True


def main():
    player = xbmc.Player()
    episode = bool(xbmc.getInfoLabel("VideoPlayer.Episode")) or \
        re.search(r"\d+x\d+", xbmc.getInfoLabel("Player.Title")) is not None
    if not episode and xbmc.getCondVisibility("Integer.IsGreater(Playlist.Length(video),1)"):
        xbmc.executebuiltin("PlayerControl(Next)")      # lista de reproducción normal (otro origen)
    else:
        skip_to_next(player, xbmcgui.Window(10000))


if __name__ == "__main__":
    main()
