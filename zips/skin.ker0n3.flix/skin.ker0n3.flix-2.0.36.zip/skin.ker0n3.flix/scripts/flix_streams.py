# -*- coding: utf-8 -*-
"""Audio y subtítulos en un panel lateral, como Netflix (Carlos, 22-nov: idea de Arctic Fuse 3). El reproductor abría
los ajustes de Kodi (osdaudiosettings / osdsubtitlesettings): una hoja centrada que tapa el vídeo y pide varios pasos.
Aquí, un panel a la derecha con las pistas (la que suena, marcada) y un clic la pone y cierra; el vídeo sigue detrás.
Debajo: «Sincronizar», en subtítulos «Buscar subtítulos» (los de fuera, flix_src_extsubs, si los hay) y «Más
ajustes…» (la hoja de Kodi de siempre, para lo demás). Las pistas, de Kodi por JSON-RPC desde dentro (sin red).

RunScript(special://skin/scripts/flix_streams.py,audio|subs)"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcvfs  # noqa: E402

LIST = 9200
A_BACK = (9, 10, 92, 110, 122)          # atrás / menú anterior / cerrar
EXTSUBS = "special://home/addons/plugin.video.ker0n3/resources/lib/flix_src_extsubs.py"

LANGS = {
    "spa": "Español", "es": "Español", "esp": "Español", "eng": "Inglés", "en": "Inglés", "fre": "Francés",
    "fra": "Francés", "fr": "Francés", "ger": "Alemán", "deu": "Alemán", "de": "Alemán", "ita": "Italiano",
    "it": "Italiano", "por": "Portugués", "pt": "Portugués", "jpn": "Japonés", "ja": "Japonés", "kor": "Coreano",
    "ko": "Coreano", "chi": "Chino", "zho": "Chino", "zh": "Chino", "rus": "Ruso", "ru": "Ruso", "cat": "Catalán",
    "ca": "Catalán", "baq": "Euskera", "eus": "Euskera", "glg": "Gallego", "dut": "Neerlandés", "nld": "Neerlandés",
    "pol": "Polaco", "tur": "Turco", "ara": "Árabe", "hin": "Hindi", "swe": "Sueco", "nor": "Noruego",
    "dan": "Danés", "fin": "Finés", "gre": "Griego", "ell": "Griego", "heb": "Hebreo", "tha": "Tailandés",
}
CODECS = {"ac3": "Dolby Digital", "eac3": "Dolby Digital Plus", "truehd": "Dolby TrueHD", "dts": "DTS",
          "dtshd_ma": "DTS-HD MA", "dtshd_hra": "DTS-HD HRA", "dca": "DTS", "aac": "AAC", "mp3": "MP3",
          "flac": "FLAC", "opus": "Opus", "vorbis": "Vorbis", "pcm": "PCM"}
CHANNELS = {1: "mono", 2: "estéreo", 6: "5.1", 7: "6.1", 8: "7.1"}


def rpc(method, params=None):
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                         "params": params or {}})))
    except (ValueError, TypeError):
        return {}
    return r.get("result") or {}


def lang_name(code, name=""):
    """«Español», «Inglés»…; sin código conocido, el nombre de la pista o «Desconocido». Latino / castellano, si el
    nombre de la pista lo dice"""
    base = LANGS.get((code or "").lower().split("-")[0], "")
    low = (name or "").lower()
    if base == "Español" or (not base and re.search(r"espa|castell|latin", low)):
        if re.search(r"latin|lat\b|es-419|mexic", low) or (code or "").lower() == "es-419":
            return "Español (latino)"
        if re.search(r"castell|españa|spain|es-es", low):
            return "Español (castellano)"
        return "Español"
    return base or (name.strip() if name and name.strip() else "Desconocido")


def codec_name(codec):
    """«Dolby Digital Plus» para «eac3» y también para los nombres compuestos de algunos aparatos («EAC3_DDP_ATMOS» en
    la Shield); lo desconocido, en mayúsculas"""
    if codec in CODECS:
        return CODECS[codec]
    if "truehd" in codec:
        return CODECS["truehd"]
    if "eac3" in codec or "ddp" in codec:
        return CODECS["eac3"]
    if "dtshd" in codec or "dts-hd" in codec:
        return "DTS-HD"
    if codec.startswith(("ac3", "dd_")):
        return CODECS["ac3"]
    return codec.upper()


def audio_detail(s):
    """«Dolby TrueHD 7.1 · Atmos», «AAC estéreo», con lo que diga la pista"""
    parts = []
    codec = (s.get("codec") or "").lower()
    if codec:
        parts.append(codec_name(codec))
    ch = CHANNELS.get(int(s.get("channels") or 0))
    if ch:
        parts.append(ch)
    out = " ".join(parts)
    name = s.get("name") or ""
    if ("atmos" in name.lower() or "atmos" in codec) and "atmos" not in out.lower():
        out += " · Atmos"
    if re.search(r"comentario|commentary", name, re.I):
        out += " · Comentarios"
    return out


def sub_detail(s):
    tags = []
    name = (s.get("name") or "").lower()
    if s.get("isforced") or "forced" in name or "forzad" in name:
        tags.append("Forzados")
    if s.get("isimpaired") or re.search(r"\bsdh\b|\bcc\b|sordo|hearing", name):
        tags.append("Para sordos")
    if s.get("isexternal"):
        tags.append("Descargados")
    return " · ".join(tags)


def rows_for(kind, props, extsubs=False):
    """[(label, detalle, icono, acción, ¿actual?)] del panel. Acción: ('audio', i) / ('sub', i) / ('suboff',) /
    ('sync_audio',) / ('sync_sub',) / ('extsubs',) / ('more_audio',) / ('more_sub',)"""
    out = []
    if kind == "audio":
        cur = (props.get("currentaudiostream") or {}).get("index")
        for s in props.get("audiostreams") or []:
            out.append((lang_name(s.get("language"), s.get("name")), audio_detail(s), "",
                        ("audio", s.get("index")), s.get("index") == cur))
        out.append(("Sincronizar audio", "", "history", ("sync_audio",), False))
        out.append(("Más ajustes…", "", "sliders-horizontal", ("more_audio",), False))
        return out
    on = bool(props.get("subtitleenabled"))
    cur = (props.get("currentsubtitle") or {}).get("index") if on else None
    out.append(("Desactivados", "", "", ("suboff",), not on))
    for s in props.get("subtitles") or []:
        out.append((lang_name(s.get("language"), s.get("name")), sub_detail(s), "",
                    ("sub", s.get("index")), on and s.get("index") == cur))
    if extsubs:
        out.append(("Buscar subtítulos", "", "buscar", ("extsubs",), False))
    out.append(("Sincronizar subtítulos", "", "history", ("sync_sub",), False))
    out.append(("Más ajustes…", "", "sliders-horizontal", ("more_sub",), False))
    return out


def run_action(act):
    """lo que hace cada fila; True si el panel se cierra después"""
    name = act[0]
    if name == "audio":
        rpc("Player.SetAudioStream", {"playerid": 1, "stream": int(act[1])})
    elif name == "sub":
        rpc("Player.SetSubtitle", {"playerid": 1, "subtitle": int(act[1]), "enable": True})
    elif name == "suboff":
        rpc("Player.SetSubtitle", {"playerid": 1, "subtitle": "off"})
    elif name == "sync_audio":
        xbmc.executebuiltin("Action(AudioDelay)")
    elif name == "sync_sub":
        xbmc.executebuiltin("Action(SubtitleDelay)")
    elif name == "extsubs":
        xbmc.executebuiltin("RunScript(%s,menu)" % EXTSUBS)
    elif name == "more_audio":
        xbmc.executebuiltin("ActivateWindow(osdaudiosettings)")
    elif name == "more_sub":
        xbmc.executebuiltin("ActivateWindow(osdsubtitlesettings)")
    return True


class Panel(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.kind = kwargs.get("kind", "audio")
        self.rows = kwargs.get("rows") or []
        self.chosen = None

    def onInit(self):
        self.setProperty("fs_title", "Audio" if self.kind == "audio" else "Subtítulos")
        lst = self.getControl(LIST)
        lst.reset()
        items, first = [], 0
        for i, (label, detail, icon, _act, cur) in enumerate(self.rows):
            li = xbmcgui.ListItem(label, detail)
            li.setProperty("icon", "check" if cur else icon)
            li.setProperty("current", "1" if cur else "")
            li.setProperty("extra", "1" if icon else "")
            items.append(li)
            if cur:
                first = i
        lst.addItems(items)
        lst.selectItem(first)          # el foco, en la pista que suena
        self.setFocusId(LIST)

    def onClick(self, control_id):
        if control_id == LIST:
            self.chosen = self.getControl(LIST).getSelectedPosition()
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.close()


def main(kind):
    kind = "subs" if kind.startswith("sub") else "audio"
    props = rpc("Player.GetProperties", {"playerid": 1, "properties": [
        "audiostreams", "currentaudiostream", "subtitles", "currentsubtitle", "subtitleenabled"]})
    extsubs = bool(xbmcgui.Window(10000).getProperty("flix_extsubs_n")) and xbmcvfs.exists(EXTSUBS)
    rows = rows_for(kind, props, extsubs)
    w = Panel("FlixStreams.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", kind=kind, rows=rows)
    w.doModal()
    pos = w.chosen
    del w
    if pos is not None and 0 <= pos < len(rows):
        label, _d, _i, act, _c = rows[pos]
        xbmc.log("[flix_streams] %s: %s" % (kind, label), xbmc.LOGINFO)
        run_action(act)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "audio")
