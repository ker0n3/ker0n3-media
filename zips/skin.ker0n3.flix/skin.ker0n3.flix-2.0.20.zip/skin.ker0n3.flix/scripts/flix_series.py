# -*- coding: utf-8 -*-
"""Abrir una serie del addon Ker0n3 en su ficha (temporadas y capítulos) en vez de reproducir el siguiente capítulo.

RunScript(special://skin/scripts/flix_series.py, <ruta …/serie/<tmdb> del addon>)
RunScript(special://skin/scripts/flix_series.py, <ruta …/play/capitulo/…>, seguir)   -> tarjeta de capítulo a medias
RunScript(special://skin/scripts/flix_series.py, ver)    -> botón «Ver / Seguir viendo» de la ficha

Qué capítulo toca lo calcula el addon con la base propia y las fechas de TMDB al dar la carpeta de la serie (k3_state).
Serie que se sigue (▶): aviso «Seguir viendo · TxEy / Desde el principio / Ver temporadas» antes de la ficha; al día,
el aviso lo dice («Ver temporadas / Cerrar»).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import time
import xbmc
import xbmcgui
import xbmcvfs

from flix_common import K3_NO_ANSWER_RETRY, watched_rel  # noqa: E402,F401
from flix_common import list_dir as flix_common_list_dir  # noqa: E402
from flix_common import MONTHS, date_es  # noqa: E402,F401  («14 nov»: la fecha de la skin)

HOME = xbmcgui.Window(10000)
WATCHED = watched_rel()      # la base de vistos de Ker0n3 (solo lectura)


def watched_rows(sql, args):
    """filas de la base de vistos (solo lectura: el acceso común de flix_common, con el timeout de 3 s de aquí); None
    si no existe o no se puede leer"""
    from flix_common import watched_query
    try:
        return watched_query(xbmcvfs.translatePath(WATCHED), sql, args, timeout=3)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] watched.db: %s" % e, xbmc.LOGINFO)
        return None


K3_FOLDER_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/serie/(\d+)(?:/(\d+))?/?(?:&reload=\d+)?$")


def route_meta(path):
    """{tmdb[, season]} de la ruta de una serie o temporada del addon (…/serie/<tmdb>[/<T>]); {} si no lo es"""
    k3 = K3_FOLDER_RE.match(str(path or ""))
    if not k3:
        return {}
    return dict({"tmdb": k3.group(1)}, **({"season": int(k3.group(2))} if k3.group(2) else {}))


def art_url(v, size):
    """'/abc.jpg' (ruta de TMDB) -> URL completa; URL completa o vacío -> tal cual"""
    return "https://image.tmdb.org/t/p/%s%s" % (size, v) if v.startswith("/") else v


def use_sheet():
    """ficha en ventana propia (flix_series_sheet, FlixSeries.xml): las dos skins (táctil fase 1, TV fase 2: 26-oct).
    Skin.SetBool(flix_series_vieja) vuelve a la de la ventana Vídeos (respaldo, sin opción en Ajustes)"""
    return not xbmc.getCondVisibility("Skin.HasSetting(flix_series_vieja)")


def main():
    run(sys.argv[1] if len(sys.argv) > 1 else "", sys.argv[2:3])


def run(path, extra=()):
    """abrir la serie (o reanudar el capítulo, extra ["seguir"]). 20-nov: el Inicio, las secciones y el buscador la
    llaman en su propio proceso (ya vivo), sin RunScript: arrancar otro intérprete y cargar módulos eran 0,85 s de los
    1,2-2 s que tardaba en salir el aviso de una serie en la Shield"""
    extra = list(extra or [])
    import flix_play
    if flix_play.opening_other():
        # 2.º OK antes de que salga el aviso del 1.º: dos «Seguir viendo» a la vez cerraban Kodi (test_doble_apertura)
        xbmc.log("[flix_series] ya se abre otro título: ignoro el clic (%s)" % path[:60], xbmc.LOGINFO)
        return
    mark = flix_play.launch_begin()
    try:
        # «ficha»: vuelta desde «Títulos de X» del panel ( i ) (flix_info.back_to): a las temporadas, sin preguntar
        # «seguir»: tarjeta del capítulo a medias de «Seguir viendo» del Inicio: lo reanuda sin el aviso
        open_series(path, lambda: flix_play.launch_end(mark), ficha=extra == ["ficha"], direct=extra == ["seguir"])
    finally:
        flix_play.launch_end(mark)


K3_SHOW = "plugin://plugin.video.ker0n3/serie/"
K3_PLAY = "plugin://plugin.video.ker0n3/play/"
K3_SEASON_PROPS = ["title", "showtitle", "season", "art", "genre", "plot", "rating"]


def k3_tmdb(path):
    """número de TMDB de una serie de Ker0n3 (…/serie/<tmdb>) o None"""
    if not str(path).startswith(K3_SHOW):
        return None
    rest = path[len(K3_SHOW):].strip("/").split("/")
    return int(rest[0]) if rest and rest[0].isdigit() else None


K3_STATE = "k3_serie_"          # Window(home) + tmdb: lo que deja la carpeta de la serie (addon: series.publish)
K3_UPTODATE = "Al día  ·  no hay más capítulos por ahora"


def te(se):
    return "T%d E%d" % (int(se[0]), int(se[1]))


# ---------- series con una temporada enorme en TMDB, en pantalla con las temporadas de IMDb (18-nov) ----------
# El addon (ker0n3.parts) reparte los capítulos de TMDB en «partes» (Bleach: 16 temporadas + 4 partes de la guerra
# sangrienta). Cada parte es una temporada de la carpeta de la serie con número PART_BASE + k (nunca choca con uno de
# TMDB); sus capítulos llevan por dentro su temporada y capítulo de TMDB (rutas, base de vistos, marcas: todo igual).
# El estado (k3_state) trae además la numeración en pantalla (next_v / upto_v / soon_v = [k, puesto]) y la parte del
# siguiente («part»); el reparto se deja en Window(home).k3_partes_<tmdb> para los ✓ por parte (seasons_seen) y los
# capítulos por llegar de la última parte (part_tail). Sin reparto (casi todas las series), nada de esto cambia nada
PART_BASE = 1000
K3_PARTS = "k3_partes_"
_PARTS = [None, {}]     # [texto de la propiedad, lo leído]: el reparto solo se decodifica cuando cambia


def k3_parts(tmdb):
    """{v: {"k": k, "eps": [(T, C), …]}, "_tail": (v, T, C, nº)} del reparto que dejó la carpeta de la serie; {} si la
    serie no tiene (o el texto está roto)"""
    raw = HOME.getProperty(K3_PARTS + str(tmdb)) if tmdb else ""
    if not raw:
        return {}
    if _PARTS[0] == raw:
        return _PARTS[1]
    out = {}
    try:
        d = json.loads(raw)
        if str(d.get("tmdb")) == str(tmdb):
            for v, k, runs in d.get("p") or []:
                out[int(v)] = {"k": int(k), "eps": [(int(t), c) for t, a, b in runs for c in range(int(a), int(b) + 1)]}
            t = d.get("t") or []
            if len(t) == 4 and int(t[0]) in out:
                out["_tail"] = tuple(int(x) for x in t)
    except (ValueError, TypeError, AttributeError):
        out = {}
    _PARTS[:] = [raw, out]
    return out


def te_vis(st, key):
    """«T17 E3» de next / upto / soon con la numeración de la ficha si la serie va por partes (next_v…), si no la de
    siempre; '' si no hay"""
    se = st.get(key + "_v") or st.get(key)
    return te(se) if se else ""


def k3_state(tmdb):
    """qué capítulo toca de la serie de Ker0n3 según su carpeta (el addon lo calcula con la base propia y las fechas
    de TMDB ya guardadas y lo deja en Window(home) al dar las temporadas); {} si no lo dejó (addon viejo, base sin
    leer): entonces la ficha se queda con «Ver»"""
    try:
        d = json.loads(HOME.getProperty(K3_STATE + str(tmdb)) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) and str(d.get("tmdb")) == str(tmdb) else {}


def k3_soon(st, today=None):
    """«T1 E5  ·  Sale el 19 nov» del capítulo que viene cuando se va al día; '' si TMDB no lo anuncia con fecha"""
    soon = st.get("soon") or []
    if len(soon) < 3 or not date_es(str(soon[2] or ""), today or today_str()):
        return ""
    when = pending_label(str(soon[2]), today or today_str())
    if st.get("parts") and not st.get("soon_v"):
        return when                 # por partes y sin sitio en ellas (otra temporada de TMDB): solo la fecha
    return "%s  ·  %s" % (te_vis(st, "soon"), when)


def k3_apply(tmdb, st):
    """el botón de la ficha con ese estado: «Seguir viendo · T1 E4»
    (flix_series_next, con flix_series_pct si está a medias), «Al día · T1 E3» (flix_series_upto; lo que viene, en
    flix_series_soon), «Ver de nuevo» (flix_series_done) o «Ver». Devuelve la ruta que reproduce el botón"""
    nxt, upto = st.get("next") or None, st.get("upto") or None
    pct, at = int(st.get("pct") or 0), int(st.get("at") or 0)
    first = st.get("first") or [1, 1]
    play = K3_PLAY + "capitulo/%s/%d/%d" % (tmdb, int((nxt or first)[0]), int((nxt or first)[1]))
    part = str(st.get("part") or "") if st.get("parts") else ""
    apply({"flix_series_next": te_vis(st, "next") if nxt else "",
           "flix_series_pct": str(pct) if nxt and pct else "",
           "flix_series_upto": te_vis(st, "upto") if upto and not nxt else "",
           "flix_series_soon": k3_soon(st) if upto and not nxt else "",
           "flix_series_done": "1" if st.get("done") and not nxt else "",
           "flix_series_resume_at": "%s|%d" % (te_vis(st, "next"), at) if nxt and pct and at > 0 else "",
           "flix_series_play_ep": "",
           # el que toca aún no tiene versión (estreno de hoy: series.of next_na): «T1 E5 · Aún no disponible»
           "flix_series_na": "1" if nxt and st.get("next_na") else "",
           # por partes: en qué parte está el que toca y su temporada/capítulo de TMDB (qué temporada se abre y en
           # qué capítulo arranca su lista: season_index, flix_series_sheet.place_next)
           "flix_series_part": part,
           "flix_series_next_se": "%d/%d" % (int(nxt[0]), int(nxt[1])) if part and nxt else "",
           "flix_series_play": play})
    return play


def k3_notice(tmdb, st, title, release):
    """el aviso «Seguir viendo» de una serie que se sigue: a medias o siguiente → «Seguir viendo /
    Desde el principio / Ver temporadas»; al día → solo lo dice («Ver temporadas / Cerrar»). True = a la ficha"""
    import flix_play
    nxt, upto, pct = st.get("next") or None, st.get("upto") or None, int(st.get("pct") or 0)
    fanart = HOME.getProperty("flix_open_fanart")
    if not nxt:
        sub = k3_soon(st)
        choice = flix_play.choose(title, "Al día  ·  %s" % sub if sub else K3_UPTODATE, "Ver temporadas", "Cerrar",
                                  mode="uptodate", fanart=fanart)
        xbmc.log("[flix_series] %s al día (visto hasta %s): opción %d" % (title, te_vis(st, "upto") or "?", choice),
                 xbmc.LOGINFO)
        flix_play.release_pending()
        return choice == 0
    path = K3_PLAY + "capitulo/%s/%d/%d" % (tmdb, int(nxt[0]), int(nxt[1]))
    sub = ("%s a medias  ·  %s %%" % (te_vis(st, "next"), pct)) if pct else "Siguiente: %s" % te_vis(st, "next")
    if st.get("next_na"):           # estreno sin versión aún (series.of: solo lo guardado)
        sub = "Siguiente: %s  ·  Aún no disponible" % te_vis(st, "next")
    # el que toca aún sin versión: el foco en «Ver temporadas» (19-nov: «Seguir viendo» no llevaría a nada)
    choice = flix_play.choose(title, sub, "Seguir viendo", more="Ver temporadas", pct=pct, fanart=fanart,
                              focus=14 if st.get("next_na") else 0)
    xbmc.log("[flix_series] %s (Ker0n3) %s: opción %d" % (title, sub, choice), xbmc.LOGINFO)
    try:
        if choice in (0, 1):
            release()
            flix_play.start(path, int(st.get("at") or 0) if choice == 0 and pct else 0)
            return False
    finally:
        flix_play.release_pending()
    return choice == 2


def open_k3_series(path, release, ficha=False):
    """ficha de serie del addon Ker0n3 (15-nov): las propiedades de Window(home) de la ficha, sacadas de la carpeta
    …/serie/<tmdb> (sus temporadas: la primera trae showtitle y art). Bloque 3 (16-nov): qué capítulo toca lo deja el addon al dar esa carpeta (k3_state: base propia
    y fechas de TMDB guardadas, sin red aparte) → botón «Seguir viendo · T1 E4» / «Al día» / «Ver de nuevo» y, en una
    serie que se sigue, el aviso «Seguir viendo» antes de la ficha (ficha=True: directo a ella)"""
    import flix_play
    tmdb = str(k3_tmdb(path))
    folder = K3_SHOW + tmdb
    seasons = local_seasons(tmdb)             # el código del addon en este proceso: sin arrancar su intérprete
    if seasons is None:
        HOME.clearProperty(K3_STATE + tmdb)       # el de otra vez no vale: lo pone la carpeta que se pide ahora
        HOME.clearProperty(K3_PARTS + tmdb)       # el reparto en partes, igual
        try:
            seasons = list_dir(folder, K3_SEASON_PROPS) or []
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] Ker0n3: sin datos de la serie %s (%s)" % (tmdb, e), xbmc.LOGWARNING)
            seasons = []
    if not seasons:         # addon ausente o desactivado, o carpeta vacía: nada que enseñar
        release()
        xbmcgui.Dialog().notification("KER0N3 MEDIA", "No puedo abrir la serie ahora mismo",
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    first = seasons[0]
    st = k3_state(tmdb)
    if not st:              # sin estado: «Ver» = capítulo 1 de la primera temporada que no sea especiales (como antes)
        nums = sorted(n for n in (number(f, "season", r"(\d+)") for f in seasons) if n)
        start = [nums[0] if nums else 1, 1]
        if start[0] >= PART_BASE:           # por partes: el 1.º de TMDB de la primera parte (la parte no es temporada)
            p = k3_parts(tmdb).get(start[0])
            start = list(p["eps"][0]) if p and p["eps"] else [1, 1]
        st = {"first": start}
    art = first.get("art") or {}
    title = first.get("showtitle") or ""
    xbmc.log("[flix_series] pulsada %s (Ker0n3 %s)" % (title or "?", tmdb), xbmc.LOGINFO)
    HOME.setProperty("flix_open_fanart", flix_play.k3_art(art.get("fanart")))
    HOME.setProperty("flix_open_logo", flix_play.k3_art(art.get("clearlogo")))
    clear_eps()                               # sin capítulos de la serie anterior mientras carga esta
    fill_seasons([])                          # ni sus temporadas
    HOME.clearProperty("flix_series_hold")
    play = k3_apply(tmdb, st)
    set_rating("", play)                      # MDBList en otro hilo, si la sabe (IMDb / Metacritic)
    star = tmdb_star(first)
    # al momento, la ★ de TMDB de la serie (18-nov: la táctil se quedaba sin nota); MDBList pone la suya con su icono
    HOME.setProperty("flix_series_star", star[2:] if star else "")
    if star and not HOME.getProperty("flix_series_rating"):
        HOME.setProperty("flix_series_rating", star)
    HOME.setProperty("flix_series_folder", folder)
    HOME.setProperty("flix_series_tmdb", tmdb)                          # botón ( i ) (flix_info)
    try:
        import flix_common
        flix_common.favorite_prop("show", tmdb)                         # corazón de la ficha
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] favoritos: %s" % e, xbmc.LOGINFO)
    HOME.setProperty("flix_series_path", folder)        # y para volver a esta ficha desde «Títulos de X»
    find_trailer(tmdb, folder)
    HOME.setProperty("flix_series_title", title)
    HOME.setProperty("flix_section", title or "?")
    if not ficha and (st.get("next") or st.get("upto")) and started(tmdb):
        if not k3_notice(tmdb, st, title or "?", release):
            return
    release()
    xbmc.log("[flix_series] abro temporadas de %s" % (title or "?"), xbmc.LOGINFO)
    if use_sheet():
        import flix_series_sheet
        flix_series_sheet.open_sheet(folder)
        return
    if open_checked(folder, title) and xbmc.getCondVisibility("Container.Content(seasons)"):
        watch_seasons(folder)


def episode_runtime(tmdb, season, episode):
    """duración (s) del capítulo según lo guardado de TMDB (su temporada; si no, la de la serie), sin red; 0 si no hay"""
    try:
        from ker0n3 import catalog
        for e in catalog.season_cached(tmdb, season) or []:
            if e.get("n") == episode and e.get("duration"):
                return float(e["duration"])
        d = catalog.default_cache().get("tv%s" % tmdb, 0, stale=True) or {}
        return float(d.get("duration") or 0)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] duración de %s %sx%s: %s" % (tmdb, season, episode, e), xbmc.LOGINFO)
        return 0.0


def resume_k3_episode(path, release):
    """tarjeta de capítulo a medias de «Seguir viendo» con la base de Ker0n3 (…/play/capitulo/<tmdb>/<T>/<C>): en su
    minuto (progreso y duración de la base), sin aviso"""
    import flix_play
    m = re.match(r"^capitulo/(\d+)/(\d+)/(\d+)/?$", path[len(K3_PLAY):])
    offset = 0.0
    if m:
        rows = watched_rows("SELECT progress, runtime FROM episodes_watched WHERE tmdb_id=? AND season=? AND episode=?",
                            (int(m.group(1)), int(m.group(2)), int(m.group(3))))
        if rows and rows[0][0]:
            # la pausa que llega de Trakt trae el % pero no la duración (runtime 0): la de TMDB, como la fila «Seguir
            # viendo» (Shield 18-nov: estaba en la fila y empezaba desde el principio)
            runtime = float(rows[0][1] or 0) or episode_runtime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            offset = runtime * float(rows[0][0]) / 100.0
    release()
    xbmc.log("[flix_series] Ker0n3: reanudo %s en %d s" % (path[len(K3_PLAY):], offset), xbmc.LOGINFO)
    flix_play.start(path, offset)


def open_series(path, release, ficha=False, direct=False):
    """release(): suelta la marca de «abriendo» antes de la ficha (dura lo que quiera el usuario). ficha: sin el aviso
    «Seguir viendo», directo a las temporadas. direct: tarjeta del capítulo a medias (lo reanuda)"""
    if direct and str(path).startswith(K3_PLAY + "capitulo/"):
        return resume_k3_episode(path, release)
    if k3_tmdb(path):
        return open_k3_series(path, release, ficha)
    xbmc.log("[flix_series] ruta inválida: %r" % path, xbmc.LOGINFO)


def tmdb_star(item):
    """«★ 8.1» con la nota de TMDB de la serie que el addon pone en cada temporada; '' si no la trae (addon viejo)"""
    try:
        r = float((item or {}).get("rating") or 0)
    except (TypeError, ValueError):
        return ""
    return "★ %.1f" % r if r > 0 else ""


def rt_parts(rt):
    """('imdb', '8.3') de «IMDb 8.3» (flix_ratings.SOURCES); ('', '') si no es una de sus fuentes"""
    try:
        import flix_ratings
        for src, spec in flix_ratings.SOURCES.items():
            if rt and rt.startswith(spec[0] + " "):
                return src, rt[len(spec[0]) + 1:].strip()
    except Exception:  # noqa: BLE001
        pass
    return "", ""


def set_rating(j, play):
    """nota de la serie en la línea de datos de la ficha (flix_series_rating). En la táctil no hay cursor que pase
    por los pósters para verla (Carlos, 21-oct). La carpeta de la serie no trae nota: sin ★ al momento; con clave de
    MDBList, Metacritic -> IMDb en un hilo (de caché, ratings3.json entero, o pedida): el clic no la lee (revisión
    7-nov PY-12). j: sin uso (antes, la ruta con su nota). Devuelve el hilo"""
    HOME.setProperty("flix_series_rating", "")
    HOME.setProperty("flix_series_rt_src", "")      # icono de la fuente en la ficha (FlixSeriesRatingItems)
    HOME.setProperty("flix_series_rt_val", "")

    def late():
        try:
            import flix_ratings
            r = flix_ratings.label_for(play, wait=flix_ratings.TIMEOUT)
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] nota: %s" % e, xbmc.LOGINFO)
            return
        if r and HOME.getProperty("flix_series_play") == play:
            src, val = rt_parts(r)
            HOME.setProperty("flix_series_rt_src", src)
            HOME.setProperty("flix_series_rt_val", val)
            HOME.setProperty("flix_series_rating", r)
    import threading
    t = threading.Thread(target=late, daemon=True)
    t.start()
    return t


def find_trailer(tmdb, seasons):
    """botón «Tráiler» de la serie: URL en flix_series_trailer, buscada en un hilo (flix_trailer: TMDB) mientras se
    abren las temporadas. Sin el addon YouTube ni se busca: sin botón."""
    HOME.clearProperty("flix_series_trailer")
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
        return

    def run():
        try:
            import flix_common
            import flix_trailer
            url = flix_trailer.resolve("tv", tmdb, "")
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] tráiler: %s" % e, xbmc.LOGINFO)
            return
        if flix_common.quitting():              # Kodi cerrándose: nada que poner
            return
        if url and HOME.getProperty("flix_series_folder") == seasons:     # sigue en esta serie
            HOME.setProperty("flix_series_trailer", url)
    import threading
    # daemon: el script no se queda hasta 6-12 s vivo esperando a TMDB tras abrir la ficha (revisión 7-nov PY-22)
    threading.Thread(target=run, daemon=True).start()


def started(tmdb):
    """serie con ▶ (a medias y seguida; mismo criterio que el póster): vista entera u oculta = no. Solo esa serie y
    sin cargar flix_progress (revisión 29-oct DAT-06: 45-128 ms de imports antes del aviso en proot)"""
    from flix_common import SHOW_STARTED, show_state
    try:
        return show_state(xbmcvfs.translatePath(WATCHED), tmdb) == SHOW_STARTED
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] estado de la serie: %s" % e, xbmc.LOGINFO)
        return False


SPECIAL_RE = re.compile(r"especial|special|extra", re.I)


def local_seasons(tmdb):
    """20-nov: las temporadas y el estado de la serie con el código del addon (ker0n3.handlers.seasons_for_skin) en
    ESTE proceso, como la skin hacía con la base de Palantir (flix_fastsheet, 1.7.20): sin Files.GetDirectory, que
    arrancaba el intérprete del addon (0,7 s en la Shield). None si no se puede (addon viejo, error): se pregunta como
    siempre"""
    try:
        from ker0n3 import handlers
        if not hasattr(handlers, "seasons_for_skin"):
            return None
        HOME.clearProperty(K3_STATE + tmdb)       # lo pone seasons_for_skin, como la carpeta
        HOME.clearProperty(K3_PARTS + tmdb)
        t0 = time.time()
        items = handlers.seasons_for_skin(tmdb) or None
        xbmc.log("[flix_series] serie %s en este proceso: %d temporadas en %d ms"
                 % (tmdb, len(items or []), (time.time() - t0) * 1000), xbmc.LOGINFO)
        return items
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] serie %s en este proceso: %r (pregunto al addon)" % (tmdb, e), xbmc.LOGINFO)
        return None


def list_dir(path, props):
    # JSON-RPC común (revisión 29-oct DAT-20); respuesta que no es JSON: ValueError, como antes
    return flix_common_list_dir(path, props)


def number(f, key, pattern):
    """temporada / capítulo de un elemento: propiedad de Kodi o, si no la trae, el número de la etiqueta"""
    n = f.get(key)
    if isinstance(n, int) and n >= 0:
        return n
    m = re.search(pattern, f.get("title") or f.get("label") or "")
    return int(m.group(1)) if m else None


def pick_season(items):
    """1.ª temporada que no sea especial (temporada 0 / «Especiales»)"""
    ok = [(number(f, "season", r"(\d+)"), i, f) for i, f in enumerate(items)
          if f.get("filetype") != "file" and not SPECIAL_RE.search(f.get("label") or "")]
    ok = [x for x in ok if x[0] != 0]
    ok.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return ok[0][2] if ok else None


WATCH_STEP = 0.15       # s entre miradas a la temporada enfocada
# carpeta que no existe (0 elementos): un hueco se vacía con ella antes de cargar otra temporada. Con la ruta vacía
# Kodi conservaba los capítulos viejos y Container.IsUpdating no se marca en estas listas
EMPTY_EPS = "special://skin/media/flix/sin-capitulos/"
EPS_FAIL = 20           # s sin capítulos tras pedir una temporada -> «No se pudieron cargar los capítulos»
DEBOUNCE = 0.4          # s quieto en una temporada antes de pedir sus capítulos
EPS_SLOTS = 6           # listas de capítulos (MyVideoNav 7970-7975): las últimas temporadas vistas se quedan cargadas
EPS_FIRST_ID = 7970


def season_key(path):
    """lo que identifica una temporada: su ruta (la del addon no cambia al marcar un capítulo)"""
    return path


class EpsSlots:
    """Qué lista de capítulos se ve (Carlos, 21-oct: al volver a una temporada, sin esperar a pedirla otra vez).
    Cada hueco k es una lista de MyVideoNav con contenido Window(home).Property(flix_eps_c<k>); solo se ve la activa
    (flix_eps_slot) y las ocultas conservan sus capítulos sin pintar miniaturas. step() devuelve los cambios de
    propiedades; count(k) = elementos que tiene ya la lista k. Temporada nueva: tras DEBOUNCE quieto se coge el hueco
    libre o el usado hace más tiempo, se vacía (EMPTY_EPS, para no ver los de otra temporada) y se le pone la ruta."""

    def __init__(self, n=EPS_SLOTS):
        self.paths, self.used, self.ready = [None] * n, [0.0] * n, set()   # paths: season_key de cada hueco
        self.active, self.seen, self.since, self.job = None, None, 0.0, None

    def find(self, path):
        key = season_key(path)
        return next((k for k, p in enumerate(self.paths) if p == key and k in self.ready), None)

    def pick(self):
        free = [k for k, p in enumerate(self.paths) if p is None]
        return free[0] if free else min(range(len(self.paths)), key=lambda k: self.used[k])

    def _show(self, k, out):
        self.active = k
        out["flix_eps_slot"] = "" if k is None else str(k)
        out["flix_eps_id"] = str(EPS_FIRST_ID + k) if k is not None else str(SEASONS_LIST)
        out["flix_eps_failed"] = ""

    def stale_except(self, k):
        """tras ver un capítulo de la temporada a la vista (hueco k): esa se queda como está (sin vaciarla: el foco
        sigue en el capítulo) y ponerla al día es cosa de quien llama (la ventana Vídeos, con hide_keep, la refresca
        en su sitio con refresh_eps_in_place); las demás se vuelven a pedir cuando se enfoquen"""
        for i in range(len(self.paths)):
            if i != k:
                self.paths[i] = None
                self.ready.discard(i)
        return {}

    def hide_keep(self, k):
        """tras parar un capítulo lanzado desde el hueco k: todo oculto mientras Kodi recarga la carpeta (a la vista, Kodi
        refresca él solo las listas y, a la vez que la carpeta, la recarga fallaba y saltaba a la raíz de
        Vídeos: banco 25-oct); k sigue cargado y vuelve al momento en cuanto se vea su temporada (seen=None)"""
        self.stale_except(k)
        self.seen, self.job = None, None
        out = {"flix_eps_loading": ""}
        self._show(None, out)
        return out

    def invalidate(self):
        """tras ver un capítulo (✓ nuevos): todo se vuelve a pedir; la enfocada, en seguida"""
        self.paths, self.ready, self.job, self.seen = [None] * len(self.paths), set(), None, None
        out = {"flix_eps_loading": ""}
        self._show(None, out)
        return out

    def step(self, focus, now, count, first=False):
        out = {}
        if season_key(focus) != self.seen:              # misma temporada con ✓ nuevos: no es otra
            self.seen, self.since = season_key(focus), now
            self.job = None
            out["flix_eps_loading"] = ""
            k = self.find(focus)
            if k is not None:                           # ya cargada: al momento
                self.used[k] = now
                self._show(k, out)
                return out
            if self.active is not None:
                self._show(None, out)                   # rueda hasta que se pida y llegue
        if not focus:
            return out
        if self.job is None and self.active is None and (first or now - self.since >= DEBOUNCE):
            k = self.pick()
            self.ready.discard(k)
            self.paths[k], self.used[k] = season_key(focus), now
            self.job = ["vaciar", k, now]
            out["flix_eps_c%d" % k] = EMPTY_EPS
            out["flix_eps_loading"] = str(k)
            self._show(k, out)
        elif self.job and self.job[0] == "vaciar" and count(self.job[1]) == 0:
            self.job = ["cargar", self.job[1], now]
            out["flix_eps_c%d" % self.job[1]] = focus
        elif self.job and self.job[0] == "cargar" and count(self.job[1]) > 0:
            out["log"] = "capítulos en %.1f s" % (now - self.job[2])
            self.ready.add(self.job[1])
            self.job = None
            out["flix_eps_loading"] = ""
        elif self.job and self.job[0] == "cargar" and now - self.job[2] > EPS_FAIL:
            self.paths[self.job[1]] = None
            self.job = None
            out["flix_eps_failed"] = "1"
        return out


def season_index(items, nxt, part=""):
    """posición en la lista de temporadas de la del siguiente capítulo («T2 E5» -> temporada 2; por partes, la parte
    part, flix_series_part); si no se sabe, la 1.ª que no es especial"""
    if str(part).isdigit():
        for i, f in enumerate(items):
            if number(f, "season", r"(\d+)") == int(part):
                return i
        nxt = ""                    # «T17 E3» es de la ficha, no una temporada de la carpeta
    m = re.match(r"T(\d+) ", nxt or "")
    if m:
        for i, f in enumerate(items):
            if number(f, "season", r"(\d+)") == int(m.group(1)):
                return i
    first = pick_season(items)
    return items.index(first) if first is not None else 0


REFOCUS_SECS = 6        # s intentando devolver el foco al capítulo marcado (desde que acaba la recarga de la carpeta)
HOLD_MAX = 20           # s como mucho de retención de la pantalla de serie (flix_menu: flix_series_hold)
# un diálogo encima de la pantalla de serie. Nombrados uno a uno: System.HasModalDialog no ve los de Python (con
# FlixMenu abierto el vigilante seguía y vaciaba la lista de capítulos; Shield, 23-oct)
COVERED = ("System.HasModalDialog | Window.IsActive(contextmenu) | Window.IsActive(selectdialog) | "
           "Window.IsVisible(FlixMenu.xml) | Window.IsVisible(FlixResume.xml) | "
           "Window.IsVisible(FlixMovie.xml) | Window.IsVisible(FlixMessage.xml) | Window.IsVisible(FlixEditor.xml)")
SEASONS_LIST = 7952     # columna de temporadas (MyVideoNav vista 52: elementos fijos, su onclick manda)
EPS_IDS = {str(EPS_FIRST_ID + k) for k in range(EPS_SLOTS)}
LOADING = "Window.IsActive(busydialog) | Window.IsActive(selectdialog) | Window.IsActive(progressdialog)"
AFTER_STOP = 12         # s desde que había vídeo: lo que se abra al parar (progressdialog / selectdialog) no es un clic


BACK_PLAY_SECS = 30     # s tras parar en los que el foco vuelve al capítulo si la recarga se lo lleva
REFRESH_AFTER_STOP = 6  # s: si Kodi no recarga la carpeta tras el vídeo, los ✓ se refrescan igualmente


def back_to_episode(since_stop, idle):
    """¿devolver el foco al capítulo que se estaba viendo? Mientras nadie haya tocado el mando desde que se paró (la
    recarga de Kodi llega a los ~2-9 s) y como mucho BACK_PLAY_SECS"""
    return since_stop < BACK_PLAY_SECS and idle + 1 >= since_stop


def reload_pending(pending, updating, now):
    """¿seguimos esperando a que Kodi recargue la carpeta tras un vídeo? (mientras, las listas de capítulos ocultas)"""
    if not pending:
        return False
    done = pending["updated"] and not updating
    return not done and now - pending["t"] <= REFRESH_AFTER_STOP


def follow_column(col_path, col_now, column_focused):
    """(temporada que manda en el panel, ¿hay que corregir la selección de la columna?). El panel sigue a la columna
    SOLO mientras la columna tiene el foco: con el foco en los capítulos, la recarga de Kodi tras un vídeo le cambiaba
    la selección y el panel saltaba a otra temporada (banco, 25-oct)"""
    if col_now and (column_focused or not col_path):
        return col_now, False
    return col_path, bool(col_now and col_path and season_key(col_now) != season_key(col_path))


def column_delta(col_path, current_item):
    """cuánto mover la selección de la columna (Control.Move) para volver a col_path; 0 si no se sabe"""
    want = season_key(col_path)
    idx = next((i for i in range(MAX_SEASONS) if season_key(HOME.getProperty("flix_s%d_path" % i) or "-") == want), None)
    return idx - (int(current_item) - 1) if idx is not None and current_item.isdigit() else 0


def episode_click(loading, last_focus, layer_on, since_stop, ids=EPS_IDS, pressed=False):
    """¿acaba de pulsarse un capítulo de la lista? Kodi lo reproduce él (no pasa por flix_play) y la pantalla de carga
    única no salía: carga en marcha, el foco estaba en una lista de capítulos, sin capa aún y sin un capítulo recién
    parado. ids: listas de capítulos (la ficha propia añade la
    7976 de las series de una temporada). pressed (flix_user_press): consta la pulsación, da igual el tiempo"""
    return bool(loading) and last_focus in ids and not layer_on and (pressed or since_stop > AFTER_STOP)
MAX_SEASONS = 40        # huecos fijos de la columna (Includes_Flix.xml FlixSeasonSlots) y tope de la ficha propia
SEASON_FIELDS = ("title", "sub", "watched", "progress", "path", "plot", "genre", "seen")


def num(v):
    return int(v) if str(v or "").isdigit() else 0


def episodes(n):
    return "1 capítulo" if n == 1 else "%d capítulos" % n


def season_sub(it):
    """«10 capítulos  ·  2017» (lo que se sepa)"""
    n = num(it.get("total"))
    return "  ·  ".join(x for x in (n and episodes(n), it.get("year", "")) if x)


def season_state(it):
    """'watched', 'progress' o '': capítulos vistos en la base frente a los de la temporada (en emisión con todos los
    emitidos vistos: «En progreso» hasta que salga y se vea el último). Sin esos datos, el porcentaje de la carpeta"""
    seen = it.get("seen")
    total = num(it.get("total"))
    if seen is not None and total:
        return "watched" if seen >= total else "progress" if seen else ""
    pct = num(it.get("pct"))
    return "watched" if pct >= 100 else "progress" if pct else ""


def seen_label(it):
    """«5 de 10 vistos» para la ficha en tarjetas (21-nov); «» sin nada visto o sin el total"""
    seen, total = it.get("seen"), num(it.get("total"))
    if not seen or not total:
        return ""
    return "%d de %d %s" % (seen, total, "visto" if total == 1 else "vistos")


def season_row(it):
    """{campo: valor} (SEASON_FIELDS) de una temporada para la columna 7952: la etiqueta («Temporada 3» o la de la
    carpeta) y sus propiedades (sub, watched, progress, path, plot, genre). Una sola regla para los huecos fijos
    (season_props: flix_s<i>_*, FlixSeasonSlots) y los elementos que añade la ficha propia de TV (revisión 7-nov XML-06)"""
    n = it.get("season", -1)
    state = season_state(it)
    # una parte (n ≥ PART_BASE) se llama como dice la carpeta («Temporada 3», «… · Parte 2»)
    return {"title": "Temporada %d" % n if 0 < n < PART_BASE else it.get("label", ""),
            "sub": season_sub(it),
            "watched": "1" if state == "watched" else "",
            "progress": "1" if state == "progress" else "",
            "path": it.get("path", ""),
            "plot": it.get("plot", ""),
            "genre": it.get("genre", ""),
            "seen": seen_label(it)}


def season_props(items):
    """{propiedad de Window(home): valor} para la columna 7952 a partir de las temporadas ya leídas (sin pedirlas otra
    vez)"""
    out = {}
    for i in range(MAX_SEASONS):
        row = season_row(items[i]) if i < len(items) else dict.fromkeys(SEASON_FIELDS, "")
        out.update(("flix_s%d_%s" % (i, k), row[k]) for k in SEASON_FIELDS)
    return out


def db_sig(path):
    """huella de una base SQLite para no repetir la misma consulta: fecha y tamaño, también del -wal (como
    flix_progress.watched_sig), y el contador de cambios de la cabecera (bytes 24-27), que SQLite sube en cada
    escritura aunque el aparato guarde la hora del fichero por segundos y el tamaño no cambie. None si no se lee"""
    out = []
    for f in (path, path + "-wal"):
        try:
            st = os.stat(f)
            out.append((st.st_mtime_ns, st.st_size))
        except OSError:
            out.append(None)
    try:
        with open(path, "rb") as fh:
            out.append(fh.read(28)[24:])
    except OSError:
        return None
    return tuple(out)


_SEEN = [None, None]    # [(base, serie, huella), {temporada: vistos}] de la última consulta de seasons_seen


def seasons_seen(tmdb):
    """{temporada: capítulos vistos} de la serie en watched.db; None si no se puede saber.
    La ficha lo pide cada segundo (flix_series_sheet.step_seasons): con la misma huella de watched.db se repite lo de
    la vez anterior sin abrirla (revisión 29-oct DAT-07: 18 ms por consulta en proot). La huella se toma ANTES de leer:
    si se guarda algo mientras, la vuelta siguiente lo ve (como flix_progress, 25-oct)"""
    if not tmdb:
        return None
    db = xbmcvfs.translatePath(WATCHED)
    parts = k3_parts(tmdb)
    key = (db, tmdb, db_sig(db)) + ((_PARTS[0],) if parts else ())
    if key[2] is not None and _SEEN[0] == key:
        return dict(_SEEN[1])
    if parts:
        # por partes: {parte: vistos} con la temporada y el capítulo de TMDB de cada visto
        rows = watched_rows("SELECT season, episode FROM episodes_watched WHERE tmdb_id=? AND playcount>0", (tmdb,))
        if rows is None:
            return None
        where = {se: v for v, p in parts.items() if v != "_tail" for se in p["eps"]}
        out = {}
        for se in rows:
            v = where.get((int(se[0]), int(se[1])))
            if v is not None:
                out[v] = out.get(v, 0) + 1
    else:
        rows = watched_rows("SELECT season, COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND playcount>0 "
                            "GROUP BY season", (tmdb,))
        if rows is None:
            return None
        out = {s: c for s, c in rows}
    if key[2] is not None:
        _SEEN[:] = [key, dict(out)]
    return out


def season_item(label, s, total, year, pct, path, plot, genre):
    """(temporada como la usa la ficha, tmdb de su ruta) con lo leído de su elemento en la carpeta de la serie. Sin
    número de temporada en el elemento, el de su ruta (…/serie/<tmdb>/<T>)"""
    meta = route_meta(path)
    if not s.lstrip("-").isdigit() and "season" in meta:
        s = str(meta["season"])
    return {"label": label, "season": int(s) if s.lstrip("-").isdigit() else -1, "total": total, "year": year,
            "pct": pct, "path": path, "plot": plot, "genre": genre}, meta.get("tmdb", "")


def window_seasons(cid=None):
    """temporadas ya cargadas (no se vuelven a pedir): las de la ventana Vídeos o, con cid, las de esa lista (ficha
    propia, flix_series_sheet: lista 7976)"""
    c = "Container(%d)." % cid if cid else "Container."
    n = xbmc.getInfoLabel(c + "NumItems")
    out, tmdb = [], ""
    for i in range(min(int(n) if n.isdigit() else 0, MAX_SEASONS)):
        g = lambda k: xbmc.getInfoLabel("%sListItemAbsolute(%d).%s" % (c, i, k))  # noqa: E731
        if g("Label") == "..":
            continue
        it, t = season_item(g("Label"), g("Season"), g("Property(TotalEpisodes)"), g("Year"),
                            g("Property(WatchedEpisodePercent)"), g("FileNameAndPath"), g("Plot"), g("Genre"))
        tmdb = tmdb or t
        out.append(it)
    seen = seasons_seen(tmdb) if out else None
    for it in out:
        it["seen"] = None if seen is None else seen.get(it["season"], 0)
    return out


def fill_seasons(items):
    for k, v in season_props(items).items():
        HOME.setProperty(k, v)


def visible_seasons():
    """rellena la columna con las temporadas de la ventana y las devuelve (etiqueta, número, ruta)"""
    items = window_seasons()
    fill_seasons(items)
    return items


def eps_count(k):
    n = xbmc.getInfoLabel("Container(%d).NumItems" % (EPS_FIRST_ID + k))
    return int(n) if n.isdigit() else 0


def apply(out):
    for k, v in out.items():
        if k == "log":
            xbmc.log("[flix_series] %s" % v, xbmc.LOGINFO)
        elif v:
            HOME.setProperty(k, v)
        else:
            HOME.clearProperty(k)


def clear_eps():
    """sin capítulos de la serie anterior"""
    for k in range(EPS_SLOTS):
        HOME.clearProperty("flix_eps_c%d" % k)
    for k in ("flix_eps_slot", "flix_eps_loading", "flix_eps_failed", "flix_season_cur"):
        HOME.clearProperty(k)
    clear_pending_props()
    HOME.setProperty("flix_eps_id", str(SEASONS_LIST))


def refresh_eps_in_place(mon, hint="", wait=6):
    """tras marcar un capítulo (flix_menu): la lista de capítulos a la vista se vuelve a pedir EN SU SITIO (misma
    ruta + &reload=, como las filas del Inicio): Kodi no la vacía, llega con los ✓ al día y solo cambia ese
    icono. Antes se vaciaban todas («Cargando capítulos…») y no quedaba nada a la vista (Carlos, 23-oct). El foco se
    queda en el mismo capítulo: devuelve (lista, posición) y el vigilante lo enfoca cuando Kodi acaba de recargar la
    carpeta (si se hace aquí, la recarga lo vuelve a llevar a la columna de temporadas). hint = «lista,posición»
    que leyó flix_menu antes de abrir sus diálogos (aquí, recién cerrados, CurrentItem salía vacío)"""
    k = HOME.getProperty("flix_eps_slot")
    if not k.isdigit():
        return None
    cid = EPS_FIRST_ID + int(k)
    base = re.sub(r"&reload=\d+$", "", HOME.getProperty("flix_eps_c%s" % k))
    if not base or base == EMPTY_EPS:
        return None
    hcid, _, hpos = hint.partition(",")
    pos = hpos if hcid == str(cid) else xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
    pos = int(pos) - 1 if pos.isdigit() and int(pos) > 0 else None
    old = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, pos)) if pos is not None else ""
    xbmc.log("[flix_series] capítulos al día en su sitio (lista %d, posición %s)" % (cid, pos), xbmc.LOGINFO)
    HOME.setProperty("flix_eps_c%s" % k, "%s&reload=%d" % (base, int(time.time() * 1000)))
    end = time.time() + wait
    while pos is not None and time.time() < end and not mon.waitForAbort(0.15):
        now = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, pos))
        if now and now != old:                          # ya llegó la lista nueva
            break
    return (cid, pos) if pos is not None else None


def reload_eps():
    """la lista de capítulos a la vista, otra vez EN SU SITIO (misma ruta + &reload=) y sin esperar: ✓ y barras al día
    cuando la base de vistos cambia con la ficha abierta (flix_series_sheet.step_k3)"""
    k = HOME.getProperty("flix_eps_slot")
    base = re.sub(r"&reload=\d+$", "", HOME.getProperty("flix_eps_c%s" % k)) if k.isdigit() else ""
    if base and base != EMPTY_EPS:
        HOME.setProperty("flix_eps_c%s" % k, "%s&reload=%d" % (base, int(time.time() * 1000)))


def watch_seasons(folder):
    """Mientras la ventana Vídeos muestre las temporadas de esta serie: capítulos de la temporada enfocada en una de
    las listas EpsSlots. Sigue vivo durante la reproducción de un capítulo; termina al salir de la serie o al
    cerrarse Kodi (System.OnQuit: a los RunScript sin addon Kodi no les avisa por abortRequested; APA-03)"""
    import flix_common
    mon = flix_common.quit_monitor()
    items = visible_seasons()
    slots, away, sig_at, played = EpsSlots(), None, time.time(), False
    if items:
        # al día: la temporada donde se va, no la primera
        idx = season_index(items, HOME.getProperty("flix_series_next") or HOME.getProperty("flix_series_upto"),
                           HOME.getProperty("flix_series_part"))
        end = time.time() + 2                           # los huecos se ven un fotograma después de rellenarlos
        while time.time() < end and xbmc.getInfoLabel("Container(%d).NumItems" % SEASONS_LIST) != str(len(items)):
            mon.waitForAbort(0.05)
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (SEASONS_LIST, idx))
        # la temporada inicial, sin esperar al debounce: lo primero que se pide tras las temporadas
        apply(slots.step(items[idx]["path"], time.time(), eps_count, first=True))
        xbmc.log("[flix_series] %d temporadas a la vista; pido capítulos de la %d.ª" % (len(items), idx + 1),
                 xbmc.LOGINFO)
    sig = [(x["pct"], x["path"], x["total"], x.get("seen")) for x in items]
    refocus = None                                      # (lista, posición, hasta): capítulo marcado en flix_menu
    reloaded = False                                    # Kodi recargó la carpeta con la retención puesta
    last_focus, last_path, last_media = "", "", 0.0     # foco y ruta del capítulo antes de que salga un diálogo
    last_pos, play_from = "", None                      # posición en su lista y (lista, posición) del que se reproduce
    back_play = None                                    # (lista, posición, hora de parar): volver a ese capítulo
    back_try, back_ok = 0.0, 0.0                        # último intento de devolver el foco / desde cuándo está en él
    loading_from, last_loading = None, 0.0              # capítulo enfocado al EMPEZAR una carga (no en sus relevos)
    pending_refresh = None                              # ✓ del capítulo visto: refrescar cuando Kodi recargue la carpeta
    col_path, col_fixed = "", 0.0                       # temporada que manda en el panel (la de la columna al enfocarla)
    while not flix_common.quitting(mon):
        if xbmc.getCondVisibility("Player.HasMedia"):
            if not played:                              # empieza: de qué capítulo de la lista (para volver a él)
                play_from, loading_from = loading_from, None
                xbmc.log("[flix_series] vídeo en marcha desde %s" % (play_from,), xbmc.LOGINFO)
            played, last_media = True, time.time()      # tras parar: lo que se abra no es un clic
        if xbmc.getCondVisibility("Window.IsActive(videos)"):
            if pending_refresh and xbmc.getCondVisibility("Container.IsUpdating"):
                pending_refresh["updated"] = True       # Kodi recarga la carpeta tras el vídeo (aunque haya diálogos)
            if xbmc.getCondVisibility(LOADING):
                if time.time() - last_loading > 3:      # empieza una carga, no un relevo entre diálogos (0,2-0,5 s)
                    loading_from = (last_focus, last_pos) if last_focus in EPS_IDS and last_pos.isdigit() else None
                last_loading = time.time()
                # con capa ya puesta (flix_play), o con una acción del menú en marcha (sus diálogos también son
                # «carga»), no es un clic en un capítulo
                busy = HOME.getProperty("flix_playload") or HOME.getProperty("flix_working")
                import flix_playload
                if episode_click(True, last_focus, bool(busy), time.time() - last_media,
                                 pressed=bool(HOME.getProperty(flix_playload.USER_PRESS))):
                    flix_playload.begin(HOME.getProperty("flix_open_fanart"), last_path, mark=False)
                    xbmc.log("[flix_series] capítulo pulsado en la lista: pantalla de carga", xbmc.LOGINFO)
            elif not xbmc.getCondVisibility("System.HasModalDialog"):
                last_focus = xbmc.getInfoLabel("System.CurrentControlId")
                if last_focus in EPS_IDS:
                    last_path = xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % last_focus)
                    last_pos = xbmc.getInfoLabel("Container(%s).CurrentItem" % last_focus)
            if xbmc.getCondVisibility(COVERED):
                # un diálogo encima (FlixMenu, menú de Kodi): Container.* y las listas son las SUYAS -> la
                # columna se llenaba con sus elementos («Temporada 1» repetida, «Marcar como vista»), los capítulos se
                # iban y la carpeta «cambiaba» (este vigilante se terminaba). Nada hasta que se cierre (Shield, 23-oct)
                if flix_common.wait_quit(mon, WATCH_STEP):
                    break
                continue
            fp = xbmc.getInfoLabel("Container.FolderPath")
            if not fp or xbmc.getCondVisibility("Container.IsUpdating"):
                reloaded = reloaded or bool(HOME.getProperty("flix_series_hold"))
                if pending_refresh:
                    pending_refresh["updated"] = True
                if flix_common.wait_quit(mon, WATCH_STEP):  # Kodi recargando la carpeta (tras marcar)
                    break
                continue
            if fp != folder:
                break                                   # otra carpeta (Atrás, otra serie)
            away = None
            if xbmc.getCondVisibility("Control.HasFocus(52)"):
                # la lista de temporadas de Kodi está fuera de pantalla: al cerrar un menú el foco vuelve a ella y el
                # mando se movía sin que se viera nada (Fire TV, 23-oct) -> a la columna visible
                xbmc.executebuiltin("SetFocus(%d)" % SEASONS_LIST)
            if played and not xbmc.getCondVisibility("Player.HasMedia"):
                played = False                          # tras ver un capítulo: capítulos guardados con ✓ viejos
                # durante el vídeo la columna no tiene selección y el panel se queda sin hueco a la vista (active None):
                # el hueco es el de la lista desde la que se lanzó
                k = int(play_from[0]) - EPS_FIRST_ID if play_from else None
                xbmc.log("[flix_series] vídeo parado: lanzado desde %s (hueco %s)" % (play_from, k), xbmc.LOGINFO)
                if k is not None and 0 <= k < EPS_SLOTS and slots.paths[k] and k in slots.ready:
                    # lanzado desde una lista de la ficha: sigue a la vista y el foco vuelve a ese capítulo (antes se
                    # vaciaban todas y el foco acababa en la columna de temporadas; ya en 1.5.69, banco 25-oct). Sus ✓
                    # se refrescan en su sitio DESPUÉS de que Kodi recargue la carpeta: las dos llamadas a la vez
                    # hicieron fallar la recarga y Kodi saltó a la raíz de Vídeos (banco, 25-oct)
                    apply(slots.hide_keep(k))
                    pos = int(play_from[1]) - 1
                    back_play = (EPS_FIRST_ID + k, pos, time.time())
                    pending_refresh = {"hint": "%s,%s" % play_from, "t": time.time(), "updated": False, "k": k}
                else:
                    apply(slots.invalidate())
                play_from = None
            if pending_refresh and slots.active == pending_refresh["k"] and (
                    (pending_refresh["updated"] and not xbmc.getCondVisibility("Container.IsUpdating")) or
                    time.time() - pending_refresh["t"] > REFRESH_AFTER_STOP):
                # Kodi ya recargó la carpeta tras el vídeo (o no lo hizo) y la temporada vuelve a estar a la vista:
                # ahora sí, los ✓ del capítulo en su sitio
                refresh_eps_in_place(mon, pending_refresh["hint"], wait=0)
                pending_refresh = None
            elif pending_refresh and time.time() - pending_refresh["t"] > BACK_PLAY_SECS:
                pending_refresh = None                  # se fue a otra temporada: se pedirá al volver
            hint = HOME.getProperty("flix_eps_refresh")
            if hint:                                    # flix_menu marcó un capítulo: ✓ al día, en su sitio
                HOME.clearProperty("flix_eps_refresh")
                back = refresh_eps_in_place(mon, hint)
                refocus = (back + (None,)) if back else None
            hold = HOME.getProperty("flix_series_hold")
            age = time.time() - float(hold or 0)
            if hold and (age > HOLD_MAX or (not HOME.getProperty("flix_eps_refresh") and (reloaded or age > 3) and
                         xbmc.getCondVisibility("Container.Content(seasons) + !Container.IsUpdating"))):
                # suelta cuando Kodi ya recargó la carpeta (se refresca tras marcar: ~8 s en la Shield);
                # antes se soltaba al segundo, ANTES de que empezara, y todo se ocultaba mientras (Shield, 23-oct)
                HOME.clearProperty("flix_series_hold")  # la carpeta ya está otra vez (MyVideoNav: retención)
                hold, reloaded = "", False
            if refocus and not hold:                    # con la recarga en curso el foco aún se lo lleva Kodi
                rcid, rpos, until = refocus
                if until is None:
                    refocus = (rcid, rpos, time.time() + REFOCUS_SECS)
                elif time.time() > until or xbmc.getCondVisibility("Control.HasFocus(%d)" % rcid):
                    refocus = None
                elif xbmc.getCondVisibility("Control.HasFocus(%d) | Control.HasFocus(52)" % SEASONS_LIST):
                    xbmc.log("[flix_series] foco de vuelta al capítulo (lista %d, posición %d)" % (rcid, rpos),
                             xbmc.LOGINFO)
                    xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (rcid, rpos))
            if back_play:
                bcid, bpos, t_stop = back_play
                now = time.time()
                if not back_to_episode(now - t_stop, xbmc.getGlobalIdleTime()):
                    back_play = None
                elif xbmc.getCondVisibility("Control.HasFocus(%d)" % bcid):
                    back_ok = back_ok or now
                    if now - back_ok > 2:               # ya se quedó en el capítulo: no insistir más
                        back_play = None
                else:
                    back_ok = 0.0
                    if now - back_try > 0.5 and not xbmc.getCondVisibility("Container.IsUpdating") and \
                            not reload_pending(pending_refresh, False, now) and \
                            xbmc.getCondVisibility("Control.HasFocus(%d) | Control.HasFocus(52)" % SEASONS_LIST):
                        back_try = now                  # cada 0,5 s como mucho: la recarga se lo puede volver a llevar
                        xbmc.log("[flix_series] tras el vídeo, foco de vuelta al capítulo (lista %d, posición %d)"
                                 % (bcid, bpos), xbmc.LOGINFO)
                        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (bcid, bpos))
            if time.time() - sig_at > 1:                # Kodi recarga la carpeta tras ver un capítulo: ✓ al día
                sig_at = time.time()
                now = window_seasons()
                if [(x["pct"], x["path"], x["total"], x.get("seen")) for x in now] != sig and now:
                    sig = [(x["pct"], x["path"], x["total"], x.get("seen")) for x in now]
                    fill_seasons(now)
            col_now = xbmc.getInfoLabel("Container(%d).ListItem.Property(path)" % SEASONS_LIST)
            # tras parar un capítulo (back_play), la recarga de Kodi lleva el foco a la columna y le cambia la selección:
            # manda la temporada del capítulo hasta que el foco vuelva a él o se toque el mando
            col_path, fix = follow_column(col_path, col_now, xbmc.getCondVisibility("Control.HasFocus(%d)" % SEASONS_LIST)
                                          and not back_play)
            if fix and time.time() - col_fixed > 1:
                # la recarga de Kodi (tras un vídeo) cambió la selección de la columna con el foco en los capítulos: se
                # devuelve a la temporada a la vista sin mover el foco (si no, el panel saltaba a otra temporada)
                col_fixed = time.time()
                delta = column_delta(col_path, xbmc.getInfoLabel("Container(%d).CurrentItem" % SEASONS_LIST))
                if delta:
                    xbmc.executebuiltin("Control.Move(%d,%d)" % (SEASONS_LIST, delta))
            cur = col_path
            if cur != HOME.getProperty("flix_season_cur"):
                # temporada resaltada en la columna (táctil FTSeasonRow): con un diálogo encima Container(7952) ya no
                # es la columna y TODAS salían resaltadas (Carlos, 23-oct); esta propiedad no cambia mientras
                HOME.setProperty("flix_season_cur", cur)
            if not reload_pending(pending_refresh, xbmc.getCondVisibility("Container.IsUpdating"), time.time()):
                apply(slots.step(cur, time.time(), eps_count))  # tras un vídeo, nada a la vista hasta que Kodi recargue
        elif not xbmc.getCondVisibility("Player.HasMedia | Window.IsActive(busydialog) | "
                                        "Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog)"):
            away = away or time.time()
            if time.time() - away > 3:                  # ni en la serie ni viendo un capítulo
                break
        if mon.waitForAbort(WATCH_STEP):
            break
    HOME.clearProperty("flix_series_hold")          # fuera de la serie: nada de retener su pantalla
    xbmc.log("[flix_series] fin del vigilante de temporadas", xbmc.LOGINFO)


def episodes_of(cid):
    """[(número, ruta, título)] de una lista de capítulos ya cargada"""
    out = []
    n = xbmc.getInfoLabel("Container(%d).NumItems" % cid)
    for i in range(int(n) if n.isdigit() else 0):
        e = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Episode" % (cid, i))
        if e.isdigit():
            out.append((int(e), xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, i)),
                        xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, i))))
    return out


def ver():
    """botón de la ficha: «Seguir viendo · TxEy» / «Ver» / «Ver de nuevo» = flix_series_play (el capítulo que toca, o
    su T1 E1; el que está a medias, en su minuto). Al día: lo dice, con la fecha del siguiente si se sabe"""
    if HOME.getProperty("flix_series_upto"):
        soon = HOME.getProperty("flix_series_soon")
        xbmcgui.Dialog().notification(HOME.getProperty("flix_series_title") or "Serie",
                                      "Al día  ·  %s" % soon if soon else
                                      "Al día: aún no ha salido el capítulo siguiente al %s" %
                                      HOME.getProperty("flix_series_upto"), xbmcgui.NOTIFICATION_INFO, 4000)
        return
    play = HOME.getProperty("flix_series_play")
    if not play.startswith(K3_PLAY):
        xbmc.log("[flix_series] «Ver» sin capítulo: %r" % play[:80], xbmc.LOGINFO)
        return
    # por el mismo camino que «Seguir viendo» del aviso (play_full con Player().play: tras el tráiler de la ficha el
    # vídeo no se queda en ventana)
    import flix_play
    late = HOME.getProperty("flix_series_resume_at").partition("|")
    at = int(late[2]) if late[0] and late[0] == HOME.getProperty("flix_series_next") and late[2].isdigit() else 0
    flix_play.resume_series(play, HOME.getProperty("flix_open_fanart"), at)


def loaded_ok(path):
    n = xbmc.getInfoLabel("Container.NumItems")
    return xbmc.getInfoLabel("Container.FolderPath") == path and n.isdigit() and int(n) > 0


def wait_loaded(path, timeout=90):
    """True si la ventana Vídeos acaba mostrando 'path'. False si la carpeta falla: entonces Kodi deja a la vista la
    ÚLTIMA carpeta que tuvo esa ventana (p. ej. un "Especial Halloween" de antes) -> hay que detectarlo."""
    t0 = time.time()
    idle_since = None
    while time.time() - t0 < timeout:
        busy = xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Container.IsUpdating")
        if loaded_ok(path) and not busy:
            xbmc.sleep(600)                         # al fallar, Kodi pone un instante la ruta pedida y vuelve atrás
            if loaded_ok(path):
                return True
            continue
        if xbmc.getCondVisibility("Window.IsActive(videos)") and not busy and time.time() - t0 > 2:
            idle_since = idle_since or time.time()
            if time.time() - idle_since > 3:        # ventana quieta 3 s con otra carpeta = falló la carga
                return False
        else:
            idle_since = None
        if not xbmc.getCondVisibility("Window.IsActive(videos)") and time.time() - t0 > 5:
            return True                             # el usuario se fue: nada que vigilar
        xbmc.sleep(200)
    return False


def open_checked(seasons, title, tries=2):
    """Abre las temporadas tapando la carpeta vieja (MyVideoNav: flix_opening) y reintenta una vez si la carpeta
    falla."""
    HOME.setProperty("flix_opening", "1")
    try:
        for attempt in range(1, tries + 1):
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % seasons)
            if wait_loaded(seasons):
                return True
            xbmc.log("[flix_series] Ker0n3 no dio las temporadas de %s (intento %d)" % (title, attempt), xbmc.LOGINFO)
            if xbmc.getCondVisibility("Window.IsActive(videos)"):
                xbmc.executebuiltin("Action(Back)")     # fuera la carpeta vieja
                xbmc.sleep(800)
        xbmcgui.Dialog().notification(title, K3_NO_ANSWER_RETRY, xbmcgui.NOTIFICATION_INFO, 5000)
        return False
    finally:
        HOME.clearProperty("flix_opening")


# ---------- capítulos que aún no tienen versión (Carlos, 7-nov) ----------
# Debajo de los capítulos de la temporada, en la MISMA lista, salen atenuados y sin reproducir los que TMDB cuenta y la
# carpeta no da: «Sale el 14 nov» si aún no se ha emitido, «Aún no disponible · emitido el 5 nov» si ya salió. Los
# datos los trae flix_newep.season_episodes (caché de un día) y la ficha propia (flix_series_sheet.step_pending) los
# pone en Window(home).Property(flix_pend<i>_*): cada lista de capítulos lleva, además de su <content>, un 2.º
# <content> con PEND_SLOTS elementos fijos (FlixPendingItems; Kodi 21 junta los dos, CMultiProvider) que solo se ven
# en la lista flix_pend_list. Así es una sola lista: se baja de los capítulos a los pendientes sin cambiar de control
# (Carlos, 7-nov: «que salgan debajo de los otros», no como sección aparte). addItems a una lista con <content> no
# vale: Kodi los descarta al fotograma siguiente. ListItem.Property(flix_pending) = la frase: el XML atenúa la fila,
# no enseña barra ni ✓ y el clic solo avisa; sin Episode (episodes_of no los cuenta)
PENDING = "flix_pending"
PEND_SLOTS = 20         # elementos fijos por lista (FlixPendingItems, TV y táctil): más allá no se enseñan
PEND_FIELDS = ("label", "thumb", "when", "plot")
PENDING_FUTURE = "Sale el %s"
PENDING_TODAY = "Aún no disponible  ·  sale hoy"
PENDING_AIRED = "Aún no disponible  ·  emitido el %s"
PENDING_NODATE = "Aún no ha salido  ·  sin fecha"


def today_str():
    return time.strftime("%Y-%m-%d")


def pending_label(date, today):
    """la frase del capítulo pendiente, según su fecha de emisión (TMDB) frente a hoy"""
    d = date_es(date, today)
    if not d:
        return PENDING_NODATE
    if date > today:
        return PENDING_FUTURE % d
    if date == today:
        return PENDING_TODAY
    return PENDING_AIRED % d


def pending_episodes(tmdb_eps, have):
    """los de TMDB (flix_newep.parse_season) cuyo número no está entre los de la lista (have), por número"""
    have = {int(n) for n in have or () if str(n).isdigit() or isinstance(n, int)}
    return sorted((e for e in tmdb_eps or [] if isinstance(e.get("n"), int) and e["n"] not in have),
                  key=lambda e: e["n"])


def pending_rows(tmdb_eps, have, season, today=None, thumb=""):
    """[{label, plot, thumb, pending}] para la lista: etiqueta «2x09 Título» como la de los capítulos; la
    miniatura de TMDB o, sin ella (los futuros no tienen), la que se pase (el fanart de la serie, atenuado por el XML)"""
    today = today or today_str()
    out = []
    for e in pending_episodes(tmdb_eps, have):
        name = (e.get("name") or "").strip()
        out.append({"label": ("%sx%02d %s" % (season, e["n"], name)).strip(),
                    "plot": e.get("plot") or "",
                    "thumb": e.get("still") or thumb or "",
                    "pending": pending_label(e.get("date") or "", today)})
    return out


def part_tail(tmdb, v):
    """(temporada de TMDB, último capítulo de TMDB, k, capítulos de la parte) si la parte v es la del último capítulo de
    TMDB de la serie (los que estén por llegar de esa temporada van debajo de ella); None en las demás partes o sin
    reparto (entonces no se pinta ninguno: nada que no cuadre)"""
    parts = k3_parts(tmdb)
    tail = parts.get("_tail")
    if not tail or int(v) != tail[0]:
        return None
    return tail[1], tail[2], parts[tail[0]]["k"], tail[3]


def part_pending_rows(tmdb_eps, have, tail, today=None, thumb=""):
    """pending_rows de la última parte: solo los de su temporada de TMDB posteriores a su último capítulo (los de
    antes son de otras partes), con la numeración de la parte: «20x11 Título» (k y puesto tras los que tiene)"""
    _season, last, k, count = tail
    rows = pending_rows([e for e in tmdb_eps or [] if isinstance(e.get("n"), int) and e["n"] > last], have, k,
                        today=today, thumb=thumb)
    later = [e for e in pending_episodes(tmdb_eps, have) if e["n"] > last]
    for r, e in zip(rows, later):
        name = (e.get("name") or "").strip()
        r["label"] = ("%dx%02d %s" % (k, count + e["n"] - last, name)).strip()
    return rows


def pending_source(path, first_season=""):
    """(tmdb, temporada) de la lista de capítulos a la vista desde la ruta de su temporada (o la de la serie, en las de
    una temporada: la temporada es la del 1.er capítulo o la 1). ('', '') si no se sabe"""
    meta = route_meta(re.sub(r"&reload=\d+$", "", str(path or "")))
    tmdb = meta.get("tmdb", "")
    if not tmdb:
        return "", ""
    s = meta.get("season")
    if s is None:
        s = int(first_season) if str(first_season).isdigit() else 1
    return tmdb, str(s)


def pending_props(rows, cid, real):
    """{propiedad: valor} de Window(home) para los pendientes de la lista cid (pending_rows), hasta PEND_SLOTS; las de
    los huecos que sobran, vacías (ocultan el elemento). flix_pend_n / flix_pend_real: recuento para la cabecera"""
    out = {}
    rows = rows[:PEND_SLOTS]
    for i in range(PEND_SLOTS):
        r = rows[i] if i < len(rows) else None
        out["flix_pend%d_label" % i] = r["label"] if r else ""
        out["flix_pend%d_thumb" % i] = r["thumb"] if r else ""
        out["flix_pend%d_when" % i] = r["pending"] if r else ""
        out["flix_pend%d_plot" % i] = r["plot"] if r else ""
    out["flix_pend_list"] = str(cid) if rows else ""
    out["flix_pend_n"] = str(len(rows)) if rows else ""
    out["flix_pend_real"] = str(real) if rows else ""
    return out


def clear_pending_props():
    apply(pending_props([], 0, 0))


# al final: main() usa funciones de todo el fichero (clear_eps -> clear_pending_props)
if __name__ == "__main__":
    if sys.argv[1:2] == ["ver"]:
        ver()
    else:
        main()
