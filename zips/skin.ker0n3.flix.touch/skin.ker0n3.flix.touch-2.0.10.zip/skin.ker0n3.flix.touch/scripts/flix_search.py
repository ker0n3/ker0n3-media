# -*- coding: utf-8 -*-
"""Buscador (ventana Python WindowXML).

Uso desde el skin:
  RunScript(special://skin/scripts/flix_search.py)            -> pide texto con el teclado
  RunScript(special://skin/scripts/flix_search.py, <texto>)   -> busca directamente

Cómo funciona: dos consultas al addon Ker0n3 (ruta buscar/peliculas/<texto> y buscar/series/<texto>, a la vez, cada
una en su proceso del addon), una fila cada una. El addon ya busca en castellano y en TMDB (títulos alternativos) y
solo da lo que tiene alguna versión para ver. Las consultas van por JSON-RPC (Files.GetDirectory). La misma búsqueda
en los 10 min siguientes sale de memoria (results_get).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import threading
import time
import unicodedata
import urllib.parse
import xbmc
import xbmcgui
import xbmcvfs

import flix_builtin  # noqa: E402
from flix_common import A_BACK, COLOR_RE, atomic_write, clean  # noqa: E402,F401
# to_listitem y compañía viven en flix_items: la sección y el Inicio no cargan el buscador entero por ellas
# (revisión 29-oct ARR-19); aquí se vuelven a exportar
from flix_items import brackets, clean_title, langs_from_label, quality_from_label, to_listitem  # noqa: E402,F401

HOME = xbmcgui.Window(10000)
HIST_MAX = 5
SKIN_PATH = xbmcvfs.translatePath("special://skin/")
ROW_IDS = [5201, 5202, 5203, 5204, 5205, 5206, 5207, 5208]
CHIPS = {5301: 1, 5302: 2, 5303: 3, 5304: 4, 5305: 5}
BTN_NEW = 5309
K3_PARALLEL = 2      # Películas y Series a la vez; cada una es un proceso del addon aparte


def log(msg):
    xbmc.log("[flix_search] %s" % msg, xbmc.LOGINFO)


# ---------- consultas al addon Ker0n3 ----------
K3_ROOT = "plugin://plugin.video.ker0n3/"
K3_SEARCH = K3_ROOT + "buscar/%s/%s"


def is_k3(route):
    return (route or "").startswith(K3_ROOT)


def k3_routes(text):
    """las dos filas del buscador: una consulta por ruta (el addon ya busca en castellano y en TMDB)"""
    q = urllib.parse.quote(text, safe="")
    return [["Películas", K3_SEARCH % ("peliculas", q)], ["Series", K3_SEARCH % ("series", q)]]


# JSON-RPC común (revisión 29-oct DAT-20): la misma petición y ValueError si la respuesta no es JSON, como antes
from flix_common import rpc  # noqa: E402


SECTIONS = ["películas", "series", "dibujos", "anime", "documentales"]
SINGULAR = {"películas": "película", "series": "serie", "documentales": "documental"}


def count_label(n, label):
    """resumen de una fila: «3 películas», «1 película», «1 película de dibujos», «1 serie», «1 documental» (TV-27:
    nunca «1 películas»). Solo cambia la 1.ª palabra; si no acaba en -s (Anime, Música) se queda igual"""
    first, _, rest = label.lower().partition(" ")
    if n == 1:
        first = SINGULAR.get(first) or (first[:-1] if first.endswith("s") and not first.endswith("ss") else first)
    return "%d %s" % (n, first + (" " + rest if rest else ""))


def norm(t):
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


# ---------- resultados de la sesión ----------
# La misma búsqueda otra vez no vuelve a preguntar (revisión 29-oct APA-04, aprobado por Carlos). Cada apertura del
# buscador es otro intérprete: se guardan en Window(home) (memoria de la sesión de Kodi), RESULTS_TTL s, con clave el
# texto normalizado y las rutas. Si el catálogo cambia entre medias, esos 10 min sale lo de antes (decisión de Carlos).
RESULTS_TTL = 600
RESULTS_MAX = 5                     # búsquedas guardadas como mucho (las más viejas se sueltan)
RESULTS_INDEX = "flix_sr_index"     # {hueco: [hora, clave]}; cada búsqueda en Window(home).Property(flix_sr_<hueco>)
RESULTS_BYTES = 500000              # una búsqueda más grande no se guarda (antes 2 MB: hasta 10 MB de JSON en
                                    # propiedades de Window(home); revisión 7-nov PY-27)


def _results_slot(text, routes):
    """clave: el texto normalizado y las filas con su ruta sin lo buscado (la ruta lleva el texto tal cual)"""
    import zlib
    key = json.dumps([norm(text), [[lab, str(r).rsplit("/", 1)[0]] for lab, r in routes]], ensure_ascii=False)
    return key, "%08x" % zlib.crc32(key.encode("utf-8"))


def _results_index():
    try:
        idx = json.loads(HOME.getProperty(RESULTS_INDEX) or "{}")
    except ValueError:
        idx = {}
    return idx if isinstance(idx, dict) else {}


def results_get(text, routes):
    """{"rows": [[sección, títulos]], "paths": {...}, "summary": [...]} de esa búsqueda si se hizo hace menos de
    RESULTS_TTL s; None si no"""
    key, slot = _results_slot(text, routes)
    hit = _results_index().get(slot)
    try:
        if not hit or not 0 <= time.time() - float(hit[0]) < RESULTS_TTL:
            return None
        data = json.loads(HOME.getProperty("flix_sr_" + slot) or "null")
    except (TypeError, ValueError, IndexError):
        return None
    return data if isinstance(data, dict) and data.get("key") == key else None


def results_put(text, routes, rows, paths, summary):
    """guarda los resultados de una búsqueda acabada (rows: {sección: títulos}, en su orden)"""
    key, slot = _results_slot(text, routes)
    blob = json.dumps({"key": key, "rows": [[k, v] for k, v in rows.items()], "paths": paths or {},
                       "summary": summary})
    if len(blob) > RESULTS_BYTES:
        return
    now = time.time()
    idx = _results_index()
    idx[slot] = [now, key]
    for old in sorted(idx, key=lambda k: idx[k][0] if isinstance(idx[k], list) else 0)[:-RESULTS_MAX]:
        HOME.clearProperty("flix_sr_" + old)
        idx.pop(old, None)
    HOME.setProperty("flix_sr_" + slot, blob)
    HOME.setProperty(RESULTS_INDEX, json.dumps(idx))


def results_forget():
    for slot in _results_index():
        HOME.clearProperty("flix_sr_" + slot)
    HOME.clearProperty(RESULTS_INDEX)


# ---------- orden y filtro de lo que llega ----------
ARTICLES = ("el ", "la ", "los ", "las ", "lo ", "un ", "una ", "the ", "a ")
SHORT_MAX = 3   # «up», «it», «f1»: la búsqueda da muchos títulos con esas letras dentro de otras palabras


def is_short(text):
    n = norm(text)
    return bool(n) and " " not in n and len(n) <= SHORT_MAX


def word_match(text, title):
    """¿lo buscado está en el título como palabra entera? («up» en «Up» o «Pop-Up», no en «Superficie»)"""
    return re.search(r"\b%s\b" % re.escape(norm(text)), norm(title)) is not None


def is_exact(text, title):
    """el título es lo buscado (sin mayúsculas, tildes, signos ni artículo delante: «padrino» = «El padrino»)"""
    n0, nt = norm(text), norm(title)
    for art in ARTICLES:
        if nt.startswith(art) and not n0.startswith(art):
            nt = nt[len(art):]
            break
    return bool(n0) and nt == n0


def exact_first(rows, text):
    """orden de las filas: primero las que empiezan por el título exacto; si son todas o ninguna, como venían"""
    labels = list(rows)
    hit = [k for k in labels if rows[k] and is_exact(text, clean_title(rows[k][0].get("title") or rows[k][0].get("label")))]
    if not hit or len(hit) == len(labels):
        return labels
    return hit + [k for k in labels if k not in hit]


class NoAnswer(Exception):
    """Files.GetDirectory devolvió un error en vez de un listado (aunque fuera vacío): el addon no contestó"""


def fetch(route, text=None, terms=None):
    """resultados de una consulta al addon; NoAnswer si no contestó (antes daba [] y salía «Sin resultados»; TV-12).
    La ruta tal cual: un «&reload=…» el addon lo tomaría por parte del texto"""
    r = rpc("Files.GetDirectory", {
        "directory": route, "media": "video",
        "properties": ["title", "art", "plot", "year", "genre", "rating", "duration", "mpaa", "premiered", "file",
                       "playcount", "resume", "uniqueid"],
    })
    if r.get("error"):
        raise NoAnswer(str(r["error"]))
    return (r.get("result") or {}).get("files") or []


# ---------- historial ----------
def history():
    items = []
    for i in range(1, HIST_MAX + 1):
        v = xbmc.getInfoLabel("Skin.String(flix_hist%d)" % i)
        if v:
            items.append(v)
    return items


def push_history(text):
    items = [text] + [h for h in history() if h.lower() != text.lower()]
    items = items[:HIST_MAX]
    for i in range(1, HIST_MAX + 1):
        val = items[i - 1] if i <= len(items) else ""
        xbmc.executebuiltin(flix_builtin.set_string("flix_hist%d" % i, val))


# ---------- teclado en pantalla (TV y táctil; en táctil Kodi no puede abrir el teclado de Android) ----------
TOUCH = xbmc.getSkinDir().endswith(".touch")
KEYS = list("1234567890qwertyuiopasdfghjklñzxcvbnm'")   # orden QWERTY; FlixSearch.xml: botones 6000 + índice
SYMS = list("1234567890" "@#&_-+()/:" ";!?,.'\"*%=" "¿¡[]$~€º")  # capa de símbolos (tecla ?123), mismo nº de teclas
assert len(SYMS) == len(KEYS)
KEY_SPACE, KEY_BACK, KEY_CLEAR, KEY_ENTER, KEY_TOGGLE, KEY_VOICE = 6090, 6091, 6092, 6093, 6094, 6095
A_CONTEXT, A_VOICE = (101, 117), 300   # mantener OK = menú contextual en nuestra ventana; tecla de voz del mando
MENU_WAIT = 180   # s: lo más que se espera a que acabe una marca del menú para poner ✓ y ▶ al día
KEY_FIRST = 6010  # foco al abrir el teclado (la "q")
BOX = 5309      # caja de búsqueda: tocarla vuelve a mostrar el teclado
PREVIEW = 5290  # tira de carátulas visible encima del teclado mientras se escribe (resultados en vivo)
# búsqueda en vivo (solo táctil) tras una pausa al teclear.
# En la TV no hay búsqueda en vivo: con el mando cada letra tarda >1 s y lanzaba "bat", "batm"… -> solo "Buscar".
LIVE_DELAY, LIVE_MIN = 1.2, 3
LIVE_SPACING = 3.0   # s entre dos búsquedas en vivo: tecleando despacio encadenaba 2-3 («bat», «batm»…) (TAC-08)
# táctil: los resultados (teclado oculto) se ven en la ventana del Inicio (flix_home.py search): una lista vertical con
# inercia, como el Inicio y las secciones (aquí era un grouplist: sin inercia, a saltos; Carlos, 20-oct). Las filas le
# llegan por este fichero según responde el addon (= flix_home.SEARCH_FILE).
SEARCH_FILE = xbmcvfs.translatePath("special://temp/flix_search_rows.json")


# ---------- ventana ----------
class SearchWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.query = kwargs.get("query", "")
        self.shown, self.items = {}, {}             # lo pintado en cada lista: títulos y sus ListItem
        self.paint_lock = threading.RLock()

    def onInit(self):
        # Kodi vuelve a llamar a onInit al volver de una ficha, una serie o un vídeo: los resultados siguen en la
        # ventana, así que solo se vuelve a enlazar la caja (auditoría PY-02: antes se repetía la búsqueda entera)
        if getattr(self, "started", False):
            try:
                ctl = self.getControl(BOX)
                self.edit = ctl if isinstance(ctl, xbmcgui.ControlEdit) else None
            except Exception:  # noqa: BLE001
                self.edit = None
            self.repaint()                          # tras recargar la skin las listas vuelven vacías
            if getattr(self, "results_open", False):  # Atrás en la ventana de resultados: al teclado con lo buscado
                self.results_open = False
                self.show_kbd(True)
                return
            self.show_kbd(getattr(self, "kbd", False))  # Kodi devuelve el foco al control por defecto (tecla oculta)
            return
        self.started = True
        self.setProperty("flix_state", "loading" if self.query else "idle")
        self.abort = False
        self.worker = None
        self.typed = self.query
        self._deb = 0
        self.phys = False                               # escribe con un teclado físico (edit_changed)
        self.sym = False
        self.paint_keys()
        # caja = control edit en la TV (teclado físico); en la táctil es un botón
        try:
            ctl = self.getControl(BOX)
            self.edit = ctl if isinstance(ctl, xbmcgui.ControlEdit) else None
        except Exception:  # noqa: BLE001
            self.edit = None
        self.set_typed(self.typed)
        self.show_kbd(not self.query)                   # sin texto: teclado a la vista
        if self.query:
            self.start_search(self.query)
            self.show_results()
        if not TOUCH:                                   # QR para escribir desde el móvil (flix_phonekb.py)
            import flix_phonekb
            self.phone = flix_phonekb.PhoneKeyboard(self.phone_text, "Buscar películas y series", props=self).start()

    def phone_text(self, text):
        """texto escrito (o dictado) en el móvil: busca ya, como el dictado por voz"""
        if getattr(self, "abort", False):
            return
        self.set_typed(text)
        self._deb += 1
        self.show_kbd(False)
        push_history(text)
        self.cancel_search()
        self.start_search(text, record=False)
        self.show_results()

    def fill(self, cid, files, append=False):
        """pinta una lista por id (reset/addItems: seguros tras recargar la skin) y guarda lo pintado. Nada de
        getSelectedItem ni getSelectedPosition: tras una actualización automática el objeto de Python apunta a la
        lista vieja, ya borrada, y Kodi se cae (SIGSEGV, auditoría 22-oct A-01)"""
        new = [to_listitem(f) for f in files]
        with self._lock():
            ctl = self.getControl(cid)
            if append:
                self.shown.setdefault(cid, []).extend(files)
                self.items.setdefault(cid, []).extend(new)
            else:
                ctl.reset()
                self.shown[cid], self.items[cid] = list(files), new
            if new:
                ctl.addItems(new)

    def _lock(self):
        lock = getattr(self, "paint_lock", None)
        if lock is None:
            lock = self.paint_lock = threading.RLock()
        return lock

    def sel_item(self, cid):
        """ListItem seleccionado, con la posición que dice Kodi y los ListItem guardados"""
        try:
            pos = int(xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) or 0) - 1
        except ValueError:
            return None
        items = getattr(self, "items", {}).get(cid) or []
        return items[pos] if 0 <= pos < len(items) else None

    def repaint(self):
        """al volver a la ventana: si una lista con resultados está vacía, la skin se recargó -> se vuelve a pintar
        con ListItem nuevos (A-07: antes quedaba el resumen sin resultados y el foco en una fila vacía)"""
        with self._lock():
            for cid, files in list(getattr(self, "shown", {}).items()):
                if files and xbmc.getInfoLabel("Container(%d).NumItems" % cid) in ("", "0"):
                    log("lista %d vacía al volver (skin recargada): repinto %d" % (cid, len(files)))
                    self.fill(cid, files)

    def start_search(self, text, record=True):
        self.abort = False
        self.gen = getattr(self, "gen", 0) + 1          # cada búsqueda su número: la anterior queda obsoleta
        if TOUCH:                                       # ya, no en el hilo: show_results no debe ver las de antes
            self.results, self.result_paths = {}, {}
            self.write_results(self.gen)
        self.worker = threading.Thread(target=self._guarded_search, args=(text, record, self.gen), daemon=True)
        self.worker.start()

    def set_typed(self, text):
        """Texto escrito -> etiqueta de la caja y control edit (sin que cuente como tecleo físico)."""
        self.typed = text
        self.setProperty("flix_typed", text)
        if getattr(self, "edit", None):
            self.edit_seen = text
            self.edit.setText(text)

    def edit_changed(self):
        """onClick de la caja edit: Kodi lo manda por cada cambio de texto (teclado físico o su teclado propio)
        y con Intro sin cambios. Intro = Buscar; un salto de varias letras (teclado de Kodi, pegar) busca ya."""
        text = self.edit.getText()
        prev = getattr(self, "edit_seen", "")
        if text == prev:
            self.type_key(KEY_ENTER)
            return
        if len(text) == len(prev) - 1 and not getattr(self, "phys", False):
            # Atrás del mando en Android: llega como retroceso y el edit ya ha borrado la letra (su clic llega antes
            # que el onAction). Sin escribir con un teclado físico, Atrás no borra (Carlos 30-oct): vuelve la letra y
            # onAction lo trata como Atrás
            self.set_typed(prev)
            self.edit_time = 0
            return
        self.edit_seen = text
        self.edit_time = time.time()
        self.typed = text
        self.setProperty("flix_typed", text)
        self._deb += 1
        if abs(len(text) - len(prev)) == 1:          # una letra: teclado físico
            if len(text) > len(prev):                # solo una letra de más (borrar no lo marca, era el Atrás)
                self.phys = True                     # en esta apertura su retroceso sí borra
                if not xbmc.getCondVisibility("Skin.HasSetting(flix_physkbd)"):
                    xbmc.executebuiltin("Skin.SetBool(flix_physkbd)")   # en adelante el buscador abre con foco en la caja
            if not self.kbd:
                self.show_kbd(True, focus=BOX)
            if TOUCH:
                threading.Timer(LIVE_DELAY, self._live, args=(self._deb,)).start()
        else:
            self.type_key(KEY_ENTER)

    # --- resultados en la ventana del Inicio (táctil) ---
    def write_results(self, gen, done=False):
        rows = [{"label": k, "path": self.result_paths.get(k, ""), "files": v} for k, v in list(self.results.items())]
        try:
            atomic_write(SEARCH_FILE, json.dumps({"gen": gen, "done": done, "rows": rows}))
        except OSError as e:
            log("no escribo %s: %s" % (SEARCH_FILE, e))

    def show_results(self):
        """teclado oculto con una búsqueda: sus resultados en la ventana del Inicio en cuanto haya una fila"""
        if not TOUCH:
            return
        self.want_results = True
        self.open_results()

    def open_results(self):
        if not (getattr(self, "want_results", False) and getattr(self, "results", None)) or self.kbd \
                or getattr(self, "results_open", False):
            return
        self.want_results, self.results_open = False, True
        HOME.setProperty("flix_search_title", "«%s»" % self.query)
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,search)")

    # --- teclado táctil ---
    def show_kbd(self, on, focus=None):
        self.kbd = on
        self.setProperty("flix_kbd", "1" if on else "")
        if on and not TOUCH:
            if focus is None and getattr(self, "edit", None) and xbmc.getCondVisibility("Skin.HasSetting(flix_physkbd)"):
                focus = BOX                         # ya usó teclado físico: a escribir directamente
            self.setFocusId(focus or KEY_FIRST)
        elif not on and not TOUCH:
            self.focus_results()

    def focus_results(self):
        for rid in ROW_IDS:
            if getattr(self, "shown", {}).get(rid):  # no size(): tras recargar es una copia que miente
                self.setFocusId(rid)
                return
        self.setFocusId(BOX)

    def paint_keys(self):
        """Etiquetas de las teclas según la capa (letras / símbolos), como el toggle ?123 de Android."""
        layer = SYMS if self.sym else KEYS
        for i, ch in enumerate(layer):
            self.setProperty("flix_k%d" % i, ch.upper() if ch.isalpha() else ch)
        self.setProperty("flix_ktoggle", "ABC" if self.sym else "?123")

    def voice(self):
        """Dictado: abre el teclado de Kodi y le manda VoiceRecognizer (en ese teclado, mantener OK = voz de
        Android, como antes); lo dictado pasa a la búsqueda."""
        def go():
            xbmc.sleep(500)
            if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                xbmc.executebuiltin("Action(VoiceRecognizer)")
        threading.Thread(target=go, daemon=True).start()
        kb = xbmc.Keyboard(self.typed, "Buscar películas y series")
        HOME.setProperty("flix_voice", "1")         # DialogKeyboard.xml no se autocierra
        try:
            kb.doModal()
        finally:
            HOME.clearProperty("flix_voice")
        if not kb.isConfirmed():
            return
        text = kb.getText().strip()
        if not text:
            return
        self.set_typed(text)
        self._deb += 1
        self.show_kbd(False)
        push_history(text)
        self.cancel_search()
        self.start_search(text, record=False)
        self.show_results()

    def type_key(self, control_id):
        if KEY_ENTER == control_id:                 # Buscar: busca ya y oculta el teclado
            self._deb += 1
            self.show_kbd(False)
            text = self.typed.strip()
            if text:
                push_history(text)                  # recientes: lo buscado con «Buscar» (lo tecleado en vivo, no)
            if text and text != self.query:
                self.cancel_search()
                self.start_search(text, record=False)
            if text:
                self.show_results()
            return
        if KEY_TOGGLE == control_id:
            self.sym = not self.sym
            self.paint_keys()
            return
        if KEY_BACK == control_id:
            self.typed = self.typed[:-1]
        elif KEY_CLEAR == control_id:
            self.typed = ""
        elif KEY_SPACE == control_id:
            if self.typed and not self.typed.endswith(" "):
                self.typed += " "
        else:
            self.typed += (SYMS if self.sym else KEYS)[control_id - 6000]
        self.set_typed(self.typed)
        self._deb += 1
        if TOUCH:   # en vivo solo en la táctil; en la TV se busca al pulsar "Buscar" (pedido de Carlos)
            threading.Timer(LIVE_DELAY, self._live, args=(self._deb,)).start()

    def _live(self, deb):
        if deb != self._deb:
            return                                  # se siguió tecleando
        text = self.typed.strip()
        if not text:
            self.cancel_search()
            self.clear_rows()
            self.query = ""
            self.setProperty("flix_state", "idle")
            return
        if len(text) < LIVE_MIN or text == self.query:
            return
        since = time.time() - getattr(self, "live_at", 0.0)
        if since < LIVE_SPACING:                    # la anterior lleva menos de 3 s: se encola (vuelve a mirar lo tecleado)
            threading.Timer(LIVE_SPACING - since, self._live, args=(deb,)).start()
            return
        self.live_at = time.time()
        self.cancel_search()
        self.start_search(text, record=False)

    def cancel_search(self):
        # la búsqueda en curso queda obsoleta al instante (sus resultados ya no se pintan aunque lleguen tarde);
        # no se espera a que el addon termine la consulta que tenga entre manos
        self.gen = getattr(self, "gen", 0) + 1
        self.abort = False
        self.wake_event().set()                     # la espera de la obsoleta se entera ya

    def wake_event(self):
        """Event que despiertan los hilos de consulta al acabar y la cancelación: la espera de run_query ya no es un
        sleep de 50 ms (revisión 7-nov PY-28)"""
        ev = self.__dict__.get("wake")
        if ev is None:
            ev = self.__dict__["wake"] = threading.Event()
        return ev

    def clear_rows(self):
        for i, rid in enumerate(ROW_IDS, 1):
            self.fill(rid, [])
            self.setProperty("flix_row%d" % i, "")
        self.fill(PREVIEW, [])
        self.setProperty("flix_summary", "")

    def _guarded_search(self, text, record=True, gen=0):
        try:
            self.run_search(text, record, gen)
        except Exception as e:  # noqa: BLE001
            log("búsqueda abortada/fallida: %s" % e)

    def onAction(self, action):
        aid = action.getId()
        if (aid == 61448 and getattr(self, "edit", None) and self.getFocusId() == BOX
                and time.time() - getattr(self, "edit_time", 0) < 0.4):
            return          # retroceso crudo que el edit ya ha aplicado (su clic llega antes): no es "Atrás"
        if (aid == 110 or aid == 92 and getattr(self, "phys", False)) and getattr(self, "edit", None) \
                and self.getFocusId() == BOX and self.typed:
            # Retroceso (110) y, escribiendo con un teclado físico, el retroceso que Kodi da como "Atrás" (92) en la
            # caja con texto: borra una letra, como el teclado de Kodi. Sin teclado físico, el 92 (mando CEC o IR)
            # es Atrás (Carlos 30-oct)
            log("caja: retroceso (accion %d, boton %d)" % (aid, action.getButtonCode()))
            self.set_typed(self.edit.getText()[:-1])
            return
        if aid in A_BACK:  # Atrás (comunes, TV-28: antes sin el 9)
            if not getattr(self, "kbd", False) and self.query:
                self.show_kbd(True)                 # Atrás con resultados: vuelve al teclado con lo buscado (NAV-07)
                return
            self.abort = True
            self.wake_event().set()
            self.close()
            return
        if aid in (7, 135) and getattr(self, "edit", None) and self.getFocusId() == BOX:
            # OK del mando / Intro del teclado físico en la caja (el teclado de Kodi que abre el edit ya lo ha
            # cerrado DialogKeyboard.xml): escribiendo con texto = Buscar; si no, a nuestro teclado
            if self.kbd and self.typed.strip():
                self.type_key(KEY_ENTER)
            else:
                self.show_kbd(True, focus=KEY_FIRST)
            return
        if aid == A_VOICE or (aid in A_CONTEXT and (self.getFocusId() >= 6000 or self.getFocusId() in (BOX, 5300) or 5301 <= self.getFocusId() <= 5305)):
            self.voice()                            # mantener OK en el teclado / caja = hablar
            return
        if aid in A_CONTEXT and not TOUCH and (self.getFocusId() in ROW_IDS or self.getFocusId() == PREVIEW):
            self.open_menu(self.getFocusId())
            return
        super().onAction(action)

    def open_menu(self, cid):
        """menú KER0N3 (flix_k3menu: vista, resolución, favoritos…) del resultado con foco, como en las filas del Inicio
        y de las secciones. Antes salía el menú de Kodi, vacío (Carlos, 31-oct)"""
        item = self.sel_item(cid)
        path = item.getPath() if item else ""
        import flix_k3menu
        if not flix_k3menu.kind(path):
            log("menú: sin menú para %s" % (item.getLabel() if item else "nada"))
            return
        t0 = time.time()
        if flix_k3menu.menu(path, item.getLabel(), item.getArt("poster"), item.getArt("fanart")) == \
                flix_k3menu.PENDING:            # una marca en marcha: al acabar (flix_menu_done), ✓ y ▶ al día
            threading.Thread(target=self.after_menu, args=(cid, t0, getattr(self, "gen", 0)), daemon=True).start()

    def after_menu(self, cid, t0, gen):
        """cuando acaba la marca del menú (flix_menu_done): ✓ y ▶ al día en la fila, sin mover la selección"""
        mon, end = xbmc.Monitor(), t0 + MENU_WAIT
        while not self.stale(gen) and time.time() < end and not mon.abortRequested():
            done = HOME.getProperty("flix_menu_done")
            if done and float(done) > t0:
                break
            mon.waitForAbort(0.5)
        else:
            return
        if self.stale(gen):
            return
        import flix_rows
        try:
            pos = int(xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) or 0) - 1
        except ValueError:
            pos = 0
        focus = self.getFocusId()
        self.fill(cid, flix_rows._progress(self.shown.get(cid) or []))
        if pos > 0:
            self.getControl(cid).selectItem(pos)
        if focus == cid:
            self.setFocusId(cid)                    # Kodi suelta el foco de una lista que se vacía

    def stale(self, gen):
        return self.abort or (gen and gen != getattr(self, "gen", 0))

    def run_search(self, text, record=True, gen=0):
        t0 = time.time()
        log("buscar %s" % text)             # principio y fin (_run_search) de C3 sin depuración (revisión 29-oct DAT-22)
        self.query = text
        HOME.setProperty("flix_query", text)
        self.setProperty("flix_state", "loading")
        self.setProperty("flix_summary", "")
        self.setProperty("flix_error", "")
        for i, rid in enumerate(ROW_IDS, 1):
            self.fill(rid, [])
            self.setProperty("flix_row%d" % i, "")
        self.fill(PREVIEW, [])

        if record:
            push_history(text)
        HOME.setProperty("flix_searching", "true")
        try:
            self._run_search(text, gen, t0)
        finally:
            if not gen or gen == getattr(self, "gen", 0):   # una búsqueda vieja no apaga la marca de la nueva
                HOME.clearProperty("flix_searching")

    def _run_search(self, text, gen=0, t0=None):
        t0 = t0 or time.time()
        routes = k3_routes(text)
        hit = results_get(text, routes)
        if hit:                             # la misma búsqueda hace menos de 10 min: sin preguntar (APA-04)
            self.replay(hit, gen)
            log("fin %s: %d filas en %.1f s (de memoria)" % (text, len(hit["rows"]), time.time() - t0))
            return
        rows_by_label = {}
        rank = {label: i for i, (label, _route) in enumerate(routes)}

        def by_route(rows):
            """las filas en el orden de las rutas (Películas, Series…), lleguen cuando lleguen"""
            return {k: rows[k] for k in sorted(rows, key=lambda k: rank.get(k, len(rank)))}
        seen = set()
        lock = threading.Lock()
        qlock = threading.Lock()        # orden de entrega de las filas (deliver coge «lock» por dentro)
        failed, answered = [], []       # consultas sin respuesta / con respuesta (TV-12)
        spare = []
        short = is_short(text)

        def one(label, route, i):
            if self.stale(gen):
                return
            t1 = time.time()
            try:
                items = fetch(route)
                answered.append(label)
            except Exception as e:  # noqa: BLE001  (la fila vacía no debe dejar esperando a las siguientes)
                log("sección %s: %s" % (label, e))
                failed.append(label)
                items = []
            if not self.stale(gen):
                put(i, (label, items, time.time() - t1))
            wake.set()                              # un hueco libre: el bucle de abajo arranca la siguiente

        def deliver(label, items, dt):
            """resultados de una consulta a su fila (sin repetidos de la otra)"""
            with lock:
                items = [f for f in items if f.get("file") and f["file"] not in seen]
                log("sección %s %r -> %d (%.1fs)" % (label, text, len(items), dt))
                for f in items:
                    seen.add(f["file"])
                if short:
                    # «up»: letras sueltas dentro de las palabras (SUPerficie, BUPkis…): solo la palabra entera; lo
                    # demás se guarda por si no hay nada mejor
                    keep = [f for f in items if word_match(text, clean_title(f.get("title") or f.get("label")))]
                    spare.extend((label, f) for f in items if f not in keep)
                    items = keep
                show(label, items)

        def show(label, items):
            """añade a su fila; con el cerrojo cogido"""
            if not items:
                return
            if label not in rows_by_label:
                if len(rows_by_label) >= len(ROW_IDS):
                    return
                rows_by_label[label] = []
            old = []
            rows_by_label[label] = rows_by_label[label] + items
            order = exact_first(by_route(rows_by_label), text)
            if order != list(rows_by_label):        # fila con el título exacto: arriba nada más llegar
                focus = self.getFocusId()
                was = list(rows_by_label)
                moved = {k: rows_by_label[k] for k in order}
                rows_by_label.clear()
                rows_by_label.update(moved)
                log("filas: %s" % order)
                if not TOUCH:
                    for i, k in enumerate(order):
                        if k == label:
                            continue                # la nueva se pinta abajo
                        self.setProperty("flix_row%d" % (i + 1), "%s (%d)" % (k, len(rows_by_label[k])))
                        self.fill(ROW_IDS[i], rows_by_label[k])
                    if focus in ROW_IDS and ROW_IDS.index(focus) < len(was):   # el foco sigue en su fila
                        self.setFocusId(ROW_IDS[order.index(was[ROW_IDS.index(focus)])])
                    old = rows_by_label[label]      # su control se rehace entero abajo
            idx = list(rows_by_label.keys()).index(label)
            self.setProperty("flix_row%d" % (idx + 1), "%s (%d)" % (label, len(rows_by_label[label])))
            self.fill(PREVIEW, items, append=True)
            if TOUCH:
                if self.stale(gen):
                    return
                self.results = rows_by_label
                self.result_paths.setdefault(label, "")
                self.write_results(gen)
                self.open_results()
            else:
                if old:
                    self.fill(ROW_IDS[idx], rows_by_label[label])
                else:
                    self.fill(ROW_IDS[idx], items, append=True)
                if idx == 0 and len(rows_by_label[label]) == len(items) and not getattr(self, "kbd", False):
                    self.setFocusId(ROW_IDS[0])
            self.setProperty("flix_summary", "  ·  ".join(count_label(len(v), k) for k, v in rows_by_label.items()) + "  ·  buscando más…")

        # cada consulta a su fila EN CUANTO llega (18-nov, Carlos: Bleach serie estaba en 2 s y esperaba a las películas,
        # 5-6 s): las filas se colocan en el orden de las rutas (by_route en show; la que llega tarde se pone encima)
        def put(i, args):
            with qlock:
                deliver(*args)
        threads = [threading.Thread(target=one, args=(label, route, i), daemon=True)
                   for i, (label, route) in enumerate(routes)]
        wake = self.wake_event()
        for t in threads[:K3_PARALLEL]:
            t.start()
        pending = threads[K3_PARALLEL:]
        while not self.stale(gen) and (pending or any(t.is_alive() for t in threads if t.ident)):
            while pending and sum(1 for t in threads if t.ident and t.is_alive()) < K3_PARALLEL:
                pending.pop(0).start()
            wake.wait(0.25)                         # hasta que acabe una consulta o se cancele
            wake.clear()
        for t in threads:
            if t.ident:
                t.join(timeout=30)
        if self.stale(gen):
            return
        if not rows_by_label and spare:         # búsqueda corta sin la palabra entera en ningún título: lo que haya
            with lock:
                for label, f in spare:
                    show(label, [f])
        order = exact_first(rows_by_label, text)
        if order != list(rows_by_label):            # «up»: la fila con «Up» arriba del todo
            log("filas con %r exacto primero: %s" % (text, order[:3]))
            with lock:
                moved = {k: rows_by_label[k] for k in order}
                rows_by_label.clear()
                rows_by_label.update(moved)
                if not TOUCH:
                    for i, k in enumerate(order):
                        self.setProperty("flix_row%d" % (i + 1), "%s (%d)" % (k, len(rows_by_label[k])))
                        self.fill(ROW_IDS[i], rows_by_label[k])
                    if not getattr(self, "kbd", False):
                        self.setFocusId(ROW_IDS[0])
        summary = [count_label(len(v), k) for k, v in rows_by_label.items()]
        if rows_by_label and not self.stale(gen):   # sin nada no se guarda: quizá el addon falló
            try:
                results_put(text, routes, rows_by_label, getattr(self, "result_paths", {}) if TOUCH else {},
                            summary)
            except (TypeError, ValueError) as e:
                log("no guardo los resultados: %s" % e)
        if not rows_by_label and failed and not answered:
            log("%s: Ker0n3 no contestó a ninguna fila (%s)" % (text, failed))
            self.setProperty("flix_error", "2")     # «Ker0n3 no responde» (Includes_Flix.xml) en vez de «Sin resultados»
        elif not rows_by_label and failed:
            log("%s: Ker0n3 no contestó (%s)" % (text, failed))
        self.setProperty("flix_summary", "  ·  ".join(summary))
        self.setProperty("flix_state", "done")
        if TOUCH:
            self.write_results(gen, done=True)
        elif not getattr(self, "kbd", False):  # escribiendo: no robar el foco al teclado
            self.focus_results()
        log("fin %s: %d filas en %.1f s" % (text, len(rows_by_label), time.time() - t0))

    def replay(self, hit, gen):
        """pinta los resultados guardados de la misma búsqueda (results_get) como si acabara de contestar el addon"""
        rows = [(label, files) for label, files in hit.get("rows") or [] if files][:len(ROW_IDS)]
        if TOUCH:
            self.results = dict(rows)                   # flix_home (load_search) corrige ✓ y ▶ al pintarlos
            self.result_paths = dict(hit.get("paths") or {})
            self.write_results(gen, done=True)
            self.open_results()
        else:
            try:
                import flix_rows                        # ✓ y ▶ al día: lo guardado puede ser de hace unos minutos
                rows = [(label, flix_rows._progress(files)) for label, files in rows]
            except Exception as e:  # noqa: BLE001
                log("progreso de lo guardado: %s" % e)
            preview = []
            for i, (label, files) in enumerate(rows):
                self.setProperty("flix_row%d" % (i + 1), "%s (%d)" % (label, len(files)))
                self.fill(ROW_IDS[i], files)
                preview += files
            self.fill(PREVIEW, preview)
        self.setProperty("flix_summary", "  ·  ".join(hit.get("summary") or []))
        self.setProperty("flix_state", "done")
        if not TOUCH and not getattr(self, "kbd", False):
            self.focus_results()

    def onClick(self, control_id):
        if control_id == KEY_VOICE:
            self.voice()
            return
        if 6000 <= control_id < 6000 + len(KEYS) or control_id in (KEY_SPACE, KEY_BACK, KEY_CLEAR, KEY_ENTER, KEY_TOGGLE):
            self.type_key(control_id)
            return
        if control_id == BOX:
            if getattr(self, "edit", None):
                self.edit_changed()
            else:
                self.show_kbd(True)
            return
        if control_id in ROW_IDS or control_id == PREVIEW:
            item = self.sel_item(control_id)
            if not item:
                return
            if self.query:
                push_history(self.query)            # en vivo: al historial solo lo que se ha abierto
            path = item.getPath()
            if item.getProperty("filetype") == "directory":
                xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
            else:
                import flix_play
                tag = item.getVideoInfoTag()
                flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))
        elif control_id in CHIPS:
            text = xbmc.getInfoLabel("Skin.String(flix_hist%d)" % CHIPS[control_id])
            if text:
                self.set_typed(text)
                self.show_kbd(False)
                self.cancel_search()
                self.start_search(text)
                self.show_results()




def main():
    text = sys.argv[1].strip() if len(sys.argv) > 1 else ""
    # banco de pruebas (tools/xvfb/tour.sh): special://temp/flix_debug.txt con el texto a buscar (se borra al usarlo)
    dbg = xbmcvfs.translatePath("special://temp/flix_debug.txt")
    if xbmcvfs.exists(dbg):
        with xbmcvfs.File(dbg) as fh:
            text = fh.read().strip().split("|")[0]
        xbmcvfs.delete(dbg)
        log("debug: query=%r" % text)
    win = SearchWindow("FlixSearch.xml", SKIN_PATH, "Default", "1080i", query=text)
    try:
        win.doModal()
    finally:
        win.abort = True
        if getattr(win, "phone", None) is not None:
            win.phone.stop()
        # cerrado el buscador, sus avisos ya no se esconden aunque la consulta en curso siga: antes la marca se
        # quedaba hasta que contestaba y un aviso salía invisible pero modal (A-11)
        HOME.clearProperty("flix_searching")
    del win


if __name__ == "__main__":
    main()
