"""Menú de pulsación larga (menú KER0N3) de los títulos del addon Ker0n3 (plugin://plugin.video.ker0n3/…).

Un solo menú (Carlos, 16-nov): la ventana FlixMenu.xml —carátula, título, estado y botones grandes—, con lo que
funciona sin depender de ningún servicio:
  · «Ver ficha» y, en películas, «Elegir resolución» (la lista de versiones, con la marca de «una vez»);
  · vista / no vista (película y serie; en la tarjeta de un capítulo de «Seguir viendo», «Marcar como visto»);
  · «Quitar progreso / dejar de seguir» en lo que está a medias y «Dejar de seguir la serie» en las que se siguen.
El estado («Sin empezar», «Vista», «Empezada · …») sale de la base de vistos de Ker0n3 (una lectura local: el menú se
abre sin red y sin arrancar el addon). Las marcas las hace el addon (ruta marcar/…, ker0n3/marks.py: base propia, cola
de Simkl / Trakt y repintado de filas como al parar un vídeo); aquí se enseña la rueda mientras tanto y el aviso al
acabar. Bloque 3 (16-nov): «Añadir a favoritos» / «Quitar de favoritos» (base propia; el corazón de las fichas hace lo
mismo: favorite) y «Ver similares» (TMDB, con títulos de Ker0n3).

Capítulo de la FICHA de una serie (16-nov; in_sheet): flix_menu.run_menu lo trae aquí: «Ver», «Elegir resolución»,
«Marcar como visto / no visto», «Quitar progreso» si está a medias y «Marcar vistos hasta aquí»; en la columna de
temporadas, el menú de la serie (sin «Ver ficha»: ya se está en ella). Ahí la marca se espera (wait): quien llama es un
script que acaba al volver y un hilo suyo moriría a medias.

«Quitar progreso» (16-nov) sale también si la pausa solo la tiene el servicio (Trakt o Simkl; p. ej. una vieja que
aquí ya se quitó): el addon deja en cada bajada la lista de lo que el servicio tiene en pausa (PAUSES_FILE, junto a la
base) y aquí se lee del disco, sin red."""
import json
import os
import re
import threading
import time

import xbmc
import xbmcgui

K3_ROOT = "plugin://plugin.video.ker0n3/"
K3_MOVIE = K3_ROOT + "play/pelicula/"
K3_SERIE = K3_ROOT + "serie/"
HOME = xbmcgui.Window(10000)

OPT_RES, OPT_SHEET = "Elegir resolución", "Ver ficha"
DONE = "k3_mark_done"       # Window(10000): lo deja el addon al acabar una marca («ok|hora», «igual|…», «error|…»)
MARK_WAIT = 45              # s como mucho esperando al addon (una serie entera pide su ficha a TMDB)
PENDING = "pending"         # menu(): se ha lanzado una marca; al acabar bien se pone flix_menu_done
TIPOS = {"movie": "pelicula", "show": "serie", "episode": "capitulo"}
PAUSES_FILE = "service_pauses.json"     # = sync.PAUSES del addon (test_k3_pausas_servicio)
# acción -> (texto, icono, acción de la ruta marcar/ del addon, rueda mientras tanto, aviso al acabar)
ACTIONS = {
    "sheet": (OPT_SHEET, "info", None, None, None),
    "res": (OPT_RES, "sliders-horizontal", None, None, None),
    "seen": ("Marcar como vista", "check", "vista", "Marcando como vista…", "Marcada como vista"),
    "unseen": ("Marcar como no vista", "x", "novista", "Marcando como no vista…", "Marcada como no vista"),
    "ep_seen": ("Marcar como visto", "check", "vista", "Marcando como visto…", "Marcado como visto"),
    "play": ("Ver", "play", None, None, None),
    "ep_unseen": ("Marcar como no visto", "x", "novista", "Marcando como no visto…", "Marcado como no visto"),
    "ep_upto": ("Marcar vistos hasta aquí", "check", "hasta", "Marcando vistos hasta aquí…",
                "Marcados como vistos hasta aquí"),
    "nopause": ("Quitar progreso / dejar de seguir", "rewind", "sinpausa", "Quitando progreso…", "Progreso quitado"),
    "show_seen": ("Marcar serie como vista", "check", "vista", "Marcando serie como vista…",
                  "Serie marcada como vista"),
    "show_unseen": ("Marcar serie como no vista", "x", "novista", "Marcando serie como no vista…",
                    "Serie marcada como no vista"),
    "fav_add": ("Añadir a favoritos", "heart", "favorita", "Añadiendo a favoritos…", "Añadida a favoritos"),
    "fav_del": ("Quitar de favoritos", "heart-off", "nofavorita", "Quitando de favoritos…", "Quitada de favoritos"),
    "similar": ("Ver similares", "sparkles", None, None, None),
    "tlists": ("Listas de Trakt…", "list-video", None, None, None),
    "tl_del": ("Quitar de esta lista", "x", None, None, None),
    "unfollow": ("Dejar de seguir la serie", "delete", "noseguir", "Dejando de seguir la serie…",
                 "Serie quitada de Series en seguimiento"),
}
_TITLE = re.compile(r"^(?:play/pelicula/(\d+)|serie/(\d+)(?:/\d+)?|play/capitulo/(\d+)/(\d+)/(\d+))/?$")
_TAGS = re.compile(r"(?:\s*\[[^\]]*\])+\s*$")       # «[Esp] [4K HDR]» del final de la etiqueta de Ker0n3


def target(path):
    """{"kind": movie | show | episode, "tmdb", ["season", "episode"]} de un título de Ker0n3; None si no lo es"""
    path = str(path or "")
    if not path.startswith(K3_ROOT):
        return None
    m = _TITLE.match(re.split(r"[?&]", path[len(K3_ROOT):], maxsplit=1)[0])
    if not m:
        return None
    if m.group(1):
        return {"kind": "movie", "tmdb": int(m.group(1))}
    if m.group(2):
        return {"kind": "show", "tmdb": int(m.group(2))}
    return {"kind": "episode", "tmdb": int(m.group(3)), "season": int(m.group(4)), "episode": int(m.group(5))}


def kind(path):
    """«movie», «serie», «episode» (tarjeta de capítulo de «Seguir viendo») o None (otra cosa: sin menú)"""
    path = path or ""
    if path.startswith(K3_MOVIE):
        return "movie"
    if path.startswith(K3_SERIE):
        return "serie"
    if (target(path) or {}).get("kind") == "episode":
        return "episode"
    return None


def _rows(sql, args):
    """filas de la base de vistos de Ker0n3; [] si no existe o falla"""
    try:
        import flix_common
        return flix_common.watched_query(flix_common.watched_path(), sql, args, snapshot=False, timeout=1) or []
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_k3menu] base de vistos: %s" % e, xbmc.LOGINFO)
        return []


def service_paused(t):
    """¿el servicio tiene en pausa esta película o este capítulo? (la lista que deja el addon al bajar; sin ella o
    rota, no)"""
    try:
        import flix_common
        with open(os.path.join(os.path.dirname(flix_common.watched_path()), PAUSES_FILE), encoding="utf-8") as f:
            d = json.load(f)
        if t["kind"] == "movie":
            return t["tmdb"] in (d.get("movies") or [])
        return [t["tmdb"], t["season"], t["episode"]] in [list(e) for e in d.get("episodes") or []]
    except Exception:  # noqa: BLE001
        return False


def is_favorite(t):
    """¿está en favoritos? (tabla favorites de la base propia; película y serie van aparte)"""
    return bool(_rows("SELECT 1 FROM favorites WHERE tmdb_id=? AND content=?",
                      (str(t["tmdb"]), "movies" if t["kind"] == "movie" else "shows")))


def extras(t, in_sheet, origin=""):
    """las últimas opciones, como en el menú de siempre: favoritos (película y serie) y «Ver similares» (también la
    tarjeta de un capítulo: los de su serie); en la ficha de la serie no (tiene su corazón y su botón).
    origin: la ruta de la fila o cuadrícula de donde viene el título; si es una lista de Trakt que lo tiene, «Quitar de
    esta lista» (19-nov, Carlos: elegir en «Listas de Trakt…» la lista en la que ya está «no es muy intuitivo»)"""
    if in_sheet:
        return []
    fav = [] if t["kind"] == "episode" else ["fav_del" if is_favorite(t) else "fav_add"]
    tl = []
    if t["kind"] != "episode" and trakt_on():
        tl = (["tl_del"] if origin_list(t, origin) is not None else []) + ["tlists"]
    return fav + tl + ["similar"]


_ORIGIN = re.compile(r"lista/trakt-(\d+|watchlist-(?:pelis|series))(?:/|$|\?)")


def origin_list(t, origin):
    """id de la lista de Trakt de la fila de origen (WATCHLIST_ID para la watchlist) si el título está en ella; None si
    no (o la fila no es de una lista de Trakt)"""
    m = _ORIGIN.search(str(origin or ""))
    if not m or t.get("kind") == "episode":
        return None
    try:
        from ker0n3 import trakt_lists
        kind = "movie" if t["kind"] == "movie" else "tv"
        if m.group(1).isdigit():
            lid = int(m.group(1))
            return lid if (kind, t["tmdb"]) in trakt_lists.members(lid) else None
        return trakt_lists.WATCHLIST_ID if trakt_lists.in_watchlist(kind, t["tmdb"]) else None
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_k3menu] lista de origen: %s" % e, xbmc.LOGINFO)
        return None


def trakt_on():
    """¿Trakt vinculado y en uso? (las listas de la cuenta, guardadas por el servicio del addon; sin red)"""
    try:
        from ker0n3 import trakt_lists
        return bool(trakt_lists.load().get("on"))
    except Exception:  # noqa: BLE001
        return False


WL_NAME = "Watchlist (pendientes)"


def _pick(dialog, props, sub, entries):
    """índice de la opción elegida de entries [(texto, icono)], -1 = Atrás. En la ventana del menú KER0N3, con la
    carátula y el título (19-nov, Carlos: el diálogo de lista de Kodi era «muy básico y más oscuro»); dialog: el de
    las pruebas (select)"""
    if dialog is not None:
        return dialog.select(sub, [e[0] for e in entries])
    p = dict(props or {}, fm_sub=sub, fm_state="new")
    c = choose(p, [("i%d" % k, text, icon) for k, (text, icon) in enumerate(entries)])
    return int(c[1:]) if c and c.startswith("i") and c[1:].isdigit() else -1


def _confirm(dialog, props, sub, text):
    """¿sí? Igual que _pick: «text» (con icono de borrar) o «Cancelar»"""
    if dialog is not None:
        return bool(dialog.yesno("Borrar lista", "%s[CR]%s" % (sub, text)))
    return _pick(None, props, sub, [(text, "delete"), ("Cancelar", "x")]) == 0


def _n_titles(n):
    n = int(n or 0)
    return "1 título" if n == 1 else "%d títulos" % n


def _list_name(lid):
    from ker0n3 import trakt_lists
    if lid == trakt_lists.WATCHLIST_ID:
        return WL_NAME
    return next((x["name"] for x in trakt_lists.mine() if x["id"] == lid), "la lista")


def trakt_menu(t, title, dialog=None, remove_from=None, props=None):
    """«Listas de Trakt…» (18-nov, Carlos): «Añadir a «X»» / «Quitar de «X»» por lista (la watchlist primero),
    «Nueva lista…» (pide el nombre, la crea privada y lo añade) y «Borrar una lista…» (19-nov; con confirmación).
    remove_from: id de la lista de la que quitarlo sin preguntar («Quitar de esta lista» de la fila de origen).
    props: la cabecera del menú KER0N3 (carátula, título) para las ventanas de elegir.
    True si cambió algo (la sección se repinta), False si falló, None si nada"""
    from ker0n3 import trakt, trakt_lists
    kind = "movie" if t["kind"] == "movie" else "tv"
    own = trakt_lists.mine()
    if remove_from is not None:
        i, mine, inside = None, [], set()
    else:
        wl = {"id": trakt_lists.WATCHLIST_ID, "name": WL_NAME}
        inside = {x["id"] for x in own if (kind, t["tmdb"]) in trakt_lists.members(x["id"])}
        if trakt_lists.in_watchlist(kind, t["tmdb"]):
            inside.add(wl["id"])
        mine = [wl] + own               # la watchlist primero: es la lista de Trakt de siempre
        entries = [(("Quitar de «%s»" if x["id"] in inside else "Añadir a «%s»") % x["name"],
                    "x" if x["id"] in inside else "plus") for x in mine] + \
            [("Nueva lista…", "list-video")] + ([("Borrar una lista…", "delete")] if own else [])
        i = _pick(dialog, props, "Listas de Trakt", entries)
        if i is None or i < 0:
            return None
    name = ""
    if i == len(mine):
        name = ((dialog or xbmcgui.Dialog()).input("Nombre de la lista nueva") or "").strip()
        if not name:
            return None
        if name.isdigit():          # 19-nov (Carlos, «1»): Trakt contesta 400 a un nombre que solo son números
            notify("Trakt no acepta un nombre solo con números")
            return None
    gone = None
    if i is not None and i == len(mine) + 1:
        j = _pick(dialog, props, "Borrar una lista de Trakt",
                  [("%s  ·  %s" % (x["name"], _n_titles(x.get("n"))), "list-video") for x in own])
        if j is None or j < 0:
            return None
        gone = own[j]
        if not _confirm(dialog, props, "¿Borrar «%s» de tu Trakt con todo lo que tiene? No se puede deshacer"
                        % gone["name"], "Borrar «%s»" % gone["name"]):
            return None
    HOME.setProperty("flix_working", "Trakt…")
    try:
        if gone is not None:
            trakt_lists.delete_list(gone["id"])
            done, lid_changed = "Lista «%s» borrada" % gone["name"], gone["id"]
        elif remove_from is not None:
            if remove_from == trakt_lists.WATCHLIST_ID:
                trakt_lists.watchlist_set(kind, t["tmdb"], False)
            else:
                trakt_lists.remove(remove_from, kind, t["tmdb"])
            done, lid_changed = "Quitada de «%s»" % _list_name(remove_from), remove_from
        elif i == len(mine):
            lid = trakt_lists.create(name)
            trakt_lists.add(lid, kind, t["tmdb"])
            done, lid_changed = "Añadida a «%s»" % name, lid
        else:
            x = mine[i]
            if x["id"] == trakt_lists.WATCHLIST_ID:
                trakt_lists.watchlist_set(kind, t["tmdb"], x["id"] not in inside)
            elif x["id"] in inside:
                trakt_lists.remove(x["id"], kind, t["tmdb"])
            else:
                trakt_lists.add(x["id"], kind, t["tmdb"])
            done = ("Quitada de «%s»" if x["id"] in inside else "Añadida a «%s»") % x["name"]
            lid_changed = x["id"]
    except trakt.TraktError as e:
        xbmc.log("[flix_k3menu] Trakt: %s" % e, xbmc.LOGWARNING)
        import flix_common
        notify("Trakt no deja más con tu cuenta (límite de listas o de títulos)" if e.code == trakt_lists.LIMIT
               else "No se ha podido. %s" % flix_common.RETRY_LATER)
        return False
    finally:
        HOME.clearProperty("flix_working")
    try:            # su fila (Inicio y secciones), otra vez a su ruta
        import flix_rows
        flix_rows.expire(re.compile(r"lista/trakt-watchlist" if lid_changed == trakt_lists.WATCHLIST_ID
                                    else r"lista/trakt-%d(?:/|$)" % int(lid_changed)))
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_k3menu] fila de la lista: %s" % e, xbmc.LOGINFO)
    HOME.setProperty("flix_menu_done", "%f" % time.time())
    notify(done)
    return True


def ep_label(t):
    """«T1 E4» del capítulo; en una serie por partes, el de la ficha («T20 E9»: ker0n3.parts, solo lo guardado)"""
    try:
        from ker0n3 import parts
        return parts.label(t["tmdb"], t["season"], t["episode"])
    except Exception:  # noqa: BLE001
        return "T%s E%s" % (t["season"], t["episode"])


def state(t, in_sheet=False, origin=""):
    props, opts = _state(t, in_sheet)
    return props, opts + extras(t, in_sheet, origin)


def _state(t, in_sheet=False):
    """(propiedades de la cabecera, opciones) según la base de vistos.
    in_sheet: el elemento está en la ficha de su serie (capítulo de la lista o temporada de la columna)"""
    import flix_play
    tmdb = str(t["tmdb"])
    if t["kind"] == "show":
        row = _rows("SELECT completa, num_total_episodios, ocultar FROM shows_watched WHERE tmdb_id=?", (tmdb,))
        n = _rows("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND season>0 AND playcount>0", (tmdb,))
        seen, done = (n[0][0] if n else 0), bool(row and row[0][0])
        total = int(row[0][1] or 0) if row else 0
        caps = "%d capítulo visto" % seen if seen == 1 else "%d capítulos vistos" % seen
        if total:
            sub = "%d de %d %s" % (seen, total, "capítulo visto" if total == 1 else "capítulos vistos")
        else:
            sub = caps if seen else "Sin empezar"
        opts = ([] if in_sheet else ["sheet"]) + ([] if done else ["show_seen"]) + \
            (["show_unseen"] if done or seen else [])
        if row and not row[0][2] and not done:
            opts.append("unfollow")             # está en «Series en seguimiento»
        return {"fm_state": "watched" if done else "new", "fm_sub": sub, "fm_pct": "0"}, opts
    if t["kind"] == "movie":
        row = _rows("SELECT playcount, progress, runtime FROM movies_watched WHERE tmdb_id=?", (tmdb,))
    else:
        row = _rows("SELECT playcount, progress, runtime FROM episodes_watched WHERE tmdb_id=? AND season=? "
                    "AND episode=?", (tmdb, t["season"], t["episode"]))
    watched = int(row[0][0] or 0) if row else 0
    pct = float(row[0][1] or 0) if row else 0.0
    total = float(row[0][2] or 0) if row else 0.0
    started = pct > 0                           # la base solo guarda progreso de lo que quedó a medias de verdad
    if started and total:
        sub = "Empezada  ·  %s de %s" % (flix_play.fmt(total * pct / 100), flix_play.fmt(total))
    elif started:
        sub = "Empezada  ·  %d %%" % pct
    else:
        sub = "Vista" if watched else "Sin empezar"
    if t["kind"] == "episode":
        sub = "%s  ·  %s" % (ep_label(t), sub)
        if in_sheet:
            opts = ["play", "res", "ep_unseen" if watched and not started else "ep_seen"]
        else:           # tarjeta de «Seguir viendo»
            opts = ["sheet"] + ([] if watched and not started else ["ep_seen"])
    else:
        opts = ["sheet", "res", "unseen" if watched and not started else "seen"]
    if started or service_paused(t):
        opts.append("nopause")
    if t["kind"] == "episode" and in_sheet:
        opts.append("ep_upto")
    # 24-nov (Carlos: «Elegir versión» desde «Seguir viendo» empezaba desde el principio): el punto donde se quedó,
    # para «Ver» y «Elegir versión» del menú (resume_at); el mismo criterio que la ficha (flix_play._play)
    pos = total * pct / 100 if started and total else 0.0
    return {"fm_state": "started" if started else "watched" if watched else "new", "fm_sub": sub, "fm_pos": pos,
            "fm_total": total,
            "fm_pct": str(int(pct)) if started else "0"}, opts


class Menu(xbmcgui.WindowXMLDialog):
    """la ventana del menú KER0N3 (FlixMenu.xml): cabecera por propiedades fm_* y la lista 9100 con texto,
    Property(icon) y Property(act)"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props, self.opts, self.choice = kwargs.get("props", {}), kwargs.get("opts", []), None

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v if isinstance(v, str) else str(v))      # fm_pos / fm_total son números
        lst = self.getControl(9100)
        lst.reset()
        for act in self.opts:
            # («act», texto, icono): opción propia (menú de las listas de Trakt); si no, la de ACTIONS
            act, text, icon = act if isinstance(act, tuple) else (act, ACTIONS[act][0], ACTIONS[act][1])
            li = xbmcgui.ListItem(text)
            li.setProperty("icon", icon)
            li.setProperty("act", act)
            lst.addItem(li)
        self.setFocusId(9100)       # con la lista ya llena (el XML abre con el foco en el botón 90)

    def onClick(self, cid):
        if cid == 9100:
            item = self.getControl(9100).getSelectedItem()
            if item:
                self.choice = item.getProperty("act")
                self.close()

    def onAction(self, action):
        import flix_common
        if action.getId() in flix_common.A_BACK:
            self.close()


def choose(props, opts):
    """enseña el menú y devuelve la acción elegida (None = Atrás)"""
    import xbmcvfs
    w = Menu("FlixMenu.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props, opts=opts)
    w.doModal()
    choice = w.choice
    del w
    return choice


def notify(msg):
    import xbmcvfs
    xbmcgui.Dialog().notification("KER0N3 MEDIA", msg, xbmcvfs.translatePath("special://skin/resources/icon.png"),
                                  3000)


def _bg(fn):
    threading.Thread(target=fn, daemon=True).start()


def mark(t, act):
    """pide la marca al addon (RunPlugin) y espera su respuesta con la rueda puesta; al acabar, el aviso y, si cambió
    algo, flix_menu_done (el buscador y las secciones de la TV repintan ✓ y ▶; las filas del Inicio las repinta el
    addon, como al parar un vídeo)"""
    _label, _icon, op, working, done = ACTIONS[act]
    url = "%smarcar/%s/%s/%d" % (K3_ROOT, op, TIPOS[t["kind"]], t["tmdb"])
    if t["kind"] == "episode":
        url += "/%d/%d" % (t["season"], t["episode"])
    HOME.clearProperty(DONE)
    HOME.setProperty("flix_working", working)
    result = ""
    t0 = time.time()
    try:
        result = mark_here(op, t)
        if result is None:          # addon sin mark_for_skin: por su ruta, como antes
            result = ""
            xbmc.executebuiltin("RunPlugin(%s)" % url)
            mon, end = xbmc.Monitor(), time.time() + MARK_WAIT
            while time.time() < end and not mon.abortRequested():
                result = HOME.getProperty(DONE).split("|")[0]
                if result:
                    break
                xbmc.sleep(100)
    finally:
        HOME.clearProperty("flix_working")
    xbmc.log("[flix_k3menu] marca en %d ms" % ((time.time() - t0) * 1000), xbmc.LOGINFO)
    xbmc.log("[flix_k3menu] %s → %s" % (url[len(K3_ROOT):], result or "sin respuesta"), xbmc.LOGINFO)
    if result == "ok":
        if act in ("fav_add", "fav_del"):
            try:        # corazón de la ficha abierta y filas de favoritos, otra vez a su ruta
                import flix_common
                import flix_rows
                flix_common.favorite_prop(t["kind"], t["tmdb"], act == "fav_add")
                flix_rows.expire(flix_rows.FAV_RE)
                # las secciones abiertas (flix_section / flix_home drop_title) quitan al momento lo que sale de
                # favoritos: «hora|add o del|movie:603 o tv:1399»
                HOME.setProperty("flix_fav_change", "%f|%s|%s:%d" % (time.time(), "add" if act == "fav_add" else "del",
                                                                     "movie" if t["kind"] == "movie" else "tv", t["tmdb"]))
            except Exception as e:  # noqa: BLE001
                xbmc.log("[flix_k3menu] favoritos: %s" % e, xbmc.LOGINFO)
        HOME.setProperty("flix_menu_done", "%f" % time.time())
        notify(done)
    elif result == "igual":
        notify("Ya estaba así")
    else:
        import flix_common
        notify("No se ha podido. %s" % flix_common.RETRY_LATER)


def mark_here(op, t):
    """22-nov: la marca con el código del addon en ESTE proceso (handlers.mark_for_skin), sin RunPlugin: sin arrancar
    su intérprete (0,4-0,8 s en la Shield, 1-2 s en un Fire TV) la rueda casi no se ve. None si no se puede (addon
    viejo): quien llama va por la ruta marcar/…"""
    try:
        from ker0n3 import handlers
        fn = handlers.mark_for_skin
    except (ImportError, AttributeError):
        return None
    ep = (t["season"], t["episode"]) if t["kind"] == "episode" else (None, None)
    return fn(op, TIPOS[t["kind"]], t["tmdb"], *ep) or "error"


def favorite(path):
    """corazón de la ficha de una película o una serie de Ker0n3 (flix_menu.fav_from_sheet): la añade a favoritos o
    la quita, según esté, y espera a que el addon lo apunte. False si no es un título de Ker0n3 con favoritos"""
    t = target(path)
    if not t or t["kind"] not in ("movie", "show"):
        return False
    mark(t, "fav_del" if is_favorite(t) else "fav_add")
    return True


def resume_at(props):
    """segundo donde reanudar «Ver» / «Elegir versión» del menú: donde se quedó, salvo los primeros 30 s o el final
    (último minuto), como la ficha (flix_play._play); 0 = desde el principio"""
    try:
        pos, total = float(props.get("fm_pos") or 0), float(props.get("fm_total") or 0)
    except (TypeError, ValueError):
        return 0
    return int(pos) if pos > 30 and (not total or pos < total - 60) else 0


def menu(path, label="", poster="", fanart="", in_sheet=False, wait=False, origin=""):
    """muestra el menú del título de Ker0n3 y actúa; False si la ruta no es de Ker0n3 (sin menú). PENDING si se ha
    lanzado una marca (se hace por detrás: quien llama no se queda esperando; con wait=True se espera aquí).
    in_sheet: capítulo o temporada de la ficha de la serie (ver state). origin: ruta de la fila o cuadrícula de donde
    viene (extras: «Quitar de esta lista»)"""
    t = target(path)
    if not t:
        return False
    import flix_common
    import flix_play
    title = _TAGS.sub("", flix_common.COLOR_RE.sub("", label or "")).strip()
    props, opts = state(t, in_sheet, origin)
    props.update({"fm_title": title, "fm_poster": poster or "", "fm_fanart": fanart or ""})
    act = choose(props, opts)
    if act not in opts:
        return True
    if act in ("res", "play"):
        if act == "res":
            HOME.setProperty("flix_pick_once", str(time.time()))
        HOME.setProperty("flix_title", title)
        HOME.setProperty("flix_poster", poster or "")
        HOME.setProperty("flix_fanart", fanart or "")
        flix_play.start(path, resume_at(props))
    elif act in ("tlists", "tl_del"):
        # cambió algo: PENDING, para que la sección se repinte al acabar (flix_menu_done) con la lista al día (19-nov,
        # Carlos: «no lo muestra al momento»)
        rm = origin_list(t, origin) if act == "tl_del" else None
        if act == "tl_del" and rm is None:
            return True
        if trakt_menu(t, title, remove_from=rm, props=props):
            return PENDING
    elif act == "similar":
        import flix_menu
        flix_menu.open_similar("movie" if t["kind"] == "movie" else "show", {"tmdb": str(t["tmdb"])}, title)
    elif act == "sheet":
        if t["kind"] == "movie":
            flix_play.seed_focused(path)        # la ficha con lo de la carátula enfocada: sin esperar al addon
            flix_play.play(path, title=label, fanart=fanart)
        else:
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s%d")' % (K3_SERIE, t["tmdb"]))
    else:
        if wait:
            mark(t, act)
        else:
            _bg(lambda: mark(t, act))
        return PENDING
    return True

