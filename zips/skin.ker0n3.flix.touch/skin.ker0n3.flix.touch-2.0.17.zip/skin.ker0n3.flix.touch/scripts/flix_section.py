"""Sección del menú desplegada en filas (versión TV, ventana FlixSection.xml).

Uso: RunScript(special://skin/scripts/flix_section.py,<clave de la sección>)   (flix_sections: sections.json)
Las filas son las del menú propio de la sección (flix_sections_own), con el orden y los interruptores elegidos en
Ajustes → Personalizar menú e Inicio → Filas (flix_sections_conf.apply_rows).
Se carga SOLO al entrar: lo guardado al momento y las filas caducadas se piden al addon una a una, por detrás.
  fila de listado  -> carátulas (película = ficha, serie = su ficha vía flix_series.py)
  fila de tarjetas -> sagas, géneros, años: al abrir una, su lista como sección de una fila
  último "Más…" de un listado -> tarjeta "Ver más" que abre la página siguiente como sección de una fila suelta
                               (open_rows, como «Ver similares»): en la cuadrícula de Kodi el clic no iba a la ficha
                               propia (Carlos, 7-nov)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import threading
import time

import xbmc
import xbmcgui

import flix_cache  # noqa: E402
import flix_common  # noqa: E402
import flix_menu_preview  # noqa: E402
import flix_newep  # noqa: E402
import flix_reload  # noqa: E402
import flix_rows  # noqa: E402
import flix_sections_conf  # noqa: E402
from flix_items import to_listitem  # noqa: E402  (sin el buscador entero: revisión 29-oct ARR-19)

HOME = xbmcgui.Window(10000)
FIRST, NROWS = 5401, 16
# cuadrícula (18-nov, Carlos): una sección de UNA sola fila suelta (saga, género, año, «Ver similares», «Títulos de X»,
# «Ver más», carpeta del NAS) se pinta en el panel GRID de FlixSection.xml (mismas carátulas que las filas, varias
# líneas). Su «Ver más» del final carga la página siguiente AHÍ MISMO al pulsarlo (grid_load_more; Carlos: «así solo
# se pide si quieres ir pidiendo más»)
GRID = 5450
RETRY = 5490            # botón de reserva (FlixSection.xml): foco mientras no hay filas; OK = reintentar
ROW_LIMIT = 40
FOLDER_LIMIT = 1000
SEEN = 9304              # «Ocultar vistos» de la cabecera (gen_tv_section.SEEN)
SEEN_VARS = ("own:trakt", "own:favoritos")     # secciones en las que sale
HIDE_SEEN = "flix_trakt_hide_seen"             # = ker0n3.lists.HIDE_SEEN     # carpeta del NAS abierta (otros orígenes): entera
from flix_common import A_BACK  # noqa: E402,F401  (comunes: TV-28; flix_inicio lo importa de aquí)
A_OK = (7, 100)                 # Select y clic: OK en el menú lateral (9000) de la sección
A_RIGHT = (2,)                  # derecha: sobre «Inicio» del menú, como OK (vuelve al Inicio)
MENU = 9000                     # menú lateral (FlixHomeChrome): 1 = «Inicio», 2… = hueco flix_sec<N> del Inicio
A_CONTEXT = (117,)              # mantener OK / tecla menú: menú KER0N3 de la carátula, como en el Inicio (28-oct)
MENU_WAIT = 180                 # s: lo más que se espera a que acabe el menú de un título para repintar
LOADING, MISSING = flix_rows.LOADING, flix_rows.MISSING     # tarjeta de una fila que aún no ha llegado / que no dio nada
TICK = 0.5                      # s entre vueltas de la vigilancia (vista previa del menú), como el Inicio


def log(msg):
    xbmc.log("[flix_section] %s" % msg, xbmc.LOGINFO)


def small_screen():
    """pantalla de 1080 o menos (Fire TV): las carátulas de las filas se dibujan a 168x252 y llegan a 342x513.
    En la Shield (4K) y el móvil se quedan como estaban"""
    global _SMALL
    if _SMALL is None:
        try:
            _SMALL = 0 < int(xbmc.getInfoLabel("System.ScreenWidth") or 0) <= 1920
        except ValueError:
            _SMALL = False
    return _SMALL


_SMALL = None


def small_art(art):
    """póster y miniatura de TMDB a w185 (~ -65 % de memoria de textura por carátula; auditoría 22-oct C-02). Solo en
    las filas: la ficha y el selector siguen con las suyas"""
    out = dict(art)
    for k in ("poster", "thumb"):
        v = out.get(k) or ""
        if "image.tmdb.org" in v:
            out[k] = v.replace("%2fw342%2f", "%2fw185%2f").replace("/w342/", "/w185/")
    return out


def external_item(li, f):
    """tarjeta de otros orígenes. Carpeta del NAS: se abre como sección; foto: pase de fotos desde ella; vídeo o lo de
    la biblioteca: lo reproduce Kodi; carpeta de lo demás: la cuadrícula de Kodi. Sin la extensión en el nombre"""
    import flix_common
    path, kind = f.get("file") or "", flix_common.file_kind(f)
    fs = flix_common.is_fs(path)
    if kind == "dir":
        li.setProperty("open", "folder" if fs else "grid")
    elif kind == "picture" and fs:
        li.setProperty("open", "picture")
        li.setArt({"poster": path, "thumb": path, "fanart": path, "landscape": path})
    else:
        li.setProperty("open", "kodi")
    if fs and kind != "dir":
        name = os.path.splitext(f.get("label") or "")[0]
        li.setLabel(name)
        li.setProperty("FlixTitulo", name)
        li.getVideoInfoTag().setTitle(name)
    if fs and not li.getArt("poster") and not li.getArt("thumb"):
        li.setProperty("card", "text")      # carpeta o vídeo sin carátula: su nombre, no un hueco vacío


def make_item(f, row):
    if small_screen() and f.get("art"):
        f = dict(f, art=small_art(f["art"]))
    li = to_listitem(f)
    try:
        import flix_audio
        au = flix_audio.for_path(f.get("file") or "")
        if au:
            li.setProperty("FlixAudio", au)     # mejor audio disponible: insignia de la cabecera (FlixMetaRow)
    except Exception:  # noqa: BLE001
        pass
    if f.get("file") and not flix_rows.is_more(f):
        import flix_meta                        # duración y edad que la fila no traiga (Top 10, Seguir viendo…)
        flix_meta.complete(li, f)
    if flix_rows.is_more(f):
        li.setLabel("Ver más")
        li.setProperty("card", "text")
        li.setProperty("open", "grid")
        li.setProperty("more", "1")         # página siguiente: la sección la abre como fila suelta (onClick)
    elif row["kind"] == "coll":
        li.setProperty("card", "text" if flix_rows.is_generic(f) else "band")
        li.setProperty("open", "grid")
    elif f.get("flix_ep"):
        li.setProperty("open", "resume")    # capítulo a medias en «Seguir viendo» (flix_progress.episode_cards): sin aviso
        li.setProperty("FlixEp", f["flix_ep"])      # «T1 E4»: el menú de la tarjeta es el del capítulo (flix_menu.card_episode)
    elif str(f.get("file") or "").startswith("plugin://plugin.video.ker0n3/"):
        # de Ker0n3: serie = su ficha; película = ficha con lo de la base (flix_play.play)
        li.setProperty("open", "series" if f.get("filetype") == "directory" else "play")
    elif f.get("file") and not f["file"].startswith("flix://"):
        # de otros orígenes (biblioteca de Kodi, carpetas, otros complementos; como Arctic Fuse 3): lo de Kodi
        external_item(li, f)
    elif f.get("filetype") == "directory":
        li.setProperty("open", "series")
    else:
        li.setProperty("open", "play")
    return li


def placeholder(label):
    """tarjeta de texto de una fila sin títulos todavía: no abre nada (onClick mira «open»)"""
    li = xbmcgui.ListItem(label)
    li.setProperty("card", "text")
    li.setProperty("open", "")
    return li


class SectionWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.var = kwargs.get("var")
        self.title = kwargs.get("title")
        self.rconf = kwargs.get("rconf") or {}     # filas elegidas (orden / apagadas)
        # filas sueltas en vez de las del menú de la sección (open_rows: «Ver similares»); Atrás la cierra
        self.fixed = kwargs.get("rows")
        self.grid = bool(self.fixed) and len(self.fixed) == 1
        self.grid_busy = False          # cuadrícula: pidiendo la página siguiente de su «Ver más»
        self.setProperty("fs_grid", "1" if self.grid else "")
        self.back_cover = kwargs.get("back_cover") or ""
        # sección del menú lateral de la que se vino (cuadrícula de un género, «Ver más»…: no tienen hueco propio en el
        # menú). El menú la marca a ella y derecha/OK sobre ella vuelve aquí (Shield 18-nov, Carlos: marcaba «Inicio» y
        # derecha sacaba al Inicio)
        self.menu_key = kwargs.get("menu_key") or ""    # «Títulos de X»: fondo de la ficha a la que vuelve Atrás
        self.t0 = kwargs.get("t0")       # hora de la pulsación (main): la 1.ª carga apunta «lista en X s» desde ahí
        self.key = kwargs.get("key") or ""      # clave de esta sección (flix_sections): la cabecera de entrada la compara
        self.next = ""                   # clave de la sección que el usuario eligió en el menú lateral ("" = no hay)
        # fs_key ANTES de doModal: las animaciones WindowOpen y la cabecera de entrada (FlixSection.xml) la leen al abrirse
        # la ventana y onInit llegaría tarde
        self.setProperty("fs_key", self.key)
        # y su nombre: la marca «estás aquí» del menú lateral cerrado (FlixHomeChrome, param current) lo compara con el
        # de cada elemento del menú; así ya está al abrirse (onInit lo repite, como siempre)
        self.setProperty("fs_title", self.title or "")
        # sin menú lateral: filas sueltas abiertas desde donde no se veía (búsqueda, ficha, cuadrícula: open_rows)
        self.setProperty("fs_nomenu", "1" if kwargs.get("nomenu") else "")
        # «Ocultar vistos» en la cabecera: solo en Trakt y Favoritos (19-nov, Carlos)
        self.setProperty("fs_seen", "1" if self.var in SEEN_VARS else "")
        self.stop = False
        self.started = False
        self.rows = {}           # id de lista -> fila
        self.slot_of = {}        # ruta de la fila -> id de lista
        self.shown = {}          # id de lista -> títulos pintados
        # vista previa en el menú lateral, como en el Inicio (Carlos, 31-oct): la crea la primera onInit
        self.preview = None
        self.wid = ""            # id de esta ventana (primera onInit): active()
        self.in_flight = False   # el hilo de carga pidiendo una fila: la vista previa no pide a la vez
        self.wake = threading.Event()       # la vista previa acabó de pedir: la carga, si esperaba, sigue
        self.refocus = None      # foco pedido a una fila recién rellenada: tick() lo repite si Kodi no lo dio (XML-02)

    def onInit(self):
        self.setProperty("fs_title", self.title)
        self.setProperty("fs_key", getattr(self, "key", ""))
        self.mark_menu()
        if not self.started:
            self.started = True
            # solo en la primera, como fi_window en el Inicio: las siguientes pueden llegar con otra ventana ya delante
            self.wid = str(xbmcgui.getCurrentWindowId())
            # aquí y no en __init__: al crearse quita la vista previa del Inicio (flix_pv_on), que aún se ve hasta que
            # esta ventana está delante. home_item: «Inicio» del menú enseña la vista previa del Inicio (Carlos, 31-oct)
            self.preview = flix_menu_preview.Preview(self, self.wake.set, lambda: self.in_flight, own=self.key,
                                                     home_item=True)
            threading.Thread(target=self.load, daemon=True).start()
            threading.Thread(target=self.watch, daemon=True).start()
        else:
            self.repaint()

    def mark_menu(self):
        """marca en el menú lateral la sección de esta ventana (posición = hueco + 1; «Inicio» es la 1). Sin su hueco en
        el Inicio (acceso por clave que no está en el menú) o sin la lista (tests) no hace nada. Se repite en cada
        onInit: tras recargar la skin el menú se monta de nuevo y vuelve a «Inicio»"""
        key = getattr(self, "key", "") or getattr(self, "menu_key", "")
        if not key:
            return
        for n in range(1, flix_sections_conf.MAX_SECTIONS + 1):
            if HOME.getProperty("flix_sec%d_key" % n) == key:
                try:
                    self.getControl(MENU).selectItem(n)         # 0-based: el hueco n está en la posición n + 1
                except (RuntimeError, AttributeError):
                    pass
                return

    def menu_choice(self):
        """(clave, tipo) de la sección que tiene el foco en el menú lateral; ('', '') si es «Inicio» o no hay"""
        import flix_menu_preview
        n = flix_menu_preview.slot_of(xbmc.getInfoLabel("Container(%d).CurrentItem" % MENU))
        if not n:
            return "", ""
        return HOME.getProperty("flix_sec%d_key" % n), HOME.getProperty("flix_sec%d_kind" % n)

    def fallback(self):
        """adónde va el foco cuando no hay fila con títulos: a la 1.ª fila si ya tiene hueco («Cargando…» / «No
        disponible» son tarjetas enfocables; con fs_row1 puesta la reserva 5490 está oculta y Kodi no la enfoca:
        «5490 can't focus», revisión 7-nov XML-02) o a la reserva mientras no hay ninguna"""
        return self.first() if self.getProperty("fs_row1") else RETRY

    def first(self):
        """la lista de la primera fila: la cuadrícula en una sección de una sola fila suelta"""
        return GRID if getattr(self, "grid", False) else FIRST

    def slot(self, n):
        """id de la lista de la fila n (0…): en la cuadrícula solo hay una"""
        return GRID if getattr(self, "grid", False) else FIRST + n

    def focus_soon(self, cid):
        """pide el foco y lo apunta para que tick() lo repita si Kodi no lo dio: tras reset()+addItems() la fila sigue
        oculta (NumItems era 0) hasta el fotograma siguiente y el foco pedido en el mismo se pierde («5412 can't
        focus»; luego la 1.ª tecla lo devolvía a la 1.ª fila). XML-02"""
        self.setFocusId(cid)
        self.refocus = cid

    def focus_rows(self):
        """OK en el menú sobre la sección actual: el foco a su primera fila con títulos (o, si aún no hay, adonde diga
        fallback: ahí también lo deja restore_focus)"""
        for lid in sorted(self.rows):
            if self.shown.get(lid):
                self.setFocusId(lid)
                return
        self.focus_soon(self.fallback())

    def restore_focus(self):
        """foco perdido (p. ej. abajo desde la lupa con el grupo de filas aún sin filas que enfocar): a la primera fila,
        o a la reserva mientras no hay. Con la sección cerrándose no se toca nada"""
        if self.stop:
            return
        try:
            if self.focus_id() is None:
                self.setFocusId(self.fallback())
        except RuntimeError:                        # ventana ya destruida
            pass

    def repaint(self):
        """tras recargar la skin (actualización automática con la sección abierta) Kodi vuelve a montar la ventana
        desde el XML con las listas vacías y llama otra vez a onInit: se repinta lo que había y se devuelve el foco.
        Antes quedaba en negro, sin foco, y solo respondía Atrás (auditoría 22-oct A-06). Solo con "0": al volver de
        un vídeo onInit puede llegar con la ventana del vídeo aún delante y entonces da "" """
        for lid, row in sorted(self.rows.items()):
            if xbmc.getInfoLabel("Container(%d).NumItems" % lid) != "0":
                continue
            files = self.shown.get(lid)
            if files:
                items = [make_item(f, row) for f in files]
            else:
                items = [placeholder(MISSING if getattr(self, "loaded", False) else LOADING)]
            log("fila %s vacía al volver (skin recargada): repinto" % row["label"])
            self.refill(lid, items)
        if self.focus_id() is None:
            self.focus_soon(self.fallback())

    def load(self, refocus=True):
        try:
            self._load(refocus)
        except RuntimeError:
            if not self.stop:
                raise
            # sección cerrada mientras cargaba: Kodi ya destruyó la ventana (antes: traceback en el log, PY-10)

    def _load(self, refocus=True):
        """1) lo guardado al momento, aunque esté caducado; 2) solo lo caducado o sin caché, por detrás, en orden, sin
        mover la selección (auditoría REND-02: antes ~40 s con la caché caducada).
        refocus=False: repintado tras el menú KER0N3 (el foco se queda en la carátula)"""
        t0 = getattr(self, "t0", None) or time.time()      # recargas (reintentar, tras el menú): desde que empiezan
        self.t0 = None
        self.setProperty("fs_empty", "")
        self.setProperty("fs_error", "")
        self.setProperty("fs_status", "cargando…")
        # ¿el addon no contesta o no hay nada? (TV-12: antes las dos cosas salían como «Sin contenido»)
        failed, answered = False, False
        flix_common.dir_failed(reset=True)
        if not self.hold_turn():            # la vista previa del menú pidiendo: después de ella
            return
        try:
            if getattr(self, "fixed", None):
                rows = list(self.fixed)
            else:
                import flix_sections
                rows = flix_sections.effective_rows(self.var, self.rconf)
        except Exception as e:  # noqa: BLE001  (antes el hilo moría y la sección se quedaba en «Cargando…»)
            log("menú de %s: %s" % (self.title, e))
            rows, failed = [], True
        finally:
            self.in_flight = False
        failed = flix_common.dir_failed(reset=True) or failed
        if not getattr(self, "fixed", None):
            self.drop_gone(rows[:NROWS])
        # todas las filas cogen su hueco ya, en su orden y con «Cargando…»: se puede bajar sin esperar
        # (antes cada fila cogía hueco al llegar: no había adónde bajar y salían en orden de llegada)
        for row in rows[:NROWS]:
            if self.stop:
                return
            self.place(row)
        if rows and not self.stop and refocus:
            self.focus_soon(self.first())
        pending = []
        for row in rows:
            if self.stop:
                return
            files, fresh = flix_rows.peek(row["path"])
            if files:
                self.paint(row, files, "caché" if fresh else "caché antigua")
            if not fresh:
                pending.append(row)
        back, self.regain = getattr(self, "regain", None), None
        if back:                            # la fila con el foco, recolocada (drop_gone): en el título en que estaba
            try:
                self.getControl(back[0]).selectItem(back[1])
            except (RuntimeError, AttributeError):
                pass
        failed, answered = self.fetch_rows(pending, failed, answered)
        flix_rows.flush()
        self.setProperty("fs_status", "")
        self.loaded = True
        if self.stop:
            return
        for lid, files in self.shown.items():
            if files is None:                       # la fila no dio nada
                self.refill(lid, [placeholder(MISSING)])
        if not any(self.shown.values()):
            # botón 5490 (FlixState): «No responde» si nada contestó, si no «Sin contenido»; OK = reintentar.
            # Con filas colocadas (todas «No disponible») la reserva está oculta: a la 1.ª fila (fallback)
            self.setProperty("fs_error", "1" if failed and not answered else "")
            self.setProperty("fs_empty", "1")
            self.focus_soon(self.fallback())
            log("sección %s sin filas%s" % (self.title, " (no responde)" if failed and not answered else ""))
        log("%s: lista en %.1f s" % (self.title, time.time() - t0))     # fin de C5 sin depuración (DAT-22)

    def drop_gone(self, rows):
        """filas que ya no están (19-nov, Carlos: una lista de Trakt vaciada o borrada desde la pulsación larga seguía
        pintada): los huecos otra vez en orden sin ella; el foco, a la fila en la que estaba en su sitio nuevo (si era
        la que se fue, a la que ocupa su lugar o la de antes)"""
        paths = [r["path"] for r in rows]
        slots, shown = getattr(self, "slot_of", None) or {}, getattr(self, "rows", None) or {}
        gone = [(shown.get(lid) or {}).get("label") or p for p, lid in slots.items() if p not in paths]
        if not gone:
            return
        old = sorted(self.rows)
        fid = self.focus_id()
        was = old.index(fid) if fid in old else None
        path = self.rows[fid]["path"] if was is not None else None
        pos = self.sel_pos(fid) if was is not None else 0
        for n, lid in enumerate(old):
            self.getControl(lid).reset()
            self.items_of()[lid] = []
            self.setProperty("fs_row%d" % (n + 1), "")
        self.slot_of, self.rows, self.shown = {}, {}, {}
        for row in rows:
            self.place(row)
        log("%s: filas recolocadas (ya no está: %s)" % (self.title, ", ".join(gone)))
        if was is None or not rows:
            return
        lid = self.slot_of.get(path)
        if lid is None:
            lid, pos = self.slot(min(was, len(rows) - 1)), 0
        self.focus_soon(lid)
        self.regain = (lid, pos)

    def fetch_rows(self, pending, failed, answered):
        """pide las filas de pending, en orden, y las pinta; devuelve (failed, answered) al día"""
        for k, row in enumerate(pending):
            if self.stop or not self.hold_turn():
                break
            try:
                files, _ = flix_rows.fetch(row["path"], force=True, save=False)
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row["label"], e))
                failed = True
                continue
            finally:
                self.in_flight = False
            if flix_common.dir_failed(reset=True):
                failed = True
            else:
                answered = True
            if files and not self.stop:
                self.paint(row, files, "pedida")
            if k % 4 == 3:
                flix_rows.flush(keep=True)      # vienen más: sin releer el fichero si nadie lo ha tocado (DAT-02)
        return failed, answered

    def hold_turn(self):
        """antes de pedir desde el hilo de carga: si la vista previa del menú está pidiendo, se espera sin pedir (de una
        en una: cada petición arranca el addon) y se marca in_flight para que ella no pida a la vez, como
        flix_inicio.worker. Quien pide quita la marca al acabar (finally). False: la sección se cerró esperando"""
        pv = getattr(self, "preview", None)
        while not getattr(self, "stop", False):
            if pv is None or not pv.busy():
                self.in_flight = True       # se avisa antes de mirar otra vez (la vista previa, igual): nunca los dos
                if pv is None or not pv.busy():
                    return True
                self.in_flight = False      # se adelantó la vista previa: a esperar
            self.wake.wait(1)
            self.wake.clear()
        return False

    # ---------- vigilancia: vista previa del menú lateral (como flix_inicio.InicioWindow.watch / tick) ----------
    def watch(self):
        # al cerrarse Kodi se para en menos de 1 s (System.OnQuit, flix_common.quit_monitor: a los RunScript sin addon
        # Kodi no les avisa por abortRequested; antes esperaba 5 s y lo mataba con traceback, revisión 7-nov PY-01)
        mon = flix_common.quit_monitor()
        last = None                         # un fallo que se repite, una sola línea (como el Inicio)
        while not self.stop and not flix_common.wait_quit(mon, TICK):
            try:
                self.tick()
                last = None
            except Exception as e:  # noqa: BLE001
                msg = "vigilancia: %s" % e
                if msg != last and not self.stop:
                    log(msg)
                last = msg
        self.trailer_leave()            # la vigilancia se va: nadie pararía ya el tráiler de la fila
        if flix_common.quitting(mon) and not self.stop:
            self.on_quit()

    def on_quit(self):
        """Kodi se cierra: la carga deja de esperar (wake) y la ventana se cierra para que doModal vuelva y el script
        acabe solo, sin que Kodi tenga que matarlo"""
        self.stop = True
        self.wake.set()
        self.trailer_leave()
        try:
            self.close()
        except RuntimeError:                        # ventana ya destruida
            pass

    # ---------- tráiler automático en las filas (flix_rowtrailer; Carlos, 11-nov), como el Inicio ----------
    def row_trailer(self):
        rt = self.__dict__.get("rowtrailer")
        if rt is None:
            import flix_rowtrailer
            rt = self.rowtrailer = flix_rowtrailer.RowTrailer(self, self.trailer_focus)
        return rt

    def trailer_focus(self):
        """(fila, ruta) del título enfocado con la sección delante y sin nada encima (ficha, menú, aviso); None si no"""
        if not self.active() or xbmc.getCondVisibility("System.HasActiveModalDialog"):
            return None
        lid = self.focus_id()
        if lid not in self.rows:
            return None
        items, pos = self.items_of().get(lid) or [], self.sel_pos(lid)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open") or item.getProperty("more"):       # «Cargando…», «Ver más»
            return None
        return lid, item.getPath()

    def trailer_leave(self):
        rt = self.__dict__.get("rowtrailer")
        if rt is not None:
            rt.leave()

    def tick(self):
        """sin el ajuste (o en modo ligero), fuera lo pintado; tapada (ficha, aviso, vídeo, otra ventana), que no pida
        más; delante, su vuelta"""
        if self.stop:
            return
        try:                                        # llegaron edades de TMDB: a las carátulas ya pintadas, sin repintar
            import flix_age
            rev = HOME.getProperty(flix_age.REV)
            if rev != getattr(self, "age_rev", ""):
                self.age_rev = rev
                for items in list(self.items_of().values()):
                    flix_age.apply(items)
        except Exception:  # noqa: BLE001
            pass
        pending, self.refocus = getattr(self, "refocus", None), None
        if pending is not None and self.focus_id() is None:
            self.setFocusId(pending)            # una sola vez más: ya pasó el fotograma en que la fila estaba oculta
        if flix_reload.reloading(HOME):
            # «Recargar skin»: la ventana se cierra antes de que Kodi la destruya con el skin viejo (flix_reload)
            self.stop = True
            self.trailer_leave()
            self.close()
            return
        self.personal_tick()
        self.row_trailer().tick()
        if not flix_menu_preview.enabled():
            self.preview.leave(hide=True)
        elif self.covered():
            self.preview.leave()
        else:
            self.preview.tick(time.time())

    # «Ver más» ágil (19-nov, Carlos: «va muy lento… y a veces añade 6 o 7»): la página siguiente se prepara por detrás
    # desde que la cuadrícula se pinta, y se repite mientras al addon le quede algo por comprobar (cada vuelta, ~10 s;
    # lo comprobado queda guardado). Al pulsar, si ya está, se añade al momento
    PRE_ROUNDS = 8       # vueltas de precarga (cada una, ~12 s: la página de 60 series se completa en ~6; 19-nov)

    def grid_prefetch_start(self, path):
        if not path or (getattr(self, "grid_pre_path", "") == path and getattr(self, "grid_pre_run", False)):
            return
        self.grid_pre_path, self.grid_pre, self.grid_pre_run = path, None, True
        threading.Thread(target=self.grid_prefetch, args=(path,), daemon=True).start()

    def grid_prefetch(self, path):
        try:
            for _ in range(self.PRE_ROUNDS):
                if self.stop or getattr(self, "grid_pre_path", "") != path:
                    return
                try:
                    files, _ = flix_rows.fetch(path, force=True, save=False)
                except Exception as e:  # noqa: BLE001
                    log("cuadrícula, precarga: %s" % e)
                    return
                if self.stop or getattr(self, "grid_pre_path", "") != path:
                    return
                self.grid_pre = files
                more = [f for f in files if flix_rows.is_more(f)][:1]
                if not more or more[0].get("file") != path:
                    return              # página entera (su «Ver más» ya es la siguiente, o no hay más)
        finally:
            if getattr(self, "grid_pre_path", "") == path:
                self.grid_pre_run = False

    def grid_load_more(self, item, pos):
        """«Ver más» de la cuadrícula: lo precargado al momento; si aún no hay nada, se espera a la precarga (o se pide)"""
        if self.grid_busy:
            return
        self.grid_busy = True
        item.setLabel("Cargando…")
        threading.Thread(target=self.grid_fetch, args=(item.getPath(), pos), daemon=True).start()

    def grid_fetch(self, path, pos, wait=25.0, step=0.2):
        """los títulos nuevos de la página `path` en lugar de su «Ver más» (posición pos), sin repetidos; si hay otra
        página (o queda algo de esta por comprobar), su «Ver más» al final y su precarga. El foco, al primero nuevo"""
        try:
            files = None
            if getattr(self, "grid_pre_path", "") == path:
                end = time.time() + wait
                while getattr(self, "grid_pre", None) is None and getattr(self, "grid_pre_run", False) \
                        and time.time() < end and not self.stop:
                    time.sleep(step)
                files = getattr(self, "grid_pre", None)
            if files is None:
                files, _ = flix_rows.fetch(path, force=True, save=False)
            if self.stop:
                return
            self.grid_pre_path, self.grid_pre = "", None        # usada: la próxima, otra
            self.grid_apply(files, pos)
        except Exception as e:  # noqa: BLE001
            log("cuadrícula, página siguiente: %s" % e)
        finally:
            self.grid_busy = False

    def grid_apply(self, files, pos):
        more = [f for f in files if flix_rows.is_more(f)][:1]
        old = [f for f in (self.shown.get(GRID) or []) if not flix_rows.is_more(f)]
        have = {f.get("file") for f in old}
        new = [f for f in files if not flix_rows.is_more(f) and f.get("file") not in have]
        new = new[:max(0, FOLDER_LIMIT - len(old))]
        try:
            import flix_age
            flix_age.want(new)
        except Exception:  # noqa: BLE001
            pass
        row = self.rows.get(GRID) or {"kind": "list"}
        items = self.items_of().get(GRID) or []
        keep = [it for it in items if not it.getProperty("more")]
        tail = more if len(old) + len(new) < FOLDER_LIMIT else []
        added = [make_item(f, row) for f in new + tail]
        self.shown[GRID] = old + new + tail
        lst = self.getControl(GRID)
        try:
            # sin repintar la cuadrícula entera: fuera la tarjeta y lo nuevo al final (Kodi 18+: removeItem)
            if len(keep) != len(items):
                lst.removeItem(len(items) - 1)
            lst.addItems(added)
            self.items_of()[GRID] = keep + added
            if new:
                lst.selectItem(min(pos, len(keep)))
        except (AttributeError, RuntimeError, TypeError):
            self.refill(GRID, keep + added, min(pos, len(keep)))
        log("cuadrícula: +%d (%d en total)%s" % (len(new), len(old) + len(new), "" if tail else ", no hay más"))
        if tail:
            self.grid_prefetch_start(tail[0].get("file") or "")

    def personal_tick(self):
        """el addon avisa de que la base personal cambió (flix_rows: clave «personal»; bajada de Trakt, favorito…):
        con la sección delante y filas personales (Favoritos, Seguir viendo…), se vuelve a cargar (lo personal ya no
        está fresco: flix_rows.hit_fresh), sin mover el foco (17-nov: un favorito del móvil no salía en Favoritos de
        la Fire TV aunque su corazón sí estaba)"""
        rev = HOME.getProperty("k3_list_rev_" + flix_rows.PERSONAL_KEY)
        seen = self.__dict__.setdefault("personal_rev", rev)
        if rev == seen or self.covered() or self.in_flight:
            return
        self.personal_rev = rev
        if any(flix_rows.k3_list_key(r.get("path")) == flix_rows.PERSONAL_KEY for r in list(self.rows.values())):
            log("%s: la base personal ha cambiado: recargo" % self.title)
            threading.Thread(target=self.load, kwargs={"refocus": False}, daemon=True).start()

    def active(self):
        """¿la sección está delante? Solo entonces la vista previa toca sus listas (5191/5192) y pide; cerrándose, no"""
        wid = getattr(self, "wid", "")
        return bool(wid) and not self.stop and str(xbmcgui.getCurrentWindowId()) == wid

    def covered(self):
        # HasActiveModalDialog: HasModalDialog no cuenta las fichas y avisos de Python (como el Inicio)
        return not self.active() or xbmc.getCondVisibility("System.HasActiveModalDialog | Player.HasMedia")

    def place(self, row):
        """hueco de una fila antes de que lleguen sus títulos (al reintentar, vuelve a «Cargando…»)"""
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            n = len(self.slot_of)
            lid = self.slot(n)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = None
            self.setProperty("fs_row%d" % (n + 1), row.get("title") or row["label"])
        elif self.shown.get(lid) is not None:
            return
        self.refill(lid, [placeholder(LOADING)])

    def focus_id(self):
        try:
            return self.getFocusId() or None
        except RuntimeError:                        # ningún control de la ventana tiene el foco
            return None

    def refill(self, lid, items, pos=0):
        """vacía y rellena una fila. Kodi suelta el foco de una lista vacía: si la fila lo tenía (o nadie lo tiene y
        es la 1.ª) se le devuelve. Sin esto la 1.ª entrada a una sección se quedaba sin responder al mando hasta salir
        y volver (Carlos, 22-oct; desde la 1.5.38: la 1.ª fila coge el foco con «Cargando…» y luego se rellena)"""
        focus = self.focus_id()
        lst = self.getControl(lid)
        lst.reset()
        lst.addItems(items)
        self.items_of()[lid] = list(items)
        if pos > 0:
            lst.selectItem(min(pos, len(items) - 1))
        if focus == lid or (lid == self.first() and focus in (None, RETRY)):
            self.focus_soon(lid)

    def paint(self, row, files, origin):
        """show() desde el hilo de carga: una fila que falle al pintarse se apunta en el log y se sigue con las demás
        (antes la excepción mataba el hilo en silencio y la sección se quedaba en «Cargando…», revisión 7-nov PY-10).
        RuntimeError sigue subiendo: es Kodi destruyendo la ventana (load lo trata)"""
        try:
            self.show(row, files, origin)
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001
            log("fila %s: no se pudo pintar (%s: %s)" % (row.get("label"), type(e).__name__, e))

    def show(self, row, files, origin):
        """pinta una fila: su hueco ya está (place); solo si cambió, conservando la selección"""
        if row.get("skip"):
            # «Ver más» de Series en seguimiento del Inicio (open_more con skip): la misma lista sin las que ya enseña
            # la fila ni su «más…» (que lleva a la lista entera desde el principio)
            skip = set(row["skip"])
            files = [f for f in files if flix_rows.follow_tmdb(f) not in skip and not flix_rows.is_more(f)]
        if getattr(self, "grid", False):
            # cuadrícula: todo lo de la página y, al final, su «Ver más» (la página siguiente al pulsarlo). Repintada
            # (tras el menú, una marca…): lo ya cargado de las páginas siguientes se queda, y su «Ver más» el último
            more = [f for f in files if flix_rows.is_more(f)][:1]
            files = [f for f in files if not flix_rows.is_more(f)][:FOLDER_LIMIT]
            before = self.shown.get(GRID)
            if before:
                have = {f.get("file") for f in files}
                extra = [f for f in before if f.get("file") not in have and not flix_rows.is_more(f)]
                if extra:
                    more = [f for f in before if flix_rows.is_more(f)][-1:]
                files = (files + extra)[:FOLDER_LIMIT]
            files = files + (more if not row.get("all") else [])
        else:
            files = flix_rows.head(files, FOLDER_LIMIT if row.get("all") else ROW_LIMIT)
        try:                                        # edad de TMDB en segundo plano, solo las que falten (flix_age)
            import flix_age
            flix_age.want(files)
        except Exception:  # noqa: BLE001
            pass
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            n = len(self.slot_of)
            lid = self.slot(n)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = files
            self.setProperty("fs_row%d" % (n + 1), row.get("title") or row["label"])
            items = [make_item(f, row) for f in files]
            flix_newep.paint(items, files, lambda: self.items_of().get(lid))     # Series en seguimiento
            self.getControl(lid).addItems(items)
            self.items_of()[lid] = items
            if lid == self.first():
                self.focus_soon(lid)
        else:
            if flix_cache.same_items(self.shown.get(lid), files):
                flix_newep.update(self.items_of().get(lid))
                flix_newep.recheck(self.items_of().get(lid), lambda: self.items_of().get(lid))   # caducó algo: refresco
                return
            self.shown[lid] = files
            items = [make_item(f, row) for f in files]
            flix_newep.paint(items, files, lambda: self.items_of().get(lid))
            self.refill(lid, items, self.sel_pos(lid))
        if getattr(self, "grid", False) and files and flix_rows.is_more(files[-1]):
            self.grid_prefetch_start(files[-1].get("file") or "")      # la página siguiente, ya por detrás
        log("fila %s [%s]: %d (%s)" % (row["label"], row["kind"], len(files), origin))

    def items_of(self):
        if not hasattr(self, "items"):
            self.items = {}             # id de lista -> ListItems pintados (los nuestros)
        return self.items

    def sel_pos(self, lid):
        """posición seleccionada preguntando a Kodi: ControlList.getSelectedPosition/getSelectedItem usan la lista
        de antes de recargar la skin (actualización automática con la sección abierta) y Kodi se caía (SIGSEGV)"""
        try:
            return max(0, int(xbmc.getInfoLabel("Container(%d).CurrentItem" % lid) or 0) - 1)
        except ValueError:
            return 0

    def onAction(self, action):
        rt = self.__dict__.get("rowtrailer")
        if rt is not None:
            rt.key(action.getId())      # cualquier tecla para el tráiler de la fila, y hace lo suyo
        if action.getId() in A_BACK and getattr(self, "fixed", None):
            self.stop = True                    # «Ver similares»: no es una sección del menú lateral, Atrás vuelve
            cover = getattr(self, "back_cover", "")
            if cover:
                # «Títulos de X»: el fondo de la ficha tapa ya, antes de cerrar; puesto después (back_with_cover), en el
                # fundido de cierre asomaba el Inicio con su menú lateral (Shield, Carlos 1-nov)
                HOME.setProperty(flix_common.INFO_COVER, cover)
            self.close()
            return
        if action.getId() in A_BACK:
            # Atrás como en el Inicio (Carlos, 31-oct): lo hace cada control (<onback>: filas y reserva -> menú ->
            # lupa -> menú de apagar) y nunca cierra la sección; a Kodi no pasa (el onAction de serie de WindowXML la
            # cerraría). Cuando llega aquí el XML ya movió el foco: si está en el menú es que venía de las filas o de la
            # reserva, y el cursor va a esta sección (pudo bajarse a las filas desde la lupa con el menú en «Inicio»)
            if self.focus_id() == MENU:
                self.mark_menu()
            else:
                self.restore_focus()            # foco perdido: como con cualquier otra tecla
            return
        if (action.getId() in A_OK + A_RIGHT and self.focus_id() == MENU and not self.stop
                and xbmc.getInfoLabel("Container(%d).CurrentItem" % MENU) == "1"):
            # «Inicio» con OK, clic o derecha (en el XML, noop): se cierra la sección y el Inicio vuelve a sus filas
            # (flix_inicio.InicioWindow.onInit), no al menú abierto en esta sección con su vista previa (Carlos, 31-oct)
            HOME.setProperty("flix_go_home", "1")
            self.stop = True
            self.close()
            return
        if action.getId() in A_CONTEXT and self.focus_id() in self.rows:
            self.open_menu(self.focus_id())
            return
        if action.getId() in A_OK and self.focus_id() == MENU and not self.stop:
            key, kind = self.menu_choice()
            if key and kind == "rows":
                if key in (getattr(self, "key", ""), getattr(self, "menu_key", "")):
                    self.focus_rows()                   # la misma sección: a sus filas
                else:                                   # otra: esta ventana se cierra y main abre la nueva (sin apilar)
                    self.next = key
                    HOME.setProperty(SWAP, "1")         # el Inicio, tapado mientras asoma entre las dos
                    self.stop = True
                    self.close()
                return
            # las de lista (flix_sections.py,open): lo hace el XML
        self.restore_focus()                        # foco perdido: la tecla no iría a ningún sitio
        super().onAction(action)
        self.restore_focus()                        # y si esta tecla lo perdió (abajo a un grupo sin filas): ya

    def open_menu(self, lid):
        """menú de la carátula con foco (flix_k3menu); lo de otros orígenes, «Cargando…», «Ver más» y las tarjetas no
        tienen"""
        items = self.items_of().get(lid) or []
        pos = self.sel_pos(lid)
        item = items[pos] if pos < len(items) else None
        path = item.getPath() if item else ""
        if item and path.startswith(flix_common.K3_ROOT) and item.getProperty("open") not in ("", "grid"):
            import flix_k3menu
            t0 = time.time()
            if flix_k3menu.menu(path, item.getLabel(), item.getArt("poster"), item.getArt("fanart"),
                                origin=(self.rows.get(lid) or {}).get("path") or "") == flix_k3menu.PENDING:    # una marca en marcha: al acabar (flix_menu_done) se repinta
                threading.Thread(target=self.after_menu, args=(t0,), daemon=True).start()

    def after_menu(self, t0):
        """cuando el menú acaba (flix_menu_done) se repinta lo que cambió (✓…) sin mover el foco. Un favorito quitado lo
        saca la sección de sus filas al momento, sin volver a pedirlas"""
        mon, end = flix_common.quit_monitor(), t0 + MENU_WAIT
        while not self.stop and time.time() < end and not flix_common.quitting(mon):
            done = HOME.getProperty("flix_menu_done")
            if done and float(done) > t0:
                break
            if flix_common.wait_quit(mon, 0.5):
                return
        else:
            return
        if self.stop:
            return
        change = HOME.getProperty("flix_fav_change").split("|")
        if len(change) == 3 and change[1] == "del" and float(change[0] or 0) > t0:
            self.drop_title(change[2])
            return
        self.load(refocus=False)

    def drop_title(self, key):
        """saca el título key («movie:603» / «tv:1399», de flix_k3menu) de las filas de FAVORITOS pintadas, sin pedir
        nada (en Películas o en un Top 10 la película sigue estando aunque deje de ser favorita)"""
        def ref(f):
            r = flix_common.k3_ref(f.get("file")) if isinstance(f, dict) else None
            return "%s:%s" % r if r else ""
        for lid, files in list(self.shown.items()):
            if not flix_rows.FAV_RE.search(self.rows[lid]["path"] or ""):
                continue
            keep = [f for f in files or [] if ref(f) != key]
            if files and len(keep) != len(files):
                self.shown[lid] = keep
                self.refill(lid, [make_item(f, self.rows[lid]) for f in keep] or [placeholder(MISSING)],
                            self.sel_pos(lid))
                log("fila %s: quitado %s (favorito)" % (self.rows[lid]["label"], key))

    def toggle_seen(self, wait=2.0, step=0.05):
        """«Ocultar vistos» / «Vistos ocultos» (Skin.Bool HIDE_SEEN, que lee la ruta del addon: lists.hide_seen): cambia
        el ajuste, da por caducadas las filas de tus listas de Trakt y de favoritos y vuelve a cargar la sección sin mover
        el foco del botón"""
        before = xbmc.getCondVisibility("Skin.HasSetting(%s)" % HIDE_SEEN)
        xbmc.executebuiltin("Skin.ToggleSetting(%s)" % HIDE_SEEN)
        end = time.time() + wait            # el builtin va por la cola de Kodi: se espera a que se vea (acotado)
        while time.time() < end and xbmc.getCondVisibility("Skin.HasSetting(%s)" % HIDE_SEEN) == before:
            time.sleep(step)
        log("%s: vistos %s" % (self.title, "ocultos" if not before else "a la vista"))
        try:
            flix_rows.expire(re.compile(r"lista/trakt-|favoritos/"))
        except Exception as e:  # noqa: BLE001
            log("filas de Trakt y favoritos: %s" % e)
        threading.Thread(target=self.load, kwargs={"refocus": False}, daemon=True).start()

    def onClick(self, control_id):
        if control_id == SEEN:
            self.toggle_seen()
            return
        if control_id == RETRY and self.getProperty("fs_empty") == "1":
            threading.Thread(target=self.load, daemon=True).start()
            return
        if control_id not in self.rows:
            return
        items, pos = self.items_of().get(control_id) or [], self.sel_pos(control_id)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open"):     # «Cargando…» / «No disponible»
            return
        path, how = item.getPath(), item.getProperty("open")
        self.trailer_leave()        # el tráiler de la fila no sigue debajo de lo que se abre
        HOME.setProperty("flix_title", item.getProperty("FlixTitulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid" and item.getProperty("more") and getattr(self, "grid", False):
            self.grid_load_more(item, pos)          # cuadrícula: la página siguiente aquí mismo
        elif how == "grid" and item.getProperty("more"):
            # «Ver más»: la página siguiente como sección de una fila suelta, con los clics de cualquier fila (ficha
            # con tráiler y «Seguir viendo»); en la cuadrícula de Kodi (ventana Vídeos) una película no iba a su ficha
            # y Kodi no deja cambiar el clic de sus listas (Carlos, 7-nov)
            row = self.rows.get(control_id) or {}
            open_more(self.title, row.get("label", ""), path, menu=not self.getProperty("fs_nomenu"),
                      key=getattr(self, "key", "") or getattr(self, "menu_key", ""))
        elif how == "grid" and path.startswith(flix_common.K3_ROOT):
            # tarjeta propia (saga, género, año: bloques 4 y 5): su lista como sección de una fila, con ficha y menú,
            # no la rejilla de Kodi (una película se reproduciría sin ficha)
            open_folder(self.title, item.getLabel(), path, menu=not self.getProperty("fs_nomenu"),
                        key=getattr(self, "key", "") or getattr(self, "menu_key", ""))
        elif how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.title, item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            import flix_series
            flix_series.run(path)                   # en este proceso: sin arrancar otro intérprete
        elif how == "kodi":                 # archivo de otros orígenes: reproducirlo como Kodi
            flix_common.play_kodi(path)
        elif how == "picture":              # foto de una carpeta del NAS: pase de fotos desde ella
            flix_common.show_picture(path)
        elif how == "folder":               # subcarpeta del NAS: como sección, con su nombre
            open_folder(self.title, item.getLabel(), path, menu=not self.getProperty("fs_nomenu"),
                        key=getattr(self, "key", "") or getattr(self, "menu_key", ""))
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.seed_item(path, item)         # la ficha con lo de la carátula: sin esperar al addon
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def open_section(key, t0):
    """abre la sección key y espera a que se cierre; devuelve la clave de la que el usuario eligió en su menú lateral
    ("" = ninguna: se acabó). t0: la pulsación de esta apertura"""
    import flix_sections
    import xbmcvfs
    s = flix_sections.section(key) or flix_sections.section("peliculas")
    log("%s: abierta" % flix_sections_conf.shown(s))     # principio de C5 sin depuración (revisión 29-oct DAT-22)
    HOME.setProperty("flix_section", flix_sections_conf.shown(s))
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                        var=s["src"], title=flix_sections_conf.shown(s), rconf=s.get("rows") or {}, t0=t0,
                        key=s["key"])
    return run_window(win)


# Window(home): «1» desde que una sección se cierra para abrir otra elegida en su menú lateral hasta que main vuelve
# al Inicio. Entre las dos ventanas Kodi enseña el Inicio un instante, con su menú y su vista previa de cuando se salió
# de él: «salta unos segundos la última que has visto» (Carlos, 8-nov). FlixInicio.xml lo tapa de negro
SWAP = "flix_sec_swap"
SIMILAR = "flix_similar"        # Window(home): {"title", "rows"} que deja flix_menu.open_similar para open_rows
MORE_LABEL = "Más títulos"      # cabecera de la fila con la página siguiente de un listado («Ver más»)


def more_rows(title, label, path, menu, skip=None):
    """lo que deja «Ver más» en SIMILAR: la página siguiente (path) como sección de una fila suelta titulada
    «Sección · Fila»; desde una página ya abierta así (fila MORE_LABEL) se conserva el título. menu: menú lateral,
    solo si se veía donde se pulsó (fs_nomenu). skip: tmdb de Series en seguimiento que ya enseñaba la fila (show)"""
    if label and label != MORE_LABEL:
        title = "%s · %s" % (title, label)
    # «Más…» de una fila de tarjetas (sagas: bloques 4 y 5): la página siguiente sigue siendo de tarjetas
    row = {"label": MORE_LABEL, "path": path, "kind": "coll" if path.startswith(flix_rows.CARDS) else "list"}
    if flix_common.is_fs(path):
        row["all"] = True                   # carpeta del NAS: entera, sin otro «Ver más» que volvería a lo mismo
    if skip:
        row["skip"] = list(skip)
    return {"title": title, "rows": [row], "menu": bool(menu)}


def open_more(title, label, path, menu=True, skip=None, key=""):
    """abre la página siguiente de un listado (tarjeta «Ver más») como open_rows, en otro intérprete (como
    flix_menu.open_similar: esta ventana sigue debajo y Atrás vuelve a ella)"""
    data = more_rows(title, label, path, menu, skip)
    data["key"] = key           # la sección de la que se viene: su marca en el menú lateral (SectionWindow.menu_key)
    HOME.setProperty(SIMILAR, json.dumps(data))
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_section.py,similar)")


def open_folder(title, label, path, menu=True, key=""):
    """subcarpeta del NAS (otros orígenes) o tarjeta propia (bloques 4 y 5) como sección de una fila titulada con su
    nombre (la del NAS, entera)"""
    data = more_rows(title, "", path, menu)
    data["rows"][0]["label"] = label
    data["key"] = key           # la sección de la que se viene: su marca en el menú lateral (SectionWindow.menu_key)
    HOME.setProperty(SIMILAR, json.dumps(data))
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_section.py,similar)")


def open_rows(t0):
    """sección hecha de filas sueltas que dejó flix_menu en Window(home) (SIMILAR): «Ver similares» (Carlos, 31-oct).
    En la cuadrícula de Kodi (ventana Vídeos) una película se reproducía sin ficha: aquí los clics son los de cualquier
    sección. Atrás la cierra. Devuelve como open_section"""
    import xbmcvfs
    try:
        data = json.loads(HOME.getProperty(SIMILAR) or "{}")
    except ValueError:
        data = {}
    HOME.clearProperty(SIMILAR)
    rows = [r for r in data.get("rows") or [] if isinstance(r, dict) and r.get("path")]
    if not rows:
        return ""
    title = data.get("title") or ""
    log("%s: abierta" % title)
    HOME.setProperty("flix_section", title)
    # el menú lateral, solo si se abrió desde donde se veía: el Inicio o una sección con él (data["menu"], de quien la
    # pide; Carlos, 31-oct: «si estoy en búsqueda o en una ficha … si abro algo no debería mostrarlo»)
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                        var="", title=title, rconf={}, t0=t0, key="", rows=rows, nomenu=not data.get("menu", True),
                        menu_key=str(data.get("key") or ""),
                        back_cover=(data.get("cover") or "") if data.get("back") else "")
    return run_window(win)


def run_window(win):
    """abre la ventana de una sección y espera a que se cierre; devuelve la clave de la que el usuario eligió en su
    menú lateral ("" = ninguna)"""
    win.doModal()
    win.stop = True
    preview = getattr(win, "preview", None)
    if preview is not None:
        preview.leave()                     # lo que estuviera pidiendo para antes de la fila siguiente
    nxt = getattr(win, "next", "")
    del win
    # la cabecera de entrada es de esta ventana: la siguiente, elegida en su menú, solo lleva la suya si ya la pintaba la
    # vista previa de esta o main la pone (de lo guardado); si no, ni se desliza ni enseña una cabecera vieja
    if not nxt or flix_menu_preview.HOME.getProperty("flix_pv_key") != nxt:
        flix_menu_preview.drop("flix_pv_key")
    return nxt


def main():
    try:
        run(sys.argv[1] if len(sys.argv) > 1 else "peliculas")
    finally:
        HOME.clearProperty(SWAP)            # de vuelta al Inicio (o error): que no se quede tapado


def run(key):
    if key == "similar":                # «Ver similares» (flix_menu.open_similar) y «Títulos de X» (flix_info)
        try:
            data = json.loads(HOME.getProperty(SIMILAR) or "{}")
        except ValueError:
            data = {}
        import flix_info
        if data.get("cover"):
            flix_info.uncover_soon()    # el fondo de la ficha tapaba el Inicio hasta verse esta
        key = open_rows(time.time())
        if not key and data.get("back") and not flix_reload.reloading(HOME):
            # Atrás: a la ficha de la que se vino (no si se fue a otra sección ni si se está recargando el skin)
            flix_info.back_with_cover(data["back"], data.get("cover") or "")
    while key:          # cada vuelta, su pulsación: el menú lateral de la sección cambia de sección en este mismo proceso
        key = open_section(key, time.time())
        if key:
            # la siguiente abre con su cabecera de entrada (lo guardado, sin pedir nada) y se desliza desde los 230 px del
            # menú abierto de esta: sin ella se veían ~0,5 s de negro y «Cargando…» (Carlos, 31-oct)
            flix_menu_preview.entry_header(key)
    # de vuelta al Inicio, nada de la vista previa queda puesto: la repinta el Inicio (lo apartado con leave lo repinta
    # al volver el foco a la misma sección; con «Inicio» o fuera del menú, nada). Antes se reponía lo de antes de entrar
    # y flix_pv_on podía quedarse sin dueño si el Inicio ya había quitado lo suyo: con el foco en «Inicio», la última
    # sección parpadeaba antes de ir a las filas (Carlos, 31-oct). Solo si nadie las ha tocado desde lo último que
    # escribió esta sección: si el Inicio ya repintó su vista previa, es suya (revisión)
    if flix_menu_preview.still_mine():
        flix_menu_preview.clear()


if __name__ == "__main__":
    main()
