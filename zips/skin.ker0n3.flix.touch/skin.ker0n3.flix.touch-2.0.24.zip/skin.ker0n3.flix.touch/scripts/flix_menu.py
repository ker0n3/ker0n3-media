"""Entrada del menú KER0N3 MEDIA (mantener OK / botón ☰) que lanzan las ventanas de Kodi y el corazón de las fichas.

El menú es uno solo, el de flix_k3menu (Carlos, 16-nov: «un solo menú»): ventana FlixMenu.xml con carátula, título,
estado y botones grandes; las marcas las hace el addon Ker0n3 (base propia, Trakt / Simkl). Aquí solo se averigua QUÉ
título es:
  · sin argumentos: lo enfocado en la ficha de una serie (capítulo de una lista de capítulos o temporada de la columna;
    flix_series_sheet lanza este script con el elemento ya enfocado);
  · <ruta>,<carátula>,<título>: ese título;
  · <ruta>,<carátula>,<título>,fav: el corazón de la ficha (añadir o quitar de favoritos, sin menú).
Y «Ver similares» (open_similar), que comparten el menú y las fichas.
Uso: RunScript(special://skin/scripts/flix_menu.py[,<ruta>,<carátula>,<título>[,fav]])
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402

HOME = xbmcgui.Window(10000)
SEASONS_COLUMN = "7952"              # columna de temporadas de la ficha (elementos con su ruta en Property(path))
EPS_LISTS = range(7970, 7977)        # listas de capítulos de la ficha (7970-7975) y 7976: la de una serie de una temporada

_LAST_LOG = [""]


def log(msg):
    xbmc.log("[flix_menu] %s" % msg, xbmc.LOGINFO)
    _LAST_LOG[0] = msg[:500]


def flush_log():
    """la última línea del menú en Window(home).Property(flix_menu_log), legible por JSON-RPC (en Fire OS no se puede
    leer kodi.log). Antes se escribía la propiedad en CADA línea (revisión 7-nov PY-31, como flix_progress)"""
    if _LAST_LOG[0]:
        HOME.setProperty("flix_menu_log", _LAST_LOG[0])


def sheet_open():
    """¿está abierta la ficha de serie (flix_series_sheet)?"""
    return bool(HOME.getProperty("flix_sheet"))


def on_series():
    """¿estamos en la pantalla de una serie (ventana Vídeos o ficha propia)?"""
    return xbmc.getCondVisibility("Window.IsActive(videos)") or sheet_open()


def wait_ctx_closed(limit=2.0):
    """DialogContextMenu.xml lo cierra en su onload, pero este script puede arrancar antes de que se vaya"""
    end = time.time() + limit
    while time.time() < end and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
        xbmc.sleep(50)


def focused_episode():
    """(ruta, carátula, etiqueta) de lo enfocado en la pantalla de serie: el capítulo (listas de capítulos) o la
    temporada (columna 7952); None fuera de ahí"""
    if not on_series():
        return None
    cid = xbmc.getInfoLabel("System.CurrentControlId")
    c = "Container(%s).ListItem." % cid
    if cid == SEASONS_COLUMN:
        path = xbmc.getInfoLabel(c + "Property(path)")
        return (path, "", xbmc.getInfoLabel(c + "Label")) if path else None
    if not cid.isdigit() or int(cid) not in EPS_LISTS:
        return None
    path = xbmc.getInfoLabel(c + "FileNameAndPath")
    return (path, xbmc.getInfoLabel(c + "Art(thumb)"), xbmc.getInfoLabel(c + "Label")) if path else None


def side_menu_shown():
    """¿se ve el menú lateral donde está la carátula? En el Inicio y en las secciones que lo llevan; no en la búsqueda,
    la cuadrícula de Kodi ni una sección de filas sueltas abierta sin él (fs_nomenu). «Ver similares» lo lleva igual"""
    if xbmc.getCondVisibility("Window.IsVisible(FlixSearch.xml)") or not xbmc.getCondVisibility(
            "Window.IsVisible(FlixInicio.xml) | Window.IsVisible(FlixSection.xml)"):
        return False
    return not xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty("fs_nomenu")


def open_similar(kind, info, title):
    """«Ver similares» (Carlos, 31-oct): los parecidos de TMDB que tienen versión (ruta similares/ del addon), en una
    sección de una fila («Similares a <título>»), TV y táctil. Un capítulo, los de su serie"""
    mtype = "movie" if kind == "movie" else "tv"
    title = flix_common.COLOR_RE.sub("", title or "").strip()
    row = {"label": "Títulos parecidos", "path": flix_common.k3_similar(mtype, info.get("tmdb")), "kind": "list"}
    HOME.setProperty("flix_similar", json.dumps({"title": "Similares a %s" % title, "rows": [row],
                                                 "menu": side_menu_shown()}))
    script = "flix_home.py" if xbmc.getSkinDir().endswith(".touch") else "flix_section.py"
    xbmc.executebuiltin("RunScript(special://skin/scripts/%s,similar)" % script)


def fav_from_sheet(path, art, label):
    """corazón de la ficha de película o de serie (Carlos, 13-nov): lo mismo que «Añadir a favoritos» / «Quitar de
    favoritos» del menú, sin enseñarlo (flix_k3menu.favorite: base propia)"""
    import flix_k3menu
    HOME.setProperty("flix_fav_busy", str(time.time()))     # la ficha: corazón «trabajando» hasta que esto acabe
    try:
        if flix_k3menu.favorite(path):
            return True
    finally:
        HOME.clearProperty("flix_fav_busy")
    log("favoritos desde la ficha: ruta sin título (%s)" % (path or "")[:80])
    xbmcgui.Dialog().notification("KER0N3 MEDIA", "No se puede añadir este título a favoritos",
                                  xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)
    return False


def run_menu(path, art, label, in_sheet=True):
    """el menú único del título (flix_k3menu). in_sheet: capítulo o temporada de la ficha de su serie. La marca se
    espera aquí: este script acaba al volver, y quien lo llamó (_main) deja después flix_eps_refresh para que la ficha
    ponga el ✓ en su sitio. False si la ruta no es de un título (sin menú); si no, lo que dio flix_k3menu.menu
    (flix_k3menu.PENDING = se marcó algo)"""
    import flix_k3menu
    if not flix_k3menu.target(path):
        log("sin menú: %s" % (path or "")[:80])
        return False
    return flix_k3menu.menu(path, label, art, HOME.getProperty("flix_open_fanart"), in_sheet=in_sheet, wait=True)


def _main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    art = sys.argv[2] if len(sys.argv) > 2 else ""
    label = sys.argv[3] if len(sys.argv) > 3 else ""
    if len(sys.argv) > 4 and sys.argv[4] == "fav":
        return fav_from_sheet(path, art, label)       # corazón de la ficha: añadir / quitar de favoritos, sin menú
    if path:
        return run_menu(path, art, label, in_sheet=False)
    return menu_focused()


def menu_focused():
    """el menú de lo enfocado en la pantalla de serie (capítulo o temporada). La lista se vuelve a pedir
    (flix_eps_refresh) solo si el menú marcó algo: cerrarlo sin elegir la recargaba igual y la fila parpadeaba y el
    foco podía irse al capítulo que toca (Carlos, 21-nov, ficha en tarjetas)"""
    import flix_k3menu
    wait_ctx_closed()
    ep = focused_episode()
    if not ep:
        return False
    cid = xbmc.getInfoLabel("System.CurrentControlId")
    pos = xbmc.getInfoLabel("Container(%s).CurrentItem" % cid)  # ahora: con un diálogo encima no se lee
    result = None
    try:
        result = run_menu(*ep)
        return result
    finally:
        if result == flix_k3menu.PENDING:
            HOME.setProperty("flix_eps_refresh", "%s,%s" % (cid, pos))  # flix_series: ✓ al día y el foco
        # de vuelta al capítulo; no si ya hay otro menú abierto encima (18-nov, Shield: el SetFocus caía en el menú
        # nuevo y le quitaba el foco de la lista)
        if on_series() and not xbmc.getCondVisibility("Window.IsVisible(FlixMenu.xml)"):
            xbmc.executebuiltin("SetFocus(%s)" % cid)


def main(run=None):
    """run: lo que se hace (de serie _main: RunScript con sus argumentos). La ficha de serie llama a
    main(menu_focused) en su propio proceso: sin arrancar otro intérprete, ~1 s menos en la Shield (21-nov)"""
    # la ficha de serie propia (flix_series_sheet) no abre otro menú mientras este corre (ni con sus Action(ContextMenu))
    HOME.setProperty("flix_menu_run", "1")
    try:
        return (run or _main)()
    finally:
        flush_log()
        HOME.clearProperty("flix_menu_run")
        HOME.setProperty("flix_menu_done", "%f" % time.time())     # sección de la TV: repinta (flix_section.py)


if __name__ == "__main__":
    main()
