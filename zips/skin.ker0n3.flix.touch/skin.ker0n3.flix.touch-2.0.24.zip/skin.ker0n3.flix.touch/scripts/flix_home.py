"""Home TÁCTIL de Ker0n3 Flix (ventana FlixHome.xml), con INERCIA y paso lateral por filas.

Por qué un script (código de Kodi 21):
  - La inercia solo existe en listas/paneles (responden a GESTURE_NOTIFY); un grouplist no la tiene.
    => toda la Home es UNA lista vertical (7000) y cada elemento es una fila.
  - Un elemento de lista no puede contener otra lista, así que los pósters de cada fila son
    propiedades del elemento (p0..p8) y este script decide qué enseñar.
  - WindowXML.onAction recibe TODAS las acciones con coordenadas (getAmount1/2): toque (100) =>
    qué póster se ha tocado; swipe izq/der (511/521) => qué fila pasar de página. El arrastre vertical
    lo hace la lista sola, con inercia, empiece donde empiece el dedo.
Geometría compartida con tools/gen_touch_flixhome.py.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_age  # noqa: E402  (edad recomendada de TMDB en la cabecera)
import flix_common  # noqa: E402
import flix_rows  # noqa: E402  (secciones en filas, compartido con la TV)
import flix_cache  # noqa: E402
import flix_reload  # noqa: E402
import flix_sections  # noqa: E402
from flix_screen import RES, skin_res  # noqa: E402,F401  (común con la ficha de serie: flix_series_sheet.py)

HOME = xbmcgui.Window(10000)
SKIN = xbmcvfs.translatePath("special://skin/")
ROWS = json.load(open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8"))
FOLLOW_ROW = 5102     # «Series en seguimiento» (flix_home_conf.FOLLOW_ROW): de aquí salen los capítulos a medias


def show_chips():
    """tarjetas de arriba = primeras secciones activas (sections.json) -> Window(home).Property(flix_chipN)"""
    flix_sections.chips_props()


def chip_at(i):
    """tarjeta i (0..) tal como se ve ahora (lo que haya puesto flix_sections.apply, también tras editar en Ajustes):
    (etiqueta, clave, rows|list)"""
    if not 0 <= i < flix_sections.flix_sections_conf.TOUCH_MAX:
        return None, None, None
    n = i + 1
    lab = HOME.getProperty("flix_chip%d" % n)
    return (lab, HOME.getProperty("flix_sec%d_key" % n), HOME.getProperty("flix_sec%d_kind" % n)) if lab else (None, None, None)
# geometría común con tools/gen_touch_flixhome.py (FlixHome.xml): una sola fuente (TCT-15)
from flix_home_geom import (CHIP_GAP, CHIP_GAP_NARROW, CHIP_W, CHIP_W_NARROW, CHIPS_EXTRA, CHIPS_H,  # noqa: E402
                            HEADER_H, LEFT, PIECES, POSTER_W, ROW_H, SEEN_H, SEEN_RIGHT, SEEN_TOP, SEEN_W, SIDE_TAP,
                            SLOTS_SET, STEP, TITLE_GAP, TITLE_TAP, WIDE_ROW, grid_cols, item_w, ox_step, pieces_of,
                            slots_of)
CACHE_TTL = 1800   # 30 min: filas personales (las listas, lo que diga flix_rows.ttl_of)
# «2»: caché de la 1.0.71 en adelante; la vieja se borra
# datos de la skin EN USO (xbmc.getSkinDir()), como el resto: con el id escrito a mano, la skin puente (id viejo)
# escribiría en la carpeta de la nueva y le haría creer que ya tiene datos (flix_puente)
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/home_cache2.json" % xbmc.getSkinDir())
try:
    os.remove(CACHE_FILE.replace("home_cache2.json", "home_cache.json"))
except OSError:
    pass
# búsqueda (flix_search.py táctil): las filas de resultados llegan aquí según responde el addon
SEARCH_FILE = xbmcvfs.translatePath("special://temp/flix_search_rows.json")
COLOR_RE = flix_common.COLOR_RE    # la común: la copia de aquí no quitaba [LIGHT] (revisión 29-oct ARR-14b)
A_CLICK, A_SELECT, A_MOVE = 100, 7, 107
A_SWIPE_L, A_SWIPE_R = 511, 521
A_BEGIN, A_PAN, A_ABORT, A_END = 501, 504, 505, 599
A_BACK = flix_common.A_BACK      # códigos de Atrás comunes (TV-28)
A_CONTEXT = (101, 117)
DLG_CTX_QUIET = 3.0      # s tras cerrar un pop-up (FlixResume) sin atender pulsaciones largas
LONG_REPEAT = 1.5        # s: una 2.ª pulsación larga seguida es la misma (Kodi manda 101 y 117)
# Kodi manda cada pulsación larga dos veces: 101 con las coordenadas del dedo y 117 sin ellas, en cualquier orden. La
# que llega sin coordenadas espera un poco a la otra: si se atendía primero usaba un toque anterior (menú de otra
# carátula, o de ninguna) y la buena se descartaba por repetida (móvil Carlos, 22-oct: «a la 1.ª no sale, a la 2.ª sí»)
CTX_WAIT = 0.35
# tocar algo que abre (tarjeta, título, sección, hero, buscador) lanza un RunScript o ActivateWindow que tarda 0,3-1 s
# sin feedback: Window(home).Property(fh_opening) = id de esta ventana → rueda en FlixHome.xml y sin más toques hasta que
# la ventana nueva tapa, sale un diálogo o pasan OPEN_GUARD s (revisión 7-nov TAC-03). SEC_OPENING: una sección que
# aún no ha llegado a onInit cuenta como abierta ese tiempo (fh_sec_open «clave|hora|id de ventana»)
OPEN_GUARD = 3.0
# tras un vídeo: se espera a que la base guarde el progreso antes de repasar las filas personales, como mucho esto.
# Repasando al instante, lo recién parado se quedaba fuera de «Seguir viendo» (móvil de Carlos, 12-nov)
AFTER_VIDEO_MAX = 6.0
SEC_OPENING = 10.0
HERO_EVERY = 12          # s entre giros del hero en reposo (antes 8; revisión 7-nov TAC-05)


def ctx_after_dialog(closed, last_long, now):
    """¿hay que ignorar esta pulsación larga? closed = flix_dlg_closed (hora como texto), last_long = la anterior"""
    try:
        if closed and now - float(closed) < DLG_CTX_QUIET:
            return True
    except ValueError:
        pass
    return bool(last_long) and now - last_long < LONG_REPEAT


def log(msg):
    xbmc.log("[flix_home] %s" % msg, xbmc.LOGINFO)


def clean(s):
    return COLOR_RE.sub("", s or "").strip()


SKIN_W, SKIN_H, SCR_W, SCR_H = skin_res()


def chip_geom(skin_w):
    """(ancho, hueco) de las tarjetas de arriba: las 7 tienen que caber sin desplazar la fila"""
    if LEFT + 7 * (CHIP_W + CHIP_GAP) - CHIP_GAP > skin_w - 16:
        return CHIP_W_NARROW, CHIP_GAP_NARROW
    return CHIP_W, CHIP_GAP


CHIP_GEOM = chip_geom(SKIN_W)
HOME.setProperty("fh_narrow", "1" if CHIP_GEOM[0] == CHIP_W_NARROW else "")   # FlixHome.xml: tamaño de tarjeta


def live(path):
    """resuelve en vivo los $INFO[...] que llevan algunas rutas (&reload=$INFO[Window(home).Property(flix_rl_…)]) y
    convierte las filas de listas de TMDB (flix://tmdb/…) en la ruta lista/<clave> del addon"""
    return flix_rows.directory(re.sub(r"\$INFO\[([^\]]+)\]", lambda m: xbmc.getInfoLabel(m.group(1)), path))


_cache = None
_cache_lock = threading.Lock()
_dirty = [False]    # filas pedidas con fetch(save=False) aún sin guardar (flush)


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cache_save():
    # con el lock: otro hilo de carga puede estar añadiendo filas (antes: «dictionary changed size» y el hilo moría)
    _dirty[0] = False
    if not flix_cache.save_json(CACHE_FILE, _cache, _cache_lock):
        log("no guardo caché")


def flush():
    """guarda home_cache2.json si hay filas pedidas sin guardar (fetch con save=False)"""
    if _dirty[0]:
        _cache_save()


def fetch(path, force=False, save=True):
    """filas con caché en disco (sobrevive a reinicios de Kodi). Clave = ruta sin el
    parámetro &reload= (cambia en cada sesión y no debe invalidar la caché). save=False: no escribe el fichero; el
    que llama hace flush() cada pocas filas (antes se escribía entero tras cada fila; revisión 29-oct DAT-11)"""
    key = flix_rows.cache_key(path)         # la ruta del addon de la fila (bloque 2)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and flix_rows.hit_fresh(path, hit, HOME):     # 30 min personales / 6 h (C-07); aviso de Ker0n3
        return flix_rows._progress(hit[1]), True
    files = flix_rows.list_files(live(path), ["title", "art", "year", "genre", "rating", "runtime", "resume",
                                              "playcount", "file"])
    files = [f for f in files if f.get("label") and not clean(f["label"]).endswith(":")]
    files = flix_rows.tag_k3(path, files)
    if files:                 # vacío = fallo: no machaca una caché buena ni se guarda
        with _cache_lock:
            cache[key] = [time.time(), files]
        _dirty[0] = True
        if save:
            _cache_save()
    return flix_rows._progress(files or (hit[1] if hit else [])), False


def peek(path):
    """(filas guardadas o None, ¿frescas?) SIN pedir nada, aunque estén caducadas: al abrir el Inicio tras
    más de CACHE_TTL se pintan ya y se refrescan por detrás (antes: tarjetas vacías 2-20 s por fila)"""
    hit = _cache_load().get(flix_rows.cache_key(path))
    if not hit or not hit[1]:
        return None, False
    return flix_rows._progress(hit[1]), flix_rows.hit_fresh(path, hit, HOME)


def poster_of(f):
    a = f.get("art") or {}
    return a.get("poster") or a.get("thumb") or a.get("tvshow.poster") or ""


def hero_fanart(url):
    """fondo del hero: el /original de TMDB (hasta 3840×2160) en w1280, el tamaño que pide la ficha de serie
    (flix_series.art_url); lo demás, tal cual (revisión 7-nov TAC-05)"""
    if "image.tmdb.org/t/p/original/" in url:
        return url.replace("/t/p/original/", "/t/p/w1280/", 1)
    return url


def pct_of(f):
    """'' si no hay barra: antes devolvía "0" con duración conocida y posición 0, y watched_of lo tomaba por «a
    medias» -> vista sin ✓ hasta reiniciar Kodi (Proyecto Salvación, móvil 23-oct)"""
    r = f.get("resume") or {}
    pct = int(100 * float(r.get("position") or 0) / float(r["total"])) if r.get("total") else 0
    return str(pct) if pct > 0 else ""


SHOW_STARTED = 99   # serie a medias (flix_progress.SHOW_STARTED)


def watched_of(f):
    """'1' = ya vista (película o serie entera según la base) y sin progreso a medias: ✓ en el póster"""
    pc = int(f.get("playcount") or 0)
    return "1" if pc > 0 and pc != SHOW_STARTED and not pct_of(f) else ""



def reopen_settings():
    """vuelta de «Ajustes de Kodi» abiertos desde los Ajustes de la skin (Settings.xml deja la marca al salir hacia
    atrás): el menú de Ajustes otra vez delante, ahora que el Inicio ya lo está"""
    if HOME.getProperty("flix_abrir_ajustes"):
        HOME.clearProperty("flix_abrir_ajustes")
        xbmc.executebuiltin("ActivateWindow(1196)")

def wide_image(f, cache=None):
    """(imagen, ¿sin título?) de la tarjeta apaisada: la de TMDB con título si está en caché; si no, el fondo del
    título a 500 px (flix_wide.small_fanart) con el logo encima; ('', True) si no hay ninguna"""
    import flix_wide
    u = flix_wide.url_of(f.get("file", ""), cache)
    if u:
        return u, False
    a = f.get("art") or {}
    return flix_wide.small_fanart(a.get("fanart") or "") or a.get("fanart") or "", True


def wide_files(files):
    """«Seguir viendo» como en la TV (flix_inicio.show): el capítulo a medias de cada serie con su «T1 E4»
    (flix_progress.episode_cards)"""
    import flix_progress
    try:
        return flix_progress.episode_cards(files, follow_files())
    except Exception as e:  # noqa: BLE001
        log("Seguir viendo con capítulos: %s" % e)
        return files


def wide_sig(files):
    """lo que se ve de cada tarjeta apaisada: ruta, capítulo y progreso"""
    return [(f.get("file"), f.get("flix_ep"), pct_of(f), f.get("playcount")) for f in files or [] if isinstance(f, dict)]


def follow_files():
    """lo guardado de «Series en seguimiento» del Inicio (sin red); [] si no hay"""
    path = next((d["path"] for d in ROWS if d.get("id") == FOLLOW_ROW), "")
    files, _ = peek(path) if path else (None, False)
    return files or []


def personal_row(row):
    """«Seguir viendo» (apaisada o no) o «Series en seguimiento»"""
    import flix_progress
    return row.layout == "wide" or row.id == FOLLOW_ROW or flix_progress.is_resume_row(row.path)


class Strip:
    """una fila de la Home (o el hero) = PIECES elementos de la lista con las mismas propiedades"""

    def __init__(self, kind, label, pieces=PIECES):
        self.kind = kind
        self.lis = []
        self.vals = {}
        self.height = pieces * STEP
        for j in range(pieces):
            # offscreen=True: setProperty no espera al hilo de dibujo de Kodi (con GUI lock cada llamada
            # tarda ~1 fotograma; 9 trozos x varias propiedades = trompicones al arrastrar)
            li = xbmcgui.ListItem(label, offscreen=True)
            li.setProperty("type", kind)
            li.setProperty("j", str(j))
            li.setProperty("w", str(SKIN_W))
            self.lis.append(li)

    def set(self, key, value):
        if self.vals.get(key) == value:
            return
        self.vals[key] = value
        for li in self.lis:
            li.setProperty(key, value)

    def relabel(self, label):
        """título de la fila (Ajustes → Cambiar nombre con el Inicio ya pintado)"""
        for li in self.lis:
            li.setLabel(label)


SNAP_EDGE = 0.2     # al soltar: encaja a carátula entera solo si la fracción del borde es < 20 % o > 80 %


class Row:
    """fila de pósters con desplazamiento continuo. pos = posición en pósters (2.4 = 3.er póster a la
    izquierda y 0.4 desplazado). Dos juegos de huecos (a/b) en FlixHome.xml: el visible muestra los
    pósters desde 'start'; al cruzar un póster se rellena el otro juego (ListItem offscreen: no espera al
    dibujado) y se cambia juego + fracción con UNA propiedad (fh_o) -> sin saltos ni esperas"""

    def __init__(self, d):
        self.id, self.label, self.path, self.top10 = d["id"], d["label"], d["path"], d["top10"]
        self.title = d.get("title") or d["label"]     # nombre que se ve (Ajustes → Cambiar nombre); label = el interno
        self.kind = d.get("kind", "list")       # sección: "coll" = submenú (tarjetas que abren su rejilla)
        self.limit = d.get("limit")             # Inicio: elementos por fila elegidos en el editor (secciones: todos)
        # fila del Inicio que es una lista de Ker0n3: la ruta de lo que NO enseña (el título abre solo ese resto;
        # Carlos, 16-nov) o '' si lo enseña todo (título sin ›). None: cualquier otra fila, «ver todo» de siempre
        self.rest, self._nochev = None, False
        self.items, self.pos, self.start, self.ox, self.buf, self.strip = [], 0.0, 0, 0, "a", None
        # sin títulos, el hueco 0 es una tarjeta de texto: «Cargando…» y, si la fila no da nada, «No disponible»,
        # como la Sección de la TV (revisión 29-oct TCT-08: antes una franja negra con el título y nada más)
        self.empty_text = flix_rows.LOADING
        self._arrows = None
        self.win = None             # ventana mientras se arrastra (estado en Window.Property(fh_o))
        self._o = None
        self._painted = {"a": None, "b": None}
        self.new = {}               # {tmdb: «NUEVO» / «TEMP. 3»} (flix_newep): Series en seguimiento
        # «Seguir viendo» del Inicio en tarjetas apaisadas (Carlos, 12-nov), como en la TV; en secciones nunca (ids 6100+)
        self.layout = "top10" if self.top10 else ("wide" if self.id == WIDE_ROW else "row")
        self.wide_rev = None        # Window(home).Property(flix_wide_rev) con la que se pintaron sus imágenes

    @property
    def itemw(self):
        return item_w(self.layout)

    @property
    def slots(self):
        return slots_of(self.layout)

    @property
    def visible(self):
        return max(1, int((SKIN_W - LEFT) // self.itemw))

    @property
    def max_pos(self):
        return float(max(0, len(self.items) - self.visible))

    def rest_for(self, files):
        """self.rest que toca con lo que da la ruta (files): la fila enseña los self.limit primeros"""
        key = flix_rows.k3_list_key(self.path) if self.limit and not self.top10 else ""
        if not key:
            return None
        out = flix_rows.k3_rest(key, files, files[:self.limit])
        return out[-1]["file"] if out and flix_rows.is_more(out[-1]) else ""

    def chevron(self):
        """lista de Ker0n3 sin nada más que ver: título sin › (nochev, como las filas del buscador)"""
        if self.rest is not None or self._nochev:
            self._nochev = self.rest == ""
            self.strip.set("nochev", "1" if self._nochev else "")

    def sync_rest(self, files):
        """la fila no se repinta (enseña lo mismo) pero la lista puede haber crecido o menguado por detrás"""
        rest = self.rest_for(files)
        if rest != self.rest:
            self.rest = rest
            if self.strip is not None:
                self.chevron()

    def set_items(self, files):
        if self.layout == "wide":
            files = wide_files(files)
        self.items = files[:10] if self.top10 else (files[:self.limit] if self.limit else files)
        self.rest = self.rest_for(files)
        self.pos = min(self.pos, self.max_pos)
        self.load_new()
        if self.layout == "wide":
            import flix_wide
            flix_wide.want(self.items)      # imágenes apaisadas que falten, en segundo plano (avisa con flix_wide_rev)

    def load_new(self):
        """etiquetas de lo nuevo (solo lee lo guardado; lo caducado se pide en un hilo que luego llama a paint_new).
        True si cambiaron"""
        ids = [flix_rows.follow_tmdb(f) for f in self.items]
        old, self.new = self.new, {}
        if any(ids):
            import flix_newep
            self.new = flix_newep.row_labels(ids, self.reload_new)
        return self.new != old

    def reload_new(self):
        """hilo de flix_newep: TMDB ya ha contestado. Solo toca la etiqueta de los huecos pintados, nada de posición"""
        if self.load_new():
            self.paint_new()

    def paint_new(self):
        for buf in ("a", "b"):
            start = self._painted[buf]
            if start is None or self.strip is None:
                continue
            for k in range(self.slots):
                i = start + k
                self.strip.set("%snw%d" % (buf, k), self.new_label(self.items[i]) if i < len(self.items) else "")

    def new_label(self, f):
        return self.new.get(str(flix_rows.follow_tmdb(f)), "")

    def fill(self, buf, start):
        if self.layout == "wide":
            return self.fill_wide(buf, start)
        st = self.strip
        for k in range(SLOTS_SET):
            i = start + k
            if i < len(self.items):
                f = self.items[i]
                more = flix_rows.is_more(f)
                text = more or (self.kind == "coll" and flix_rows.is_generic(f))   # tarjeta de texto
                st.set("%sp%d" % (buf, k), "" if text else poster_of(f))
                st.set("%st%d" % (buf, k), ("Cargando…" if f.get("loading") else "Ver más") if more
                       else (clean(f.get("label")) or " "))
                st.set("%spc%d" % (buf, k), pct_of(f))
                st.set("%sw%d" % (buf, k), watched_of(f))
                # series: ▶ en «Series en seguimiento» y en las que llevas a medias (flix_progress: playcount
                # SHOW_STARTED, calculado de watched.db: las filas no traen el estado de las series)
                st.set("%sip%d" % (buf, k), "1" if f.get("type") == "tvshow" and (
                    self.id == FOLLOW_ROW or int(f.get("playcount") or 0) == SHOW_STARTED) else "")
                st.set("%sn%d" % (buf, k), str(i + 1) if self.top10 else "")
                st.set("%snw%d" % (buf, k), self.new_label(f))
            else:
                for p in ("p", "t", "pc", "n", "w", "ip", "nw"):
                    st.set("%s%s%d" % (buf, p, k), "")
                if not self.items and i == 0:
                    st.set("%st%d" % (buf, k), self.empty_text)      # tarjeta de texto (TCT-08)
        self._painted[buf] = start

    def fill_wide(self, buf, start):
        """tarjeta apaisada: imagen de TMDB con el título (flix_wide) o, mientras no llega / si no hay, el fondo del
        título en pequeño con su logo; «Quedan…» (con «T1 E4» en los capítulos) y la barra"""
        import flix_wide
        st = self.strip
        self.wide_rev = HOME.getProperty(flix_wide.REV)
        cache = flix_wide.data()
        for k in range(self.slots):
            i = start + k
            f = self.items[i] if i < len(self.items) else None
            if f is not None:
                more = flix_rows.is_more(f)
                img, plain = ("", False) if more else wide_image(f, cache)
                a = f.get("art") or {}
                st.set("%sp%d" % (buf, k), img)
                st.set("%st%d" % (buf, k), "Ver más" if more else (clean(f.get("label")) or " "))
                st.set("%spl%d" % (buf, k), "1" if plain and img else "")
                st.set("%slg%d" % (buf, k), (a.get("clearlogo") or "") if plain else "")
                st.set("%slf%d" % (buf, k), "" if more else flix_wide.left_text(f))
                st.set("%spc%d" % (buf, k), "" if more else pct_of(f))
            else:
                for p in ("p", "t", "pl", "lg", "lf", "pc"):
                    st.set("%s%s%d" % (buf, p, k), "")
                if not self.items and i == 0:
                    st.set("%st%d" % (buf, k), self.empty_text)
        self._painted[buf] = start

    def paint(self):
        """(re)pinta con los datos actuales (carga / refresco)"""
        self.start = int(self.pos)
        self.fill(self.buf, self.start)
        self.chevron()
        self._painted[self.other] = None
        self._arrows = None
        self.publish(force=True)

    @property
    def other(self):
        return "b" if self.buf == "a" else "a"

    def set_pos(self, pos):
        self.pos = max(0.0, min(float(pos), self.max_pos))
        start = int(self.pos)
        step = ox_step(self.layout)
        ox = int(round((self.pos - start) * self.itemw / step))
        if ox >= self.itemw // step:
            # FlixHome.xml solo tiene animación para los pasos 1 … itemw // OX_STEP - 1 (gen_touch_flixhome.offset_anims):
            # un paso más alto (286 / 10 = 28,6 → redondeo a 28) no existía y la fila saltaba al principio del póster
            start, ox = start + 1, 0
        if start != self.start:
            nb = self.other
            if self._painted[nb] != start:
                self.fill(nb, start)              # el juego oculto: no se ve mientras se rellena
            self.buf, self.start = nb, start
        self.ox = ox
        self.publish()

    def publish(self, force=False):
        if self.win is not None:                  # arrastrando: juego + fracción en UNA propiedad
            o = "%s%02d" % (self.buf.upper(), self.ox)
            if o != self._o:
                self._o = o
                self.win.setProperty("fh_o", o)
        else:
            self.strip.set("buf", self.buf)
            self.strip.set("ox", str(self.ox) if self.ox else "")
        arrows = (self.pos > 0.05, self.pos < self.max_pos - 0.05)
        if force or arrows != self._arrows:
            self._arrows = arrows
            self.strip.set("prev", "1" if arrows[0] else "")
            self.strip.set("next", "1" if arrows[1] else "")

    def begin_drag(self, win):
        if self.win is None:
            self.win = win
            self._o = None
            self.publish()                        # primero la propiedad de ventana…
            self.strip.set("drag", "1")           # …luego la fila pasa a leerla

    def end_drag(self):
        if self.win is not None:
            win, self.win = self.win, None
            self.publish(force=True)              # estado final en la propia fila…
            self.strip.set("drag", "")            # …deja de leer la de ventana…
            win.setProperty("fh_o", "")

    def index_at(self, sx):
        return int((sx - LEFT) / self.itemw + self.pos)


class GridRow(Row):
    """cuadrícula (19-nov, Carlos; spec 2026-11-18-cuadricula-listas-sueltas): la sección de UNA fila suelta en
    líneas de carátulas. Esta es la 1.ª (título + las primeras `cols`); las demás son Line, detrás en la lista vertical.
    every = todos los títulos (con el «Ver más» al final si hay más); items = los de la 1.ª línea. home = la ventana
    (paint pone las líneas en su lista)"""

    def __init__(self, d, home):
        super().__init__(d)
        self.layout = "gridhead"
        self.home, self.every, self.lines = home, [], []

    @property
    def cols(self):
        return grid_cols(SKIN_W)

    @property
    def max_pos(self):
        return 0.0                  # nada que desplazar: lo que no cabe va a la línea siguiente

    def set_items(self, files):
        """lo que dé la ruta; lo añadido con «Ver más» se queda (un repintado de la 1.ª página no lo quita)"""
        files = list(files or [])
        old = [f for f in self.every if not flix_rows.is_more(f)]
        if len(old) > len([f for f in files if not flix_rows.is_more(f)]):
            have = {f.get("file") for f in files}
            more = [f for f in self.every if flix_rows.is_more(f)][-1:]
            files = [f for f in files if not flix_rows.is_more(f)] + \
                [f for f in old if f.get("file") not in have] + more
        self.every = files[:FOLDER_LIMIT + 1]
        self.items = self.every[:self.cols]
        self.rest, self.pos = None, 0.0
        self.load_new()

    def paint(self):
        super().paint()
        self.strip.set("nochev", "1")
        self.home.grid_lines(self)


class Line(Row):
    """línea de la cuadrícula tras la 1.ª: solo carátulas (FlixHome.xml, tipo «line»), de la fila head"""

    def __init__(self, head):
        super().__init__({"id": head.id, "label": head.label, "title": head.title, "path": head.path, "top10": False,
                          "kind": head.kind})
        self.layout, self.head, self.empty_text = "line", head, ""
        self.strip = Strip("line", "", pieces_of("line"))

    @property
    def max_pos(self):
        return 0.0


FOLDER_LIMIT = 1000     # tope de títulos en la cuadrícula (= flix_section.FOLDER_LIMIT)
SEEN_VARS = ("own:trakt", "own:favoritos")     # secciones con «Ocultar vistos» (= flix_section.SEEN_VARS)
HIDE_SEEN = "flix_trakt_hide_seen"             # = ker0n3.lists.HIDE_SEEN
PRE_ROUNDS = 8          # vueltas de precarga de la página siguiente (= flix_section.SectionWindow.PRE_ROUNDS)


class Animator(threading.Thread):
    """aplica el movimiento lateral a ~60 fps: sigue al dedo (drag) o desliza con frenada (glide).
    Los eventos del dedo solo guardan la posición deseada; así no se encolan repintados."""

    def __init__(self, win):
        super().__init__(daemon=True)
        self.win = win
        self.row = None
        self.drag_pos = None        # posición pedida por el dedo
        self.glide = None           # (inicio, destino, t0, duración)
        self.cv = threading.Condition()

    def _switch(self, row):
        if self.row is not None and self.row is not row:
            self.row.end_drag()
        row.begin_drag(self.win)

    def drag(self, row, pos):
        with self.cv:
            self._switch(row)
            self.row, self.glide, self.drag_pos = row, None, pos
            self.cv.notify()

    def stop_row(self, row):
        with self.cv:
            if self.row is row:
                self.glide = None

    def glide_to(self, row, target, dur=0.35):
        with self.cv:
            self._switch(row)
            self.row, self.drag_pos = row, None
            self.glide = (row.pos, max(0.0, min(float(target), row.max_pos)), time.time(), dur)
            self.cv.notify()

    def run(self):
        try:
            self._run()
        except Exception:  # noqa: BLE001
            import traceback
            log("animador caído: %s" % traceback.format_exc())

    def _run(self):
        while not self.win.stop:
            with self.cv:
                if self.drag_pos is None and self.glide is None:
                    self.cv.wait(0.5)
                    idle = True
                else:
                    idle = False
            if idle:
                if not self.win.section:
                    self.win.sync_chips()   # barato: Strip.set no toca nada si no cambió
                continue
            with self.cv:
                row, dp, gl = self.row, self.drag_pos, self.glide
                self.drag_pos = None
            if dp is not None:
                row.set_pos(dp)
            elif gl is not None:
                a, b, t0, dur = gl
                t = min(1.0, (time.time() - t0) / dur)
                row.set_pos(a + (b - a) * (1 - (1 - t) ** 3))
                if t >= 1.0:
                    with self.cv:
                        if self.glide is gl:
                            self.glide = None
                            row.end_drag()        # guarda la posición en la fila
            time.sleep(1 / 60)


class FlixHome(xbmcgui.WindowXML):
    progress_sig = ""        # huella de watched.db (flix_progress.watched_sig) de la última pasada de sync_progress
    opening_at = 0.0         # de clase, como progress_sig: los tests construyen la ventana sin __init__
    win_id = 0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.section = kwargs.get("section")    # (menú own:… o ruta, título) = sección desplegada en filas
        self.rconf = kwargs.get("rconf") or {}  # filas elegidas de la sección (flix_sections_conf.apply_rows)
        self.fixed = kwargs.get("rows")         # filas sueltas en vez de las del menú de la sección («Ver similares»)
        # resultados del buscador táctil: misma ventana que una sección (atrás + título), filas de SEARCH_FILE
        self.search = kwargs.get("search", False)
        self.token = kwargs.get("token", "")     # solo el Inicio: fh_token de main()
        self.sec_key = kwargs.get("sec_key", "")  # sección del menú (RunScript(flix_home.py,sec,<clave>)): fh_sec_open
        self.inited = False
        self.opening_at = 0.0    # hora del toque que está abriendo algo (mark_opening)
        self.flags = {}          # flix_common.expire_hide_flags
        self.rows = [] if self.section else self.home_rows()
        self.shown = []          # orden en la lista: "hero" o Row (cada uno ocupa PIECES elementos)
        # el hueco del hero existe desde el principio (vacío hasta que llegan datos): crearlo más tarde obligaba a
        # rehacer la lista entera y la devolvía arriba aunque el usuario ya estuviera bajando
        # (las secciones no llevan hero: Carlos no lo quiere ahí)
        self.hero_items, self.hero_i, self.hero_top = [], 0, False
        self.hero = None if kwargs.get("section") else Strip("hero", "hero")
        self.chips = Strip("chips", "chips", CHIPS_H // STEP)
        self.last_touch = 0.0
        self.fav_seen = time.time()     # flix_fav_change de flix_menu.py: solo los de después de abrir esta pantalla
        self.mouse = (0.0, 0.0)
        self.loaded_at = 0.0
        self.win_id = 0          # id de esta ventana (onInit): el hilo de carga solo consulta con ella activa
        self._cur_row = 0
        self.lock = threading.RLock()
        self.rating_busy = set()  # rutas cuya nota (flix_ratings) se está pidiendo
        self.stop = False
        self.g = None            # gesto en curso
        self.anim = Animator(self)
        self.anim.start()
        self.fling_id = 0

    def sync_chips(self):
        """copia las etiquetas de Window(home).Property(flix_chipN) al elemento de tarjetas (el animador lo repite en
        reposo: así se ve el cambio al salir de Ajustes → Secciones del menú sin reabrir el Inicio)"""
        for i in range(1, flix_sections.flix_sections_conf.TOUCH_MAX + 1):
            self.chips.set("c%d" % i, HOME.getProperty("flix_chip%d" % i))

    @staticmethod
    def home_rows():
        """filas del Inicio elegidas en el editor (flix_home_order.py): orden, ocultas, eliminadas, añadidas y
        elementos por fila (flix_home_conf)"""
        try:
            import flix_home_conf as hc
            import flix_home_order as fho
            try:
                import flix_random_rows
                flix_random_rows.promote_saved(peek)    # Filas al azar: el sorteo preparado (una vez por sesión)
            except Exception as e:  # noqa: BLE001
                log("filas al azar: %s" % e)
            conf = fho.effective(fho.load_conf())      # modo modesto: sus 6 filas
            return [Row(dict(r, top10=r.get("top10", False), kind=r.get("kind", "list"), limit=conf["items"]))
                    for r in hc.compose(ROWS, conf) if not r["hidden"]]
        except Exception as e:  # noqa: BLE001
            log("orden del Inicio: %s" % e)
            return [Row(dict(d, limit=15)) for d in ROWS]

    def apply_reorder(self):
        """orden cambiado en Ajustes (flix_home_order.py pone fh_reorder): se aplica al momento"""
        if self.section or HOME.getProperty("fh_reorder") != "1":
            return
        HOME.clearProperty("fh_reorder")
        with self.lock:
            old = {r.id: r for r in self.rows}
            rows = []
            for r in self.home_rows():
                o = old.get(r.id)
                if o is not None and o.path != r.path:
                    o = None    # hueco de una fila borrada que ahora es otra: con la fila vieja salían sus títulos
                if o is not None and o.title != r.title:     # renombrada en el editor: la fila ya pintada también
                    o.title = r.title
                    if o.strip is not None:
                        o.strip.relabel(r.title)
                rows.append(o or r)
            self.rows = rows
            for row in self.rows:                   # filas añadidas: su hueco ya, en su sitio
                if row.strip is None:
                    row.strip = Strip(row.layout, row.title)
                    row.paint()
            if self.shown:
                # cambio pedido en el editor: lista entera en el orden guardado. Sin esto, tras tocar la pantalla
                # order() manda las filas nuevas al final (evita saltos al cargar) y la añadida "no aparecía"
                self.shown = []
                touched, self.last_touch = self.last_touch, 0.0
                self.rebuild()
                self.last_touch = touched
        threading.Thread(target=self.load_all, daemon=True).start()   # filas que estaban ocultas
        log("orden del Inicio aplicado")

    # ---------- ciclo de vida ----------
    def onInit(self):
        self.inited = True
        log("DIAG onInit (filas mostradas %d, pos %s)" % (len(self.shown), xbmc.getInfoLabel("Container(7000).Position")))
        # id de ESTA ventana (Python: 13000+). Al volver de un vídeo onInit llega con Home (10000) activa: guardar ese
        # id hacía que Home.xml «volviera» al Inicio activándose a sí misma -> pantalla negra (móvil, 19-oct)
        wid = xbmcgui.getCurrentWindowId()
        if wid >= 13000:
            self.win_id = wid
        if self.section:
            self.setProperty("fh_mode", "section")
            self.setProperty("fh_title", self.section[1])
            # «Ocultar vistos» en la cabecera: Trakt y Favoritos (19-nov, Carlos)
            self.setProperty("fh_seen", "1" if self.section[0] in SEEN_VARS else "")
            if self.sec_key and self.win_id:
                HOME.setProperty("fh_sec_open", "%s|%f|%d" % (self.sec_key, time.time(), self.win_id))
        elif self.win_id:
            HOME.setProperty("fh_window", str(self.win_id))
        self.clear_opening()         # lo que se tocó ya se abrió (y se ha vuelto) o no llegó: toques otra vez
        self.restore_after_reload()
        show_chips()                 # al volver de Ajustes se ven ya las secciones elegidas
        self.sync_chips()
        self.lst = self.getControl(7000)
        self.apply_reorder()
        reopen_settings()
        if HOME.getProperty("flix_trailer"):
            return                   # vuelta de un tráiler (flix_trailer.py): nada que repasar, se reabre la ficha
        # vuelta de un vídeo: el repaso de las filas personales espera a que la base guarde (personal_tick). Se apunta
        # ANTES de lanzar sync_progress: su 1.ª pasada no debe tocarlas con lo recién visto aún sin guardar
        pending = (HOME.getProperty("fh_played") == "1" and bool(self.shown) and not self.section and not self.search
                   and time.time() - self.loaded_at <= CACHE_TTL)
        if pending:
            self.after_video = time.time()
        threading.Thread(target=self.sync_progress, daemon=True).start()
        seen, self.seen_all = getattr(self, "seen_all", None), None
        if seen is not None and self.shown:
            threading.Thread(target=self.refresh_seen, args=(seen,), daemon=True).start()
        if not self.shown:
            threading.Thread(target=self.load_all, daemon=True).start()
            threading.Thread(target=self.hero_timer, daemon=True).start()
        elif time.time() - self.loaded_at > CACHE_TTL:
            threading.Thread(target=self.load_all, kwargs={"refresh": True}, daemon=True).start()
        elif HOME.getProperty("fh_played") == "1":
            HOME.clearProperty("fh_played")
            if not pending:                             # pendiente: lo repasa personal_tick cuando la base guarde
                threading.Thread(target=self.load_all, kwargs={"refresh": True, "only_progress": True}, daemon=True).start()

    @staticmethod
    def cards_row(row):
        """¿fila de tarjetas propias (ruta tarjetas/ del addon, bloques 4 y 5)? Su título no abre nada"""
        return str(getattr(row, "path", "") or "").startswith(flix_rows.CARDS)

    def rest_of(self, row):
        """lo que abre el título de una fila del Inicio que es una lista de Ker0n3: la ruta de su resto, '' si no
        queda nada por ver, None si no es el caso (secciones, buscador, Top 10, otros orígenes: «ver todo»)"""
        return None if self.section or self.search else getattr(row, "rest", None)

    def refresh_seen(self, row):
        """vuelta de «ver todo» (título de la fila): la fila se pide otra vez. La rejilla se acaba de pedir y
        la fila del Inicio seguía con lo guardado (hasta CACHE_TTL): el Top 10 salía en otro orden en el Inicio que en
        su rejilla (móvil, Carlos 1-nov)"""
        try:
            files, _ = fetch(row.path, force=True, save=True)
        except Exception as e:  # noqa: BLE001
            log("fila %s al volver de ver todo: %s" % (row.label, e))
            return
        if self.stop or not files or flix_cache.same_items(row.items, files[:len(row.items)]):
            return
        with self.lock:
            row.set_items(files)
            self.hero_from(row, files)
            row.paint()
        log("fila %s: puesta al día al volver de ver todo" % row.label)

    def sync_progress(self):
        """progreso real de la base de vistos (flix_progress.py): repinta las barras de las filas ya mostradas sin
        volver a pedirlas (al volver de un vídeo o de limpiar progreso / marcar como vista)"""
        import flix_progress
        # esperas de 3, 8 y 15 s: al cerrarse Kodi vuelven en menos de 1 s (System.OnQuit; a los RunScript sin addon
        # Kodi no avisa por abortRequested y los mataba a los 5 s; APA-03)
        mon = flix_common.quit_monitor()
        for wait in (0, 3, 8):
            if wait and flix_common.wait_quit(mon, wait):
                return
            if self.stop:
                return
            # la huella ANTES de leer watched.db (como one_pass en la TV): si la base guarda mientras se corrige, la
            # vuelta siguiente lo ve
            sig = flix_progress.watched_sig()
            W = flix_progress.truth_cached(max_age=0)
            if W is None:
                continue   # sin watched.db no se toca nada ({} = sin películas, las series sí: B-06)
            self.progress_sig = sig
            with self.lock:
                for row in self.rows:
                    # las carátulas de la fila están en row.items (Strip no tiene items: antes no repintaba nunca,
                    # auditoría PY-01)
                    if row.strip is None or not row.items:
                        continue
                    if getattr(self, "after_video", None) is not None and personal_row(row):
                        continue    # recién parado un vídeo y la base aún sin guardar: las repasa personal_tick
                    changed = flix_progress.fix_files(getattr(row, "every", None) or row.items, W)
                    changed = row.load_new() or changed     # y lo nuevo: ya visto, la etiqueta se va
                    if row.layout == "wide":
                        # tarjetas apaisadas: los capítulos a medias rehechos con lo de ahora
                        before = wide_sig(row.items)
                        row.set_items(list(row.items))
                        changed = changed or wide_sig(row.items) != before
                    if changed:
                        log("fila %s: ✓/progreso al día" % row.label)
                        row.paint()

    def load_all(self, refresh=False, only_progress=False):
        if self.search:
            self.load_search()
            return
        if self.section and not self.rows:
            flix_common.dir_failed(reset=True)
            rows = getattr(self, "fixed", None) or \
                flix_sections.effective_rows(self.section[0], self.rconf, stale_ok=True)
            grid = bool(getattr(self, "fixed", None)) and len(rows) == 1     # cuadrícula: una sola fila suelta
            self.rows = [(GridRow if grid else Row)(
                {"id": 6100 + i, "label": r["label"], "title": r.get("title"), "path": r["path"], "top10": False,
                 "kind": r["kind"]}, *([self] if grid else [])) for i, r in enumerate(rows)]
            if not self.rows:
                # sección sin filas: «No responde» o «Sin contenido» en vez de «Cargando…» para siempre (TV-12)
                self.setProperty("fh_state", "error" if flix_common.dir_failed(reset=True) else "empty")
                log("sección %s sin filas (%s)" % (self.section[1], self.getProperty("fh_state")))
        # TODAS las filas se crean de golpe (vacías, con su título) y la lista se monta UNA vez: luego solo se
        # rellenan sus carátulas (propiedades). Añadir elementos a la lista mientras el usuario baja la recolocaba
        # (vuelta arriba) y redibujaba el hero (parpadeo).
        with self.lock:
            fresh = False
            for row in self.rows:
                if row.strip is None:
                    row.strip = Strip(row.layout, row.title, pieces_of(row.layout))
                    row.paint()
                    fresh = True
            if fresh and (not self.shown or any(r not in self.shown for r in self.rows)):
                self.rebuild()
        fresh_rows = set()
        if not self.section and not only_progress and not refresh:
            # Inicio: lo guardado al momento aunque esté caducado; luego solo se pide lo caducado
            painted = 0
            for row in list(self.rows):
                files, fresh = peek(row.path)
                if files:
                    with self.lock:
                        row.set_items(files)
                        self.hero_from(row, files)
                        row.paint()
                    painted += 1
                    if fresh:
                        fresh_rows.add(row.id)
            log("Inicio: %d filas pintadas con lo guardado (%d caducadas: se refrescan)" % (painted, painted - len(fresh_rows)))
        if self.section and not only_progress:
            # sección: lo guardado al momento aunque esté caducado; luego solo se pide lo caducado (auditoría REND-02)
            for row in list(self.rows):
                files, fresh = flix_rows.peek(row.path)
                if files:
                    with self.lock:
                        row.set_items(files)
                        row.paint()
                if fresh and not refresh:
                    fresh_rows.add(row.id)
        # Inicio: home_cache2.json cada 4 filas pedidas, antes de quedarse esperando en la carga diferida y al final
        # (antes, entero tras cada fila; Android puede cerrar Kodi en segundo plano: lo pedido se guarda antes de
        # esperar; revisión 29-oct DAT-11). Las secciones guardan rows_cache2.json con flix_rows.flush
        try:
            done = self._load_rows(refresh, only_progress, fresh_rows)
        finally:
            if not self.section:
                flush()
        if self.section:
            flix_rows.flush()
        if done:
            self.loaded_at = time.time()

    def _load_rows(self, refresh, only_progress, fresh_rows):
        """lo que falta de load_all: pide las filas caducadas o sin caché, en orden. False si se cortó (ventana
        cerrada, Kodi cerrándose)"""
        asked = 0
        mon = xbmc.Monitor()      # uno para toda la carga (antes uno nuevo cada 0,3 s de espera: revisión 7-nov TAC-06)
        todo = list(enumerate(self.rows))
        while todo:
            idx, row = todo.pop(0)
            if self.stop:
                return False
            if row.id in fresh_rows:
                continue
            if only_progress and "Seguir" not in row.label and "seguimiento" not in row.label:
                continue
            # carga diferida (solo Inicio): las filas lejanas esperan a que el usuario se acerque; las que tienen
            # caché fresca se pintan ya (no cuestan llamadas al addon). Al refrescar, las lejanas se dejan.
            if not self.section and not only_progress and not self.cache_fresh(row.path):
                if refresh and idx >= self.near_limit():
                    continue
                if idx >= self.near_limit():
                    flush()                         # antes de esperar: lo pedido, guardado
                while idx >= self.near_limit():
                    if self.stop or mon.waitForAbort(0.3):
                        return False
            try:
                files, cached = (flix_rows.fetch(row.path, force=True, save=False) if self.section
                                 else fetch(row.path, force=only_progress, save=False))
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row.label, e))
                self.missing(row)
                continue
            if not self.section and not cached:
                asked += 1
                if asked % 4 == 0:
                    flush()
            log("fila %s: %d%s" % (row.label, len(files), " (caché)" if cached else ""))
            if self.section and files and flix_cache.same_items(row.items, files[:len(row.items)]) and \
                    len(row.items) == len(files[:row.limit] if row.limit else files):
                continue                                # sección refrescada sin cambios: no se repinta
            if not self.section and not refresh and not only_progress and files and flix_cache.same_items(row.items, files[:len(row.items)]) and \
                    len(row.items) == len(files[:10] if row.top10 else (files[:row.limit] if row.limit else files)):
                row.sync_rest(files)                    # …pero su «ver más» sí puede haber cambiado
                continue                                # ya pintada con lo guardado y no ha cambiado: sin repintar
            with self.lock:
                row.set_items(files)
                self.hero_from(row, files)
                row.paint()
            if not files:
                self.missing(row)
        return True

    def missing(self, row):
        """la fila no dio nada y no hay nada guardado: «No disponible» en su hueco (TCT-08)"""
        if row.items or row.strip is None:
            return
        with self.lock:
            row.empty_text = flix_rows.MISSING
            row.paint()

    def load_search(self):
        """resultados del buscador: flix_search.py escribe SEARCH_FILE cada vez que una búsqueda del addon responde
        (filas nuevas o más títulos en una fila) y lo marca como terminado al final. Las filas se añaden al final de
        la lista según llegan (append_or_rebuild: sin volver arriba)."""
        if getattr(self, "_search_started", False):
            return                      # onInit lo vuelve a pedir al volver de una ficha o un vídeo
        self._search_started = True
        by_label, mtime, gen = {}, None, None
        mon = xbmc.Monitor()
        while not self.stop:
            try:
                st = os.stat(SEARCH_FILE).st_mtime_ns
            except OSError:
                st = None
            if st is not None and st != mtime:
                mtime = st
                try:
                    with open(SEARCH_FILE, encoding="utf-8") as fh:
                        data = json.load(fh)
                except (OSError, ValueError):
                    data = None             # a medio escribir: el siguiente vistazo
                if data is not None:
                    if gen is None:
                        gen = data.get("gen")
                    if data.get("gen") != gen:
                        return              # otra búsqueda: esta ventana ya no la enseña
                    for r in data.get("rows") or []:
                        files = flix_rows._progress(r.get("files") or [])
                        row = by_label.get(r["label"])
                        with self.lock:
                            if row is None:
                                row = Row({"id": 6100 + len(by_label), "label": r["label"], "path": r.get("path") or "",
                                           "top10": False, "kind": "list"})
                                by_label[r["label"]] = row
                                self.rows.append(row)
                                row.strip = Strip("row", row.title)
                                row.strip.set("nochev", "1")    # título sin › (no hay «ver todo»)
                                row.set_items(files)
                                row.paint()
                                order = [x["label"] for x in data.get("rows") or []]
                                after = [x for x in self.rows if x.label in by_label and x is not row
                                         and order.index(x.label) > order.index(row.label)] if row.label in order else []
                                if after and self.shown and after[0] in self.shown:
                                    self.rows.remove(row)
                                    self.rows.insert(self.rows.index(after[0]), row)
                                    self.insert_before(row, after[0])     # título exacto: arriba nada más llegar
                                else:
                                    self.append_or_rebuild(row)
                            elif len(files) != len(row.items):
                                row.set_items(files)
                                row.paint()
                    if data.get("done"):
                        # flix_search.py sube al final la fila con el título exacto («up» -> Películas de dibujos)
                        order = [r["label"] for r in data.get("rows") or []]
                        with self.lock:
                            mine = [r for r in self.rows if r.label in by_label]
                            if [r.label for r in mine] != [k for k in order if k in by_label]:
                                log("búsqueda: filas reordenadas (título exacto arriba)")
                                rest = [r for r in self.rows if r.label not in by_label]
                                self.rows = rest + sorted(mine, key=lambda r: order.index(r.label))
                                self.rebuild()
                        break
            if mon.waitForAbort(0.3):
                return
        log("búsqueda: %d filas" % len(by_label))
        self.loaded_at = time.time()

    def hero_from(self, row, files):
        """el hero sale de Top 10 películas (o de la primera fila de carátulas si esa está oculta)"""
        hero_src = 5105 if any(r.id == 5105 for r in self.rows) else None
        if self.hero is not None and files and (row.id == hero_src or (hero_src is None and row.kind == "list" and not self.hero_items)):
            self.set_hero([f for f in files if not flix_rows.is_more(f)][:10], top=row.id == 5105)

    def near_limit(self):
        """filas que se pueden cargar ya: las 5 primeras y hasta 3 por debajo de la que se está viendo"""
        import flix_home_conf as hc
        return max(hc.INITIAL_NEAR, self.current_row() + hc.AHEAD + 1)

    def current_row(self):
        """índice en self.rows de la fila seleccionada en la lista vertical (hero/chips = 0).
        Se llama desde el hilo de carga: NUNCA tocar controles (self.lst) desde aquí. Si Kodi destruye la ventana
        (recarga de la skin al actualizarse) mientras un hilo usa un control, Kodi entero se cae (pasó en 1.0.40-41).
        Por eso: InfoLabel de Kodi y solo con esta ventana activa; si no, el último valor conocido."""
        if self.stop or not self.win_id or xbmcgui.getCurrentWindowId() != self.win_id:
            return self._cur_row
        try:
            pos = int(xbmc.getInfoLabel("Container(7000).CurrentItem") or 0) - 1
        except ValueError:
            return self._cur_row
        if pos < 0:
            return self._cur_row
        self._sel = pos                         # para repintar tras recargar la skin (restore_after_reload)
        n, row = 0, len(self.rows)
        for t in list(self.shown):
            n += len(self.strip_of(t).lis)
            if pos < n:
                row = self.rows.index(t) if t in self.rows else 0
                break
        self._cur_row = row
        return row

    @staticmethod
    def cache_fresh(path):
        hit = _cache_load().get(flix_rows.cache_key(path))
        return flix_rows.hit_fresh(path, hit, HOME)

    def order(self):
        if self.shown and self.last_touch:          # orden ya mostrado + filas nuevas al final
            return self.shown + [r for r in self.rows if r.strip is not None and r not in self.shown]
        chips = [] if self.section else ["chips"]
        out = chips + (["hero"] if self.hero is not None else [])
        for r in self.rows:
            if r.strip is not None:
                out += [r] + list(getattr(r, "lines", None) or [])     # cuadrícula: sus líneas detrás
        return out

    def strip_of(self, t):
        return self.chips if t == "chips" else self.hero if t == "hero" else t.strip

    def append_or_rebuild(self, row):
        """añade una fila nueva. Rehacer la lista la devuelve arriba del todo, así que si el usuario ya ha
        tocado la pantalla la fila se añade al final aunque no le toque ese orden"""
        # las filas llegan en orden y el hero existe desde el principio: con la lista ya creada, SIEMPRE al final
        # (rehacerla la devolvía arriba mientras el usuario bajaba, en el Inicio y en las secciones)
        if self.shown:
            before = xbmc.getInfoLabel("Container(7000).Position") + "/" + xbmc.getInfoLabel("Container(7000).CurrentItem")
            self.shown = self.shown + [row]
            self.lst.addItems(row.strip.lis)
            log("DIAG añadida fila %s (pos antes %s, después %s/%s)" % (row.label, before,
                xbmc.getInfoLabel("Container(7000).Position"), xbmc.getInfoLabel("Container(7000).CurrentItem")))
        else:
            self.rebuild()

    # ---------- cuadrícula (una sola fila suelta) ----------
    def grid_lines(self, head):
        """reparte head.every en líneas de head.cols detrás de la 1.ª. Las que faltan se añaden al final de la lista
        (la cuadrícula es lo último: sin rehacerla ni mover lo que se ve); si sobran, se rehace (pocas veces: la ruta
        dio menos que antes)"""
        n = head.cols
        chunks = [head.every[i:i + n] for i in range(n, len(head.every), n)]
        new = []
        while len(head.lines) < len(chunks):
            line = Line(head)
            head.lines.append(line)
            new.append(line)
        for line, chunk in zip(head.lines, chunks):
            line.items, line.pos = list(chunk), 0.0
            line.load_new()
            Row.paint(line)
        shrink = len(head.lines) > len(chunks)
        if shrink:
            del head.lines[len(chunks):]
        if head not in self.shown:
            return                          # aún sin lista: la monta rebuild con order() (líneas incluidas)
        if shrink:
            self.rebuild()
        elif new:
            self.shown = self.shown + new
            items = []
            for line in new:
                items += line.strip.lis
            self.lst.addItems(items)
        if new:
            log("cuadrícula %s: %d líneas" % (head.title, len(head.lines) + 1))
        more = [f for f in head.every if flix_rows.is_more(f)][-1:]
        if more and not more[0].get("loading"):
            self.grid_prefetch_start(more[0].get("file") or "")

    def grid_prefetch_start(self, path):
        """la página siguiente, por detrás, en cuanto se ve la cuadrícula (como la TV: al tocar «Ver más» sale al
        momento); una a la vez"""
        if not path or (getattr(self, "grid_pre_path", "") == path and getattr(self, "grid_pre_run", False)):
            return
        if getattr(self, "grid_pre_path", "") == path and getattr(self, "grid_pre", None) is not None:
            return                          # ya está
        self.grid_pre_path, self.grid_pre, self.grid_pre_run = path, None, True
        threading.Thread(target=self.grid_prefetch, args=(path,), daemon=True).start()

    def grid_prefetch(self, path):
        try:
            for _ in range(PRE_ROUNDS):
                if self.stop or getattr(self, "grid_pre_path", "") != path:
                    return
                try:
                    files, _ = flix_rows.fetch(path, force=True, save=False)
                except Exception as e:  # noqa: BLE001
                    log("cuadrícula, precarga: %s" % e)
                    return
                if self.stop or getattr(self, "grid_pre_path", "") != path:
                    return
                self.grid_pre = files
                more = [f for f in files if flix_rows.is_more(f)][:1]
                if not more or more[0].get("file") != path:
                    return              # página entera (su «Ver más» ya es la siguiente, o no hay más)
        finally:
            if getattr(self, "grid_pre_path", "") == path:
                self.grid_pre_run = False

    def grid_load_more(self, f, head):
        """«Ver más» de la cuadrícula: lo precargado al momento; si aún no hay nada, se espera a la precarga (o se pide)"""
        if getattr(self, "grid_busy", False):
            return
        self.grid_busy = True
        with self.lock:
            f["loading"] = True
            head.paint()                    # «Cargando…» en la tarjeta
        threading.Thread(target=self.grid_fetch, args=(head, f.get("file") or ""), daemon=True).start()

    def grid_fetch(self, head, path, wait=25.0, step=0.2):
        try:
            files = None
            if getattr(self, "grid_pre_path", "") == path:
                end = time.time() + wait
                while getattr(self, "grid_pre", None) is None and getattr(self, "grid_pre_run", False) \
                        and time.time() < end and not self.stop:
                    time.sleep(step)
                files = getattr(self, "grid_pre", None)
            if files is None:
                files, _ = flix_rows.fetch(path, force=True, save=False)
            if self.stop:
                return
            self.grid_pre_path, self.grid_pre = "", None        # usada: la próxima, otra
            with self.lock:
                old = [f for f in head.every if not flix_rows.is_more(f)]
                have = {f.get("file") for f in old}
                new = [f for f in files if not flix_rows.is_more(f) and f.get("file") not in have]
                new = new[:max(0, FOLDER_LIMIT - len(old))]
                more = [f for f in files if flix_rows.is_more(f)][:1] if len(old) + len(new) < FOLDER_LIMIT else []
                head.every = old + new + more
                head.items = head.every[:head.cols]
                head.paint()
            log("cuadrícula: +%d (%d en total)%s" % (len(new), len(old) + len(new), "" if more else ", no hay más"))
        except Exception as e:  # noqa: BLE001
            log("cuadrícula, página siguiente: %s" % e)
            with self.lock:
                for f in head.every:
                    f.pop("loading", None)
                head.paint()
        finally:
            self.grid_busy = False

    def sel_pos(self):
        """posición seleccionada en la lista vertical, preguntando a Kodi (-1 si no se sabe). NUNCA
        ControlList.getSelectedPosition: tras recargar la skin (actualización automática) el objeto de Python apunta
        a la lista vieja, ya borrada, y Kodi se cae (SIGSEGV, auditoría 22-oct A-09). Solo con esta ventana activa
        (las secciones táctiles usan el mismo id 7000); si no, la última conocida"""
        wid = getattr(self, "win_id", 0)
        if wid and xbmcgui.getCurrentWindowId() == wid:
            try:
                pos = int(xbmc.getInfoLabel("Container(7000).CurrentItem") or 0) - 1
            except ValueError:
                pos = -1
            if pos >= 0:
                self._sel = pos
                return pos
        return getattr(self, "_sel", -1)

    def insert_before(self, row, other):
        """mete una fila delante de otra ya mostrada sin mover lo que se está viendo (el seleccionado se corre
        tantas posiciones como ocupa la nueva si estaba por debajo). ControlList no tiene insertar: se rehace."""
        pos = self.sel_pos()
        k = self.shown.index(other)
        start = sum(len(self.strip_of(t).lis) for t in self.shown[:k])
        self.shown = self.shown[:k] + [row] + self.shown[k:]
        self.lst.reset()
        items = []
        for t in self.shown:
            items += self.strip_of(t).lis
        self.lst.addItems(items)
        if pos >= 0:
            self.lst.selectItem(min(pos + (len(row.strip.lis) if pos >= start else 0), len(items) - 1))
        log("búsqueda: fila %s delante de %s (pos %d)" % (row.label, other.label, pos))

    def restore_after_reload(self):
        """Kodi recarga la skin (p. ej. al actualizarla) y vuelve a montar esta ventana desde el XML con la lista vacía,
        llamando otra vez a onInit (antes: «Cargando…» hasta reiniciar Kodi). Se repinta EN LA MISMA ventana con los
        mismos elementos (reset/addItems/selectItem van por id). Antes se cerraba y se abría otro Inicio: una tecla en
        ese hueco cerraba Kodi y, con un diálogo delante, el Inicio se perdía (auditoría 22-oct A-03/A-04). Lo que
        cerraba Kodi al re-meter los elementos (19-oct) era getSelectedPosition sobre la lista vieja (A-09)."""
        # Container(7000).NumItems = lo que hay de verdad en pantalla (ControlList.size() es la copia de Python y
        # sigue llena tras la recarga). SOLO "0": al volver de un vídeo onInit llega con la ventana del vídeo aún
        # activa y da "" (no existe ese contenedor ahí); tomarlo por recarga cerraba y relanzaba el Inicio tras CADA
        # vídeo, dos veces -> con varios Atrás, menú de apagado y pantalla negra «Cargando» (móvil, 19-oct)
        if self.shown and xbmc.getInfoLabel("Container(7000).NumItems") == "0":
            with self.lock:
                pos = getattr(self, "_sel", -1)
                items = []
                for t in self.shown:
                    items += self.strip_of(t).lis
                log("ventana montada de nuevo (skin recargada): repinto %d elementos (pos %d)" % (len(items), pos))
                self.lst = self.getControl(7000)
                self.lst.reset()
                self.lst.addItems(items)
                if pos >= 0:
                    self.lst.selectItem(min(pos, len(items) - 1))
            return True
        return False

    def rebuild(self):
        pos = self.sel_pos()
        import traceback
        log("DIAG rebuild (pos %d, filas %d) desde %s" % (pos, len(self.shown), " < ".join(
            "%s:%d" % (f.name, f.lineno) for f in traceback.extract_stack()[-4:-1])))
        self.lst.reset()
        self.shown = self.order()
        items = []
        for t in self.shown:
            items += self.strip_of(t).lis
        self.lst.addItems(items)
        if pos >= 0:
            self.lst.selectItem(min(pos, len(items) - 1))

    # ---------- hero ----------
    def set_hero(self, items, top=False):
        self.hero_items = items
        self.hero_top = top             # ¿de Top 10 películas (5105)? Solo entonces «TOP 10 · N.º k» (TCT-07)
        try:
            flix_age.want(items)        # edad de TMDB de los del hero que falten, en segundo plano (flix_age)
        except Exception as e:  # noqa: BLE001
            log("edad: %s" % e)
        self.paint_hero()

    def check_ages(self):
        """llegaron edades de TMDB (flix_age avisa con Window(home).Property(flix_age_rev)): repinta la cabecera"""
        rev = HOME.getProperty(flix_age.REV)
        if rev != getattr(self, "age_rev", ""):
            self.age_rev = rev
            with self.lock:
                self.paint_hero()

    def paint_hero(self, step=0):
        if not self.hero_items:
            return
        self.hero_i %= len(self.hero_items)
        f = self.hero_items[self.hero_i]
        a = f.get("art") or {}
        h = self.hero
        h.set("fanart", hero_fanart(a.get("fanart") or a.get("landscape") or ""))
        h.set("logo", a.get("clearlogo") or "")
        h.set("title", clean(f.get("label")))
        meta = [str(f["year"])] if f.get("year") else []
        if f.get("runtime"):
            meta.append("%d min" % (int(f["runtime"]) // 60))
        rt = self.rating_of(f.get("file") or "")
        if rt:
            meta.append(rt)
        elif f.get("rating"):
            meta.append("★ %.1f" % float(f["rating"]))
        h.set("meta", "  ·  ".join(meta))
        # círculo de edad recomendada de la TV (flix_age, 7-nov) al principio de la línea de datos
        h.set("age", flix_age.age_of(f.get("file") or ""))
        h.set("genre", " / ".join(f.get("genre") or []))
        # distintivo TOP 10 solo en el Inicio y con el hero sacado de esa fila: con ella oculta sale de la 1.ª fila
        # de carátulas (Seguir viendo…) y decía «N.º 1 en películas hoy» (revisión 29-oct TCT-07)
        top = self.hero_top and not self.section
        h.set("rank", str(self.hero_i + 1) if top else "")
        for k in range(10):
            h.set("dot%d" % k, "" if k >= len(self.hero_items) else ("on" if k == self.hero_i else "off"))


    def rating_of(self, path):
        """nota de Metacritic/IMDb (flix_ratings, clave de MDBList en Ajustes) o '' -> la ★ de TMDB. Si no está
        guardada se pide en un hilo y se repinta la cabecera si sigue en ese título"""
        try:
            import flix_ratings
            rt = flix_ratings.label_for(path)
            if rt or not flix_ratings.wanted(path) or path in self.rating_busy:
                return rt
        except Exception as e:  # noqa: BLE001
            log("nota: %s" % e)
            return ""
        self.rating_busy.add(path)

        def late():
            try:
                if flix_ratings.label_for(path, wait=flix_ratings.TIMEOUT):
                    with self.lock:
                        if self.hero_items and (self.hero_items[self.hero_i % len(self.hero_items)].get("file") == path):
                            self.paint_hero()
            finally:
                self.rating_busy.discard(path)
        threading.Thread(target=late, daemon=True).start()
        return ""

    def hero_step(self, step):
        with self.lock:
            if self.hero_items:
                self.hero_i += step
                self.paint_hero(step)

    def k3_changed(self):
        """ids de las filas cuya lista de Ker0n3 acaba de repasar el servicio del addon (bloque 2:
        Window(home).Property(k3_list_rev_<clave>) cambia cuando lo que la lista enseña es otro). La 1.ª vez solo se
        apunta lo que hay; la clave de cada fila se calcula una vez. Como flix_inicio.k3_bumped"""
        keys = self.__dict__.setdefault("k3keys", {})
        seen = self.__dict__.setdefault("k3seen", {})
        out = []
        for row in list(self.rows):
            if (row.id, row.path) not in keys:
                keys[(row.id, row.path)] = flix_rows.k3_list_key(row.path)
            key = keys[(row.id, row.path)]
            if not key:
                continue
            v = HOME.getProperty("k3_list_rev_" + key) + "|" + HOME.getProperty("k3_list_rev_*")   # «*»: addon actualizado (21-nov)
            if row.id in seen and seen[row.id] != v:
                out.append(str(row.id))
            elif row.id not in seen:
                # 1.ª mirada: aviso anterior (Inicio cerrado o Kodi reiniciado: queda en disco) y fila guardada
                # antes de él → también se vuelve a pedir, una vez
                hit = _cache_load().get(flix_rows.cache_key(row.path))
                if hit and flix_rows.k3_newer(row.path, hit[0], HOME):
                    out.append(str(row.id))
            seen[row.id] = v
        return out

    def refetch_row(self, rid):
        """vuelve a pedir una fila saltándose la caché (p. ej. Series en seguimiento tras dejar de seguir)"""
        for row in list(self.rows):
            if str(row.id) == rid:
                try:
                    files, _ = fetch(row.path, force=True)
                except Exception as e:  # noqa: BLE001
                    log("fila %s: %s" % (row.label, e))
                    return
                with self.lock:
                    row.set_items(files)
                    row.paint()
                log("fila %s recargada (%d)" % (row.label, len(files)))

    def drop_title(self, key):
        """favorito quitado («movie:603» / «tv:1399»): fuera de las filas de favoritos ya pintadas, sin pedir nada; no
        desaparecía hasta salir y volver a entrar (Carlos, 28-oct, como en la TV)"""
        def ref(f):
            r = flix_common.k3_ref(f.get("file")) if isinstance(f, dict) else None
            return "%s:%s" % r if r else ""
        with self.lock:
            for row in self.rows:
                if row.strip is None or not row.items or not flix_rows.FAV_RE.search(row.path or ""):
                    continue
                keep = [f for f in row.items if ref(f) != key]
                if len(keep) != len(row.items):
                    row.set_items(keep)
                    row.paint()
                    log("fila %s: quitado %s (favorito)" % (row.label, key))

    # ---------- algo tocado se está abriendo (TAC-03) ----------
    def mark_opening(self):
        """rueda en FlixHome.xml (fh_opening) y sin atender más toques hasta que la ventana nueva tape (expire_opening)"""
        self.opening_at = time.time()
        HOME.setProperty("fh_opening", str(self.win_id))

    def opening(self):
        """¿hay un toque abriendo algo hace menos de OPEN_GUARD s? Solo cuenta la marca de esta ventana"""
        return bool(self.opening_at) and HOME.getProperty("fh_opening") == str(self.win_id) and \
            time.time() - self.opening_at < OPEN_GUARD

    def clear_opening(self):
        self.opening_at = 0.0
        HOME.clearProperty("fh_opening")

    def expire_opening(self, now=None):
        """hero_timer (1 Hz): la marca propia se quita cuando otra ventana ya tapa, con un diálogo delante (Reanudar,
        selector, pantalla de carga) o a los OPEN_GUARD s si nada llegó. La que pone el XML («1», barra de búsqueda) la
        adopta la ventana activa; la de otra FlixHome (sección encima) no se toca"""
        flag = HOME.getProperty("fh_opening")
        if not flag and not self.opening_at:
            return
        now = time.time() if now is None else now
        mine = str(self.win_id)
        active = xbmcgui.getCurrentWindowId() == self.win_id
        if flag == "1":
            if active:
                self.opening_at = now
                HOME.setProperty("fh_opening", mine)
            return
        if flag != mine:
            self.opening_at = 0.0        # vacía u otra ventana la ha escrito: la propia ya no bloquea
            return
        if not active or now - self.opening_at >= OPEN_GUARD or xbmc.getCondVisibility("System.HasActiveModalDialog"):
            self.clear_opening()

    def hero_timer(self):
        mon = xbmc.Monitor()
        while not mon.abortRequested() and not self.stop:
            mon.waitForAbort(1)
            self.expire_opening()
            if getattr(self, "token", "") and HOME.getProperty("fh_token") != self.token:
                log("hay otro Inicio: este se retira")   # quedó tapado o sin verse y main() abrió otro
                self.stop = True
                self.close()
                return
            if self.section and flix_reload.reloading(HOME):
                # «Recargar skin»: la sección se cierra antes de que Kodi la destruya con el skin viejo (flix_reload)
                self.stop = True
                self.close()
                return
            self.apply_reorder()
            if not self.section and not self.search:
                self.check_wide()
                self.personal_tick()
            if self.hero_items:
                self.check_ages()
            if not self.section:
                flix_common.expire_hide_flags(self.flags)
            if not self.section and not self.search and HOME.getProperty("flix_rnd_prep") == "1":
                HOME.clearProperty("flix_rnd_prep")     # Filas al azar: preparar el siguiente sorteo con NUESTRA
                import flix_random_rows                 # caché (otro proceso la perdería: se guarda entera)
                threading.Thread(target=flix_random_rows.prepare, args=(fetch,), daemon=True).start()
            if HOME.getProperty("fh_progress") == "1":     # menú contextual cerrado: limpiar progreso / vista
                HOME.clearProperty("fh_progress")
                threading.Thread(target=self.sync_progress, daemon=True).start()
            fav = HOME.getProperty("flix_fav_change").split("|")     # flix_k3menu: «hora|del/add|movie:603»
            if len(fav) == 3 and fav[1] == "del" and float(fav[0] or 0) > self.fav_seen:
                self.fav_seen = float(fav[0])
                threading.Thread(target=self.drop_title, args=(fav[2],), daemon=True).start()
            refetch = HOME.getProperty("fh_refetch_row")       # servicio del addon, flix_progress…: ids separados por comas
            if not self.section and not self.search:
                refetch = ",".join([x for x in refetch.split(",") if x] + self.k3_changed())
            if refetch:
                HOME.clearProperty("fh_refetch_row")
                for rid in [x for x in refetch.split(",") if x]:
                    threading.Thread(target=self.refetch_row, args=(rid,), daemon=True).start()
            if self.hero_items and self.g is None and time.time() - self.last_touch > 10 and int(time.time()) % HERO_EVERY == 0 \
                    and xbmc.getCondVisibility("Window.IsActive(%s)" % HOME.getProperty("fh_window")):
                self.hero_step(1)

    def seen_hit(self, sx, sy):
        """¿el toque cae en «Ocultar vistos» (cabecera de Trakt y Favoritos)? Con margen de 16 px alrededor"""
        if not self.section or self.section[0] not in SEEN_VARS:
            return False
        x0 = SKIN_W - SEEN_RIGHT - SEEN_W
        return x0 - 16 <= sx <= SKIN_W - SEEN_RIGHT + 16 and SEEN_TOP - 16 <= sy <= SEEN_TOP + SEEN_H + 16

    def toggle_seen(self, wait=2.0, step=0.05):
        """«Ocultar vistos» / «Vistos ocultos» (Skin.Bool HIDE_SEEN, que lee la ruta del addon): cambia el ajuste, da por
        caducadas las filas de tus listas de Trakt y de favoritos y vuelve a cargar la sección"""
        if self.opening():
            return
        before = xbmc.getCondVisibility("Skin.HasSetting(%s)" % HIDE_SEEN)
        xbmc.executebuiltin("Skin.ToggleSetting(%s)" % HIDE_SEEN)
        end = time.time() + wait
        while time.time() < end and xbmc.getCondVisibility("Skin.HasSetting(%s)" % HIDE_SEEN) == before:
            time.sleep(step)
        log("%s: vistos %s" % (self.section[1], "ocultos" if not before else "a la vista"))
        try:
            flix_rows.expire(re.compile(r"lista/trakt-|favoritos/"))
        except Exception as e:  # noqa: BLE001
            log("filas de Trakt y favoritos: %s" % e)
        threading.Thread(target=self.reload_section, daemon=True).start()

    def after_menu(self, t0, wait=45.0, step=0.3):
        """sección: tras una marca o un cambio en una lista de Trakt desde el menú KER0N3 (PENDING), cuando acaba
        (flix_menu_done) se vuelve a cargar (19-nov, Carlos: una película de Favoritos a la watchlist no salía hasta
        salir y volver a entrar). Como la sección de la TV (flix_section.after_menu)"""
        end = t0 + wait
        while not self.stop and time.time() < end:
            try:
                if float(HOME.getProperty("flix_menu_done") or 0) > t0:
                    break
            except ValueError:
                pass
            time.sleep(step)
        else:
            return
        if not self.stop:
            self.reload_section()

    def reload_section(self):
        """la sección otra vez: si cambió qué filas tiene (la watchlist que aparece, una lista de Trakt vaciada o
        borrada), entera; si no, sus filas pedidas de nuevo sin mover nada"""
        try:
            rows = getattr(self, "fixed", None) or \
                flix_sections.effective_rows(self.section[0], self.rconf, stale_ok=True)
        except Exception as e:  # noqa: BLE001
            log("recargar la sección: %s" % e)
            return
        with self.lock:
            if [r.get("path") for r in rows] != [r.path for r in self.rows]:
                log("sección %s: cambian sus filas, la monto otra vez" % self.section[1])
                self.rows, self.shown = [], []
        self.load_all(refresh=True)

    def personal_tick(self, now=None):
        """cada vuelta de la vigilancia: cuando la base guarda algo visto más reciente (al parar un vídeo, o lo que baja
        de Trakt / Simkl), las filas personales al día. Tras un vídeo es el repaso de siempre (load_all only_progress),
        que onInit dejó pendiente; si la base no guarda nada en AFTER_VIDEO_MAX s, se hace igual"""
        now = time.time() if now is None else now
        changed = False
        try:
            st = self.__dict__.setdefault("pwatch", flix_common.personal_watch())
            changed = flix_common.personal_changed(st, now, xbmc.getCondVisibility("Player.HasVideo"))
        except Exception as e:  # noqa: BLE001
            log("lo visto: %s" % e)
        after = getattr(self, "after_video", None)
        if after is not None and (changed or now - after > AFTER_VIDEO_MAX):
            self.after_video = None
            log("tras el vídeo: repaso el progreso (%s)" % ("ya guardado, %.1f s" % (now - after) if changed
                                                         else "sin esperar más"))
            threading.Thread(target=self.load_all, kwargs={"refresh": True, "only_progress": True}, daemon=True).start()
        elif changed:
            log("la base ha guardado algo visto: recargo Seguir viendo y Series en seguimiento")
            for rid in (WIDE_ROW, FOLLOW_ROW):
                threading.Thread(target=self.refetch_row, args=(str(rid),), daemon=True).start()

    def check_wide(self):
        """llegaron imágenes apaisadas de TMDB (flix_wide_rev): a las tarjetas de «Seguir viendo» ya pintadas"""
        rev = HOME.getProperty("flix_wide_rev")
        for row in self.rows:
            if row.layout == "wide" and row.strip is not None and row.items and row.wide_rev != rev:
                with self.lock:
                    row.fill(row.buf, row.start)          # el juego visible: solo cambian imágenes, sin moverse
                    row._painted[row.other] = None
                break

    # ---------- geometría ----------
    def to_skin(self, x, y):
        return x * SKIN_W / SCR_W, y * SKIN_H / SCR_H

    def strip_at(self, sy):
        """(fila/hero, y dentro de la fila) bajo la coordenada sy (skin), con la lista en reposo"""
        try:
            pos = int(xbmc.getInfoLabel("Container(7000).Position"))
            cur = int(xbmc.getInfoLabel("Container(7000).CurrentItem")) - 1
        except ValueError:
            return None, 0
        y = (sy - HEADER_H) + (cur - pos) * STEP     # y dentro del contenido de la lista
        if y < 0:
            return None, 0
        top = 0
        for t in self.shown:
            h = self.strip_of(t).height
            if y < top + h:
                return t, y - top
            top += h
        return None, 0

    # ---------- acciones ----------
    def onAction(self, action):
        aid = action.getId()
        x, y = action.getAmount1(), action.getAmount2()
        if aid == A_MOVE:
            self.mouse = (x, y)
            return
        if aid in A_BACK:
            if self.section:
                self.stop = True
                self.close()
            else:
                xbmc.executebuiltin("ActivateWindow(shutdownmenu)")
            return
        if aid in A_CONTEXT:
            # el dedo de verdad (101) trae coordenadas; 117 no
            if ctx_after_dialog(HOME.getProperty("flix_dlg_closed"), getattr(self, "last_long", 0), time.time()):
                log("pulsación larga ignorada (tras cerrar un pop-up o repetida)")
                return
            # mantener pulsado: menú KER0N3 de la carátula bajo el dedo
            if x <= 1 and y <= 1:
                stamp = time.time()
                self.ctx_wait = stamp
                threading.Timer(CTX_WAIT, self.ctx_fallback, args=(stamp,)).start()
                return
            self.handle_long(x, y)
            return
        if aid == A_BEGIN:
            self.gesture_begin(x, y)
            return
        if aid == A_PAN:
            self.gesture_move(x, y)
            return
        if aid in (A_END, A_ABORT):
            self.gesture_end()
            return
        if aid in (A_CLICK, A_SWIPE_L, A_SWIPE_R):
            if x <= 1 and y <= 1:        # acción sin coordenadas (pruebas por JSON-RPC): última posición del ratón
                x, y = self.mouse
            sx, sy = self.to_skin(x, y)
            self.last_touch = time.time()
            if xbmc.getCondVisibility("Container(7000).Scrolling"):
                return      # la lista frenando: el dedo la para y nada más; strip_at apuntaría al destino de la inercia
            if sy < HEADER_H:   # y se abría otra fila u otra carátula (revisión 7-nov TAC-02)
                if aid == A_CLICK and self.seen_hit(sx, sy):
                    self.toggle_seen()
                return
            target, ry = self.strip_at(sy)
            if target is None:
                return
            if aid == A_CLICK:
                self.tap(target, sx, ry)
            elif time.time() - getattr(self, "last_hdrag", 0) > 0.6:   # swipe sin arrastre lateral previo
                self.swipe(target, 1 if aid == A_SWIPE_L else -1)
        elif aid == A_SELECT:
            pos, t = self.sel_pos(), None
            for cand in self.shown:
                n = len(self.strip_of(cand).lis)
                if pos < n:
                    t = cand
                    break
                pos -= n
            if t is not None and t != "chips":
                self.open(self.hero_items[self.hero_i] if t == "hero" and self.hero_items else (t.items[int(t.pos)] if t != "hero" and t.items else None),
                          t if t != "hero" else None)

    def onClick(self, control_id):
        pass                             # los toques se resuelven en onAction (con coordenadas)

    # ---------- arrastre lateral continuo ----------
    def gesture_begin(self, x, y):
        self.last_touch = time.time()
        self.press_xy = (x, y)                                # mantener pulsado: dónde empezó el toque
        sx, sy = self.to_skin(x, y)
        target, _ = self.strip_at(sy) if sy >= HEADER_H else (None, 0)
        if isinstance(target, Row):
            self.anim.stop_row(target)                        # el dedo detiene el deslizamiento
        self.g = {"x0": sx, "y0": sy, "t": target, "mode": None, "hist": [(time.time(), sx)],
                  "base": target.pos if isinstance(target, Row) else 0.0}

    def gesture_move(self, x, y):
        g = self.g
        if not g or g["t"] is None:
            return
        sx, sy = self.to_skin(x, y)
        dx, dy = sx - g["x0"], sy - g["y0"]
        if g["mode"] is None:
            if abs(dx) > 20 and abs(dx) > 1.2 * abs(dy):
                g["mode"] = "h"
                g["x0"], dx = sx, 0.0
            elif abs(dy) > 20:
                g["mode"] = "v"
        if g["mode"] != "h":
            return
        now = time.time()
        g["hist"].append((now, sx))
        while len(g["hist"]) > 2 and now - g["hist"][0][0] > 0.12:   # velocidad de los últimos 120 ms
            g["hist"].pop(0)
        self.last_hdrag = now
        t = g["t"]
        if t == "hero":
            g["hero_dx"] = dx
            return
        if not isinstance(t, Row):      # tira de botones («chips») u otra: no se arrastra (AttributeError en el S24, 17-nov)
            return
        self.anim.drag(t, g["base"] - dx / t.itemw)

    def gesture_end(self):
        g, self.g = self.g, None
        if not g or g.get("mode") != "h" or g["t"] is None:
            return
        self.last_hdrag = time.time()
        h = g["hist"]
        v = 0.0
        if len(h) >= 2 and h[-1][0] - h[0][0] > 0.01:
            v = (h[-1][1] - h[0][1]) / (h[-1][0] - h[0][0])      # px/s (skin)
        t = g["t"]
        if t == "hero":
            dx = g.get("hero_dx", 0)
            if abs(dx) > 120 or abs(v) > 600:
                self.hero_step(1 if (dx or v) < 0 else -1)
            return
        if not isinstance(t, Row):
            return
        # inercia: recorre v*0,35 s y frena. Encaje suave (petición de Carlos, 18-oct): solo se recoloca a carátula
        # entera si la del borde queda casi fuera (<20 % o >80 % de una carátula); si no, se queda donde cae.
        # El encaje siempre a la más cercana recolocaba casi en cada gesto y se veía un parpadeo.
        target = max(0.0, min(t.pos - (v * 0.35) / t.itemw, t.max_pos))
        frac = target - int(target)
        if frac < SNAP_EDGE:
            target = float(int(target))
        elif frac > 1 - SNAP_EDGE:
            target = float(int(target) + 1)
        dur = 0.25 + min(0.5, abs(v) / 6000)
        self.anim.glide_to(t, target, dur)

    def swipe(self, target, step):
        if target == "chips":
            return
        if target == "hero":
            self.hero_step(step)
        else:
            self.anim.glide_to(target, round(target.pos) + step * target.visible, 0.45)

    def handle_long(self, x, y):
        self.g = None
        self.last_long = time.time()
        self.long_press(*self.to_skin(x, y))

    def ctx_fallback(self, stamp):
        """no llegó la pulsación con coordenadas (tecla de menú de un teclado o mando): la del último toque"""
        if getattr(self, "ctx_wait", 0) != stamp or getattr(self, "last_long", 0) >= stamp:
            return
        x, y = getattr(self, "press_xy", None) or self.mouse
        self.handle_long(x, y)

    def long_press(self, sx, sy):
        """menú del título bajo el dedo (flix_k3menu); lo de otros orígenes no tiene menú"""
        if sy < HEADER_H:
            return
        target, _ = self.strip_at(sy)
        if target in (None, "chips"):
            log("pulsación larga sin carátula debajo (%.0f, %.0f): %s" % (sx, sy, target))
            return
        if target == "hero":
            row = next((r for r in self.rows if r.id == 5105 and r.items), None) or \
                next((r for r in self.rows if r.kind == "list" and r.items), None)
            f = self.hero_items[self.hero_i % len(self.hero_items)] if self.hero_items else None
        else:
            row = target
            k = row.index_at(sx)
            f = row.items[k] if 0 <= k < len(row.items) else None
        path = (f or {}).get("file", "")
        import flix_k3menu
        if f and flix_k3menu.kind(path) and not flix_rows.is_more(f):
            log("menú de Ker0n3 de %s" % clean(f.get("label")))
            t0 = time.time()
            res = flix_k3menu.menu(path, clean(f.get("label")), poster_of(f), (f.get("art") or {}).get("fanart") or "",
                                   origin=getattr(row, "path", "") or "")
            if res == flix_k3menu.PENDING and self.section and not self.search:
                threading.Thread(target=self.after_menu, args=(t0,), daemon=True).start()
            return
        log("pulsación larga sin menú (%.0f, %.0f): fila %s, título %s" % (sx, sy, getattr(row, "label", None),
                                                                        clean((f or {}).get("label"))))

    def tap(self, target, sx, ry):
        target, ry = self.tap_zone(target, ry)
        # el guard de «ya se está abriendo algo» (opening) solo en lo que abre: sección, título y open(); las flechas
        # laterales ‹ › y pasar de página siguen respondiendo
        if target == "chips":
            cw, cg = CHIP_GEOM
            i = int((sx - LEFT) // (cw + cg))
            lab, key, kind = chip_at(i) if i >= 0 else (None, None, None)
            if lab and (sx - LEFT) - i * (cw + cg) <= cw:
                if self.opening():
                    log("toque ignorado: ya se está abriendo algo")
                    return
                HOME.setProperty("flix_section", lab)
                self.mark_opening()
                if kind == "rows":                      # sección desplegada en filas (se carga al entrar)
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,sec,%s)" % key)
                elif kind == "list":                    # rejilla de carátulas (Trakt, Favoritos…)
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_sections.py,open,%s)" % key)
            return
        if target == "hero":
            if self.hero_items:
                self.open(self.hero_items[self.hero_i % len(self.hero_items)])
            return
        row = target
        if isinstance(row, (GridRow, Line)):
            # cuadrícula: la carátula bajo el dedo (en la 1.ª línea, el título no abre nada: ya se ve todo)
            if isinstance(row, GridRow) and ry < TITLE_TAP:
                return
            k = row.index_at(sx)
            if 0 <= k < len(row.items):
                self.open(row.items[k], row.head if isinstance(row, Line) else row)
            return
        rest = self.rest_of(row)
        if ry < TITLE_TAP and (self.search or rest == ""):   # resultados, o lista de Ker0n3 ya entera en su fila: no hay «ver todo»
            return
        if ry < TITLE_TAP and self.cards_row(row):
            return                          # tarjetas propias: ya están en la fila (o tras su «Más…»)
        if ry < TITLE_TAP:                   # título de la fila = ver todo
            if self.opening():
                log("toque ignorado: ya se está abriendo algo")
            else:
                self.seen_all = row         # al volver, esta fila se pide otra vez (refresh_seen)
                self.mark_opening()
                if row.kind == "coll":      # submenú (sagas, letras…): carpetas, en la rejilla de Kodi
                    HOME.setProperty("flix_section", row.title)
                    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % live(row.path))
                elif rest:
                    # lista de Ker0n3 en el Inicio: solo lo que la fila no enseña (lista/<clave>/resto/<n>)
                    import flix_section
                    HOME.setProperty("flix_similar", json.dumps(flix_section.more_rows(row.title, "", rest, True)))
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,similar)")
                else:
                    # la fila entera como sección de una fila suelta, como «Ver más»: en la rejilla de Kodi el toque en
                    # una carátula reproducía sin ficha (Carlos, 8-nov, fila de Crimen en el móvil)
                    import flix_section
                    HOME.setProperty("flix_similar", json.dumps(flix_section.more_rows(row.title, "", live(row.path),
                                                                                        True)))
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,similar)")
            return
        if row.pos > 0.05 and sx < SIDE_TAP:
            self.swipe(row, -1)
            return
        if row.pos < row.max_pos - 0.05 and sx > SKIN_W - SIDE_TAP:
            self.swipe(row, 1)
            return
        k = row.index_at(sx)
        if 0 <= k < len(row.items):
            self.open(row.items[k], row)

    def tap_zone(self, target, ry):
        """TCT-01: zonas de 48 dp aunque la lista vaya en trozos de 60. Las tarjetas de arriba (2 trozos, 120 px) toman
        los CHIPS_EXTRA px de arriba de lo que tengan debajo, y el título de una fila («ver todo», TITLE_TAP) los
        últimos TITLE_GAP px de la fila de encima: el hueco que queda bajo sus pósters"""
        if target is None or target == "chips" or target not in self.shown:
            return target, ry
        i = self.shown.index(target)
        if ry < CHIPS_EXTRA and i > 0 and self.shown[i - 1] == "chips":
            return "chips", CHIPS_H + ry
        nxt = self.shown[i + 1] if i + 1 < len(self.shown) else None
        if isinstance(target, (GridRow, Line)):
            return target, ry               # cuadrícula: sin títulos debajo que agrandar
        if target != "hero" and nxt not in (None, "hero") and ry >= ROW_H - TITLE_GAP:
            return nxt, ry - ROW_H
        return target, ry

    def open(self, f, row=None):
        if not f:
            return
        if isinstance(row, GridRow) and flix_rows.is_more(f):
            self.grid_load_more(f, row)     # cuadrícula: la página siguiente ahí mismo, sin abrir otra pantalla
            return
        if self.opening():
            log("toque ignorado: ya se está abriendo algo")
            return
        self.mark_opening()
        path = f.get("file", "")
        title = self.section[1] if self.section else row.title if row else ""
        if flix_rows.is_more(f):
            # «Ver más»: la página siguiente como sección de una fila suelta con los clics de siempre (ficha propia),
            # no la cuadrícula de Kodi (Carlos, 7-nov); el mismo camino que «Ver similares»
            import flix_section
            label = row.title if (row is not None and self.section) else ""
            HOME.setProperty("flix_similar", json.dumps(flix_section.more_rows(title, label, path, True)))
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,similar)")
            return
        if row is not None and row.kind == "coll" and path.startswith(flix_common.K3_ROOT):
            # tarjeta propia (saga, género, año: bloques 4 y 5): su lista como sección de una fila, con ficha
            import flix_section
            data = flix_section.more_rows(title, "", path, True)
            data["rows"][0]["label"] = clean(f.get("label"))
            HOME.setProperty("flix_similar", json.dumps(data))
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,similar)")
            return
        if row is not None and row.kind == "coll":
            # submenú de sección (sagas, letras…): su rejilla de carátulas
            HOME.setProperty("flix_section", "%s · %s" % (title, clean(f.get("label"))))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
            return
        a = f.get("art") or {}
        HOME.setProperty("flix_title", clean(f.get("label")))
        HOME.setProperty("flix_poster", poster_of(f))
        HOME.setProperty("flix_fanart", a.get("fanart") or "")
        HOME.setProperty("flix_meta", str(f.get("year") or ""))
        log("abrir %s (%s/%s)" % (clean(f.get("label")), f.get("type"), f.get("filetype")))
        HOME.setProperty("fh_played", "1")
        if f.get("flix_ep"):
            # tarjeta de capítulo a medias de «Seguir viendo»: lo reanuda sin el aviso, como en la TV. En este proceso
            # (22-nov), como la TV desde el 20-nov: sin RunScript, que arrancaba otro intérprete (~0,85 s)
            import flix_series
            flix_series.run(path, ["seguir"])
        elif f.get("type") == "tvshow" or "plugin.video.ker0n3/serie/" in path:      # serie de Ker0n3: su ficha
            import flix_series
            flix_series.run(path)
        elif f.get("filetype") == "directory":
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        else:
            import flix_play
            flix_play.play(path, *flix_play.resume_of(f), title=clean(f.get("label")), fanart=a.get("fanart") or "")


def wait_no_modal(limit=60.0):
    """con un diálogo modal delante (menú de apagado, rueda de carga, un aviso) Kodi rechaza abrir el Inicio
    («Activate of window 13000 refused because there are active modal dialogs») y doModal se queda esperando para
    siempre: se espera a que se cierre (auditoría 22-oct A-04)"""
    end = time.time() + limit
    while xbmc.getCondVisibility("System.HasModalDialog") and time.time() < end:
        xbmc.sleep(200)


def section_open(key, now=None):
    """¿la sección <key> ya está abierta o abriéndose? fh_sec_open = «clave|hora|id de ventana» (0 hasta su onInit): un
    segundo RunScript(flix_home.py,sec,<clave>) (doble toque) apilaba otra FlixHome igual (revisión 7-nov TAC-03)"""
    parts = HOME.getProperty("fh_sec_open").split("|")
    if len(parts) != 3 or parts[0] != key:
        return False
    if parts[2] not in ("", "0"):
        return xbmc.getCondVisibility("Window.IsVisible(%s)" % parts[2])
    try:
        return 0 <= (time.time() if now is None else now) - float(parts[1]) < SEC_OPENING
    except ValueError:
        return False


def already_open():
    """¿hay un Inicio abierto? Lo trae delante. Si la marca está pero la ventana no aparece (destruida, o se quedó
    sin verse), no lo hay: igual que el Inicio de la TV (1.5.44)"""
    if HOME.getProperty("fh_running") != "1":
        return False
    if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
        return True     # recarga con una película en marcha: traer el Inicio delante la cortaba (A-05)
    wid = HOME.getProperty("fh_window")
    if wid:
        xbmc.executebuiltin("ActivateWindow(%s)" % wid)
        for _ in range(20):
            xbmc.sleep(100)
            if str(xbmcgui.getCurrentWindowId()) == wid:
                return True
    log("el Inicio abierto ya no está: abro otro")
    return False


def close_if_unseen(win, wait=6.0):
    """si Kodi no llega a enseñar la ventana (onInit) en unos segundos, se cierra: doModal volvería solo al cerrar Kodi"""
    end = time.time() + wait
    while time.time() < end and not win.inited:
        xbmc.sleep(200)
    if not win.inited:
        log("el Inicio no se ha visto en %d s: lo cierro" % wait)
        win.close()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "search":           # resultados del buscador (flix_search.py táctil)
        win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", search=True,
                       section=("search", HOME.getProperty("flix_search_title")))
        win.doModal()
        win.stop = True
        del win
        return
    if len(sys.argv) > 1 and sys.argv[1] == "similar":          # «Ver similares» (flix_menu.open_similar)
        try:
            data = json.loads(HOME.getProperty("flix_similar") or "{}")
        except ValueError:
            data = {}
        HOME.clearProperty("flix_similar")
        rows = [r for r in data.get("rows") or [] if isinstance(r, dict) and r.get("path")]
        if data.get("cover"):                   # «Títulos de X»: el fondo de la ficha tapaba el Inicio hasta verse esta
            import flix_info
            flix_info.uncover_soon()
        if rows:
            # una sección más (atrás + título), con sus clics: en la cuadrícula de Kodi una película se reproducía sin
            # ficha (Carlos, 31-oct)
            win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", section=("similar", data.get("title") or ""),
                           rows=rows)
            win.doModal()
            win.stop = True
            del win
            if data.get("back") and not flix_reload.reloading(HOME):
                # «Títulos de X» del panel ( i ) (flix_info): Atrás vuelve a la ficha (no si se recarga el skin)
                import flix_info
                flix_info.back_with_cover(data["back"], data.get("cover") or "")
        return
    if len(sys.argv) > 2 and sys.argv[1] == "sec":             # sección: RunScript(flix_home.py,sec,<clave>)
        key = sys.argv[2]
        if section_open(key):
            log("sección %s ya abierta: no apilo otra" % key)
            return
        s = flix_sections.section(key) or flix_sections.section("peliculas")
        HOME.setProperty("fh_sec_open", "%s|%f|0" % (key, time.time()))
        try:
            win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", section=(s["src"], flix_sections.flix_sections_conf.shown(s)),
                           rconf=s.get("rows") or {}, sec_key=key)
            win.doModal()
            win.stop = True
            del win
        finally:
            if HOME.getProperty("fh_sec_open").startswith(key + "|"):
                HOME.clearProperty("fh_sec_open")
        return
    if flix_reload.holding(HOME):
        # el onload de Home al cerrarse este Inicio para recargar: una ventana abierta ahora tiraría Kodi al recargar
        log("recarga del skin en marcha: el Inicio lo abre la recarga")
        return
    flix_common.wait_intro()                # arranque: hasta que acaba la intro (capa sobre Home, flix_boot)
    wait_no_modal()
    if already_open():
        return
    token = "%f" % time.time()
    HOME.setProperty("fh_running", "1")
    HOME.setProperty("fh_token", token)      # un Inicio viejo que siga vivo lo ve y se retira (hero_timer)
    try:
        for _ in range(3):
            win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", token=token)
            threading.Thread(target=close_if_unseen, args=(win,), daemon=True).start()
            win.doModal()
            win.stop = True
            seen = getattr(win, "inited", True)
            del win
            if seen or HOME.getProperty("fh_token") != token:
                break
            log("el Inicio no llegó a verse (diálogo delante): lo vuelvo a abrir")
            wait_no_modal()
    finally:
        if HOME.getProperty("fh_token") == token:
            HOME.clearProperty("fh_running")
            HOME.clearProperty("fh_window")
            HOME.clearProperty("fh_token")


if __name__ == "__main__":
    main()
