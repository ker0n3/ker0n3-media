# -*- coding: utf-8 -*-
"""Ficha de serie en ventana propia (FlixSeries.xml): temporadas a la izquierda y capítulos de la elegida a la derecha.

Por qué una ventana de Python (código de Kodi 21): en la ventana Vídeos, mantener pulsado un capítulo que no era el
seleccionado solo lo seleccionaba. En Android cada toque manda antes GESTURE_NOTIFY a la lista y esta no sigue al dedo;
la pulsación larga (RightClick) solo abre el menú si el elemento ya estaba seleccionado (CGUIBaseContainer::
OnMouseEvent). Aquí onAction recibe la pulsación (101) con las coordenadas del dedo y se abre el menú KER0N3 del
elemento que hay debajo, a la primera (Carlos, 25-oct).

Listas de FlixSeries.xml:
  7976       carpeta de la serie (Window(home).Property(flix_eps_c6)). Con temporadas va apartada: de ella se leen. Con
             capítulos (serie de una temporada) se ve.
  7952       columna de temporadas: en la de TV sus elementos los añade esta ventana (fill_seasons, addItems); en la
             táctil son huecos fijos flix_s<i>_* (FlixSeasonSlots, flix_series.season_props). Las flix_s<i>_* se ponen
             siempre: las leen flix_menu.season_of y flix_series.season_index
  7970-7975  capítulos de las últimas temporadas vistas (flix_series.EpsSlots)
             (todas, además, con los capítulos que aún no tienen versión al final: step_pending, FlixPendingItems)
Fase 1: solo la táctil (flix_series.use_sheet). Spec: docs/superpowers/specs/2026-10-25-ficha-serie-ventana-propia-design.md
"""
import os
import re
import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_screen  # noqa: E402
import flix_series  # noqa: E402

HOME = xbmcgui.Window(10000)
SERIES_SLOT = 6                                        # la 7976 es el «hueco» 6 de las listas de capítulos
SERIES_LIST = flix_series.EPS_FIRST_ID + SERIES_SLOT   # 7976
SEASONS_LIST = flix_series.SEASONS_LIST                # 7952
EPS_FIRST_ID = flix_series.EPS_FIRST_ID                # 7970
# geometría de touch/xml/FlixSeries.xml y de FTEpsCards (Includes_FlixTouch.xml): test_series_sheet_xml.py las compara.
# 21-nov, ficha táctil en tarjetas: las tres listas van en HORIZONTAL (temporadas en botones, capítulos en tarjetas);
# *_ITEM es el ancho de cada elemento y el desplazamiento se mide en x
COL_LEFT, COL_RIGHT, COL_TOP, COL_H, COL_ITEM = 56, 56, 190, 144, 356      # botones de temporada (144 tocables, 96 a la vista)
EPS_LEFT, EPS_TOP, EPS_H, EPS_ITEM = 40, 376, 600, 630                   # tarjetas de la temporada tocada
ONE_LEFT, ONE_TOP, ONE_H, ONE_ITEM = 40, 300, 600, 630                   # tarjetas de una serie de una temporada
A_LONG, A_CTX = 101, 117       # pulsación larga (con coordenadas) / menú contextual (sin ellas)
A_SELECT = 7                   # OK del mando (ACTION_SELECT_ITEM)
LATE_CLICK = 1.0               # s tras parar: un clic aquí es el que lanzó el vídeo, que llega tarde (Kodi corre su clic antes)
EPS_WAIT = "flix_eps_wait"     # Window(home): ficha de serie abierta y aún sin capítulos a la vista (flix_autotrailer)
PREFETCH_DWELL = 1.5           # s con el foco en un capítulo antes de preparar su enlace (step_prefetch)
PREFETCH_GAP = 10.0            # s como poco entre dos precargas de la misma ficha
PREFETCH_MAX = 3               # precargas de enlace como mucho por ficha abierta (Carlos, 22-nov: de 6 a 3, menos peticiones)
K3_EPISODE = re.compile(r"^plugin://plugin\.video\.ker0n3/play/capitulo/(\d+)/(\d+)/(\d+)/?$")
PRESS_MAX = 30                 # s: una pulsación sin selector ni vídeo en este tiempo se da por perdida
A_CLICK = 100                  # toque (con coordenadas del dedo): ACTION_MOUSE_LEFT_CLICK
A_MOVE = 107                   # dedo apoyado (con sus coordenadas): ACTION_MOUSE_MOVE (note_press)
TAP_AGE = 5.0                  # s que un toque en un capítulo vale para la carga que arranca
ORIGIN_AGE = 60.0              # s sin carga ni vídeo tras los que se olvida el capítulo de una carga (next_origin)
A_BACK = flix_common.A_BACK      # códigos de Atrás comunes (TV-28)
CTX_WAIT = 0.35                # s que un 117 sin coordenadas espera al 101 de la misma pulsación (como flix_home)
FOCUS_WAIT = 1.5               # s que open_menu espera a que la lista tenga el foco en el elemento pedido
LONG_REPEAT = 1.5              # s: un 117 justo después de una pulsación ya atendida es su eco
MENU_START = 5.0               # s que se le dan a flix_menu.py para arrancar (flix_menu_run = «s<hora>»)
LOAD_SECS = 30                 # s esperando a que el addon dé la serie (dos intentos)
MODE_PEEK = 3                  # elementos de la carpeta que se miran para saber qué dio
# temporada (…/serie/<tmdb>/<T>) o capítulo (…/play/capitulo/…) del addon, por su ruta
SEASON_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/serie/\d+/\d+")
EPISODE_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/play/capitulo/")
EP_SE_RE = re.compile(r"/play/capitulo/\d+/(\d+)/(\d+)/?$")    # temporada y capítulo de TMDB de la ruta
PLAY_STEP = 1.0                # s por vuelta del bucle con un vídeo en marcha: solo hay que notar la parada (PY-05)
SEASONS_EVERY = 3.0            # s entre firmas de las temporadas en reposo (window_seasons: 40 × 9 getInfoLabel)
SEASONS_FAST = 1.0             # … los FAST_SECS siguientes a un vídeo o al menú: la carpeta recargada llega en 1-3 s
FAST_SECS = 10


def log(msg):
    xbmc.log("[flix_series_sheet] %s" % msg, xbmc.LOGINFO)


def ival(v, default=-1):
    return int(v) if str(v or "").isdigit() else default


def index_at(rel, item, cur, pos, n):
    """índice (0..n-1) del elemento a rel píxeles del principio de la lista (borde izquierdo en horizontal, de arriba en
    vertical), o None. cur = Container(id).CurrentItem (1..n) y pos = Container(id).Position (hueco en pantalla, desde
    0): la parte a la vista empieza en cur-1-pos"""
    if rel < 0 or n < 1 or cur < 1 or pos < 0:
        return None
    i = cur - 1 - pos + int(rel // item)
    return i if 0 <= i < n else None


def list_at(sx, sy, skin_w, mode):
    """(lista, x desde su borde izquierdo, ancho de elemento) bajo el punto sx, sy (skin), o None. «eps» = la lista de
    capítulos a la vista (cuál, lo dice flix_eps_slot). Las listas son horizontales (ficha táctil en tarjetas)"""
    if mode == "one":
        if sx >= ONE_LEFT and ONE_TOP <= sy < ONE_TOP + ONE_H:
            return SERIES_LIST, sx - ONE_LEFT, ONE_ITEM
        return None
    if mode != "seasons":
        return None
    if COL_LEFT <= sx <= skin_w - COL_RIGHT and COL_TOP <= sy < COL_TOP + COL_H:
        return SEASONS_LIST, sx - COL_LEFT, COL_ITEM
    if sx >= EPS_LEFT and EPS_TOP <= sy < EPS_TOP + EPS_H:
        return "eps", sx - EPS_LEFT, EPS_ITEM
    return None


def route_content(path):
    """«content» de la ruta de un elemento: 'seasons' en una temporada, 'episodes' en un capítulo, '' si no se sabe"""
    path = str(path or "")
    return "seasons" if SEASON_RE.match(path) else "episodes" if EPISODE_RE.match(path) else ""


def mode_of(n, items):
    """qué dio la carpeta de la serie: '' (aún nada), 'one' (capítulos: serie de una temporada) o 'seasons'.
    items = [(DBType, content de la ruta, Episode), ...] de los primeros elementos (MODE_PEEK). Manda el tipo del
    elemento (o su ruta): que las temporadas vengan sin número de capítulo no está garantizado y una serie de varias
    temporadas se abría como de una (revisión final, 25-oct). Sin tipo en ninguno: con número de capítulo en el 1.º,
    capítulos"""
    if n < 1:
        return ""
    if any(d == "season" or c == "seasons" for d, c, _ in items):
        return "seasons"
    if any(d == "episode" or c == "episodes" for d, c, _ in items):
        return "one"
    return "one" if items and str(items[0][2]).isdigit() else "seasons"


def menu_busy(run, now):
    """¿hay un menú KER0N3 en marcha? run = Window(home).Property(flix_menu_run): «1» = flix_menu.py corriendo,
    «s<hora>» = esta ventana lo acaba de lanzar y aún no ha arrancado (si no arranca, a los MENU_START s se olvida)"""
    if run == "1":
        return True
    try:
        return run.startswith("s") and now - float(run[1:]) < MENU_START
    except ValueError:
        return False


def ctx_skip(coords, last_long, now, busy):
    """¿no atender esta acción de menú? Con un menú en marcha (flix_menu manda sus Action(ContextMenu) por detrás) o un
    117 sin coordenadas justo después de una pulsación ya atendida: Kodi lo manda además del 101 cuando el elemento ya
    estaba seleccionado (PyWindowXML: RightClick en una lista)"""
    if busy:
        return True
    return not coords and bool(last_long) and now - last_long < LONG_REPEAT


def tap_source(tap, now):
    """(lista, posición, ruta) del capítulo tocado si el toque es reciente, o None. Banco 25-oct: al volver del vídeo
    Kodi deja la ficha sin foco; al tocar un capítulo la lista lo tiene una fracción de segundo antes de que salga el
    selector de enlaces, y el sondeo (0,15 s) nunca lo ve: el capítulo se sabe por el toque, no por el foco"""
    return (tap[0], tap[1], tap[2]) if tap and now - tap[3] <= TAP_AGE else None



def latest_source(tap, press, now):
    """el más reciente de los dos que sigan valiendo (tap_source): el toque (100) o el dedo apoyado (107). Si una carga
    se cancela, el 100 de su toque llega al final (Kodi lo entrega tras la carga) y queda vigente unos segundos: si en ese
    rato se toca otro capítulo, manda el dedo apoyado, que es más nuevo (con «toque primero» ganaba el de antes)"""
    cands = [x for x in (tap, press) if tap_source(x, now)]
    return tap_source(max(cands, key=lambda x: x[3]), now) if cands else None

def next_origin(current, new, now, last_busy):
    """capítulo (lista, posición) desde el que se lanzó lo que se está cargando, al EMPEZAR una carga. new = el de
    esta carga (toque, dedo apoyado o foco) o None. Banco 25-oct: con varios enlaces que fallan, el reproductor
    reintenta con más de 3 s entre diálogos; cada relevo se tomaba por una carga nueva, ya sin toque (se
    gastó en la primera), y dejaba el origen en None: tras el vídeo el foco no volvía al capítulo. Sin uno nuevo se
    conserva el anterior, salvo que lleve más de ORIGIN_AGE s sin carga ni vídeo (last_busy): una carga cancelada no
    se atribuye a un vídeo que empiece mucho después"""
    if new is not None:
        return new
    return current if now - last_busy <= ORIGIN_AGE else None


def signature(items):
    """lo que cambia en las temporadas al marcar o ver algo (flix_series.window_seasons)"""
    return [(x["pct"], x["path"], x["total"], x.get("seen")) for x in items]


def press_origin(mark):
    """(lista, posición) de la marca de pulsación («7970|6|2x6», el <onclick> de la lista), o None si vino de un botón"""
    parts = (mark or "").split("|")
    if len(parts) < 2 or not parts[0].isdigit() or not parts[1].isdigit() or int(parts[1]) < 1:
        return None
    return parts[0], parts[1]


SEASONS_AHEAD = 2       # temporadas vecinas pedidas por adelantado al abrir la ficha (prefetch_seasons): la siguiente y la anterior (Carlos, 22-nov: pocas peticiones)
_K3_SEASON_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/serie/(\d+)/(\d+)")


def prefetch_order(items, idx, limit=SEASONS_AHEAD):
    """[(tmdb, temporada)] de las temporadas de Ker0n3 de la columna, de la más cercana a la abierta (idx) a la más
    lejana, sin la abierta (ya se pide) ni las partes (temporada >= 1000: otra ruta); como mucho `limit`"""
    found = []
    for i, it in enumerate(items):
        m = _K3_SEASON_RE.match(str((it or {}).get("path") or ""))
        if m and i != idx and int(m.group(2)) < 1000:
            found.append((abs(i - idx), i > idx, (int(m.group(1)), int(m.group(2)))))
    found.sort(key=lambda x: (x[0], not x[1]))      # a igual distancia, la siguiente antes que la anterior
    return [x[2] for x in found[:limit]]


def focus_back_due(since_stop, acted):
    """¿devolver el foco al capítulo tras parar? Kodi lo manda a las temporadas al recargar las listas. Solo si el usuario
    no ha hecho nada en la ficha desde que paró (onAction: sin el contador de inactividad, que no ve los toques)"""
    return not acted and since_stop < flix_series.BACK_PLAY_SECS


def pending_item(row):
    """ListItem de un capítulo que aún no tiene versión (flix_series.pending_rows): etiqueta, miniatura, sinopsis y la
    frase en flix_pending. Sin Episode en el InfoTag: episodes_of lo tomaría por uno de la lista"""
    li = xbmcgui.ListItem(label=row["label"])
    li.setProperty(flix_series.PENDING, row["pending"])
    li.setProperty("plot", row.get("plot") or "")       # FlixEpisodeCard lo lee así en los pendientes
    if row.get("thumb"):
        li.setArt({"thumb": row["thumb"]})
    if row.get("plot"):
        try:
            li.getVideoInfoTag().setPlot(row["plot"])
        except (AttributeError, RuntimeError):
            pass
    return li


CLICK_PLAY_SECS = 90     # s entre pulsar un capítulo y que empiece su vídeo para volver a él al parar (buscar versión + caché)
EP_PROPS = ["title", "season", "episode", "plot", "runtime", "firstaired", "rating", "playcount", "resume", "art"]


def episode_items(path):
    """[ListItem] de los capítulos de la temporada (ruta …/serie/<tmdb>/<T> del addon), calculados en este proceso con
    el código del addon (handlers.episodes_for_skin: lo mismo que su carpeta, sin arrancar su intérprete). Con un addon
    sin esa función, su carpeta por JSON-RPC (episodes_rpc). Excepción si no se puede (quien llama reintenta)"""
    m = re.search(r"/serie/(\d+)/(\d+)", path or "")
    if not m:
        return []
    try:
        from ker0n3 import handlers
        fn = handlers.episodes_for_skin
    except (ImportError, AttributeError):
        return episodes_rpc(path)
    return [li for _url, li in fn(m.group(1), int(m.group(2)))]


def episodes_rpc(path):
    """respaldo de episode_items: la carpeta del addon por JSON-RPC, en ListItem (sin las propiedades propias del
    addon: fecha a la española y píldora de número salen vacías)"""
    out = []
    for f in flix_series.list_dir(path, EP_PROPS) or []:
        li = xbmcgui.ListItem(f.get("label") or "", path=f.get("file") or "")
        t = li.getVideoInfoTag()
        t.setMediaType("episode")
        t.setTitle(f.get("title") or "")
        t.setSeason(int(f.get("season") or 0))
        t.setEpisode(int(f.get("episode") or 0))
        t.setPlot(f.get("plot") or "")
        t.setDuration(int(f.get("runtime") or 0))
        t.setPremiered(f.get("firstaired") or "")
        r = f.get("resume") or {}
        if r.get("position"):
            t.setResumePoint(float(r["position"]), float(r.get("total") or 0))
        elif f.get("playcount"):
            t.setPlaycount(int(f["playcount"]))
        li.setArt(f.get("art") or {})
        li.setProperty("IsPlayable", "true")
        li.setProperty("flix_aired", f.get("firstaired") or "")
        out.append(li)
    return out


VER_BTN = 5250


def in_background(fn, *args):
    """fn(*args) en un hilo (no daemon: si la ficha se cierra mientras busca la versión, el vídeo sigue arrancando como
    con el RunScript de antes). Lo que antes iba en otro intérprete; el clic de la ventana no espera"""
    def run():
        try:
            fn(*args)
        except Exception:  # noqa: BLE001
            import traceback
            xbmc.log("[flix_series_sheet] %s: %s" % (getattr(fn, "__name__", fn), traceback.format_exc()), xbmc.LOGERROR)
    threading.Thread(target=run).start()


def clock(secs):
    """«1:02:03» / «12:34» (flix_play.resume_focused lee así el tiempo del botón de Kodi)"""
    secs = int(secs)
    h, m, sec = secs // 3600, secs // 60 % 60, secs % 60
    return "%d:%02d:%02d" % (h, m, sec) if h else "%d:%02d" % (m, sec)


class SeriesSheet(xbmcgui.WindowXML):
    local, local_raw, seasons_dirty = False, None, False     # pruebas que crean la ventana sin __init__

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.folder = kwargs.get("folder", "")
        self.res = None                  # flix_screen.skin_res() (onInit)
        # 22-nov: temporadas (flix_series.local_seasons) y capítulos calculados en ESTE proceso. Las listas 7970-7975 ya
        # no tienen <content>: las rellena siempre la ficha (fill_slot). Las temporadas, sin las de este proceso (error):
        # la carpeta 7976 como antes (local False)
        self.local_raw = kwargs.get("seasons") or None
        self.local = bool(self.local_raw)
        self.local_state()
        self.mode = ""                   # '' cargando, 'seasons' o 'one' (mode_of)
        self.last_long = 0.0             # última pulsación larga atendida
        self.ctx_wait = 0.0              # 117 sin coordenadas esperando a su 101
        self.started = self.stop = self.closing = False
        self.win_id = 0                  # id de esta ventana (Python: 13000+)
        self.slots = flix_series.EpsSlots()
        self.tap = None                  # (lista, posición, ruta, hora) del último capítulo tocado (onAction)
        self.press = None                # lo mismo del capítulo bajo el dedo al apoyarlo (note_press)
        self.sig, self.sig_at, self.noted = [], 0.0, set()
        self.auto = None                 # tráiler automático (flix_autotrailer.AutoTrailer), se crea en onInit
        # capítulos que aún no tienen versión (flix_series.pending_rows): TMDB por temporada («tmdb/temporada» ->
        # capítulos, None = sin datos), consultas en marcha y para qué (lista, clave, totales válidos) están puestos
        self.pend, self.pend_busy, self.pend_shown = {}, set(), None

    # ---------- ciclo de vida ----------
    def onInit(self):
        # vuelta desde «Títulos de X» (flix_info): el fondo que tapaba el Inicio se quita cuando ya se ve la ficha
        if HOME.getProperty(flix_common.INFO_COVER):
            flix_common.later(0.5, HOME.clearProperty, flix_common.INFO_COVER)   # daemon: no retiene el intérprete (PY-21)
        # también al volver de un vídeo: no se vuelve a cargar nada
        if self.res is None:
            self.res = flix_screen.skin_res()
        wid = xbmcgui.getCurrentWindowId()
        if wid >= 13000:
            self.win_id = wid
        HOME.setProperty("flix_sheet", "1")
        if not self.started:
            self.started = True
            import flix_autotrailer         # tráiler automático: la URL la busca flix_series.find_trailer
            self.auto = flix_autotrailer.AutoTrailer(self, lambda: HOME.getProperty("flix_series_trailer"))
            self.auto.start()               # antes del hilo: si run() falla, leave() ya lo encuentra
            import flix_more                # lo de abajo: reparto, similares y detalles (21-nov)
            self.more = flix_more.More(self, "tv", HOME.getProperty("flix_series_tmdb"),
                                       HOME.getProperty("flix_series_path"), HOME.getProperty("flix_open_fanart"),
                                       HOME.getProperty("flix_series_title"))
            self.more.start()
            threading.Thread(target=self.run, daemon=True).start()

    def stop_auto(self):
        # getattr: hay pruebas que crean la ventana sin __init__
        auto = getattr(self, "auto", None)
        if auto is not None:
            auto.stop()

    def is_active(self):
        return not self.win_id or xbmc.getCondVisibility("Window.IsActive(%d)" % self.win_id)

    def leave(self):
        if self.closing:
            return
        self.closing, self.stop = True, True
        HOME.clearProperty(EPS_WAIT)
        self.stop_auto()
        more = getattr(self, "more", None)
        if more is not None:
            more.stop()
        self.close()

    def up_id(self):
        """adónde sube Atrás desde lo de abajo: los capítulos a la vista (o la serie de una temporada)"""
        if self.mode == "one":
            return SERIES_LIST
        eid = HOME.getProperty("flix_eps_id")
        return int(eid) if eid.isdigit() else SEASONS_LIST

    def onFocus(self, control_id):
        more = getattr(self, "more", None)
        if more is not None and more.focus(control_id):
            self.stop_auto()

    # ---------- columna de temporadas ----------
    def seasons_control(self):
        """la lista 7952 cuando la pinta esta ventana (FlixSeries.xml de TV, lista sin <content>); None en la táctil
        (huecos fijos FlixSeasonSlots). Se decide por la skin, no por una propiedad del <onload>: SetProperty sin
        ventana va a la que tiene el foco, y en la Shield al abrir la serie es la rueda (DialogBusy) → la columna se
        quedaba vacía, sin temporadas ni capítulos (Carlos, 7-nov, 1.7.5)"""
        try:
            if xbmc.getSkinDir().endswith(".touch"):
                return None
            return self.getControl(SEASONS_LIST)
        except (AttributeError, RuntimeError):     # pruebas que crean la ventana sin __init__; lista sin control
            return None

    def fill_seasons(self, items):
        """temporadas a la columna: flix_s<i>_* en Window(home) siempre (flix_menu.season_of, season_index) y, en la
        de TV, sus elementos: con las mismas temporadas se cambian etiqueta y propiedades en su sitio (el foco y el
        desplazamiento no se mueven: ✓ nuevo tras el menú o un vídeo); con otro número se rehace conservando la
        posición. Antes eran 40 huecos fijos × 7 propiedades evaluadas por fotograma (revisión 7-nov XML-06)"""
        flix_series.fill_seasons(items)
        ctl = self.seasons_control()
        if ctl is None:
            return
        rows = [flix_series.season_row(it) for it in items[:flix_series.MAX_SEASONS]]
        if rows and len(rows) == ctl.size():
            for i, row in enumerate(rows):
                li = ctl.getListItem(i)
                li.setLabel(row["title"])
                for k in flix_series.SEASON_FIELDS[1:]:
                    li.setProperty(k, row[k])
            return
        pos = -1
        if ctl.size():
            pos = ctl.getSelectedPosition()
            ctl.reset()
        lis = []
        for row in rows:
            li = xbmcgui.ListItem(label=row["title"])
            for k in flix_series.SEASON_FIELDS[1:]:
                li.setProperty(k, row[k])
            lis.append(li)
        ctl.addItems(lis)
        if 0 <= pos < len(lis):
            ctl.selectItem(pos)

    # ---------- bucle de la ficha (hilo): lo de flix_series.watch_seasons sin la ventana Vídeos ----------
    def run(self):
        mon = xbmc.Monitor()
        try:
            if self.load(mon):
                self.start_mode()
                self.loop(mon)
        except Exception:  # noqa: BLE001
            import traceback
            # si el hilo muere con la ficha abierta se queda muda (sin cambio de temporada ni ✓): se registra como
            # error y se sale de ella para que Carlos vuelva a donde estaba
            xbmc.log("[flix_series_sheet] bucle: %s" % traceback.format_exc(), xbmc.LOGERROR)
            self.leave()
        log("fin de la ficha")

    def load(self, mon):
        """espera a que el addon dé la carpeta de la serie en la lista 7976 (reintenta una vez) y fija el modo. Con las
        temporadas ya calculadas en este proceso (local), sin esperar nada"""
        if self.local:
            self.mode = "seasons"
            self.setProperty("mode", "seasons")
            log("serie en este proceso: %d temporadas" % len(self.local_raw))
            return True
        for attempt in (1, 2):
            end = time.time() + LOAD_SECS
            while time.time() < end:
                if self.stop or mon.waitForAbort(0.15):
                    return False
                n = ival(xbmc.getInfoLabel("Container(%d).NumItems" % SERIES_LIST), 0)
                items = [self.peek(i) for i in range(min(n, MODE_PEEK))]
                mode = mode_of(n, items)
                if mode:
                    self.mode = mode
                    self.setProperty("mode", mode)
                    log("serie cargada: %s (%d elementos; 1.º: dbtype=%s content=%s)" % (mode, n, items[0][0],
                                                                                     items[0][1]))
                    return True
            log("Ker0n3 no dio la serie (intento %d)" % attempt)
            if attempt == 1:
                self.reload_series()                    # solo entre intentos: tras el último sería una petición inútil
        xbmcgui.Dialog().notification(HOME.getProperty("flix_series_title") or "Serie",
                                      flix_common.K3_NO_ANSWER_RETRY, xbmcgui.NOTIFICATION_INFO, 5000)
        self.leave()
        return False

    def peek(self, i):
        """(DBType, content de la ruta, Episode) del elemento i de la carpeta de la serie (mode_of)"""
        g = lambda k: xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).%s" % (SERIES_LIST, i, k))  # noqa: E731
        return g("DBType").lower(), route_content(g("FileNameAndPath")), g("Episode")

    def start_mode(self):
        if self.mode == "one":
            # la propia 7976 es la lista de capítulos (hueco 6): flix_menu y refresh_eps_in_place la encuentran así
            flix_series.apply({"flix_eps_slot": str(SERIES_SLOT), "flix_eps_id": str(SERIES_LIST),
                               "flix_eps_loading": "", "flix_eps_failed": ""})
            self.setProperty("loaded", "1")
            HOME.clearProperty(EPS_WAIT)                # capítulos a la vista: el tráiler automático ya puede pedirse
            xbmc.executebuiltin("SetFocus(%d)" % SERIES_LIST)
            return
        self.start_seasons(self.season_rows() if self.local else flix_series.window_seasons(SERIES_LIST))

    def start_seasons(self, items):
        """la columna con esas temporadas y los capítulos de la que toca (el capítulo que toca ya es exacto:
        flix_series.k3_state). Devuelve la ruta de esa temporada (None sin temporadas)"""
        self.fill_seasons(items)
        self.sig, self.sig_at = signature(items), time.time()
        self.setProperty("loaded", "1")
        if not items:
            return None
        nxt = HOME.getProperty("flix_series_next")
        idx = flix_series.season_index(items, nxt or HOME.getProperty("flix_series_upto"),
                                       HOME.getProperty("flix_series_part"))
        end = time.time() + 2                           # los huecos se ven un fotograma después de rellenarlos
        while time.time() < end and xbmc.getInfoLabel("Container(%d).NumItems" % SEASONS_LIST) != str(len(items)):
            xbmc.sleep(50)
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (SEASONS_LIST, idx))
        self.apply_slots(self.slots.step(items[idx]["path"], time.time(), flix_series.eps_count, first=True))
        log("%d temporadas; capítulos de la %d.ª" % (len(items), idx + 1))
        self.prefetch_seasons(items, idx)
        return items[idx]["path"]

    def prefetch_seasons(self, items, idx):
        """las temporadas vecinas a TMDB por detrás (22-nov, usuarios: «paso a las siguientes y no las carga» / «tarda
        en responder»): pedida por 1.ª vez, una temporada tardaba 3-4 s en la Shield (casi todo, TMDB) y el doble en
        un Fire TV; ya guardada, 1 s. Solo TMDB (ni fuentes ni PeLis), de una en una y las más cercanas primero"""
        seasons = prefetch_order(items, idx)
        if not seasons:
            return
        threading.Thread(target=self._prefetch, args=(seasons,), daemon=True).start()

    def _prefetch(self, seasons):
        try:
            from ker0n3 import catalog
            n = 0
            for tmdb, season in seasons:
                if self.stop or flix_common.quitting():
                    break
                try:
                    if catalog.season_cached(tmdb, season) is None:
                        catalog.season_all(tmdb, season)
                        n += 1
                except Exception as e:  # noqa: BLE001  (sin red: ya se pedirá al enfocarla)
                    log("temporada %s T%s por adelantado: %s" % (tmdb, season, type(e).__name__))
                    break
            if n:
                catalog.flush_default()     # al disco: la ruta del addon (otro proceso) la lee de ahí
                log("%d temporadas pedidas por adelantado" % n)
        except Exception as e:  # noqa: BLE001
            log("temporadas por adelantado: %s" % type(e).__name__)

    def eps_ids(self):
        return {str(SERIES_LIST)} if self.mode == "one" else flix_series.EPS_IDS

    def reload_series(self):
        if self.local:
            fresh = flix_series.local_seasons(HOME.getProperty("flix_series_tmdb"))    # y el estado k3_serie_<tmdb>
            if fresh:
                self.local_raw = fresh
            self.seasons_dirty = True
            return
        self.reload_series_folder()

    # ---------- capítulos en este proceso (22-nov) ----------
    def season_rows(self):
        """las temporadas para la columna, de local_raw (flix_series.local_seasons) con lo visto de la base: lo mismo
        que window_seasons leía de la carpeta 7976"""
        out, tmdb = [], ""
        for f in self.local_raw or []:
            genre = f.get("genre") or []
            it, t = flix_series.season_item(f.get("label") or "", str(f.get("season", "")),
                                            str(f.get("episodes") or ""), str(f.get("year") or ""), "0",
                                            f.get("file") or "", f.get("plot") or "",
                                            " / ".join(genre) if isinstance(genre, list) else str(genre))
            tmdb = tmdb or t
            out.append(it)
        seen = flix_series.seasons_seen(tmdb) if out else None
        for it in out:
            it["seen"] = None if seen is None else seen.get(it["season"], 0)
        return out

    def local_state(self):
        """huecos cargándose, pendientes y capítulos por hueco (también si la ventana se creó sin __init__)"""
        if "filling" not in self.__dict__:
            self.filling, self.pend_rows, self.eps_items = set(), {}, {}

    def slot_updating(self, k):
        """¿la lista k está cargándose? (EpsSlots: no se vuelve a pedir mientras)"""
        self.local_state()
        return k in self.filling

    def apply_slots(self, out):
        """los cambios de EpsSlots. Las rutas flix_eps_c<k> ya no las carga Kodi (sin <content>): vaciar = la lista sin
        nada; ruta = rellenarla aquí (fill_slot, en un hilo). En Window(home) se queda la ruta sin &reload= (la leen
        pending_list y flix_menu)"""
        rest = {}
        for key, v in out.items():
            m = re.match(r"flix_eps_c(\d+)$", key)
            if not m or int(m.group(1)) == SERIES_SLOT:
                rest[key] = v
            elif not v or v == flix_series.EMPTY_EPS:
                rest[key] = v
                self.clear_slot(int(m.group(1)))
            else:
                rest[key] = re.sub(r"&reload=\d+$", "", v)
                self.fill_slot(int(m.group(1)), rest[key])
        flix_series.apply(rest)

    def clear_slot(self, k):
        self.local_state()
        self.pend_rows.pop(k, None)
        self.eps_items.pop(k, None)
        try:
            self.getControl(EPS_FIRST_ID + k).reset()
        except (RuntimeError, TypeError, AttributeError):
            pass

    def fill_slot(self, k, path, keep=False):
        """los capítulos de la temporada `path` en la lista k, calculados en este proceso. keep: en su sitio (✓ al día
        tras un vídeo, el menú o un cambio en la base), sin vaciarla antes y con el mismo capítulo seleccionado"""
        self.local_state()
        if k in self.filling and not keep:
            return                  # ya se está pidiendo (el empujón de EpsSlots no duplica el trabajo)
        self.filling.add(k)
        threading.Thread(target=self._fill, args=(k, path, keep), daemon=True).start()

    def _fill(self, k, path, keep):
        t0 = time.time()
        items = None
        try:
            items = episode_items(path)
        except Exception as e:  # noqa: BLE001  (sin red y sin guardar, etc.: sin capítulos; EpsSlots lo reintenta)
            log("capítulos de %s: %r" % (path[-20:], e))
        try:
            if self.stop or items is None or self.slots.paths[k] != flix_series.season_key(path):
                return              # la ficha se cerró o el hueco ya es de otra temporada
            self.eps_items[k] = items
            rows = self.pend_rows.get(k) or []
            self.set_items(EPS_FIRST_ID + k, items + [pending_item(r) for r in rows], keep)
            log("capítulos de %s en este proceso: %d en %d ms" % (path[-14:], len(items), (time.time() - t0) * 1000))
        finally:
            self.filling.discard(k)

    def set_items(self, cid, items, keep):
        """reset + addItems de la lista cid; keep: vuelve al elemento que estaba seleccionado"""
        try:
            lst = self.getControl(cid)
            pos = lst.getSelectedPosition() if keep else -1
            lst.reset()
            lst.addItems(items)
            if keep and 0 <= pos < len(items):
                lst.selectItem(pos)
        except (RuntimeError, TypeError, AttributeError) as e:
            log("lista %d sin pintar: %s" % (cid, e))

    def refill_active(self):
        """la temporada a la vista otra vez en su sitio (✓ y barras al día); las demás se piden al enfocarlas"""
        k = self.slots.active
        if self.mode != "seasons" or k is None or not self.slots.paths[k]:
            return
        self.slots.stale_except(k)
        self.fill_slot(k, self.slots.paths[k], keep=True)

    def reload_series_folder(self):
        """la carpeta de la serie otra vez (misma ruta + &reload=): ✓ y «En progreso» de las temporadas"""
        base = re.sub(r"&reload=\d+$", "", HOME.getProperty("flix_eps_c%d" % SERIES_SLOT))
        if base:        # el router del addon quita el «&reload=…» (router.parse)
            HOME.setProperty("flix_eps_c%d" % SERIES_SLOT, "%s&reload=%d" % (base, int(time.time() * 1000)))

    def place_next(self, cid, key, nums, ses=None):
        """la lista de capítulos de la temporada del capítulo que toca («Seguir viendo · T2 E5») arranca en ESE capítulo
        y no en el primero (revisión de diseño 13-nov: como Netflix, Disney+ o Prime). Una sola vez por temporada y
        ficha, recién llegados sus capítulos, solo si la lista sigue en el primero y el foco no está ya en ella (no se
        le mueve a nadie de donde está). Sin llamadas: los números ya se han leído de la lista (nums). key: «tmdb/temporada».
        Serie por partes (flix_series_part): la parte y el capítulo de TMDB (flix_series_next_se) entre los de la
        lista (ses: [(T, C)] de sus rutas)"""
        placed = self.__dict__.setdefault("placed", set())
        if key in placed:
            return
        placed.add(key)
        part = HOME.getProperty("flix_series_part")
        if part:
            want = tuple(int(x) for x in HOME.getProperty("flix_series_next_se").split("/") if x.isdigit())
            if len(want) != 2 or not str(key).endswith("/%s" % part) or want not in (ses or []):
                return
            idx = ses.index(want)
            nums = ses
            m = re.match(r"T(\d+) E(\d+)$", HOME.getProperty("flix_series_next"))
        else:
            m = re.match(r"T(\d+) E(\d+)$", HOME.getProperty("flix_series_next"))
            if not m or not str(key).endswith("/%s" % m.group(1)) or int(m.group(2)) not in nums:
                return
            idx = nums.index(int(m.group(2)))
        # si algún elemento no trae número de capítulo, la posición en nums no es la de la lista: no se toca
        if idx < 1 or xbmc.getInfoLabel("Container(%d).NumItems" % cid) != str(len(nums)) or \
                xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) != "1" or \
                xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
            return
        xbmc.executebuiltin("Control.Move(%d,%d)" % (cid, idx))
        log("capítulos de T%s: la lista arranca en el E%s" % (m.group(1), m.group(2)) if m else
            "capítulos de la parte %s: la lista arranca en el %d.º" % (part, idx + 1))

    def after_stop(self, play_from):
        """tras parar un vídeo. La temporada a la vista se rehace en su sitio, en este proceso (22-nov: sus listas ya
        no tienen <content> y Kodi no las recarga; la carpeta 7976, si se usa, sí la recarga él). Las temporadas ocultas
        se invalidan (se piden al mostrarse). Si la base de vistos cambia después (el servicio apunta la pausa), step_k3
        la rehace otra vez. Devuelve (lista, posición, hora) para devolver el foco al capítulo, o None"""
        log("vídeo parado: lanzado desde %s" % (play_from,))
        # la hora de la parada se toma lo primero: un toque posterior debe contar como «tocado» en keep_focus
        t = time.time()
        self.acted, self.stop_at = False, t
        self.fast_until = t + FAST_SECS                 # la carpeta 7976 recargada: firma de temporadas cada segundo
        if self.mode == "seasons" and self.slots.active is not None:
            self.slots.stale_except(self.slots.active)
        self.refill_active()        # sin <content> Kodi ya no las recarga solo al parar: aquí, en su sitio
        self.seasons_dirty = True
        if play_from and str(play_from[0]).isdigit() and str(play_from[1]).isdigit():
            return int(play_from[0]), int(play_from[1]) - 1, t
        return None

    def fix_focus(self):
        """en temporadas, el foco no puede quedarse en la lista oculta 7976 (fuera de pantalla; banco 25-oct:
        System.CurrentControlId = 7976 tras un menú)"""
        if self.mode == "seasons" and xbmc.getCondVisibility("Control.HasFocus(%d)" % SERIES_LIST):
            xbmc.executebuiltin("SetFocus(%d)" % SEASONS_LIST)
        elif self.mode in ("seasons", "one") and not xbmc.getInfoLabel("System.CurrentControlId"):
            # tras volver del vídeo Kodi deja la ficha sin control enfocado (banco 25-oct): a la lista principal
            xbmc.executebuiltin("SetFocus(%d)" % (SEASONS_LIST if self.mode == "seasons" else SERIES_LIST))

    def after_menu(self, mon, hint):
        """flix_menu marcó algo (flix_eps_refresh = «lista,posición»): capítulos a la vista al día en su sitio, luego las
        temporadas; el foco vuelve al capítulo si el menú era de un capítulo (si era de una temporada, flix_menu ya lo
        dejó en la columna)"""
        back = self.refresh_local(hint)
        if self.mode == "seasons":
            self.reload_series()
            self.fast_until = time.time() + FAST_SECS
        if back and hint.partition(",")[0] == str(back[0]):
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % back)
        HOME.clearProperty("flix_series_hold")         # flix_menu la pone para la ventana Vídeos: aquí no hace falta

    def refresh_local(self, hint):
        """after_menu en local: la temporada a la vista otra vez en su sitio; (lista, posición) para devolver el foco"""
        k = self.slots.active
        if k is None or not self.slots.paths[k]:
            return None
        cid = EPS_FIRST_ID + k
        hcid, _, hpos = hint.partition(",")
        pos = hpos if hcid == str(cid) else xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
        pos = int(pos) - 1 if pos.isdigit() and int(pos) > 0 else None
        self.refill_active()
        self.local_state()
        end = time.time() + 3
        while k in self.filling and time.time() < end:
            xbmc.sleep(30)
        return (cid, pos) if pos is not None else None

    def keep_focus(self, back_play, back_try, now):
        """tras el vídeo, el foco vuelve al capítulo que se estaba viendo mientras nadie toque nada"""
        bcid, bpos, t_stop = back_play
        if not focus_back_due(now - t_stop, getattr(self, "acted", False)):
            return None, back_try
        if xbmc.getCondVisibility("Control.HasFocus(%d)" % bcid) and \
                xbmc.getInfoLabel("Container(%d).CurrentItem" % bcid) == str(bpos + 1):
            return None, back_try                       # ya está
        if now - back_try > 0.5:
            log("tras el vídeo, foco de vuelta al capítulo (lista %d, posición %d)" % (bcid, bpos))
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (bcid, bpos))
            return back_play, now
        return back_play, back_try

    def step_seasons(self, now):
        # ✓ y «En progreso» al día cuando llega la carpeta recargada: cada segundo tras un vídeo o el menú, si no cada 3
        every = SEASONS_FAST if now < getattr(self, "fast_until", 0.0) else SEASONS_EVERY
        if now - self.sig_at > every:
            self.sig_at = now
            if self.local:          # ✓ y «En progreso» de la base: solo cuando algo pudo cambiarlos (seasons_dirty)
                items = self.season_rows() if getattr(self, "seasons_dirty", False) else None
                self.seasons_dirty = False
            else:
                items = flix_series.window_seasons(SERIES_LIST)
            if items and signature(items) != self.sig:
                self.sig = signature(items)
                self.fill_seasons(items)
        cur = xbmc.getInfoLabel("Container(%d).ListItem.Property(path)" % SEASONS_LIST)
        if not cur and self.slots.seen:
            # la columna no dice qué temporada tiene delante (un instante, mientras se cierra lo que había encima de
            # la ficha: el aviso «Ver temporadas»). No es un cambio de temporada: tomarlo por uno escondía los
            # capítulos y los volvía a pedir (móvil de Carlos, 12-nov: pedidos dos veces al abrir)
            if not getattr(self, "blank_noted", False):
                self.blank_noted = True
                log("la columna aún no dice su temporada: los capítulos pedidos se quedan")
            return
        if cur != HOME.getProperty("flix_season_cur"):
            HOME.setProperty("flix_season_cur", cur)    # temporada resaltada en la columna (FTSeasonRow)
        self.apply_slots(self.slots.step(cur, now, flix_series.eps_count, updating=self.slot_updating))
        k = self.slots.active
        if k is not None and k in self.slots.ready and (k, self.slots.paths[k]) not in self.noted:
            self.noted.add((k, self.slots.paths[k]))    # recién llegados: la lista arranca en el capítulo que toca
            HOME.clearProperty(EPS_WAIT)                # capítulos a la vista: el tráiler automático ya puede pedirse
            eps = flix_series.episodes_of(EPS_FIRST_ID + k)
            ses = [tuple(int(x) for x in m.groups()) for m in (EP_SE_RE.search(e[1] or "") for e in eps) if m] \
                if HOME.getProperty("flix_series_part") else None
            self.place_next(EPS_FIRST_ID + k, self.slots.paths[k], [e[0] for e in eps], ses)

    def step_k3(self, now):
        """la ficha al día sin que nadie la toque. (1) El botón («Seguir viendo · T1 E4»,
        «Al día»…) con el estado que deja la carpeta de la serie cada vez que se recarga (flix_series.k3_state: una
        propiedad, sin llamadas). (2) Cuando la base de vistos cambia (el servicio del addon apunta el capítulo al
        parar, un visto que llega de Simkl), los capítulos a la vista y la carpeta de la serie se piden otra vez en
        su sitio: ✓, barras y capítulo que toca. Kodi recarga solo las listas al parar el vídeo, pero puede hacerlo
        antes de que el servicio haya escrito. Como mucho una mirada por segundo (tres os.stat)"""
        tmdb = HOME.getProperty("flix_series_tmdb")
        raw = HOME.getProperty(flix_series.K3_STATE + tmdb)
        if "k3_raw" not in self.__dict__:
            self.k3_raw = raw                   # el de abrir ya está puesto (open_k3_series)
        elif raw and raw != self.k3_raw:
            self.k3_raw = raw
            st = flix_series.k3_state(tmdb)
            if st:
                flix_series.k3_apply(tmdb, st)
                log("estado de la serie al día: %s" % (HOME.getProperty("flix_series_next") or
                                                      HOME.getProperty("flix_series_upto") or "sin capítulo que toque"))
        if now - self.__dict__.get("k3_at", 0.0) < 1.0:
            return
        self.k3_at = now
        sig = flix_series.db_sig(xbmcvfs.translatePath(flix_series.WATCHED))
        old, self.k3_sig = self.__dict__.get("k3_sig"), sig
        if old is not None and sig is not None and sig != old:
            log("la base de vistos ha cambiado: capítulos y temporadas al día")
            self.refill_active()
            self.reload_series()
            self.fast_until = now + FAST_SECS

    def loop(self, mon):
        import flix_autotrailer
        import flix_playload
        mark_used = False                               # la pulsación actual ya contó como carga nueva
        mark_at = 0.0                                   # desde cuándo está puesta
        played, play_from, loading_from = False, None, None
        last_focus, last_path, last_pos = "", "", ""
        last_media = last_loading = 0.0
        back_play, back_try = None, 0.0
        while not self.stop and not mon.abortRequested():
            now = time.time()
            mark = HOME.getProperty(flix_playload.USER_PRESS)
            mark_used = mark_used and bool(mark)
            mark_at = (mark_at or now) if mark else 0.0
            if mark and now - mark_at > PRESS_MAX and not xbmc.getCondVisibility("Player.HasMedia"):
                HOME.clearProperty(flix_playload.USER_PRESS)
                HOME.clearProperty(flix_playload.USER_PRESS_PATH)
                mark = ""
            # hay una pulsación en camino o el aviso de reanudar: el foco no se mueve
            if back_play and (mark or HOME.getProperty(flix_playload.PROP) == flix_playload.PENDING or
                              xbmc.getCondVisibility("Window.IsActive(contextmenu)")):
                back_play = None
            if xbmc.getCondVisibility("Player.HasMedia") and not HOME.getProperty(flix_autotrailer.ACTIVE):
                if not played:                          # empieza: de qué capítulo de la lista (para volver a él)
                    play_from, loading_from = loading_from or self.clicked_from(now), None
                    log("vídeo en marcha desde %s" % (play_from,))
                played, last_media = True, now          # tras parar: lo que se abra no es un clic
            elif played and self.is_active():           # de vuelta en la ficha (no antes: sus listas no se leen)
                played = False
                back_play = self.after_stop(play_from)
                play_from = None
            if xbmc.getCondVisibility(flix_series.LOADING):
                # el tráiler automático se prepara (flix_tr_loading): su busydialog no es la carga de un capítulo
                if not HOME.getProperty(flix_autotrailer.LOADING):
                    # el capítulo tocado manda sobre el foco: el del toque (100) si ya llegó; si no, el del dedo apoyado
                    # (107). Con un capítulo sin empezar el 100 llega cuando la carga ya ha terminado (note_press)
                    src = latest_source(getattr(self, "tap", None), getattr(self, "press", None), now)
                    origin = press_origin(mark)             # la pulsación dice cuál es: manda sobre foco y dedo
                    # empieza una carga: consta la pulsación, o un relevo largo (next_origin) si no la hay
                    fresh = bool(mark) and not mark_used
                    if fresh or now - last_loading > 3:
                        new = origin or ((src[0], src[1]) if src else
                                         (last_focus, last_pos) if last_focus in self.eps_ids() and last_pos.isdigit() else None)
                        # una pulsación manda, también sin lista (un botón): no hereda el origen de lo anterior
                        loading_from = new if fresh else next_origin(loading_from, new, now, max(last_loading, last_media))
                        self.tap = self.press = None        # un toque arranca una sola carga
                        mark_used = bool(mark)
                    last_loading = now
                    busy = HOME.getProperty("flix_playload") or HOME.getProperty("flix_working")
                    if flix_series.episode_click(True, origin[0] if origin else src[0] if src else last_focus, bool(busy),
                                                 now - last_media, self.eps_ids(), pressed=bool(mark)):
                        # un capítulo pulsado: va a reproducirse. Solo aquí: la rueda de cargar la lista de
                        # capítulos al abrir la ficha paraba el tráiler recién pedido (Shield, 30-oct)
                        self.stop_auto()
                        flix_playload.begin(HOME.getProperty("flix_open_fanart"),
                                             HOME.getProperty(flix_playload.USER_PRESS_PATH) or (src[2] if src else last_path),
                                             mark=False)
                        log("capítulo pulsado en la lista (%s): pantalla de carga" % mark)
            elif self.is_active() and not xbmc.getCondVisibility(flix_series.COVERED):
                last_focus = xbmc.getInfoLabel("System.CurrentControlId")
                if last_focus in self.eps_ids():
                    last_path = xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % last_focus)
                    last_pos = xbmc.getInfoLabel("Container(%s).CurrentItem" % last_focus)
                hint = HOME.getProperty("flix_eps_refresh")
                if hint:                                # flix_menu marcó algo: ✓ al día, en su sitio
                    HOME.clearProperty("flix_eps_refresh")
                    self.after_menu(mon, hint)
                if back_play:
                    back_play, back_try = self.keep_focus(back_play, back_try, now)
                if not back_play:                       # con back_play, keep_focus es quien manda en el foco
                    self.fix_focus()
                if self.mode == "seasons":
                    self.step_seasons(now)
                self.step_k3(now)
                self.step_pending()
                self.step_prefetch(now)
            # con un vídeo (no el tráiler de la ficha) solo hay que notar la parada: 1 s por vuelta (PY-05)
            if mon.waitForAbort(PLAY_STEP if played else flix_series.WATCH_STEP):
                break

    # ---------- agilidad (18-nov): el capítulo enfocado se va preparando ----------
    def step_fresh(self, now, today=None):
        """al abrir la ficha, el capítulo estrenado hoy o ayer (fecha de TMDB, flix_aired) se comprueba ya, tenga o no
        el foco (19-nov, Carlos: Nocturno 1x05 salía disponible el día de su estreno y al pulsar «Ver» decía que no).
        Es la misma precarga: si no hay ninguna versión, el addon lo pinta «Aún no disponible». Una vez por ficha"""
        if getattr(self, "fresh_done", False):
            return
        pl = self.pending_list()
        if not pl or not pl[2]:
            return                      # la lista aún no ha llegado
        self.fresh_done = True
        if video_on():
            return
        t = time.time() if today is None else today
        days = {time.strftime("%Y-%m-%d", time.localtime(t)), time.strftime("%Y-%m-%d", time.localtime(t - 86400))}
        lid = pl[0]
        try:
            n = int(xbmc.getInfoLabel("Container(%d).NumItems" % lid) or 0)
        except ValueError:
            return
        for k in range(n - 1, -1, -1):
            aired = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Property(flix_aired)" % (lid, k))
            if aired in days:
                path = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (lid, k))
                if K3_EPISODE.match(path):
                    log("capítulo estrenado %s: lo compruebo ya" % aired)
                    self.pf_done = getattr(self, "pf_done", []) + [now]
                    threading.Thread(target=prefetch_episode, args=(path,), name="flix_ep_fresh", daemon=True).start()
                return

    def step_prefetch(self, now):
        """el capítulo con el foco PREFETCH_DWELL s (el que toca al abrir la ficha, o al que se baja y se queda): su
        enlace se prepara en segundo plano (flix_src_play.prefetch, a disco: el clic reproduce en otro proceso).
        Bajando por la lista sin pararse no se pide nada; uno ya pedido no se repite"""
        try:
            self.step_fresh(now)
        except Exception as e:  # noqa: BLE001
            log("capítulo de estreno: %s" % e)
        try:
            cid = xbmc.getInfoLabel("System.CurrentControlId")
            if cid == str(SEASONS_LIST) and self.mode == "seasons":
                cid = HOME.getProperty("flix_eps_id")   # en las temporadas: el capítulo que toca en la lista de al lado
            if cid not in self.eps_ids() or video_on():
                self.pf = None
                return
            path = xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % cid)
            if not K3_EPISODE.match(path):
                self.pf = None
                return
            pf = getattr(self, "pf", None)
            if not pf or pf[0] != path:
                self.pf = (path, now, False)
            elif not pf[2] and now - pf[1] >= PREFETCH_DWELL:
                self.pf = (path, pf[1], True)
                done = getattr(self, "pf_done", [])
                if len(done) >= PREFETCH_MAX or (done and now - done[-1] < PREFETCH_GAP):
                    return              # bajando despacio por la lista: no se acribilla a Torrentio (429 = 10 min)
                self.pf_done = done + [now]
                threading.Thread(target=prefetch_episode, args=(path,), name="flix_ep_prefetch", daemon=True).start()
        except Exception as e:  # noqa: BLE001
            log("precarga: %s" % e)

    # ---------- capítulos que aún no tienen versión (Carlos, 7-nov) ----------
    def pending_list(self):
        """(lista, ruta de su temporada, ¿ya cargada?) de la lista de capítulos a la vista, o None. En «one» es la
        carpeta 7976; con temporadas, el hueco activo (cargado o cargándose: la consulta a TMDB sale ya, en paralelo
        con la lista; los pendientes solo se ponen cuando la lista ha llegado)"""
        if self.mode == "one":
            return SERIES_LIST, HOME.getProperty("flix_eps_c%d" % SERIES_SLOT), True
        k = self.slots.active
        if self.mode != "seasons" or k is None or self.slots.paths[k] is None:
            return None
        return EPS_FIRST_ID + k, HOME.getProperty("flix_eps_c%d" % k), k in self.slots.ready

    def clear_pending(self):
        """sin pendientes a la vista (temporada cambiando o sin datos): sus elementos fijos se ocultan"""
        if self.pend_shown is None:
            return
        self.pend_shown = None
        flix_series.clear_pending_props()

    def step_pending(self):
        """los capítulos que TMDB cuenta y la lista no da, debajo de los de la lista (elementos fijos
        FlixPendingItems que se rellenan con flix_pend<i>_*), atenuados y sin reproducir. Primero los de la lista como
        siempre; TMDB llega en un hilo (fetch_pending, en cuanto se pide la temporada) y se ponen en la vuelta
        siguiente. Se rehacen si cambia la temporada o lo que tiene la lista (tras un vídeo o un &reload=). Sin red ni
        datos no sale nada"""
        if "pend" not in self.__dict__:                 # pruebas que crean la ventana sin __init__
            self.pend, self.pend_busy, self.pend_shown = {}, set(), None
        meta = self.__dict__.setdefault("pend_meta", {})   # ruta -> (tmdb, temporada): decodificar la ruta una vez, no cada 0,15 s
        src = self.pending_list()
        if not src:
            self.clear_pending()
            return
        cid, path, ready = src
        path = re.sub(r"&reload=\d+$", "", path or "")
        if not path or path == flix_series.EMPTY_EPS or not ready:
            self.clear_pending()
            return
        if path not in meta:
            first = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(0).Season" % cid) if cid == SERIES_LIST else ""
            meta[path] = flix_series.pending_source(path, first)
        tmdb, season = meta[path]
        if not tmdb:
            self.clear_pending()
            return
        ptail = None
        if season.isdigit() and int(season) >= flix_series.PART_BASE:
            # una parte (serie con temporadas como en IMDb): solo la del último capítulo de TMDB lleva los que están
            # por llegar (de su temporada de TMDB); las demás, ninguno (ni se pregunta a TMDB)
            ptail = flix_series.part_tail(tmdb, season)
            if not ptail:
                self.clear_pending()
                return
            season = str(ptail[0])
        key = "%s/%s" % (tmdb, season)
        if key not in self.pend:
            if key not in self.pend_busy:
                self.pend_busy.add(key)
                threading.Thread(target=self.fetch_pending, args=(tmdb, season, key), daemon=True).start()
            return
        if cid != SERIES_LIST:
            self.pending_python(cid, key, season, ptail)
            return
        # NumItems cuenta también los pendientes que ya se ven (un fotograma después de ponerlos): mientras sea el de
        # la lista sola o con ellos, nada que hacer (sin leer la lista entera cada 0,15 s)
        n = ival(xbmc.getInfoLabel("Container(%d).NumItems" % cid), 0)
        shown = self.pend_shown
        if n < 1 or (shown and shown[0] == cid and shown[1] == key and n in shown[2]):
            return
        have = [e[0] for e in flix_series.episodes_of(cid)]
        if not have:
            return                                      # aún sin los de la lista
        rows = self.pending_rows_for(key, have, season, ptail)
        # los de la lista = los que hay menos los pendientes que aún se vean (último elemento con flix_pending)
        tail = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Property(%s)" % (cid, n - 1, flix_series.PENDING))
        real = n - (shown[3] if tail and shown and shown[0] == cid else 0)
        flix_series.apply(flix_series.pending_props(rows, cid, real))
        shown_n = min(len(rows), flix_series.PEND_SLOTS)
        self.pend_shown = (cid, key, {real, real + shown_n}, shown_n)
        if rows:
            log("%d capítulos sin versión debajo de la lista %d (%s, %d suyos)" % (shown_n, cid, key, real))

    def pending_rows_for(self, key, have, season, ptail):
        fanart = HOME.getProperty("flix_open_fanart")
        if ptail:
            return flix_series.part_pending_rows(self.pend[key] or [], have, ptail, thumb=fanart)
        return flix_series.pending_rows(self.pend[key] or [], have, season, thumb=fanart)

    def pending_python(self, cid, key, season, ptail):
        """los pendientes de un hueco (lista que rellena la ficha): elementos suyos detrás de los capítulos; la lista
        se rehace en su sitio solo si cambian (fill_slot los vuelve a poner al refrescarla)"""
        self.local_state()
        k = cid - EPS_FIRST_ID
        items = self.eps_items.get(k)
        if items is None or k in self.filling:
            return                                      # aún sin los capítulos
        if self.pend_shown == (cid, key, len(items)):
            return
        have = [e[0] for e in flix_series.episodes_of(cid)]
        rows = self.pending_rows_for(key, have, season, ptail)[:flix_series.PEND_SLOTS] if have else []
        self.pend_shown = (cid, key, len(items))
        if [r["label"] for r in rows] == [r["label"] for r in self.pend_rows.get(k) or []]:
            return
        self.pend_rows[k] = rows
        self.set_items(cid, items + [pending_item(r) for r in rows], True)
        if rows:
            log("%d capítulos sin versión debajo de la lista %d (%s)" % (len(rows), cid, key))

    def fetch_pending(self, tmdb, season, key):
        eps = None
        try:
            import flix_newep
            eps = flix_newep.season_episodes(tmdb, season)
        except Exception as e:  # noqa: BLE001
            log("TMDB %s: %s" % (key, type(e).__name__))
        if not self.stop:
            self.pend[key] = eps
        self.pend_busy.discard(key)

    def pending_at(self, cid, idx):
        """la frase del capítulo pendiente en esa posición, o '' si es un capítulo de la lista"""
        return xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Property(%s)" % (cid, idx, flix_series.PENDING))

    # ---------- toques ----------
    def onClick(self, control_id):
        # botones: su onclick del XML; listas de capítulos: el clic de Kodi (reproduce; un pendiente, su aviso). Lo de
        # abajo (reparto y similares, flix_more): aquí
        more = getattr(self, "more", None)
        if control_id in (7300, 7301) and more is not None:
            more.click(control_id)
        elif EPS_FIRST_ID <= control_id < EPS_FIRST_ID + flix_series.EPS_SLOTS:
            self.click_episode(control_id)
        elif control_id == VER_BTN:
            # «Ver / Seguir viendo»: aquí, sin RunScript (el <onclick> del XML solo vale sin la ficha: vista de respaldo)
            in_background(flix_series.ver)

    def clicked_from(self, now):
        """(lista, posición) del capítulo pulsado en la ficha si el vídeo empieza poco después (CLICK_PLAY_SECS), o
        None. La marca del <onclick> (flix_user_press) la pisa flix_play al encender la capa de carga; esta no"""
        c = getattr(self, "click_at", None)
        self.click_at = None
        return (c[0], c[1]) if c and now - c[2] < CLICK_PLAY_SECS else None

    def click_episode(self, cid):
        """capítulo pulsado en un hueco (lista de Python, 22-nov): lo que hacían el <onclick> del XML y el clic de Kodi.
        Pendiente: su aviso. A medias: «Te quedaste en…» (flix_play resume, con el elemento enfocado). Si no: se
        apunta la pulsación (flix_playload.USER_PRESS) y se reproduce"""
        try:
            lst = self.getControl(cid)
            li, pos = lst.getSelectedItem(), lst.getSelectedPosition()
        except (RuntimeError, TypeError):
            return
        if li is None:
            return
        when = li.getProperty(flix_series.PENDING)
        if when:
            xbmcgui.Dialog().notification(li.getLabel(), when, xbmcgui.NOTIFICATION_INFO, 4000)
            return
        path = li.getPath()
        if not path:
            return
        tag = li.getVideoInfoTag()
        resume = tag.getResumeTime()
        import flix_play     # en este proceso: sin arrancar otro intérprete para el clic (~0,85 s; 22-nov)
        if resume > 0:
            self.click_at = (str(cid), str(pos + 1), time.time())
            in_background(flix_play.resume_focused, "Reanudar desde %s" % clock(resume))
            return
        self.click_at = (str(cid), str(pos + 1), time.time())     # para volver a él al parar (clicked_from)
        HOME.clearProperty("flix_play_offset")
        HOME.setProperty("flix_user_press_path", path)
        HOME.setProperty("flix_user_press", "%d|%d|%dx%d" % (cid, pos + 1, tag.getSeason(), tag.getEpisode()))
        in_background(flix_play.start, path)

    def busy(self, now):
        return menu_busy(HOME.getProperty("flix_menu_run"), now)

    def menu_lock(self):
        """cerrojo de «decidir y abrir» el menú. onAction (101) y el Timer de ctx_fallback deciden en hilos
        distintos: sin él los dos podían mirar a la vez, ver el menú sin marcar y abrir dos (revisión final,
        25-oct). Se crea al pedirlo (los tests crean la ventana sin __init__); setdefault es atómico: dos hilos a la
        vez reciben el mismo"""
        lock = self.__dict__.get("_menu_lock")
        return lock if lock is not None else self.__dict__.setdefault("_menu_lock", threading.Lock())

    def onAction(self, action):
        aid = action.getId()
        late = aid in (A_CLICK, A_SELECT) and time.time() - getattr(self, "stop_at", 0.0) < LATE_CLICK
        self.acted = getattr(self, "acted", False) or not late   # hizo algo: el foco ya no se le mueve (keep_focus)
        if aid in A_BACK:
            import flix_more
            if flix_more.back(self, getattr(self, "more", None), self.up_id):
                return                      # abajo: Atrás sube a los capítulos
            import flix_playload
            flix_playload.clear_press()      # si no, el selector que llegue arrancaría el vídeo con la ficha cerrada
            self.leave()
            return
        auto = getattr(self, "auto", None)
        if auto is not None:                 # cualquier otra tecla antes del tráiler automático: ya no arranca
            auto.key_in_sheet(aid)
        import flix_more
        if flix_more.swipe(self, getattr(self, "more", None), aid, self.up_id):
            return                           # móvil: deslizar arriba / abajo mueve la ficha (21-nov)
        if aid in (A_CLICK, A_MOVE):
            x, y = action.getAmount1(), action.getAmount2()
            if x > 1 or y > 1:
                (self.note_tap if aid == A_CLICK else self.note_press)(x, y)
            return
        if aid not in (A_LONG, A_CTX):
            return
        x, y = action.getAmount1(), action.getAmount2()
        coords = x > 1 or y > 1
        now = time.time()
        # mirar (menú en marcha, last_long) y marcar de una vez: ctx_fallback decide en otro hilo
        with self.menu_lock():
            if ctx_skip(coords, self.last_long, now, self.busy(now)):
                return
            if not coords:
                # sin dedo: o es el eco que manda Kodi ANTES del 101 (temporada ya seleccionada) o una tecla de menú
                self.ctx_wait = now
                threading.Timer(CTX_WAIT, self.ctx_fallback, args=(now,)).start()
                return
            target = self.target_at(x, y)
            if target is None:
                log("pulsación larga sin temporada ni capítulo debajo (%.0f, %.0f)" % (x, y))
                return
            self.last_long = now
            self.menu_async(*target)

    def note_tap(self, x, y):
        """toque (100): apunta el capítulo tocado; un toque en la columna de temporadas o fuera no se apunta. La
        geometría solo dice QUÉ lista se tocó: Kodi reproduce el elemento que SELECCIONÓ, y en la fila de abajo, a
        medio ver, limita el cursor y no es el que hay bajo el dedo (revisión final, 25-oct). Cuando llega esta
        llamada Kodi ya movió la selección: el capítulo es Container(id).CurrentItem; sin él, el de la geometría"""
        tap = self.episode_at(x, y, prefer_selected=True)
        if tap is not None:
            self.tap = tap

    def note_press(self, x, y):
        """dedo apoyado (107: Kodi lo manda al apoyar el dedo, focusControl de Android; en el banco X11, con cada
        movimiento del ratón). Banco 25-oct: con un capítulo SIN EMPEZAR el clic de Kodi arranca la carga del capítulo
        dentro de su propia acción 100 (diálogo de espera y selector de enlaces, modales) y onAction(100) llega
        cuando la carga ya ha terminado: al empezar no se sabía el capítulo («vídeo en marcha desde None»: ni pantalla
        de carga ni foco de vuelta tras el vídeo). El 107 llega al momento, antes de la carga. Se apunta siempre,
        aunque sea None: manda el último dedo apoyado, y uno en un botón o en la columna borra el anterior. Va por la
        geometría (Kodi aún no ha movido la selección); en la fila cortada de abajo puede no ser el que reproduce
        Kodi, pero solo se usa si el toque no ha llegado"""
        self.press = self.episode_at(x, y)
        if self.press is None:
            HOME.clearProperty("flix_touch_item")
        else:                                # flix_play.resume_focused: con el aviso delante la lista no se lee
            HOME.setProperty("flix_touch_item", "%s|%s|%s|%s" % (self.press[3], self.press[0], self.press[1], self.press[2]))

    def episode_at(self, x, y, prefer_selected=False):
        """(lista, posición, ruta, hora) del capítulo bajo el dedo, o None si no es una lista de capítulos de la
        ficha. La ruta se lee ya: con el diálogo de la carga encima Container(797x) da '' (Kodi la busca en el
        diálogo). prefer_selected (toque): la posición es la seleccionada (Container(id).CurrentItem) si se lee"""
        target = self.target_at(x, y)
        if target is None or str(target[0]) not in self.eps_ids():
            return None
        cid, idx = target
        if prefer_selected:
            cur = ival(xbmc.getInfoLabel("Container(%d).CurrentItem" % cid))
            if cur > 0:
                idx = cur - 1
        path = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, idx))
        return str(cid), str(idx + 1), path, time.time()

    def ctx_fallback(self, stamp):
        """117 sin coordenadas y no llegó el 101 (tecla de menú de un teclado o mando): el elemento enfocado"""
        with self.menu_lock():          # un 101 que llegue a la vez decide después (o antes), nunca a la vez
            if self.stop or self.ctx_wait != stamp or self.last_long >= stamp or self.busy(time.time()):
                return
            target = self.focused_target()
            if target is not None:
                self.last_long = time.time()
                self.menu_async(*target)

    def target_at(self, x, y):
        """(lista, índice) bajo el dedo (coordenadas de pantalla), o None"""
        if self.res is None:             # onAction antes de onInit, o skin_res falló
            return None
        sx, sy = flix_screen.to_skin(x, y, self.res)
        hit = list_at(sx, sy, self.res[0], self.mode)
        if hit is None:
            return None
        cid, rel, h = hit
        if cid == "eps":
            slot = HOME.getProperty("flix_eps_slot")
            if not slot.isdigit() or int(slot) >= flix_series.EPS_SLOTS:
                return None
            cid = EPS_FIRST_ID + int(slot)
        g = lambda k: ival(xbmc.getInfoLabel("Container(%d).%s" % (cid, k)))  # noqa: E731
        idx = index_at(rel, h, g("CurrentItem"), g("Position"), g("NumItems"))
        return None if idx is None else (cid, idx)

    def focused_target(self):
        """(lista, índice) del elemento enfocado si es una temporada o un capítulo de la ficha"""
        cid = xbmc.getInfoLabel("System.CurrentControlId")
        ids = {str(SERIES_LIST)} if self.mode == "one" else \
            {str(SEASONS_LIST)} | {str(EPS_FIRST_ID + k) for k in range(flix_series.EPS_SLOTS)}
        cur = ival(xbmc.getInfoLabel("Container(%s).CurrentItem" % cid))
        return (int(cid), cur - 1) if cid in ids and cur > 0 else None

    def menu_async(self, cid, idx):
        # un capítulo que aún no tiene versión: sin menú (no hay nada que marcar ni reproducir), el mismo aviso que el clic
        phrase = self.pending_at(cid, idx)
        if phrase:
            xbmcgui.Dialog().notification(xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, idx)),
                                          phrase, xbmcgui.NOTIFICATION_INFO, 4000)
            return
        # la marca va ANTES de arrancar el hilo: si fuera dentro, un 101 que llegase justo después de decidir el
        # fallback vería el menú aún sin marcar y abriría un segundo
        self.stop_auto()
        HOME.setProperty("flix_menu_run", "s%f" % time.time())
        threading.Thread(target=self.open_menu, args=(cid, idx), daemon=True).start()

    def open_menu(self, cid, idx):
        """menú KER0N3 del elemento idx de la lista cid. flix_menu.py lo lee de la lista enfocada (focused_episode): se
        enfoca antes. Si Kodi abrió su menú por su cuenta (el elemento ya estaba seleccionado), DialogContextMenu.xml lo
        cierra sin lanzar flix_menu.py con esta ficha abierta (flix_sheet): solo lo lanza esta ventana"""
        if self.stop:                    # ficha cerrada (Atrás) mientras tanto: ni foco ni menú
            HOME.clearProperty("flix_menu_run")
            return
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, idx))
        end = time.time() + FOCUS_WAIT
        while time.time() < end and not (xbmc.getCondVisibility("Control.HasFocus(%d)" % cid) and
                                         xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) == str(idx + 1)):
            xbmc.sleep(30)
        if self.stop:
            HOME.clearProperty("flix_menu_run")
            return
        if not (xbmc.getCondVisibility("Control.HasFocus(%d)" % cid) and
                xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) == str(idx + 1)):
            # flix_menu.py lee el elemento enfocado: sin el pedido abriría el menú de otro capítulo
            log("no llegó al elemento %d de la lista %d: sin menú" % (idx, cid))
            HOME.clearProperty("flix_menu_run")
            return
        log("menú de la lista %d, elemento %d" % (cid, idx))
        # en este proceso (ya está en marcha) y no con RunScript: arrancar otro intérprete para cada menú costaba ~1 s
        # en la Shield (Carlos, 21-nov: «tarda mucho en abrir el menú contextual»)
        try:
            import flix_menu
            flix_menu.main(flix_menu.menu_focused)
        except Exception as e:  # noqa: BLE001
            log("menú en este proceso: %s; con RunScript" % e)
            HOME.clearProperty("flix_menu_run")
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_menu.py)")


def video_on():
    """¿se está viendo algo de verdad? El tráiler automático de la ficha no cuenta (19-nov, Fire TV: con él en marcha
    no se comprobaba el capítulo de estreno ni se preparaba el enlace del que tiene el foco)"""
    import flix_autotrailer
    return xbmc.getCondVisibility("Player.HasMedia") and not HOME.getProperty(flix_autotrailer.ACTIVE)


def prefetch_episode(path):
    """en un hilo: flix_src_play (urllib/ssl) se importa aquí, no en la ficha"""
    m = K3_EPISODE.match(path)
    if not m:
        return
    try:
        import flix_src_play
        flix_src_play.prefetch({"content": "episodes", "tmdb": m.group(1), "season": int(m.group(2)),
                                "episode": int(m.group(3))})
    except Exception as e:  # noqa: BLE001
        log("precarga: %s" % e)


def open_sheet(folder, seasons=None):
    """abre la ficha de la serie (carpeta …/serie/<tmdb> del addon) y espera a que se cierre. flix_series ya puso las
    propiedades de la serie (flix_series_*, flix_open_*)"""
    w = None
    # un flix_eps_refresh que se quedase puesto (de otra ficha o de la ventana Vídeos) haría correr after_menu nada
    # más abrir: más peticiones a la vez que la primera carga de la serie
    HOME.clearProperty("flix_eps_refresh")
    # hasta que se vean los primeros capítulos, el tráiler automático no se pide (flix_autotrailer.eps_busy; 22-nov,
    # Fire TV: YouTube preparándolo retrasaba 9-12 s la lista de temporadas y la 1.ª temporada)
    HOME.setProperty(EPS_WAIT, "1")
    try:
        if not seasons:     # sin las temporadas de este proceso: la carpeta de la serie en la lista 7976, como antes
            HOME.setProperty("flix_eps_c%d" % SERIES_SLOT, folder)
        w = SeriesSheet("FlixSeries.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", folder=folder,
                        seasons=seasons)
        w.doModal()
    finally:
        if w is not None:
            w.stop = True
            w.stop_auto()                       # red de seguridad: ningún camino de cierre deja el tráiler sonando
        for k in ("flix_sheet", "flix_eps_c%d" % SERIES_SLOT, "flix_season_cur", "flix_series_hold", "flix_menu_run",
                  "flix_eps_refresh", EPS_WAIT):
            HOME.clearProperty(k)
        flix_series.clear_pending_props()
        del w
