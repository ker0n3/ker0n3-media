"""Ker0n3 Flix táctil: instala el keymap de gestos y lo recarga.

Por qué: en Kodi el arrastre lo coge la lista que hay bajo el dedo; una fila horizontal de pósters
ignora el movimiento vertical, así que en la Home no se podía bajar/subir arrastrando sobre los
pósters. Kodi sí detecta los "swipes" (gesto rápido <0,5 s y >1,3 cm) y permite mapearlos por
ventana. Aquí:
  Home:            nada (desde v5 la Home se arrastra en continuo: filas = listas desactivadas)
  FullScreenVideo: swipe arriba/abajo SIN acción (Kodi por defecto salta capítulo/10 min por error),
                   izquierda/derecha = -10 s / +10 s, pulsación larga = mostrar controles
                   (por defecto saca de la reproducción a la Home).
Se versiona con Skin.String(flix_touch_keymap); subir KEYMAP_VERSION si cambia el contenido.
"""
import xbmc
import xbmcvfs

KEYMAP_VERSION = "5"
KEYMAP = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Generado por la skin Ker0n3 Flix táctil (scripts/flix_touch_setup.py). Se reescribe al cambiar de versión. -->
<keymap>
  <FullScreenVideo>
    <touch>
      <swipe direction="up">noop</swipe>
      <swipe direction="down">noop</swipe>
      <swipe direction="left">Seek(-10)</swipe>
      <swipe direction="right">Seek(10)</swipe>
      <longpress>OSD</longpress>
    </touch>
  </FullScreenVideo>
</keymap>
"""


def main(force=False):
    """force (Ajustes → «Arreglar gestos del reproductor»): reescribe el keymap aunque sea de esta versión y avisa del
    resultado real (antes el aviso «instalados» lo ponía el XML, a la vez que el RunScript, y salía aunque fallase)"""
    try:
        _install(force)
    except Exception as e:      # noqa: BLE001  (sin escribir el keymap: que el usuario lo sepa)
        xbmc.log("[flix_touch] keymap: %s" % e, xbmc.LOGWARNING)
        if force:
            import xbmcgui
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "No he podido arreglar los gestos", xbmcgui.NOTIFICATION_ERROR,
                                          3500)
        return
    if force:
        import xbmcgui
        xbmcgui.Dialog().notification("KER0N3 MEDIA", "Gestos del reproductor arreglados", xbmcgui.NOTIFICATION_INFO,
                                      2500)


def _install(force):
    folder = "special://profile/keymaps/"
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    path = folder + "flix_touch.xml"
    fresh = not force and xbmc.getInfoLabel("Skin.String(flix_touch_keymap)") == KEYMAP_VERSION and xbmcvfs.exists(path)
    if not fresh:                     # solo al cambiar de versión (o si alguien lo borró): TT-02
        with xbmcvfs.File(path, "w") as fh:
            if fh.write(KEYMAP) is False:
                raise IOError("no se pudo escribir %s" % path)
        xbmc.executebuiltin("Action(reloadkeymaps)")
    # fechas dd/mm/aaaa (Carlos, 16-oct): las pone first_run una sola vez, como en la TV; si luego se cambian a mano,
    # se respetan (antes aquí se forzaban en cada arranque: revisión 29-oct ARR-16)
    # sin ".." en los listados: hay botón Atrás en pantalla. Una sola vez (Skin.SetBool): antes por JSON-RPC en cada
    # arranque (revisión 7-nov TAC-10); si luego se cambia a mano, se respeta
    if not xbmc.getCondVisibility("Skin.HasSetting(flix_touch_noparent)"):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Settings.SetSettingValue","params":{"setting":"filelists.showparentdiritems","value":false}}')
        xbmc.executebuiltin("Skin.SetBool(flix_touch_noparent)")
    if not fresh:
        xbmc.executebuiltin("Skin.SetString(flix_touch_keymap,%s)" % KEYMAP_VERSION)
        xbmc.log("[flix_touch] keymap v%s instalado en %s" % (KEYMAP_VERSION, xbmcvfs.translatePath(path)), xbmc.LOGINFO)


if __name__ == "__main__":
    import sys
    main(force=len(sys.argv) > 1 and sys.argv[1] == "ajuste")
