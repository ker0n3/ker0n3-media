"""Migración única de la configuración al quitar Palantir (bloque 7, 17-nov). Lógica sin xbmc salvo migrate().

Es lo ÚNICO de la skin que aún sabe leer rutas del addon viejo (plugin.video.palantir3): lo que el usuario guardó con
él en sections.json (secciones añadidas, filas añadidas a una sección) y en home_order.json (filas añadidas al
Inicio) pasa una sola vez por aparato a su equivalente propio, con las tablas de los bloques 2 y 5 (lo que hasta
ahora se traducía al pintar). Sin equivalente, fuera (Carlos, bloques 4 y 5: «sin equivalente = borrar»). Lo que el
usuario tocó y tiene equivalente se queda: nombres, orden, ocultas, eliminadas.

  sections.json  sección añadida «Telenovelas» (menú 30 de Palantir)   → src own:telenovelas (menú propio)
                 sección añadida «Series en seguimiento» (rejilla)       → src K3/siguiendo
                 sección que seguía al «Especial…» o sin equivalente     → fuera
                 fila añadida «Acción» (listado de Palantir por género)  → flix://tmdb/genero-pelis-accion
                 fila añadida sin parecida (sagas, por letra, calidad…)  → fuera (y su orden, nombre, oculta)
                 configuración de filas que el menú propio no tiene      → fuera (filas de Trakt: con Trakt en uso)
                 (las claves «p3:<nombre>» de las añadidas pasan a «sec:<nombre>» en flix_sections_conf.normalize)
  home_order.json fila añadida de Palantir → la lista propia (personal: seguir / siguiendo / favoritos; si no, la
                 lista de TMDB parecida); sin parecida → fuera (de custom, order, hidden, deleted y names)

Antes de reescribir un fichero se guarda una copia (<fichero>.antes-limpieza, la primera vez) en el addon_data de la
skin; lo quitado va al registro (solo nombres). Marca por aparato: MARK = {"t", "trakt"}: si Trakt no estaba en uso,
sus filas se miran en un arranque posterior con Trakt en uso (como en los bloques 4 y 5)."""
import ast
import binascii
import json
import math
import os
import re
import time

import flix_sections_conf
import flix_sections_own as so

OLD = "plugin://plugin.video.palantir3/"
K3 = "plugin://plugin.video.ker0n3/"
TMDB = "flix://tmdb/"
MARK = "sin_palantir_limpieza.json"
SUFFIX = ".antes-limpieza"
HOME_FILE = "home_order.json"
SECTIONS_FILE = "sections.json"


def decode(path):
    """diccionario de una ruta del addon viejo (JSON en base64 invertido y rotado ceil(len/4)); None si no lo es"""
    path = str(path or "")
    if not path.startswith(OLD):
        return None
    blob = path.split("?", 1)[-1].split("&", 1)[0]
    for code, ch in (("%2B", "+"), ("%2F", "/"), ("%3D", "=")):
        blob = blob.replace(code, ch).replace(code.lower(), ch)
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    try:
        d = ast.literal_eval(binascii.a2b_base64(b64).decode("utf-8", "replace"))
    except Exception:  # noqa: BLE001
        return None
    return d if isinstance(d, dict) else None


# ---------- filas: tablas de los bloques 2 y 3 (antes flix_rows.k3_personal y flix_tmdblists.k3_equivalent / k3_guess)
_FAVORITES = {"WidgetPelisFavoritas": K3 + "favoritos/peliculas", "WidgetSeriesFavoritas": K3 + "favoritos/series"}
_KIND = {"listado_peliculaS": "pelis", "listado_serieS": "series"}
_SPECIAL = {"mas_vista_mes": "masvistas-%s-mes", "mas_vistas": "populares-%s", "recomendadas": "recomendadas-%s"}
_WIDGETS = {"WidgetTop10Pelis": "top10-pelis", "WidgetTop10Series": "top10-series",
            "WidgetPeliculasNovedades": "novedades-pelis", "WidgetSeriesNuevas": "nuevas-series",
            "WidgetSeriesUltimasActualizadas": "actualizadas-series", "WidgetAnimeNovedades": "anime-pelis",
            "WidgetDibujosNovedades": "dibujos-pelis", "WidgetDocumentalesNovedades": "documentales-pelis"}
_TRAKT_LISTS = {"best-movies-on-netflix": "netflix-pelis", "disney": "disney-pelis", "amazon-prime-video": "prime-pelis",
                "hbo-movies": "max-pelis", "netflix-tv-shows-series-2021-2025": "netflix-series",
                "apple-tv-shows-series-2021-2025": "apple-series", "amazon-prime-shows": "prime-series",
                "disney-tv-shows-series-2021-2025": "disney-series", "hbo-shows": "max-series",
                "based-on-or-inspired-by-a-true-story": "historia-real-pelis"}
_VIEWS = {("pelis", "anime"): "anime-pelis", ("series", "anime"): "anime-series",
          ("pelis", "dibujo"): "dibujos-pelis", ("series", "dibujo"): "dibujos-series",
          ("pelis", "documental"): "documentales-pelis", ("series", "documental"): "documentales-series"}
_LIST_ID = re.compile(r'"list_id"\s*:\s*"([^"]+)"')
_GENRE_SQL = re.compile(r"genero\s+(?:REGEXP|LIKE)\s+[\"']%?([^\"'%]+)", re.I)
_VIEW_SQL = re.compile(r"v_(?:pelis|series)_(\w+)", re.I)
_NO_GUESS = re.compile(r"coleccion|INICIAL\s*\(|calidad\s+REGEXP|fecha\s+like|tmdb\s+in\s*\(|enlaces_", re.I)


def personal(item):
    """ruta propia de una lista personal (Seguir viendo, Series en seguimiento, favoritos); '' si no es de esas"""
    item = item or {}
    if item.get("nameWidget") in _FAVORITES:
        return _FAVORITES[item["nameWidget"]]
    if item.get("action") == "Mis_serieS":
        return K3 + "siguiendo"
    if item.get("action") == "listado_peliculaS" and item.get("especial") == "no_finalizadas":
        return K3 + "seguir"
    return ""


def _norm(s):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", str(s).lower()) if unicodedata.category(c) != "Mn").strip()


def _genre_slug(kind, name):
    """clave del género de TMDB para un género del addon viejo («Acción» → accion); '' si TMDB no lo tiene"""
    import flix_tmdblists
    n = _norm(name)
    for slug, label, _gid in flix_tmdblists.GENRES[kind]:
        lab = _norm(label)
        if n in (lab, slug.replace("-", " ")) or lab.startswith(n + " "):
            return slug
    return ""


def list_key(item):
    """clave de la lista propia (flix_tmdblists) que sustituye a ese listado: la equivalente (Top 10, más vistas,
    recomendadas, novedades, «Lo mejor de…») o la parecida (por género, por categoría, listado general); ''"""
    item = item or {}
    if item.get("nameWidget") in _WIDGETS:
        return _WIDGETS[item["nameWidget"]]
    kind = _KIND.get(item.get("action"))
    if kind and item.get("especial") in _SPECIAL:
        return _SPECIAL[item["especial"]] % kind
    if item.get("action") == "listado_trakt":
        m = _LIST_ID.search(str(item.get("sql") or ""))
        return _TRAKT_LISTS.get(m.group(1), "") if m else ""
    if not kind or item.get("especial") or item.get("sub_categoria") or item.get("isWidget"):
        return ""
    sql = str(item.get("sql") or "")
    if not sql or _NO_GUESS.search(sql):
        return ""
    g = _GENRE_SQL.search(sql)
    if g:
        slug = _genre_slug("movie" if kind == "pelis" else "tv", g.group(1))
        return "genero-%s-%s" % (kind, slug) if slug else ""
    v = _VIEW_SQL.search(sql)
    return _VIEWS.get((kind, v.group(1).lower() if v else ""), "populares-%s" % kind)


def home_path(path):
    """fila añadida al Inicio: su ruta propia ('' = sin equivalente). Lo que no es del addon viejo, tal cual"""
    if not str(path or "").startswith(OLD):
        return path
    item = decode(path)
    if not item:
        return ""
    own = personal(item)
    if own:
        return own
    key = list_key(item)
    return TMDB + key if key else ""


def row_path(path):
    """fila añadida a una sección: la lista parecida (flix://tmdb/<clave>); '' sin ella. Lo demás, tal cual"""
    if not str(path or "").startswith(OLD):
        return path
    key = list_key(decode(path))
    return TMDB + key if key else ""


# ---------- secciones: tabla de los bloques 4 y 5 (antes flix_sections_own.own_var / list_path con la ruta) ----------
_BY_MENU_ID = {"20": "own:peliculas", "40": "own:series", "50": "own:dibujos", "60": "own:anime",
               "80": "own:documentales", "30": "own:telenovelas", "70": "own:musica", "110": "own:seleccion"}
_MENU_ID = re.compile(r"menu_id=(-?\d+)")


def section_src(s):
    """src propio de una sección añadida desde el addon viejo ('' = sin equivalente; lo demás, tal cual)"""
    src = s.get("src", "")
    if not str(src).startswith(OLD):
        return src
    if str(s.get("label") or "").strip().lower().startswith("especial"):
        return ""                       # seguía al «Especial…» del addon viejo (Carlos, 17-nov: sin especiales)
    item = decode(src) or {}
    if s.get("kind") == "list":
        own = personal(item)
        return own if own in (K3 + "siguiendo", K3 + "seguir") else ""
    act = item.get("action")
    if act == "menu":
        m = _MENU_ID.search(str(item.get("sql") or ""))
        return _BY_MENU_ID.get(m.group(1), "") if m else ""
    return {"favoritos": "own:favoritos", "listas_trakt": so.TRAKT}.get(act, "")


def prune_rows(rconf, own_labels):
    """(filas de la sección sin lo que no tiene equivalente, etiquetas quitadas). Las añadidas del addon viejo pasan
    a su lista parecida (row_path) o salen; de orden, ocultas, nombres y eliminadas se queda lo de las filas del menú
    propio (own_labels) y lo de las añadidas que quedan"""
    rconf = dict(rconf or {})
    gone, custom = [], []
    for c in rconf.get("custom") or []:
        p = row_path(c.get("path", ""))
        if p:
            custom.append(dict(c, path=p))
        else:
            gone.append(c["label"])
    keep = set(own_labels) | {c["label"] for c in custom}
    for field in ("order", "off", "deleted"):
        if field in rconf:
            vals = list(rconf.get(field) or [])
            gone += [l for l in vals if l not in keep and l not in gone]
            rconf[field] = [l for l in vals if l in keep]
            if field == "deleted" and not rconf[field]:
                del rconf[field]
    if "names" in rconf:
        gone += [l for l in rconf["names"] if l not in keep and l not in gone]
        rconf["names"] = {l: n for l, n in rconf["names"].items() if l in keep}
        if not rconf["names"]:
            del rconf["names"]
    if "custom" in rconf:
        if custom:
            rconf["custom"] = custom
        else:
            del rconf["custom"]
    return rconf, gone


def migrate_sections(conf, trakt=None, rows_only_trakt=False):
    """(conf nuevo, [textos de lo quitado], ¿Trakt hecho?). Las secciones del addon viejo pasan a su menú o rejilla
    propios o salen; en las de menú propio, fuera la configuración de filas sin equivalente (las de Trakt solo con
    Trakt en uso: sin él no se sabe qué listas son de la cuenta). rows_only_trakt: solo eso (lo demás ya está)"""
    trakt = trakt if isinstance(trakt, dict) else {}
    out, removed, trakt_done = [], [], bool(trakt.get("on"))
    for s in conf["sections"]:
        s = dict(s)
        src = section_src(s)
        if not src:
            removed.append("sección «%s»" % flix_sections_conf.shown(s))
            continue
        if src != s.get("src"):
            s["src"] = src
        var = so.own_var(src)
        if s.get("deleted") or not var or s.get("kind") != "rows":
            out.append(s)
            continue
        if var == so.TRAKT and trakt_done or var != so.TRAKT and not rows_only_trakt:
            rows, gone = prune_rows(s.get("rows"), [r["label"] for r in so.rows_for(var, trakt=trakt) or []])
            s["rows"] = rows
            removed += ["%s: fila «%s»" % (flix_sections_conf.shown(s), l) for l in gone]
        out.append(s)
    return dict(conf, sections=out), removed, trakt_done


def migrate_home(conf):
    """(home_order.json nuevo, [nombres de filas quitadas]): filas añadidas del addon viejo a su ruta propia o fuera"""
    conf = dict(conf)
    custom, gone_ids, removed = [], set(), []
    for c in conf.get("custom") or []:
        p = home_path(c.get("path", ""))
        if p:
            custom.append(dict(c, path=p))
        else:
            gone_ids.add(c.get("id"))
            removed.append("Inicio: fila «%s»" % c.get("label", ""))
    conf["custom"] = custom
    if gone_ids:
        for field in ("order", "hidden", "deleted"):
            if field in conf:
                conf[field] = [i for i in conf[field] or [] if i not in gone_ids]
        if isinstance(conf.get("names"), dict):
            conf["names"] = {k: v for k, v in conf["names"].items() if str(k) not in {str(i) for i in gone_ids}}
            if not conf["names"]:
                del conf["names"]
    return conf, removed


def _rewrite(path, raw, new, atomic_write):
    """escribe new (si cambió) con copia previa de raw en <path>.antes-limpieza (solo la primera vez)"""
    text = json.dumps(new, ensure_ascii=False, indent=1)
    if json.loads(text) == json.loads(raw):
        return False
    if not os.path.exists(path + SUFFIX):
        atomic_write(path + SUFFIX, raw)
    atomic_write(path, text)
    return True


def migrate(conf_dir, trakt=None, log_fn=None, atomic_write=None):
    """una sola vez por aparato, al arrancar (first_run, antes de montar el menú y el Inicio). Devuelve lo quitado
    ([] si no tocaba). Nunca lanza"""
    log_fn = log_fn or (lambda m: None)
    if atomic_write is None:
        from flix_common import atomic_write
    try:
        mark_file = os.path.join(conf_dir, MARK)
        try:
            with open(mark_file, encoding="utf-8") as fh:
                mark = json.load(fh)
        except (OSError, ValueError):
            mark = None
        if isinstance(mark, dict) and mark.get("trakt"):
            return []                       # hecho del todo
        trakt = trakt if isinstance(trakt, dict) else {"on": False}
        only_trakt = isinstance(mark, dict)
        if only_trakt and not trakt.get("on"):
            return []                       # falta lo de Trakt y sigue sin estar en uso
        removed, done = [], bool(trakt.get("on"))
        sec_file = os.path.join(conf_dir, SECTIONS_FILE)
        if os.path.exists(sec_file):        # sin fichero: las de serie, sin nada configurado que traducir
            with open(sec_file, encoding="utf-8") as fh:
                raw = fh.read()
            new, gone, done = migrate_sections(flix_sections_conf.normalize(json.loads(raw)), trakt,
                                               rows_only_trakt=only_trakt)
            removed += gone
            _rewrite(sec_file, raw, new, atomic_write)
        home_file = os.path.join(conf_dir, HOME_FILE)
        if not only_trakt and os.path.exists(home_file):
            with open(home_file, encoding="utf-8") as fh:
                raw = fh.read()
            data = json.loads(raw)
            if isinstance(data, dict):
                new, gone = migrate_home(data)
                removed += gone
                _rewrite(home_file, raw, new, atomic_write)
        atomic_write(mark_file, json.dumps({"t": int(time.time()), "trakt": done}))
        log_fn("sin Palantir: %s" % ("quitado de la configuración (copias en *%s): %s" % (SUFFIX, "; ".join(removed))
                                     if removed else "configuración al día, nada que quitar"))
        return removed
    except Exception as e:  # noqa: BLE001
        log_fn("sin Palantir: configuración sin migrar (%s)" % type(e).__name__)
        return []
