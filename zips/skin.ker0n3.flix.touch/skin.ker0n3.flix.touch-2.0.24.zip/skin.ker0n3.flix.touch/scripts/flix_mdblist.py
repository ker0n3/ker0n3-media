# -*- coding: utf-8 -*-
"""Ajustes → Cuentas → «MDBList (notas, opcional)» (18-nov): poner, comprobar o quitar la clave de MDBList, como PeLis
(flix_pelis.py).

MDBList da las notas de IMDb, Metacritic, Rotten Tomatoes y Letterboxd de las fichas (flix_ratings.py), gratis con una
clave propia (unas 1000 consultas al día). Sin vincular: una pantalla que lo explica con el QR de la página de la clave
(FlixMdblist.xml, tools/gen_telegram_dialog.py), el teclado de Kodi (en la tele, el de la skin enseña «Escribir desde
el móvil», flix_phonekb: se puede PEGAR desde el móvil; en la táctil, la página local para pegar de flix_pelis), se
mira la forma (flix_ratings.KEY_RE), se comprueba con UNA petición a la API (/user: la cuenta de esa clave) y se
guarda donde siempre (Skin.String flix_mdblist_key, flix_ratings.save_settings: también el orden de Notas, y si no
había ninguna fuente de MDBList encendida antes de TMDB, las de serie, flix_ratings.DEFAULT). Vinculada: «Comprobar» y
«Desvincular» (la clave a «-»; en mdblist.com no se toca nada).

La clave es un secreto: del teclado al ajuste de la skin y a api.mdblist.com, a ningún sitio más. Ni al registro ni a
un diálogo (como mucho, flix_ratings.mask: los 4 últimos). Los fallos se apuntan por su tipo, sin texto.
También lo usa el editor de «Nota de los títulos» (flix_editor UI.ask_key): run() devuelve la clave nueva ('' si se
desvinculó) o None si no cambió nada."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re

import xbmc

SITE = "https://mdblist.com/preferences/"
SHOWN = "mdblist.com/preferences"
HEADING = "MDBList"
USER_API = "https://api.mdblist.com/user?apikey=%s"
ASK = "Pega aquí tu API key de MDBList"
TIMEOUT = 8
UA = "Ker0n3Media-skin"
CONTINUE, OPEN = 10, 11                 # botones de FlixMdblist.xml
WAIT_TEXT = ("En el navegador se ha abierto una página: pega ahí tu API key de MDBList y pulsa «Enviar a Kodi». "
             "Luego vuelve aquí.")
BAD = "Esa clave no parece de MDBList: son letras y números, sin espacios (Preferences → API Access → API key)."


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[flix_mdblist] %s" % msg, level)


def parse(text):
    """la clave limpia de lo escrito (sin espacios ni saltos al pegar). ValueError(BAD) si no tiene su forma; el
    mensaje nunca repite lo escrito"""
    import flix_ratings
    key = re.sub(r"\s+", "", text or "")
    if not re.fullmatch(flix_ratings.KEY_RE, key):
        raise ValueError(BAD)
    return key


def verify(key, opener=None):
    """UNA petición a la API (/user): «ok» (contesta con la cuenta), «limite» (la clave vale pero hoy no quedan
    consultas: 429), «mala» (401/403: la clave no vale) o «sin_red»"""
    import urllib.error
    import urllib.request
    req = urllib.request.Request(USER_API % key, headers={"User-Agent": UA})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
            raw = r.read(100000)
    except urllib.error.HTTPError as e:
        log("comprobación: HTTP %s" % e.code)
        return "limite" if e.code == 429 else "mala" if e.code in (400, 401, 403) else "sin_red"
    except Exception as e:  # noqa: BLE001  (sin red, lento: solo el tipo; el texto puede llevar la dirección con la clave)
        log("comprobación: %s" % type(e).__name__)
        return "sin_red"
    try:
        d = json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        d = None
    if isinstance(d, dict) and d.get("error"):
        log("comprobación: la API dice que la clave no vale")
        return "mala"
    ok = isinstance(d, dict)
    log("comprobación: %s" % ("vale" if ok else "respuesta rara"))
    return "ok" if ok else "sin_red"


class Store:
    """lo que toca Kodi: la clave y el orden de Notas (flix_ratings)"""

    def key(self):
        import flix_ratings
        return flix_ratings.read_key()

    def save(self, key):
        """guarda la clave (o la quita, '') con el orden de Notas; al vincular, si no había ninguna fuente de MDBList
        encendida antes de TMDB, las de serie (si no, la clave no serviría de nada)"""
        import flix_ratings as fr
        order = fr.read_order(key)
        if key and not fr.chain(order):
            order = list(fr.DEFAULT)
        fr.save_settings(key, order)


def menu(ui, store, verify):
    """el flujo entero. La clave nueva, '' si se desvinculó o None si no cambió nada"""
    if store.key():
        pick = ui.select("MDBList: Vinculada", ["Comprobar", "Desvincular"])
        if pick == 0:
            r = verify(store.key())
            ui.ok({"ok": "MDBList responde: la clave guardada vale.",
                   "limite": "La clave vale, pero hoy ya no quedan consultas. Mañana vuelven las notas.",
                   "mala": "La clave guardada ya no vale. Desvincula y vuelve a vincular con la de mdblist.com.",
                   }.get(r, "No he podido hablar con MDBList. Prueba otra vez en un momento."))
        elif pick == 1 and ui.yesno("¿Desvincular MDBList en este aparato?[CR]Las fichas vuelven a la nota de TMDB; "
                                    "en mdblist.com no se toca nada."):
            store.save("")
            log("MDBList desvinculado")
            ui.notify("MDBList desvinculado")
            return ""
        return None
    if not ui.intro():
        return None
    while True:
        text = ui.input(ASK)
        if not (text or "").strip():
            return None
        try:
            key = parse(text)
        except ValueError as e:
            log("clave con otra forma: no la guardo")
            ui.ok(str(e))
            continue
        r = verify(key)
        if r == "mala":
            ui.ok("MDBList dice que esa clave no vale. Cópiala otra vez de mdblist.com (Preferences → API Access).")
            continue
        if r == "sin_red" and not ui.yesno("No he podido comprobar la clave (sin conexión con MDBList).[CR]"
                                           "¿Guardarla de todos modos?"):
            return None
        store.save(key)
        log("MDBList vinculado%s" % ("" if r in ("ok", "limite") else " (sin comprobar)"))
        ui.notify("MDBList vinculado")
        return key


def make_qr():
    """QR de la página de la clave (la de todos: sin nada del usuario)"""
    import flix_phonekb
    return flix_phonekb.make_qr(SITE)


class _UI:
    def __init__(self):
        import xbmcgui
        self.gui, self.d = xbmcgui, xbmcgui.Dialog()

    def intro(self):
        import xbmcvfs
        import flix_common
        gui = self.gui

        class Intro(gui.WindowXMLDialog):
            go = False

            def onInit(self):
                self.setProperty("md_qr", self.qr)
                self.setProperty("md_url", SHOWN)

            def onClick(self, cid):
                if cid == OPEN:         # táctil: la página en el navegador del móvil; la ventana sigue aquí al volver
                    xbmc.executebuiltin("StartAndroidActivity(,android.intent.action.VIEW,,%s)" % SITE)
                    return
                self.go = cid == CONTINUE
                self.close()

            def onAction(self, action):
                if action.getId() in flix_common.A_BACK:
                    self.close()
        w = Intro("FlixMdblist.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
        try:
            w.qr = make_qr()
        except Exception as e:  # noqa: BLE001  (sin QR la explicación vale igual: la web va escrita)
            log("sin QR: %s" % type(e).__name__)
            w.qr = ""
        w.doModal()
        go = w.go
        del w
        return go

    def input(self, heading):
        if xbmc.getSkinDir().endswith(".touch"):
            import flix_pelis
            # la página local para pegar (el teclado de Kodi en Android no deja)
            return flix_pelis.browser_input(heading, title=HEADING, text=WAIT_TEXT)
        return self.d.input(heading, type=self.gui.INPUT_ALPHANUM)

    def ok(self, text):
        self.d.ok(HEADING, text)

    def yesno(self, text):
        return self.d.yesno(HEADING, text)

    def select(self, heading, options):
        return self.d.select(heading, options)

    def notify(self, text):
        self.d.notification(HEADING, text, time=4000)


def run():
    """el asistente, si no hay otro abierto. La clave nueva, '' (desvinculada) o None (sin cambios)"""
    import xbmcgui
    home = xbmcgui.Window(10000)
    if home.getProperty("flix_mdblist_open"):
        return None
    home.setProperty("flix_mdblist_open", "1")
    try:
        return menu(_UI(), Store(), verify)
    finally:
        home.clearProperty("flix_mdblist_open")


if __name__ == "__main__":
    run()
