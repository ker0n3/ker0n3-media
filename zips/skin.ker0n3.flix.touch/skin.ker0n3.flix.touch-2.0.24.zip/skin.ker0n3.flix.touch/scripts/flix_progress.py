"""✓ y progreso iguales en todas las filas.

La base de vistos de Ker0n3 (addon_data/plugin.video.ker0n3/watched.db; la escribe el addon al parar un vídeo, al
marcar desde el menú y al bajar de Trakt / Simkl) manda; las filas guardadas (rows_cache2.json del skin) llevan el ✓,
el ▶ y la barra del momento en que se pidieron. Este script (solo lee la base):
  · corrige el «resume» / «playcount» de las filas guardadas (fix_rows_cache) y avisa al Inicio, que repinta cuando
    cambia Window(home).Property(flix_progress_wsig); el táctil corrige las suyas (flix_home.sync_progress);
  · tras ver un capítulo, pide otra vez «Series en seguimiento» si alguna serie dejó de estar a medias, y «Seguir
    viendo» si cambió lo que está a medias (mark_row: la misma marca de recarga que pone el servicio del addon).
Se lanza al abrir el Inicio, al cerrar el vídeo y al cerrar el menú; repite la pasada unos segundos después porque
la base se escribe con algo de retraso.
Uso: RunScript(special://skin/scripts/flix_progress.py,home|video|menu)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import sqlite3
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
WATCHED_DB = flix_common.watched_path()
ROWS_CACHE = flix_rows.CACHE_FILE
# las últimas pasadas recogen lo que la base apunta con retraso (el addon guarda tras parar y tras bajar del servicio)
PASSES = {"home": [0, 4, 12, 35], "video": [2, 6, 15, 30], "menu": [1, 3, 8, 15, 25, 40]}
# filas personales del Inicio: (src de la fila TV para flix_rl_<src>, id de la fila para fh_refetch_row). Las mismas
# que marca el servicio del addon (ker0n3/service.py ROWS)
RESUME_ROW = ("FlixPathSeguir", "5101")
FOLLOW_ROW = ("FlixPathSiguiendo", "5102")


_LAST_LOG = [""]


def log(msg):
    xbmc.log("[flix_progress] %s" % msg, xbmc.LOGINFO)
    _LAST_LOG[0] = msg[:500]


def flush_log():
    """la última línea de la pasada en Window(home).Property(flix_progress_log), legible por JSON-RPC (en Fire OS no
    se puede leer kodi.log). Antes se escribía la propiedad en CADA línea (revisión 7-nov PY-31)"""
    if _LAST_LOG[0]:
        HOME.setProperty("flix_progress_log", _LAST_LOG[0])


# ---------- verdad: la base de vistos ----------
def truth():
    """{tmdb(str): (playcount, progress %, runtime s, lastPlayed)}; None si no se puede leer. {} = base sin
    películas (quien solo ve series): NO es «sin watched.db» (auditoría 22-oct B-06)"""
    try:
        return flix_common.watched_movies(WATCHED_DB)
    except Exception as e:  # noqa: BLE001  (p. ej. watched.db vacío sin tablas)
        log("watched.db: %s" % e)
        return None


# Series: vista = playCount 1 (✓), a medias = SHOW_STARTED (▶). La regla está en flix_common (show_rule): el clic en
# una serie la usa sin cargar este módulo (revisión 29-oct DAT-06) y así no hay dos copias.
SHOW_STARTED = flix_common.SHOW_STARTED
show_rule = flix_common.show_rule


def truth_shows():
    """{tmdb(str): playCount que toca a la serie (1 vista, SHOW_STARTED a medias)}; las demás no están"""
    path = flix_common.watched_db(WATCHED_DB)
    if not os.path.exists(path):
        return None
    db = flix_common.watched_connect(path, snapshot=False, timeout=5)
    try:
        eps = {r[0]: (r[1] or 0, r[2] or 0) for r in db.execute(
            "SELECT tmdb_id, SUM(playcount > 0), SUM(progress > 0) FROM episodes_watched GROUP BY tmdb_id")}
        out = {}
        for tmdb, total, complete, hidden in db.execute(
                "SELECT tmdb_id, num_total_episodios, completa, ocultar FROM shows_watched"):
            pc = show_rule(total, complete, hidden, *eps.get(tmdb, (0, 0)))
            if pc:
                out[str(tmdb)] = pc
        return out
    finally:
        db.close()


def show_pc(S, tmdb):
    return (S or {}).get(str(tmdb), 0)


# ---------- fecha de lo último visto de cada serie (etiquetas «NUEVO», flix_newep) ----------
# Lo que baja del servicio puede llegar apuntado con la hora de la SINCRONIZACIÓN (con milésimas: «…07:06:16.863Z») y
# no con la de verdad (siempre «.000Z»): un capítulo así vale con la hora de su llegada, que se guarda aquí
STAMPS_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/p3_sellos.json" % xbmc.getSkinDir())
SEED = "semilla"
_FOLLOW = [0.0, None]


def is_sync_stamp(last):
    """¿hora puesta al sincronizar (milésimas distintas de 0)?"""
    m = re.search(r"\.(\d+)Z$", last or "")
    return bool(m) and int(m.group(1)) != 0


def show_dates(rows, stamps):
    """({tmdb: fecha del último capítulo}, ¿stamps cambió?) de las filas (tmdb, temporada, capítulo, lastPlayed).
    Un capítulo que llega sellado por 1.ª vez (visto en otro aparato) vale con la hora de su llegada, que se guarda
    en stamps: si se vuelve a sellar, se sigue usando esa. Los sellos que ya había al estrenar esto (SEED) no
    cuentan: son los que se repiten en cada sincronización"""
    dates, changed = {}, False
    for tmdb, season, episode, last in rows:
        if not last:
            continue
        if is_sync_stamp(last):
            key = "%s:%s:%s" % (tmdb, season, episode)
            first = stamps.get(key)
            if first is None:
                stamps[key] = first = last
                changed = True
            if first == SEED:
                continue
            last = first
        if last > dates.get(str(tmdb), ""):
            dates[str(tmdb)] = last
    return dates, changed


def follow_dates(max_age=5):
    """{tmdb: fecha de lo último visto} de cada serie (leídas como mucho cada max_age s); None si no se puede"""
    if _FOLLOW[1] is not None and time.time() - _FOLLOW[0] <= max_age:
        return _FOLLOW[1]
    try:
        rows = flix_common.watched_query(WATCHED_DB, "SELECT tmdb_id, season, episode, lastPlayed FROM episodes_watched")
        if rows is None:
            return None
        import flix_cache
        with flix_cache.file_lock(STAMPS_FILE):
            try:
                with open(STAMPS_FILE, encoding="utf-8") as fh:
                    stamps, seed = json.load(fh), False
                if not isinstance(stamps, dict):
                    raise ValueError("no es un diccionario")
            except (OSError, ValueError):
                # 1.ª vez (o fichero roto): lo sellado hasta ahora no dice cuándo se vio
                stamps, seed = {"%s:%s:%s" % r[:3]: SEED for r in rows if is_sync_stamp(r[3])}, True
            dates, changed = show_dates(rows, stamps)
            if seed or changed:
                flix_cache.atomic_write(STAMPS_FILE, json.dumps(stamps))
    except Exception as e:  # noqa: BLE001
        log("orden de Series en seguimiento: %s" % e)
        return None
    _FOLLOW[:] = [time.time(), dates]
    return dates


# ---------- listas JSON-RPC (Inicio, secciones, táctil) ----------
_TRUTH = [0.0, None, None]


def truth_cached(max_age=5):
    """watched.db leída como mucho una vez cada max_age s (una pantalla pide varias filas seguidas) Y otra vez en
    cuanto cambia el fichero: una pasada que llegaba antes de que se guardara dejaba aquí lo viejo y el Inicio
    repintaba con ello al avisarle la pasada siguiente (Spider-Man desmarcado seguía con ✓; Carlos, 24-oct)"""
    sig = watched_sig()
    if _TRUTH[1] is None or time.time() - _TRUTH[0] > max_age or _TRUTH[2] != sig:
        try:
            _TRUTH[:] = [time.time(), truth(), sig]
        except Exception as e:  # noqa: BLE001
            log("watched.db: %s" % e)
            return None
    return _TRUTH[1]


_SHOWS = [0.0, None, None]


def truth_shows_cached(max_age=5):
    sig = watched_sig()
    if _SHOWS[1] is None or time.time() - _SHOWS[0] > max_age or _SHOWS[2] != sig:
        try:
            _SHOWS[:] = [time.time(), truth_shows(), sig]
        except Exception as e:  # noqa: BLE001
            log("watched.db series: %s" % e)
            return None
    return _SHOWS[1]


_MISS = object()     # estado de las series aún sin pedir en esta llamada de fix_files


def fix_files(files, W=None):
    """pone en cada título del addon de una lista de Files.GetDirectory el resume / playcount de la base (series: ✓ y
    ▶); devuelve cuántos cambió"""
    W = truth_cached() if W is None else W
    if W is None or not files:
        return 0
    changed, S = 0, _MISS
    for f in files:
        if not isinstance(f, dict):
            continue
        k3 = flix_common.k3_ref(f.get("file"))
        if not k3:
            continue                    # otros orígenes (NAS, biblioteca…): como vienen
        # los capítulos de «Seguir viendo» (play/capitulo) ya traen su barra de la ruta seguir
        if "/play/capitulo/" in f["file"]:
            continue
        if k3[0] == "tv":
            if S is _MISS:
                # una vez por llamada, al llegar a la 1.ª serie (revisión 29-oct ARR-01/DAT-01)
                S = truth_shows_cached()
            if S is not None and int(f.get("playcount") or 0) != show_pc(S, k3[1]):
                f["playcount"] = show_pc(S, k3[1])
                changed += 1
            continue
        row = W.get(str(k3[1]))
        if row and float(row[1] or 0) > 0 and not float(row[2] or 0):
            continue                    # pausa sin duración apuntada: se queda la barra que dio la ruta
        changed += _fix_movie(f, row)
    return changed


def _fix_movie(f, row):
    """resume/playcount de una película según su fila de la base (None = sin ver); 1 si cambió algo"""
    total = float(row[2] or 0) if row else 0.0
    pos = round(total * float(row[1] or 0) / 100, 3) if row else 0.0
    want_pc = int(row[0] or 0) if row else 0
    old = f.get("resume") or {}
    if abs(float(old.get("position") or 0) - pos) > 1 or int(f.get("playcount") or 0) != want_pc:
        f["resume"], f["playcount"] = {"position": pos, "total": total}, want_pc
        return 1
    return 0


K3_RESUME = "plugin://plugin.video.ker0n3/seguir"


def is_resume_row(path):
    """¿es la fila «Seguir viendo» (ruta seguir del addon, con o sin &reload=)? Sus capítulos llevan «T1 E4»
    (episode_cards) y vacía se esconde. La fila ya viene al día de la base: no hay que quitarle nada"""
    import flix_cache
    return flix_cache.key_of(str(path or "")) == K3_RESUME


EP_KEY = "flix_ep"      # tarjeta de capítulo a medias en «Seguir viendo»: «T1 E4»


EP_DAYS = 30            # y solo si se tocó en los últimos 30 días (lo usa el addon: store.RESUME_DAYS)


K3_EP_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/play/capitulo/(\d+)/(\d+)/(\d+)/?$")


def ep_label(tmdb, s, e):
    """«T1 E4»; en una serie por partes, la numeración de la ficha («T20 E9»: ker0n3.parts.label, solo lo guardado)"""
    try:
        from ker0n3 import parts
        return parts.label(tmdb, s, e)
    except Exception:  # noqa: BLE001
        return "T%d E%d" % (s, e)


def k3_marks(files):
    """«Seguir viendo» del addon (ruta seguir): los capítulos ya vienen en la fila; solo su «T1 E4» (EP_KEY: el clic
    reanuda sin aviso) y, sin duración, la barra sin «Quedan…»"""
    for f in files:
        m = K3_EP_RE.match(str(f.get("file") or "")) if isinstance(f, dict) else None
        if m:
            f[EP_KEY] = ep_label(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            f["flix_untimed"] = not float((f.get("resume") or {}).get("total") or 0)
    return files


def episode_cards(files, follow_files=None, eps=None, movies=None):
    """«Seguir viendo»: los capítulos a medias ya vienen en la fila del addon; se les pone su «T1 E4» (k3_marks).
    follow_files, eps y movies se dejan para quien la llama"""
    return k3_marks(list(files or []))


_ROWS_WROTE = [""]   # huella de rows_cache2.json justo después de escribirlo fix_rows_cache con el cerrojo cogido


def fix_rows_cache(W):
    import flix_cache
    with flix_cache.file_lock(ROWS_CACHE) as lock:  # leer-corregir-escribir sin pisar a flix_rows (B-05)
        try:
            with open(ROWS_CACHE, encoding="utf-8") as fh:
                cache = json.load(fh)
        except Exception:  # noqa: BLE001
            return 0
        changed = 0
        for _key, entry in cache.items():
            if isinstance(entry, list) and len(entry) == 2 and isinstance(entry[1], list):
                changed += fix_files(entry[1], W)
        if changed:
            flix_cache.atomic_write(ROWS_CACHE, json.dumps(cache, ensure_ascii=False))   # temporal único (PY-NUEVO-01)
            if getattr(lock, "fh", None):
                # con el cerrojo nadie ha podido escribir entre medias: lo que hay es lo que acabamos de corregir
                # (sin él, file_lock sigue al cabo de 5 s y la pasada siguiente lo vuelve a mirar) (DAT-04)
                _ROWS_WROTE[0] = file_sig(ROWS_CACHE)
            log("rows_cache: %d películas corregidas" % changed)
    return changed


def watched_sig():
    """huella de watched.db (fecha y tamaño, también del -wal de SQLite): si no cambia, las cachés ya están bien"""
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def file_sig(path):
    """inodo, fecha (ns) y tamaño de un fichero ('-' si no está). atomic_write pone uno nuevo en cada escritura: se
    nota aunque la fecha y el tamaño coincidan"""
    try:
        st = os.stat(path)
        return "%d:%d:%d" % (st.st_ino, st.st_mtime_ns, st.st_size)
    except OSError:
        return "-"


def rows_sig(sig):
    """huella de lo que usa fix_rows_cache (revisión 29-oct DAT-04): watched.db y su -wal (sig, tomada ANTES de leer)
    y rows_cache2.json"""
    return "|".join(sig.split("|")[:2] + [file_sig(ROWS_CACHE)])


# ---------- recargas de las filas personales del Inicio ----------
def mark_row(src, rid, sig):
    """pide al Inicio que vuelva a pedir una fila personal (TV: Window(home).Property(flix_rl_<src>), que mira
    flix_inicio.tick; táctil: fh_refetch_row con el id de la fila). sig = lo que la fila enseñaría según la base
    (shows_sig / resume_sig): si es lo mismo que cuando se marcó la última vez, no se marca (revisión 7-nov PY-02).
    Sin sig (base ilegible) se marca siempre. True si marcó"""
    if sig is not None and sig == HOME.getProperty("flix_rlsig_%s" % src):
        return False
    HOME.setProperty("flix_rlsig_%s" % src, sig or "")
    try:
        cur = int(HOME.getProperty("flix_rl_%s" % src) or 0)
    except ValueError:
        cur = 0
    # siempre distinta de la anterior: dos marcas en la misma décima de segundo salían iguales y el Inicio (que
    # compara el valor) no veía la segunda
    HOME.setProperty("flix_rl_%s" % src, str(max(int(time.time() * 10), cur + 1)))
    ids = [x for x in HOME.getProperty("fh_refetch_row").split(",") if x]
    if rid not in ids:
        HOME.setProperty("fh_refetch_row", ",".join(ids + [rid]))
    return True


def _sig(sql):
    try:
        rows = flix_common.watched_query(WATCHED_DB, sql, snapshot=False)
        return repr(rows) if rows is not None else None
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def shows_sig():
    """series seguidas (no ocultas) + capítulos vistos: si cambian, «Series en seguimiento» está vieja"""
    a = _sig("SELECT tmdb_id FROM shows_watched WHERE NOT ocultar ORDER BY tmdb_id")
    b = _sig("SELECT COUNT(*), MAX(lastPlayed), SUM(progress) FROM episodes_watched")
    return None if a is None or b is None else a + b


def resume_sig():
    """pelis a medias (las de «Seguir viendo») con su playcount: si cambian, la fila del Inicio está vieja"""
    return _sig("SELECT tmdb_id, progress, playcount FROM movies_watched WHERE progress > 0 ORDER BY tmdb_id")


def reload_resume_row():
    """«Seguir viendo» del Inicio otra vez pedida si cambió lo que está a medias (mark_row)"""
    if mark_row(RESUME_ROW[0], RESUME_ROW[1], resume_sig()):
        log("Seguir viendo cambió: recargo la fila")


def refresh_follow():
    """«Series en seguimiento» del Inicio otra vez pedida si cambiaron las series seguidas o lo visto (mark_row)"""
    return mark_row(FOLLOW_ROW[0], FOLLOW_ROW[1], shows_sig())


def one_pass():
    # la huella ANTES de leer watched.db: si se guarda mientras corregimos, la siguiente pasada lo ve (Spider-Man,
    # Shield, 25-oct). El trabajo (rows_cache ~0,7 s por pasada en el S24) solo si la base cambió desde la última vez
    # (REND-05/PY-06; revisión 29-oct DAT-05)
    sig = watched_sig()
    prev = HOME.getProperty("flix_progress_wsig")
    if sig == prev:
        return
    rsig = rows_sig(sig)                # también ANTES de leer
    W = truth()
    if W is None:
        log("sin watched.db en %s" % WATCHED_DB)
        return
    b = 0
    # rows_cache2.json solo depende de watched.db: si desde su última corrección no han cambiado ni watched.db ni el
    # fichero, saldría lo mismo y no se repite (revisión 29-oct DAT-04; 74-110 ms por pasada en proot)
    if rsig != HOME.getProperty("flix_progress_rsig"):
        _ROWS_WROTE[0] = ""
        b = fix_rows_cache(W)
        if b and _ROWS_WROTE[0]:
            rsig = rsig.rsplit("|", 1)[0] + "|" + _ROWS_WROTE[0]     # lo que acaba de escribir ya está bien
        HOME.setProperty("flix_progress_rsig", rsig)
    HOME.setProperty("flix_progress_wsig", sig)
    if b:
        log("pasada: filas corregidas %d" % b)


def started_shows():
    """series seguidas a medias (▶) según watched.db"""
    try:
        return {k for k, v in (truth_shows() or {}).items() if v == SHOW_STARTED}
    except Exception as e:  # noqa: BLE001
        log("series a medias: %s" % e)
        return set()


def episode_just_watched(now=None, window=180):
    """¿la base ha apuntado un capítulo en los últimos 3 min? (lastPlayed en UTC, «2026-10-20T21:56:17.000Z»)"""
    import calendar
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            last = db.execute("SELECT MAX(lastPlayed) FROM episodes_watched").fetchone()[0]
        finally:
            db.close()
        t = calendar.timegm(time.strptime(last[:19], "%Y-%m-%dT%H:%M:%S"))
    except Exception:  # noqa: BLE001
        return False
    return 0 <= (now or time.time()) - t <= window


def follow_check(before):
    """si alguna serie ha dejado de estar a medias (último capítulo visto) se renueva «Series en seguimiento».
    Devuelve las series a medias de ahora."""
    now = started_shows()
    done = before - now
    if done:
        log("series que ya no están a medias: %s -> renuevo Series en seguimiento" % sorted(done))
        refresh_follow()
    return now


def wait_or_again(monitor, secs, step=0.25):
    """espera secs entre pasadas: 'abort' si Kodi se cierra, 'again' si otra llamada pidió pasada (flix_progress_again)
    y '' si se cumplió el tiempo. Antes la petición esperaba a que acabara todo el horario en marcha (hasta 40 s): al
    marcar, la pasada de después de guardar quedaba en cola y la ✓ tardaba en quitarse (Carlos, 24-oct)"""
    end = time.time() + secs
    while True:
        if flix_common.quitting():
            return "abort"          # System.OnQuit (Kodi no avisa por abortRequested a los RunScript sin addon; APA-03)
        if HOME.getProperty("flix_progress_again"):
            return "again"
        left = end - time.time()
        if left <= 0:
            return ""
        if monitor.waitForAbort(min(step, left)):
            return "abort"


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "home"
    busy = HOME.getProperty("flix_progress_busy")
    if busy and time.time() - float(busy or 0) < 60:
        HOME.setProperty("flix_progress_again", mode)
        return
    HOME.setProperty("flix_progress_busy", str(time.time()))
    # se entera del cierre de Kodi (System.OnQuit) mientras espera entre pasadas: antes seguía su horario (hasta 40 s)
    # y Kodi lo mataba a los 5 s (revisión 29-oct APA-03)
    monitor = flix_common.quit_monitor()
    log("inicio (%s)" % mode)
    started = started_shows() if mode == "video" else set()
    # tras ver un capítulo, «Series en seguimiento» se renueva al final: va por lo último visto (Carlos, 20-oct: El
    # Castillo, recién vista, ni salía)
    renew = mode == "video"

    def do_pass():
        nonlocal started
        HOME.setProperty("flix_progress_busy", str(time.time()))
        try:
            one_pass()
            if mode == "video":
                started = follow_check(started)
        except Exception as e:  # noqa: BLE001
            log("error: %s" % e)
        flush_log()

    try:
        while True:
            last = 0
            for t in PASSES.get(mode, PASSES["home"]):
                # waitForAbort(0) no vuelve en algunas versiones: solo se espera si hay algo que esperar
                if t > last:
                    woke = wait_or_again(monitor, t - last)
                    if woke == "abort":
                        return
                    if woke == "again":
                        break           # otra petición (p. ej. «Marcar como no vista» ya guardado): pasada YA
                last = t
                do_pass()
            if renew and episode_just_watched():
                renew = False
                log("capítulo visto: renuevo Series en seguimiento (orden por lo último visto)")
                refresh_follow()
            again = HOME.getProperty("flix_progress_again")
            HOME.clearProperty("flix_progress_again")
            if not again:
                break
            # tras un vídeo se sigue con su horario (follow_check / Series en seguimiento) aunque llegue otra petición
            mode = mode if mode == "video" else again
            HOME.setProperty("flix_progress_busy", str(time.time()))
            try:
                one_pass()                  # al momento: el horario de la nueva petición empieza después
            except Exception as e:  # noqa: BLE001
                log("error: %s" % e)
    finally:
        flush_log()
        HOME.clearProperty("flix_progress_busy")


if __name__ == "__main__":
    main()
