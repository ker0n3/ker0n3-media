# -*- coding: utf-8 -*-
"""Duración y edad de los títulos de las filas (Carlos, 13-nov: en la cabecera del Inicio «después del año debería ir
la duración» y «la edad no siempre aparece»).

Los títulos del addon Ker0n3 traen su edad (mpaa) y su duración; to_listitem solo lee «duration» y algunas filas la
mandan como «runtime»: aquí se completa lo que falte sin pisar lo que ya tiene. Cualquier fallo no cambia nada."""


def complete(li, f):
    """pone en la carátula lo que le falte: la edad (de la fila) y la duración de las películas («duration» o
    «runtime»). Nunca pisa lo que ya tiene"""
    try:
        has_dur = bool(f.get("duration"))           # la que ya puso to_listitem
        if li.getProperty("FlixAge") and has_dur:
            return
        import flix_age
        age = li.getProperty("FlixAge") or flix_age.normalize(f.get("mpaa") or "")
        dur = int(f.get("duration") or f.get("runtime") or 0)
        if age and not li.getProperty("FlixAge"):
            li.setProperty("FlixAge", age)
        if dur and not has_dur:
            li.getVideoInfoTag().setDuration(dur)
    except Exception:  # noqa: BLE001
        pass
