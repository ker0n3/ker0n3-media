"""Secciones del menú: barra lateral de la TV (Home.xml, lista 9000: Inicio + 14 huecos fijos) y tarjetas de arriba de
la táctil (flix_home.py, las 7 primeras). Qué secciones salen, en qué orden y qué filas lleva cada una lo decide
flix_sections_conf (sections.json, por aparato); apply() lo copia a Window(home).Property(flix_sec<N>_*) y
flix_chip<N>, que es lo que pintan los huecos: el menú cambia al momento, sin recargar el skin.
Uso: RunScript(special://skin/scripts/flix_sections.py)              -> editor único (flix_editor.py,menu)
     RunScript(special://skin/scripts/flix_sections.py,apply)        -> rellena el menú (Home.xml si no lo está)
     RunScript(special://skin/scripts/flix_sections.py,open,<clave>) -> abre una sección de rejilla (Series en
                                                                        seguimiento, Películas no finalizadas…)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import flix_sections_conf  # noqa: E402

CONF_NAME = "sections.json"


def setting(key):
    """ajuste viejo (antes de sections.json) que ocultaba una sección de serie"""
    return "flix_hide_%s" % key


def hidden_now():
    import xbmc
    return {d["key"] for d in flix_sections_conf.DEFAULTS
            if xbmc.getCondVisibility("Skin.HasSetting(%s)" % setting(d["key"]))}


def conf_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/%s" % (xbmc.getSkinDir(), CONF_NAME))


def load_conf():
    import json
    try:
        with open(conf_path(), encoding="utf-8") as fh:
            raw = json.load(fh)
    except OSError:
        return flix_sections_conf.default_conf(hidden_now())     # sin fichero: lo de siempre (y flix_hide_<clave>)
    except ValueError as e:
        import xbmc
        xbmc.log("[flix_sections] %s ilegible (%s): secciones de serie" % (CONF_NAME, e), xbmc.LOGWARNING)
        return flix_sections_conf.default_conf(set())
    return flix_sections_conf.normalize(raw)


def save_conf(conf):
    import json
    from flix_common import atomic_write     # temporal único (antes «.tmp» fijo) (revisión 29-oct ARR-13/DAT-15)
    atomic_write(conf_path(), json.dumps(conf, ensure_ascii=False, indent=1))


def own_list(s):
    """la ruta propia de una sección de rejilla («Series en seguimiento», «Películas no finalizadas»); '' si no la tiene"""
    import flix_sections_own
    return flix_sections_own.list_path(s.get("src", "")) if s.get("kind") == "list" else ""


def own_ok(s):
    """¿sale la sección? Las de menú propio, si tienen filas (Trakt, solo en uso); las de rejilla propia, sí; las de
    «Otros orígenes» (biblioteca, NAS, otros complementos), sí. Una de antes sin migrar (sin equivalente), no"""
    import flix_sections_own as so
    src = s.get("src", "")
    if so.own_var(src):
        import flix_rows
        return bool(flix_rows.own_menu(src))
    if so.list_path(src):
        return True
    return "://" in src or src.startswith("/")


def shown_sections(conf):
    """las secciones que salen en el menú: las activas que tienen de dónde salir (own_ok). Leer no toca la
    configuración"""
    return [s for s in flix_sections_conf.active(conf) if own_ok(s)]


def effective_rows(var, rconf, **kw):
    """filas que salen en la sección: su menú (flix_rows.section_rows) con lo elegido en «Editar filas» (apply_rows)"""
    import flix_rows
    return flix_sections_conf.apply_rows(flix_rows.section_rows(var, **kw), rconf or {})


def menu_props(conf, resolve=None):
    """{propiedad: valor} del menú: huecos flix_sec<N>_* (TV) y flix_chip<N> (táctil, los TOUCH_MAX primeros)"""
    act = shown_sections(conf)
    out = {}
    for n in range(1, flix_sections_conf.MAX_SECTIONS + 1):
        s = act[n - 1] if n <= len(act) else {}
        out.update({"flix_sec%d_label" % n: flix_sections_conf.shown(s) if s else "", "flix_sec%d_icon" % n: s.get("icon", ""),
                    "flix_sec%d_kind" % n: s.get("kind", ""), "flix_sec%d_key" % n: s.get("key", "")})
        out["flix_chip%d" % n] = flix_sections_conf.shown(s) if s and n <= flix_sections_conf.TOUCH_MAX else ""
    return out


def apply(conf=None):
    import xbmcgui
    conf = conf or load_conf()
    home = xbmcgui.Window(10000)
    for k, v in menu_props(conf).items():
        home.setProperty(k, v)
    home.setProperty("flix_sec_ok", "1")        # Home.xml: si falta (skin recién instalado) lo pide al cargar
    return shown_sections(conf)


def chips_props():
    """táctil: tarjetas de arriba (flix_chip<N>) = las primeras secciones activas"""
    return apply()[:flix_sections_conf.TOUCH_MAX]


def section(key, conf=None):
    """sección por clave; también por su menú (own:…)"""
    secs = (conf or load_conf())["sections"]
    return next((s for s in secs if s["key"] == key), None) or next((s for s in secs if s["src"] == key), None)


def src_path(s):
    """ruta de una sección de «Otros orígenes» (library://, sources://, smb://, special://…), tal cual"""
    src = s.get("src", "")
    return src if "://" in src or src.startswith("/") else ""


def open_one_row(title, path):
    """una ruta del addon como sección de una fila (como «Ver más»: ficha, tráiler y menú de siempre), en otro
    intérprete: flix_section.py en la TV, flix_home.py en la táctil"""
    import json
    import xbmc
    import xbmcgui
    xbmcgui.Window(10000).setProperty("flix_similar", json.dumps(
        {"title": title, "rows": [{"label": title, "path": path, "kind": "list"}], "menu": True}))
    script = "flix_home.py" if xbmc.getSkinDir().endswith(".touch") else "flix_section.py"
    xbmc.executebuiltin("RunScript(special://skin/scripts/%s,similar)" % script)


def open_list(key):
    """sección de rejilla (Series en seguimiento, Películas no finalizadas…): la propia, como sección de una fila (en
    la rejilla de Kodi una película se reproducía sin ficha; bloques 4 y 5); la de otro origen, en la ventana Vídeos"""
    import xbmc
    import xbmcgui
    s = section(key)
    own = own_list(s) if s else ""
    if own:
        open_one_row(flix_sections_conf.shown(s), own)
        return
    path = src_path(s) if s else ""
    if not path:
        xbmc.log("[flix_sections] sección %s sin ruta" % key, xbmc.LOGWARNING)
        return
    xbmcgui.Window(10000).setProperty("flix_section", flix_sections_conf.shown(s))     # cabecera de la ventana Vídeos
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)


def log(msg):
    import xbmc
    xbmc.log("[flix_sections] %s" % msg, xbmc.LOGINFO)


def rows_conf(items):
    """[(etiqueta, encendida)] del editor de filas -> {"order", "off"} de sections.json"""
    return {"order": [l for l, _ in items], "off": [l for l, on in items if not on]}


def count_text(n, touch):
    if touch and n > flix_sections_conf.TOUCH_MAX:
        return "%d de %d · en el móvil se ven %d" % (n, flix_sections_conf.MAX_SECTIONS, flix_sections_conf.TOUCH_MAX)
    return "%d de %d secciones" % (n, flix_sections_conf.MAX_SECTIONS)


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "open":
        open_list(sys.argv[2])
    elif len(sys.argv) > 1 and sys.argv[1] == "apply":
        apply()
    else:
        import flix_editor
        flix_editor.run("menu")          # acceso viejo (Ajustes de antes)
