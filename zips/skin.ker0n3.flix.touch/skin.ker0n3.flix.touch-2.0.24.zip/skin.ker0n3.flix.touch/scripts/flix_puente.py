# -*- coding: utf-8 -*-
"""Paso de las skins con el nombre interno viejo a las nuevas (2.0.0, 17-nov; docs/arquitectura-skin-addon.md):
  skin.palantir.flix        → skin.ker0n3.flix          (Ker0n3 Media TV)
  skin.palantir.flix.touch  → skin.ker0n3.flix.touch    (Ker0n3 Media Táctil)

Va en las dos familias de skins (es el mismo código) y hace cosas distintas según el id de la skin en uso:

* PUENTE (skin vieja, última versión 1.7.44 / 1.3.45 = la skin nueva completa con el id viejo y la nueva como
  dependencia en su addon.xml, para que Kodi la instale desde el repositorio). first_run lanza run() en un hilo, una
  vez por aparato:
    1. si la skin nueva no está instalada (o está desactivada y no se puede activar), nada: se reintenta en el
       siguiente arranque y la vieja sigue funcionando;
    2. copia addon_data/<vieja>/ entero a addon_data/<nueva>/ (settings.xml con los ajustes de la skin incluido;
       permisos y fechas si el sistema deja; se copia en una carpeta temporal y se renombra al final). Si la nueva ya tiene
       datos, no se pisa nada. Las claves (pelis.json, alldebrid.json…) se copian tal cual y NUNCA salen en el registro:
       solo cuántos ficheros;
    3. cambia Kodi a la skin nueva (JSON-RPC Settings.SetSettingValue lookandfeel.skin) y contesta «Sí» al «¿Mantener
       el cambio?» que Kodi saca entonces (confirm_keep, aislado para probarlo en un aparato);
    4. si la nueva se queda puesta, deja la marca (MARCA_HECHO en la carpeta de la vieja) y una línea en el registro.
       Si no se queda (nadie pudo contestar, otra ventana…), se reintenta en el siguiente arranque, como mucho
       MAX_TRIES veces; después, un aviso y nada más (la puente es la skin completa: la tele sigue sirviendo).
* RED DE SEGURIDAD (skin nueva). Al instalarse la nueva como dependencia de la puente (actualización en segundo
  plano) Kodi puede preguntar «¿Cambiar a esta skin?» (CSkinInfo::OnPostInstall). Si alguien dice Sí, la nueva
  arranca antes de que la puente haya copiado nada: adopt(), lo primero de first_run, trae de la vieja lo que falte
  (sin pisar) y pasa sus ajustes de skin con Skin.SetString / Skin.SetBool (el settings.xml ya está cargado en Kodi:
  copiarlo encima no serviría). Una vez por aparato (MARCA_DATOS en la carpeta de la nueva, que también deja la
  puente al copiar); con la marca, una sola comprobación de disco por arranque.
"""
import json
import os
import shutil
import time

PUENTE = {"skin.palantir.flix": "skin.ker0n3.flix", "skin.palantir.flix.touch": "skin.ker0n3.flix.touch"}
VIEJA = {v: k for k, v in PUENTE.items()}
MARCA_HECHO = "puente_hecho.json"   # en addon_data/<vieja>/: {"hecho": bool, "intentos": n, …}
MARCA_DATOS = "puente_datos.json"   # en addon_data/<nueva>/: los datos de la vieja ya están aquí (o no había)
MARCAS = (MARCA_HECHO, MARCA_DATOS)
MAX_TRIES = 3
SETTING = "lookandfeel.skin"
# Kodi 21 (xbmc/application/ApplicationSkinHandling.cpp): al cambiar lookandfeel.skin, también por JSON-RPC,
# OnSettingChanged manda «ReloadSkin(confirm)»; ReloadSkin carga la nueva y saca ShowYesNoDialogText(13123, 13111, …,
# 10000): «¿Mantener el cambio?» con cierre solo a los 10 s; todo lo que no sea Sí vuelve a la skin vieja. Con Sí activa
# la ventana de arranque (Startup.xml de la nueva → su first_run)
KEEP_HEADING = 13123
YES_BUTTON = 11             # CONTROL_YES_BUTTON (xbmc/dialogs/GUIDialogBoxBase.h); el título es el control 1
KEEP_WAIT = 25.0            # s: lo que se espera a que salga el diálogo tras pedir el cambio
VERIFY_AFTER = 12.0         # s: pasado el cierre solo (10 s) de Kodi, ¿sigue puesta la nueva?
READY_MAX = 90.0
# el Inicio es una ventana Python encima de Home (TV: FlixInicio.xml de flix_inicio.py; táctil: FlixHome.xml de
# flix_home.py): con ella a la vista Window.IsActive(home) es falso (Fire TV 17-nov: «el Inicio no llegó a estar libre»)
INICIO = "Window.IsActive(home) | Window.IsVisible(FlixInicio.xml) | Window.IsVisible(FlixHome.xml)"            # s: lo que se espera a que el Inicio esté a la vista (sin intro ni vídeo) antes de cambiar


def log(msg, warn=False):
    try:
        import xbmc
        xbmc.log("[flix_puente] %s" % msg, xbmc.LOGWARNING if warn else xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def data_dir(skin, translate=None):
    if translate is None:
        import xbmcvfs
        translate = xbmcvfs.translatePath
    return translate("special://profile/addon_data/%s/" % skin)


def has_data(d):
    """¿hay algo (que no sea una marca nuestra) en la carpeta?"""
    try:
        return any(e.name not in MARCAS for e in os.scandir(d))
    except OSError:
        return False


def _read(path):
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
        return True
    except OSError as e:
        log("no puedo escribir la marca %s: %s" % (os.path.basename(path), e), warn=True)
        return False


def _fix_paths(root, old, new):
    """las rutas addon_data/<vieja>/ escritas dentro de los .json/.xml copiados pasan a la nueva (sin tocar nada
    más; el modo del fichero se mantiene). Cuántos ficheros cambian"""
    a, b = "addon_data/%s/" % old, "addon_data/%s/" % new
    n = 0
    for dirpath, _dirs, files in os.walk(root):
        for f in files:
            if not f.endswith((".json", ".xml")):
                continue
            p = os.path.join(dirpath, f)
            try:
                with open(p, encoding="utf-8") as fh:
                    s = fh.read()
            except (OSError, ValueError):
                continue
            if a in s:
                with open(p, "w", encoding="utf-8") as fh:      # mismo fichero: conserva sus permisos
                    fh.write(s.replace(a, b))
                n += 1
    return n


def _count(root):
    return sum(len(files) for _d, _s, files in os.walk(root))


def _copy_file(a, b):
    """el contenido siempre; permisos y fechas si se puede. En el almacenamiento de Android (Fire TV 17-nov) chmod y
    utime fallan con PermissionError: con copy2/copytree eso tumbaba la copia entera («no he podido copiar (Error)»)"""
    shutil.copyfile(a, b)
    try:
        shutil.copystat(a, b)
    except OSError:
        pass


def _copy_tree(src, dst):
    """copytree sin marcas y sin depender de copystat (ver _copy_file)"""
    for dirpath, _dirs, files in os.walk(src):
        to_dir = os.path.normpath(os.path.join(dst, os.path.relpath(dirpath, src)))
        os.makedirs(to_dir, exist_ok=True)
        for f in files:
            if f not in MARCAS:
                _copy_file(os.path.join(dirpath, f), os.path.join(to_dir, f))


def copy_data(src, dst, old="", new=""):
    """copia src entero a dst si dst no tiene datos. Ficheros copiados; 0 si src no existe o está vacía; -1 si dst ya
    tenía datos (no se pisa nada). Se copia a <dst>.copiando y se renombra: nunca queda una copia a medias en dst"""
    src, dst = src.rstrip("/\\"), dst.rstrip("/\\")
    if not has_data(src):
        return 0
    if has_data(dst):
        return -1
    tmp = dst + ".copiando"
    shutil.rmtree(tmp, ignore_errors=True)
    _copy_tree(src, tmp)
    if old and new:
        _fix_paths(tmp, old, new)
    n = _count(tmp)
    if os.path.isdir(dst):
        shutil.rmtree(dst)      # sin datos: como mucho, una marca nuestra (se vuelve a escribir)
    os.replace(tmp, dst)
    return n


def merge_missing(src, dst, skip=("settings.xml",)):
    """red de seguridad: copia de src lo que no esté en dst (sin pisar nada; settings.xml aparte). Cuántos"""
    n = 0
    src = src.rstrip("/\\")
    for dirpath, _dirs, files in os.walk(src):
        rel = os.path.relpath(dirpath, src)
        for f in files:
            if f in MARCAS or (rel == "." and f in skip):
                continue
            to = os.path.normpath(os.path.join(dst, rel, f))
            if os.path.exists(to):
                continue
            os.makedirs(os.path.dirname(to), exist_ok=True)
            _copy_file(os.path.join(dirpath, f), to)
            n += 1
    return n


def skin_settings(path):
    """[(id, tipo, valor)] del settings.xml de una skin (Kodi: <settings><setting id="…" type="bool|string">…)"""
    import xml.etree.ElementTree as ET
    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError):
        return []
    out = []
    for s in root.iter("setting"):
        sid = s.get("id") or ""
        if sid:
            out.append((sid, (s.get("type") or "string").lower(), s.text or ""))
    return out


def apply_settings(items, builtin):
    """los ajustes de la skin vieja, con builtins (Kodi ya tiene cargados los de la nueva). Cuántos"""
    import flix_builtin
    n = 0
    for sid, typ, val in items:
        if typ == "bool":
            if val.strip().lower() == "true":
                builtin("Skin.SetBool(%s)" % sid)
                n += 1
        elif val:
            builtin("Skin.SetString(%s,%s)" % (sid, flix_builtin.quote(val)))
            n += 1
    return n


# ---------- Kodi ----------
def rpc(method, params=None):
    import xbmc
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params or {}})))
    except (TypeError, ValueError):
        return {}
    return r if isinstance(r, dict) else {}


def current_skin(call=rpc):
    return ((call("Settings.GetSettingValue", {"setting": SETTING}) or {}).get("result") or {}).get("value") or ""


def ensure_installed(skin, call=rpc):
    """¿está instalada y activada? Si está desactivada, se activa. False: aún no (Kodi la instalará del repositorio)"""
    r = call("Addons.GetAddonDetails", {"addonid": skin, "properties": ["enabled", "version"]})
    addon = (r.get("result") or {}).get("addon") or {}
    if not addon:
        return False
    if addon.get("enabled") is False:
        call("Addons.SetAddonEnabled", {"addonid": skin, "enabled": True})
        r = call("Addons.GetAddonDetails", {"addonid": skin, "properties": ["enabled"]})
        return bool(((r.get("result") or {}).get("addon") or {}).get("enabled"))
    return True


def confirm_keep(new, timeout=KEEP_WAIT, cond=None, label=None, localize=None, builtin=None, sleep=None,
                 now=time.time, current=None):
    """Contesta «Sí» al «¿Mantener el cambio?» de Kodi tras cambiar de skin. AISLADO para probarlo en un aparato.

    Espera (hasta timeout s) a que esté abierto el diálogo Sí/No (ventana yesnodialog, DialogConfirm.xml de la skin
    NUEVA, que ya está cargada) y solo si es ESE diálogo (título, control 1, = $LOCALIZE[13123]; si el título no se
    puede leer: la skin puesta ya es la nueva) manda SendClick(yesnodialog,11), el botón Sí. True si lo pulsó y el
    diálogo se cerró. Si no sale (Kodi que no pregunte) o es otro, False sin tocar nada"""
    if cond is None:
        import xbmc
        cond, label, localize, builtin = (xbmc.getCondVisibility, xbmc.getInfoLabel, xbmc.getLocalizedString,
                                          xbmc.executebuiltin)
        sleep = sleep or (lambda s: xbmc.sleep(int(s * 1000)))
    sleep = sleep or time.sleep
    current = current or current_skin
    want = (localize(KEEP_HEADING) or "").strip()
    t0 = now()
    while now() - t0 < timeout:
        if cond("Window.IsActive(yesnodialog)"):
            head = (label("Control.GetLabel(1)") or "").strip()
            if (head and want and head == want) or (not head and current() == new):
                log("contesto «Sí» a «%s»" % (head or "¿Mantener el cambio?"))
                builtin("SendClick(yesnodialog,%d)" % YES_BUTTON)
                for _ in range(30):
                    sleep(0.1)
                    if not cond("Window.IsActive(yesnodialog)"):
                        return True
                return False
            if head:
                log("hay un Sí/No abierto que no es el del cambio de skin («%s»): no lo toco" % head, warn=True)
                return False
        sleep(0.2)
    return False


def switch_skin(new, call=rpc, keep=confirm_keep, sleep=None, verify_after=VERIFY_AFTER):
    """cambia Kodi a la skin `new` y confirma el cambio. True si al final sigue puesta"""
    if sleep is None:
        try:
            import xbmc
            sleep = xbmc.Monitor().waitForAbort         # si Kodi se cierra mientras, no se le hace esperar
        except Exception:  # noqa: BLE001
            sleep = time.sleep
    r = call("Settings.SetSettingValue", {"setting": SETTING, "value": new})
    if "error" in r:
        log("Kodi no acepta %s como skin: %s" % (new, r.get("error")), warn=True)
        return False
    clicked = keep(new)
    sleep(verify_after)
    now_skin = current_skin(call)
    log("cambio a %s: «Sí» %s; skin puesta ahora: %s" % (new, "pulsado" if clicked else "no pulsado", now_skin or "?"))
    return now_skin == new


def _ui_ready(cond, sleep, limit=READY_MAX, quit_fn=None):
    """espera a que el Inicio esté a la vista (INICIO): sin intro (flix_boot), sin vídeo ni diálogos. Al
    arrancar, con Startup abierta, Kodi no recarga la skin (comentario de Startup.xml)"""
    t0 = time.time()
    while time.time() - t0 < limit:
        if quit_fn and quit_fn():
            return False
        if (cond(INICIO) and not cond("System.HasActiveModalDialog") and not cond("Player.HasMedia")
                and not cond("!String.IsEmpty(Window(home).Property(flix_boot))")):
            return True
        sleep(1.0)
    return False


def run(skin=None, translate=None, call=rpc, switch=switch_skin, ready=None, notify=None):
    """el puente (solo en la skin vieja). Devuelve qué pasó: «no» (no es una skin vieja), «hecho», «agotado»,
    «sin_nueva», «sin_inicio», «cambiada» o «reintentar»"""
    if skin is None:
        import xbmc
        skin = xbmc.getSkinDir()
    new = PUENTE.get(skin)
    if not new:
        return "no"
    old_dir, new_dir = data_dir(skin, translate), data_dir(new, translate)
    marca = os.path.join(old_dir, MARCA_HECHO)
    st = _read(marca)
    if st.get("hecho"):
        return "hecho"
    tries = int(st.get("intentos") or 0)
    if tries >= MAX_TRIES:
        if not st.get("avisado"):
            st["avisado"] = True
            _write(marca, st)
            log("%s → %s: %d intentos sin quedarse la nueva; no lo vuelvo a intentar solo" % (skin, new, tries),
                warn=True)
            (notify or _notify)("No he podido pasar solo a la skin nueva. Todo sigue funcionando igual; si puedes, "
                                "dímelo.")
        return "agotado"
    if not ensure_installed(new, call):
        log("%s aún no está instalada: lo intento en el siguiente arranque (sigo con %s)" % (new, skin))
        return "sin_nueva"
    if ready is None:
        import xbmc
        mon = xbmc.Monitor()
        ready = lambda: _ui_ready(xbmc.getCondVisibility, lambda s: mon.waitForAbort(s),       # noqa: E731
                                  quit_fn=mon.abortRequested)
    if not ready():
        log("el Inicio no llegó a estar libre: lo intento en el siguiente arranque")
        return "sin_inicio"
    try:
        n = copy_data(old_dir, new_dir, skin, new)
    except OSError as e:
        log("no he podido copiar los datos a %s (%s): lo intento en el siguiente arranque" % (new, type(e).__name__),
            warn=True)
        return "reintentar"
    marca_datos = os.path.join(new_dir, MARCA_DATOS)
    if n < 0 and not os.path.exists(marca_datos):
        # la nueva tiene algo pero nadie le trajo los datos (Kodi pudo dejar ahí sus ajustes por defecto al instalarla):
        # se trae lo que falte sin pisar y SIN marca, para que la red de seguridad de la nueva (adopt, al arrancar
        # ella) pase los ajustes de la vieja con Skin.SetString/SetBool. Si no, se perderían ajustes y claves
        try:
            log("la nueva ya tenía algo sin marca: traigo %d ficheros que le faltaban" % merge_missing(old_dir, new_dir))
        except OSError as e:
            log("no he podido completar %s (%s)" % (new, type(e).__name__), warn=True)
    elif n >= 0:
        # que la red de seguridad de la nueva no vuelva a traer nada
        _write(marca_datos, {"desde": skin, "ficheros": n, "hora": int(time.time()), "por": "puente"})
    st.update(intentos=tries + 1, ultimo=int(time.time()))
    _write(marca, st)
    log("%s → %s: %s; cambio de skin (intento %d de %d)" % (
        skin, new, "%d ficheros copiados" % n if n > 0 else "la nueva ya tenía datos: no copio nada" if n < 0 else
        "no había datos que copiar", tries + 1, MAX_TRIES))
    if switch(new):
        st.update(hecho=True, hora=int(time.time()))
        _write(marca, st)
        log("HECHO: Kodi usa ya %s (los datos de %s están en addon_data/%s)" % (new, skin, new))
        return "cambiada"
    log("la skin nueva no se quedó puesta: lo intento en el siguiente arranque", warn=True)
    return "reintentar"


def adopt(skin=None, translate=None, builtin=None):
    """red de seguridad en la skin NUEVA (lo primero de first_run). «no», «hecho», «nada» o «traidos»"""
    if skin is None:
        import xbmc
        skin = xbmc.getSkinDir()
    old = VIEJA.get(skin)
    if not old:
        return "no"
    new_dir = data_dir(skin, translate)
    marca = os.path.join(new_dir, MARCA_DATOS)
    if os.path.exists(marca):
        return "hecho"
    old_dir = data_dir(old, translate)
    if not has_data(old_dir):
        _write(marca, {"desde": old, "ficheros": 0, "hora": int(time.time()), "por": "nueva"})
        return "nada"
    if builtin is None:
        import xbmc
        builtin = xbmc.executebuiltin
    try:
        n = merge_missing(old_dir, new_dir)
        k = apply_settings(skin_settings(os.path.join(old_dir.rstrip("/\\"), "settings.xml")), builtin)
    except OSError as e:
        log("no he podido traer los datos de %s (%s)" % (old, type(e).__name__), warn=True)
        return "error"
    _write(marca, {"desde": old, "ficheros": n, "ajustes": k, "hora": int(time.time()), "por": "nueva"})
    log("arranco sin pasar por el puente: traigo de %s %d ficheros y %d ajustes de la skin" % (old, n, k))
    return "traidos"


RETIRE_AFTER = 3600     # s con la nueva puesta (desde que llegaron los datos, MARCA_DATOS) antes de retirar las puentes


def retire(skin=None, translate=None, call=rpc, now=time.time):
    """skin NUEVA (18-nov, Carlos: «¿por qué siguen apareciendo las viejas?»): las puentes se quedan instaladas tras el
    paso y salen repetidas en el selector de skins con el mismo nombre. Se DESACTIVAN (no se borran: se pueden volver a
    activar en Mis complementos) solo si: Kodi usa ya esta skin nueva hace más de RETIRE_AFTER (paso hecho y
    confirmado), la puente no es la skin en uso y su skin nueva ya está instalada (si no, la puente aún tendría que
    llevar a alguien a ella). En un aparato que aún no ha pasado manda la vieja: esto ni se ejecuta. Devuelve las
    retiradas"""
    if skin is None:
        import xbmc
        skin = xbmc.getSkinDir()
    if skin not in VIEJA or current_skin(call) != skin:
        return []
    st = _read(os.path.join(data_dir(skin, translate), MARCA_DATOS))
    try:
        since = float(st.get("hora") or 0)
    except (TypeError, ValueError):
        since = 0.0
    if not st or not since or now() - since < RETIRE_AFTER:
        return []
    out = []
    for old, new in sorted(PUENTE.items()):
        if old == skin:
            continue
        a = ((call("Addons.GetAddonDetails", {"addonid": old, "properties": ["enabled"]}).get("result") or {})
             .get("addon") or {})
        if not a or a.get("enabled") is False:
            continue
        if new != skin:
            b = ((call("Addons.GetAddonDetails", {"addonid": new, "properties": ["enabled"]}).get("result") or {})
                 .get("addon") or {})
            if not b:
                continue
        call("Addons.SetAddonEnabled", {"addonid": old, "enabled": False})
        out.append(old)
    if out:
        log("puentes desactivadas (ya no hacen falta y salían repetidas en el selector de skins): %s" % ", ".join(out))
    return out


def _notify(msg):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification("KER0N3 MEDIA", msg, xbmcgui.NOTIFICATION_INFO, 8000)
    except Exception:  # noqa: BLE001
        pass
