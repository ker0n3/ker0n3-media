"""Botón "Siguiente capítulo" del OSD y del aviso: salta a 2 s del final y deja que el capítulo ACABE. Al terminar,
flix_follow pone el siguiente (flix_upnext_choice = next): el mismo camino que cuando el capítulo acaba por sí mismo."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re

import xbmc
import xbmcgui

player = xbmc.Player()
episode = bool(xbmc.getInfoLabel("VideoPlayer.Episode")) or re.search(r"\d+x\d+", xbmc.getInfoLabel("Player.Title")) is not None
if not episode and xbmc.getCondVisibility("Integer.IsGreater(Playlist.Length(video),1)"):
    xbmc.executebuiltin("PlayerControl(Next)")      # lista de reproducción normal (otro origen)
elif player.isPlayingVideo():
    total = player.getTotalTime()
    if total > 10:
        xbmcgui.Window(10000).setProperty("flix_upnext_choice", "next")   # flix_follow.py pone el siguiente
        player.seekTime(total - 2)
        xbmc.log("[flix_next] salto al final (%.0f s) -> siguiente capítulo" % total, xbmc.LOGINFO)
