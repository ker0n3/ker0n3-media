# -*- coding: utf-8 -*-
"""Paso a las fuentes propias, una vez por aparato (publicación del 16-nov; marca Skin.HasSetting(flix_estreno_ok)).

Lo lanza Home.xml mientras falte la marca (después no se abre ni el intérprete). Quien ya tenía AllDebrid vinculado en
Palantir no tiene que volver a vincularlo: si la skin no tiene clave propia (alldebrid.json, flix_alldebrid) y el ajuste
«Alldebrid_apikey» de Palantir sí, se copia y «Ajustes → Cuentas» pasa a decir «Vinculado» (el nombre de la cuenta lo
pone «Comprobar»: aquí no se usa la red). Si no hay clave en ningún sitio, un aviso, una sola vez, con el Inicio libre.
La clave va del ajuste al fichero y a ningún sitio más: ni al registro, ni a un diálogo, ni a una propiedad."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re
import time

import xbmc

DONE = "flix_estreno_ok"            # Skin.HasSetting: hecho en este aparato (Home.xml ya no lanza el script)
BUSY = "flix_estreno"               # Window(10000): hay uno en marcha
OLD_ADDON, OLD_SETTING = "plugin.video.palantir3", "Alldebrid_apikey"
AD_USER, LINKED = "k3_ad_user", "Vinculado"         # = adlink.USER / adlink.LINKED del addon (test_estreno_fuentes)
NOTICE = "Vincula AllDebrid en Ajustes → Cuentas para poder ver"
WAIT_IDLE = 90                      # s esperando a que el Inicio esté a la vista y sin nada encima
_KEY = re.compile(r"^[!-~]{8,128}$")        # una clave va en una cabecera HTTP: sin espacios ni caracteres raros


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[flix_estreno] %s" % msg, level)


def old_key():
    """la clave que guardó Palantir (RuntimeError si no está instalado: lo recoge migrate)"""
    import xbmcaddon
    return xbmcaddon.Addon(OLD_ADDON).getSetting(OLD_SETTING)


def migrate(api, read_old, run, saved=""):
    """«ya» (la skin tiene clave), «copiada» (la de Palantir, guardada), «sin_clave» o «error» (no se pudo guardar).
    saved: lo apuntado en Skin.String(k3_ad_user)"""
    if api.load_key():
        return "ya"
    try:
        key = (read_old() or "").strip()
    except Exception as e:  # noqa: BLE001  (Palantir sin instalar o sin ese ajuste)
        log("sin ajustes de Palantir (%s)" % type(e).__name__)
        return "sin_clave"
    if not key:
        return "sin_clave"
    if not _KEY.match(key):
        log("la clave de AllDebrid de Palantir no tiene forma de clave: no la copio", xbmc.LOGWARNING)
        return "sin_clave"
    try:
        api.save_key(key)
    except Exception as e:  # noqa: BLE001  (solo el tipo: el texto del fallo no va al registro)
        log("no he podido guardar la clave de AllDebrid (%s)" % type(e).__name__, xbmc.LOGWARNING)
        return "error"
    if not saved:
        run("Skin.SetString(%s,%s)" % (AD_USER, LINKED))
    log("clave de AllDebrid copiada de Palantir: no hace falta volver a vincular")
    return "copiada"


def run_once(home, migrate, run, notice, wait_idle, quitting):
    """el paso entero. La marca se pone cuando ya no queda nada por hacer: con clave (propia o copiada) o con el
    aviso enseñado. Si el Inicio no llega a estar libre o no se pudo guardar, queda para la próxima vez"""
    if home.getProperty(BUSY):
        return None
    home.setProperty(BUSY, "1")
    try:
        result = migrate()
        if result == "sin_clave":
            if quitting() or not wait_idle():
                log("sin clave de AllDebrid; el aviso queda para otra vez (Inicio ocupado)")
                return result
            notice()
            log("sin clave de AllDebrid: aviso enseñado")
        elif result == "error":
            return result
        run("Skin.SetBool(%s)" % DONE)
        return result
    finally:
        home.clearProperty(BUSY)


def main():
    import xbmcgui
    import flix_alldebrid
    import flix_common
    home = xbmcgui.Window(10000)
    mon = flix_common.quit_monitor()

    def wait_idle():
        import flix_telegram
        end = time.time() + flix_common.INTRO_MAX + WAIT_IDLE
        while not (flix_telegram.idle() and not home.getProperty(flix_common.BOOT)
                   and flix_common.popup_take(home, "estreno")):
            if time.time() > end or flix_common.wait_quit(mon, 2):
                return False
        return True

    def notice():
        try:
            xbmcgui.Dialog().ok("AllDebrid", NOTICE)
        finally:
            flix_common.popup_free(home, "estreno")

    run_once(home, lambda: migrate(flix_alldebrid, old_key, xbmc.executebuiltin,
                                   xbmc.getInfoLabel("Skin.String(%s)" % AD_USER)),
             xbmc.executebuiltin, notice, wait_idle, flix_common.quitting)


if __name__ == "__main__":
    main()
