"""Panel «( i )» de las fichas (Carlos, 31-oct): datos de TMDB que la ficha no enseña y una fila con fotos del director
(en series, los creadores) y del reparto. Pulsar una persona abre sus títulos en una sección («Títulos de X»:
películas y series, listas persona-<pelis|series>-<id> del addon), como «Ver similares».

Lo abre el botón redondo ( i ): en la ficha de película (FlixMovie.xml, 15) y en la de serie (FlixSeriesButtons, 5252),
TV y táctil: RunScript(flix_info.py,movie|tv,<tmdb>,<fondo>,<ruta de la ficha>). Al elegir una persona se cierra
también la ficha de debajo (Atrás) antes de abrir la sección: una ficha de serie abierta debajo de otra pisaba sus
propiedades (flix_series_*). Al salir de la sección con Atrás se reabre la ficha (back_to).
Spec: docs/superpowers/specs/2026-10-31-panel-info-ficha-design.md"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import threading
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402
from flix_common import A_BACK, INFO_COVER as COVER, TMDB_KEY  # noqa: E402

HOME = xbmcgui.Window(10000)
API = "https://api.themoviedb.org/3/"
IMG = "https://image.tmdb.org/t/p/"
TIMEOUT = 8
LIST = 50
MAX_CAST = 20
MAX_TITLES = 60                     # por fila («Películas», «Series») de la sección de una persona
CLOSE_WAIT = 3.0                    # s para que se cierre la ficha de debajo
SHEETS = ("FlixMovie.xml", "FlixSeries.xml")
OPEN = "flix_info_open"             # Window(home): panel abierto (el tráiler automático de la ficha no arranca debajo)
DIRECTING = ("Director", "Creator")             # en sus créditos: lo que ha dirigido o creado
SKIP_TV_GENRES = {10763, 10767}                 # noticias y programas de entrevistas: ahí sale «como él mismo»
# los países llegan en inglés aunque se pidan en español: los habituales, a mano
COVER_SECS = 0.6                    # s que el fondo de la ficha sigue tapando tras abrirse la sección o pedir la ficha
COVER_SAFETY = 6.0                  # s: si la ficha no llega a reabrirse, el fondo no se queda tapando el Inicio
COUNTRIES = {"US": "EE. UU.", "GB": "Reino Unido", "ES": "España", "FR": "Francia", "DE": "Alemania", "IT": "Italia",
             "JP": "Japón", "KR": "Corea del Sur", "CA": "Canadá", "AU": "Australia", "MX": "México",
             "AR": "Argentina", "IN": "India", "CN": "China", "IE": "Irlanda", "NZ": "Nueva Zelanda",
             "BE": "Bélgica", "SE": "Suecia", "DK": "Dinamarca", "NO": "Noruega", "BR": "Brasil", "NL": "Países Bajos",
             "PL": "Polonia", "TR": "Turquía", "CO": "Colombia", "CL": "Chile", "HK": "Hong Kong", "TW": "Taiwán",
             "CZ": "Chequia", "HU": "Hungría", "AT": "Austria", "CH": "Suiza", "PT": "Portugal", "FI": "Finlandia",
             "IS": "Islandia", "ZA": "Sudáfrica", "RU": "Rusia", "TH": "Tailandia", "IL": "Israel"}


def log(msg):
    xbmc.log("[flix_info] %s" % msg, xbmc.LOGINFO)


# ---------- TMDB ----------
def get(ep, opener=None, **extra):
    """JSON de un endpoint de TMDB en español. Excepción = red"""
    import urllib.request
    q = dict(extra, api_key=TMDB_KEY, language="es-ES")
    req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q), headers={"User-Agent": "Ker0n3Media-skin"})
    with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace") or "{}")


def fetch(kind, tmdb, opener=None):
    """ficha de TMDB con sus créditos (las series, los de todas sus temporadas). Excepción = red"""
    if kind == "movie":
        return get("movie/%d" % int(tmdb), opener, append_to_response="credits")
    return get("tv/%d" % int(tmdb), opener, append_to_response="aggregate_credits")


# ---------- lo que se enseña ----------
def photo(path, size="w185"):
    return IMG + size + path if path else ""


def initials(name):
    return "".join(w[0] for w in (name or "").split()[:2]).upper()


def money(n):
    """200000000 -> «200 M$»; 1921847111 -> «1.922 M$»"""
    m = int((n or 0) / 1e6 + 0.5)                   # redondeo de siempre (round() deja 2,5 en 2)
    return "%s M$" % "{:,}".format(m).replace(",", ".") if m else ""


def countries(data):
    codes = data.get("origin_country") or [c.get("iso_3166_1") for c in data.get("production_countries") or []]
    names = {c.get("iso_3166_1"): c.get("name") for c in data.get("production_countries") or []}
    return ", ".join(COUNTRIES.get(c) or names.get(c) or c for c in codes if c)


def names(items, n=3):
    return ", ".join(x.get("name", "") for x in (items or [])[:n] if x.get("name"))


def person(p, role):
    # «Asta (voice)»: en el anime y la animación TMDB marca así el doblaje original (21-nov): el personaje, sin más
    role = re.sub(r"\s*\((?:voice|uncredited)\)", "", role or "", flags=re.I).strip()
    return {"id": p.get("id"), "name": p.get("name") or "", "role": role, "photo": photo(p.get("profile_path")),
            "initials": initials(p.get("name"))}


def people(kind, data):
    """dirección (series: creación) primero y después el reparto, sin repetir a nadie"""
    out, seen = [], set()

    def add(p):
        if p["id"] and p["id"] not in seen and p["name"]:
            seen.add(p["id"])
            out.append(p)
    if kind == "movie":
        for c in (data.get("credits") or {}).get("crew") or []:
            if c.get("job") == "Director":
                add(person(c, "Dirección"))
        cast = (data.get("credits") or {}).get("cast") or []
        roles = [c.get("character") for c in cast]
    else:
        for c in data.get("created_by") or []:
            add(person(c, "Creación"))
        if not out:         # sin creadores en TMDB (mucho anime): quien más capítulos ha dirigido (21-nov)
            crew = [c for c in (data.get("aggregate_credits") or {}).get("crew") or []
                    if any(j.get("job") == "Director" for j in c.get("jobs") or [])]
            for c in crew[:1]:
                add(person(c, "Dirección"))
        cast = (data.get("aggregate_credits") or {}).get("cast") or []
        roles = [((c.get("roles") or [{}])[0]).get("character") for c in cast]
    for c, role in list(zip(cast, roles))[:MAX_CAST]:
        add(person(c, role))
    return out


def summary(kind, data):
    """título y líneas de datos del panel"""
    if kind == "movie":
        title, date = data.get("title") or data.get("original_title") or "", data.get("release_date") or ""
    else:
        title, date = data.get("name") or data.get("original_name") or "", data.get("first_air_date") or ""
    mins = data.get("runtime") or 0
    genres = " / ".join(g.get("name", "") for g in data.get("genres") or [] if g.get("name"))
    first = [date[:4]]
    if kind == "movie":
        first.append("%d h %02d min" % divmod(mins, 60) if mins >= 60 else "%d min" % mins if mins else "")
    else:
        s, e = data.get("number_of_seasons") or 0, data.get("number_of_episodes") or 0
        first += ["%d temporada%s" % (s, "" if s == 1 else "s") if s else "",
                  "%d capítulos" % e if e > 1 else ""]
    first.append(genres)
    lines = ["  ·  ".join(x for x in first if x)]
    where = countries(data)
    if kind == "movie":
        studio = names(data.get("production_companies"))
        lines.append("  ·  ".join(x for x in ("País: " + where if where else "",
                                               "Productora: " + studio if studio else "") if x))
        b, r = money(data.get("budget")), money(data.get("revenue"))
        lines.append("  ·  ".join(x for x in ("Presupuesto: " + b if b else "", "Recaudación: " + r if r else "") if x))
    else:
        net = names(data.get("networks"))
        lines.append("  ·  ".join(x for x in ("Cadena: " + net if net else "", "País: " + where if where else "")
                                  if x))
        studio = names(data.get("production_companies"))
        lines.append("Productora: " + studio if studio else "")
    return {"title": title, "lines": [x for x in lines if x], "fanart": photo(data.get("backdrop_path"), "w1280")}


# ---------- títulos de una persona ----------
def credits_of(pid, opener=None):
    return get("person/%d/combined_credits" % int(pid), opener)


def titles(data):
    """ids de TMDB {movie: [...], tv: [...]} en los que sale o que ha dirigido/creado, los más conocidos primero (votos)"""
    picked = {"movie": {}, "tv": {}}
    rows = list(data.get("cast") or []) + [c for c in data.get("crew") or [] if c.get("job") in DIRECTING]
    for c in rows:
        kind = c.get("media_type")
        if kind not in picked or not c.get("id"):
            continue
        if kind == "tv" and SKIP_TV_GENRES & set(c.get("genre_ids") or []):
            continue
        picked[kind][c["id"]] = max(picked[kind].get(c["id"], 0), c.get("vote_count") or 0)
    return {k: [i for i, _ in sorted(v.items(), key=lambda kv: -kv[1])] for k, v in picked.items()}


K3_LIST = "plugin://plugin.video.ker0n3/lista/"


def person_rows(name, pid, data, spec=None):
    """filas de la sección «Títulos de X»: «Películas» y «Series» (las listas persona-<pelis|series>-<id> del addon,
    con la regla de las filas: solo lo que tiene versión; flix_tmdblists.person_entries), solo las del tipo en que sale;
    [] si nada"""
    if spec is None:
        import flix_tmdblists
        spec = flix_tmdblists.spec
    ids = titles(data)
    rows = []
    for kind, cat, label in (("movie", "pelis", "Películas"), ("tv", "series", "Series")):
        key = "persona-%s-%d" % (cat, int(pid))
        if ids[kind] and spec(key) is not None:
            rows.append({"label": label, "path": K3_LIST + key, "kind": "list"})
    return rows


def back_to(kind, path):
    """lo que reabre la ficha de la que se vino (película o serie, sin su aviso «Seguir viendo») al salir con Atrás de
    «Títulos de X» (Carlos, 31-oct: «cuando le doy a atrás no vuelvo a la ficha de la peli»); '' sin ruta del addon"""
    from flix_common import K3_ROOT
    if not path.startswith(K3_ROOT) or any(c in path for c in ',"'):
        return ""
    return "RunScript(special://skin/scripts/%s,%s,ficha)" % ("flix_play.py" if kind == "movie" else "flix_series.py",
                                                              path)


def open_rows(title, rows, back="", cover=""):
    """la sección con esas filas (TV: flix_section; táctil: flix_home), como «Ver similares» (flix_menu.open_similar);
    back: lo que se lanza al cerrarla con Atrás; cover: el fondo que tapa el Inicio mientras se vuelve a la ficha"""
    # sin menú lateral: viene de una ficha, donde no se veía (Carlos, 31-oct)
    HOME.setProperty("flix_similar", json.dumps({"title": title, "rows": rows, "back": back, "cover": cover,
                                                 "menu": False}))
    script = "flix_home.py" if xbmc.getSkinDir().endswith(".touch") else "flix_section.py"
    xbmc.executebuiltin("RunScript(special://skin/scripts/%s,similar)" % script)


later = flix_common.later       # Timer daemon (PY-21); vive en flix_common desde el lote 11d


def uncover_soon(secs=COVER_SECS):
    """quita el fondo que tapa el Inicio en cuanto se ve la sección o la ficha (lo usan flix_section y flix_home)"""
    later(secs, HOME.clearProperty, COVER)


def back_with_cover(back, cover):
    """Atrás en «Títulos de X»: el fondo de la ficha tapa el Inicio hasta que se reabre (la ficha lo quita al verse) y,
    si no llegase, se quita solo"""
    HOME.setProperty("flix_tr_skip", "%f" % time.time())     # flix_autotrailer.SKIP: la ficha reabierta, sin tráiler
    if cover:
        HOME.setProperty(COVER, cover)

        def safety():
            if HOME.getProperty(COVER) == cover:
                HOME.clearProperty(COVER)
        later(COVER_SAFETY, safety)
    xbmc.executebuiltin(back)


def sheet_open():
    return any(xbmc.getCondVisibility("Window.IsVisible(%s)" % s) for s in SHEETS)


def close_sheet():
    """cierra la ficha de debajo (película o serie) con Atrás y espera a que se vaya. Antes, a que el panel acabe su
    fundido de cierre: con él en marcha Kodi tira el Atrás («ignoring action 92, because topmost modal dialog closing
    animation is running»), la ficha seguía abierta y la sección no se abría encima (Fire TV, 31-oct). Si aun así
    sigue, un 2.º Atrás (solo uno: de más, saldría del Inicio)"""
    mon = xbmc.Monitor()

    def wait(cond, secs):
        until = time.time() + secs
        while cond() and time.time() < until:
            if mon.waitForAbort(0.05):
                return False
        return True
    if not wait(lambda: xbmc.getCondVisibility("Window.IsVisible(FlixInfo.xml)"), CLOSE_WAIT):
        return
    for _ in range(2):
        if not sheet_open():
            return
        xbmc.executebuiltin("Action(Back)")
        if not wait(sheet_open, CLOSE_WAIT / 2):
            return
    if sheet_open():
        log("la ficha no se cierra")


# ---------- ventana ----------
def item(p):
    li = xbmcgui.ListItem(p["name"])
    li.setLabel2(p["role"])
    li.setProperty("initials", p["initials"])
    li.setProperty("pid", str(p["id"]))
    if p["photo"]:
        li.setArt({"thumb": p["photo"]})
    return li


class InfoPanel(xbmcgui.WindowXMLDialog):
    """FlixInfo.xml: 50 = personas. Propiedades: fi_fanart, fi_title, fi_line1..3, fi_state (loading|error|msg|'')
    y fi_msg. Se abre al momento y lo de TMDB llega en un hilo"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.kind, self.tmdb = kwargs.get("kind", "movie"), kwargs.get("tmdb", "")
        self.fanart = kwargs.get("fanart", "")
        self.people = []
        self.busy = False
        self.done = False
        self.result = None              # (título de la sección, filas) al elegir una persona con títulos

    def onInit(self):
        if self.fanart:
            self.setProperty("fi_fanart", self.fanart)
        self.setProperty("fi_state", "loading")
        threading.Thread(target=self.load, daemon=True).start()

    def load(self):
        try:
            data = fetch(self.kind, self.tmdb)
        except Exception as e:  # noqa: BLE001  (sin red, TMDB caído…)
            log("ficha %s %s: %s" % (self.kind, self.tmdb, e))
            self.setProperty("fi_state", "error")
            return
        if self.done:
            return
        s = summary(self.kind, data)
        self.setProperty("fi_title", s["title"])
        for n in range(3):
            self.setProperty("fi_line%d" % (n + 1), s["lines"][n] if n < len(s["lines"]) else "")
        if not self.fanart and s["fanart"]:
            self.setProperty("fi_fanart", s["fanart"])
        self.people = people(self.kind, data)
        lst = self.getControl(LIST)
        lst.reset()
        lst.addItems([item(p) for p in self.people])
        self.setProperty("fi_state", "" if self.people else "msg")
        self.setProperty("fi_msg", "" if self.people else "TMDB no tiene el reparto de este título")
        if self.people:
            self.setFocusId(LIST)

    def onClick(self, cid):
        if cid != LIST or self.busy:
            return
        n = self.getControl(LIST).getSelectedPosition()
        if 0 <= n < len(self.people):
            self.busy = True
            threading.Thread(target=self.pick, args=(self.people[n],), daemon=True).start()

    def pick(self, p):
        self.setProperty("fi_working", "Buscando títulos de %s…" % p["name"])
        try:
            rows = person_rows(p["name"], p["id"], credits_of(p["id"]))
        except Exception as e:  # noqa: BLE001
            log("títulos de %s: %s" % (p["name"], e))
            rows = None
        finally:
            self.setProperty("fi_working", "")
            self.busy = False
        icon = xbmcvfs.translatePath("special://skin/resources/icon.png")
        if rows is None:
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "No se han podido buscar sus títulos", icon, 3000)
        elif not rows:
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "No he encontrado títulos de %s" % p["name"], icon, 3000)
        elif not self.done:
            log("títulos de %s: %s" % (p["name"], ", ".join(r["label"] for r in rows)))
            self.result = ("Títulos de %s" % p["name"], rows)
            self.done = True
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.done = True
            self.close()


def show(kind, tmdb, fanart=""):
    """abre el panel; (título, filas) si se eligió una persona con títulos, si no None"""
    w = InfoPanel("FlixInfo.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                  kind=kind, tmdb=tmdb, fanart=fanart)
    HOME.setProperty(OPEN, "1")
    try:
        w.doModal()
    finally:
        HOME.clearProperty(OPEN)
    result = w.result
    del w
    return result


def similar(kind, tmdb, fanart="", path="", title=""):
    """botón «Similares» de la ficha (Carlos, 12-nov: estaba solo en el menú de mantener pulsado sobre una carátula):
    los parecidos de TMDB (ruta similares/ del addon, con la regla de las filas), en la misma sección de una fila que
    flix_menu.open_similar, y con Atrás se vuelve a la ficha, como en «Títulos de X»"""
    if kind not in ("movie", "tv") or not str(tmdb).isdigit():
        log("similares sin título: %s %s" % (kind, tmdb))
        return
    try:
        import flix_autotrailer
        flix_autotrailer.ask_stop()
    except Exception as e:  # noqa: BLE001
        log("tráiler automático: %s" % e)
    title = re.sub(r"\[/?COLOR[^\]]*\]", "", title or "").strip()
    # la fila la da el addon; aquí no se pide nada y la sección se abre ya
    label = "Similares a %s" % title if title else "Similares"
    row = {"label": "Títulos parecidos", "path": flix_common.k3_similar(kind, tmdb), "kind": "list"}
    if fanart:
        HOME.setProperty(COVER, fanart)         # tapa el Inicio mientras se cierra la ficha y se abre la sección
    close_sheet()
    open_rows(label, [row], back=back_to(kind, path), cover=fanart)


def from_sheet(what, req=None):
    """lo de abajo de la ficha (flix_more.py, 21-nov): «person» = los títulos de esa persona, como al elegirla en el
    panel; «open» = la ficha de un similar. La petición la deja la ficha en Window(home) (flix_more.REQ). Se cierra la
    ficha (avisándola: flix_more.LEAVE, si no su Atrás solo subiría) y se abre lo otro; al salir de «Títulos de X» con
    Atrás se vuelve a la ficha de la que se vino"""
    import flix_more
    if req is None:
        try:
            req = json.loads(HOME.getProperty(flix_more.REQ) or "{}")
        except ValueError:
            req = {}
        HOME.clearProperty(flix_more.REQ)
    kind, path, fanart = req.get("kind") or "", req.get("path") or "", req.get("fanart") or ""
    icon = xbmcvfs.translatePath("special://skin/resources/icon.png")
    if what == "person":
        name, pid = req.get("name") or "", req.get("pid")
        if not pid:
            return
        xbmcgui.Dialog().notification("KER0N3 MEDIA", "Buscando títulos de %s…" % name, icon, 2000, False)
        try:
            rows = person_rows(name, pid, credits_of(pid))
        except Exception as e:  # noqa: BLE001
            log("títulos de %s: %s" % (name, e))
            rows = None
        if rows is None:
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "No se han podido buscar sus títulos", icon, 3000)
            return
        if not rows:
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "No he encontrado títulos de %s" % name, icon, 3000)
            return
        log("títulos de %s: %s" % (name, ", ".join(r["label"] for r in rows)))
        target = None
    elif what == "open":
        target = back_to(kind, path)
        if not target:
            log("similar sin ruta del addon: %s" % path)
            return
    else:
        return
    try:
        import flix_autotrailer
        flix_autotrailer.ask_stop()
    except Exception as e:  # noqa: BLE001
        log("tráiler automático: %s" % e)
    if fanart:
        HOME.setProperty(COVER, fanart)         # tapa el Inicio mientras se cierra la ficha y se abre lo otro
    HOME.setProperty(flix_more.LEAVE, "1")
    close_sheet()
    HOME.clearProperty(flix_more.LEAVE)
    if what == "person":
        open_rows("Títulos de %s" % name, rows, back=back_to(req.get("kind") or "", req.get("path") or ""), cover=fanart)
    else:
        xbmc.executebuiltin(target)
        later(COVER_SAFETY, lambda: HOME.getProperty(COVER) == fanart and HOME.clearProperty(COVER))


def main(argv):
    if len(argv) > 1 and argv[1] in ("person", "open"):
        return from_sheet(argv[1])
    if len(argv) > 1 and argv[1] == "similar":
        return similar(*(list(argv[2:7]) + [""] * 5)[:5])
    kind = argv[1] if len(argv) > 1 else ""
    tmdb = argv[2] if len(argv) > 2 else ""
    fanart = argv[3] if len(argv) > 3 else ""
    path = argv[4] if len(argv) > 4 else ""     # la ficha de la que se viene: se vuelve a ella al salir de la sección
    if kind not in ("movie", "tv") or not tmdb.isdigit():
        log("sin título: %s" % argv[1:])
        return
    try:
        import flix_autotrailer
        flix_autotrailer.ask_stop()     # el tráiler automático de la ficha se para: el panel la tapa entera
    except Exception as e:  # noqa: BLE001
        log("tráiler automático: %s" % e)
    result = show(kind, tmdb, fanart)
    if result:
        # el fondo de la ficha tapa el Inicio de debajo mientras se cierra la ficha y se abre la sección (Carlos, 31-oct:
        # «se sale de la ficha y va al menú inicio»); lo quita la sección al verse
        if fanart:
            HOME.setProperty(COVER, fanart)
        close_sheet()
        open_rows(*result, back=back_to(kind, path), cover=fanart)


if __name__ == "__main__":
    main(sys.argv)
