"""La stdlib y scripts/ delante de las carpetas de addons en el sys.path de los RunScript de la skin (revisión 29-oct
ARR-02, lote 6).

Los scripts de la skin se lanzan con RunScript(special://skin/scripts/…), sin addon, y Kodi («Script invoked without
an addon. Adding all addon modules installed to python path as fallback») pone delante de todo las carpetas de módulos
de los addons instalados: 35 en la Shield (script.module.*, plugin.video.asgard, plugin.video.youtube), 11 en la Fire
TV, 7 en el móvil; después scripts/ y al final la stdlib. Cada import de algo que aún no está cargado (json, sqlite3,
un flix_*…) miraba antes esas 35 carpetas: los stat al importar se multiplicaban por 4-6 (medido en proot).

Al importarlo (lo primero de cada script que se lanza con RunScript, justo después de poner scripts/ delante) las
carpetas de addons pasan al FINAL, en el mismo orden: no se quita ninguna, solo se reordena, y lo que solo esté en un
addon se sigue encontrando. Lo de la skin (scripts/ y scripts/vendor, con segno para los QR) no se mueve. Comprobado en
la Shield (29-oct): ningún módulo de esas carpetas se llama como uno de la stdlib o de la skin, así que cada import
sigue cargando el mismo fichero. Sin carpetas de addons (pytest, o un Kodi que deje de añadirlas) no hace nada.

Además (reorganización 2.0.0, docs/arquitectura-skin-addon.md): la lógica (buscar versiones, AllDebrid, reglas,
subtítulos, listas, calidades, comunes…) vive UNA sola vez en el addon Ker0n3 (plugin.video.ker0n3/resources/lib, que
la skin pide en su addon.xml). Aquí se pone esa carpeta justo detrás de scripts/, así cada `import flix_common` (o
cualquier otro módulo de lógica) de un script de la skin la encuentra a la primera. Se busca primero como carpeta
hermana de la skin (addons/<skin>/scripts → addons/plugin.video.ker0n3/resources/lib; en el repositorio, las dos
carpetas fuente también son hermanas: pytest y las herramientas la encuentran igual) y, si no, en
special://home/addons. Si el addon falta, se apunta en el registro y se sigue: lo que no use la lógica sigue andando.
Solo os y sys en el camino normal (lo importa cada RunScript); xbmc/xbmcvfs solo si la carpeta no está donde toca.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
K3_ID = "plugin.video.ker0n3"


def k3_lib(here=HERE, home_addons=None):
    """carpeta de la lógica (resources/lib del addon Ker0n3); '' si no está. home_addons: special://home/addons ya
    traducida (tests); por defecto se traduce aquí, solo si la carpeta hermana no existe"""
    cand = os.path.join(os.path.dirname(os.path.dirname(here)), K3_ID, "resources", "lib")
    if os.path.isdir(cand):
        return cand
    try:
        if home_addons is None:
            import xbmcvfs
            home_addons = xbmcvfs.translatePath("special://home/addons")
        cand = os.path.join(home_addons, K3_ID, "resources", "lib")
        if os.path.isdir(cand):
            return cand
    except Exception:  # noqa: BLE001  (sin Kodi o sin addon: abajo se apunta)
        pass
    return ""


def _norm(p):
    return os.path.normcase(os.path.normpath(p))


def is_addon_dir(p, here=HERE):
    """¿carpeta de módulos de un addon (…/addons/<id con punto>/…) que no es de la skin?"""
    if not isinstance(p, str) or not p:
        return False
    n, h = _norm(p), _norm(here)
    if n == h or n.startswith(h.rstrip("\\/") + os.sep):
        return False
    if n.replace("\\", "/").endswith("/%s/resources/lib" % K3_ID):     # la lógica de la skin: se queda delante
        return False
    parts = p.replace("\\", "/").split("/")
    return any(a == "addons" and "." in b for a, b in zip(parts, parts[1:]))


def reorder(path=None, here=HERE):
    """pasa al final, en su orden, las carpetas de addons de path (sys.path: la MISMA lista); cuántas"""
    path = sys.path if path is None else path
    moved = [p for p in path if is_addon_dir(p, here)]
    if moved:
        path[:] = [p for p in path if not is_addon_dir(p, here)] + moved
    return len(moved)


def add_k3(path=None, here=HERE, lib=None):
    """pone la carpeta de la lógica justo detrás de scripts/ (o delante de todo si scripts/ no está); la ruta o ''"""
    path = sys.path if path is None else path
    lib = k3_lib(here) if lib is None else lib
    if not lib:
        try:
            import xbmc
            xbmc.log("[flix_syspath] falta el addon %s (resources/lib): la skin sigue, pero sin buscar ni reproducir "
                     "con fuentes propias" % K3_ID, xbmc.LOGWARNING)
        except Exception:  # noqa: BLE001
            pass
        return ""
    if any(_norm(p) == _norm(lib) for p in path if isinstance(p, str)):
        return lib
    hn = _norm(here)
    at = next((i + 1 for i, p in enumerate(path) if isinstance(p, str) and p and _norm(p) == hn), 0)
    path.insert(at, lib)
    return lib


reorder()
add_k3()
