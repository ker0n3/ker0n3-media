# -*- coding: utf-8 -*-
"""Mejor audio disponible de cada título, para la cabecera del Inicio y la ficha (Carlos, 12-nov: «¿podríamos usar los
códecs como esto?», con una foto de la cabecera con «DTS»).

Las fuentes propias no dan el audio de un título antes de buscar sus enlaces: de momento no hay de dónde sacarlo y
for_path no da nada (la insignia es un extra; la parte de la ficha y la cabecera se queda para cuando lo haya). Al
reproducir sí se enseña el audio real, que es cuando Kodi lo sabe. best() resume los códecs de unos enlaces."""
import re

# una sola copia en el addon (flix_src_codec: también lee el audio y los canales de cada versión para «Elegir versión»)
from flix_src_codec import RANK, TOKENS  # noqa: E402,F401


def best(infos):
    """el mejor códec de unos textos de enlaces («AC3,DTS»); '' si no hay ninguno conocido"""
    found = set()
    for info in infos:
        for tok in re.split(r"[,\s/]+", (info or "").upper().strip("[] ")):
            key = TOKENS.get(tok)
            if key:
                found.add(key)
    return next((k for k in RANK if k in found), "")


def for_path(path):
    """códec del título de esa ruta ('' si no se sabe: hoy, siempre)"""
    return ""
