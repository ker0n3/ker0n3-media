"""Pantalla de carga única al reproducir (Custom_1198_FlixPlayLoad.xml: fondo de la película/serie + una sola rueda).

Entre pulsar y ver la imagen se turnan la rueda de Kodi, la de flix_series, la búsqueda de versiones (flix_src_play) y
el progreso de AllDebrid (flix_debrid); cada uno pinta su propia rueda y en los relevos (0,2-0,5 s) no había ninguna:
se veía el Inicio con la carátula enfocada y otra rueda después (Carlos, 25-oct, Shield).
begin() enciende la capa (Window(home).Property(flix_playload)) y un hilo la quita: al salir el vídeo, si hay que
enseñar algo (un aviso o una pregunta), si nada carga durante IDLE_MAX (Atrás, fallo sin aviso) o como mucho a los
MAX_SECS. El hilo no es daemon: el RunScript que la enciende espera a que termine.
"""
import os
import re
import sys
import threading
import time

import xbmc
import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HOME = xbmcgui.Window(10000)
PROP, FANART = "flix_playload", "flix_playload_fanart"
PENDING = "pending"     # PROP puesta por el pop-up «Te quedaste en…» al pulsar, antes del begin() real (sin hilo): no es una marca
PRESSED = "flix_play_pressed"   # hora del último begin() con pulsación (no se borra)
USER_PRESS = "flix_user_press"  # el usuario ha pulsado y su vídeo aún no ha empezado (begin() o el <onclick> de las
#                                 listas de capítulos). Se borra al empezar el vídeo, al parar y al cancelar.
#                                 Valor: «lista|posición|capítulo» («7970|6|2x6»); de un botón, sin lista («||2x6»,
#                                 «||-» película, «||» no se sabe)
USER_PRESS_PATH = "flix_user_press_path"    # ruta del capítulo pulsado en la lista
HOLD = "flix_playload_hold"     # hora desde la que la capa se mantiene aunque no cargue nada (hold())
TEXT = "flix_playload_text"     # texto bajo la rueda (vacío: solo rueda)
HOLD_SECS = 20.0    # s: lo máximo que hold() aguanta la capa sin carga ni vídeo (el aviso o el vídeo la sustituyen antes)
STEP = 0.1
IDLE_MAX = 2.0      # s sin rueda de nadie ni vídeo: se acabó (los relevos duran 0,2-0,5 s)
# al pasar al siguiente capítulo los huecos entre ruedas son más largos que al pulsar play: se espera más antes de dar
# la capa por parada
NEXT_IDLE = 10.0
# y la ventana del vídeo que acaba de parar aún puede estar activa al encender la capa: no cuenta como «ya se ve»
NEXT_GRACE = 2.0
MAX_SECS = 120
FULL_WAIT = 1.5     # s con vídeo (no tráiler) sin pantalla completa: se pone (windowed_since)
# lo que suena es el tráiler de la ficha (en su recuadro, a propósito sin pantalla completa)
TRAILER = ("!String.IsEmpty(Window(home).Property(flix_trailer)) | !String.IsEmpty(Window(home).Property(flix_tr_on)) | "
           "String.Contains(Player.Filenameandpath,plugin.video.youtube)")
LOADING = ("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog) | "
           "Window.IsActive(progressdialog)")
# un aviso o una pregunta (la de la versión original, el PIN de AllDebrid): la capa se aparta para que se vea
QUESTION = "Window.IsActive(okdialog) | Window.IsActive(yesnodialog)"


def decide(st, now, t0, idle, idle_max=IDLE_MAX, grace=0.0):
    """(por qué quitar la capa o None, desde cuándo no carga nada). video = ya se ve; mostrar = un aviso o una
    pregunta; parado = nada carga desde hace idle_max (Atrás, fallo sin aviso) o demasiado tiempo (cancel). grace: los
    primeros s desde t0 la pantalla completa no quita la capa (siguiente capítulo: fullscreenvideo sigue activa un
    momento al parar)"""
    if st["fullscreen"] and now - t0 >= grace:
        return "video", idle
    if st["question"]:
        return "mostrar", idle
    if now - t0 > MAX_SECS:
        # con la película ya sonando no es un «parado»
        return ("video" if st.get("video") and not st.get("trailer") else "parado"), idle
    if st["loading"] or st["media"] or st.get("hold"):
        return None, None
    idle = now if idle is None else idle
    return ("parado" if now - idle > idle_max else None), idle


def windowed_since(st, now, since):
    """desde cuándo hay vídeo (no el tráiler) sin pantalla completa; None si no. Red de seguridad de
    flix_play.play_full: un vídeo que Kodi empieza en ventana sonaba detrás de la ficha sin que nadie lo viera
    (Shield, 2-nov): pasados FULL_WAIT s, watch() lo pone a pantalla completa"""
    if st["fullscreen"] or not st.get("video") or st.get("trailer"):
        return None
    return now if since is None else since


def state():
    cond = xbmc.getCondVisibility
    return {"fullscreen": cond("Window.IsActive(fullscreenvideo)"),
            "question": cond(QUESTION), "loading": cond(LOADING), "media": cond("Player.HasMedia"),
            "video": cond("Player.HasVideo"), "trailer": cond(TRAILER),
            "hold": held(HOME.getProperty(HOLD), time.time())}


def held(stamp, now):
    """¿hold() sigue vigente? (hasta HOLD_SECS s; marca vacía o ilegible: no)"""
    try:
        return 0 <= now - float(stamp) <= HOLD_SECS
    except ValueError:
        return False


def hold(text=""):
    """mientras se prueba otra cosa sin rueda de nadie: la capa no se da por parada (nadie carga durante un rato) y
    enseña text bajo la rueda (15-nov tarde: 13 s sin nada en pantalla)"""
    HOME.setProperty(HOLD, "%.3f" % time.time())
    HOME.setProperty(TEXT, text)


def cancel(keep_press=False):
    """Atrás mientras cargaba: fuera la capa. keep_press: la capa se da por parada, pero lo pulsado aún puede llegar"""
    if not keep_press:
        clear_press()
    end()


def clear_pending():
    """quita la capa puesta por el pop-up (PENDING) si el flujo no llega a begin(): sin hilo que la quite se quedaría;
    una marca de verdad (otra carga en marcha) no se toca"""
    if HOME.getProperty(PROP) == PENDING:
        HOME.clearProperty(PROP)
        HOME.clearProperty(FANART)


def end(stamp=None):
    """quita la capa (solo la de esa marca, si se da)"""
    if stamp is None or HOME.getProperty(PROP) == stamp:
        HOME.clearProperty(PROP)
        HOME.clearProperty(FANART)
        HOME.clearProperty(HOLD)
        HOME.clearProperty(TEXT)


def watch(stamp, idle_max=IDLE_MAX, grace=0.0):
    # hilo que no es daemon (el RunScript espera a que acabe, hasta MAX_SECS): al cerrarse Kodi se para en menos de
    # 1 s (System.OnQuit, flix_common.quit_monitor: sin addon Kodi no avisa por abortRequested; APA-03)
    import flix_common
    mon, t0, idle, why = flix_common.quit_monitor(), time.time(), None, None
    win, forced = None, False
    try:
        while not flix_common.quitting(mon) and HOME.getProperty(PROP) == stamp:
            st, now = state(), time.time()
            why, idle = decide(st, now, t0, idle, idle_max, grace)
            if why:
                break
            win = windowed_since(st, now, win)
            if win is not None and not forced and now - win >= FULL_WAIT:
                forced = True
                xbmc.log("[flix_playload] vídeo en ventana tras %.1f s: a pantalla completa" % (now - win), xbmc.LOGINFO)
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            if flix_common.wait_quit(mon, STEP):
                break
    finally:
        if why == "parado" and HOME.getProperty(PROP) == stamp:
            cancel(keep_press=True)     # Atrás en la 1.ª rueda
        else:
            end(stamp)


def peek_press():
    return HOME.getProperty(USER_PRESS)


def take_press():
    """¿pulsó el usuario? Una pulsación vale para una sola reproducción"""
    pressed = bool(HOME.getProperty(USER_PRESS))
    clear_press()
    return pressed


K3_EPISODE_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/play/capitulo/\d+/(\d+)/(\d+)")
K3_MOVIE_RE = re.compile(r"^plugin://plugin\.video\.ker0n3/(?:play|info)/pelicula/\d+")


def press_id(path):
    """qué se ha pulsado, según la ruta de Ker0n3: «2x6», «-» si es una película, «» si no se sabe"""
    m = K3_EPISODE_RE.match(path or "")
    if m:
        return "%sx%s" % (m.group(1), m.group(2))
    return "-" if K3_MOVIE_RE.match(path or "") else ""


def clear_press():
    HOME.clearProperty(USER_PRESS)
    HOME.clearProperty(USER_PRESS_PATH)


def begin(fanart="", path="", pressed=True, idle_max=IDLE_MAX, grace=0.0, mark=True):
    """enciende la capa hasta que salga el vídeo (o algo que enseñar); otra begin() la renueva. pressed=False
    (siguiente capítulo, búsqueda de versiones, sin pulsación nueva del usuario): no marca PRESSED. mark=False: capa de
    un bucle, no pone USER_PRESS. Devuelve la marca (end(marca) quita solo esta capa)"""
    stamp = "%.3f" % time.time()
    HOME.setProperty(FANART, fanart or "")
    HOME.clearProperty(HOLD)
    HOME.clearProperty(TEXT)
    if pressed:
        HOME.setProperty(PRESSED, stamp)
        if mark:
            HOME.setProperty(USER_PRESS, "||" + press_id(path))
    HOME.setProperty(PROP, stamp)
    threading.Thread(target=watch, args=(stamp, idle_max, grace)).start()
    return stamp
