"""Seguimiento de la reproducción (RunScript(flix_follow.py,follow) desde el onload de VideoFullScreen.xml).

Mientras suena un vídeo: «Saltar intro» en los capítulos (flix_intro, si hay datos), la franja de «Similares» al final
de una película (flix_endcard, en su propio proceso) y, en un capítulo puesto con fuentes propias (marca
flix_own_playing de flix_src_play), el aviso «Siguiente capítulo» a upnext_secs() del final (o al empezar los créditos)
y, al acabar, el siguiente capítulo ya emitido por la misma cadena que «Ver» (flix_play.start). Lo de otros orígenes
(biblioteca, NAS) no encadena nada: no hay a qué.

También aquí lo que la ficha necesita al reproducir: pick_once («Elegir resolución»: la próxima reproducción, con el
selector de versiones) y upnext_secs (Ajustes → «Aviso de siguiente capítulo»)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402
from flix_common import A_BACK, TMDB_KEY, clean  # noqa: E402

HOME = xbmcgui.Window(10000)
UPNEXT_SECS = 75        # el aviso "Siguiente capítulo" sale a 75 s del final (créditos) (solo capítulos de más de 3 min)
UPNEXT_CHOICES = (30, 45, 60, 75, 90, 120)
# el salto por los créditos espera si el vídeo está en pausa o se ve el OSD o un diálogo sobre el vídeo (ajustes,
# selección, menú contextual, sí/no, subtítulos, marcadores): se saltaría por encima de lo que el usuario está tocando.
# Ventanas concretas y NO System.HasActiveModalDialog: el aviso propio (UpNext) es un diálogo abierto con show() y, si
# Kodi lo contara como modal, el salto no llegaría nunca
JUMP_WAIT = ("Player.Paused | Window.IsVisible(videoosd) | Window.IsVisible(osdsubtitlesettings) | "
             "Window.IsVisible(osdvideosettings) | Window.IsVisible(osdaudiosettings) | Window.IsVisible(selectdialog) | "
             "Window.IsVisible(contextmenu) | Window.IsVisible(yesnodialog) | Window.IsVisible(subtitlesearch) | "
             "Window.IsVisible(videobookmarks)")
SEEK_FWD = 5            # s: un avance mayor entre dos vueltas del bucle (0,5 s) es un salto del usuario, no el vídeo andando
PICK_ONCE_SECS = 90     # «Elegir resolución» en la ficha (flix_play): vale para la reproducción que empiece en ese rato
EPISODE_RE = re.compile(r"(\d+)x(\d+)")
FOLLOW_STALE = 15       # s: la marca flix_following se renueva cada ~5 s mientras alguien sigue la reproducción


def log(msg):
    xbmc.log("[flix_follow] %s" % msg, xbmc.LOGINFO)


def pick_once(now=None):
    """¿se pidió «Elegir resolución» hace poco? Se gasta al mirarla: solo esa reproducción va por el selector"""
    stamp = HOME.getProperty("flix_pick_once")
    if not stamp:
        return False
    HOME.clearProperty("flix_pick_once")
    try:
        return 0 <= (time.time() if now is None else now) - float(stamp) < PICK_ONCE_SECS
    except ValueError:
        return False


def upnext_secs():
    """segundos antes del final a los que sale el aviso: el elegido en Ajustes (Carlos, 22-oct) o UPNEXT_SECS"""
    try:
        s = int(xbmc.getInfoLabel("Skin.String(flix_upnext_secs)") or UPNEXT_SECS)
    except ValueError:
        return UPNEXT_SECS
    return s if s in UPNEXT_CHOICES else UPNEXT_SECS


_MON = []


def nap(ms):
    """espera ms; si Kodi se está cerrando termina el script. El cierre llega por System.OnQuit
    (flix_common.quit_monitor: a los RunScript sin addon no les llega abortRequested; revisión 7-nov PY-03)"""
    if not _MON:
        _MON.append(flix_common.quit_monitor())
    if flix_common.wait_quit(_MON[0], ms / 1000.0):      # en trozos: una espera larga acaba al anunciarse el cierre
        raise SystemExit


def follower_active(mark, now):
    """¿hay ya un script siguiendo la reproducción? (marca = hora de la última renovación)"""
    try:
        return now - float(mark) < FOLLOW_STALE
    except (TypeError, ValueError):
        return False


def player_header(show, season, episode, title):
    """'Serie: 1x03 Título' a partir del reproductor (para el registro)"""
    if show and season and episode:
        return "%s: %sx%02d %s" % (show, season, int(episode), title) if episode.isdigit() else "%s: %sx%s %s" % (show, season, episode, title)
    return title


def next_after(seasons, s, e, today):
    """capítulo que sigue a sXe con lo ya emitido. seasons: {temporada: [(capítulo, 'AAAA-MM-DD' o ''), ...]} (sin
    especiales). (temporada, capítulo) o None si sXe es el último emitido"""
    aired = lambda d: bool(d) and d <= today        # noqa: E731
    for ep, d in sorted(seasons.get(s, [])):
        if ep > e and aired(d):
            return s, ep
    for sn in sorted(k for k in seasons if k > s):
        eps = sorted((ep, d) for ep, d in seasons[sn] if aired(d))
        if eps:
            return sn, eps[0][0]
    return None


def tmdb_get(path):
    import json
    import urllib.parse
    import urllib.request
    url = "https://api.themoviedb.org/3/%s?%s" % (path, urllib.parse.urlencode({"api_key": TMDB_KEY}))
    with urllib.request.urlopen(url, timeout=6) as r:
        return json.load(r)


def next_label(tmdb, s, e):
    """«T1 E9» / «T2 E1» (el mismo formato que las fichas; revisión de diseño 13-nov) si hay siguiente ya emitido; '' si
    era el último; None si no se sabe (sin red)"""
    try:
        show = tmdb_get("tv/%s" % tmdb)
        seasons = {}
        for sn in show.get("seasons") or []:
            n = sn.get("season_number") or 0
            if n < s:
                continue
            if n == s:
                seasons[n] = [(x.get("episode_number") or 0, x.get("air_date") or "")
                              for x in tmdb_get("tv/%s/season/%d" % (tmdb, n)).get("episodes") or []]
            else:                       # siguientes temporadas: basta con que su 1.er capítulo esté emitido
                seasons[n] = [(1, sn.get("air_date") or "")] if (sn.get("episode_count") or 0) > 0 else []
        nxt = next_after(seasons, s, e, time.strftime("%Y-%m-%d"))
    except Exception as e2:  # noqa: BLE001
        log("siguiente capítulo en TMDB: %s" % e2)
        return None
    return "T%d E%d" % nxt if nxt else ""


def shown_label(tmdb, label):
    """el «T2 E49» de TMDB de next_label (con el que se pone el capítulo: chain_own) como se enseña: en una serie por
    partes, el de la ficha («T20 E9»: ker0n3.parts, solo lo guardado); si no, tal cual"""
    m = re.match(r"T(\d+) E(\d+)$", label or "")
    if not m:
        return label
    try:
        from ker0n3 import parts
        return parts.label(tmdb, int(m.group(1)), int(m.group(2)))
    except Exception:  # noqa: BLE001
        return label


OWN_PLAYING = "flix_own_playing"    # = flix_src_play.OWN_PLAYING (test_k3_siguiente_capitulo)
OWN_AGE = 6 * 3600                  # s que vale la marca (un capítulo no dura más)
K3_EPISODE = "plugin://plugin.video.ker0n3/play/capitulo/%d/%d/%d"


def own_episode(raw, playing_file, now):
    """(tmdb, temporada, capítulo) si lo que suena es un capítulo puesto con fuentes propias (la marca que deja
    flix_src_play.mark_playing con su fichero); None si es otra cosa (una película, un tráiler, otro origen)"""
    import json
    try:
        d = json.loads(raw or "")
        if d.get("kind") != "tv" or not d.get("file") or d["file"] != playing_file or \
                not 0 <= now - float(d.get("at") or 0) <= OWN_AGE:
            return None
        return int(d["tmdb"]), int(d["season"]), int(d["episode"])
    except (ValueError, TypeError, KeyError, AttributeError):
        return None


def chain_own(own, label, start=None, show=""):
    """al acabar un capítulo de fuentes propias: pone el siguiente ya emitido (label «T1 E5», de next_label) por la
    misma cadena que «Ver» (flix_play.start: capa de carga, mejor versión, pregunta si no hay castellano). Devuelve
    su ruta, o None si no hay siguiente emitido ('') o no se sabe (None, sin red): entonces no se pone nada y se
    vuelve a la ficha, que ya dice «Al día»"""
    m = re.match(r"T(\d+) E(\d+)$", label or "")
    if not m:
        return None
    path = K3_EPISODE % (own[0], int(m.group(1)), int(m.group(2)))
    if show and HOME.getProperty("flix_series_tmdb") != str(own[0]):
        # el nombre de la serie para el rótulo del siguiente (flix_play.k3_info lo toma de aquí): puesto sin pasar por
        # la ficha (Fire TV 18-nov: salía «1x02» a secas en vez de «Pocoyó · …»)
        HOME.setProperty("flix_series_tmdb", str(own[0]))
        HOME.setProperty("flix_series_title", show)
    if start is None:
        import flix_play
        start = flix_play.start
    start(path)
    return path


def prefetch_next(own, label):
    """al salir el aviso «Siguiente capítulo»: el enlace del siguiente (label «T1 E5» de next_label) se prepara en
    segundo plano (flix_src_play.prefetch) para que chain_own lo ponga sin buscar. Mismo proceso que chain_own: queda
    en memoria. Solo al salir el aviso (con «Cancelar» se tira: ni AllDebrid ni nada que deshacer); fuera del bucle"""
    m = re.match(r"T(\d+) E(\d+)$", label or "")
    if not m:
        return None

    def run():
        try:
            import flix_src_play
            flix_src_play.prefetch({"content": "episodes", "tmdb": str(own[0]), "season": int(m.group(1)),
                                    "episode": int(m.group(2))})
        except Exception as e:  # noqa: BLE001
            log("precarga del siguiente: %s" % e)
    th = threading.Thread(target=run, name="flix_next_prefetch", daemon=True)
    th.start()
    return th


def upnext_due(rem, cur, total, secs, credits):
    """¿toca abrir el aviso de «Siguiente capítulo»? A secs del final (como siempre) o, si hay datos de créditos
    (segundo en que empiezan, o None), en cuanto empiezan. Solo capítulos de más de 3 min; secs 0 o nulo = apagado"""
    if not (total > 180 and secs and secs > 0):
        return False
    if 0 < rem <= secs:
        return True
    return credits is not None and cur >= credits and rem > 0


def upnext_remaining(rem, opened_at, now, secs, early):
    """segundos que enseña la cuenta atrás. Normal: lo que falta para el final. early (el aviso salió con los créditos
    a más de secs del final): los secs de Ajustes contados desde que salió (opened_at y now, en segundos de vídeo)"""
    if not early:
        return rem
    return max(0.0, min(float(secs), secs - (now - opened_at)))


class UpNext(xbmcgui.WindowXMLDialog):
    """Aviso propio "Siguiente capítulo" (Custom_1111_Overlay.xml). Siguiente = saltar al final (al acabar, el
    siguiente lo pone follow_playback). Cancelar / Atrás = al acabar o parar, quedarse en el menú. Si no se toca, al
    acabar el capítulo sigue el siguiente.
    A lo Netflix (Carlos, 8-nov; tools/gen_upnext.py): sin tarjeta, [ Cancelar ] [ Siguiente capítulo · T2 · E5 ]
    abajo a la derecha como «Saltar intro», y la cuenta atrás es un relleno dentro de Siguiente (un_pct)"""

    def onInit(self):
        title = xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or HOME.getProperty("flix_series_title") or xbmc.getInfoLabel("Player.Title")
        m = EPISODE_RE.search(xbmc.getInfoLabel("Player.Title"))
        self.getControl(200001).setLabel(title)
        nxt = getattr(self, "next_label", None)     # de TMDB (follow_playback); si no se sabe, el siguiente número
        nxt = nxt or ("T%d E%d" % (int(m.group(1)), int(m.group(2)) + 1) if m else "")
        self.getControl(200003).setLabel(nxt)
        art = xbmc.getInfoLabel("Player.Art(fanart)") or HOME.getProperty("flix_fanart") or xbmc.getInfoLabel("Player.Art(thumb)")
        # imagen y barra por propiedades (Custom_1111_Overlay.xml): setImage / setPercent usan el control y, tras
        # recargar la skin con el aviso abierto, apuntaban al borrado y cerraban Kodi (auditoría 22-oct A-02).
        # setLabel / setText van por mensaje: seguros
        self.setProperty("un_art", art)
        self.setProperty("un_next", nxt)
        self.tick(self.secs())

    def tick(self, remaining):
        self.setProperty("un_pct", "%d" % max(0, min(100, round(100.0 * remaining / self.secs()))))
        try:
            self.getControl(200002).setText("Empieza en %d s" % max(0, int(remaining)))
        except RuntimeError:
            pass

    def secs(self):
        return getattr(self, "upnext_secs", UPNEXT_SECS)

    def go_next(self):
        """lo que hace el botón «Siguiente» (y la cuenta atrás de los créditos al llegar a 0)"""
        HOME.setProperty("flix_upnext_choice", "next")
        self.close()
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_next.py)")

    def onClick(self, cid):
        if cid == 200006:
            self.go_next()
        elif cid == 200005:
            HOME.setProperty("flix_upnext_choice", "stay")
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:            # = «Cancelar»
            HOME.setProperty("flix_upnext_choice", "stay")
            self.close()


def is_episode():
    return bool(xbmc.getInfoLabel("VideoPlayer.Episode")) or EPISODE_RE.search(xbmc.getInfoLabel("Player.Title")) is not None


def make_skip_watcher(player):
    """Watcher de «Saltar intro» si Kodi da el tmdb, la temporada y el capítulo (números); nunca falla hacia fuera"""
    try:
        ids = [xbmc.getInfoLabel(k) for k in ("VideoPlayer.UniqueID(tmdb)", "VideoPlayer.Season", "VideoPlayer.Episode")]
        if not all(i.isdigit() for i in ids):
            return None
        import flix_intro
        return flix_intro.Watcher(player, *[int(i) for i in ids])
    except Exception as e:  # noqa: BLE001
        log("saltar intro: %s" % e)
        return None


ENDCARD_LEAD = 25 * 60      # s antes del final de una película en que se prepara la franja de «Similares» (flix_endcard)
ENDCARD_MIN = 40 * 60       # solo películas de verdad: lo que dura menos (un corto, un extra) no la lleva


def endcard_due(total, rem):
    """¿toca lanzar flix_endcard.py? Con la duración ya conocida, en los últimos ENDCARD_LEAD s (los créditos de una
    película nunca empiezan antes) y no en el último medio minuto (no daría tiempo a nada). Puro"""
    return bool(total and total >= ENDCARD_MIN and 30 < rem <= ENDCARD_LEAD)


def credits_of(watcher, total):
    """segundo en que empiezan los créditos según el Watcher de «Saltar intro» (None: sin datos, sin watcher o fallo)"""
    try:
        return watcher.credits_at(total) if watcher is not None else None
    except Exception:  # noqa: BLE001
        return None


def follow_playback(header):
    """Durante la reproducción: «Saltar intro» en los capítulos, «Similares» al final de una película y, en un capítulo
    de fuentes propias, el aviso "Siguiente capítulo" a upnext_secs() del final (o al empezar los créditos, si hay
    datos y faltan más de esos segundos: la cuenta atrás dura los de Ajustes y luego pasa al siguiente) y, al acabar,
    el siguiente capítulo (chain_own)"""
    import flix_playload
    player, mon = xbmc.Player(), flix_common.quit_monitor()      # se para al cerrarse Kodi (System.OnQuit, PY-03)
    flix_playload.clear_press()     # ya hay vídeo: la pulsación está atendida
    HOME.clearProperty("flix_upnext_choice")
    episode, popup, last_rem = is_episode(), None, 9999.0
    # el fanart se lee ahora, con el vídeo sonando: al parar ya no hay Player.Art
    fanart = xbmc.getInfoLabel("Player.Art(fanart)") or HOME.getProperty("flix_fanart")
    secs = upnext_secs()
    renewed = 0.0
    # capítulo puesto con fuentes propias (bloque 3): se sabe cuál es sin mirar el título; qué capítulo sigue (TMDB, en
    # segundo plano): si era el último, sin aviso de «Siguiente capítulo» (anunciaba un E9 que no existe; Carlos, 20-oct)
    upnext = {"label": None}
    try:
        own = own_episode(HOME.getProperty(OWN_PLAYING), player.getPlayingFile(), time.time())
    except Exception:  # noqa: BLE001  (sin vídeo ya, o un reproductor sin ese dato)
        own = None
    if own:
        episode = True
        upnext["show"] = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")     # para el rótulo del siguiente (chain_own)

        def look():
            upnext["label"] = next_label(own[0], own[1], own[2])
            log("después de %sx%s: %r" % (own[1], own[2], upnext["label"]))
        threading.Thread(target=look, daemon=True).start()
    # «Saltar intro»: el hilo busca los tiempos; si al arrancar Kodi aún no da los ids se reintenta unos segundos
    watcher, watch_tries = None, 0
    early, opened_cur, jumped = False, 0.0, False      # aviso abierto por los créditos con más de secs por delante
    prev_cur = None                                     # el tiempo de la vuelta anterior (para ver los saltos adelante)
    endcard = False                                     # «Similares» al acabar la película: ya lanzado
    while player.isPlaying() and not flix_common.quitting(mon):
        if episode and watcher is None and watch_tries < 20:
            watch_tries += 1
            watcher = make_skip_watcher(player)
        if time.time() - renewed > 5:
            renewed = time.time()
            HOME.setProperty("flix_following", str(renewed))
        try:
            total, cur = player.getTotalTime(), player.getTime()
            last_rem = total - cur
        except RuntimeError:
            break
        seeked = prev_cur is not None and cur - prev_cur > SEEK_FWD
        prev_cur = cur
        if not episode and not endcard and endcard_due(total, last_rem):
            # película en su tramo final: «Similares» sobre los créditos o al acabar (flix_endcard.py, en SU proceso:
            # nada de lo que haga toca este seguimiento). Una vez por película
            endcard = True
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_endcard.py)")
        credits = credits_of(watcher, total) if episode else None
        # por los créditos (faltan más de secs) hay que SABER que hay siguiente: con la respuesta de TMDB «hay». Sin ella
        # (sin red) no se adelanta: un último capítulo saltaría 10 min antes del final
        if own and popup is None and upnext_due(last_rem, cur, total, secs, credits) \
                and not HOME.getProperty("flix_upnext_choice") and upnext["label"] != "" \
                and (last_rem <= secs or upnext["label"]):
            early, opened_cur, jumped = last_rem > secs, cur, False
            popup = UpNext("Custom_1111_Overlay.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
            popup.next_label = shown_label(own[0], upnext["label"])     # en pantalla: el de la parte, si la hay
            popup.upnext_secs = secs
            popup.show()
            prefetch_next(own, upnext["label"])         # agilidad (18-nov): el siguiente, preparado en los créditos
            log("aviso siguiente capítulo (%s, faltan %.0f s%s; créditos %s, dura %.0f s)" % (
                header, last_rem, ", por los créditos" if early else "",
                "a %.0f s del final" % (total - credits) if credits is not None else "sin dato válido", total))
        elif popup is not None:
            try:
                if early and credits is not None and cur < credits:     # retrocedió a antes de los créditos: se quita
                    popup.close()                                       # (sin salto; vuelve a salir al llegar a ellos)
                    popup, early = None, False
                else:
                    if early and seeked and not jumped:     # salto adelante (no el del propio «Siguiente»):
                        opened_cur = cur                    # la cuenta atrás vuelve a empezar
                    left = upnext_remaining(last_rem, opened_cur, cur, secs, early)
                    popup.tick(left)
                    # a 0: lo que haría «Siguiente», una vez y solo si nadie ha elegido (Cancelar deja seguir hasta el final);
                    # con el OSD o un diálogo abierto espera (jumped sigue False: salta en cuanto se cierren)
                    if early and left <= 0 and not jumped and not HOME.getProperty("flix_upnext_choice") \
                            and not xbmc.getCondVisibility(JUMP_WAIT):
                        jumped = True
                        popup.go_next()
            except Exception as e:  # noqa: BLE001
                log("aviso con créditos: %s" % e)
                jumped = True
        if watcher is not None:         # sin red ni diálogos bloqueantes; con el aviso del siguiente, el botón no sale
            watcher.tick(cur, total, hold=popup is not None)
        if mon.waitForAbort(0.1 if last_rem < 6 else 0.5) or flix_common.quitting():    # al final, más fino
            break
    HOME.clearProperty("flix_following")
    if watcher is not None:
        try:
            watcher.close()
        except Exception:  # noqa: BLE001
            pass
    if popup is not None:
        try:
            popup.close()
        except RuntimeError:
            pass
    if not own:
        log("fin de %r: faltaban %.0f s" % (header, last_rem))
        return
    # si toca seguir (acabó solo o se pulsó «Siguiente») y hay siguiente emitido, se pone aquí; si no, de vuelta a la
    # ficha
    HOME.clearProperty(OWN_PLAYING)
    choice = HOME.getProperty("flix_upnext_choice")
    go = choice == "next" or (last_rem < 6 and choice != "stay")
    log("fin de %r: faltaban %.0f s, elección %r -> %s" % (
        header, last_rem, choice, "siguiente capítulo %s" % (upnext["label"] or "(no hay)") if go
        else "quedarse en el menú"))
    if go:
        HOME.setProperty("flix_fanart", fanart or "")
        chain_own(own, upnext["label"], show=upnext.get("show") or "")


def follow():
    """RunScript(flix_follow.py,follow) desde el onload de VideoFullScreen: sigue la reproducción. Si ya la sigue
    otro (marca reciente), no hace nada"""
    if follower_active(HOME.getProperty("flix_following"), time.time()):
        return
    HOME.setProperty("flix_following", str(time.time()))
    player = xbmc.Player()
    for _ in range(20):
        if player.isPlayingVideo():
            break
        nap(100)
    else:
        HOME.clearProperty("flix_following")
        return
    header = player_header(xbmc.getInfoLabel("VideoPlayer.TVShowTitle"), xbmc.getInfoLabel("VideoPlayer.Season"),
                           xbmc.getInfoLabel("VideoPlayer.Episode"), clean(xbmc.getInfoLabel("Player.Title")))
    log("sigo la reproducción: %s" % header)
    follow_playback(header)


def upnext():
    """Ajustes → «Aviso de siguiente capítulo»: a cuántos segundos del final sale (upnext_secs). Antes en
    flix_quality.py (que pasó al addon Ker0n3 con la lógica: aquí se queda lo de pantalla)"""
    import flix_picker
    choices = UPNEXT_CHOICES
    cur = upnext_secs()
    labels = ["%d segundos antes del final%s" % (s, "  ·  por defecto" if s == UPNEXT_SECS else "")
              for s in choices]
    i = flix_picker.pick("Siguiente capítulo", labels,
                         "Cuándo sale el aviso para pasar al siguiente capítulo. Si se saben los créditos, sale al empezar "
                         "estos y el número es lo que dura la cuenta atrás. Si los créditos de tu serie son largos, "
                         "más segundos; si sale antes de que acabe el capítulo, menos.",
                         current=choices.index(cur))
    if i >= 0:
        xbmc.executebuiltin("Skin.SetString(flix_upnext_secs,%d)" % choices[i])


if __name__ == "__main__" and sys.argv[1:2] == ["follow"]:     # importado (tests) no hace nada
    follow()
elif __name__ == "__main__" and sys.argv[1:2] == ["upnext"]:   # RunScript(flix_follow.py,upnext): Ajustes
    upnext()
