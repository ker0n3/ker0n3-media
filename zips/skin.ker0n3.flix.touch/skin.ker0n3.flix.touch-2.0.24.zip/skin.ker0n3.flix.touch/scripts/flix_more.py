"""Ficha «como Nuvio» (21-nov, Carlos: «que bajas y te salen los similares y la info de director etc.»). Lo de debajo
de la ficha de película (flix_play.MovieSheet, FlixMovie.xml) y de la de serie (flix_series_sheet.SeriesSheet,
FlixSeries.xml), TV y táctil:
  7300  «Dirección y reparto»: fotos redondas; pulsar = los títulos de esa persona (flix_info.py person)
  7301  «Similares»: la ruta similares/ del addon, con la regla de las filas; pulsar = su ficha (flix_info.py open)
  more_k1..8 / more_v1..8   «Detalles» (dirección o creación, estreno, duración o temporadas, país, productora…)
  more_ready                 ya hay datos: la flecha de que hay más abajo (FlixMoreHint) y la página (FlixMorePage)
Sustituye a los botones ( i ) y «Similares» (el panel FlixInfo.xml sigue para quien lo abra por su ruta).

Agilidad: la ficha se abre como siempre. TMDB (una petición: la ficha con su reparto) se pide WAIT s después y solo si
la ficha sigue abierta: pasando fichas deprisa no se pide nada. Los similares (el addon, otro intérprete) solo cuando
se baja (focus) o si el título no tiene reparto (sin él no habría a qué bajar).

Pulsar una persona o un similar lo hace flix_info.py en su propio proceso, como el panel: cierra la ficha (Atrás) y
abre lo otro. La petición va en Window(home) (REQ, JSON): nombres y rutas con comas no caben en RunScript. Mientras
se cierra, LEAVE dice a la ficha que ese Atrás es para irse, no para subir (back)."""
import json
import threading
import time

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
CAST, SIMILAR = 7300, 7301
WAIT = 1.2                  # s con la ficha abierta antes de pedir TMDB
TMDB_WAIT = 10.0            # s como mucho esperando el tmdb de la serie (lo pone flix_series.run al cargar)
SIMILAR_MAX = 30
REQ = "flix_more_req"       # Window(home): {"kind", "path", "fanart", "pid", "name", "title"} de lo pulsado
LEAVE = "flix_more_leave"   # Window(home): el Atrás que llega es para cerrar la ficha (flix_info.close_sheet)
DETAILS = 8
STATUS = {"Returning Series": "En emisión", "Ended": "Finalizada", "Canceled": "Cancelada",
          "In Production": "En producción", "Planned": "Anunciada", "Pilot": "Piloto"}
LANGS = {"en": "Inglés", "es": "Español", "ja": "Japonés", "ko": "Coreano", "fr": "Francés", "de": "Alemán",
         "it": "Italiano", "pt": "Portugués", "zh": "Chino", "cn": "Chino", "hi": "Hindi", "ru": "Ruso",
         "sv": "Sueco", "da": "Danés", "no": "Noruego", "nl": "Neerlandés", "pl": "Polaco", "tr": "Turco",
         "th": "Tailandés", "ca": "Catalán", "eu": "Euskera", "gl": "Gallego", "fi": "Finés", "he": "Hebreo",
         "ar": "Árabe", "id": "Indonesio", "tl": "Tagalo", "is": "Islandés", "cs": "Checo", "hu": "Húngaro"}
MONTHS = ("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")


def log(msg):
    xbmc.log("[flix_more] %s" % msg, xbmc.LOGINFO)


def date_es(d):
    """«2017-10-03» → «3 oct 2017»; lo que no se entienda, tal cual"""
    try:
        y, m, day = (int(x) for x in str(d).split("-"))
        return "%d %s %d" % (day, MONTHS[m - 1], y)
    except (ValueError, IndexError):
        return str(d or "")


def details(kind, data):
    """[(nombre, valor)] de «Detalles», lo que haya, como mucho DETAILS. Película: dirección, estreno, duración, país,
    productora, idioma, presupuesto y recaudación. Serie: creación (o dirección), estreno, estado, temporadas, cadena,
    país, productora e idioma"""
    import flix_info
    out = []

    def add(k, v):
        if v:
            out.append((k, v))
    lang = data.get("original_language") or ""
    lang = LANGS.get(lang, lang.upper())
    if kind == "movie":
        crew = (data.get("credits") or {}).get("crew") or []
        add("Dirección", flix_info.names([c for c in crew if c.get("job") == "Director"], 2))
        add("Estreno", date_es(data.get("release_date")))
        mins = data.get("runtime") or 0
        add("Duración", ("%d h %02d min" % divmod(mins, 60)) if mins >= 60 else ("%d min" % mins if mins else ""))
        add("País", flix_info.countries(data))
        add("Productora", flix_info.names(data.get("production_companies"), 2))
        add("Idioma original", lang)
        add("Presupuesto", flix_info.money(data.get("budget")))
        add("Recaudación", flix_info.money(data.get("revenue")))
    else:
        made = flix_info.names(data.get("created_by"), 2)
        if made:
            add("Creación", made)
        else:
            crew = (data.get("aggregate_credits") or {}).get("crew") or []
            add("Dirección", flix_info.names([c for c in crew if any(j.get("job") == "Director"
                                                                    for j in c.get("jobs") or [])], 1))
        add("Estreno", date_es(data.get("first_air_date")))
        add("Estado", STATUS.get(data.get("status") or "", ""))
        s, e = data.get("number_of_seasons") or 0, data.get("number_of_episodes") or 0
        add("Temporadas", "%d · %d capítulos" % (s, e) if s and e > 1 else (str(s) if s else ""))
        add("Cadena", flix_info.names(data.get("networks"), 2))
        add("País", flix_info.countries(data))
        add("Productora", flix_info.names(data.get("production_companies"), 2))
        add("Idioma original", lang)
    return out[:DETAILS]


def kind_of_item(item):
    """película o serie de un similar (lo que haría su clic en una fila: flix_section.make_item, «open»)"""
    return "tv" if item.getProperty("open") == "series" else "movie"


class More:
    """lo de abajo de una ficha. win: la ventana (getControl, setProperty, getFocusId); kind: movie | tv;
    tmdb, path, fanart: valores o funciones sin argumentos (la serie los sabe cuando ya ha cargado)"""

    def __init__(self, win, kind, tmdb, path="", fanart="", title=""):
        self.win, self.kind = win, kind
        self._tmdb, self._path, self._fanart, self._title = tmdb, path, fanart, title
        self.people = []
        self.gone = False
        self.similar_asked = False
        self.lock = threading.Lock()

    @staticmethod
    def _v(x):
        return str((x() if callable(x) else x) or "")

    def tmdb(self):
        return self._v(self._tmdb)

    def start(self):
        HOME.clearProperty(LEAVE)       # uno que se quedase puesto (flix_info cortado) no cerraría esta al subir
        threading.Thread(target=self.load, daemon=True).start()

    def stop(self):
        self.gone = True

    def wait_tmdb(self, mon):
        until = time.time() + TMDB_WAIT
        while not self.tmdb().isdigit():
            if self.gone or time.time() > until or mon.waitForAbort(0.25):
                return ""
        return self.tmdb()

    def load(self):
        mon = xbmc.Monitor()
        if mon.waitForAbort(WAIT) or self.gone:
            return
        tmdb = self.wait_tmdb(mon)
        if not tmdb or self.gone:
            return
        import flix_info
        try:
            data = flix_info.fetch(self.kind, tmdb)
        except Exception as e:  # noqa: BLE001  (sin red, TMDB caído…): la ficha sigue como siempre
            log("%s %s: %s" % (self.kind, tmdb, e))
            return
        if self.gone:
            return
        people = flix_info.people(self.kind, data)
        rows = details(self.kind, data)
        try:
            lst = self.win.getControl(CAST)
            lst.reset()
            lst.addItems([flix_info.item(p) for p in people])
        except (RuntimeError, TypeError) as e:
            log("reparto sin pintar: %s" % e)
            return
        self.people = people
        for n in range(DETAILS):
            k, v = rows[n] if n < len(rows) else ("", "")
            self.win.setProperty("more_k%d" % (n + 1), k)
            self.win.setProperty("more_v%d" % (n + 1), v)
        self.win.setProperty("more_ready", "1")
        log("%s %s: %d personas, %d datos" % (self.kind, tmdb, len(people), len(rows)))
        if not people:
            self.load_similar()             # sin reparto, bajar va directo a los similares: que estén

    def focus(self, cid):
        """onFocus de la ficha: al bajar, los similares (una vez). True si el foco está abajo"""
        if cid in (CAST, SIMILAR):
            self.load_similar()
            return True
        return False

    def load_similar(self):
        with self.lock:
            if self.similar_asked or not self.tmdb().isdigit():
                return
            self.similar_asked = True
        threading.Thread(target=self._similar, daemon=True).start()

    def _similar(self):
        import flix_common
        import flix_rows
        import flix_section
        path = flix_common.k3_similar(self.kind, self.tmdb())
        try:
            files, _cached = flix_rows.fetch(path)
            items = [flix_section.make_item(f, {"kind": "list"}) for f in files
                     if not flix_rows.is_more(f) and f.get("file")][:SIMILAR_MAX]
        except Exception as e:  # noqa: BLE001
            log("similares: %s" % e)
            return
        if self.gone or not items:
            return
        try:
            lst = self.win.getControl(SIMILAR)
            lst.reset()
            lst.addItems(items)
        except (RuntimeError, TypeError) as e:
            log("similares sin pintar: %s" % e)

    def is_down(self):
        try:
            return self.win.getFocusId() in (CAST, SIMILAR)
        except RuntimeError:
            return False

    def click(self, cid):
        """pulsar en el reparto o en un similar: lo hace flix_info.py en otro proceso (cierra la ficha)"""
        try:
            lst = self.win.getControl(cid)
            pos = lst.getSelectedPosition()
        except RuntimeError:
            return
        req = {"kind": self.kind, "path": self._v(self._path), "fanart": self._v(self._fanart),
               "title": self._v(self._title)}
        if cid == CAST:
            if not 0 <= pos < len(self.people):
                return
            p = self.people[pos]
            req.update(pid=p["id"], name=p["name"])
            what = "person"
        elif cid == SIMILAR:
            item = lst.getSelectedItem()
            if item is None or not item.getPath():
                return
            req.update(kind=kind_of_item(item), path=item.getPath(), fanart=item.getArt("fanart"))
            what = "open"
        else:
            return
        HOME.setProperty(REQ, json.dumps(req))
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_info.py,%s)" % what)


A_SWIPE_UP, A_SWIPE_DOWN = 531, 541      # gestos de Kodi (el dedo va hacia arriba / hacia abajo)


def go_down(win, more):
    """al reparto (o, sin él, a los similares): la ficha sube (FlixMoreSlide). True si había adónde ir"""
    for cid in (CAST, SIMILAR):
        try:
            if win.getControl(cid).size() > 0:
                win.setFocusId(cid)
                return True
        except (RuntimeError, TypeError, AttributeError):
            pass
    return False


def swipe(win, more, aid, up):
    """móvil: deslizar hacia arriba sobre la ficha = bajar a lo de abajo; hacia abajo, estando abajo = volver (up: id
    del control de arriba o función que lo da). True si el gesto era para esto"""
    if more is None or aid not in (A_SWIPE_UP, A_SWIPE_DOWN):
        return False
    if aid == A_SWIPE_UP and not more.is_down():
        return go_down(win, more)
    if aid == A_SWIPE_DOWN and more.is_down():
        try:
            win.setFocusId(up() if callable(up) else up)
        except (RuntimeError, TypeError):
            return False
        return True
    return False


def leaving():
    """¿el Atrás que llega es el de flix_info.close_sheet (cerrar la ficha para abrir otra cosa)? No se borra aquí:
    close_sheet puede mandar un 2.º Atrás; lo quita flix_info.from_sheet al acabar"""
    return bool(HOME.getProperty(LEAVE))


def back(win, more, up):
    """Atrás en la ficha: si el foco está abajo, sube (up: id del control de arriba, o función que lo da) y True; si
    no, False (se cierra)"""
    if more is None or leaving() or not more.is_down():
        return False
    try:
        win.setFocusId(up() if callable(up) else up)
    except (RuntimeError, TypeError):
        return False
    return True
