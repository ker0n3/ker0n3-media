"""Reproducir con fuentes propias (parte 1, 15-nov): Torrentio + Peerflix (+ PeLis) → AllDebrid → castellano primero →
Kodi Player.
Lo llama flix_play.start. Diseño:
docs/superpowers/specs/2026-11-15-enlaces-sin-palantir-design.md

16-nov (enlaces falsos y versión original; docs/superpowers/specs/2026-11-16-inicio-sin-palantir-design.md):
  * antes de subir nada, las versiones pasan flix_src_check.keep (la misma función que decide qué ENSEÑA Ker0n3):
    nivel de estreno, año, marcas de imitación e idioma por el nombre. La ficha de TMDB que piden las reglas se pide
    a la vez que las fuentes (guardada un día); sin ficha, todo como antes.
  * al comprobar el audio (la lectura de siempre, sin peticiones nuevas) se mira también la duración: la película que
    no dura lo que dice TMDB se descarta y se prueba la siguiente.
  * sin castellano ya no es «en inglés»: la versión ORIGINAL (idioma de rodaje) con subtítulos, preguntando antes."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402

import flix_src_check  # noqa: E402
import flix_src_list  # noqa: E402
import flix_src_pick  # noqa: E402

MAX_UPLOAD = 8
MAX_CHECKS = 3
MAX_LIST = 12
CACHE_TTL = 3600
HEADING = "KER0N3 MEDIA"
# plazo total de la búsqueda (listas + AllDebrid + audio), por debajo de flix_play.SEARCH_MAX (30 s), lo que aguanta la
# capa de carga sin nada que cargue: pasado el plazo se usa lo mejor comprobado hasta entonces
SEARCH_DEADLINE = 25
TMDB_IMG = "https://image.tmdb.org/t/p/original"
META_WAIT = 6       # s como mucho esperando la ficha de TMDB (se pide a la vez que las fuentes; flix_src_check.TIMEOUT 5)
# sin ninguna versión en castellano (Carlos, 15-nov tarde, Elena de Ávalor: 13 torrents, ninguno en castellano, y se
# ponía otro idioma sin avisar): se pregunta. 16-nov: lo que se ofrece es la versión ORIGINAL (el idioma en que se
# rodó) con subtítulos en castellano. La misma pregunta en flix_play y en el addon Ker0n3
VO_Q = "No está en castellano.[CR]¿Quieres ver%s en VO subtitulada?"


def vo_question(kind):
    """kind «movie» (verla) o «tv» (un capítulo: verlo)"""
    return VO_Q % ("la" if kind == "movie" else "lo")


class NoCast(str):
    """resultado «no_cast» de play(): hay enlace, pero sin castellano; quien llama hace la pregunta (flix_play).
    Es un str: se compara con "no_cast" como los demás resultados"""
    def __new__(cls, url, cand):
        o = str.__new__(cls, "no_cast")
        o.url, o.cand = url, cand
        return o


def is_cast(c):
    """castellano confirmado (audio leído) o probable (nombre); lo demás (multi, sin datos, latino, otro) no"""
    return flix_src_pick.lang_of(c or {}) in ("cast", "esp")


def direct(c):
    """¿se pone sin preguntar? Castellano, o la versión original de un título rodado en español (cualquier español,
    también latino: ES su versión original y no necesita subtítulos)"""
    c = c or {}
    return is_cast(c) or (c.get("vo_lang") == "es" and c.get("vo") in ("si", "?"))


def want_vo(kind="movie"):
    import xbmcgui
    return bool(xbmcgui.Dialog().yesno(HEADING, vo_question(kind)))


def kind_of(info):
    return "movie" if (info or {}).get("content") == "movies" else "tv"


def tell_no_version(tmdb):
    """ninguna versión de la película pasa las reglas: se le dice al addon Ker0n3 (ruta nover/…), que la apunta como
    «sin versión» y hace que sus filas se vuelvan a pedir: el usuario no se la encuentra otra vez (16-nov, S24,
    «Godzilla Minus Zero»). Por RunPlugin: la skin no importa módulos del addon. Solo con fuentes propias"""
    try:
        import xbmc
        import flix_common
        xbmc.executebuiltin("RunPlugin(%snover/pelicula/%d)" % (flix_common.K3_ROOT, int(tmdb)))
    except Exception as e:  # noqa: BLE001
        log("sin avisar al addon: %s" % e)


def tell_no_episode(tmdb, season, episode):
    """lo mismo con un capítulo que no tiene ninguna versión lista (bloque 3): el addon lo apunta unas horas como
    «Aún no disponible» y la ficha de la serie lo pinta así, debajo de los disponibles"""
    try:
        import xbmc
        import flix_common
        xbmc.executebuiltin("RunPlugin(%snover/capitulo/%d/%d/%d)" % (flix_common.K3_ROOT, int(tmdb), int(season),
                                                                      int(episode)))
    except Exception as e:  # noqa: BLE001
        log("sin avisar al addon: %s" % e)


def usable(cands, meta, lang=True):
    """las versiones que pasan las reglas de flix_src_check (las mismas que deciden qué enseña Ker0n3). lang=False:
    sin la regla del idioma («Elegir versión»: a mano se ve todo lo que sea de verdad el título)"""
    return flix_src_check.keep(cands, meta, lang=lang, log=log)


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_src_play] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def ours(stamp):
    """¿sigue puesta NUESTRA capa de carga? Si no (se quitó sola tras SEARCH_MAX s sin nada que cargue, u otra
    pulsación la renovó), el usuario ya no espera este vídeo: ni se reproduce ni se pregunta nada. Sin marca: sí"""
    if not stamp:
        return True
    import flix_playload
    return flix_playload.HOME.getProperty(flix_playload.PROP) == stamp


def _img(v):
    v = v or ""
    return TMDB_IMG + v if v.startswith("/") else v


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def target(info):
    tmdb = _int((info or {}).get("tmdb"))
    if not tmdb:
        return None
    if info.get("content") == "movies":
        return ("movie", tmdb, None, None)
    s, e = _int(info.get("season")), _int(info.get("episode"))
    if info.get("content") == "episodes" and s and s > 0 and e and e > 0:
        return ("tv", tmdb, s, e)
    return None


K3_PLAYING = "k3_playing"   # Window(10000): qué va a reproducirse, para el servicio de Ker0n3 (base de vistos)
# lo mismo para la skin (flix_follow.own_episode): al acabar un capítulo puesto con fuentes propias, el siguiente lo
# pone ella
OWN_PLAYING = "flix_own_playing"
# lista de subtítulos externos del vídeo anterior (= flix_src_extsubs.PROP / PROP_N, test_src_extsubs): al empezar
# otro vídeo se borra, y con ella el botón «Otro subtítulo» de los controles
EXTSUBS, EXTSUBS_N = "flix_extsubs", "flix_extsubs_n"


def mark_playing(info, url, home=None, now=time.time):
    """deja en Window(10000).k3_playing qué se va a reproducir (JSON kind/tmdb/season/episode/file/at): el servicio de
    Ker0n3 lo apunta en su base al parar. Nunca falla hacia fuera: la reproducción va antes"""
    t = target(info)
    if not t:
        return False
    kind, tmdb, s, e = t
    try:
        if home is None:
            import xbmcgui
            home = xbmcgui.Window(10000)
        try:
            home.clearProperty(EXTSUBS)
            home.clearProperty(EXTSUBS_N)
        except Exception:  # noqa: BLE001
            pass
        mark = json.dumps({"kind": kind, "tmdb": tmdb, "season": s, "episode": e, "file": url or "", "at": now()})
        home.setProperty(K3_PLAYING, mark)
        home.setProperty(OWN_PLAYING, mark)     # y para la skin (el servicio borra la suya al empezar el vídeo)
        return True
    except Exception as ex:  # noqa: BLE001
        log("k3_playing: %s" % ex)
        return False


def _cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/src_cache.json" % xbmc.getSkinDir())


def _fresh(v, now):
    """entrada de la caché con forma [hora, [versiones]] y de hace menos de CACHE_TTL"""
    return (isinstance(v, list) and len(v) == 2 and isinstance(v[0], (int, float)) and isinstance(v[1], list)
            and now() - v[0] < CACHE_TTL)


_ANSWERED = [None, False]   # [clave de la última consulta a las fuentes, ¿contestaron todas?]


def answered(kind, tmdb, season, episode):
    """¿la última búsqueda de candidates fue de ese título y contestaron todas las fuentes? («no hay torrents» de
    verdad, no fuentes caídas)"""
    return _ANSWERED[0] == "%s/%s/%s/%s" % (kind, tmdb, season, episode) and bool(_ANSWERED[1])


def _alias_kw(c):
    """la numeración de IMDb del capítulo, si es otra (flix_src_epmap), para elegir el fichero dentro del torrent"""
    return {"alias": tuple(c["alias"])} if c.get("alias") else {}


def candidates(kind, tmdb, season, episode, now=time.time, cache_path=None):
    path = cache_path or _cache_path()
    key = "%s/%s/%s/%s" % (kind, tmdb, season, episode)
    try:
        with open(path, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    if not isinstance(cache, dict):
        cache = {}
    hit = cache.get(key)
    if _fresh(hit, now):
        return hit[1]
    imdb = flix_src_list.imdb_of(kind, tmdb)
    if not imdb:
        return []
    status = {}
    al = None
    if kind == "tv":        # anime largo (Naruto): la numeración de IMDb no es la de TMDB (flix_src_epmap)
        try:
            import flix_src_epmap
            al = flix_src_epmap.alias(tmdb, imdb, season, episode)
        except Exception:  # noqa: BLE001
            al = None
    found = flix_src_list.fetch(kind, imdb, al[0] if al else season, al[1] if al else episode, status=status)
    if al:
        for c in found:
            c["alias"] = list(al)
    _ANSWERED[:] = [key, bool(status) and all(status.values())]
    if found:
        cache = {k: v for k, v in cache.items() if _fresh(v, now)}
        cache[key] = [now(), found]
        try:
            from flix_common import atomic_write
            atomic_write(path, json.dumps(cache))
        except OSError:
            pass
    return found


def resolve(cands, conf, season=None, episode=None, ad=None, audio=None, deadline=None, now=time.monotonic,
            meta=None):
    """(enlace, versión) o (None, None). Sube a AllDebrid los MAX_UPLOAD primeros torrents (antes los que dejan los
    Ajustes: calidad encendida y remux con permiso), comprueba el audio de hasta MAX_CHECKS listos (se para en el
    primer castellano) y se queda con el mejor de lo comprobado. Los que no dejan los Ajustes solo se prueban si
    ninguno de los otros tiene enlace. PeLis (15-nov): su enlace listo (⚡) se usa tal cual, sin subir nada (también
    se le mira el audio); el pendiente (⏳) nunca se pone solo. La subida se hace solo cuando hace falta el primer
    torrent: si el primero es de PeLis y vale, AllDebrid ni se toca. deadline (en el reloj now): pasado, no se prueba
    ninguno más. No borra nada de la cuenta.
    meta (ficha de flix_src_check; None = sin ella, todo como antes): la película cuya duración no cuadra con TMDB se
    descarta (se apunta por qué) y se sigue con la siguiente; y, sabiendo el idioma original, sin castellano solo
    vale una versión con audio en ese idioma (confirmado antes que sin datos; después, el orden de calidades): queda
    apuntado en la versión («vo»: si / ?, «vo_lang»). Ni castellano ni original: (None, None). Las descartadas y las
    de otro idioma no gastan las MAX_CHECKS comprobaciones; el plazo manda igual"""
    if ad is None:
        import flix_alldebrid as ad
    if audio is None:
        import flix_src_audio as audio
    from flix_alldebrid import ADError

    def late():
        return deadline is not None and now() >= deadline
    lang = (meta or {}).get("lang") or ""
    probe = getattr(audio, "probe", None)
    ranked = [c for c in flix_src_pick.order(cands, conf) if not flix_src_pick.pending(c)]
    first = [c for c in ranked if flix_src_pick.allowed(c, conf)]
    ranked = first + [c for c in ranked if not flix_src_pick.allowed(c, conf)]
    torrents = [c for c in ranked if not c.get("url")][:MAX_UPLOAD]
    keep = {id(c) for c in torrents}
    ranked = [c for c in ranked if c.get("url") or id(c) in keep]
    if not ranked or late():
        return None, None
    state = {"up": None, "err": None}

    def uploaded():
        if state["up"] is None:
            try:
                state["up"] = ad.upload([c["hash"] for c in torrents])
            except ADError as err:
                if not any(c.get("url") for c in ranked):
                    raise
                log("AllDebrid al subir: %s (sigo con PeLis)" % err.kind)
                state["up"], state["err"] = {}, err
        return state["up"]

    def check(group):
        checked, good = [], 0
        for c in group:
            if late():
                log("plazo de %d s agotado: me quedo con lo comprobado (%d)" % (SEARCH_DEADLINE, len(checked)))
                break
            if c.get("url"):
                link = c["url"]     # PeLis listo: enlace ya abierto
            else:
                mid, ready = uploaded().get(c["hash"], (None, False))
                if not ready:
                    continue
                try:
                    link = ad.video_link(mid, season, episode, filename=c.get("filename") or "", **_alias_kw(c))
                except ADError as err:
                    if err.kind in ("sin_clave", "no_premium"):
                        raise
                    log("video_link: %s" % err.kind)
                    continue
                if not link:
                    continue
            p = probe(link) if probe else {"audio": audio.check(link)}
            got = p.get("audio") or "?"
            if got == "cast" and c.get("lat") and not c.get("esp") and not audio.cast_named(p.get("tracks")):
                got = "lat"     # el nombre dice latino y la pista es «spa» sin más: es latino, no castellano
            if got != "?":
                c["audio"] = got
            why = flix_src_check.duration_reason(p.get("duration"), meta)
            if why:
                log("descartada (%s): %s" % (why, (c.get("label") or "")[:90]))
                continue
            if lang:
                c["vo"], c["vo_lang"] = flix_src_check.vo(p.get("tracks"), lang), lang
            checked.append((c, link))
            if flix_src_pick.lang_of(c) == "cast":
                break
            good += not lang or is_cast(c) or c["vo"] != "no"
            if good >= MAX_CHECKS:
                break
        return checked

    def best_of(checked):
        cs = [c for c, _ in checked]
        if not lang or not cs:
            return flix_src_pick.order(cs, conf)[0] if cs else None
        cast = [c for c in cs if is_cast(c)]
        if cast:
            return flix_src_pick.order(cast, conf)[0]
        vo = [c for c in cs if c.get("vo") in ("si", "?")]      # sin castellano: la original, y nunca un tercer idioma
        return flix_src_pick.order(vo, conf, lang=lambda c: 0 if c["vo"] == "si" else 1)[0] if vo else None
    ok = {id(c) for c in first}
    for group in ([c for c in ranked if id(c) in ok], [c for c in ranked if id(c) not in ok]):
        checked = check(group)
        best = best_of(checked)
        if best is not None:
            return next(link for c, link in checked if c is best), best
        if checked:
            log("ninguna en castellano ni en versión original (%s) entre %d comprobadas" % (lang, len(checked)))
    if state["err"] is not None:
        raise state["err"]
    return None, None


def choose(cands, conf, season, episode, ad=None):
    """«Elegir resolución»: lista de las listas en AllDebrid y las de PeLis (las pendientes con «⏳ pendiente»), y la
    elegida tal cual"""
    import xbmcgui
    if ad is None:
        import flix_alldebrid as ad
    from flix_alldebrid import ADError
    ranked = flix_src_pick.order(cands, conf)[:MAX_LIST]
    torrents = [c["hash"] for c in ranked if not c.get("url")]
    try:
        up = ad.upload(torrents) if torrents else {}
    except ADError as err:
        if not any(c.get("url") for c in ranked):
            raise
        log("AllDebrid al subir: %s (solo PeLis)" % err.kind)
        up = {}
    ready = [c for c in ranked if c.get("url") or up.get(c["hash"], (None, False))[1]]
    if not ready:
        return None, None
    i = xbmcgui.Dialog().select("Elegir versión", [flix_src_pick.label(c) for c in ready])
    if i < 0:
        return "cancel", None
    c = ready[i]
    if c.get("url"):
        return c["url"], c
    return ad.video_link(up[c["hash"]][0], season, episode, filename=c.get("filename") or "", **_alias_kw(c)), c


def play(info, offset=0, pick=False, stamp=None):
    """"played" (empezó), "cancelled" (el usuario cerró «Elegir versión»), "none" (nada listo), "error" (AllDebrid, ya
    avisado), "abandoned" (la capa de carga stamp ya no es nuestra: nada que hacer, sin avisos) o NoCast ("no_cast":
    lo mejor no es castellano sino la versión original; no se reproduce: flix_play pregunta). En none/error flix_play
    avisa. Lo elegido a mano en «Elegir versión» se reproduce tal cual"""
    import xbmcgui
    import flix_quality
    import flix_alldebrid
    t = target(info)
    if not t:
        return "none"
    kind, tmdb, s, e = t
    t0 = time.monotonic()
    conf = flix_quality.load()
    cands, url, best, err, found = [], None, None, None, []
    manual = pick or not conf.auto
    # la ficha de TMDB para las reglas, a la vez que las fuentes (guardada un día: lo normal es que no pida nada)
    got = {}
    th = threading.Thread(target=lambda: got.update(meta=flix_src_check.get(kind, tmdb)), name="flix_src_meta",
                          daemon=True)
    th.start()
    try:
        found = candidates(kind, tmdb, s, e)
        if found:               # sin versiones no hay nada que filtrar: no se espera a TMDB
            th.join(META_WAIT)
        meta = got.get("meta")
        # sin ficha no se sabe el idioma original: la regla del idioma no se aplica (como antes)
        cands = usable(found, meta, lang=not manual and meta is not None)
        if not cands:
            log("%s: %s" % (t, "ninguna versión pasa las reglas (%d torrents)" % len(found) if found
                            else "ningún torrent"))
            if found and meta is not None and kind == "movie":
                tell_no_version(tmdb)
        elif manual:
            url, best = choose(cands, conf, s, e)
        else:
            url, best = resolve(cands, conf, s, e, deadline=t0 + SEARCH_DEADLINE, meta=meta)
    except flix_alldebrid.ADError as ex:
        err = ex
    if not ours(stamp):
        log("%s: la capa de carga ya no es nuestra tras %.1f s: no reproduzco ni pregunto" % (t, time.monotonic() - t0))
        return "abandoned"
    if err is not None:
        log("AllDebrid: %s" % err.kind)
        msg = {"sin_clave": "Vincula AllDebrid en Ajustes → Cuentas", "no_premium": "AllDebrid sin premium"}.get(
            err.kind, "No puedo buscar enlaces ahora")
        xbmcgui.Dialog().notification(HEADING, msg, xbmcgui.NOTIFICATION_WARNING, 4000)
        return "error"
    if url == "cancel":
        return "cancelled"
    if not url:
        if cands:
            log("%s: nada listo en AllDebrid (%d torrents, %.1f s)" % (t, len(cands), time.monotonic() - t0))
        if kind == "tv" and (found or answered(kind, tmdb, s, e)):
            # capítulo sin ninguna versión que se pueda poner (no fuentes caídas): «Aún no disponible» en su ficha
            tell_no_episode(tmdb, s, e)
        return "none"
    log("%s: %s (%.1f s, %d torrents)" % (t, flix_src_pick.label(best), time.monotonic() - t0, len(cands)))
    if conf.auto and not pick and not direct(best):       # lo elegido a mano va tal cual
        log("%s: sin versión en castellano: no pongo la original sin preguntar" % (t,))
        return NoCast(url, best)
    vo = manual_vo(best, meta if found else None)
    start_playback(info, url, best, offset, subs=vo)
    return "played"


def manual_vo(best, meta):
    """lo elegido a mano (o sin reproducción automática) que no es castellano: también con subtítulos en castellano y
    el audio en el idioma original (Taboo 1x01 «VO probable» elegida a mano salía sin subtítulos, S24 16-nov). True
    si hay que pedirlos; apunta el idioma original en la versión para flix_src_subs"""
    if not best or is_cast(best) or direct(best):
        return False
    lang = (meta or {}).get("lang") or ""
    if lang and not best.get("vo_lang"):
        best["vo_lang"] = lang
    return True


def start_playback(info, url, cand=None, offset=0, subs=False):
    """reproduce url con el título y las imágenes de la ficha. subs: después, subtítulos en castellano y, si la
    versión trae varias pistas, el audio en el idioma original (cand «vo_lang»): flix_src_subs, en otro hilo"""
    import xbmc
    import xbmcgui
    title = info.get("title") or ""
    li = xbmcgui.ListItem(label=title, path=url)
    li.setArt({"fanart": _img(info.get("fanart")), "poster": _img(info.get("poster") or info.get("thumb"))})
    t = target(info)
    if t and t[0] == "tv" and not title:
        title = "%dx%02d" % (t[2], t[3])    # capítulo de Ker0n3: su ruta no trae el nombre
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if t:
            # su ficha (bloque 3): con ella el reproductor sabe qué suena (VideoPlayer.Season / Episode /
            # UniqueID(tmdb)) → aviso «Siguiente capítulo», «Saltar intro» y «Similares» también con fuentes propias
            tag.setMediaType("movie" if t[0] == "movie" else "episode")
            tag.setUniqueIDs({"tmdb": str(t[1])}, "tmdb")
            if t[0] == "tv":
                tag.setSeason(int(t[2]))
                tag.setEpisode(int(t[3]))
                if info.get("tvshowtitle"):
                    tag.setTvShowTitle(str(info["tvshowtitle"]))
    except (AttributeError, TypeError):     # Kodi sin InfoTag (anterior a 20)
        li.setInfo("video", {"title": title})
    if offset > 0:
        li.setProperty("StartOffset", str(int(offset)))
    mark_playing(info, url)         # el servicio de Ker0n3 lo apunta al parar (base de vistos)
    xbmc.Player().play(url, li, False)
    if subs:
        import flix_src_subs
        lang = (cand or {}).get("vo_lang") or ""
        if lang:
            flix_src_subs.start(url, audio=lang)
        else:
            flix_src_subs.start(url)
    elif flix_src_pick.lang_of(cand or {}) == "cast":
        import flix_src_subs
        flix_src_subs.start_castellano(url)     # varias pistas: que no arranque en italiano o inglés
