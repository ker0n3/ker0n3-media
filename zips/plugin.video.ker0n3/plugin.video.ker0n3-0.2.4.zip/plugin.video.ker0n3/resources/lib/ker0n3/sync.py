"""Ker0n3 ⇄ Simkl (bloque 1; 15-nov). Diseño: docs/superpowers/specs/2026-11-15-base-vistos-ker0n3-design.md.
16-nov: la cola, la base y las reglas de mezcla valen también para Trakt, el servicio principal (syncsvc dice cuál
está en uso; lo propio de Trakt, en trakt_sync). Lo que sigue describe Simkl.

Subir: el servicio encola en disco lo que apunta (pausa con su % o visto con su hora) y aquí se manda de una en una
(scrobble/pause, sync/history), con 1,1 s como poco entre dos (simkl.call). Sin red, sin cupo o sin vínculo, la cola
espera. Bajar (abajo): activities y, si algo cambió, los incrementales a la base, con las reglas del plan 3.
El anime (tipo «anime» de Simkl) no se sube ni se baja: el puente por TVDB marca la entrada entera (comprobado el
15-nov; diseño, sección «Anime»)."""
import calendar
import json
import sqlite3
import threading
import time

QUEUE_MAX = 200     # entradas como mucho (sin red muchos días: lo más viejo sale)
MAX_TRIES = 3       # una entrada que Simkl rechaza (no por red ni cupo) se intenta 3 veces y sale
_qlock = threading.Lock()


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.sync] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def _data(name):
    import xbmcvfs
    import flix_common
    return xbmcvfs.translatePath(flix_common.K3DATA_REL + name)


def queue_path():
    return _data("simkl_queue.json")


def anime_path():
    return _data("simkl_anime.json")


def pauses_path():
    return _data(PAUSES)


def _load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, type(default)) else default
    except (OSError, ValueError):
        return default


def _save(path, data):
    import flix_common
    flix_common.atomic_write(path, json.dumps(data))


def when(stamp_text):
    """«2026-11-15T21:00:00.000Z» (base) → «2026-11-15T21:00:00Z» (Simkl)"""
    return (stamp_text or "")[:19] + "Z" if stamp_text and len(stamp_text) >= 19 else None


FAV = ("fav_add", "fav_del")      # favoritos de la skin ⇄ «Pendientes de ver» (plantowatch) de Simkl
# quitar la pausa que el servicio guarda de un título (16-nov): «Quitar progreso», «no vista» y «vista» del menú. Ni
# sync/history ni sync/history/remove tocan sync/playback (referencia de Trakt), y otro aparato la volvía a bajar
UNPAUSE = "unpause"
SKEW = 600      # s de margen con el reloj del servicio: una pausa de hasta 10 min después de quitarla también sale
# dejar de seguir una serie / volver a seguirla (16-nov): en Trakt, ocultarla del progreso (users/hidden/
# progress_watched). Simkl no tiene nada igual (pasarla a «dropped» cambia su lista): ahí es solo de este aparato
HIDE, UNHIDE = "hide", "unhide"
SHOW_OPS = (HIDE, UNHIDE)
# lo que el servicio tiene en pausa según la última bajada que lo leyó (16-nov): el menú de la skin ofrece «Quitar
# progreso» también para eso, sin red (flix_k3menu.PAUSES_FILE, junto a la base de vistos)
PAUSES = "service_pauses.json"


def _key(it):
    return it.get("kind"), it.get("tmdb"), it.get("season"), it.get("episode")


def _epoch(stamp_text):
    """«2026-11-15T21:00:00Z» o «2026-11-15T21:00:00.000Z» (UTC) → s; 0 si no se entiende"""
    try:
        return calendar.timegm(time.strptime((stamp_text or "")[:19], "%Y-%m-%dT%H:%M:%S"))
    except (TypeError, ValueError):
        return 0


def unpaused(x, kind, tmdb, season=None, episode=None, paused_at=""):
    """¿la entrada x de la cola quita esta pausa? (kind: movie o tv). La de una serie con eps solo esos capítulos;
    sin eps, todos los de la serie. Una pausa más nueva que la orden (más el margen) es de después: se queda"""
    if x.get("op") != UNPAUSE or x.get("kind") != kind or x.get("tmdb") != tmdb:
        return False
    if kind == "tv" and x.get("eps") is not None and [season, episode] not in [list(p) for p in x["eps"]]:
        return False
    until, paused = _epoch(x.get("at")), _epoch(paused_at)
    return not until or not paused or paused <= until + SKEW


def enqueue(op, what, progress=None, at=None, path=None, eps=None, remote=None):
    """op 'pause' (progress %) o 'watched' (at = hora de la base). Lo nuevo de un título sustituye a su pausa
    pendiente; dos vistos del mismo título se mandan los dos. Del menú de la skin (marks.py, 16-nov): 'unwatched'
    (película desmarcada), 'watched_eps' y 'unwatched_eps' (serie marcada o desmarcada: eps = sus capítulos,
    [(temporada, capítulo)], en una sola petición) y 'unpause' (quitar su pausa en el servicio; at = hora de la
    orden. De una serie: eps = esos capítulos, el capítulo de what o, sin ninguno, la serie entera; anula las pausas
    pendientes que cubre y sustituye a la misma orden aún sin resolver; y sale de la lista de pausas del servicio,
    remote o la de siempre). 'hide' / 'unhide' (dejar de seguir / volver a seguir una serie; at = hora de la
    orden): la última de la misma serie sustituye a la anterior aún sin mandar"""
    item = {"op": op, "kind": what["kind"], "tmdb": int(what["tmdb"]), "season": what.get("season"),
            "episode": what.get("episode")}
    if op == "pause":
        item["progress"] = round(float(progress or 0), 2)
    elif op in ("watched", "watched_eps", UNPAUSE) + SHOW_OPS:
        item["at"] = when(at)
    if op in ("watched_eps", "unwatched_eps"):
        item["eps"] = [[int(s), int(e)] for s, e in eps or []]
    if op == UNPAUSE and item["kind"] == "tv":
        if eps is None and item["season"] is not None and item["episode"] is not None:
            eps = [(item["season"], item["episode"])]
        item["eps"] = None if eps is None else [[int(s), int(e)] for s, e in eps]
        item["season"] = item["episode"] = None
    path = path or queue_path()
    with _qlock:
        q = [x for x in _load(path, []) if not (x.get("op") == "pause" and (
            _key(x) == _key(item) or unpaused(dict(item, at=None), x.get("kind"), x.get("tmdb"), x.get("season"),
                                              x.get("episode"))))]
        if op == UNPAUSE:
            q = [x for x in q if not (x.get("op") == UNPAUSE and "pids" not in x and _key(x) == _key(item)
                                      and x.get("eps") == item.get("eps"))] + [item]
        elif op in SHOW_OPS:
            # dejar de seguir y volver a seguir la misma serie sin haberse mandado: manda lo último
            q = [x for x in q if not (x.get("op") in SHOW_OPS and x.get("tmdb") == item["tmdb"])] + [item]
        elif op in FAV:
            # favoritos (bloque 3): añadir y quitar el mismo título sin haberse mandado se anulan
            n = len(q)
            q = [x for x in q if not (x.get("op") in FAV and x.get("op") != op and _key(x) == _key(item))]
            if len(q) == n:
                q = [x for x in q if not (x.get("op") == op and _key(x) == _key(item))] + [item]
        else:
            q.append(item)
        _save(path, q[-QUEUE_MAX:])
    if op == UNPAUSE:       # el menú deja de ofrecer «Quitar progreso» de lo que el servicio ya va a quitar
        forget_paused(item, remote)
    return item


def pending(path=None):
    return bool(_load(path or queue_path(), []))


# ---------- lo que el servicio tiene en pausa (16-nov) ----------
# {"service": nombre, "movies": [tmdb], "episodes": [[tmdb de la serie, temporada, capítulo]]}: lo escribe cada bajada
# que lee sync/playback (sin lo que la cola aún tiene que quitar) y lo lee el menú de la skin, sin red, para ofrecer
# «Quitar progreso» aunque la pausa ya no esté en la base de este aparato (una vieja que solo guarda el servicio)
def paused_list(ch, name):
    return {"service": name, "movies": sorted({r[0] for r in ch.get("movie_pauses") or []}),
            "episodes": sorted({(r[0], r[1], r[2]) for r in ch.get("episode_pauses") or []})}


def save_paused(ch, name, path=None):
    d = paused_list(ch, name)
    d["episodes"] = [list(e) for e in d["episodes"]]
    with _qlock:
        _save(path or pauses_path(), d)


def service_paused(kind, tmdb, season=None, episode=None, path=None):
    """¿el servicio tiene en pausa esa película (kind movie) o ese capítulo (kind tv)?"""
    d = _load(path or pauses_path(), {})
    if kind == "movie":
        return int(tmdb) in (d.get("movies") or [])
    return [int(tmdb), season, episode] in [list(e) for e in d.get("episodes") or []]


def forget_paused(item, path=None):
    """saca de la lista lo que quita una entrada «unpause» (sync.unpaused: la serie entera o sus capítulos). True si
    estaba. Sin lista, nada (no la crea)"""
    path = path or pauses_path()
    with _qlock:
        d = _load(path, {})
        if not d:
            return False
        movies, eps = d.get("movies") or [], [list(e) for e in d.get("episodes") or []]
        x = dict(item, at=None)
        keep_m = [t for t in movies if not unpaused(x, "movie", t)]
        keep_e = [e for e in eps if not (len(e) == 3 and unpaused(x, "tv", e[0], e[1], e[2]))]
        if len(keep_m) == len(movies) and len(keep_e) == len(eps):
            return False
        _save(path, dict(d, movies=keep_m, episodes=keep_e))
    return True


def body_of(it):
    """(ruta, cuerpo) de Simkl para una entrada de la cola"""
    ids = {"ids": {"tmdb": it["tmdb"]}}
    if it["op"] == "pause":
        if it["kind"] == "movie":
            return "/scrobble/pause", {"progress": it["progress"], "movie": ids}
        return "/scrobble/pause", {"progress": it["progress"], "show": ids,
                                   "episode": {"season": it["season"], "number": it["episode"]}}
    if it["op"] in FAV:
        group = "movies" if it["kind"] == "movie" else "shows"
        if it["op"] == "fav_add":
            return "/sync/add-to-list", {group: [dict({"to": "plantowatch"}, **ids)]}
        return "/sync/history/remove", {group: [ids]}       # solo se encola para lo que no tiene nada visto (marks)
    at = {"watched_at": it["at"]} if it.get("at") else {}
    if it["op"] == "unwatched":
        return "/sync/history/remove", {"movies": [ids]}
    if it["op"] in ("watched_eps", "unwatched_eps"):
        if it["op"] == "unwatched_eps":
            at = {}
        by = {}
        for s, e in sorted(tuple(x) for x in it.get("eps") or []):
            by.setdefault(s, []).append(dict({"number": e}, **at))
        return ("/sync/history" if it["op"] == "watched_eps" else "/sync/history/remove"), \
            {"shows": [dict(ids, seasons=[{"number": s, "episodes": by[s]} for s in sorted(by)])]}
    if it["kind"] == "movie":
        return "/sync/history", {"movies": [dict(ids, **at)]}
    return "/sync/history", {"shows": [dict(ids, seasons=[{"number": it["season"],
                                                           "episodes": [dict({"number": it["episode"]}, **at)]}])]}


def anime_of(kind, tmdb, get=None, path=None):
    """¿anime para Simkl? (TMDB: en japonés y de animación, género 16). Guardado por título: una consulta a TMDB la
    primera vez. Sin red lanza (quien llama espera)"""
    path = path or anime_path()
    key = "%s:%s" % (kind, tmdb)
    cache = _load(path, {})
    if key in cache:
        return bool(cache[key])
    if get is None:
        from ker0n3 import catalog
        get = catalog._get
    d = get("/%s/%s" % ("movie" if kind == "movie" else "tv", tmdb)) or {}
    val = d.get("original_language") == "ja" and 16 in [g.get("id") for g in d.get("genres") or []]
    cache[key] = val
    _save(path, cache)
    return val


def playback_ids(x, movies, episodes):
    """ids de las pausas de sync/playback (forma de Trakt y de Simkl) que quita la entrada x de la cola"""
    out = []
    if x["kind"] == "movie":
        for it in movies or []:
            if it.get("id") and unpaused(x, "movie", tmdb_of(it.get("movie")), paused_at=it.get("paused_at")):
                out.append(int(it["id"]))
        return out
    for it in episodes or []:
        e = it.get("episode") or {}
        if it.get("id") and not it.get("anime") and unpaused(x, "tv", tmdb_of(it.get("show")), e.get("season"),
                                                             e.get("number"), it.get("paused_at")):
            out.append(int(it["id"]))
    return out


def _svc(api):
    return getattr(api, "NAME", "simkl")


def resolve_unpause(api, it, path):
    """los ids de las pausas que quita it, y de paso los de todas las «unpause» de la cola aún sin resolver: UNA
    lectura de sync/playback por tipo (solo de los que hagan falta) para todas. Se guardan en cada entrada, por
    servicio («pids»: {servicio: [ids]}; la cola pasa al otro si se cambia): si luego falta red, no se vuelve a leer"""
    name = _svc(api)
    with _qlock:
        todo = [x for x in _load(path, []) if x.get("op") == UNPAUSE and name not in (x.get("pids") or {})]
    kinds = {x.get("kind") for x in todo} | {it["kind"]}
    movies = api.playback("movies") if "movie" in kinds else []
    episodes = api.playback("episodes") if "tv" in kinds else []
    found = [(x, playback_ids(x, movies, episodes)) for x in todo]
    with _qlock:
        q = _load(path, [])
        for x in q:
            for old, pids in found:
                if x == old:
                    x["pids"] = dict(x.get("pids") or {}, **{name: pids})
                    break
        _save(path, q)
    it["pids"] = dict(it.get("pids") or {}, **{name: playback_ids(it, movies, episodes)})


def send_unpause(api, it, path):
    """quita del servicio las pausas de una entrada «unpause»: DELETE sync/playback/<id> de cada una (una escritura
    por segundo, como los POST). Las que ya no están (404) cuentan como hechas"""
    name = _svc(api)
    if name not in (it.get("pids") or {}):
        resolve_unpause(api, it, path)
    for pid in it["pids"][name]:
        if not api.remove_playback(pid):
            log("pausa %s de %s: ya no estaba" % (pid, name))


def _drop(path, it):
    with _qlock:
        q = _load(path, [])
        if it in q:
            q.remove(it)
            _save(path, q)


def _bump(path, it):
    with _qlock:
        q = _load(path, [])
        for x in q:
            if x == it:
                x["tries"] = it.get("tries", 0) + 1
                break
        _save(path, [x for x in q if x.get("tries", 0) < MAX_TRIES])


def _error(api):
    """la excepción del cliente: Error en simkl.py y trakt.py (SimklError en los dobles de las pruebas de Simkl)"""
    return getattr(api, "Error", None) or api.SimklError


def _backend(api):
    """(etiqueta, módulo con lo propio del servicio o None si es Simkl, que vive aquí)"""
    if getattr(api, "NAME", "simkl") == "trakt":
        from ker0n3 import trakt_sync
        return "Trakt", trakt_sync
    return "Simkl", None


def _active():
    from ker0n3 import syncsvc
    return syncsvc.api()


def push_one(api=None, path=None, is_anime=None):
    """manda la primera de la cola al servicio en uso: 'vacía', 'enviado', 'anime' (sale sin mandarse; solo Simkl),
    'solo_aqui' (dejar de seguir / volver a seguir con Simkl: sale sin mandarse), 'otro' (la rechazó: hasta
    MAX_TRIES veces) o lo que hace esperar: 'sin_red', 'sin_cupo', 'sin_vinculo'"""
    if api is None:
        api = _active()
        if api is None:
            return "sin_vinculo"
    label, backend = _backend(api)
    if backend:
        return _push_to(api, path or queue_path(), label, backend)
    path = path or queue_path()
    is_anime = is_anime or anime_of
    with _qlock:
        q = _load(path, [])
    if not q:
        return "vacía"
    it = q[0]
    if it["op"] in SHOW_OPS:
        # Simkl no tiene «ocultar del progreso»: pasar la serie a «dropped» o «hold» cambia su lista (la saca de
        # «viendo») y deshacerlo pide moverla otra vez. Dejar de seguir es solo de este aparato, como antes
        _drop(path, it)
        log("%s %s: con Simkl solo en este aparato" % (it["op"], it["tmdb"]))
        return "solo_aqui"
    try:
        anime = is_anime(it["kind"], it["tmdb"])
    except Exception as e:  # noqa: BLE001  (TMDB sin red: se espera como con Simkl)
        log("¿anime %s %s?: %s" % (it["kind"], it["tmdb"], e))
        return "sin_red"
    if anime:
        _drop(path, it)
        log("anime %s %s: no se sube a Simkl" % (it["kind"], it["tmdb"]))
        return "anime"
    if it["op"] == UNPAUSE:
        return _send(api, path, it, "Simkl", lambda: send_unpause(api, it, path))
    return _send(api, path, it, "Simkl", lambda: api.post(*body_of(it)))


def _send(api, path, it, label, send):
    try:
        send()
    except _error(api) as e:
        if e.kind in ("sin_red", "sin_cupo", "sin_vinculo"):
            return e.kind
        log("%s rechaza %s %s %s: %s" % (label, it["op"], it["kind"], it["tmdb"], e))
        _bump(path, it)
        return "otro"
    _drop(path, it)
    log("subido a %s: %s %s %s" % (label, it["op"], it["kind"], it["tmdb"]))
    return "enviado"


def _push_to(api, path, label, backend):
    """la primera de la cola con lo propio de un servicio que no es Simkl (sin exclusión de anime)"""
    with _qlock:
        q = _load(path, [])
    if not q:
        return "vacía"
    return _send(api, path, q[0], label, lambda: backend.send(api, q[0], queue=path))


# ---------- bajar (reglas del plan 3 de Simkl, sobre la base de Ker0n3 y sin anime) ----------
KINDS = {"movies": "movies", "tv_shows": "shows"}      # sección de activities → tipo de all-items (sin «anime»)


READ_PAUSES = "_pauses"     # plan_changes lo pone en los cambios si ha leído sync/playback (down lo quita)


class SchemaError(Exception):
    pass


def state_path(name="simkl"):
    """el estado de la bajada es de cada servicio: volver a uno retoma donde lo dejó"""
    return _data("%s_state.json" % name)


def db_date(s):
    """«2026-11-14T23:30:21Z» → «2026-11-14T23:30:21.000Z» (formato de la base)"""
    return (s or "")[:19] + ".000Z" if s else ""


def tmdb_of(obj):
    try:
        return int(((obj or {}).get("ids") or {}).get("tmdb") or 0) or None
    except (TypeError, ValueError):
        return None


def _runtime(obj):
    try:
        return int((obj or {}).get("runtime") or 0) * 60
    except (TypeError, ValueError):
        return 0


def read_movies(data):
    """vistas: [(tmdb, lastPlayed, runtime_s)]"""
    out = []
    for it in (data or {}).get("movies") or []:
        m = it.get("movie") or {}
        t = tmdb_of(m)
        if t and it.get("status", "completed") == "completed" and it.get("last_watched_at"):
            out.append((t, db_date(it["last_watched_at"]), _runtime(m)))
    return out


def read_shows(data):
    """(capítulos vistos [(tmdb, temporada, capítulo, lastPlayed)], series [(tmdb, total emitidos, completa,
    ocultar)]). Solo «shows»: lo de «anime» no se lee"""
    eps, shows = [], []
    for it in (data or {}).get("shows") or []:
        t = tmdb_of(it.get("show"))
        if not t:
            continue
        for season in it.get("seasons") or []:
            n = season.get("number")
            if not isinstance(n, int) or n < 1:
                continue
            for e in season.get("episodes") or []:
                if e.get("watched_at") and isinstance(e.get("number"), int):
                    eps.append((t, n, e["number"], db_date(e["watched_at"])))
        total = int(it.get("total_episodes_count") or 0) - int(it.get("not_aired_episodes_count") or 0)
        shows.append((t, max(total, 0), int(it.get("status") == "completed"), int(it.get("status") == "dropped")))
    return eps, shows


def read_pauses(movies, episodes):
    """([(tmdb, %, lastPlayed, runtime_s)], [(tmdb, temporada, capítulo, %, lastPlayed)]); sin especiales ni anime
    (sus pausas vienen con la clave «anime»: resultados del 15-nov)"""
    mp, ep = [], []
    for it in movies or []:
        t = tmdb_of(it.get("movie"))
        if t and it.get("paused_at"):
            mp.append((t, float(it.get("progress") or 0), db_date(it["paused_at"]), _runtime(it.get("movie"))))
    for it in episodes or []:
        if it.get("anime"):
            continue
        t, e = tmdb_of(it.get("show")), it.get("episode") or {}
        if t and it.get("paused_at") and isinstance(e.get("season"), int) and e["season"] >= 1 \
                and isinstance(e.get("number"), int):
            ep.append((t, e["season"], e["number"], float(it.get("progress") or 0), db_date(it["paused_at"])))
    return mp, ep


def read_list(data):
    """ids de TMDB de una lista de pendientes de Simkl (películas y series; anime no)"""
    out = set()
    for key, inner in (("movies", "movie"), ("shows", "show")):
        for it in (data or {}).get(key) or []:
            t = tmdb_of(it.get(inner))
            if t:
                out.add(t)
    return out


def _apply(c, ch):
    n = 0
    for t, last, rt in ch.get("movies") or []:
        n += c.execute("INSERT OR IGNORE INTO movies_watched (tmdb_id, playcount, progress, runtime, lastPlayed) "
                       "VALUES (?, 1, 0.0, ?, ?)", (t, rt, last)).rowcount
        n += c.execute("UPDATE movies_watched SET playcount = MAX(playcount, 1), progress = 0.0, lastPlayed = ? "
                       "WHERE tmdb_id = ? AND (playcount = 0 OR progress > 0) AND IFNULL(lastPlayed, '') <= ?",
                       (last, t, last)).rowcount
    for t, s, e, last in ch.get("episodes") or []:
        n += c.execute("INSERT OR IGNORE INTO episodes_watched (tmdb_id, season, episode, playcount, progress, "
                       "runtime, lastPlayed) VALUES (?, ?, ?, 1, 0.0, 0, ?)", (t, s, e, last)).rowcount
        n += c.execute("UPDATE episodes_watched SET playcount = MAX(playcount, 1), progress = 0.0, lastPlayed = ? "
                       "WHERE tmdb_id = ? AND season = ? AND episode = ? AND (playcount = 0 OR progress > 0) "
                       "AND IFNULL(lastPlayed, '') <= ?", (last, t, s, e, last)).rowcount
    for t, total, done, hide in ch.get("shows") or []:
        n += c.execute("UPDATE shows_watched SET num_total_episodios = ?, completa = ? WHERE tmdb_id = ? "
                       "AND (num_total_episodios != ? OR completa != ?)", (total, done, t, total, done)).rowcount
        if hide:
            n += c.execute("UPDATE shows_watched SET ocultar = 1 WHERE tmdb_id = ? AND ocultar = 0", (t,)).rowcount
    for t, pct, last, rt in ch.get("movie_pauses") or []:
        n += c.execute("INSERT OR IGNORE INTO movies_watched (tmdb_id, playcount, progress, runtime, lastPlayed) "
                       "VALUES (?, 0, ?, ?, ?)", (t, pct, rt, last)).rowcount
        n += c.execute("UPDATE movies_watched SET progress = ?, lastPlayed = ?, runtime = CASE WHEN ? > 0 THEN ? "
                       "ELSE runtime END WHERE tmdb_id = ? AND IFNULL(lastPlayed, '') < ?",
                       (pct, last, rt, rt, t, last)).rowcount
    for t, s, e, pct, last in ch.get("episode_pauses") or []:
        n += c.execute("INSERT OR IGNORE INTO episodes_watched (tmdb_id, season, episode, playcount, progress, "
                       "runtime, lastPlayed) VALUES (?, ?, ?, 0, ?, 0, ?)", (t, s, e, pct, last)).rowcount
        n += c.execute("UPDATE episodes_watched SET progress = ?, lastPlayed = ? WHERE tmdb_id = ? AND season = ? "
                       "AND episode = ? AND IFNULL(lastPlayed, '') < ?", (pct, last, t, s, e, last)).rowcount
    for t, content in ch.get("fav_add") or []:
        n += c.execute("INSERT OR IGNORE INTO favorites (tmdb_id, content) VALUES (?, ?)", (t, content)).rowcount
    for t, content in ch.get("fav_del") or []:
        n += c.execute("DELETE FROM favorites WHERE tmdb_id = ? AND content = ?", (t, content)).rowcount
    # series ocultas en el servicio (Trakt, 16-nov): se deja de seguir lo oculto allí salvo que tenga un capítulo
    # visto después de ocultarla (sin fecha, siempre); y se vuelve a seguir lo que allí ya no lo está («desde»
    # vacío) o tiene un capítulo visto después de esa fecha. Después de los capítulos: así cuentan los recién bajados
    newer = ("EXISTS (SELECT 1 FROM episodes_watched WHERE tmdb_id = ? AND season > 0 AND playcount > 0 "
             "AND lastPlayed > ?)")
    for t, at in ch.get("hide") or []:
        n += c.execute("UPDATE shows_watched SET ocultar = 1 WHERE tmdb_id = ? AND ocultar = 0 AND (? = '' OR NOT "
                       + newer + ")", (t, at or "", t, at or "")).rowcount
    for t, since in ch.get("unhide") or []:
        n += c.execute("UPDATE shows_watched SET ocultar = 0 WHERE tmdb_id = ? AND ocultar = 1 AND (? = '' OR "
                       + newer + ")", (t, since or "", t, since or "")).rowcount
    return n


# ---------- espejo: manda el servicio (16-nov) ----------
# Carlos: «Lo que debe mandar es Trakt; eso es lo que debe plasmarse en todos los dispositivos» (fallo de Verity: su
# pausa quitada en la Shield seguía en «Seguir viendo» del móvil). De cada lista que la bajada lee ENTERA (plan_changes:
# ch["mirror"]), lo de aquí que el servicio no tiene sale, sin encolar nada: pausas (película y capítulo, sin
# especiales), películas y capítulos vistos, favoritos y series ocultas. Solo sobrevive lo que tiene algo pendiente en
# la cola (cualquier entrada del título: la intención de aquí aún sin mandar) y lo tocado aquí después de empezar la
# bajada (lastPlayed posterior). Salvaguardas por parte (no se toca y se dice por qué): lista sin acabar, 0 en el
# servicio con más de MIRROR_MIN aquí, y la cuenta distinta de la de la última bajada (down). Simkl: solo pausas (sus
# vistos llegan por incrementos y su lista de pendientes no admite lo empezado) y nunca anime (solo sale lo que
# simkl_anime.json dice que no lo es)
MIRROR_MIN = 20


def pause_keys(ch):
    """lo que el servicio tiene en pausa según los cambios leídos (sin enmascarar)"""
    return {"movies": sorted({r[0] for r in ch.get("movie_pauses") or []}),
            "episodes": sorted({(r[0], r[1], r[2]) for r in ch.get("episode_pauses") or []})}


def _mirror(c, m):
    """aplica el espejo m (ver arriba) dentro de la transacción de write; apunta en m["done"] cuánto ha quitado y en
    m["skipped"] las partes que no ha tocado. Filas tocadas"""
    keep = {(k, t) for k, t in m.get("keep") or []}
    cutoff = m.get("cutoff") or ""
    only = None if m.get("only") is None else {(k, t) for k, t in m["only"]}
    label = m.get("label") or "el servicio"
    done = m.setdefault("done", {"pauses": 0, "movies": 0, "episodes": 0, "fav": 0, "hidden": 0})

    def may(kind, t, last=""):
        return (kind, t) not in keep and (last or "") < cutoff and (only is None or (kind, t) in only)

    def sane(what, theirs, mine):
        if not theirs and len(mine) > MIRROR_MIN:
            m["skipped"].append("%s sin tocar (0 en %s y %d aquí)" % (what, label, len(mine)))
            return False
        return True
    if m.get("pauses") is not None:
        pm = set(m["pauses"].get("movies") or [])
        pe = {tuple(x) for x in m["pauses"].get("episodes") or []}
        mine_m = c.execute("SELECT tmdb_id, lastPlayed FROM movies_watched WHERE progress > 0").fetchall()
        mine_e = c.execute("SELECT tmdb_id, season, episode, lastPlayed FROM episodes_watched WHERE progress > 0 "
                           "AND season > 0").fetchall()
        if sane("pausas", pm or pe, mine_m + mine_e):
            for t, last in mine_m:
                if t not in pm and may("movie", t, last):
                    done["pauses"] += c.execute("UPDATE movies_watched SET progress = 0.0 WHERE tmdb_id = ?",
                                                (t,)).rowcount
            for t, s, e, last in mine_e:
                if (t, s, e) not in pe and may("tv", t, last):
                    done["pauses"] += c.execute("UPDATE episodes_watched SET progress = 0.0 WHERE tmdb_id = ? AND "
                                                "season = ? AND episode = ?", (t, s, e)).rowcount
    if m.get("movies") is not None:
        theirs = set(m["movies"])
        mine = c.execute("SELECT tmdb_id, lastPlayed FROM movies_watched WHERE playcount > 0").fetchall()
        if sane("vistos de películas", theirs, mine):
            for t, last in mine:
                if t not in theirs and may("movie", t, last):
                    done["movies"] += c.execute("UPDATE movies_watched SET playcount = 0 WHERE tmdb_id = ?",
                                                (t,)).rowcount
    if m.get("episodes") is not None:
        theirs = {tuple(x) for x in m["episodes"].get("seen") or []}
        unknown = set(m["episodes"].get("unknown") or [])
        mine = c.execute("SELECT tmdb_id, season, episode, progress, lastPlayed FROM episodes_watched "
                         "WHERE playcount > 0 AND season > 0").fetchall()
        if sane("vistos de capítulos", theirs, mine):
            shows = set()
            for t, s, e, pct, last in mine:
                if (t, s, e) in theirs or t in unknown or not may("tv", t, last):
                    continue
                if pct and pct > 0:     # se queda su pausa (si el servicio la tiene: espejo de pausas)
                    c.execute("UPDATE episodes_watched SET playcount = 0 WHERE tmdb_id = ? AND season = ? "
                              "AND episode = ?", (t, s, e))
                else:
                    c.execute("DELETE FROM episodes_watched WHERE tmdb_id = ? AND season = ? AND episode = ?",
                              (t, s, e))
                done["episodes"] += 1
                shows.add(t)
            for t in shows:
                c.execute("UPDATE shows_watched SET completa = 0 WHERE tmdb_id = ?", (t,))
    if m.get("fav") is not None:
        theirs = {(t, content) for content in ("movies", "shows") for t in m["fav"].get(content) or []}
        mine = c.execute("SELECT tmdb_id, content FROM favorites").fetchall()
        if sane("favoritos", theirs, mine):
            for t, content in mine:
                if (t, content) not in theirs and may("movie" if content == "movies" else "tv", t):
                    done["fav"] += c.execute("DELETE FROM favorites WHERE tmdb_id = ? AND content = ?",
                                             (t, content)).rowcount
    if m.get("hidden") is not None:
        theirs = set(m["hidden"])
        mine = [r[0] for r in c.execute("SELECT tmdb_id FROM shows_watched WHERE ocultar = 1")]
        if sane("ocultas", theirs, mine):
            for t in mine:
                if t not in theirs and may("tv", t):
                    done["hidden"] += c.execute("UPDATE shows_watched SET ocultar = 0 WHERE tmdb_id = ?",
                                                (t,)).rowcount
    return sum(done.values())


def mirror_summary(label, m):
    d = m.get("done") or {}
    return "espejo de %s: −%d pausas, −%d vistos (%d películas, %d capítulos), −%d favoritos, −%d ocultas" % (
        label, d.get("pauses", 0), d.get("movies", 0) + d.get("episodes", 0), d.get("movies", 0),
        d.get("episodes", 0), d.get("fav", 0), d.get("hidden", 0))


def _account(name):
    """la cuenta vinculada en este aparato (el nombre que guarda link.py en la skin); «» si no se sabe"""
    try:
        import xbmc
        from ker0n3 import link
        return (xbmc.getInfoLabel("Skin.String(%s)" % link.SERVICES[name]["user"]) or "").strip()
    except Exception:  # noqa: BLE001
        return ""


def write(db_path, ch):
    """aplica los cambios en una transacción; cuántas filas tocó. SchemaError si la base no es la esperada"""
    from ker0n3 import store

    def go(c):
        if not store.schema_ok(c):
            raise SchemaError("base sin las columnas esperadas: no escribo")
        n = _apply(c, ch)
        if ch.get("mirror"):
            n += _mirror(c, ch["mirror"])
        return n
    return store.transaction(db_path, go)


def plan_changes(acts, prev, api):
    """lo que hay que pedir según qué fechas de activities se movieron desde prev: (cambios para write, estado nuevo).
    Primera vez (prev vacío): todo lo que tenga fecha, sin date_from. La sección «anime» no se mira"""
    p_acts = prev.get("acts") or {}
    fav_prev = prev.get("fav") or {"movies": [], "shows": []}

    def moved(sec, key):
        now = (acts.get(sec) or {}).get(key)
        return bool(now) and now != (p_acts.get(sec) or {}).get(key)

    ch = {"movies": [], "episodes": [], "shows": [], "movie_pauses": [], "episode_pauses": [],
          "fav_add": [], "fav_del": []}
    if moved("movies", "completed") or moved("movies", "all"):
        ch["movies"] += read_movies(api.all_items("movies", "completed",
                                                  date_from=(p_acts.get("movies") or {}).get("all")))
    if moved("tv_shows", "all"):
        eps, shows = read_shows(api.all_items("shows", "", date_from=(p_acts.get("tv_shows") or {}).get("all")))
        ch["episodes"] += eps
        ch["shows"] += shows
    if moved("movies", "playback") or moved("tv_shows", "playback"):
        # borrar una pausa no mueve activities (resultados del plan 1): lista entera; lo de aquí que ya no está sale
        # (espejo, 16-nov) cuando se lee
        pm, pe = api.playback("movies"), api.playback("episodes")
        ch["movie_pauses"], ch["episode_pauses"] = read_pauses(pm, pe)
        ch[READ_PAUSES] = True
        if isinstance(pm, list) and isinstance(pe, list):
            ch["mirror"] = {"skipped": [], "pauses": pause_keys(ch)}
    fav = {"movies": list(fav_prev.get("movies") or []), "shows": list(fav_prev.get("shows") or [])}
    for content, sec in (("movies", "movies"), ("shows", "tv_shows")):
        if moved(sec, "plantowatch") or moved(sec, "removed_from_list"):
            now_ids = read_list(api.all_items(KINDS[sec], "plantowatch"))
            mine = set(fav[content])
            ch["fav_add"] += [(t, content) for t in sorted(now_ids - mine)]
            ch["fav_del"] += [(t, content) for t in sorted(mine - now_ids)]
            fav[content] = sorted(now_ids)
    return ch, {"acts": {s: acts.get(s) or {} for s in KINDS}, "fav": fav}


def mask(ch, queue):
    """quita de lo bajado lo que la cola aún tiene que desmarcar: un «no visto» de aquí que no ha subido no vuelve
    con la bajada (Trakt da listas enteras, y un capítulo desmarcado ya no tiene fila que lo proteja). Lo mismo con
    las pausas que la cola aún tiene que quitar (16-nov), salvo las de después de la orden (unpaused)"""
    un = [x for x in queue if x.get("op") == UNPAUSE]
    if un:
        ch["movie_pauses"] = [r for r in ch.get("movie_pauses") or []
                              if not any(unpaused(x, "movie", r[0], paused_at=r[2]) for x in un)]
        ch["episode_pauses"] = [r for r in ch.get("episode_pauses") or []
                                if not any(unpaused(x, "tv", r[0], r[1], r[2], r[4]) for x in un)]
    movies = {x.get("tmdb") for x in queue if x.get("op") == "unwatched"}
    eps = {(x.get("tmdb"), int(s), int(e)) for x in queue if x.get("op") == "unwatched_eps"
           for s, e in x.get("eps") or []}
    if movies:
        ch["movies"] = [r for r in ch.get("movies") or [] if r[0] not in movies]
    if eps:
        ch["episodes"] = [r for r in ch.get("episodes") or [] if (r[0], r[1], r[2]) not in eps]
    shows = {x.get("tmdb") for x in queue if x.get("op") in SHOW_OPS}
    for key in ("hide", "unhide"):      # dejar de seguir / volver a seguir de aquí que aún no ha subido: manda aquí
        if shows and ch.get(key):
            ch[key] = [r for r in ch[key] if r[0] not in shows]
    return ch


def down(api=None, db_path=None, state_file=None, queue_file=None, user=None):
    """una bajada del servicio en uso: filas escritas (0 = nada nuevo), -1 si no se pudo (se reintenta en la
    siguiente; el estado solo se guarda si todo fue bien). Deja la base como el servicio en lo que lee entero
    (_mirror). user: la cuenta vinculada (por defecto la que apuntó link.py)"""
    if api is None:
        api = _active()
        if api is None:
            return -1
    label, backend = _backend(api)
    name = _svc(api)
    state_file = state_file or state_path(name)
    prev = _load(state_file, {})
    from ker0n3 import store
    cutoff = store.stamp()          # lo tocado aquí desde ahora (un vídeo que se para a media bajada) se queda
    user = _account(name) if user is None else user
    try:
        if backend:
            ch, new = backend.plan_changes(api.last_activities(), prev, api)
        else:
            ch, new = plan_changes(api.activities(), prev, api)
        read = ch.pop(READ_PAUSES, False)
        if not read and _load(pauses_path(), {}).get("service") != name:
            # la lista de pausas del servicio aún no existe (estreno) o es del otro servicio: se piden una vez
            pm, pe = api.playback("movies"), api.playback("episodes")
            ch["movie_pauses"], ch["episode_pauses"] = read_pauses(pm, pe)
            read = True
            if isinstance(pm, list) and isinstance(pe, list) and getattr(pm, "complete", True) and \
                    getattr(pe, "complete", True):
                ch["mirror"] = dict(ch.get("mirror") or {"skipped": []}, pauses=pause_keys(ch))
        with _qlock:
            queue = _load(queue_file or queue_path(), [])
        mask(ch, queue)
        m = ch.get("mirror")
        if m and prev.get("user") and user and prev["user"] != user:
            log("espejo de %s: la cuenta ha cambiado desde la última bajada: no se quita nada" % label)
            ch.pop("mirror")
        elif m:
            m.update(label=label, cutoff=cutoff, keep=sorted({("movie" if x.get("kind") == "movie" else "tv",
                                                                x.get("tmdb")) for x in queue}))
            if not backend:     # Simkl: nunca anime; solo sale lo que se sabe que no lo es
                known = _load(anime_path(), {})
                m["only"] = sorted({tuple(k.split(":", 1)) for k, v in known.items() if v is False})
                m["only"] = [(k, int(t)) for k, t in m["only"] if t.isdigit()]
    except Exception as e:  # noqa: BLE001 (error del cliente: sin red, sin cupo, sin vínculo; o respuesta rara)
        log("no bajo de %s: %s" % (label, e))
        return -1
    n = 0
    if any(ch.values()):
        try:
            if db_path is None:
                from ker0n3 import store
                db_path = store.path()
            n = write(db_path, ch)
        except (SchemaError, sqlite3.Error) as e:
            log("no escribo en la base: %s" % e)
            return -1
        log("bajado de %s: %d vistas, %d capítulos, %d pausas, +%d/-%d pendientes, %d/%d ocultas (%d filas)" % (
            label, len(ch["movies"]), len(ch["episodes"]), len(ch["movie_pauses"]) + len(ch["episode_pauses"]),
            len(ch["fav_add"]), len(ch["fav_del"]), len(ch.get("hide") or []), len(ch.get("unhide") or []), n))
    m = ch.get("mirror")
    if m:
        for why in m.get("skipped") or []:
            log("espejo de %s: %s" % (label, why))
        log(mirror_summary(label, m))
    if read:
        save_paused(ch, name)
    if user:
        new = dict(new, user=user)
    elif prev.get("user"):
        new = dict(new, user=prev["user"])
    if new != prev:
        _save(state_file, new)
    return n
