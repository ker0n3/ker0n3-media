"""Servicio de Ker0n3 (bloque 1; 15-nov). Diseño: docs/superpowers/specs/2026-11-15-base-vistos-ker0n3-design.md.

Vigila el reproductor: al empezar mira qué es (Window(10000).k3_playing, que pone flix_src_play.mark_playing desde la
skin o desde la ruta play del addon); mientras suena, apunta posición y duración cada segundo; al parar o acabar lo
guarda en la base (store.record), lo encola para el servicio en uso (Trakt o Simkl; syncsvc) y pide a la skin que
repinte. Sincroniza con él (sync) al arrancar, al acabar un vídeo y cada pocos minutos con alguien delante. La red va en otro
hilo: el bucle nunca se queda esperando. Lo comprobable (claim, poke, Tracker, Clock) va aparte del bucle de Kodi."""
import json
import threading
import time

K3_PLAYING = "k3_playing"       # = flix_src_play.K3_PLAYING (test_k3_service)
SYNC_NOW = "k3_sync_now"        # Window(10000): «Sincronizar ahora» (link.menu) o recién vinculado
LOST = "k3_sync_lost_"          # Window(10000), + servicio: ya se avisó de que se desvinculó (aviso único por sesión)
CLAIM_AGE = 600                 # s que vale una marca k3_playing
START_DELAY = 30                # s tras arrancar Kodi hasta la primera sincronización
# 16-nov (Carlos, «debería ser automático»): cada pocos minutos. Cada mirada es una consulta pequeña
# (last_activities) si no hay cambios: muy lejos del cupo de Trakt (500 lecturas cada 5 min por usuario)
MIN_GAP, PERIOD, IDLE, IDLE_CAP = 60, 300, 120, 1800
TICK = 1.0
ACTIVE_EVERY = 5                # s entre dos miradas a qué servicio sincroniza (tres ficheros pequeños)
# filas personales del Inicio: (src de la fila TV para flix_rl_<src>, id para fh_refetch_row)
ROWS = (("FlixPathSeguir", "5101"), ("FlixPathSiguiendo", "5102"))
# repaso de las listas del Inicio (bloque 2; lists.warm): empieza LIST_START s tras arrancar, LIST_GAP s entre lista y
# lista, LIST_IDLE s entre miradas cuando no hay nada que repasar, LIST_RETRY s antes de reintentar una que quedó a medias
LIST_START, LIST_GAP, LIST_IDLE, LIST_RETRY = 45, 20, 60, 600


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.service] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def claim(raw, playing_file, now, max_age=CLAIM_AGE):
    """lo que se reproduce según k3_playing, o None si no es nuestro: otro fichero (tráiler, otro origen) o una marca
    vieja"""
    try:
        d = json.loads(raw or "")
    except ValueError:
        return None
    if not isinstance(d, dict) or d.get("kind") not in ("movie", "tv"):
        return None
    tmdb = _int(d.get("tmdb"))
    try:
        at = float(d.get("at") or 0)
    except (TypeError, ValueError):
        return None
    if not tmdb or now - at > max_age:
        return None
    f = d.get("file") or ""
    if f and playing_file and f != playing_file:
        return None
    return {"kind": d["kind"], "tmdb": tmdb, "season": _int(d.get("season")), "episode": _int(d.get("episode"))}


def poke(home, run, now=time.time):
    """que la skin vuelva a pedir «Seguir viendo» y «Series en seguimiento» y repinte ✓ y barras"""
    for src, _rid in ROWS:
        try:
            cur = int(home.getProperty("flix_rl_%s" % src) or 0)
        except ValueError:
            cur = 0
        home.setProperty("flix_rl_%s" % src, str(max(int(now() * 10), cur + 1)))
    ids = [x for x in home.getProperty("fh_refetch_row").split(",") if x]
    home.setProperty("fh_refetch_row", ",".join(ids + [rid for _s, rid in ROWS if rid not in ids]))
    home.setProperty("fh_progress", "1")
    run("RunScript(special://skin/scripts/flix_progress.py,menu)")


class Tracker:
    """lo que suena: start al empezar, tick cada segundo, stop al parar o acabar (record y, si se apuntó, after)"""

    def __init__(self, record, after, now=time.time):
        self.record, self.after, self.now = record, after, now
        self.what, self.pos, self.total = None, 0.0, 0.0

    def start(self, what):
        if self.what:
            self.stop()             # otro vídeo sin parar el anterior (siguiente capítulo): lo visto del anterior
        self.what, self.pos, self.total = what, 0.0, 0.0

    def tick(self, position, total):
        if self.what and position is not None and position >= 0:
            self.pos = float(position)
            if total and total > 0:
                self.total = float(total)

    def stop(self, ended=False):
        what, self.what = self.what, None
        if not what:
            return None
        pos = self.total if ended and self.total > 0 else self.pos
        now = self.now()
        try:
            result = self.record(what, pos, self.total, now)
        except Exception as e:  # noqa: BLE001  (nunca se cae el servicio por una base rota)
            log("no apunto %s %s: %s" % (what.get("kind"), what.get("tmdb"), e))
            return None
        log("%s %s %s/%s → %s" % (what.get("kind"), what.get("tmdb"), int(pos), int(self.total), result))
        if result in ("paused", "watched"):
            try:
                self.after(what, result, pos, self.total, now)
            except Exception as e:  # noqa: BLE001
                log("tras apuntar: %s" % e)
        return result


class Clock:
    """cuándo bajar del servicio en uso: al arrancar tras START_DELAY s, al acabar de reproducir, al
    volver tras IDLE s sin tocar nada y cada PERIOD s con alguien delante (menos de IDLE_CAP s sin tocar); nunca
    reproduciendo ni a menos de MIN_GAP s de la anterior (salvo la del arranque)"""

    def __init__(self, started):
        self.first, self.last = started + START_DELAY, 0.0
        self.st = {"played": False, "was_idle": False, "away": False}

    def due(self, now, playing, idle, home=None):
        """home: ¿se ve el Inicio? (None = no se sabe: sin esa regla). Volver a él desde otra pantalla también baja"""
        if home is False:
            self.st["away"] = True
        if playing:
            self.st["played"] = True
            return None
        if self.first is not None:
            if now < self.first:
                return None
            self.first = None
            return "al arrancar"
        reason = None
        if self.st["played"]:
            self.st["played"] = False
            reason = "tras reproducir"
        if idle >= IDLE:
            self.st["was_idle"] = True
        elif self.st["was_idle"]:
            self.st["was_idle"] = False
            reason = reason or "al volver tras un rato sin uso"
        if reason is None and home and self.st["away"]:
            reason = "al volver al Inicio"
        if reason is None and now - self.last >= PERIOD and idle < IDLE_CAP:
            reason = "periódica"
        if reason and now - self.last < MIN_GAP:
            return None
        if reason == "al volver al Inicio" or (reason and home):
            self.st["away"] = False
        return reason

    def done(self, now):
        self.last = now


class Background:
    """un trabajo de red a la vez, en otro hilo: el bucle sigue apuntando la posición cada segundo"""

    def __init__(self):
        self.t = None

    def busy(self):
        return self.t is not None and self.t.is_alive()

    def go(self, fn):
        if self.busy():
            return False

        def safe():
            try:
                fn()
            except Exception as e:  # noqa: BLE001
                log("%s: %s" % (getattr(fn, "__name__", "trabajo"), e))
        self.t = threading.Thread(target=safe, daemon=True)
        self.t.start()
        return True


def list_job(home, st, should_stop, now=time.time, lists=None, cache=None, tcache=None):
    """un paso del repaso de listas (en otro hilo): la que haya pedido una ruta (k3_lists_want) o, si no, la que más
    lleve sin repasar. st = {"next": cuándo volver a mirar, "retry": {clave: hasta cuándo no reintentarla}}.
    Devuelve la clave repasada o None"""
    from ker0n3 import catalog
    if lists is None:
        from ker0n3 import lists
    cache, tcache = cache or lists.default_cache(), tcache or catalog.default_cache()
    cache.refresh()                 # lo que hayan escrito las rutas del addon desde la última vez
    tcache.refresh()
    key = lists.take_wanted(home) or lists.due(cache, now=now, retry=st["retry"])
    if not key:
        # sin listas que repasar: las tarjetas de las secciones (bloques 4 y 5), de pocas en pocas
        from ker0n3 import cards
        try:
            done = cards.job(home, st, should_stop, now=now, cache=cache, tcache=tcache)
        finally:
            cache.flush()
            tcache.flush()
        st["next"] = now() + (LIST_GAP if done else LIST_IDLE)
        return None
    try:
        r = lists.warm(key, cache, tcache, should_stop=should_stop, now=now)
    finally:
        cache.flush()
        tcache.flush()
        st["next"] = now() + LIST_GAP
    log("lista %s: %d comprobados, %d con versión (%d en castellano), %d sin saber%s" % (
        key, r["checked"], r["ok"], r.get("esp", 0), r["unknown"], "" if r["complete"] else " (a medias)"))
    if r["complete"]:
        st["retry"].pop(key, None)
    else:
        st["retry"][key] = now() + LIST_RETRY
    if r["changed"]:
        lists.signal(home, key, now)
    return key


def solo_flip(st, value):
    """¿ha cambiado el interruptor «Solo en castellano» desde la última mirada? (la primera solo apunta lo que hay)"""
    old, st["solo"] = st.get("solo"), bool(value)
    return old is not None and old != st["solo"]


def show_total(tmdb):
    """capítulos de la serie en las temporadas estrenadas (TMDB, con la caché de catalog); None si no se sabe"""
    try:
        from ker0n3 import catalog
        try:
            return sum(int(s.get("episodes") or 0) for s in catalog.show(tmdb).get("seasons") or []) or None
        finally:
            catalog.flush_default()
    except Exception as e:  # noqa: BLE001
        log("capítulos de %s: %s" % (tmdb, e))
        return None


def lost_notice(name, linked, home):
    """el texto del aviso si el servicio que sincronizaba (name) ha perdido el vínculo y aún no se avisó en esta
    sesión; None si no hay que avisar"""
    if not name or linked or home.getProperty(LOST + name):
        return None
    home.setProperty(LOST + name, "1")
    return "%s se ha desvinculado" % {"trakt": "Trakt", "simkl": "Simkl"}.get(name, name)


def note_hidden(what, pos, total, db_path=None):
    """antes de apuntar un capítulo que queda visto: ¿su serie se había dejado de seguir? (what["was_hidden"]). Al
    apuntarlo la base la vuelve a seguir (store.record) y queue_after pide lo mismo al servicio (16-nov)"""
    from ker0n3 import store
    if what.get("kind") == "tv" and total and pos * 100.0 / total >= store.WATCHED_PCT:
        try:
            what["was_hidden"] = store.is_hidden(what["tmdb"], db_path)
        except Exception as e:  # noqa: BLE001  (base ocupada o rota: lo visto se apunta igual)
            log("¿serie %s oculta?: %s" % (what.get("tmdb"), type(e).__name__))


def queue_after(what, result, pos, total, now, enqueue):
    """lo que sube al servicio al parar un vídeo: visto (con su hora) y quitar la pausa que el servicio guarde de él
    (sync/history no toca sync/playback; 16-nov), o la pausa con su %. Un capítulo visto de una serie que no se
    seguía (note_hidden) la vuelve a seguir también en el servicio (sync.UNHIDE; 16-nov)"""
    from ker0n3 import store
    if result == "watched":
        at = store.stamp(now)
        enqueue("watched", what, at=at)
        enqueue("unpause", what, at=at)
        if what.get("kind") == "tv" and what.get("was_hidden"):
            enqueue("unhide", {"kind": "tv", "tmdb": what["tmdb"], "season": None, "episode": None}, at=at)
    else:
        enqueue("pause", what, progress=pos * 100.0 / total)


def push_wait(result, api):
    """s que espera la cola tras un envío que no pudo ser: el cupo, lo que diga el servicio (Trakt: Retry-After;
    Simkl: cupo diario, una hora); sin red o sin vínculo, 5 min"""
    if result != "sin_cupo":
        return 300
    wait = getattr(api, "quota_wait", None)
    return wait() if wait else 3600


def trakt_menu(run, active=None, refresh=None):
    """sección Trakt de la skin (bloques 4 y 5): sus listas al día (trakt_lists.refresh: cada 6 h con Trakt en uso; sin
    él, «no» al momento y sin red) y, si cambia que Trakt esté en uso, el menú se vuelve a montar (la sección sale o se
    va). Nunca lanza"""
    try:
        from ker0n3 import trakt_lists
        before = trakt_lists.load().get("on")
        got = (refresh or trakt_lists.refresh)(active=active)
        if got is not None and bool(got.get("on")) != bool(before):
            run("RunScript(special://skin/scripts/flix_sections.py,apply)")
        return got
    except Exception as e:  # noqa: BLE001
        log("sección Trakt: %s" % type(e).__name__)
        return None


def run():
    import xbmc
    import xbmcgui
    from ker0n3 import avail, link, lists, store, sync, syncsvc, trakt
    home, mon, bg = xbmcgui.Window(10000), xbmc.Monitor(), Background()
    try:
        log("base de vistos: %s" % store.ensure())
    except Exception as e:  # noqa: BLE001
        log("base de vistos sin preparar: %s" % e)
    try:    # Ajustes → Cuentas dice lo que hay de AllDebrid (clave puesta a mano o borrada por fuera), sin red
        import flix_alldebrid
        from ker0n3 import adlink
        adlink.refresh(flix_alldebrid, xbmc.getInfoLabel("Skin.String(%s)" % adlink.USER), xbmc.executebuiltin)
    except Exception as e:  # noqa: BLE001
        log("estado de AllDebrid sin mirar: %s" % type(e).__name__)

    def record(what, pos, total, now):
        total_eps = show_total(what["tmdb"]) if what["kind"] == "tv" and total and pos * 100.0 / total >= \
            store.WATCHED_PCT else None
        note_hidden(what, pos, total)
        return store.record(what["kind"], what["tmdb"], what.get("season"), what.get("episode"), pos, total,
                            now=now, show_total=total_eps)

    try:    # acceso de Trakt guardado con otra aplicación (cambió el Client ID): se olvida y se dice
        if trakt.stale():
            trakt.forget()
            xbmc.executebuiltin("Skin.Reset(%s)" % link.TRAKT_USER)
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "Trakt: hay que vincular otra vez (Ajustes → Cuentas)",
                                          xbmcgui.NOTIFICATION_WARNING, 8000)
            log("acceso de Trakt de otra aplicación: olvidado")
    except Exception as e:  # noqa: BLE001
        log("acceso de Trakt sin mirar: %s" % type(e).__name__)
    using = {"name": "", "active": "", "next": 0.0}            # el último servicio que se vio en uso (para avisar si pierde el vínculo)

    def after(what, result, pos, total, now):
        if syncsvc.linked():        # al parar un vídeo: en disco, no lo último que vio el bucle
            queue_after(what, result, pos, total, now, sync.enqueue)
        poke(home, xbmc.executebuiltin)

    def lost():
        name = using["name"]
        text = lost_notice(name, bool(name) and syncsvc.module(name).linked(), home)
        if text:
            xbmc.executebuiltin("Skin.Reset(%s)" % link.SERVICES[name]["user"])
            xbmcgui.Dialog().notification("KER0N3 MEDIA", text, xbmcgui.NOTIFICATION_WARNING, 5000)

    def do_down():
        n = sync.down()
        if n > 0:
            poke(home, xbmc.executebuiltin)
        elif n < 0:
            lost()
        if trakt_menu(xbmc.executebuiltin) is not None:     # listas de Trakt para su sección, cada 6 h
            poke(home, xbmc.executebuiltin)

    wait = {"until": 0.0}

    def do_push():
        r = sync.push_one()
        if r in ("sin_red", "sin_cupo", "sin_vinculo"):
            wait["until"] = time.time() + push_wait(r, syncsvc.module(using["name"]) if using["name"] else None)
            if r == "sin_vinculo":
                lost()

    tracker = Tracker(record, after)

    class Player(xbmc.Player):
        def onAVStarted(self):
            raw = home.getProperty(K3_PLAYING)
            try:
                playing = self.getPlayingFile()
            except RuntimeError:
                playing = ""
            what = claim(raw, playing, time.time())
            if what:
                home.clearProperty(K3_PLAYING)
                tracker.start(what)
            elif tracker.what:
                tracker.stop()      # suena otra cosa: lo nuestro ya acabó

        def onPlayBackStopped(self):
            tracker.stop()

        def onPlayBackEnded(self):
            tracker.stop(ended=True)

        def onPlayBackError(self):
            tracker.stop()

    player, clock = Player(), Clock(time.time())
    lbg, lst = Background(), {"next": time.time() + LIST_START, "retry": {}}

    def busy_now():
        return bool(player.isPlayingVideo()) or mon.abortRequested()

    def do_lists():
        list_job(home, lst, busy_now)
    log("en marcha")
    while not mon.abortRequested():
        video = bool(player.isPlayingVideo())
        if tracker.what and video:
            try:
                tracker.tick(player.getTime(), player.getTotalTime())
            except RuntimeError:
                pass
        now = time.time()
        # qué servicio sincroniza: se mira en disco cada ACTIVE_EVERY s, o ya si acaban de vincular (SYNC_NOW)
        if now >= using["next"] or home.getProperty(SYNC_NOW):
            was = using["active"]
            using["active"], using["next"] = syncsvc.active(), now + ACTIVE_EVERY
            if using["active"] != "trakt" and (was == "trakt" or not using.get("menu")):
                using["menu"] = True        # sin Trakt en uso (al arrancar o al dejarlo): su sección fuera, sin red
                trakt_menu(xbmc.executebuiltin, active=using["active"])
        name = using["active"]
        if name:
            if name != using["name"]:
                using["name"] = name
                home.clearProperty(LOST + name)
            reason = clock.due(now, bool(tracker.what), xbmc.getGlobalIdleTime(),
                               home=xbmcgui.getCurrentWindowId() == 10000)
            if not reason and home.getProperty(SYNC_NOW) and not tracker.what:
                reason = "pedida"
            if reason and not video and not bg.busy():
                home.clearProperty(SYNC_NOW)
                clock.done(now)
                log("bajo de %s (%s)" % (name, reason))
                bg.go(do_down)
            elif not video and now >= wait["until"] and not bg.busy() and sync.pending():
                bg.go(do_push)
        # interruptor «Solo en castellano» cambiado: las filas se vuelven a pedir ya (filtran con lo guardado) y sus
        # listas pasan a la cola del repaso, por si ahora se quedan cortas
        if solo_flip(lst, avail.solo_esp()):
            try:
                log("solo en castellano: %s → %d listas avisadas" % (lst["solo"], len(lists.refilter(home))))
            except Exception as e:  # noqa: BLE001
                log("solo en castellano, sin avisar: %r" % e)
            lst["next"] = min(lst["next"], now + 2)
        # listas del Inicio (bloque 2): sin vídeo y de una en una; no depende de Trakt ni de Simkl
        if not video and now >= lst["next"] and not lbg.busy():
            lst["next"] = now + LIST_IDLE       # por si el trabajo muere antes de poner la suya
            lbg.go(do_lists)
        if mon.waitForAbort(TICK):
            break
    tracker.stop()                  # Kodi se cierra a media reproducción: lo visto hasta aquí
    log("parado")
