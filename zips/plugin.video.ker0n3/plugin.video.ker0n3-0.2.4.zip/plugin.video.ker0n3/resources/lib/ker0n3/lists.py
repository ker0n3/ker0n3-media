"""Listas del Inicio de Ker0n3 (bloque 2; 16-nov). Diseño:
docs/superpowers/specs/2026-11-16-inicio-sin-palantir-design.md.

Ruta lista/<clave> (claves de flix_tmdblists, módulo compartido con la skin): la fila de esa lista con títulos de
Ker0n3. La ruta NO comprueba enlaces: la lista sale de su caché (6 h; si caducó, TMDB o Simkl), se quita lo que ya se
sabe que no tiene versión en castellano (avail.cached) y cada título se pinta con su ficha guardada (catalog) o, si
aún no la hay, con lo que traía la lista. La comprobación va por detrás, en el servicio (warm, más abajo), que avisa a
la skin cuando lo que enseña una lista cambia.

Caché propia (listas.json, aparte de tmdb.json para no engordar lo que lee cada ruta del addon):
  L/<clave>  la lista: [{tmdb, kind, title, year, premiered, plot, poster, fanart, rating}] (Simkl: solo tmdb y kind)
  U/<clave>  cuándo se pidió por última vez (el servicio solo repasa las que se usan)
  W2/<clave> último repaso completo: {"t", "n" comprobados, "ok" con alguna versión, "esp" con castellano}. El número
             es la versión de las reglas (avail.RULES): un repaso hecho con las reglas de antes («W/») no cuenta, la
             lista vuelve a enseñar lo que aún no se ha comprobado y el servicio la repasa cuanto antes

16-nov (Carlos): la fila enseña lo que tenga alguna versión que se pueda usar, en castellano o en original / inglés
(avail); solo se quita lo que no tiene ninguna."""
import re
import time

LIST_TTL = 6 * 3600         # la lista de TMDB / Simkl (lo mismo que su fila en la skin)
USED_KEEP = 7 * 86400       # una lista sin pedir en una semana ya no se repasa
USED_EVERY = 3600           # como mucho un apunte de uso por hora y lista
WARM_KEEP = 3 * 86400       # repasada hace menos de esto: lo que no esté comprobado no sale
MAX_ENTRIES = 60            # títulos de la lista que se guardan (3 páginas de TMDB)
ROW_MAX = 30                # títulos que da la ruta (el Inicio enseña de 8 a 30); el resto, tras «Más…» (resto/<n>)
MORE = "Más…"               # flix_rows.is_more lo reconoce: tarjeta «Ver más»
WARMED = "W2/"              # + clave; el 2 = avail.RULES (test_k3_falsos lo ata)
WANT = "k3_lists_want"      # Window(10000): claves que una ruta pide repasar, separadas por comas
REV = "k3_list_rev_"        # Window(10000) + clave: cambia cuando lo que enseña esa lista es otro


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.lists] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


_DEFAULT = []


def default_cache():
    if not _DEFAULT:
        import xbmcvfs
        from ker0n3 import catalog
        _DEFAULT.append(catalog.Cache(xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.ker0n3/listas.json")))
    return _DEFAULT[0]


def flush_default():
    """guarda la caché de listas de la ruta (si se llegó a crear); nunca lanza"""
    if _DEFAULT:
        try:
            _DEFAULT[0].flush()
        except Exception:  # noqa: BLE001
            pass


def _tcache(tcache):
    from ker0n3 import catalog
    return tcache or catalog.default_cache()


SIM_RE = re.compile(r"^sim-(movie|tv)-(\d+)$")     # lista de parecidos de un título («Ver similares», bloque 3)


def sim_key(kind, tmdb):
    return "sim-%s-%d" % (kind, int(tmdb))


# lista personal de Trakt o su watchlist (bloques 4 y 5; trakt_lists.items): solo lectura
TRAKT_RE = re.compile(r"^trakt-(\d+|watchlist-(pelis|series))$")


def known(key):
    """¿lista que la ruta sabe hacer? Las de flix_tmdblists (también saga, año, década: spec), similares y Trakt"""
    import flix_tmdblists
    key = key or ""
    return flix_tmdblists.spec(key) is not None or bool(SIM_RE.match(key)) or bool(TRAKT_RE.match(key))


def kind_of(key):
    """'movie' / 'tv' de la lista; 'mixed' en las de Trakt (cada título lleva el suyo)"""
    import flix_tmdblists
    m = SIM_RE.match(key)
    if m:
        return m.group(1)
    m = TRAKT_RE.match(key)
    if m:
        return {"pelis": "movie", "series": "tv"}.get(m.group(2), "mixed")
    return flix_tmdblists.spec(key)[1]


def _fetcher(key):
    """de dónde sale la lista: TMDB / Simkl (flix_tmdblists) o, las de Trakt, la cuenta (trakt_lists)"""
    if TRAKT_RE.match(key or ""):
        from ker0n3 import trakt_lists
        return trakt_lists.items
    import flix_tmdblists
    return flix_tmdblists.fetch_entries


def entries(key, cache=None, fetch=None, now=time.time):
    """la lista, en su orden: de la caché si está fresca; si no, de TMDB / Simkl (flix_tmdblists.fetch_entries); si
    eso falla o viene vacío, lo último guardado; [] si nunca hubo"""
    cache = cache or default_cache()
    hit = cache.get("L/" + key, LIST_TTL, now=now)
    if hit is not None:
        return hit
    try:
        got = (fetch or _fetcher(key))(key)[:MAX_ENTRIES]
    except Exception as e:  # noqa: BLE001  (sin red: lo que hubiera)
        log("%s: no llega la lista (%s)" % (key, type(e).__name__))
        got = None
    if got:
        cache.put("L/" + key, got, now=now)
        return got
    return cache.get("L/" + key, LIST_TTL, now=now, stale=True) or []


def sheet(e, tcache=None, now=time.time):
    """con qué pintar el título sin tocar la red: su ficha guardada de catalog aunque esté caducada (logo, duración,
    edad y géneros no cambian) y, si no la hay, lo que traía la lista; None si no hay ni título (id pelado de Simkl)"""
    from ker0n3 import catalog
    d = _tcache(tcache).get(("m%s" if e["kind"] == "movie" else "tv%s") % e["tmdb"], 0, now=now, stale=True)
    if d:
        return d
    if not e.get("title"):
        return None
    return dict(e, poster=catalog._img(e.get("poster"), "w500"), fanart=catalog._img(e.get("fanart"), "w1280"))


def visible(key, cache=None, tcache=None, now=time.time, solo=None):
    """[(entrada, disponibilidad guardada o None)] de lo que se enseña, en el orden de la lista. Fuera lo que se sabe
    que no tiene ninguna versión que se pueda usar (o, con «Solo en castellano», que no la tiene en castellano). Lo que aún no se sabe sale solo mientras la lista no esté repasada (primer
    arranque: como el buscador cuando se le acaba el plazo); repasada, espera a su comprobación"""
    from ker0n3 import avail
    cache, tcache = cache or default_cache(), _tcache(tcache)
    warmed = cache.get(WARMED + key, WARM_KEEP, now=now) is not None
    solo = avail.solo_esp() if solo is None else solo       # interruptor «Solo en castellano»: con lo guardado
    out = []
    for e in entries(key, cache, now=now):
        a = avail.cached(e["kind"], e["tmdb"], cache=tcache, now=now)
        if a is None and warmed:
            continue
        if a is not None and not avail.shows(a, solo):
            continue
        out.append((e, a))
    return out


def used(key, cache=None, now=time.time):
    """apunta que la lista se usa (el servicio repasa solo las pedidas en la última semana)"""
    cache = cache or default_cache()
    if cache.get("U/" + key, USED_EVERY, now=now) is None:
        cache.put("U/" + key, {"t": now()}, now=now)


def want(key, home=None):
    """pide al servicio que repase esta lista cuanto antes (hay títulos sin comprobar a la vista)"""
    try:
        if home is None:
            import xbmcgui
            home = xbmcgui.Window(10000)
        cur = [k for k in home.getProperty(WANT).split(",") if k]
        if key not in cur:
            home.setProperty(WANT, ",".join(cur + [key]))
    except Exception:  # noqa: BLE001
        pass


def after(vis, shown, tcache=None, now=time.time):
    """lo que queda de `vis` tras los `shown` primeros títulos que la fila enseña: los que tienen con qué pintarse
    (sheet). Uno sin ficha (id pelado cuya ficha no llegó) no salió en la fila: no cuenta y se queda en el resto"""
    out, n = [], 0
    for e, a in vis:
        if n < shown and sheet(e, tcache, now) is not None:
            n += 1
        else:
            out.append((e, a))
    return out


def directory(handle, key, whole=False, cache=None, tcache=None, now=time.time, sheets=None, home=None, rest=None):
    """ruta lista/<clave>: la fila (30 títulos como mucho). whole: lista/<clave>/todo, la lista entera. rest = n:
    lista/<clave>/resto/<n>, solo lo que viene tras los n títulos que ya enseña la fila («Ver más», Carlos 16-nov),
    también de 30 en 30; su «Más…» lleva a la página siguiente del resto"""
    import xbmcgui
    import xbmcplugin
    from ker0n3 import avail, handlers, personal, router
    if not known(key):
        handlers.log("lista desconocida: %s" % key)
        handlers._end(handle, "", ok=False)
        return
    cache, tcache = cache or default_cache(), _tcache(tcache)
    kind = kind_of(key)
    vis = visible(key, cache, tcache, now)
    used(key, cache, now)
    pool = vis if rest is None else after(vis, rest, tcache, now)
    top = pool if whole else pool[:ROW_MAX]
    # las de Simkl y las recomendadas solo traen el id: las fichas que falten, en paralelo y con plazo (personal.sheets);
    # la que no llegue a tiempo no sale esta vez
    missing = [(e["kind"], e["tmdb"], None) for e, _a in top if sheet(e, tcache, now) is None]
    got = (sheets or personal.sheets)(missing) if missing else {}
    n = 0
    for e, a in top:
        d = sheet(e, tcache, now) or got.get((e["kind"], e["tmdb"], None))
        if not d:
            continue
        q, esp = (a or {}).get("q", ""), avail.has_esp(a)
        if e["kind"] == "movie":            # el del título: una lista de Trakt mezcla películas y series
            xbmcplugin.addDirectoryItem(handle, router.url_play_movie(e["tmdb"]), handlers.movie_item(d, q, esp),
                                        isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, router.url_show(e["tmdb"]), handlers.show_item(d, q, esp),
                                        isFolder=True)
        n += 1
    if not whole and len(pool) > ROW_MAX and n:
        more = router.url_list_rest(key, (rest or 0) + n)      # el resto: sin repetir lo que ya se ve
        xbmcplugin.addDirectoryItem(handle, more, xbmcgui.ListItem(MORE, path=more), isFolder=True)
    if any(a is None for _e, a in vis):
        want(key, home)
    handlers.log("lista %s%s: %d de %d" % (key, "" if rest is None else " (tras %d)" % rest, n, len(vis)))
    handlers._end(handle, {"movie": "movies", "tv": "tvshows"}.get(kind, "videos"))


# ---------- repaso por detrás (servicio del addon) ----------
WARM_TTL = 5 * 3600         # cada cuánto se repasa una lista en uso (antes de que su fila caduque a las 6 h)
ENOUGH = 20                 # títulos que se enseñan que bastan por lista: el resto no se comprueba
CHUNK = 6                   # títulos por tanda (fichas a la vez; disponibilidad, de 3 en 3: avail.many)
CHUNK_BUDGET = 25           # s como mucho por tanda


def _state(key, cache, tcache, now):
    """lo que la fila enseña ahora: [(tmdb, ¿con ficha?, calidad, ¿castellano?)]; si cambia, la skin tiene que volver a pedirla"""
    out = []
    for e, a in visible(key, cache, tcache, now)[:ROW_MAX]:
        has = tcache.get(("m%s" if e["kind"] == "movie" else "tv%s") % e["tmdb"], 0, now=now, stale=True) is not None
        out.append((e["tmdb"], has, (a or {}).get("q", ""), (a or {}).get("esp", True)))
    return out


def check_chunk(chunk, sheets, many, check, stop):
    """{(tipo, tmdb): disponibilidad} de una tanda de entradas (lo que no dé tiempo, o una serie sin ficha, falta =
    desconocido): sus fichas a la vez (sheets) y la disponibilidad de 3 en 3 (many), un tipo por llamada (las claves
    de avail.many son solo el tmdb y una lista de Trakt mezcla películas y series). La usan warm y cards.check"""
    got = sheets([(e["kind"], e["tmdb"], None) for e in chunk])
    items = []
    for e in chunk:
        d = got.get((e["kind"], e["tmdb"], None))
        if e["kind"] == "movie":
            items.append(("movie", e["tmdb"], None))
        elif d is not None:             # serie sin ficha: no se sabe qué capítulo mirar (desconocida)
            items.append(("tv", e["tmdb"], d.get("last_aired")))
    res = {}
    for k in ("movie", "tv"):
        part = [x for x in items if x[0] == k]
        if part:
            res.update({(k, t): a for t, a in many(part, timeout=CHUNK_BUDGET, check=check, cancel=stop).items()})
    return res


def warm(key, cache=None, tcache=None, should_stop=None, now=time.time, sheets=None, many=None, solo=None):
    """repasa la lista en su orden, de CHUNK en CHUNK, hasta tener ENOUGH títulos con alguna versión que se pueda
    usar (castellano u original: avail, 16-nov) o acabarla: guarda la ficha de cada uno (catalog: logo, duración, edad; en las series, el último capítulo emitido) y
    su disponibilidad (avail.check: misma caché y mismas reglas que el buscador; lo ya sabido no toca la red).
    should_stop(): True = dejarlo (empieza un vídeo, Kodi se cierra). Si acaba y casi todo se pudo comprobar, la
    lista queda repasada (W/<clave>): desde entonces solo enseña lo comprobado.
    Devuelve {"checked", "ok", "esp", "unknown", "complete", "changed"} (ok: con alguna versión; esp: de ellos, con
    castellano; changed: lo que enseña la fila es otro)"""
    from ker0n3 import avail, personal
    cache, tcache = cache or default_cache(), _tcache(tcache)
    sheets, many = sheets or personal.sheets, many or avail.many
    stop = should_stop or (lambda: False)
    before = _state(key, cache, tcache, now)
    todo = entries(key, cache, now=now)
    ok = esp = unknown = checked = 0
    cut = False
    solo = avail.solo_esp() if solo is None else solo

    def check(kind, tmdb, last=None):
        return avail.check(kind, tmdb, last, cache=tcache, now=now)
    for i in range(0, len(todo), CHUNK):
        if (esp if solo else ok) >= ENOUGH:     # bastan ENOUGH de los que se enseñan
            break
        if stop():
            cut = True
            break
        chunk = todo[i:i + CHUNK]
        res = check_chunk(chunk, sheets, many, check, stop)
        for e in chunk:
            a = res.get((e["kind"], e["tmdb"]))
            checked += 1
            if a is None:
                unknown += 1
            elif a.get("ok"):
                ok += 1
                esp += bool(a.get("esp", True))
    # repasada si no se cortó y como mucho 1 de cada 10 quedó sin saber (un título roto no la deja a medias siempre)
    complete = bool(todo) and not cut and unknown * 10 <= checked
    if complete:
        cache.put(WARMED + key, {"t": now(), "n": checked, "ok": ok, "esp": esp}, now=now)
    return {"checked": checked, "ok": ok, "esp": esp, "unknown": unknown, "complete": complete,
            "changed": _state(key, cache, tcache, now) != before}


def take_wanted(home):
    """la primera lista que una ruta pidió repasar (y la quita de la cola); None si no hay"""
    cur = [k for k in home.getProperty(WANT).split(",") if k]
    while cur:
        key = cur.pop(0)
        home.setProperty(WANT, ",".join(cur))
        if known(key):
            return key
    return None


def used_keys(cache=None, now=time.time):
    """listas pedidas en la última semana: las de flix_tmdblists.BY_KEY y las de parámetro (sagas, años, Trakt) que
    haya apuntado la ruta (U/<clave>). Las de similares no: se repasan solo cuando se piden (want)"""
    import flix_tmdblists
    cache = cache or default_cache()
    keys = list(flix_tmdblists.BY_KEY)
    keys += [k[2:] for k in cache.keys("U/") if k[2:] not in flix_tmdblists.BY_KEY and not SIM_RE.match(k[2:])
             and known(k[2:])]
    return [k for k in keys if cache.get("U/" + k, USED_KEEP, now=now) is not None]


def due(cache=None, now=time.time, retry=None):
    """la lista en uso (pedida en la última semana) que más lleva sin repasar, si lleva más de WARM_TTL; None si
    todas están al día. retry: {clave: hora hasta la que no se reintenta} (repaso que quedó a medias)"""
    cache = cache or default_cache()
    best, best_t = None, None
    for key in used_keys(cache, now):
        if (retry or {}).get(key, 0) > now():
            continue
        if cache.get(WARMED + key, WARM_TTL, now=now) is not None:
            continue
        t = (cache.get(WARMED + key, 0, now=now, stale=True) or {}).get("t", 0)
        if best is None or t < best_t:
            best, best_t = key, t
    return best


def refilter(home, cache=None, now=time.time):
    """el interruptor «Solo en castellano» ha cambiado: cada lista en uso se vuelve a pedir ya (la ruta filtra con
    lo guardado, sin red) y se pone en cola para repasarla, por si ahora le faltan títulos para llegar a ENOUGH.
    Devuelve las claves avisadas"""
    cache = cache or default_cache()
    keys = used_keys(cache, now)
    for k in keys:
        signal(home, k, now)
        want(k, home)
    from ker0n3 import cards                # y las filas de tarjetas en uso (bloques 4 y 5): otra regla, otras tarjetas
    return keys + cards.refilter(home, cache, now)


def rev_path():
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/listas_rev.json")


def signal(home, key, now=time.time, path=None):
    """avisa a la skin: lo que enseña esta lista ha cambiado (el Inicio vuelve a pedir su fila). En la propiedad de
    Window(10000) (el Inicio abierto la ve al momento) y en disco (listas_rev.json, {clave: hora}): la propiedad se
    pierde al reiniciar Kodi y no la ve un Inicio que aún no está abierto, y la skin guarda cada fila 6 h (16-nov,
    S24: «En cines ahora» seguía con lo descartado tras el repaso). flix_rows.k3_changed_at lee las dos.
    Nunca lanza"""
    t = now()
    try:
        home.setProperty(REV + key, str(int(t * 10)))
    except Exception:  # noqa: BLE001
        pass
    try:
        import json
        import os
        path = path or rev_path()
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
        if not isinstance(data, dict):
            data = {}
        data[key] = t
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        tmp = "%s.%d.tmp" % (path, os.getpid())
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except Exception as e:  # noqa: BLE001
        log("aviso de %s sin guardar: %s" % (key, type(e).__name__))


def no_version(kind, tmdb, home=None, cache=None, tcache=None, now=time.time, path=None):
    """al ir a reproducir, ninguna versión pasó las reglas (flix_src_check): el título queda apuntado YA como «sin
    versión» (un día, como cualquier «no») y se avisa a las listas en uso que lo llevan, para que el usuario no se
    lo vuelva a encontrar. Devuelve las claves avisadas. Solo lee y escribe cachés: sin red"""
    from ker0n3 import avail
    cache, tcache = cache or default_cache(), _tcache(tcache)
    avail.mark_none(kind, tmdb, cache=tcache, now=now)
    tcache.flush()
    if home is None:
        import xbmcgui
        home = xbmcgui.Window(10000)
    keys = []
    for k in used_keys(cache, now):
        ents = cache.get("L/" + k, LIST_TTL, now=now, stale=True) or []
        if any(e.get("tmdb") == int(tmdb) and e.get("kind") == kind for e in ents):
            signal(home, k, now, path)
            keys.append(k)
    log("sin versión al reproducir: %s %s → %d listas avisadas" % (kind, tmdb, len(keys)))
    return keys


# ---------- «Ver similares» (bloque 3; 16-nov) ----------
def similar_entries(kind, tmdb, cache=None, opener=None, now=time.time):
    """los parecidos de TMDB a ese título (recomendaciones y parecidas; en una película de saga, la saga primero), en
    el orden por parecido de siempre (flix_tmdblists.rank_similar), como entradas de lista. Una petición a TMDB (dos
    con saga), guardada como cualquier lista (L/sim-…, 6 h); sin red, lo último que hubiera o []"""
    import urllib.request
    import flix_tmdblists as tl
    cache = cache or default_cache()
    key = sim_key(kind, tmdb)
    hit = cache.get("L/" + key, LIST_TTL, now=now)
    if hit is not None:
        return hit
    try:
        opener = opener or urllib.request.urlopen
        src = tl._get("%s/%d" % (kind, int(tmdb)), opener, {"append_to_response": "recommendations,similar"})
        pools = [("rec", (src.get("recommendations") or {}).get("results") or []),
                 ("sim", (src.get("similar") or {}).get("results") or [])]
        saga = []
        col = src.get("belongs_to_collection")
        if kind == "movie" and isinstance(col, dict) and col.get("id"):
            try:
                saga = tl._get("collection/%d" % int(col["id"]), opener).get("parts") or []
            except Exception as e:  # noqa: BLE001  (sin la saga, lo demás sirve)
                log("saga %s: %s" % (col.get("id"), type(e).__name__))
        by = {}
        for x in saga + [x for _l, res in pools for x in res]:
            if x.get("id"):
                by.setdefault(x["id"], x)
        got = [tl._entry(by[i], kind) for i in tl.rank_similar(kind, src, pools, saga) if i in by][:MAX_ENTRIES]
    except Exception as e:  # noqa: BLE001
        log("%s: no llegan los parecidos (%s)" % (key, type(e).__name__))
        got = None
    if got:
        cache.put("L/" + key, got, now=now)
        return got
    return cache.get("L/" + key, LIST_TTL, now=now, stale=True) or []


def similar(handle, tipo, tmdb, cache=None, tcache=None, now=time.time, opener=None, home=None, seen=None):
    """ruta similares/<pelicula|serie>/<tmdb>: los parecidos con la regla de las filas (visible: fuera lo que se sabe
    que no tiene versión; lo sin comprobar sale y se pide su repaso al servicio), lo ya visto al final"""
    import xbmcplugin
    from ker0n3 import avail, handlers, router
    kind = "movie" if tipo == "pelicula" else "tv"
    cache, tcache = cache or default_cache(), _tcache(tcache)
    key = sim_key(kind, tmdb)
    similar_entries(kind, tmdb, cache, opener, now)
    vis = visible(key, cache, tcache, now)
    if seen is None:
        try:
            import flix_tmdblists
            from ker0n3 import store
            seen = flix_tmdblists.seen_ids(kind, [e["tmdb"] for e, _a in vis], store.path())
        except Exception:  # noqa: BLE001
            seen = set()
    vis = [x for x in vis if x[0]["tmdb"] not in seen] + [x for x in vis if x[0]["tmdb"] in seen]
    n = 0
    for e, a in vis[:ROW_MAX]:
        d = sheet(e, tcache, now)
        if not d:
            continue
        q, esp = (a or {}).get("q", ""), avail.has_esp(a)
        if kind == "movie":
            xbmcplugin.addDirectoryItem(handle, router.url_play_movie(e["tmdb"]), handlers.movie_item(d, q, esp),
                                        isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, router.url_show(e["tmdb"]), handlers.show_item(d, q, esp),
                                        isFolder=True)
        n += 1
    if any(a is None for _e, a in vis):
        want(key, home)
    handlers.log("similares %s %s: %d" % (tipo, tmdb, n))
    handlers._end(handle, "movies" if kind == "movie" else "tvshows")
