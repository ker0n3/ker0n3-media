"""Temporadas como en IMDb / Stremio en las series con una temporada enorme en TMDB (18-nov, Carlos: opción «B»).

TMDB pone algunas series en una temporada gigante: Bleach T1 = 366 capítulos (+ T2 = 50 de «Thousand-Year Blood War»),
Doraemon (2005) T1 = 1.464, Crayon Shin-chan T1 = 2.484. En la ficha de serie eso es una lista imposible de recorrer.
IMDb (lo que enseña Stremio) las reparte en temporadas de verdad: Bleach son 16, y las 4 partes de la guerra
sangrienta están en otra ficha (tt14986406).

Aquí solo cambia CÓMO SE AGRUPA EN PANTALLA: cada capítulo de TMDB se coloca en su temporada de IMDb por su fecha de
emisión (flix_src_epmap.match_date) y la ficha enseña esas «partes». Por dentro todo sigue con la numeración de TMDB:
rutas play/capitulo/<tmdb>/<T>/<C>, base de vistos, Trakt, siguiente capítulo y marcas; títulos, sinopsis e imágenes,
de TMDB en castellano.

layout(tmdb) → None (la serie se enseña como siempre) o [{"v", "k", "name", "eps": [[T, C], …], "year", "air_date",
"s" (temporada de TMDB del primero), "o" (imdb de la otra ficha, o "" si es la de la serie)}, …]:
  · solo si alguna temporada de TMDB (sin especiales) tiene más de BIG capítulos y la serie tiene ficha de IMDb: el
    resto de series no hace ni una petición más (la comprobación es con la ficha de la serie, ya guardada);
  · cada capítulo EMITIDO va a la temporada de IMDb de su fecha: primero la ficha de la serie; una temporada de TMDB
    que casi no está en ella (menos de la mitad) se busca en otras fichas (flix_src_epmap.others, la misma búsqueda
    que usa la petición de versiones), y una otra ficha cuenta solo si se emparejan al menos MIN_OTHER capítulos;
  · un capítulo sin pareja va con el anterior (o con el siguiente, si es el primero);
  · si se emparejan menos de MIN_SHARE de los capítulos: None. Sin red y sin nada guardado: None, sin romper nada;
  · las partes van en el orden de IMDb (la ficha de la serie y luego las otras; cada una por temporada) y dentro, por
    su capítulo de IMDb, como en Stremio;
  · v = PART_BASE + k (k = 1…N, en ese orden): nunca choca con una temporada de TMDB en la skin. Nombre: la
    ficha de la serie, «Temporada k»; otra ficha, «Parte j · <nombre de la temporada de TMDB>» (j = su temporada en
    esa ficha).
Se guarda un día en la caché del catálogo (tmdb.json, clave «pt<tmdb>»), también el «no hace falta» (None)."""
import json
import os
import time

BIG = 100             # capítulos de una temporada de TMDB a partir de los que se mira IMDb (más de esto)
MIN_SHARE = 0.9       # parte de los capítulos emitidos que tienen que emparejarse por fecha
HALF = 0.5            # una temporada de TMDB con menos de esto en la ficha de la serie se busca en otras fichas
MIN_OTHER = 3         # capítulos que tiene que tener otra ficha para contar (si la temporada tiene menos, todos)
RUN = 4               # sin emparejar quedan solo tandas de menos de esto: ya no se buscan más fichas (sueltos)
MAX_PARTS = 40        # huecos de la columna de temporadas de la ficha (flix_series.MAX_SEASONS)
PART_BASE = 1000      # número de temporada de las partes en la skin: PART_BASE + k
KEY = "pt2_%s"       # caché del catálogo (pt2: «Parte j · …» delante, 18-nov)
PROP = "k3_partes_"   # Window(10000) + tmdb: el reparto, para la skin (flix_series.k3_parts)


def big(show):
    """¿alguna temporada de TMDB (sin especiales) con más de BIG capítulos? Solo con la ficha ya pedida"""
    for s in (show or {}).get("seasons") or []:
        try:
            if int(s.get("n") or 0) > 0 and int(s.get("episodes") or 0) > BIG:
                return True
        except (TypeError, ValueError):
            continue
    return False


# --- emparejar por fecha (puro, sin red) -------------------------------------------------------------------------
def _index(vids):
    """{fecha: [[T, C, fecha], …]} en el orden de la ficha"""
    out = {}
    for v in vids or []:
        out.setdefault(v[2], []).append(v)
    return out


def _match(when, idx):
    """flix_src_epmap.match_date con el índice por fecha (sin recorrer la ficha entera en cada capítulo: Crayon
    Shin-chan son 2.484)"""
    import flix_src_epmap as em
    day = when[0]
    sub = idx.get(day)
    if not sub:
        try:
            sub = [v for n in range(1, em.DATE_SLACK + 1) for d in (em._shift(day, n), em._shift(day, -n))
                   for v in idx.get(d, [])]
        except ValueError:
            return None
    return em.match_date(when, sub) if sub else None


def _longest_run(ids):
    """la tanda más larga de capítulos seguidos (posiciones consecutivas) entre ids"""
    best = run = 0
    for n, i in enumerate(ids):
        run = run + 1 if n and i == ids[n - 1] + 1 else 1
        best = max(best, run)
    return best


def build(eps, main, others=None, names=None):
    """el reparto (ver arriba) o None. eps: [(T, C, 'AAAA-MM-DD')] emitidos de TMDB en orden; main: vídeos de la ficha
    de la serie ([[T, C, fecha]], flix_src_epmap.videos); others(T): [(imdb, vídeos)] de otras fichas para esa
    temporada de TMDB, iterable perezoso (solo se llama si hace falta); names: {T: nombre de la temporada en TMDB}"""
    eps = [(int(s), int(e), d) for s, e, d in eps or [] if d]
    if not eps:
        return None
    names = names or {}
    rank, ranks = {}, []
    for s, e, d in eps:                     # puesto entre los del mismo día de su temporada (episode_date)
        ranks.append(rank.get((s, d), 0))
        rank[(s, d)] = ranks[-1] + 1
    idx = _index(main)
    hits = []
    for (s, e, d), r in zip(eps, ranks):
        m = _match((d, r), idx)
        hits.append(("", m[0], m[1]) if m else None)
    # temporadas de TMDB que no están en la ficha de la serie: ¿otra ficha? (Bleach T2, «Thousand-Year Blood War»)
    per = {}
    for i, (s, _e, _d) in enumerate(eps):
        per.setdefault(s, []).append(i)
    for s, ids in per.items():
        if others is None or sum(1 for i in ids if hits[i]) >= HALF * len(ids):
            continue
        left = [i for i in ids if not hits[i]]
        found = {}
        for mid, vids in others(s) or []:
            oidx = _index(vids)
            for i in left:
                m = _match((eps[i][2], ranks[i]), oidx)
                if m:
                    found[i] = (mid, m[0], m[1])
            if len([i for i in found if found[i][0] == mid]) >= min(MIN_OTHER, len(ids)):
                left = [i for i in left if i not in found]
            else:                           # coincidencias sueltas en otra serie: no cuentan
                found = {i: v for i, v in found.items() if v[0] != mid}
            if _longest_run(left) < RUN:    # solo quedan sueltos (fechas que no cuadran): no se piden más fichas
                break
        for i, v in found.items():
            hits[i] = v
    matched = sum(1 for h in hits if h)
    if matched < MIN_SHARE * len(eps):
        return None
    # sin pareja: con el anterior (o con el siguiente si es el primero), en su mismo sitio de IMDb
    prev = next(h for h in hits if h)
    where = []
    for h in hits:
        prev = h or prev
        where.append(prev)
    # partes en el orden de IMDb (como Stremio): la ficha de la serie primero, las otras en el orden en que salen; y
    # dentro de cada una, por su capítulo de IMDb. Con fechas raras en TMDB (Doraemon: del 1x844 al 1x941 con fechas
    # de 2025-26) cada capítulo va a la temporada de IMDb de su fecha, no a la de sus vecinos de número
    sheets = [""]
    for h in where:
        if h[0] not in sheets:
            sheets.append(h[0])
    groups = {}
    for i, h in enumerate(where):
        groups.setdefault((sheets.index(h[0]), h[1]), []).append((h[2], i))
    out = []
    for k, key in enumerate(sorted(groups), 1):
        g = [eps[i] for _ie, i in sorted(groups[key])]
        s0 = g[0][0]
        if key[0]:
            # «Parte 1 · …» delante: la columna de temporadas corta el nombre largo (Shield 18-nov: «Thousand-Year
            # Blood W…» en las 4 y no se sabía cuál era cuál)
            name = "Parte %d · %s" % (key[1], names[s0]) if names.get(s0) else "Parte %d" % key[1]
        else:
            name = "Temporada %d" % k
        out.append({"v": PART_BASE + k, "k": k, "name": name, "eps": [[s, e] for s, e, _d in g],
                    "air_date": min(d for _s, _e, d in g), "s": s0, "o": sheets[key[0]]})
        out[-1]["year"] = int(out[-1]["air_date"][:4]) if out[-1]["air_date"][:4].isdigit() else 0
    if len(out) > MAX_PARTS:            # la columna de temporadas de la ficha no enseña más: mejor como siempre
        return None
    # lo mismo que las temporadas de TMDB (cada parte = una temporada entera, en orden): nada que cambiar
    if len(out) == len(per) and all(p["eps"] == [[s, e] for s, e, _d in eps if s == p["s"]] for p in out):
        return None
    return out


# --- con la red y la caché -----------------------------------------------------------------------------------------
def _aired(tmdb, n, today, cache, opener):
    from ker0n3 import catalog
    return [(n, e["n"], e.get("premiered") or "") for e in catalog.season_all(tmdb, n, opener=opener, cache=cache)
            if isinstance(e.get("n"), int) and e["n"] > 0 and e.get("premiered") and e["premiered"] <= today]


def compute(tmdb, show, cache=None, opener=None, today=None, path=None, now=time.time):
    """(reparto o None, ¿completo?). ¿completo? = False si algo no se pudo preguntar (no se guarda: se probará otra
    vez). Lanza si falta lo imprescindible (temporadas de TMDB, ficha de IMDb)"""
    import flix_src_epmap as em
    import flix_src_list
    today = today or time.strftime("%Y-%m-%d")
    imdb = flix_src_list.imdb_of("tv", int(tmdb), opener=opener, raise_errors=True)
    if not imdb:
        return None, True               # TMDB no le conoce ficha de IMDb
    seasons = sorted(int(s["n"]) for s in show.get("seasons") or [] if int(s.get("n") or 0) > 0)
    names = {int(s["n"]): s.get("name") or "" for s in show.get("seasons") or [] if int(s.get("n") or 0) > 0}
    eps = []
    for n in seasons:
        eps += _aired(tmdb, n, today, cache, opener)
    main = em.videos(imdb, opener=opener, path=path, now=now)
    state = {"ok": True}

    def others(s):
        try:
            ids = em.others(tmdb, imdb, s, opener=opener, path=path, now=now)
        except Exception:  # noqa: BLE001  (sin red: esa parte se queda sin emparejar)
            state["ok"] = False
            return
        for mid in ids:
            try:
                vids = em.videos(mid, opener=opener, path=path, now=now)
            except Exception:  # noqa: BLE001
                state["ok"] = False
                continue
            if vids:
                yield mid, vids
    return build(eps, main, others, names), state["ok"]


def layout(tmdb, show=None, cache=None, opener=None, today=None, path=None, now=time.time):
    """el reparto de la serie (ver arriba) o None. Nunca lanza"""
    try:
        from ker0n3 import catalog
        if show is None:
            show = catalog.show(tmdb, opener=opener, cache=cache)
        if not big(show):
            return None
        cache = cache or catalog.default_cache()
        key = KEY % int(tmdb)
        hit = cache.get(key, catalog.TTL_SEASON)
        if isinstance(hit, dict) and "p" in hit:
            remember(tmdb, hit["p"])
            return hit["p"] or None
        try:
            out, complete = compute(int(tmdb), show, cache=cache, opener=opener, today=today, path=path, now=now)
        except Exception:  # noqa: BLE001  (sin red: lo de ayer si lo hay; si no, como siempre)
            old = cache.get(key, catalog.TTL_SEASON, stale=True)
            return (old.get("p") or None) if isinstance(old, dict) else None
        if complete or out:
            cache.put(key, {"p": out})
            remember(tmdb, out)
        return out
    except Exception:  # noqa: BLE001
        return None


# --- lo que usan la carpeta de la serie y el estado ---------------------------------------------------------------
def latest(lay):
    """(v, T, C) del capítulo de TMDB más alto del reparto: los que salgan después en esa temporada van a su parte"""
    best = None
    for p in lay or []:
        for s, e in p["eps"]:
            if best is None or (s, e) > best[1:]:
                best = (p["v"], s, e)
    return best


def with_tail(lay, aired):
    """el reparto con los capítulos emitidos DESPUÉS de calcularlo (se calcula una vez al día) al final de la parte del
    último de TMDB (latest), si son de su misma temporada. aired: [números] emitidos de esa temporada"""
    top = latest(lay)
    if not top:
        return lay
    v, s, e = top
    more = sorted(n for n in aired or [] if isinstance(n, int) and n > e)
    if not more:
        return lay
    return [dict(p, eps=p["eps"] + [[s, n] for n in more]) if p["v"] == v else p for p in lay]


def part(lay, v):
    return next((p for p in lay or [] if p["v"] == int(v)), None)


def locate(lay, s, e):
    """(v, k, puesto en la parte) del capítulo [T, C] de TMDB, o None. Uno que aún no está (por emitir, o emitido tras
    calcular el reparto) y sigue al último de TMDB en su temporada (latest): al final de esa parte"""
    if not lay or s is None or e is None:
        return None
    s, e = int(s), int(e)
    for p in lay:
        for i, (ps, pe) in enumerate(p["eps"]):
            if ps == s and pe == e:
                return p["v"], p["k"], i + 1
    v, ls, le = latest(lay)
    if s == ls and e > le:
        p = part(lay, v)
        return v, p["k"], len(p["eps"]) + (e - le)
    return None


def annotate(st, lay):
    """añade al estado de la serie (series.state) la numeración de la ficha: next_v / upto_v / soon_v = [k, puesto] y
    part = v de la parte del siguiente (o del último visto si se va al día). Sin reparto, el estado no cambia"""
    if not lay or not isinstance(st, dict):
        return st
    st["parts"] = len(lay)
    for key in ("next", "upto", "soon"):
        se = st.get(key)
        loc = locate(lay, se[0], se[1]) if se else None
        if loc:
            st[key + "_v"] = [loc[1], loc[2]]
            if key != "soon" and "part" not in st:
                st["part"] = loc[0]
    return st


def runs(eps):
    """[[T, desde, hasta], …] de [[T, C], …] (seguidos en la misma temporada): el reparto en poco texto"""
    out = []
    for s, e in eps:
        if out and out[-1][0] == s and out[-1][2] == e - 1:
            out[-1][2] = e
        else:
            out.append([s, e, e])
    return out


def publish(tmdb, lay, home=None):
    """deja el reparto en Window(10000).k3_partes_<tmdb> (la skin agrupa ✓ y progreso por parte: flix_series.k3_parts);
    sin reparto lo quita. Nunca lanza"""
    try:
        if home is None:
            import xbmcgui
            home = xbmcgui.Window(10000)
        name = "%s%d" % (PROP, int(tmdb))
        if lay:
            home.setProperty(name, json.dumps(dict(compact(lay), tmdb=int(tmdb)), separators=(",", ":")))
        else:
            home.clearProperty(name)
    except Exception:  # noqa: BLE001
        pass


def compact(lay):
    """{"p": [[v, k, runs], …], "t": [v, T, C, nº]} del reparto: lo que se guarda y lo que lee la skin"""
    v, s, e = latest(lay)
    return {"p": [[p["v"], p["k"], runs(p["eps"])] for p in lay], "t": [v, s, e, len(part(lay, v)["eps"])]}


# --- numeración en pantalla fuera de la ficha (18-nov, 2.ª tarea) -----------------------------------------------
# Las filas del Inicio («Seguir viendo», «Series en seguimiento»), el menú de un capítulo, el aviso de «Siguiente
# capítulo», el rótulo del reproductor y el capítulo encadenado dicen «T20 E9» y no el «T2 E49» de TMDB en las series
# por partes. Todo sale de visible(), que SOLO lee partes.json (addon_data del addon): el reparto de cada serie que lo
# tiene, en poco texto, escrito al calcularlo o leerlo de la caché (layout → remember) y por el servicio para las
# series en seguimiento (warm). Nunca red ni espera: un os.stat por llamada y el fichero (unos pocos KB) solo se
# vuelve a leer si cambia. Serie sin reparto guardado: la numeración de TMDB, como siempre
FILE = "special://profile/addon_data/plugin.video.ker0n3/partes.json"
_STORE = {"path": None, "sig": None, "data": {}, "idx": {}}
WARM_RETRY = 6 * 3600       # s: una serie cuyo reparto no se pudo calcular (sin red) no se reintenta antes
_TRIED = {}
STAT_EVERY = 1.0            # s: partes.json se mira (os.stat) como mucho una vez por segundo y proceso


def store_path():
    if _STORE["path"] is None:
        import xbmcvfs
        _STORE["path"] = xbmcvfs.translatePath(FILE)
    return _STORE["path"]


def _sig(path):
    try:
        st = os.stat(path)
        return st.st_mtime_ns, st.st_size
    except OSError:
        return None


def stored(path=None):
    """{tmdb (str): {"p", "t"}} de partes.json ({} si no hay); solo se relee si cambió el fichero, y eso se mira como
    mucho una vez por segundo (una fila del Inicio pregunta por cada tarjeta, todas a la vez)"""
    path = path or store_path()
    t = time.monotonic()
    if _STORE["sig"] and _STORE["sig"][0] == path and t - _STORE.get("at", -99.0) < STAT_EVERY:
        return _STORE["data"]
    _STORE["at"] = t
    sig = _sig(path)
    if sig is None:
        _STORE.update(sig=(path, None), data={}, idx={})
        return {}
    if _STORE["sig"] == (path, sig):
        return _STORE["data"]
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        data = data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        data = {}
    _STORE.update(sig=(path, sig), data=data, idx={})
    return data


def remember(tmdb, lay, path=None):
    """apunta (o quita, sin reparto) el de la serie en partes.json si cambió. Nunca lanza"""
    try:
        path = path or store_path()
        _STORE["at"] = -99.0                # lo del disco, no lo de hace menos de un segundo
        data = dict(stored(path))
        key = str(int(tmdb))
        new = compact(lay) if lay else None
        if data.get(key) == new or (new is None and key not in data):
            return
        if new is None:
            data.pop(key, None)
        else:
            data[key] = new
        from flix_common import atomic_write
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        atomic_write(path, json.dumps(data, separators=(",", ":")))
        _STORE["at"] = -99.0                # la próxima lectura, ya con lo escrito
    except Exception:  # noqa: BLE001
        pass


def visible(tmdb, s, e, path=None):
    """(k, puesto) del capítulo [T, C] de TMDB en su parte, o None (serie sin reparto guardado, o capítulo sin sitio:
    se queda con la numeración de TMDB). Solo lo guardado (partes.json). Nunca lanza"""
    try:
        data = stored(path)
        if not data:
            return None
        key = str(int(tmdb))
        ent = data.get(key)
        if not ent:
            return None
        idx = _STORE["idx"].get(key)
        if idx is None:
            idx = {}
            ks = {}
            for v, k, rr in ent["p"]:
                ks[int(v)] = int(k)
                pos = 0
                for t, a, b in rr:
                    for c in range(int(a), int(b) + 1):
                        pos += 1
                        idx[(int(t), c)] = (int(k), pos)
            tv, ts, te, n = (int(x) for x in ent["t"])
            idx["_tail"] = (ks[tv], ts, te, n)
            _STORE["idx"][key] = idx
        s, e = int(s), int(e)
        hit = idx.get((s, e))
        if hit:
            return hit
        k, ts, te, n = idx["_tail"]
        return (k, n + e - te) if s == ts and e > te else None
    except Exception:  # noqa: BLE001
        return None


def label(tmdb, s, e, path=None):
    """«T20 E9» (o el «T2 E49» de TMDB si la serie no va por partes)"""
    vis = visible(tmdb, s, e, path)
    return "T%d E%d" % (vis or (int(s), int(e)))


def short(tmdb, s, e, path=None):
    """«20x09» (o «2x49»), como las etiquetas de los capítulos"""
    vis = visible(tmdb, s, e, path)
    return "%dx%02d" % (vis or (int(s), int(e)))


def warm(tcache=None, should_stop=None, db_path=None, path=None, now=time.time):
    """el servicio, por detrás y sin vídeo: el reparto de UNA serie en seguimiento con una temporada de más de BIG
    capítulos que aún no lo tenga en partes.json (así las filas del Inicio lo dicen bien sin haber abierto la ficha).
    Lo ya calculado en la caché pasa a partes.json sin red. Devuelve el tmdb calculado o None"""
    from ker0n3 import catalog, store
    tcache = tcache or catalog.default_cache()
    have = stored(path)
    for row in store.followed(db_path):
        if should_stop is not None and should_stop():
            return None
        tmdb = int(row[0])
        if str(tmdb) in have or now() - _TRIED.get(tmdb, 0) < WARM_RETRY:
            continue
        hit = tcache.get(KEY % tmdb, catalog.TTL_SEASON, stale=True)
        if isinstance(hit, dict) and "p" in hit:
            if hit["p"]:
                remember(tmdb, hit["p"], path)
            else:
                _TRIED[tmdb] = now()
            continue
        sheet = tcache.get("tv%s" % tmdb, catalog.TTL_SEASON, stale=True)
        if not sheet or not big(sheet):
            continue
        _TRIED[tmdb] = now()
        layout(tmdb, cache=tcache)
        return tmdb
    return None
