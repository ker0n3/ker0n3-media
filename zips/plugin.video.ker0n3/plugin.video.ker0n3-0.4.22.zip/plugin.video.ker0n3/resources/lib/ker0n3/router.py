"""Rutas del addon Ker0n3 (parte 2b+2c; 15-nov). Diseño:
docs/superpowers/specs/2026-11-15-catalogo-fichas-buscador-design.md"""
import re
import sys
import threading
import urllib.parse

ROOT = "plugin://plugin.video.ker0n3"


def _q(text):
    return urllib.parse.quote(str(text), safe="")


def url_search(kind, text):
    return "%s/buscar/%s/%s" % (ROOT, kind, _q(text))


def url_show(tmdb):
    return "%s/serie/%s" % (ROOT, tmdb)


def url_season(tmdb, season):
    return "%s/serie/%s/%s" % (ROOT, tmdb, season)


def url_play_movie(tmdb):
    return "%s/play/pelicula/%s" % (ROOT, tmdb)


def url_play_episode(tmdb, season, episode):
    return "%s/play/capitulo/%s/%s/%s" % (ROOT, tmdb, season, episode)


def url_info_movie(tmdb):
    return "%s/info/pelicula/%s" % (ROOT, tmdb)


def url_simkl():
    return "%s/simkl" % ROOT


def url_resume():
    return "%s/seguir" % ROOT


def url_follow():
    return "%s/siguiendo" % ROOT


def url_list(key, whole=False):
    """fila de una lista del Inicio (clave de flix_tmdblists); whole: la lista entera («Ver más»)"""
    return "%s/lista/%s%s" % (ROOT, _q(key), "/todo" if whole else "")


def url_favorites(tipo, whole=False):
    """fila de favoritos (peliculas / series); whole: todos («Ver más» de la sección Favoritos)"""
    return "%s/favoritos/%s%s" % (ROOT, tipo, "/todo" if whole else "")


def url_cards(group, whole=False):
    """fila de tarjetas de una sección (sagas, géneros, años: cards.directory); whole: todas («Más…»)"""
    return "%s/tarjetas/%s%s" % (ROOT, _q(group), "/todo" if whole else "")


def url_list_page(key, n):
    """página n (2…) de 60 títulos de una lista de TMDB («Ver más» al final de la cuadrícula)"""
    return "%s/lista/%s/pagina/%d" % (ROOT, _q(key), int(n))


def url_list_rest(key, shown):
    """lo que viene tras los `shown` primeros títulos de la lista («Ver más» de una fila: solo el resto)"""
    return "%s/lista/%s/resto/%d" % (ROOT, _q(key), int(shown))


def url_alldebrid():
    return "%s/alldebrid" % ROOT


def url_trakt():
    return "%s/trakt" % ROOT


def url_cuentas():
    return "%s/cuentas" % ROOT


def parse(url):
    """(nombre de ruta, argumentos). Sin el «&reload=<ms>» que la skin añade para que Kodi vuelva a pedir una carpeta
    (flix_series_sheet.reload_series y demás; un «&» del texto buscado llega codificado: %26)"""
    rest = re.sub(r"&reload=\d+$", "", url.split("?")[0])
    if rest.startswith(ROOT):
        rest = rest[len(ROOT):]
    parts = [urllib.parse.unquote(p) for p in rest.strip("/").split("/") if p]
    if not parts:
        return "root", []
    head = parts[0]
    if head == "buscar" and len(parts) == 3:
        return "search", parts[1:]
    if head == "serie" and len(parts) == 2:
        return "seasons", parts[1:]
    if head == "serie" and len(parts) == 3:
        return "episodes", parts[1:]
    if head == "play" and len(parts) == 3 and parts[1] == "pelicula":
        return "play_movie", parts[2:]
    if head == "play" and len(parts) == 5 and parts[1] == "capitulo":
        return "play_episode", parts[2:]
    if head == "info" and len(parts) == 3 and parts[1] == "pelicula":
        return "info_movie", parts[2:]
    if head in ("simkl", "trakt") and len(parts) == 1:
        return head, []
    if head in ("alldebrid", "cuentas") and len(parts) == 1:
        return head, []
    if head == "seguir" and len(parts) == 1:
        return "resume", []
    if head == "siguiendo" and len(parts) == 1:
        return "follow", []
    if head == "marcar" and len(parts) == 4 and parts[1] in ("favorita", "nofavorita") \
            and parts[2] in ("pelicula", "serie") and parts[3].isdigit():
        return "mark", parts[1:]        # corazón de las fichas y «Añadir / Quitar de favoritos» del menú
    if head == "similares" and len(parts) == 3 and parts[1] in ("pelicula", "serie") and parts[2].isdigit():
        return "similar", parts[1:]     # «Ver similares» (lists.similar)
    if head == "favoritos" and len(parts) == 2 and parts[1] in ("peliculas", "series"):
        return "favorites", parts[1:]   # filas de favoritos (personal.favorites)
    if head == "favoritos" and len(parts) == 3 and parts[1] in ("peliculas", "series") and parts[2] == "todo":
        return "favorites", parts[1:]   # todos («Ver más» de la sección Favoritos; bloques 4 y 5)
    if head == "marcar" and len(parts) in (4, 6) and parts[1] in ("vista", "novista", "sinpausa", "noseguir", "hasta") \
            and (len(parts) == 6) == (parts[2] == "capitulo") and parts[2] in ("pelicula", "serie", "capitulo") \
            and (parts[1] != "hasta" or parts[2] == "capitulo") and all(p.isdigit() for p in parts[3:]):
        return "mark", parts[1:]        # menú de pulsación larga de la skin (marks.py)
    if head == "nover" and len(parts) == 3 and parts[1] == "pelicula" and parts[2].isdigit():
        return "no_version", parts[1:]  # el reproductor de la skin: ninguna versión pasó las reglas (lists.no_version)
    if head == "nover" and len(parts) == 5 and parts[1] == "capitulo" and all(p.isdigit() for p in parts[2:]):
        return "no_episode", parts[2:]  # …o ninguna versión de ese capítulo (series.mark_unavailable)
    if head == "lista" and len(parts) == 2:
        return "list", parts[1:]
    if head == "tarjetas" and len(parts) == 2:
        return "cards", parts[1:]       # fila de tarjetas de una sección (cards.directory; bloques 4 y 5)
    if head == "tarjetas" and len(parts) == 3 and parts[2] == "todo":
        return "cards_all", parts[1:2]
    if head == "lista" and len(parts) == 3 and parts[2] == "todo":
        return "list_all", parts[1:2]
    if head == "lista" and len(parts) == 4 and parts[2] == "resto" and parts[3].isdigit():
        return "list_rest", [parts[1], parts[3]]
    if head == "lista" and len(parts) == 4 and parts[2] == "pagina" and parts[3].isdigit() and int(parts[3]) >= 2:
        return "list_page", [parts[1], parts[3]]
    return "unknown", parts


SKIN_ART = ("thumb", "poster", "fanart", "clearlogo", "landscape", "banner", "icon", "clearart", "keyart",
            "tvshow.poster", "tvshow.fanart", "tvshow.clearlogo", "season.poster")
SKIN_PROPS = ("k3_next", "k3_upto", "k3_left", "k3_ring")
_SKIN_LOCK = threading.Lock()
SKIN_CACHE_AGE = 30     # s: la skin relee las cachés de disco (TMDB, listas) como mucho así al pedir una fila


def directory_for_skin(url, props, handlers=None):
    """22-nov (filas del Inicio, secciones…: «el mando más suelto»): la carpeta `url` del addon calculada en el
    proceso de la skin, sin Files.GetDirectory (que arranca el intérprete del addon por cada fila: 0,4-0,8 s de CPU
    en la Shield, 1-2 s en un Fire TV). Corre la misma ruta (_run) con un xbmcplugin que apunta lo que recibe y lo da
    con la forma de Files.GetDirectory: label, file, filetype, type y las propiedades pedidas (props). Las cachés de
    disco se releen si otro proceso las cambió y se guardan al acabar (mezclan con el disco). Una ruta a la vez en el
    proceso (el xbmcplugin de sys.modules se cambia mientras dura: todos los módulos lo importan dentro de la función)"""
    import types
    from ker0n3 import catalog, lists
    got = []
    fake = types.ModuleType("xbmcplugin")
    fake.addDirectoryItem = lambda handle, u, li, isFolder=False, totalItems=0: got.append((u, li, isFolder)) or True
    fake.addDirectoryItems = lambda handle, items, totalItems=0: got.extend(
        (i[0], i[1], bool(i[2]) if len(i) > 2 else False) for i in items) or True
    for name in ("endOfDirectory", "setContent", "setResolvedUrl", "addSortMethod", "setPluginCategory",
                 "setProperty", "setPluginFanart"):
        setattr(fake, name, lambda *a, **k: None)
    with _SKIN_LOCK:
        for cache in (catalog.default_cache(), lists.default_cache()):
            cache.reload_if_changed(min_age=SKIN_CACHE_AGE)
        real = sys.modules.get("xbmcplugin")
        sys.modules["xbmcplugin"] = fake
        try:
            _run([url, "-1"], handlers)
        finally:
            if real is not None:
                sys.modules["xbmcplugin"] = real
            else:
                sys.modules.pop("xbmcplugin", None)
            catalog.flush_default()
            lists.flush_default()
    return [skin_item(u, li, folder, props) for u, li, folder in got]


def wrap_art(url):
    """la imagen como la da Files.GetDirectory: image://<url codificada, %xx en minúscula>/ (CTextureUtils::
    GetWrappedImageURL; comprobado en la Shield con las filas, 22-nov)"""
    if not url or url.startswith("image://"):
        return url
    out = []
    for ch in url.encode("utf-8"):
        c = chr(ch)
        out.append(c if (c.isascii() and c.isalnum()) or c in "-._!()" else "%%%02x" % ch)
    return "image://%s/" % "".join(out)


def skin_item(url, li, folder, props):
    """un elemento de la carpeta como lo da Files.GetDirectory (props: las propiedades pedidas). Comprobado en la
    Shield contra Files.GetDirectory (filas del Inicio, 22-nov): sin ficha de vídeo (tarjeta «Más…»), solo title y
    art; «duration» no sale en vídeo; la edad, de la propiedad k3_mpaa (InfoTagVideo no tiene getMpaa)"""
    def call(obj, name, *a):
        try:
            return getattr(obj, name)(*a)
        except Exception:  # noqa: BLE001  (getter que falta en este Kodi o en las pruebas)
            return None
    tag = call(li, "getVideoInfoTag")
    mediatype = (call(tag, "getMediaType") if tag is not None else "") or ""
    out = {"label": call(li, "getLabel") or "", "file": url, "filetype": "directory" if folder else "file",
           "type": mediatype or "unknown"}
    t = (lambda name, *a: call(tag, name, *a)) if tag is not None else (lambda name, *a: None)
    for p in props:
        if p == "title":
            out[p] = t("getTitle") or ""
        elif p == "art":
            out[p] = {k: wrap_art(v) for k, v in ((k, call(li, "getArt", k)) for k in SKIN_ART) if v}
        elif not mediatype or p in ("duration", "file"):
            pass            # sin ficha de vídeo Kodi no da más; «duration» no sale en vídeo; «file» ya va
        elif p == "year":
            out[p] = int(t("getYear") or 0)
        elif p == "genre":
            out[p] = list(t("getGenres") or [])
        elif p == "rating":
            out[p] = float(t("getRating") or 0)
        elif p in ("runtime", "duration"):
            out[p] = int(t("getDuration") or 0)
        elif p == "resume":
            out[p] = {"position": float(t("getResumeTime") or 0), "total": float(t("getResumeTimeTotal") or 0)}
        elif p == "playcount":
            out[p] = int(t("getPlayCount") or 0)
        elif p == "plot":
            out[p] = t("getPlot") or ""
        elif p == "mpaa":
            out[p] = t("getMpaa") or call(li, "getProperty", "k3_mpaa") or ""
    # propiedades propias que Files.GetDirectory no da (22-nov: aquí sí llegan): capítulo que toca y círculo de los
    # que quedan en «Series en seguimiento» (personal.follow)
    props = {k: v for k, v in ((k, call(li, "getProperty", k)) for k in SKIN_PROPS) if v}
    if props:
        out["k3"] = props
    return out


def run(argv, handlers=None):
    try:
        _run(argv, handlers)
    finally:
        from ker0n3 import catalog, lists
        catalog.flush_default()     # la caché de TMDB y de disponibilidad, una sola escritura por ruta
        lists.flush_default()       # y la de listas (lista/<clave>)


def _run(argv, handlers=None):
    if handlers is None:
        from ker0n3 import handlers as mod
        handlers = mod.HANDLERS
    handle = int(argv[1]) if len(argv) > 1 and str(argv[1]).lstrip("-").isdigit() else -1
    name, args = parse(argv[0])
    fn = handlers.get(name)
    if fn is None:
        import xbmcplugin
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    try:
        import xbmcgui
        import xbmcplugin
    except ImportError:     # fuera de Kodi (pruebas de solo despacho)
        fn(handle, *args)
        return
    done = []
    real_end, real_res = xbmcplugin.endOfDirectory, xbmcplugin.setResolvedUrl

    def end(*a, **k):
        done.append(1)
        return real_end(*a, **k)

    def res(*a, **k):
        done.append(1)
        return real_res(*a, **k)
    xbmcplugin.endOfDirectory, xbmcplugin.setResolvedUrl = end, res
    try:
        fn(handle, *args)
    except Exception as e:  # noqa: BLE001  (un fallo no deja a Kodi esperando)
        try:
            import xbmc
            xbmc.log("[ker0n3] %s falló: %r" % (name, e), xbmc.LOGERROR)
        except Exception:  # noqa: BLE001
            pass
        if not done:
            if name.startswith("play"):
                real_res(handle, False, xbmcgui.ListItem())
            else:
                real_end(handle, succeeded=False)
    finally:
        xbmcplugin.endOfDirectory, xbmcplugin.setResolvedUrl = real_end, real_res
