"""¿Hay versión que se pueda usar? (Torrentio + Peerflix + PeLis si el aparato tiene su dirección, sin AllDebrid; de PeLis
cuentan las ⚡ y las ⏳ con alguna fuente: las de «0 fuentes» ya las quita flix_src_list.parse_pelis). Carlos, 15-nov: solo se enseña lo que tenga
alguna versión que parezca castellano por el nombre (flix_src_list.parse: esp). Caché 3 días si hay, 1 día si no;
fuentes caídas o TMDB sin red = desconocido (se enseña, no se guarda). Sin torrents con las dos fuentes contestando, o
TMDB sin id de IMDb = no (se guarda).

16-nov (Carlos): se ENSEÑA lo que tenga alguna versión en castellano O en versión original / inglés (todo lo que no sea
solo latino): lo que se enseña tiene que poder verse, y sin castellano el reproductor ofrece la original con
subtítulos. «ok» = hay alguna de esas; «esp» = hay castellano (se guarda aparte: lo que se REPRODUCE sigue prefiriendo
el castellano, y una insignia o un orden futuros pueden usarlo); «q» = la mejor calidad en castellano o, si no hay, la
mejor de las otras.

16-nov tarde (Carlos; «La Odisea» de The Asylum, «Godzilla Minus Zero» en cines): qué versión cuenta lo decide
flix_src_check.keep, la MISMA función que usa el reproductor (flix_src_play): película sin estrenar = no (sin preguntar
a las fuentes); en cines sin edición doméstica, modo estricto; fuera otro año, marcas de imitación, latino y lo que solo
está en un tercer idioma (ni castellano ni el idioma original de TMDB). Original en español: cualquier español vale y
cuenta como «esp». La ficha (fechas de estreno, año, idioma) sale del catálogo (catalog.movie / catalog.show, ya
guardada por el repaso; en el buscador, una petición a TMDB por película sin ficha). Sin ficha: no se sabe (None).

Lo guardado con las reglas de antes NO vale: la clave lleva la versión de las reglas (KEY, «a2/»); las «a/» viejas no
se leen (la caché las poda sola a los 8 días) y cada título se comprueba otra vez."""
import threading
import time

TTL_YES, TTL_NO = 3 * 86400, 86400
TTL_LIMITED = 600       # tras un 429 persistente: «no se sabe» 10 min, sin volver a preguntar en cada tecla
RULES = 6               # versión de las reglas (flix_src_check): al cambiarlas, lo guardado se comprueba otra vez  (6: Linkañol, 17-nov)
# (3, 4 y 5, 17-nov: numeración de IMDb en las series, flix_src_epmap —en la 3 el addon aún no llevaba el módulo—;
# Frieren no salía en el buscador)
KEY = "a%d/" % RULES    # + tipo/tmdb
MISS = "am/"            # + tmdb de la serie: [temporada, capítulo] del último emitido sin versión (bloque 3)

class _Status(dict):
    """status de flix_src_list.fetch; .limited = fuentes que siguieron dando 429"""
    def __init__(self):
        super().__init__()
        self.limited = []

def _quality(c):
    res = {2160: "4K", 1080: "1080p", 720: "720p"}.get(c.get("res"), "SD")
    extra = " DV" if c.get("dv") else " HDR" if c.get("hdr") else ""
    return res + extra

def _rank(c):
    return (c.get("res") or 0, bool(c.get("dv")), bool(c.get("hdr")))

def _hit(cache, key, now):
    """el sí (3 días) o el no (1 día) guardado; None si no hay. Lo comprobado en la etapa «de cine» (castellano
    descartado) caduca el día que sale en casa («until», 17-nov: La Odisea seguía con «VO» con castellano ya válido)"""
    for ttl in (TTL_YES, TTL_NO):
        hit = cache.get(key, ttl, now=now)
        if hit is not None and (hit.get("ok") or ttl == TTL_NO):
            until = cache.get(key + UNTIL, TTL_YES, now=now)
            if until and now() >= until:
                return None
            return hit
    return None


UNTIL = "~u"     # + clave del sí/no: hasta cuándo vale (lo de la etapa «de cine»)


def _until(m, today):
    """fecha (epoch, 00:00 local) en que una película «de cine» pasa a «en casa»; None si no aplica"""
    import flix_src_check
    try:
        if m.get("kind") != "movie" or flix_src_check.level(m, today) != "cine":
            return None
        casa = (m.get("rel") or {}).get("casa") or ""
        if not casa or casa <= today:
            return None
        return time.mktime(time.strptime(casa, "%Y-%m-%d"))
    except Exception:  # noqa: BLE001
        return None

def _no():
    return {"ok": False, "esp": False, "q": ""}

def _usable(found, meta=None, today=None):
    """versiones que valen para enseñar el título: las mismas que valdrían al reproducir (flix_src_check.keep)"""
    import flix_src_check
    return flix_src_check.keep(found, meta, today)

def _sheet_meta(kind, tmdb, cache=None):
    """la ficha para las reglas, del catálogo (guardada por el repaso; si falta, una petición a TMDB). None si la
    ficha no trae lo necesario; sin red y sin caché, lanza (quien llama lo da por desconocido)"""
    import flix_src_check
    from ker0n3 import catalog
    return flix_src_check.from_sheet(catalog.movie(tmdb, cache=cache) if kind == "movie"
                                     else catalog.show(tmdb, cache=cache))

def _alias(tmdb, imdb, season, episode):
    """numeración de IMDb si no es la de TMDB (anime: Frieren 1x38 de TMDB es el 2x10 de IMDb; flix_src_epmap)"""
    try:
        import flix_src_epmap
        return flix_src_epmap.alias(tmdb, imdb, season, episode)
    except Exception:  # noqa: BLE001
        return None

def check(kind, tmdb, last=None, fetch=None, imdb_of=None, cache=None, now=time.time, meta=None, today=None,
          alias=None):
    import flix_src_check
    import flix_src_list
    from ker0n3 import catalog
    if alias is None:       # con el fetch de verdad, la traducción de verdad; quien pone el suyo, pone la suya
        alias = _alias if fetch is None else (lambda *a: None)
    fetch = fetch or flix_src_list.fetch
    imdb_of = imdb_of or flix_src_list.imdb_of
    cache = cache or catalog.default_cache()
    key = "%s%s/%s" % (KEY, kind, tmdb)
    hit = _hit(cache, key, now)
    if hit is not None:
        return hit
    mkey = "l/%s/%s" % (kind, tmdb)
    if cache.get(mkey, TTL_LIMITED, now=now) is not None:
        return None         # hace poco contestaron 429: desconocido, sin insistir
    if kind == "tv" and not last:
        out = _no()
        cache.put(key, out, now=now)
        return out
    today = today or time.strftime("%Y-%m-%d", time.localtime(now()))
    try:
        m = (meta or _sheet_meta)(kind, tmdb, cache)
    except Exception:  # noqa: BLE001  (TMDB sin red y sin ficha guardada)
        m = None
    if m is None:
        return None         # sin ficha no se pueden aplicar las reglas: no se sabe, y no se guarda
    if flix_src_check.level(m, today) == "sin_estrenar":
        out = _no()         # ni en cines: cualquier versión es falsa. Sin preguntar a las fuentes
        cache.put(key, out, now=now)
        return out
    try:
        imdb = imdb_of(kind, tmdb, raise_errors=True)
    except Exception:  # noqa: BLE001  (sin red: no se sabe, y no se guarda)
        return None
    if not imdb:            # TMDB contestó y no tiene IMDb: sin id no hay torrents que buscar
        out = _no()
        cache.put(key, out, now=now)
        return out
    s, e = (last[0], last[1]) if last else (None, None)

    def fetch_ep(season, episode, status):
        al = alias(tmdb, imdb, season, episode) if kind == "tv" and season else None
        return fetch(kind, imdb, al[0] if al else season, al[1] if al else episode, status=status)
    st = _Status()
    found = fetch_ep(s, e, st)
    use = _usable(found, m, today)
    from_prev = False
    if not use and kind == "tv" and e and e > 1 and st and all(st.values()):
        from_prev = True
        # capítulo recién emitido del que aún no hay ninguna versión (16-nov, bloque 2, con el OK de Carlos): vale el
        # anterior. Una petición más solo para las series que iban a dar «no»
        st = _Status()
        found = fetch_ep(s, e - 1, st)
        use = _usable(found, m, today)
    if not use and not (st and all(st.values())):
        if st.limited:             # límite de peticiones: marca corta, aparte de los sí/no
            cache.put(mkey, {"t": 1}, now=now)
        return None         # alguna fuente no contestó: no se sabe, y no se guarda
    spanish = m.get("lang") == "es"         # original en español: cualquier versión que valga está en español
    # «esp» es del ÚLTIMO capítulo emitido (16-nov, «Manhunt»): si la serie se enseña por el anterior, no se afirma
    # castellano; el rótulo «[Esp]» y el interruptor «Solo en castellano» dicen lo que el reproductor va a encontrar
    esp = [] if from_prev else [c for c in use if spanish or c.get("esp")]
    out = {"ok": bool(use), "esp": bool(esp), "q": _quality(max(esp or use, key=_rank)) if use else ""}
    until = _until(m, today)
    if until:
        cache.put(key + UNTIL, until, now=now)
    if from_prev and use:
        # del último emitido aún no hay versión (bloque 3): apunte aparte para la ficha de la serie, que lo pinta
        # «Aún no disponible» unas horas sin preguntar nada (series.unavailable)
        cache.put("%s%s" % (MISS, tmdb), [int(s), int(e)], now=now)
    cache.put(key, out, now=now)
    return out

def mark_none(kind, tmdb, cache=None, now=time.time):
    """apunta «sin versión» (lo dice el reproductor, con las mismas reglas: lists.no_version)"""
    from ker0n3 import catalog
    cache = cache or catalog.default_cache()
    cache.put("%s%s/%s" % (KEY, kind, tmdb), _no(), now=now)

def cached(kind, tmdb, cache=None, now=time.time):
    """lo que haya en caché (sí o no) sin tocar la red; None si no se sabe"""
    from ker0n3 import catalog
    cache = cache or catalog.default_cache()
    return _hit(cache, "%s%s/%s" % (KEY, kind, tmdb), now)

SOLO_ESP = "flix_solo_castellano"   # Skin.Bool (Ajustes → Orden de calidades → «Solo en castellano»)

def solo_esp():
    """¿enseñar solo lo que tiene castellano? (interruptor de la skin; apagado de serie: también lo que solo está en
    versión original). Sin Kodi o ante cualquier fallo: no"""
    try:
        import xbmc
        return bool(xbmc.getCondVisibility("Skin.HasSetting(%s)" % SOLO_ESP))
    except Exception:  # noqa: BLE001
        return False

def shows(a, solo=False):
    """¿se enseña un título con esta disponibilidad comprobada? Con alguna versión; con solo=True, además castellano"""
    return bool(a and a.get("ok")) and (not solo or bool(a.get("esp")))

def has_esp(a):
    """para el rótulo: True = castellano, False = solo versión original, None = no se sabe (sin comprobar, o sin
    ninguna versión): sin rótulo de idioma. 16-nov («Manhunt»): «sin saber» contaba como castellano y las filas
    personales, que no comprueban nada, rotulaban «[Esp]» lo que nadie había mirado"""
    if not a or not a.get("ok"):
        return None
    return bool(a.get("esp"))

def many(items, workers=3, timeout=12, check=None, cancel=None):
    """{tmdb: resultado} de lo que dé tiempo a comprobar en `timeout` s (lo demás, ausente = desconocido).
    Las claves son solo el tmdb: quien llame debe pasar listas de un único tipo (película o serie), no mezcladas.
    cancel(): True = ya no hace falta (otra búsqueda): los hilos no cogen más"""
    check = check or (lambda kind, tmdb, last=None: globals()["check"](kind, tmdb, last))
    out, lock, queue = {}, threading.Lock(), list(items)
    stop = threading.Event()

    def worker():
        while True:
            with lock:
                if stop.is_set() or not queue:
                    return
            if cancel is not None and cancel():
                return
            with lock:
                if not queue:
                    return
                kind, tmdb, last = queue.pop(0)
            try:
                res = check(kind, tmdb, last)
            except Exception:  # noqa: BLE001
                res = None
            with lock:
                out[tmdb] = res
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(max(1, min(workers, len(items))))]
    for th in threads:
        th.start()
    end = time.monotonic() + timeout
    for th in threads:
        th.join(max(0, end - time.monotonic()))
    stop.set()      # pasado el plazo, los hilos libres no cogen más
    with lock:
        return dict(out)
