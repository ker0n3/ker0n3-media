"""Listados y reproducción de Ker0n3: lo que Kodi pide por cada ruta (parte 2b+2c; 15-nov)"""
import threading
import time

from ker0n3 import avail, catalog, router

HEADING = "KER0N3 MEDIA"
SEARCH_BUDGET = 20      # s para toda la búsqueda de series (buscar + fichas + disponibilidad)
MOVIE_AVAIL_BUDGET = 12     # s para la disponibilidad de las películas (la fila de películas sale antes)


MPAA_PROP = "k3_mpaa"     # edad del título también como propiedad: InfoTagVideo no tiene getMpaa (Kodi 21)

def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def notify(msg):
    import xbmcgui
    xbmcgui.Dialog().notification(HEADING, msg, xbmcgui.NOTIFICATION_WARNING, 4000)


def label_of(title, year, q, esp=True):
    lab = "%s (%d)" % (title, year) if year else title
    # flix_items.langs_from_label necesita ≥2 corchetes para leer el idioma; «?» = calidad desconocida.
    # esp=False: comprobado que no hay castellano y sí versión original (16-nov: también se enseña) → «VO».
    # esp=None: no se sabe (sin comprobar) → UN solo corchete, sin rótulo de idioma (16-nov, «Manhunt»: decía «[Esp]»)
    return lab + ("" if esp is None else " [%s]" % ("Esp" if esp else "VO")) + " [%s]" % (q or "?")


def _tag(li, d, mediatype):
    t = li.getVideoInfoTag()
    t.setMediaType(mediatype)
    t.setTitle(d.get("title") or "")
    if d.get("plot"):
        t.setPlot(d["plot"])
    if d.get("year"):
        t.setYear(int(d["year"]))
    if d.get("genres"):
        t.setGenres(list(d["genres"]))
    if d.get("rating"):
        t.setRating(float(d["rating"]))
    if d.get("duration"):
        t.setDuration(int(d["duration"]))
    if d.get("mpaa"):
        t.setMpaa(d["mpaa"])
        li.setProperty(MPAA_PROP, str(d["mpaa"]))     # la skin la lee así en su proceso (router.skin_item, 22-nov)
    if d.get("premiered"):
        t.setPremiered(d["premiered"])
    if d.get("tmdb"):
        t.setUniqueIDs({"tmdb": str(d["tmdb"])}, "tmdb")
    return t


def _art(d):
    return {k: v for k, v in (("poster", d.get("poster")), ("fanart", d.get("fanart")), ("thumb", d.get("poster")),
                              ("clearlogo", catalog.logo_url(d.get("clearlogo")))) if v}


def movie_item(d, q="", esp=True):
    import xbmcgui
    li = xbmcgui.ListItem(label_of(d.get("title") or "", d.get("year") or 0, q, esp), path=router.url_play_movie(d["tmdb"]))
    _tag(li, d, "movie")
    li.setArt(_art(d))
    li.setProperty("IsPlayable", "true")
    return li


def show_item(d, q="", esp=True):
    import xbmcgui
    li = xbmcgui.ListItem(label_of(d.get("title") or "", d.get("year") or 0, q, esp), path=router.url_show(d["tmdb"]))
    _tag(li, d, "tvshow")
    li.setArt(_art(d))
    return li


def _end(handle, content, ok=True):
    import xbmcplugin
    if content:
        xbmcplugin.setContent(handle, content)
    xbmcplugin.endOfDirectory(handle, succeeded=ok, cacheToDisc=False)


def query_changed(text):
    """el buscador de la skin ya busca otra cosa (Window(home).flix_query, flix_search.run_search): lo que quede de
    esta búsqueda no lo va a ver nadie. Sin la propiedad (ruta abierta desde otro sitio) no se da por cambiada"""
    try:
        import xbmcgui
        now = xbmcgui.Window(10000).getProperty("flix_query") or ""
    except Exception:  # noqa: BLE001
        return False
    return bool(now.strip()) and now.strip().lower() != (text or "").strip().lower()


def _last_aired_many(tmdbs, workers=6, timeout=12, cancel=None):
    """{tmdb: last_aired o None} de las fichas que SÍ se obtuvieron (en paralelo, con plazo). Las que fallan o no llegan
    a tiempo quedan ausentes: son desconocidas, no «nada emitido». cancel(): True = no coger más"""
    out, lock, queue = {}, threading.Lock(), list(tmdbs)
    stop = threading.Event()

    def worker():
        while True:
            with lock:
                if stop.is_set() or not queue:
                    return
            if cancel is not None and cancel():
                return
            with lock:
                if not queue:
                    return
                tmdb = queue.pop(0)
            try:
                last = (catalog.show(tmdb) or {}).get("last_aired")
            except Exception:  # noqa: BLE001
                continue
            with lock:
                out[tmdb] = last
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(max(1, min(workers, len(queue))))]
    for th in threads:
        th.start()
    end = time.monotonic() + timeout
    for th in threads:
        th.join(max(0, end - time.monotonic()))
    stop.set()
    with lock:
        return dict(out)


PELIS_WAIT = 1.5    # s que el buscador espera a PeLis tras contestar las demás (flix_src_list.fetch, pelis_wait)
SEARCH_WORKERS = 5  # títulos a la vez en el buscador (Torrentio sigue con 2 a la vez por servidor: flix_src_list._HOST_MAX)


SEARCH_NO_TTL = 3600   # s: en el buscador, un «sin versión» guardado hace más de 1 h se vuelve a mirar (18-nov, Carlos:
                       # Bleach seguía sin salir en series con un «no» de antes de los arreglos, que valía 24 h)


def _search_check(kind, tmdb, last=None):
    return avail.check(kind, tmdb, last, pelis_wait=PELIS_WAIT, no_ttl=SEARCH_NO_TTL)


def _search_check_fast(kind, tmdb, last=None):
    """la 1.ª pasada del buscador (21-nov, medido en la Shield: «matrix» esperaba 7-8 s a PeLis por 3 títulos que no
    tenían castellano en las demás y la fila salía a los 12 s): lo que solo PeLis puede decidir vuelve
    avail.DEFERRED y se comprueba entero por detrás (_search_more); el resto, igual que _search_check"""
    return avail.check(kind, tmdb, last, pelis_wait=PELIS_WAIT, no_ttl=SEARCH_NO_TTL, defer_pelis=True)


def obscure(r):
    """resultado de TMDB que no merece comprobarse: sin cartel o sin un solo voto (solo si viene el dato de votos: las
    búsquedas guardadas antes del 17-nov no lo traen)"""
    return "votes" in r and (not r.get("poster") or r["votes"] == 0)


def search(handle, kind, text):
    import xbmcplugin
    tmdb_kind = "tv" if kind == "series" else "movie"
    if not (text or "").strip():
        _end(handle, "tvshows" if tmdb_kind == "tv" else "movies")
        return
    t0 = time.monotonic()
    # sin cartel o sin un solo voto en TMDB (17-nov, «bleach»: 9 de 20 eran cortos y vídeos sin nada): ni se comprueban,
    # así la búsqueda va más rápida y lo que importa se comprueba antes de que se acabe el tiempo
    results = [r for r in catalog.search(text, tmdb_kind)[:20] if not obscure(r)]

    def left():
        return max(1, SEARCH_BUDGET - (time.monotonic() - t0))

    def cancel():
        return query_changed(text)
    if tmdb_kind == "tv":
        lasts = _last_aired_many([r["tmdb"] for r in results], timeout=left() * 0.6, cancel=cancel)
        items = [("tv", r["tmdb"], lasts[r["tmdb"]]) for r in results if r["tmdb"] in lasts]
        budget = left()
    else:
        items = [("movie", r["tmdb"], None) for r in results]
        budget = MOVIE_AVAIL_BUDGET
    t_many = time.monotonic()
    ok = avail.many(items, workers=SEARCH_WORKERS, timeout=budget, cancel=cancel,
                    check=_search_check_fast) if items else {}
    deferred = [it for it in items if ok.get(it[1]) is avail.DEFERRED]
    if deferred and not any(ok.get(r["tmdb"]) not in (None, avail.DEFERRED) for r in results):
        # nada comprobado del todo (p. ej. todo sin castellano en las demás): la fila depende de PeLis → se la espera
        # aquí como siempre, con lo que quede del plazo (así lo que se enseña no cambia: ni títulos sin comprobar)
        rest = max(1, budget - (time.monotonic() - t_many))
        ok.update(avail.many(deferred, workers=SEARCH_WORKERS, timeout=rest, cancel=cancel, check=_search_check))
    for it in items:
        if ok.get(it[1]) is avail.DEFERRED:
            ok.pop(it[1])       # sin decidir: no se enseña aún y se comprueba entero por detrás (pend)
    shown, solo = 0, avail.solo_esp()
    # lo que no dio tiempo a comprobar (o con una fuente caída) solo se enseña si NO se pudo comprobar nada (fuentes
    # caídas: mejor algo que nada). 17-nov: tras cambiar las reglas salían títulos sin ningún enlace
    # (lo aplazado para PeLis no cuenta: solo se aplaza si hay algo comprobado del todo; si no, se esperó arriba)
    known = any(ok.get(r["tmdb"]) is not None for r in results)
    for r in results:
        a = ok.get(r["tmdb"])
        if a is None and known:
            continue
        if a is not None and not avail.shows(a, solo):
            continue
        q, esp = (a or {}).get("q", ""), avail.has_esp(a)
        if tmdb_kind == "tv":
            xbmcplugin.addDirectoryItem(handle, router.url_show(r["tmdb"]), show_item(r, q, esp), isFolder=True)
        else:
            xbmcplugin.addDirectoryItem(handle, router.url_play_movie(r["tmdb"]), movie_item(r, q, esp), isFolder=False)
        shown += 1
    log("buscar %s %r: %d de %d" % (kind, text, shown, len(results)))
    # 20-nov (Carlos: «en el móvil la primera búsqueda no me mostraba las series, he tenido que darle otra vez»): lo
    # que no dio tiempo a comprobar se sigue comprobando DESPUÉS de dar la carpeta (las mismas preguntas que haría la
    # 2.ª búsqueda, ninguna más) y la skin, avisada, vuelve a pedir la fila (flix_search: ya sale de lo guardado)
    pend = [it for it in items if ok.get(it[1]) is None] if known else []
    missing = [r["tmdb"] for r in results if r["tmdb"] not in lasts] if (known and tmdb_kind == "tv") else []
    more = bool(pend or missing) and not cancel()
    key = (text or "").strip().lower()
    _home_set(SEARCH_PENDING % kind, key if more else "")
    _end(handle, "tvshows" if tmdb_kind == "tv" else "movies")
    if more:
        _search_more(kind, text, key, pend, missing, solo, cancel)


SEARCH_MORE_BUDGET = 40     # s comprobando por detrás lo que no dio tiempo (tras dar la carpeta)
SEARCH_PENDING = "k3_search_pending_%s"     # Window(home): búsqueda (minúsculas) que sigue comprobando, por ruta
SEARCH_DONE = "k3_search_done_%s"           # «búsqueda|nuevas|ms» al acabar


def _home_set(key, value):
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty(key, value)
    except Exception:  # noqa: BLE001  (fuera de Kodi: nada)
        pass


def _search_more(kind, text, key, pend, missing, solo, cancel):
    """comprueba lo que la búsqueda no llegó a comprobar (y las series cuya ficha no llegó) y avisa a la skin; lo
    comprobado queda guardado (avail), así la ruta repetida lo enseña sin preguntar. Nunca lanza"""
    t0, n = time.monotonic(), 0
    lock, found = threading.Lock(), [0]

    def each(tmdb, a):
        """24-nov (Carlos, móvil, «la isla de las tenta»: 1 de 5 y las otras 3 llegaron a los 35 s, todas a la vez,
        por la más lenta): cada título con versión se guarda y se avisa ya; la skin vuelve a pedir la fila con cada
        aviso (mismo formato «búsqueda|nuevas|ms»; nuevas = las que van) hasta que se quita la marca de pendiente"""
        if a is None or not avail.shows(a, solo) or cancel():
            return
        with lock:
            found[0] += 1
            count = found[0]
            catalog.flush_default()             # la fila repetida lo lee en otro proceso: guardado antes de avisar
        _home_set(SEARCH_DONE % kind, "%s|%d|%d" % (key, count, int(time.time() * 1000)))
    try:
        if missing and not cancel():
            lasts = _last_aired_many(missing, timeout=SEARCH_MORE_BUDGET * 0.4, cancel=cancel)
            pend = list(pend) + [("tv", t, lasts[t]) for t in missing if t in lasts]
        left = max(1, SEARCH_MORE_BUDGET - (time.monotonic() - t0))
        got = avail.many(pend, workers=SEARCH_WORKERS, timeout=left, cancel=cancel,
                         check=_search_check, on_result=each) if pend and not cancel() else {}
        n = sum(1 for a in got.values() if a is not None and avail.shows(a, solo))
        log("buscar %s %r: por detrás %d de %d con versión (%.1f s)" % (kind, text, n, len(pend),
                                                                      time.monotonic() - t0))
    except Exception as e:  # noqa: BLE001
        log("buscar %s %r por detrás: %r" % (kind, text, e))
    finally:
        catalog.flush_default()
        _home_set(SEARCH_DONE % kind, "%s|%d|%d" % (key, n, int(time.time() * 1000)))
        if not cancel():
            _home_set(SEARCH_PENDING % kind, "")    # acabó: la skin deja de esperar (antes esperaba hasta su plazo)


def _layout(tmdb, s, aired=None, stale_ok=False):
    """el reparto como en IMDb de una serie con una temporada enorme (parts.layout), con lo emitido después de
    calcularlo; None en el resto (sin una sola petición más). aired(T): capítulos emitidos de T (por defecto, los
    guardados). stale_ok: el guardado aunque haya caducado, renovado por detrás (la ficha de la skin). Nunca lanza"""
    try:
        from ker0n3 import parts
        lay = parts.layout(tmdb, show=s, stale_ok=stale_ok)
        top = parts.latest(lay)
        if top:
            if aired is None:
                today = time.strftime("%Y-%m-%d")
                aired = lambda n: [e.get("n") for e in catalog.season_cached(tmdb, n) or []      # noqa: E731
                                   if e.get("premiered") and e["premiered"] <= today]
            lay = parts.with_tail(lay, aired(top[1]))
        return lay
    except Exception as e:  # noqa: BLE001
        log("reparto de %s: %r" % (tmdb, e))
        return None


def _publish_state(tmdb, s, lay):
    """qué capítulo toca («Seguir viendo · T1 E4», «Al día», «Ver de nuevo»): con lo guardado, para la skin (bloque 3)"""
    try:
        from ker0n3 import parts, series
        parts.publish(tmdb, lay)                        # el reparto, para los ✓ por parte (o fuera el de otra vez)
        series.publish(tmdb, parts.annotate(series.of(tmdb, show=s), lay))
    except Exception as e:  # noqa: BLE001  (sin base o sin ficha: la skin se queda con «Ver»)
        log("estado de la serie %s: %r" % (tmdb, e))


SKIN_CACHE_AGE = 600     # s: la skin relee la caché del addon como mucho así (temporadas y fechas cambian poco; lo visto
                         # va en watched.db, que se lee siempre al día)


def seasons_for_skin(tmdb):
    """20-nov (Carlos, Shield: abrir una serie tardaba 1-2 s; con Palantir la skin leía su base sin lanzarlo): lo mismo
    que la carpeta serie/<tmdb> (temporadas o partes, y el estado publicado en Window(home)) pero llamado DENTRO del
    proceso de la skin, sin arrancar el intérprete del addon. Mismas claves que Files.GetDirectory con las propiedades
    que pide flix_series (K3_SEASON_PROPS). La caché se relee si otro proceso la cambió"""
    catalog.default_cache().reload_if_changed(min_age=SKIN_CACHE_AGE)
    s = catalog.show(tmdb, stale_ok=True)      # caducada: la guardada ya y se renueva por detrás (no 2 s a TMDB)
    lay = _layout(tmdb, s, stale_ok=True)      # igual el reparto en partes (23-nov, Black Clover 2,7 s)
    art = {k: v for k, v in (("fanart", s.get("fanart")), ("clearlogo", catalog.logo_url(s.get("clearlogo")))) if v}
    out = []
    if lay:
        posters = {int(x["n"]): x for x in s.get("seasons") or [] if x.get("n")}
        for p in lay:
            x = posters.get(int(p.get("s") or 0)) or {}
            plot = (x.get("plot") if p.get("o") else "") or s.get("plot") or ""
            out.append((p["v"], p["name"], plot, x.get("poster") or s.get("poster"), len(p["eps"]), p.get("year")))
    else:
        for x in s.get("seasons") or []:
            out.append((x["n"], x["name"], x.get("plot") or s.get("plot") or "", x.get("poster") or s.get("poster"),
                        x.get("episodes") or 0, x.get("year")))
    items = []
    for v, name, plot, poster, total, year in out:
        a = dict(art, **({"poster": poster} if poster else {}))
        # total y año: los mismos que la carpeta (TotalEpisodes, Year), para la ficha que no la pide (22-nov)
        items.append({"label": name, "title": name, "showtitle": s.get("title") or "", "season": int(v),
                      "file": router.url_season(tmdb, v), "filetype": "directory", "art": a,
                      "genre": list(s.get("genres") or []), "plot": plot, "rating": float(s.get("rating") or 0),
                      "episodes": int(total or 0), "year": int(year) if str(year or "").isdigit() else 0})
    _publish_state(tmdb, s, lay)
    catalog.flush_default()             # si hubo que pedir algo a TMDB, al disco (este proceso no acaba)
    return items


def seasons(handle, tmdb):
    import xbmcgui
    import xbmcplugin
    s = catalog.show(tmdb)
    lay = _layout(tmdb, s)
    if lay:
        _parts(handle, tmdb, s, lay)
    for x in [] if lay else s.get("seasons") or []:
        li = xbmcgui.ListItem(x["name"], path=router.url_season(tmdb, x["n"]))
        t = li.getVideoInfoTag()
        t.setMediaType("season")
        t.setSeason(int(x["n"]))
        t.setTitle(x["name"])
        t.setTvShowTitle(s.get("title") or "")
        if s.get("rating"):        # nota de la SERIE (la ficha la enseña: táctil sin ella, 18-nov)
            t.setRating(float(s["rating"]), int(s.get("votes") or 0), "tmdb", True)
        if x.get("plot") or s.get("plot"):
            t.setPlot(x.get("plot") or s.get("plot"))
        if x.get("year"):
            t.setYear(int(x["year"]))
        if s.get("genres"):
            t.setGenres(list(s["genres"]))
        li.setArt({k: v for k, v in (("poster", x.get("poster") or s.get("poster")), ("fanart", s.get("fanart")),
                                     ("clearlogo", catalog.logo_url(s.get("clearlogo")))) if v})
        li.setProperty("TotalEpisodes", str(x.get("episodes") or 0))
        li.setProperty("WatchedEpisodePercent", "0")    # ✓ y «En progreso»: la skin, de la base (flix_series.seasons_seen)
        xbmcplugin.addDirectoryItem(handle, router.url_season(tmdb, x["n"]), li, isFolder=True)
    _publish_state(tmdb, s, lay)
    _end(handle, "seasons")


def _parts(handle, tmdb, s, lay):
    """las temporadas como en IMDb (parts.layout): una carpeta por parte, serie/<tmdb>/<v> (v ≥ parts.PART_BASE)"""
    import xbmcgui
    import xbmcplugin
    posters = {int(x["n"]): x for x in s.get("seasons") or [] if x.get("n")}
    for p in lay:
        x = posters.get(int(p.get("s") or 0)) or {}
        li = xbmcgui.ListItem(p["name"], path=router.url_season(tmdb, p["v"]))
        t = li.getVideoInfoTag()
        t.setMediaType("season")
        t.setSeason(int(p["v"]))
        t.setTitle(p["name"])
        t.setTvShowTitle(s.get("title") or "")
        if s.get("rating"):        # nota de la SERIE (la ficha la enseña: táctil sin ella, 18-nov)
            t.setRating(float(s["rating"]), int(s.get("votes") or 0), "tmdb", True)
        # la sinopsis de la temporada de TMDB solo si la parte es otra ficha (la guerra sangrienta de Bleach); las de
        # la serie son trozos de una temporada enorme: la de la serie
        plot = (x.get("plot") if p.get("o") else "") or s.get("plot")
        if plot:
            t.setPlot(plot)
        if p.get("year"):
            t.setYear(int(p["year"]))
        if p.get("air_date"):
            t.setPremiered(p["air_date"])
        if s.get("genres"):
            t.setGenres(list(s["genres"]))
        li.setArt({k: v for k, v in (("poster", x.get("poster") or s.get("poster")), ("fanart", s.get("fanart")),
                                     ("clearlogo", catalog.logo_url(s.get("clearlogo")))) if v})
        li.setProperty("TotalEpisodes", str(len(p["eps"])))
        li.setProperty("WatchedEpisodePercent", "0")    # ✓ y «En progreso»: la skin, por parte (flix_series.seasons_seen)
        xbmcplugin.addDirectoryItem(handle, router.url_season(tmdb, p["v"]), li, isFolder=True)


def _episode_marks(tmdb, season):
    """({capítulo: (visto, %, duración)}, {capítulos sin versión}) de lo guardado; nunca lanza"""
    marks, off = {}, set()
    try:
        from ker0n3 import series, store
        marks = store.season_marks(tmdb, season)
        off = series.unavailable(tmdb, season)
    except Exception as e:  # noqa: BLE001
        log("vistos de %s T%s: %r" % (tmdb, season, e))
    return marks, off


def episodes(handle, tmdb, season):
    """capítulos EMITIDOS de la temporada (bloque 3): «1x03 Título», ✓ y barra de la base
    propia, fecha a la española (flix_date: «5 nov»). Los emitidos que se sabe que no tienen versión no salen
    (series.unavailable): la ficha los pinta debajo con los que están por llegar. Una parte (temporada ≥
    parts.PART_BASE): sus capítulos de TMDB (part_episodes). Los elementos, de episode_items (los mismos que la ficha
    de la skin pide en su proceso: episodes_for_skin)"""
    import xbmcplugin
    for url, li in episode_items(tmdb, season):
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    _end(handle, "episodes")


def episodes_for_skin(tmdb, season):
    """22-nov (Carlos: «¿no hay manera de acelerar la carga de episodios?»): los capítulos de la temporada, los mismos
    ListItem que la carpeta serie/<tmdb>/<T>, pero DENTRO del proceso de la skin: la ficha los pone ella en su lista sin
    que Kodi arranque el intérprete del addon (0,4-0,8 s en la Shield, 1-2 s en un Fire TV) ni pase por su cargador de
    listas (que además los volvía a pedir al empezar o parar cualquier vídeo, el tráiler incluido). La caché se relee si
    otro proceso la cambió; sin guardar, TMDB (quien llama lo hace en un hilo)"""
    catalog.default_cache().reload_if_changed(min_age=SKIN_CACHE_AGE)
    items = episode_items(tmdb, season)
    catalog.flush_default()
    return items


def episode_items(tmdb, season):
    """[(ruta de reproducción, ListItem)] de los capítulos emitidos de la temporada (o de la parte, si season ≥
    parts.PART_BASE): la base común de episodes (carpeta del addon) y episodes_for_skin (ficha)"""
    from ker0n3 import parts, series
    if int(season) >= parts.PART_BASE:
        return part_items(tmdb, int(season))
    s = catalog.show(tmdb)
    marks, off = _episode_marks(tmdb, season)
    today = series.today()
    out = []
    for e in catalog.episodes(tmdb, season):        # solo los ya emitidos
        n = e.get("n")
        if not isinstance(n, int) or n in off:
            continue
        out.append((router.url_play_episode(tmdb, season, n),
                    _episode_item(tmdb, s, int(season), e, marks, today, "%sx%02d" % (int(season), n))))
    return out


def part_episodes(handle, tmdb, v):
    """la carpeta de una parte (part_items)"""
    import xbmcplugin
    for url, li in part_items(tmdb, v):
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    _end(handle, "episodes")


def part_items(tmdb, v):
    """los capítulos de una parte (parts.layout) con su numeración en pantalla, «17x03 Título» (17 = k de la parte, 3
    = su puesto en ella), y por dentro los de TMDB: ruta play/capitulo/<tmdb>/<T>/<C>, setSeason/setEpisode, ✓ y
    barras de la base. Sin reparto (sin red y sin nada guardado): ninguno"""
    from ker0n3 import parts, series
    s = catalog.show(tmdb)
    today = series.today()
    seasons = {}

    def season(n):
        """({capítulo: datos} emitidos, marcas, sin versión) de la temporada n de TMDB, una vez"""
        if n not in seasons:
            marks, off = _episode_marks(tmdb, n)
            seasons[n] = ({e["n"]: e for e in catalog.episodes(tmdb, n) if isinstance(e.get("n"), int)}, marks, off)
        return seasons[n]
    lay = _layout(tmdb, s, aired=lambda n: list(season(n)[0]))
    p = parts.part(lay, v)
    out = []
    for pos, (n, c) in enumerate(p["eps"] if p else [], 1):
        eps, marks, off = season(n)
        e = eps.get(c)
        if e is None or c in off:       # aún no emitido o sin versión: la ficha lo pinta debajo (o no sale)
            continue
        out.append((router.url_play_episode(tmdb, n, c), _episode_item(tmdb, s, n, e, marks, today,
                                                                        "%dx%02d" % (p["k"], pos))))
    return out


def _episode_item(tmdb, s, season, e, marks, today, number):
    """el capítulo e (catalog.episodes) de la temporada season de TMDB; number: «1x03» en la etiqueta"""
    import xbmcgui
    import flix_common
    n = e["n"]
    url = router.url_play_episode(tmdb, season, n)
    li = xbmcgui.ListItem(("%s %s" % (number, e.get("title") or "")).strip(), path=url)
    t = li.getVideoInfoTag()
    t.setMediaType("episode")
    t.setTitle(e.get("title") or "")
    t.setTvShowTitle(s.get("title") or "")
    t.setSeason(int(season))
    t.setEpisode(int(n))
    if e.get("plot"):
        t.setPlot(e["plot"])
    if e.get("duration"):
        t.setDuration(int(e["duration"]))
    if e.get("premiered"):
        t.setPremiered(e["premiered"])
    if e.get("rating"):
        t.setRating(float(e["rating"]))
    t.setUniqueIDs({"tmdb": str(tmdb)}, "tmdb")
    seen, pct, runtime = marks.get(n, (0, 0.0, 0))
    total = runtime or e.get("duration") or s.get("duration") or 0
    if pct > 0 and total:
        t.setResumePoint(round(total * pct / 100.0, 3), float(total))      # barra; el clic pregunta «Te quedaste en…»
    elif seen > 0:
        t.setPlaycount(int(seen))                                          # ✓
    li.setArt({k: v for k, v in (("thumb", e.get("still") or s.get("fanart")), ("fanart", s.get("fanart")),
                                 ("poster", s.get("poster")), ("clearlogo", catalog.logo_url(s.get("clearlogo")))) if v})
    li.setProperty("IsPlayable", "true")
    # el número de la etiqueta («1x05» → 5; partes «20x09» → 9) para la píldora «EPISODIO n» de la ficha (21-nov)
    li.setProperty("k3_ep", str(int(number.rsplit("x", 1)[-1])) if "x" in number else str(n))
    li.setProperty("flix_date", flix_common.date_es(e.get("premiered") or "", today))
    li.setProperty("flix_aired", e.get("premiered") or "")     # AAAA-MM-DD: la ficha comprueba el de hoy / ayer
    return li


def info_movie(handle, tmdb):
    """un solo elemento con la ficha entera (la skin lo pide por JSON-RPC para su ficha de película)"""
    import xbmcplugin
    d = catalog.movie(tmdb)
    a = avail.cached("movie", int(tmdb)) or {}       # solo caché: la ficha no espera a la red
    xbmcplugin.addDirectoryItem(handle, router.url_play_movie(tmdb), movie_item(d, a.get("q", ""), avail.has_esp(a)),
                                isFolder=False)
    _end(handle, "movies")


def _tag_episode(li, tmdb, season, episode):
    t = li.getVideoInfoTag()
    t.setMediaType("episode")
    t.setSeason(int(season))
    t.setEpisode(int(episode))
    t.setUniqueIDs({"tmdb": str(tmdb)}, "tmdb")     # «Saltar intro» y el aviso del siguiente saben qué serie es
    try:
        t.setTvShowTitle((catalog.show(tmdb) or {}).get("title") or "")
    except Exception:  # noqa: BLE001
        pass
    try:
        for e in catalog.episodes(tmdb, season):
            if e.get("n") == int(episode):
                t.setTitle(e.get("title") or "")
                break
    except Exception:  # noqa: BLE001
        pass


def _pick_sub(kind, tmdb, season, episode):
    """el título (o la serie y el capítulo) debajo de «Elegir versión», de la ficha ya guardada; '' si falla"""
    try:
        import flix_src_play
        d = catalog.movie(tmdb) if kind == "movie" else catalog.show(tmdb)
        info = {"content": "movies" if kind == "movie" else "episodes", "tmdb": tmdb, "season": season,
                "episode": episode, "title": d.get("title") or "", "tvshowtitle": d.get("title") or ""}
        return flix_src_play.pick_sub(info)
    except Exception:  # noqa: BLE001
        return ""


def _play(handle, kind, tmdb, season=None, episode=None):
    import xbmcgui
    import xbmcplugin
    import flix_alldebrid
    import flix_quality
    import flix_src_play
    conf = flix_quality.load()
    t0 = time.monotonic()
    url, found = None, 0
    try:
        cands = flix_src_play.candidates(kind, int(tmdb), season, episode)
        if cands:
            # la ficha para las reglas contra enlaces falsos (flix_src_check, 16-nov): del catálogo, la misma que usa
            # la disponibilidad; ya guardada (y la película la pide de todos modos más abajo). Sin ficha: como antes
            try:
                import flix_src_check
                meta = flix_src_check.from_sheet(catalog.movie(tmdb) if kind == "movie" else catalog.show(tmdb))
            except Exception as e:  # noqa: BLE001
                log("ficha para las reglas: %s" % e)
                meta = None
            found = len(cands)
            cands = flix_src_play.usable(cands, meta, lang=bool(conf.auto) and meta is not None)
            if not cands and meta is not None and kind == "movie":
                # ninguna pasa las reglas: «sin versión» ya, para que no vuelva a salir en las filas
                log("ninguna versión pasa las reglas (%d torrents)" % found)
                try:
                    from ker0n3 import lists
                    lists.no_version("movie", int(tmdb))
                    lists.flush_default()
                except Exception as e:  # noqa: BLE001
                    log("sin apuntar: %r" % e)
        if cands and conf.auto:
            url, best = flix_src_play.resolve(cands, conf, season, episode,
                                              deadline=t0 + flix_src_play.SEARCH_DEADLINE, meta=meta)
        elif cands:
            import xbmc
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
            url, best = flix_src_play.choose(cands, conf, season, episode, sub=_pick_sub(kind, tmdb, season, episode))
            if url == "cancel":
                url = None
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return
    except flix_alldebrid.ADError as e:
        log("AllDebrid: %s" % e.kind)
        import flix_playaccount
        notify(flix_playaccount.error_text(e.kind, flix_playaccount.active()))
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    if not url:
        if kind == "tv" and (found or flix_src_play.answered(kind, int(tmdb), season, episode)):
            no_episode(handle, tmdb, season, episode)       # «Aún no disponible» en la ficha (no con fuentes caídas)
        notify("No hay versión lista ahora mismo")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    if conf.auto and not flix_src_play.direct(best):
        # ninguna en castellano (15-nov tarde): se pregunta por la versión original (16-nov; lo elegido a mano en el
        # selector va tal cual)
        import xbmc
        log("sin versión en castellano: pregunto por la original")
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
        if not flix_src_play.want_vo(kind):
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        # subtítulos en castellano (y la pista de audio original) cuando arranque: script aparte, porque este proceso
        # acaba al resolver
        lang = (best or {}).get("vo_lang") or ""
        xbmc.executebuiltin("RunScript(special://home/addons/plugin.video.ker0n3/resources/lib/flix_src_subs.py%s)" % ("," + lang if lang else ""))
    elif not conf.auto and best and not flix_src_play.is_cast(best) and not flix_src_play.direct(best):
        # elegido a mano y no castellano (Taboo 1x01, S24 16-nov): subtítulos en castellano y el audio original
        import xbmc
        lang = (best or {}).get("vo_lang") or ((meta or {}).get("lang") if cands else "") or ""
        xbmc.executebuiltin("RunScript(special://home/addons/plugin.video.ker0n3/resources/lib/flix_src_subs.py%s)" % ("," + lang if lang else ""))
    elif (best or {}).get("audio") == "cast":
        # castellano confirmado en un fichero con varias pistas: que suene esa (Slow Horses 3x05 arrancaba en italiano)
        import xbmc
        xbmc.executebuiltin("RunScript(special://home/addons/plugin.video.ker0n3/resources/lib/flix_src_subs.py,castellano)")
    li = xbmcgui.ListItem(path=url)
    try:        # el enlace ya está: ninguna ficha que falle puede perderlo
        if kind == "movie":
            _tag(li, catalog.movie(tmdb), "movie")
        else:
            _tag_episode(li, tmdb, season, episode)
    except Exception as e:  # noqa: BLE001
        log("ficha al reproducir: %s" % e)
    # para el servicio de Ker0n3: qué se reproduce (base de vistos; flix_src_play.mark_playing)
    flix_src_play.mark_playing({"tmdb": tmdb, "content": "movies" if kind == "movie" else "episodes",
                                "season": season, "episode": episode}, url, cand=best, manual=not conf.auto)
    xbmcplugin.setResolvedUrl(handle, True, li)


def play_movie(handle, tmdb):
    _play(handle, "movie", tmdb)


def play_episode(handle, tmdb, season, episode):
    _play(handle, "tv", tmdb, int(season), int(episode))


def resume(handle):
    """fila «Seguir viendo» de la base de Ker0n3 (personal.resume)"""
    from ker0n3 import personal
    personal.resume(handle)


def follow(handle):
    """fila «Series en seguimiento» de la base de Ker0n3 (personal.follow)"""
    from ker0n3 import personal
    personal.follow(handle)


def favorites(handle, tipo, todo=None):
    """filas de favoritos de la base de Ker0n3 (personal.favorites): peliculas o series; todo: todos («Ver más»)"""
    from ker0n3 import personal
    personal.favorites(handle, tipo, whole=todo == "todo")


def similar(handle, tipo, tmdb):
    """«Ver similares» de un título (lists.similar): parecidos de TMDB con la regla de las filas"""
    from ker0n3 import lists
    lists.similar(handle, tipo, tmdb)


def list_row(handle, key):
    """fila de una lista del Inicio (lists.directory): Top 10, novedades, plataformas, géneros…"""
    from ker0n3 import lists
    lists.directory(handle, key)


def list_all(handle, key):
    """la lista entera («Ver más» de la fila)"""
    from ker0n3 import lists
    lists.directory(handle, key, whole=True)


def list_rest(handle, key, shown):
    """«Ver más» de una fila: solo lo que viene tras los `shown` títulos que ya enseña"""
    from ker0n3 import lists
    lists.directory(handle, key, rest=int(shown))


def list_page(handle, key, n):
    """«Ver más» al final de la cuadrícula: los 60 títulos siguientes de la lista, comprobados ahora"""
    from ker0n3 import lists
    lists.page_directory(handle, key, int(n))


def cards_row(handle, group):
    """fila de tarjetas de una sección (cards.directory): sagas, géneros, años"""
    from ker0n3 import cards
    cards.directory(handle, group)


def cards_all(handle, group):
    """todas las tarjetas del grupo («Más…» de la fila)"""
    from ker0n3 import cards
    cards.directory(handle, group, whole=True)


def no_version(handle, tipo, tmdb):
    """la skin, al reproducir: ninguna versión de la película pasó las reglas → «sin versión» ya, y sus filas al día"""
    try:
        from ker0n3 import lists
        lists.no_version("movie", int(tmdb))
        lists.flush_default()
    except Exception as e:  # noqa: BLE001
        log("nover %s: %r" % (tmdb, e))


def no_episode(handle, tmdb, season, episode):
    """la skin, al reproducir: ninguna versión del capítulo → «Aún no disponible» unas horas (series.unavailable), y
    la ficha de la serie, si está abierta, repinta su lista (flix_eps_refresh, como tras una marca del menú)"""
    try:
        from ker0n3 import series
        series.mark_unavailable(tmdb, season, episode)
        catalog.flush_default()
        import xbmcgui
        home = xbmcgui.Window(10000)
        if home.getProperty("flix_sheet"):
            home.setProperty("flix_eps_refresh", "0,0")
    except Exception as e:  # noqa: BLE001
        log("nover capítulo %s %sx%s: %r" % (tmdb, season, episode, e))


def mark(handle, op, tipo, tmdb, season=None, episode=None):
    """menú de pulsación larga de la skin: vista / no vista, quitar la pausa, dejar de seguir (marks.run)"""
    from ker0n3 import marks
    marks.run(op, tipo, tmdb, season, episode)


def mark_for_skin(op, tipo, tmdb, season=None, episode=None):
    """22-nov (Carlos: «marcas casi al momento»): la misma marca que la ruta marcar/… (marks.run: base, cola del
    servicio, k3_mark_done y repintado), pero llamada DENTRO del proceso de la skin, sin arrancar el intérprete del
    addon con RunPlugin. La caché de fichas se relee si otro proceso la cambió y se guarda al acabar (marcar una serie
    entera puede pedir su ficha). Devuelve «ok», «igual» o «error»"""
    from ker0n3 import marks
    catalog.default_cache().reload_if_changed(min_age=SKIN_CACHE_AGE)
    try:
        return marks.run(op, tipo, tmdb, season, episode)
    finally:
        catalog.flush_default()


def _account(fn):
    """un menú de cuenta abierto desde la pantalla Cuentas de la skin: mientras dura, Window(10000).k3_cuentas_run
    (la pantalla espera y, al acabar, pone al día los estados: flix_editor_sources.AccountsSource)"""
    home = None
    try:
        import xbmcgui
        from ker0n3 import cuentas
        home = xbmcgui.Window(10000)
        home.setProperty(cuentas.RUNNING, "1")
    except Exception:  # noqa: BLE001
        home = None
    try:
        fn()
    finally:
        if home is not None:
            from ker0n3 import cuentas
            home.clearProperty(cuentas.RUNNING)


def simkl_menu(handle):
    """Ajustes → «Simkl» (RunPlugin): vincular, sincronizar ahora o desvincular (link.menu)"""
    from ker0n3 import link
    _account(lambda: link.menu(handle))


def trakt_menu(handle):
    """Cuentas → «Trakt» (RunPlugin): vincular con código, sincronizar ahora, comprobar o desvincular (link.menu)"""
    from ker0n3 import link
    _account(lambda: link.menu(handle, service="trakt"))


def alldebrid_menu(handle):
    """Cuentas → «AllDebrid» (RunPlugin): vincular con código, comprobar o desvincular (adlink.menu)"""
    from ker0n3 import adlink
    _account(lambda: adlink.menu(handle))


def cuentas_menu(handle):
    """Ajustes → «Cuentas» (RunPlugin): AllDebrid, Trakt y Simkl con su estado (cuentas.menu)"""
    from ker0n3 import cuentas
    cuentas.menu(handle)


def root(handle):
    _end(handle, "", ok=True)


HANDLERS = {"search": search, "seasons": seasons, "episodes": episodes, "play_movie": play_movie,
            "play_episode": play_episode, "info_movie": info_movie, "root": root,
            "simkl": simkl_menu, "trakt": trakt_menu, "alldebrid": alldebrid_menu, "cuentas": cuentas_menu, "resume": resume, "follow": follow,
            "list": list_row, "list_all": list_all, "list_rest": list_rest, "list_page": list_page, "mark": mark, "no_version": no_version,
            "no_episode": no_episode, "favorites": favorites, "similar": similar, "cards": cards_row,
            "cards_all": cards_all}
