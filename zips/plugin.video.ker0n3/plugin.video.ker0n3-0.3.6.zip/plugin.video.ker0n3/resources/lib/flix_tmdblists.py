"""Listas de TMDB (tendencias, populares, por plataforma en España, por género, de las secciones…): qué son y cómo se
piden. Lógica sin xbmc, compartida con el addon Ker0n3 (tools/build_addon.py, SHARED): el addon las sirve por la ruta
lista/<clave> (fetch_entries) con su regla de lo que se enseña (solo lo que tiene versión para ver).

En la configuración del Inicio y de las secciones una lista se guarda como flix://tmdb/<clave> (editor: «Añadir fila» →
«Listas de TMDB»); flix_rows la pide como lista/<clave> del addon. Carlos, 23-oct."""
import json
import os
import re
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import TMDB_KEY  # noqa: E402

PREFIX = "flix://tmdb/"
API = "https://api.themoviedb.org/3/"
TTL = 6 * 3600
ERR_TTL = 600
PAGES = 3                   # 60 títulos de TMDB: la regla de lo que se enseña deja la mitad o más
TIMEOUT = 8
PROVIDERS = (("netflix", "Netflix", "8"), ("prime", "Prime Video", "119"), ("disney", "Disney+", "337"),
             ("max", "HBO Max", "1899"), ("apple", "Apple TV+", "350"), ("movistar", "Movistar Plus+", "2241|149"),
             ("skyshowtime", "SkyShowtime", "1773"), ("filmin", "Filmin", "63"))

# clave: (nombre en el editor, movie|tv, endpoint, parámetros extra)
LISTS = [
    ("tendencias-series-semana", "Tendencias de la semana · Series", "tv", "trending/tv/week", {}),
    ("tendencias-pelis-semana", "Tendencias de la semana · Películas", "movie", "trending/movie/week", {}),
    ("tendencias-series-hoy", "Tendencias de hoy · Series", "tv", "trending/tv/day", {}),
    ("tendencias-pelis-hoy", "Tendencias de hoy · Películas", "movie", "trending/movie/day", {}),
    ("populares-series", "Populares · Series", "tv", "tv/popular", {"region": "ES"}),
    ("populares-pelis", "Populares · Películas", "movie", "movie/popular", {"region": "ES"}),
    ("valoradas-series", "Mejor valoradas · Series", "tv", "tv/top_rated", {}),
    ("valoradas-pelis", "Mejor valoradas · Películas", "movie", "movie/top_rated", {}),
    ("emision-series", "Series en emisión", "tv", "tv/on_the_air", {}),
    ("cines-pelis", "En cines ahora", "movie", "movie/now_playing", {"region": "ES"}),
] + [
    ("%s-%s" % (key, k), "Populares en %s · %s" % (name, lab), kind, "discover/" + kind,
     {"watch_region": "ES", "with_watch_providers": pid, "sort_by": "popularity.desc"})
    for key, name, pid in PROVIDERS for k, lab, kind in (("series", "Series", "tv"), ("pelis", "Películas", "movie"))
]
# géneros de TMDB (ids de /genre/movie/list y /genre/tv/list; las series no tienen Suspense ni Terror). Populares
# del género con un mínimo de votos: sin él salían títulos desconocidos (Carlos, 23-oct)
GENRES = {
    "movie": (("accion", "Acción", "28"), ("aventura", "Aventura", "12"), ("animacion", "Animación", "16"),
              ("comedia", "Comedia", "35"), ("crimen", "Crimen", "80"), ("documental", "Documental", "99"),
              ("drama", "Drama", "18"), ("familia", "Familia", "10751"), ("fantasia", "Fantasía", "14"),
              ("historia", "Historia", "36"), ("terror", "Terror", "27"), ("musica", "Música", "10402"),
              ("misterio", "Misterio", "9648"), ("romance", "Romance", "10749"),
              ("ciencia-ficcion", "Ciencia ficción", "878"), ("suspense", "Suspense", "53"),
              ("belica", "Bélica", "10752"), ("western", "Western", "37")),
    "tv": (("accion", "Acción y aventura", "10759"), ("animacion", "Animación", "16"), ("comedia", "Comedia", "35"),
           ("crimen", "Crimen", "80"), ("documental", "Documental", "99"), ("drama", "Drama", "18"),
           ("familia", "Familia", "10751"), ("infantil", "Infantil", "10762"), ("misterio", "Misterio", "9648"),
           ("ciencia-ficcion", "Ciencia ficción y fantasía", "10765"), ("belica", "Bélica y política", "10768"),
           ("western", "Western", "37")),       # Reality fuera: apenas había versiones (6 de 60, 23-oct)
}
MIN_VOTES = {"movie": "200", "tv": "50"}
GENRE_LISTS = [
    ("genero-%s-%s" % (k, slug), "%s · %s" % (name, lab), kind, "discover/" + kind,
     {"with_genres": gid, "sort_by": "popularity.desc", "vote_count.gte": MIN_VOTES[kind]})
    for k, lab, kind in (("pelis", "Películas", "movie"), ("series", "Series", "tv")) for slug, name, gid in GENRES[kind]
]
LISTS += GENRE_LISTS
# Niños y adolescentes (Carlos, 30-oct; comprobado: de 60, entre 39 y 60 con versión en todas). Edad en
# España: niños «A»/7; adolescentes 12, sin terror, thriller ni crimen. Las series infantiles, con el género Infantil
_KIDS_M = {"certification_country": "ES", "certification.lte": "7", "sort_by": "popularity.desc"}
_TEEN_M = {"certification_country": "ES", "certification": "12", "without_genres": "27,53,80",
           "sort_by": "popularity.desc"}
_KIDS_T = {"with_genres": "10762", "sort_by": "popularity.desc"}
_TEEN_T = {"certification_country": "ES", "certification": "12", "without_genres": "10762,80",
           "sort_by": "popularity.desc"}
_FAM = "16|10751"                                                     # animación o familia
_NEW = {"primary_release_date.gte": "%d-01-01" % (int(time.strftime("%Y")) - 2)}
_ES = {"watch_region": "ES"}


def _m(base, **kw):
    out = dict(base)
    out.update(kw)
    return out


KIDS_LISTS = [
    ("ninos-pelis-populares", "Niños · Películas populares", "movie", "discover/movie", _m(_KIDS_M, with_genres=_FAM)),
    ("ninos-pelis-valoradas", "Niños · Películas mejor valoradas", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, sort_by="vote_average.desc", **{"vote_count.gte": "500"})),
    ("ninos-pelis-novedades", "Niños · Películas nuevas", "movie", "discover/movie", _m(_KIDS_M, with_genres=_FAM, **_NEW)),
    ("ninos-pelis-clasicos", "Niños · Clásicos", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, **{"primary_release_date.lte": "2004-12-31", "vote_count.gte": "300"})),
    ("ninos-pelis-animacion", "Niños · Películas de animación", "movie", "discover/movie", _m(_KIDS_M, with_genres="16")),
    ("ninos-pelis-aventura", "Niños · Aventuras en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="12,10751")),
    ("ninos-pelis-comedia", "Niños · Comedias en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="35,10751")),
    ("ninos-pelis-fantasia", "Niños · Fantasía en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="14,10751")),
    ("ninos-pelis-disney", "Niños · Películas en Disney+", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="337", **_ES)),
    ("ninos-pelis-netflix", "Niños · Películas en Netflix", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="8", **_ES)),
    ("ninos-pelis-prime", "Niños · Películas en Prime Video", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="119", **_ES)),
    ("ninos-series-populares", "Niños · Series populares", "tv", "discover/tv", _m(_KIDS_T)),
    ("ninos-series-valoradas", "Niños · Series mejor valoradas", "tv", "discover/tv",
     _m(_KIDS_T, sort_by="vote_average.desc", **{"vote_count.gte": "50"})),
    ("ninos-series-animacion", "Niños · Series de animación", "tv", "discover/tv", _m(_KIDS_T, with_genres="10762,16")),
    ("ninos-series-disney", "Niños · Series en Disney+", "tv", "discover/tv", _m(_KIDS_T, with_watch_providers="337", **_ES)),
    ("ninos-series-netflix", "Niños · Series en Netflix", "tv", "discover/tv", _m(_KIDS_T, with_watch_providers="8", **_ES)),
    ("ninos-anime", "Niños · Anime", "tv", "discover/tv",
     {"with_genres": "16", "with_origin_country": "JP", "certification_country": "ES", "certification.lte": "7",
      "sort_by": "popularity.desc"}),
]
TEEN_LISTS = [
    ("teen-pelis-populares", "Adolescentes · Películas populares", "movie", "discover/movie", _m(_TEEN_M)),
    ("teen-pelis-valoradas", "Adolescentes · Películas mejor valoradas", "movie", "discover/movie",
     _m(_TEEN_M, sort_by="vote_average.desc", **{"vote_count.gte": "1000"})),
    ("teen-pelis-novedades", "Adolescentes · Películas nuevas", "movie", "discover/movie", _m(_TEEN_M, **_NEW)),
    ("teen-pelis-accion", "Adolescentes · Acción y aventura", "movie", "discover/movie", _m(_TEEN_M, with_genres="28|12")),
    ("teen-pelis-scifi", "Adolescentes · Ciencia ficción y fantasía", "movie", "discover/movie",
     _m(_TEEN_M, with_genres="878|14")),
    ("teen-pelis-comedia", "Adolescentes · Comedias", "movie", "discover/movie", _m(_TEEN_M, with_genres="35")),
    ("teen-pelis-netflix", "Adolescentes · Películas en Netflix", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="8", **_ES)),
    ("teen-pelis-disney", "Adolescentes · Películas en Disney+", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="337", **_ES)),
    ("teen-pelis-prime", "Adolescentes · Películas en Prime Video", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="119", **_ES)),
    ("teen-pelis-anime", "Adolescentes · Películas anime", "movie", "discover/movie",
     _m(_TEEN_M, with_genres="16", with_origin_country="JP")),
    ("teen-series-populares", "Adolescentes · Series populares", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10759|10765|16|35")),
    ("teen-series-scifi", "Adolescentes · Series de ciencia ficción y fantasía", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10765")),
    ("teen-series-comedia", "Adolescentes · Series de comedia", "tv", "discover/tv", _m(_TEEN_T, with_genres="35")),
    ("teen-series-accion", "Adolescentes · Series de acción y aventura", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10759")),
    ("teen-series-anime", "Adolescentes · Series anime", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="16", with_origin_country="JP")),
]
LISTS += KIDS_LISTS + TEEN_LISTS
# Top 10 y más vistas del mes (15-nov): de los ficheros públicos de tendencias de Simkl («ordenados por número de
# espectadores»; sin clave ni cuenta, no gastan cupo). El endpoint de TMDB de cada lista es la reserva si Simkl no
# responde. Van al final de LISTS y fuera de GROUPS: no son para el editor ni para las filas al azar (son filas de
# serie del Inicio)
SIMKL_CDN = "https://data.simkl.in/discover/trending/"
SIMKL_MAX = 60
SIMKL_LISTS = [
    ("top10-pelis", "Top 10 películas", "movie", "trending/movie/week", {}),
    ("top10-series", "Top 10 series", "tv", "trending/tv/week", {}),
    ("masvistas-pelis-mes", "Películas más vistas este mes", "movie", "trending/movie/week", {}),
    ("masvistas-series-mes", "Series más vistas este mes", "tv", "trending/tv/week", {}),
]
SIMKL = {"top10-pelis": "movies/week_100.json", "top10-series": "tv/week_100.json",
         "masvistas-pelis-mes": "movies/month_100.json", "masvistas-series-mes": "tv/month_100.json"}
# «Recomendadas» sin Trakt: recomendaciones de TMDB de lo último que se ha visto en este aparato (last_watched); el
# endpoint de la lista (populares) es lo que sale si aún no se ha visto nada
RECOMMENDED_LISTS = [
    ("recomendadas-pelis", "Películas recomendadas", "movie", "movie/popular", {"region": "ES"}),
    ("recomendadas-series", "Series recomendadas", "tv", "tv/popular", {"region": "ES"}),
]
RECOMMENDED = {"recomendadas-pelis": "movie", "recomendadas-series": "tv"}
RECOMMENDED_SEEDS = 3       # cuántos de los últimos vistos se usan
WATCHED_DB = None           # ruta de watched.db; None = la de la skin (las pruebas ponen la suya)
# Bloque 2 (16-nov): las filas de serie del Inicio (Novedades, Nuevas series, Series actualizadas, Anime, Dibujos,
# Documentales). Fechas relativas a hoy: «{hoy}» y «{hoy-N}» (N días)
# se resuelven al pedir la lista (dated). Al final de LISTS y fuera de GROUPS, como las de Simkl: ni el editor ni el
# sorteo cambian
_NO_TV = "10763,10764,10766,10767"          # noticias, reality, telenovelas y tertulias
_POP = "popularity.desc"
_3Y = {"primary_release_date.gte": "{hoy-1095}", "primary_release_date.lte": "{hoy}", "sort_by": _POP}
OWN_LISTS = [
    ("novedades-pelis", "Novedades", "movie", "discover/movie",
     {"region": "ES", "with_release_type": "4|5", "release_date.gte": "{hoy-120}", "release_date.lte": "{hoy}",
      "sort_by": _POP, "vote_count.gte": "20"}),
    ("nuevas-series", "Nuevas series", "tv", "discover/tv",
     {"first_air_date.gte": "{hoy-180}", "first_air_date.lte": "{hoy}", "sort_by": _POP, "vote_count.gte": "10",
      "without_genres": _NO_TV}),
    ("actualizadas-series", "Series actualizadas", "tv", "discover/tv",
     {"air_date.gte": "{hoy-7}", "air_date.lte": "{hoy}", "sort_by": _POP, "vote_count.gte": "50",
      "without_genres": _NO_TV}),
    ("anime-pelis", "Anime", "movie", "discover/movie",
     _m(_3Y, with_genres="16", with_original_language="ja", **{"vote_count.gte": "20"})),
    ("anime-series", "Anime · Series", "tv", "discover/tv",
     {"with_genres": "16", "with_origin_country": "JP", "sort_by": _POP, "vote_count.gte": "20"}),
    ("dibujos-pelis", "Dibujos", "movie", "discover/movie", _m(_3Y, with_genres="16,10751", **{"vote_count.gte": "20"})),
    ("dibujos-series", "Dibujos · Series", "tv", "discover/tv",
     {"with_genres": "16,10762", "sort_by": _POP, "vote_count.gte": "20"}),
    ("documentales-pelis", "Documentales", "movie", "discover/movie", _m(_3Y, with_genres="99", **{"vote_count.gte": "10"})),
    ("documentales-series", "Documentales · Series", "tv", "discover/tv",
     {"with_genres": "99", "sort_by": _POP, "vote_count.gte": "10"}),
]
OWN = {x[0] for x in OWN_LISTS}
# Bloques 4 y 5 (17-nov): las filas de las secciones («Últimas
# añadidas», «Clásicas», «Reality», series de Dibujos / Anime / Documentales, Telenovelas, Música, «Nuestra
# selección»). Como las de arriba: al final de LISTS, fuera de GROUPS y en OWN (ni el editor ni el sorteo cambian).
# Sin «Especiales» (Carlos, 17-nov: fuera)
_LAST_M = {"primary_release_date.lte": "{hoy}", "sort_by": "primary_release_date.desc", "vote_count.gte": "10"}
_CATS = {"anime": ({"with_genres": "16", "with_original_language": "ja"}, {"with_genres": "16", "with_origin_country": "JP"}),
         "dibujos": ({"with_genres": "16,10751"}, {"with_genres": "16,10762"}),
         "documentales": ({"with_genres": "99"}, {"with_genres": "99"})}
_CAT_NAMES = {"anime": "Anime", "dibujos": "Dibujos", "documentales": "Documentales"}
SECTION_LISTS = [
    ("ultimas-pelis", "Últimas añadidas", "movie", "discover/movie",
     {"region": "ES", "with_release_type": "4|5", "release_date.gte": "{hoy-120}", "release_date.lte": "{hoy}",
      "sort_by": "release_date.desc", "vote_count.gte": "20"}),
    ("clasicas-series", "Clásicas", "tv", "discover/tv",
     {"first_air_date.lte": "1999-12-31", "sort_by": "vote_count.desc", "vote_count.gte": "200", "without_genres": _NO_TV}),
    ("reality-series", "Reality", "tv", "discover/tv",
     {"with_genres": "10764", "with_original_language": "es|en", "sort_by": _POP, "vote_count.gte": "5"}),
    ("telenovelas-series-actualizadas", "Telenovelas · Últimas actualizaciones", "tv", "discover/tv",
     {"with_genres": "10766", "with_original_language": "es|tr", "air_date.gte": "{hoy-14}", "air_date.lte": "{hoy}",
      "sort_by": _POP}),
    ("telenovelas-series-nuevas", "Telenovelas · Nuevas", "tv", "discover/tv",
     {"with_genres": "10766", "with_original_language": "es|tr", "first_air_date.gte": "{hoy-365}",
      "first_air_date.lte": "{hoy}", "sort_by": _POP}),
    ("musica-pelis", "Música", "movie", "discover/movie", _m(_3Y, with_genres="10402", **{"vote_count.gte": "10"})),
    ("musica-pelis-ultimas", "Música · Últimas", "movie", "discover/movie", _m(_LAST_M, with_genres="10402")),
    ("historia-real-pelis", "Basado en hechos reales", "movie", "discover/movie",
     {"with_keywords": "9672", "sort_by": _POP, "vote_count.gte": "200"}),
]
for _c, (_mb, _tb) in _CATS.items():
    SECTION_LISTS += [
        ("%s-pelis-ultimas" % _c, "%s · Últimas añadidas" % _CAT_NAMES[_c], "movie", "discover/movie", _m(_LAST_M, **_mb)),
        ("%s-series-actualizadas" % _c, "%s · Series actualizadas" % _CAT_NAMES[_c], "tv", "discover/tv",
         _m(_tb, **{"air_date.gte": "{hoy-14}", "air_date.lte": "{hoy}", "sort_by": _POP})),
        ("%s-series-nuevas" % _c, "%s · Nuevas series" % _CAT_NAMES[_c], "tv", "discover/tv",
         _m(_tb, **{"first_air_date.gte": "{hoy-365}", "first_air_date.lte": "{hoy}", "sort_by": _POP,
                    "vote_count.gte": "5"})),
    ]
OWN |= {x[0] for x in SECTION_LISTS}
LISTS += SIMKL_LISTS + RECOMMENDED_LISTS + OWN_LISTS + SECTION_LISTS
BY_KEY = {k: (label, kind, ep, extra) for k, label, kind, ep, extra in LISTS}
# claves con parámetro (bloques 4 y 5): saga = colección de TMDB; año, década o «antes de» un año
_COL_KEY = re.compile(r"^col-(\d{1,9})$")
_YEAR_KEY = re.compile(r"^(anio|decada|antes)-(pelis|series)-(\d{4})$")
_YEAR_VOTES = {"movie": "50", "tv": "20"}
# «Títulos de X» (flix_info.person_rows): dónde sale una persona o lo que ha dirigido o creado (limpieza, bloque 7)
_PERSON_KEY = re.compile(r"^persona-(pelis|series)-(\d{1,9})$")
PERSON_JOBS = ("Director", "Creator")            # = flix_info.DIRECTING
PERSON_SKIP_TV = {10763, 10767}                  # noticias y entrevistas: ahí sale «como él mismo» (flix_info)
PERSON_MAX = 60                                  # lo de una lista de PAGES páginas


def spec(key):
    """(nombre, tipo, endpoint, parámetros) de una lista: las de BY_KEY y las de parámetro; None si no es una"""
    key = str(key or "")
    if key in BY_KEY:
        return BY_KEY[key]
    m = _COL_KEY.match(key)
    if m:
        return ("Saga", "movie", "collection/%s" % m.group(1), {})
    m = _PERSON_KEY.match(key)
    if m:
        kind = "movie" if m.group(1) == "pelis" else "tv"
        return ("Películas" if kind == "movie" else "Series", kind,
                "person/%s/%s_credits" % (m.group(2), kind), {})
    m = _YEAR_KEY.match(key)
    if not m:
        return None
    what, kind, year = m.group(1), "movie" if m.group(2) == "pelis" else "tv", int(m.group(3))
    if not 1900 <= year <= 2100 or (what == "decada" and year % 10):
        return None
    field = "primary_release_date" if kind == "movie" else "first_air_date"
    extra = {"sort_by": _POP, "vote_count.gte": _YEAR_VOTES[kind]}
    if what == "antes":
        extra[field + ".lte"] = "%d-12-31" % (year - 1)
        label = "Antes de %d" % year
    else:
        last = year if what == "anio" else year + 9
        extra.update({field + ".gte": "%d-01-01" % year, field + ".lte": "%d-12-31" % last})
        label = str(year) if what == "anio" else "%d-%d" % (year, last)
    return (label, kind, "discover/" + kind, extra)
# apartados del editor («Añadir fila» → «Listas de TMDB…» → apartado → lista)
GROUPS = [
    ("Tendencias y populares", [x[0] for x in LISTS[:10]]),
    ("Por plataforma", [x[0] for x in LISTS[10:10 + 2 * len(PROVIDERS)]]),
    ("Por género · Películas", [x[0] for x in GENRE_LISTS if x[2] == "movie"]),
    ("Por género · Series", [x[0] for x in GENRE_LISTS if x[2] == "tv"]),
    ("Niños", [x[0] for x in KIDS_LISTS]),
    ("Adolescentes", [x[0] for x in TEEN_LISTS]),
]

def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_tmdblists] %s" % msg, xbmc.LOGINFO)
    except ImportError:
        pass


def is_list(path):
    return str(path or "").startswith(PREFIX)


def key_of(path):
    """clave de la lista de una ruta flix://tmdb/<clave>[&reload=…]; '' si no es una"""
    if not is_list(path):
        return ""
    return re.split(r"[&?]", path[len(PREFIX):], maxsplit=1)[0]


def path_of(key):
    return PREFIX + key


def label_of(path):
    return BY_KEY.get(key_of(path), ("",))[0]


_DATE_RE = re.compile(r"\{hoy(?:-(\d+))?\}")


def dated(extra, today=None):
    """los parámetros de una lista con sus fechas relativas resueltas: «{hoy}» y «{hoy-N}» → AAAA-MM-DD"""
    import datetime
    today = today or datetime.date.today()

    def sub(m):
        return (today - datetime.timedelta(days=int(m.group(1) or 0))).isoformat()
    return {k: _DATE_RE.sub(sub, v) if isinstance(v, str) else v for k, v in (extra or {}).items()}


def _results(ep, opener, pages=2, extra=None):
    """resultados (tal cual los da TMDB) de un endpoint, en es-ES, hasta pages páginas y sin repetir id.
    Excepción = red"""
    import urllib.request
    out, seen = [], set()
    for page in range(1, pages + 1):
        q = dict(dated(extra), api_key=TMDB_KEY, language="es-ES", page=page)
        req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q),
                                     headers={"User-Agent": "Ker0n3Media-skin"})
        with opener(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
        for x in data.get("results") or []:
            if isinstance(x, dict) and x.get("id") and x["id"] not in seen:
                seen.add(x["id"])
                out.append(x)
        if page >= (data.get("total_pages") or 1):
            break
    return out


def _pages(ep, opener, pages=2, extra=None):
    """ids de un endpoint de TMDB (es-ES), hasta pages páginas. Excepción = red"""
    return [x["id"] for x in _results(ep, opener, pages, extra)]


def _watched_db():
    if WATCHED_DB:
        return WATCHED_DB
    import flix_common
    return flix_common.watched_path()


def last_watched(kind, db_path=None, n=RECOMMENDED_SEEDS):
    """los n títulos (película o serie) tocados más recientemente según watched.db, el último primero.
    Sin base o ilegible: []"""
    import sqlite3
    db_path = db_path or _watched_db()
    if not os.path.exists(db_path):
        return []
    sql = ("SELECT tmdb_id FROM movies_watched ORDER BY lastPlayed DESC LIMIT ?" if kind == "movie" else
           "SELECT tmdb_id FROM episodes_watched GROUP BY tmdb_id ORDER BY MAX(lastPlayed) DESC LIMIT ?")
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=5)
        try:
            return [int(r[0]) for r in con.execute(sql, (n,))]
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("no leo lo último visto: %s" % e)
        return []


def _recommended(key, opener):
    """recomendaciones de TMDB de lo último visto, alternando una de cada título, sin repetir y sin lo ya visto ni
    los propios títulos de partida; sin nada visto (o sin resultados), el endpoint de la lista. Excepción = red"""
    label, kind, ep, extra = BY_KEY[key]
    db = _watched_db()
    seeds = last_watched(kind, db)
    pools = [_pages("%s/%d/recommendations" % (kind, s), opener, 1) for s in seeds]
    mixed = []
    for i in range(max([len(p) for p in pools] or [0])):
        for p in pools:
            if i < len(p) and p[i] not in mixed and p[i] not in seeds:
                mixed.append(p[i])
    seen = seen_ids(kind, mixed, db)
    mixed = [i for i in mixed if i not in seen]
    return mixed or _pages(ep, opener, PAGES, extra)


def _simkl_ids(path, opener):
    """ids de TMDB de un fichero de tendencias de Simkl, en su orden y sin repetidos. Excepción = red"""
    import urllib.request
    req = urllib.request.Request(SIMKL_CDN + path, headers={"User-Agent": "Ker0n3Media-skin"})
    with opener(req, timeout=TIMEOUT) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "[]")
    out = []
    for x in data if isinstance(data, list) else []:
        t = str(((x if isinstance(x, dict) else {}).get("ids") or {}).get("tmdb") or "")
        if t.isdigit() and int(t) not in out:
            out.append(int(t))
    return out[:SIMKL_MAX]


def fetch_ids(key, opener=None):
    """ids de TMDB de la lista (PAGES páginas). Las de Simkl, de su fichero; si no responde o viene sin títulos,
    de su endpoint de TMDB. Excepción = red."""
    import urllib.request
    opener = opener or urllib.request.urlopen
    label, kind, ep, extra = BY_KEY[key]
    if key in SIMKL:
        try:
            ids = _simkl_ids(SIMKL[key], opener)
            if ids:
                return ids
            log("Simkl sin títulos (%s): uso TMDB" % key)
        except Exception as e:  # noqa: BLE001
            log("Simkl no responde (%s): %s; uso TMDB" % (key, e))
    if key in RECOMMENDED:
        return _recommended(key, opener)
    return _pages(ep, opener, PAGES, extra)


def _entry(x, kind):
    """lo que una fila necesita de un resultado de lista de TMDB, sin más peticiones (las imágenes, como ruta de TMDB)"""
    date = str(x.get("release_date") or x.get("first_air_date") or "")
    return {"tmdb": int(x["id"]), "kind": kind, "title": x.get("title") or x.get("name") or "",
            "year": int(date[:4]) if date[:4].isdigit() else 0, "premiered": date, "plot": x.get("overview") or "",
            "poster": x.get("poster_path") or "", "fanart": x.get("backdrop_path") or "",
            "rating": float(x.get("vote_average") or 0)}


def fetch_entries(key, opener=None, pages=None):
    """la lista para Ker0n3 (bloque 2): [{tmdb, kind, título, año, sinopsis, carátula, fondo, nota}] en
    su orden. Las de Simkl y las recomendadas solo traen {tmdb, kind} (su ficha la pone el addon). Acepta las claves
    con parámetro (spec; bloques 4 y 5): una saga son sus partes por fecha de estreno; una persona, sus créditos
    (person_entries). pages: páginas de TMDB (de
    serie PAGES; la comprobación de una tarjeta pide 1). Excepción = red (KeyError si la clave no es de ninguna lista)"""
    import urllib.request
    opener = opener or urllib.request.urlopen
    sp = spec(key)
    if sp is None:
        raise KeyError(key)
    label, kind, ep, extra = sp
    if key in SIMKL or key in RECOMMENDED:
        return [{"tmdb": int(i), "kind": kind} for i in fetch_ids(key, opener)]
    if ep.startswith("collection/"):           # saga: sus partes, por fecha de estreno (las sin fecha, al final)
        parts = [x for x in _get(ep, opener).get("parts") or [] if isinstance(x, dict) and x.get("id")]
        return [_entry(x, "movie") for x in sorted(parts, key=lambda x: str(x.get("release_date") or "9999"))]
    if ep.startswith("person/"):
        return person_entries(_get(ep, opener), kind)
    return [_entry(x, kind) for x in _results(ep, opener, pages or PAGES, extra)]


def person_entries(data, kind):
    """títulos de los créditos de una persona (person/<id>/movie_credits o tv_credits): donde sale o lo que ha
    dirigido o creado, los más conocidos primero (votos), sin repetir y, en series, sin noticias ni entrevistas"""
    rows = [x for x in data.get("cast") or [] if isinstance(x, dict)]
    rows += [x for x in data.get("crew") or [] if isinstance(x, dict) and x.get("job") in PERSON_JOBS]
    best = {}
    for x in rows:
        if not x.get("id") or (kind == "tv" and PERSON_SKIP_TV & set(x.get("genre_ids") or [])):
            continue
        if x["id"] not in best or (x.get("vote_count") or 0) > (best[x["id"]].get("vote_count") or 0):
            best[x["id"]] = x
    picked = sorted(best.values(), key=lambda x: -(x.get("vote_count") or 0))[:PERSON_MAX]
    return [_entry(x, kind) for x in picked]


ANIMATION = 16              # género «Animación» (pelis y series)
KIDS = {"movie": 10751, "tv": 10762}            # «Familia» / «Kids»
MIN_VOTES = {"movie": 40, "tv": 15}             # por debajo, relleno desconocido (8-nov): fuera


def _get(ep, opener, extra=None):
    """JSON de un endpoint de TMDB (es-ES). Excepción = red"""
    import urllib.request
    q = dict(extra or {}, api_key=TMDB_KEY, language="es-ES")
    req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q), headers={"User-Agent": "Ker0n3Media-skin"})
    with opener(req, timeout=TIMEOUT) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    return data if isinstance(data, dict) else {}


def _year(x):
    d = str(x.get("release_date") or x.get("first_air_date") or "")
    return int(d[:4]) if d[:4].isdigit() else None


def _genres(x):
    return {g["id"] if isinstance(g, dict) else g for g in (x.get("genres") or x.get("genre_ids") or [])}


def score(src, cand, rank, kind):
    """parecido de un candidato al título (Carlos, 8-nov: «mejorar los similares»), con lo que TMDB ya da en la
    respuesta (sin más peticiones). rank: (lista, posición, largo) — recomendaciones pesan más que «parecidas».
    None = fuera: muy pocos votos o infantil con un original que no lo es"""
    if int(cand.get("vote_count") or 0) < MIN_VOTES[kind]:
        return None
    g, c = _genres(src), _genres(cand)
    kids = KIDS[kind]
    if kids in c and kids not in g:
        return None
    sc = 3.0 * (len(g & c) / len(g | c) if g | c else 0)
    if (ANIMATION in g) != (ANIMATION in c):
        sc -= 4.0                                   # dibujos con imagen real (y al revés): al final
    lang = src.get("original_language")
    if lang and cand.get("original_language") == lang:
        sc += 0.6 if lang == "en" else 1.5          # anime con anime, coreanas con coreanas…
    ys, yc = _year(src), _year(cand)
    if ys and yc:
        sc += 1.0 - min(abs(ys - yc), 30) / 30.0
    va = float(cand.get("vote_average") or 0)
    sc += max(-1.0, min(1.0, (va - 6.5) / 2.0))
    sc += min(1.0, len(str(int(cand.get("vote_count") or 0))) / 5.0) * 0.5     # ~log10: más votado, más fiable
    lst, pos, n = rank
    sc += (1.5 if lst == "rec" else 0.5) * (1.0 - pos / float(max(n, 1)))
    return sc


def rank_similar(kind, src, pools, saga=()):
    """ids ordenados: la saga primero (por fecha), luego por parecido (score). pools: [(«rec»|«sim», resultados)]"""
    me = src.get("id")
    best = {}
    for lst, res in pools:
        for pos, x in enumerate(res):
            i = x.get("id")
            if not i or i == me:
                continue
            sc = score(src, x, (lst, pos, len(res)), kind)
            if sc is not None and (i not in best or sc > best[i]):
                best[i] = sc
    saga_ids = [x["id"] for x in sorted(saga, key=lambda x: str(x.get("release_date") or "9999"))
                if x.get("id") and x["id"] != me]
    return saga_ids + [i for i, _ in sorted(best.items(), key=lambda kv: -kv[1]) if i not in saga_ids]


def seen_ids(kind, ids, db_path=None):
    """de esos ids, los que ya has visto según la base (película con playcount; serie completa o con todos sus
    capítulos vistos). Sin base o ilegible: ninguno"""
    if not ids:
        return set()
    try:
        import flix_common
        if db_path is None:
            db_path = flix_common.watched_path()
        marks = ",".join(str(int(i)) for i in ids)
        if kind == "movie":
            sql = "SELECT tmdb_id FROM movies_watched WHERE playcount > 0 AND tmdb_id IN (%s)" % marks
        else:
            sql = ("SELECT s.tmdb_id FROM shows_watched s WHERE s.tmdb_id IN (%s) AND (s.completa OR "
                   "(s.num_total_episodios > 0 AND s.num_total_episodios <= (SELECT COUNT(*) FROM episodes_watched e "
                   "WHERE e.tmdb_id = s.tmdb_id AND e.playcount > 0)))" % marks)
        rows = flix_common.watched_query(db_path, sql)
    except Exception as e:  # noqa: BLE001
        log("no leo lo visto: %s" % e)
        return set()
    return {int(r[0]) for r in rows or []}
