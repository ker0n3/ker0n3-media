"""Rutas del addon Ker0n3 (parte 2b+2c; 15-nov). Diseño:
docs/superpowers/specs/2026-11-15-catalogo-fichas-buscador-design.md"""
import re
import urllib.parse

ROOT = "plugin://plugin.video.ker0n3"


def _q(text):
    return urllib.parse.quote(str(text), safe="")


def url_search(kind, text):
    return "%s/buscar/%s/%s" % (ROOT, kind, _q(text))


def url_show(tmdb):
    return "%s/serie/%s" % (ROOT, tmdb)


def url_season(tmdb, season):
    return "%s/serie/%s/%s" % (ROOT, tmdb, season)


def url_play_movie(tmdb):
    return "%s/play/pelicula/%s" % (ROOT, tmdb)


def url_play_episode(tmdb, season, episode):
    return "%s/play/capitulo/%s/%s/%s" % (ROOT, tmdb, season, episode)


def url_info_movie(tmdb):
    return "%s/info/pelicula/%s" % (ROOT, tmdb)


def url_simkl():
    return "%s/simkl" % ROOT


def url_resume():
    return "%s/seguir" % ROOT


def url_follow():
    return "%s/siguiendo" % ROOT


def url_list(key, whole=False):
    """fila de una lista del Inicio (clave de flix_tmdblists); whole: la lista entera («Ver más»)"""
    return "%s/lista/%s%s" % (ROOT, _q(key), "/todo" if whole else "")


def url_favorites(tipo, whole=False):
    """fila de favoritos (peliculas / series); whole: todos («Ver más» de la sección Favoritos)"""
    return "%s/favoritos/%s%s" % (ROOT, tipo, "/todo" if whole else "")


def url_cards(group, whole=False):
    """fila de tarjetas de una sección (sagas, géneros, años: cards.directory); whole: todas («Más…»)"""
    return "%s/tarjetas/%s%s" % (ROOT, _q(group), "/todo" if whole else "")


def url_list_rest(key, shown):
    """lo que viene tras los `shown` primeros títulos de la lista («Ver más» de una fila: solo el resto)"""
    return "%s/lista/%s/resto/%d" % (ROOT, _q(key), int(shown))


def url_alldebrid():
    return "%s/alldebrid" % ROOT


def url_trakt():
    return "%s/trakt" % ROOT


def url_cuentas():
    return "%s/cuentas" % ROOT


def parse(url):
    """(nombre de ruta, argumentos). Sin el «&reload=<ms>» que la skin añade para que Kodi vuelva a pedir una carpeta
    (flix_series_sheet.reload_series y demás; un «&» del texto buscado llega codificado: %26)"""
    rest = re.sub(r"&reload=\d+$", "", url.split("?")[0])
    if rest.startswith(ROOT):
        rest = rest[len(ROOT):]
    parts = [urllib.parse.unquote(p) for p in rest.strip("/").split("/") if p]
    if not parts:
        return "root", []
    head = parts[0]
    if head == "buscar" and len(parts) == 3:
        return "search", parts[1:]
    if head == "serie" and len(parts) == 2:
        return "seasons", parts[1:]
    if head == "serie" and len(parts) == 3:
        return "episodes", parts[1:]
    if head == "play" and len(parts) == 3 and parts[1] == "pelicula":
        return "play_movie", parts[2:]
    if head == "play" and len(parts) == 5 and parts[1] == "capitulo":
        return "play_episode", parts[2:]
    if head == "info" and len(parts) == 3 and parts[1] == "pelicula":
        return "info_movie", parts[2:]
    if head in ("simkl", "trakt") and len(parts) == 1:
        return head, []
    if head in ("alldebrid", "cuentas") and len(parts) == 1:
        return head, []
    if head == "seguir" and len(parts) == 1:
        return "resume", []
    if head == "siguiendo" and len(parts) == 1:
        return "follow", []
    if head == "marcar" and len(parts) == 4 and parts[1] in ("favorita", "nofavorita") \
            and parts[2] in ("pelicula", "serie") and parts[3].isdigit():
        return "mark", parts[1:]        # corazón de las fichas y «Añadir / Quitar de favoritos» del menú
    if head == "similares" and len(parts) == 3 and parts[1] in ("pelicula", "serie") and parts[2].isdigit():
        return "similar", parts[1:]     # «Ver similares» (lists.similar)
    if head == "favoritos" and len(parts) == 2 and parts[1] in ("peliculas", "series"):
        return "favorites", parts[1:]   # filas de favoritos (personal.favorites)
    if head == "favoritos" and len(parts) == 3 and parts[1] in ("peliculas", "series") and parts[2] == "todo":
        return "favorites", parts[1:]   # todos («Ver más» de la sección Favoritos; bloques 4 y 5)
    if head == "marcar" and len(parts) in (4, 6) and parts[1] in ("vista", "novista", "sinpausa", "noseguir", "hasta") \
            and (len(parts) == 6) == (parts[2] == "capitulo") and parts[2] in ("pelicula", "serie", "capitulo") \
            and (parts[1] != "hasta" or parts[2] == "capitulo") and all(p.isdigit() for p in parts[3:]):
        return "mark", parts[1:]        # menú de pulsación larga de la skin (marks.py)
    if head == "nover" and len(parts) == 3 and parts[1] == "pelicula" and parts[2].isdigit():
        return "no_version", parts[1:]  # el reproductor de la skin: ninguna versión pasó las reglas (lists.no_version)
    if head == "nover" and len(parts) == 5 and parts[1] == "capitulo" and all(p.isdigit() for p in parts[2:]):
        return "no_episode", parts[2:]  # …o ninguna versión de ese capítulo (series.mark_unavailable)
    if head == "lista" and len(parts) == 2:
        return "list", parts[1:]
    if head == "tarjetas" and len(parts) == 2:
        return "cards", parts[1:]       # fila de tarjetas de una sección (cards.directory; bloques 4 y 5)
    if head == "tarjetas" and len(parts) == 3 and parts[2] == "todo":
        return "cards_all", parts[1:2]
    if head == "lista" and len(parts) == 3 and parts[2] == "todo":
        return "list_all", parts[1:2]
    if head == "lista" and len(parts) == 4 and parts[2] == "resto" and parts[3].isdigit():
        return "list_rest", [parts[1], parts[3]]
    return "unknown", parts


def run(argv, handlers=None):
    try:
        _run(argv, handlers)
    finally:
        from ker0n3 import catalog, lists
        catalog.flush_default()     # la caché de TMDB y de disponibilidad, una sola escritura por ruta
        lists.flush_default()       # y la de listas (lista/<clave>)


def _run(argv, handlers=None):
    if handlers is None:
        from ker0n3 import handlers as mod
        handlers = mod.HANDLERS
    handle = int(argv[1]) if len(argv) > 1 and str(argv[1]).lstrip("-").isdigit() else -1
    name, args = parse(argv[0])
    fn = handlers.get(name)
    if fn is None:
        import xbmcplugin
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    try:
        import xbmcgui
        import xbmcplugin
    except ImportError:     # fuera de Kodi (pruebas de solo despacho)
        fn(handle, *args)
        return
    done = []
    real_end, real_res = xbmcplugin.endOfDirectory, xbmcplugin.setResolvedUrl

    def end(*a, **k):
        done.append(1)
        return real_end(*a, **k)

    def res(*a, **k):
        done.append(1)
        return real_res(*a, **k)
    xbmcplugin.endOfDirectory, xbmcplugin.setResolvedUrl = end, res
    try:
        fn(handle, *args)
    except Exception as e:  # noqa: BLE001  (un fallo no deja a Kodi esperando)
        try:
            import xbmc
            xbmc.log("[ker0n3] %s falló: %r" % (name, e), xbmc.LOGERROR)
        except Exception:  # noqa: BLE001
            pass
        if not done:
            if name.startswith("play"):
                real_res(handle, False, xbmcgui.ListItem())
            else:
                real_end(handle, succeeded=False)
    finally:
        xbmcplugin.endOfDirectory, xbmcplugin.setResolvedUrl = real_end, real_res
