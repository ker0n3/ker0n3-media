"""Ajustes → «Cuentas» (16-nov): AllDebrid (para reproducir), Trakt o Simkl (lo visto: sincroniza
uno, syncsvc) y PeLis (fuente extra, opcional), cada una con su estado. Una sola fila en Ajustes: no cabe
otra (gen_settings.py). Elegir una abre lo suyo: adlink.menu / link.menu / flix_pelis.py de la skin
(ahí están el QR y la ventana de la explicación). De PeLis aquí solo se sabe si hay dirección guardada: la dirección
no se lee a ninguna variable de este módulo"""

PELIS_SCRIPT = "RunScript(special://skin/scripts/flix_pelis.py)"


def _pelis_linked():
    try:
        import flix_src_list
        return bool(flix_src_list.load_pelis_url())
    except Exception:  # noqa: BLE001
        return False


def sync_states(trakt_on, simkl_on, active, info):
    """(estado de Trakt, estado de Simkl): la cuenta o «Sin vincular»; con los dos vinculados, cuál sincroniza"""
    from ker0n3 import adlink, link
    out = []
    for name, on in (("trakt", trakt_on), ("simkl", simkl_on)):
        st = (info("Skin.String(%s)" % link.SERVICES[name]["user"]) or "tu cuenta") if on else adlink.NONE
        if on and trakt_on and simkl_on:
            st += " · en uso" if name == active else " · en pausa"
        out.append(st)
    return tuple(out)


def menu(handle=-1, ad_api=None, simkl_api=None, dialog=None, run=None, info=None, open_ad=None, open_simkl=None,
         pelis_linked=None, open_pelis=None, trakt_api=None, open_trakt=None, active=None):
    import xbmc
    import xbmcgui
    from ker0n3 import adlink, link
    if ad_api is None:
        import flix_alldebrid as ad_api
    if simkl_api is None:
        from ker0n3 import simkl as simkl_api
    if trakt_api is None:
        from ker0n3 import trakt as trakt_api
    if active is None:
        from ker0n3 import syncsvc
        active = syncsvc.active({"trakt": trakt_api, "simkl": simkl_api})
    dialog = dialog or xbmcgui.Dialog()
    run = run or xbmc.executebuiltin
    info = info or xbmc.getInfoLabel
    ad_state = adlink.refresh(ad_api, info("Skin.String(%s)" % adlink.USER), run)
    trakt_state, simkl_state = sync_states(trakt_api.linked(), simkl_api.linked(), active, info)
    pelis_state = adlink.LINKED if (pelis_linked or _pelis_linked)() else adlink.NONE
    pick = dialog.select("Cuentas", ["AllDebrid: %s" % ad_state, "Trakt: %s" % trakt_state, "Simkl: %s" % simkl_state,
                                     "PeLis (opcional): %s" % pelis_state])
    if pick == 0:
        (open_ad or adlink.menu)()
    elif pick == 1:
        (open_trakt or (lambda: link.menu(service="trakt")))()
    elif pick == 2:
        (open_simkl or link.menu)()
    elif pick == 3:
        if open_pelis:
            open_pelis()
        else:
            run(PELIS_SCRIPT)
