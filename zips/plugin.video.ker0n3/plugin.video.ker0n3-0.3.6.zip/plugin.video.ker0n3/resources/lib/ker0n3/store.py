"""Base de vistos de Ker0n3 (bloque 1; 15-nov). Diseño:
docs/superpowers/specs/2026-11-15-base-vistos-ker0n3-design.md.

Mismo formato que watched.db de Palantir 3.3.11 (la skin la lee con las mismas consultas), en addon_data de Ker0n3.
La primera vez se copia la de Palantir (historial completo). Reglas de Watched.scrobble de Palantir: con menos de 180 s
no se apunta; desde el 80 % es visto (playcount + 1, progreso 0); si no, progreso en % y duración en s.
Escrituras cortas, en una transacción, con reintento si la base está ocupada: nunca bloquean el reproductor."""
import os
import sqlite3
import time

MIN_SECONDS = 180
WATCHED_PCT = 80.0
RESUME_DAYS = 30        # «Seguir viendo»: lo tocado en los últimos 30 días (Palantir hideUnfinished; flix_progress.EP_DAYS)
BUSY_TRIES, BUSY_WAIT, BUSY_TIMEOUT = 5, 0.2, 1.0
_sleep = time.sleep
# esquema de Palantir 3.3.11 (iooOO0OO.connect), con sus dos disparadores; IF NOT EXISTS: la copiada ya los trae
SCHEMA = """
CREATE TABLE IF NOT EXISTS episodes_watched (tmdb_id INTEGER, season INTEGER NOT NULL DEFAULT 1,
  episode INTEGER NOT NULL DEFAULT 1, playcount INTEGER DEFAULT 0, progress DOUBLE, runtime INTEGER, lastPlayed TEXT,
  PRIMARY KEY (tmdb_id, season, episode));
CREATE TABLE IF NOT EXISTS movies_watched (tmdb_id INTEGER PRIMARY KEY, playcount INTEGER DEFAULT 0, progress DOUBLE,
  runtime INTEGER, lastPlayed TEXT);
CREATE TABLE IF NOT EXISTS favorites (tmdb_id INTEGER, content TEXT, PRIMARY KEY (tmdb_id, content));
CREATE TABLE IF NOT EXISTS shows_watched (tmdb_id INTEGER PRIMARY KEY, num_total_episodios INTEGER NOT NULL DEFAULT 0,
  completa INTEGER NOT NULL DEFAULT 0, ocultar INTEGER NOT NULL DEFAULT 0, actualizada INTEGER NOT NULL DEFAULT 0);
CREATE TRIGGER IF NOT EXISTS agregar_serie_si_no_existe AFTER INSERT ON episodes_watched BEGIN
  INSERT OR IGNORE INTO shows_watched (tmdb_id) SELECT NEW.tmdb_id
  WHERE NOT EXISTS (SELECT 1 FROM shows_watched WHERE tmdb_id = NEW.tmdb_id); END;
CREATE TRIGGER IF NOT EXISTS eliminar_serie_si_no_quedan_episodios AFTER DELETE ON episodes_watched BEGIN
  DELETE FROM shows_watched WHERE tmdb_id = OLD.tmdb_id
  AND NOT EXISTS (SELECT 1 FROM episodes_watched WHERE tmdb_id = OLD.tmdb_id); END;
"""
COLUMNS = {"movies_watched": {"tmdb_id", "playcount", "progress", "runtime", "lastPlayed"},
           "episodes_watched": {"tmdb_id", "season", "episode", "playcount", "progress", "runtime", "lastPlayed"},
           "shows_watched": {"tmdb_id", "num_total_episodios", "completa", "ocultar"},
           "favorites": {"tmdb_id", "content"}}


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.store] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def stamp(now=None):
    """hora en el formato de Palantir (UTC): «2026-11-15T21:00:00.000Z»"""
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(time.time() if now is None else now))


def path():
    import xbmcvfs
    import flix_common
    return xbmcvfs.translatePath(flix_common.K3_WATCHED_DB_REL)


# la base del addon viejo de este perfil: solo para la importación única (ensure), si el fichero está
OLD_DB_REL = "special://profile/addon_data/plugin.video.palantir3/watched.db"


def palantir_path():
    import xbmcvfs
    return xbmcvfs.translatePath(OLD_DB_REL)


def schema_ok(c):
    for table, cols in COLUMNS.items():
        have = {r[1] for r in c.execute("PRAGMA table_info(%s)" % table)}
        if not cols <= have:
            return False
    return True


def transaction(db_path, fn):
    """fn(conexión) en una transacción; con la base ocupada, hasta BUSY_TRIES intentos separados BUSY_WAIT s"""
    for i in range(BUSY_TRIES):
        c = sqlite3.connect(db_path, timeout=BUSY_TIMEOUT)
        try:
            with c:
                return fn(c)
        except sqlite3.OperationalError as e:
            if ("locked" not in str(e) and "busy" not in str(e)) or i == BUSY_TRIES - 1:
                raise
        finally:
            c.close()
        _sleep(BUSY_WAIT)


def _copy(src, dst):
    """copia coherente aunque Palantir esté escribiendo (API de copia de SQLite), a un temporal que luego se cambia"""
    tmp = dst + ".tmp"
    if os.path.exists(tmp):
        os.remove(tmp)
    s = sqlite3.connect("file:%s?mode=ro" % src, uri=True, timeout=5)
    try:
        d = sqlite3.connect(tmp)
        try:
            s.backup(d)
        finally:
            d.close()
    finally:
        s.close()
    os.replace(tmp, dst)


def ensure(db_path=None, palantir=None):
    """la base lista: 'ok' (ya estaba), 'imported' (copiada de la de Palantir) o 'created' (vacía). palantir=None: la
    de Palantir de este perfil; '' = no importar"""
    db_path = db_path or path()
    result = "ok"
    if not os.path.exists(db_path) or os.path.getsize(db_path) == 0:
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        src = palantir_path() if palantir is None else palantir
        result = "created"
        if src and os.path.exists(src) and os.path.getsize(src) > 0:
            try:
                _copy(src, db_path)
                result = "imported"
            except (sqlite3.Error, OSError) as e:
                log("no copio la base de Palantir: %s" % e)
                for p in (db_path, db_path + ".tmp"):
                    try:
                        os.remove(p)
                    except OSError:
                        pass

    def go(c):
        c.executescript(SCHEMA)
        if result == "imported":
            # pausas que flix_p3sync tenía marcadas a media sincronización (lastPlayed acabado en «z»): con su «Z»
            for table in ("movies_watched", "episodes_watched"):
                c.execute("UPDATE %s SET lastPlayed = substr(lastPlayed, 1, length(lastPlayed) - 1) || 'Z' "
                          "WHERE substr(lastPlayed, -1) = 'z'" % table)
    transaction(db_path, go)
    if result != "ok":
        log("base de vistos %s: %s" % ("copiada de Palantir" if result == "imported" else "nueva", db_path))
    return result


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def record(kind, tmdb, season, episode, position, total, now=None, show_total=None, db_path=None):
    """apunta lo reproducido con las reglas de Palantir: 'ignored' (menos de 180 s, sin duración o capítulo sin
    número), 'paused' (progreso en %) o 'watched' (desde el 80 %). show_total: capítulos de la serie (TMDB) para
    saber si queda completa"""
    try:
        position, total = float(position or 0), float(total or 0)
    except (TypeError, ValueError):
        return "ignored"
    tmdb, season, episode = _int(tmdb), _int(season), _int(episode)
    if kind not in ("movie", "tv") or not tmdb or tmdb <= 0 or position < MIN_SECONDS or total <= 0:
        return "ignored"
    if kind == "tv" and not (season and season > 0 and episode and episode > 0):
        return "ignored"
    pct = min(position * 100.0 / total, 100.0)
    watched = pct >= WATCHED_PCT
    when, rt = stamp(now), int(round(total))

    def go(c):
        if kind == "movie":
            c.execute("INSERT OR IGNORE INTO movies_watched (tmdb_id, playcount, progress, runtime, lastPlayed) "
                      "VALUES (?, 0, ?, ?, ?)", (tmdb, pct, rt, when))
            if watched:
                c.execute("UPDATE movies_watched SET playcount = IFNULL(playcount, 0) + 1, progress = 0.0, "
                          "runtime = ?, lastPlayed = ? WHERE tmdb_id = ?", (rt, when, tmdb))
            else:
                c.execute("UPDATE movies_watched SET progress = ?, runtime = ?, lastPlayed = ? WHERE tmdb_id = ?",
                          (pct, rt, when, tmdb))
            return
        key = (tmdb, season, episode)
        c.execute("INSERT OR IGNORE INTO episodes_watched (tmdb_id, season, episode, playcount, progress, runtime, "
                  "lastPlayed) VALUES (?, ?, ?, 0, ?, ?, ?)", key + (pct, rt, when))
        if not watched:
            c.execute("UPDATE episodes_watched SET progress = ?, runtime = ?, lastPlayed = ? WHERE tmdb_id = ? "
                      "AND season = ? AND episode = ?", (pct, rt, when) + key)
            return
        c.execute("UPDATE episodes_watched SET playcount = IFNULL(playcount, 0) + 1, progress = 0.0, runtime = ?, "
                  "lastPlayed = ? WHERE tmdb_id = ? AND season = ? AND episode = ?", (rt, when) + key)
        if show_total:
            c.execute("UPDATE shows_watched SET num_total_episodios = ? WHERE tmdb_id = ?", (int(show_total), tmdb))
        seen = c.execute("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id = ? AND season > 0 AND playcount > 0",
                         (tmdb,)).fetchone()[0]
        tot = c.execute("SELECT num_total_episodios FROM shows_watched WHERE tmdb_id = ?", (tmdb,)).fetchone()
        done = 1 if tot and tot[0] and seen >= tot[0] else 0
        # verla otra vez la vuelve a seguir (Palantir: ocultar = 0 al acabar un capítulo)
        c.execute("UPDATE shows_watched SET completa = ?, ocultar = 0 WHERE tmdb_id = ?", (done, tmdb))
    transaction(db_path or path(), go)
    return "watched" if watched else "paused"


def _ro(db_path):
    p = db_path or path()
    if not os.path.exists(p):
        return None
    return sqlite3.connect("file:%s?mode=ro" % p, uri=True, timeout=5)


def _cut(days, now):
    return stamp((time.time() if now is None else now) - days * 86400)


def resume_movies(db_path=None, days=RESUME_DAYS, now=None):
    """películas a medias tocadas en los últimos `days` días, la última primero: [(tmdb, %, duración s, lastPlayed)]"""
    c = _ro(db_path)
    if c is None:
        return []
    try:
        return [(int(t), float(p), int(r or 0), last) for t, p, r, last in c.execute(
            "SELECT tmdb_id, progress, runtime, lastPlayed FROM movies_watched WHERE progress > 0 AND lastPlayed >= ? "
            "ORDER BY lastPlayed DESC", (_cut(days, now),))]
    finally:
        c.close()


def _shows(c):
    """{tmdb: [(temporada, capítulo, %, lastPlayed, duración)]} sin especiales; filas y series de lo último tocado a
    lo más viejo (el formato que espera flix_common.current_episode)"""
    by = {}
    for t, s, e, p, r, last in c.execute(
            "SELECT tmdb_id, season, episode, progress, runtime, lastPlayed FROM episodes_watched WHERE season > 0 "
            "ORDER BY lastPlayed DESC, season DESC, episode DESC"):
        by.setdefault(int(t), []).append((int(s), int(e), float(p or 0), last or "", int(r or 0)))
    return by


def show_rows(tmdb, db_path=None):
    """filas de UNA serie con el formato de _shows (lo último tocado primero, sin especiales); [] si no hay"""
    c = _ro(db_path)
    if c is None:
        return []
    try:
        return [(int(s), int(e), float(p or 0), last or "", int(r or 0)) for s, e, p, r, last in c.execute(
            "SELECT season, episode, progress, runtime, lastPlayed FROM episodes_watched WHERE tmdb_id = ? "
            "AND season > 0 ORDER BY lastPlayed DESC, season DESC, episode DESC", (int(tmdb),))]
    finally:
        c.close()


def season_marks(tmdb, season, db_path=None):
    """{capítulo: (veces visto, % de la pausa, duración s)} de una temporada: ✓ y barras de la ficha de la serie"""
    c = _ro(db_path)
    if c is None:
        return {}
    try:
        return {int(e): (int(pc or 0), float(p or 0), int(r or 0)) for e, pc, p, r in c.execute(
            "SELECT episode, playcount, progress, runtime FROM episodes_watched WHERE tmdb_id = ? AND season = ?",
            (int(tmdb), int(season)))}
    finally:
        c.close()


def resume_episodes(db_path=None, days=RESUME_DAYS, now=None):
    """el capítulo «que toca» de cada serie (flix_common.current_episode) si quedó a medias en los últimos `days`
    días, lo último primero: [(tmdb, temporada, capítulo, %, duración s, lastPlayed)]"""
    import flix_common
    c = _ro(db_path)
    if c is None:
        return []
    try:
        by = _shows(c)
    finally:
        c.close()
    cut, out = _cut(days, now), []
    for t, rows in by.items():
        row, _late = flix_common.current_episode(rows)
        if row and row[2] > 0 and row[3] >= cut:
            out.append((t, row[0], row[1], row[2], row[4], row[3]))
    out.sort(key=lambda x: x[5], reverse=True)
    return out


def followed(db_path=None):
    """«Series en seguimiento»: [(tmdb, temporada, capítulo, %)] del capítulo que toca de cada serie con algo tocado,
    la tocada más recientemente primero; sin las ocultas, las completas ni las que solo tienen el piloto (T1 E1)
    empezado (como flix_direct.items_of)"""
    import flix_common
    c = _ro(db_path)
    if c is None:
        return []
    try:
        skip = {int(r[0]) for r in c.execute("SELECT tmdb_id FROM shows_watched WHERE ocultar = 1 OR completa = 1")}
        by = _shows(c)
        seen = {}
        for t, s_, e_ in c.execute("SELECT tmdb_id, season, episode FROM episodes_watched WHERE playcount > 0"):
            seen.setdefault(int(t), set()).add((int(s_), int(e_)))
    finally:
        c.close()
    out = []
    for t, rows in by.items():
        if t in skip:
            continue
        # solo cuenta lo visto o a medias: una fila «muerta» (pausa quitada, ni vista ni empezada) no hace que la serie
        # se siga ni la sube en el orden (17-nov: The Crown en la Shield y VisionQuest en el móvil, que Trakt no
        # tiene, salían arriba con la fecha de esa fila)
        rows = [r for r in rows if r[2] > 0 or r[0:2] in seen.get(t, ())]
        if not rows:
            continue
        row, _late = flix_common.current_episode(rows)
        if not row or ((row[0], row[1]) == (1, 1) and row[2] > 0):
            continue
        out.append((rows[0][3], t, row[0], row[1], row[2]))
    out.sort(key=lambda x: x[0], reverse=True)       # la tocada más recientemente (de lo que cuenta) primero
    return [x[1:] for x in out]


# ---------- marcas del menú de la skin (marks.py; 16-nov) ----------
# Lo que con Palantir hacían sus opciones de menú. Quien llama (marks.py) encola para el servicio lo visto, lo
# desmarcado, quitar una pausa y (16-nov) dejar de seguir y volver a seguir una serie.
def mark_movie(tmdb, watched, now=None, db_path=None):
    """película vista (una vez más, sin pausa) o no vista. Al desmarcar la fila se queda, sin ver y con la hora de
    ahora: una bajada de Simkl con el visto de antes (más viejo) no la vuelve a marcar. True si cambió algo"""
    when, tmdb = stamp(now), int(tmdb)

    def go(c):
        if watched:
            c.execute("INSERT OR IGNORE INTO movies_watched (tmdb_id, playcount, progress, runtime, lastPlayed) "
                      "VALUES (?, 0, 0.0, 0, ?)", (tmdb, when))
            c.execute("UPDATE movies_watched SET playcount = IFNULL(playcount, 0) + 1, progress = 0.0, lastPlayed = ? "
                      "WHERE tmdb_id = ?", (when, tmdb))
            return True
        return c.execute("UPDATE movies_watched SET playcount = 0, progress = 0.0, lastPlayed = ? WHERE tmdb_id = ? "
                         "AND (playcount > 0 OR progress > 0)", (when, tmdb)).rowcount > 0
    return transaction(db_path or path(), go)


def mark_episode(tmdb, season, episode, now=None, show_total=None, db_path=None):
    """capítulo visto, como al acabarlo (record): una vez más, sin pausa, y la serie completa si era el último"""
    when, key = stamp(now), (int(tmdb), int(season), int(episode))

    def go(c):
        c.execute("INSERT OR IGNORE INTO episodes_watched (tmdb_id, season, episode, playcount, progress, runtime, "
                  "lastPlayed) VALUES (?, ?, ?, 0, 0.0, 0, ?)", key + (when,))
        c.execute("UPDATE episodes_watched SET playcount = IFNULL(playcount, 0) + 1, progress = 0.0, lastPlayed = ? "
                  "WHERE tmdb_id = ? AND season = ? AND episode = ?", (when,) + key)
        if show_total:
            c.execute("UPDATE shows_watched SET num_total_episodios = ? WHERE tmdb_id = ?", (int(show_total), key[0]))
        seen = c.execute("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id = ? AND season > 0 AND playcount > 0",
                         key[:1]).fetchone()[0]
        tot = c.execute("SELECT num_total_episodios FROM shows_watched WHERE tmdb_id = ?", key[:1]).fetchone()
        done = 1 if tot and tot[0] and seen >= tot[0] else 0
        c.execute("UPDATE shows_watched SET completa = ?, ocultar = 0 WHERE tmdb_id = ?", (done, key[0]))
        return True
    return transaction(db_path or path(), go)


def unmark_episode(tmdb, season, episode, db_path=None):
    """capítulo no visto: fuera su fila (ni visto ni pausa) y la serie deja de estar completa. True si estaba visto
    (una pausa sola no cuenta: eso es «Quitar progreso»)"""
    key = (int(tmdb), int(season), int(episode))

    def go(c):
        n = c.execute("DELETE FROM episodes_watched WHERE tmdb_id = ? AND season = ? AND episode = ? AND playcount > 0",
                      key).rowcount
        if n:
            c.execute("UPDATE shows_watched SET completa = 0 WHERE tmdb_id = ?", key[:1])
        return n > 0
    return transaction(db_path or path(), go)


def mark_show_watched(tmdb, episodes, now=None, db_path=None, total=None):
    """serie vista: cada capítulo emitido ([(temporada, capítulo)]) que no lo estuviera queda visto y sin pausa, y la
    serie, completa. Devuelve los que ha marcado (los ya vistos no se tocan).
    total («vistos hasta aquí»): episodes es solo una parte; total = capítulos emitidos de la serie, que queda
    completa solo si ya están todos vistos, y vuelve a «Series en seguimiento» si se había dejado de seguir"""
    when, tmdb = stamp(now), int(tmdb)

    def go(c):
        have = {(s, e): (pc or 0, pr or 0) for s, e, pc, pr in c.execute(
            "SELECT season, episode, playcount, progress FROM episodes_watched WHERE tmdb_id = ?", (tmdb,))}
        new = []
        for s, e in episodes:
            if (s, e) not in have:
                c.execute("INSERT INTO episodes_watched (tmdb_id, season, episode, playcount, progress, runtime, "
                          "lastPlayed) VALUES (?, ?, ?, 1, 0.0, 0, ?)", (tmdb, s, e, when))
            elif have[(s, e)][0] <= 0 or have[(s, e)][1] > 0:
                c.execute("UPDATE episodes_watched SET playcount = MAX(IFNULL(playcount, 0), 1), progress = 0.0, "
                          "lastPlayed = ? WHERE tmdb_id = ? AND season = ? AND episode = ?", (when, tmdb, s, e))
            else:
                continue
            if have.get((s, e), (0, 0))[0] <= 0:
                new.append((s, e))
        if total is None:
            c.execute("UPDATE shows_watched SET num_total_episodios = ?, completa = 1 WHERE tmdb_id = ?",
                      (len(episodes), tmdb))
        else:
            seen = c.execute("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id = ? AND season > 0 AND playcount > 0",
                             (tmdb,)).fetchone()[0]
            c.execute("UPDATE shows_watched SET num_total_episodios = ?, completa = ?, ocultar = 0 WHERE tmdb_id = ?",
                      (int(total), 1 if seen >= int(total) else 0, tmdb))
        return new
    return transaction(db_path or path(), go)


def mark_show_unwatched(tmdb, db_path=None):
    """serie no vista: fuera todos sus capítulos (y con ellos la serie: disparador). Devuelve (capítulos que estaban
    vistos [(temporada, capítulo)], sin especiales; filas quitadas)"""
    tmdb = int(tmdb)

    def go(c):
        seen = [(int(s), int(e)) for s, e in c.execute(
            "SELECT season, episode FROM episodes_watched WHERE tmdb_id = ? AND season > 0 AND playcount > 0 "
            "ORDER BY season, episode", (tmdb,))]
        n = c.execute("DELETE FROM episodes_watched WHERE tmdb_id = ?", (tmdb,)).rowcount
        n += c.execute("DELETE FROM shows_watched WHERE tmdb_id = ?", (tmdb,)).rowcount
        return seen, n
    return transaction(db_path or path(), go)


def clear_pause(kind, tmdb, season=None, episode=None, now=None, db_path=None):
    """quita la pausa de una película o de un capítulo (fuera de «Seguir viendo»). La fila se queda con la hora de
    ahora: la pausa que Simkl aún guarde, más vieja, no vuelve al bajar (sync._apply solo pone las más nuevas).
    True si había pausa"""
    when = stamp(now)

    def go(c):
        if kind == "movie":
            return c.execute("UPDATE movies_watched SET progress = 0.0, lastPlayed = ? WHERE tmdb_id = ? "
                             "AND progress > 0", (when, int(tmdb))).rowcount > 0
        return c.execute("UPDATE episodes_watched SET progress = 0.0, lastPlayed = ? WHERE tmdb_id = ? AND season = ? "
                         "AND episode = ? AND progress > 0", (when, int(tmdb), int(season), int(episode))).rowcount > 0
    return transaction(db_path or path(), go)


def unfollow(tmdb, db_path=None):
    """la serie deja de salir en «Series en seguimiento» (ocultar = 1; verla otra vez la vuelve a seguir: record).
    True si se seguía"""
    def go(c):
        return c.execute("UPDATE shows_watched SET ocultar = 1 WHERE tmdb_id = ? AND ocultar = 0",
                         (int(tmdb),)).rowcount > 0
    return transaction(db_path or path(), go)


def is_hidden(tmdb, db_path=None):
    """¿la serie se ha dejado de seguir? (ocultar = 1). Se mira antes de apuntar un capítulo visto: si lo estaba, el
    servicio también tiene que volver a seguirla (sync.UNHIDE)"""
    c = _ro(db_path)
    if c is None:
        return False
    try:
        return bool(c.execute("SELECT 1 FROM shows_watched WHERE tmdb_id = ? AND ocultar = 1", (int(tmdb),)).fetchone())
    finally:
        c.close()


# ---------- favoritos (bloque 3; 16-nov) ----------
# Una sola lista, «guardado para ver»: la misma tabla que la bajada de Simkl llena con sus «Pendientes de ver»
# (sync.plan_changes). content: «movies» o «shows», como en Palantir.
FAV_CONTENT = {"movie": "movies", "tv": "shows"}


def set_favorite(kind, tmdb, on, db_path=None):
    """añade o quita el título de favoritos; True si cambió algo"""
    args = (int(tmdb), FAV_CONTENT[kind])

    def go(c):
        if on:
            return c.execute("INSERT OR IGNORE INTO favorites (tmdb_id, content) VALUES (?, ?)", args).rowcount > 0
        return c.execute("DELETE FROM favorites WHERE tmdb_id = ? AND content = ?", args).rowcount > 0
    return transaction(db_path or path(), go)


def is_favorite(kind, tmdb, db_path=None):
    c = _ro(db_path)
    if c is None:
        return False
    try:
        return bool(c.execute("SELECT 1 FROM favorites WHERE tmdb_id = ? AND content = ?",
                              (int(tmdb), FAV_CONTENT[kind])).fetchone())
    finally:
        c.close()


def favorites(kind, db_path=None):
    """[tmdb] de los favoritos de ese tipo, lo último añadido primero"""
    c = _ro(db_path)
    if c is None:
        return []
    try:
        return [int(r[0]) for r in c.execute("SELECT tmdb_id FROM favorites WHERE content = ? ORDER BY rowid DESC",
                                             (FAV_CONTENT[kind],))]
    finally:
        c.close()


def has_views(kind, tmdb, db_path=None):
    """¿tiene algo visto o a medias? (película, o cualquier capítulo de la serie)"""
    c = _ro(db_path)
    if c is None:
        return False
    try:
        table = "movies_watched" if kind == "movie" else "episodes_watched"
        return bool(c.execute("SELECT 1 FROM %s WHERE tmdb_id = ? AND (playcount > 0 OR progress > 0) LIMIT 1" % table,
                              (int(tmdb),)).fetchone())
    finally:
        c.close()
