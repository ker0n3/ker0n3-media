"""¿Esta versión es de verdad la película (o el capítulo) que se pide, y en un idioma que valga? (16-nov, Carlos)

Casos reales: «La Odisea» (2026, tmdb 1368337, 173 min) — Peerflix daba con el mismo id la de The Asylum (~90 min) en
castellano y la prioridad del castellano ponía la otra película; «Godzilla Minus Zero» (tmdb 1381071), recién
estrenada en cines: solo había grabaciones de sala y «HD» sin origen.

UNA sola función (keep / reason) para lo que se ENSEÑA (addon Ker0n3, avail: ok / esp) y lo que se REPRODUCE
(flix_src_play): las dos miran lo mismo. Reglas:

1. Nivel de estreno (películas; TMDB release_dates, tipos 1 preestreno, 2-3 cines, 4 digital, 5 físico, 6 TV):
   * «sin_estrenar»: ninguna fecha de cines / digital / físico / TV ≤ hoy en ningún país y la fecha de estreno futura
     o vacía (un preestreno de festival no cuenta) → no vale NINGUNA versión.
   * «cine»: en cines, sin fecha doméstica (4-6) ≤ hoy → modo estricto: el nombre tiene que llevar el año de la
     película (o el siguiente: STRICT_YEARS) Y un origen doméstico (_HOME) y no ser una grabación de sala (_CINEMA).
   * «casa»: con fecha doméstica ≤ hoy → como siempre.
   Sin fecha doméstica en TMDB (lo normal en películas antiguas y en muchas pequeñas): doméstica a los HOME_AFTER
   días del estreno en cines. Si TMDB conoce una fecha doméstica que aún no ha llegado, manda ella… hasta
   HOME_AFTER_KNOWN días (después es una reedición en disco de una película vieja).
   Series: el «aún no emitido» ya lo lleva avail (último capítulo emitido); sin modo estricto.
2. Nombre, siempre: fuera si lleva OTRO año (margen YEAR_SLACK; los números del propio título no cuentan: «2001»,
   «1917», «Blade Runner 2049») y fuera las marcas de imitación (_MARKS: The Asylum…). Series: solo se descarta un año
   ANTERIOR al del estreno de la serie (otra serie con el mismo nombre); las temporadas llevan años posteriores.
3. Idioma por el nombre: castellano o versión original (el idioma en que se rodó, TMDB original_language). Fuera el
   latino (salvo «dual», que puede traer la original) y lo marcado solo en un tercer idioma. Original en español:
   cualquier español (de España o latino) ES la versión original.
4. Duración (película, al reproducir): la de la cabecera del fichero contra la de TMDB (duration_reason).
"""
import collections
import datetime
import json
import os
import re
import time
import unicodedata
import urllib.request

# días desde el estreno en cines a partir de los cuales una película SIN fecha doméstica en TMDB se da por editada.
# 120: la ventana más larga que se usa hoy (Francia, 4 meses a vídeo; España 112 días con ayudas; el disco en EE. UU.
# ~90-120; el alquiler digital, 17-45). Más corto dejaría pasar falsos de lo que sigue en salas; más largo solo
# alarga el modo estricto, que lo de verdad (año + origen) pasa igual
HOME_AFTER = 120
HOME_AFTER_KNOWN = 365      # con fecha doméstica FUTURA en TMDB: hasta un año manda esa fecha
YEAR_SLACK = 1              # ±1: TMDB fecha por el primer estreno (festival) y los nombres por el estreno general
STRICT_YEARS = (0, 1)       # en estricto, el año de TMDB o el siguiente (el anterior suele ser la entrega anterior)
META_TTL = 86400            # ficha para reproducir (skin): un día
TIMEOUT = 5
UA = "Mozilla/5.0 (Ker0n3Media-skin)"

# origen doméstico (sobre el nombre en minúsculas y sin signos). «UHD», «HD» o «4K» a secas no dicen de dónde sale
_HOME = re.compile(r"\b(?:web ?dl|web ?rip|web|blu ?ray|bd ?rip|br ?rip|bd ?remux|remux|bdmv|uhd ?rip|hd ?rip|"
                   r"dvd ?rip|micro ?hd)\b")
# grabación de sala o copia de trabajo
_CINEMA = re.compile(r"\b(?:cam|cam ?rip|hd ?cam|hq ?cam|ts|hd ?ts|hq ?ts|ts ?rip|hd ?ts ?rip|telesync|tc|hd ?tc|"
                     r"telecine|scr|screener|dvd ?scr|bd ?scr|hd ?scr|web ?scr|hd ?ts ?scr|hd ?tscr|tscr|ts ?scr|ts ?screener|r5|"
                     r"workprint|pre ?dvd|pdvd|1xbet)\b")
# otra película con el mismo nombre (lista corta y explícita). (palabra que la anula si está en el título, patrón, texto)
_MARKS = (("asylum", re.compile(r"\b(?:the )?asylum\b"), "The Asylum"),
          ("mockbuster", re.compile(r"\bmockbuster\b"), "mockbuster"),
          ("not", re.compile(r"\bnot the\b.{0,40}\b(?:film|movie)\b"), "«NOT the … film»"),
          ("extras", re.compile(r"\bextras\b"), "extras del disco"))
_YEAR = re.compile(r"(?<![0-9a-z])(?:19|20)[0-9]{2}(?![0-9a-z])")

# idiomas por el nombre (lo que no es castellano ni latino, que ya los marca flix_src_list.parse)
_NAME_LANGS = (("en", r"\benglish\b|\beng\b"), ("it", r"\bita\b|\bitalian[oa]?\b"),
               ("fr", r"french|\bvf[fqi]?\b"), ("de", r"\bgerman\b|\bdeutsch\b|\bger\b"),
               ("ja", r"\bjapanese\b|\bjap\b|\bjpn\b"), ("ko", r"\bkorean\b|\bkor\b"),
               ("zh", r"\bchinese\b|\bmandarin\b|\bcantonese\b|\bchi\b"), ("hi", r"\bhindi\b|\bhin\b"),
               ("ta", r"\btamil\b|\btam\b"), ("te", r"\btelugu\b|\btel\b"), ("ru", r"\brussian\b|\brus\b"),
               ("uk", r"\bukrainian\b|\bukr\b"), ("pt", r"\bdublado\b|\bportugu[eê]s\b|\bpt-br\b"),
               ("pl", r"\bpolish\b|\blektor\b"), ("tr", r"\bturkish\b|\bt[uü]rk[cç]e\b"), ("th", r"\bthai\b"),
               ("ar", r"\barabic\b"))
_NAME_LANGS = tuple((k, re.compile(p)) for k, p in _NAME_LANGS)
_LT = r"(?:eng|english|ita|italian[oa]?|fre|fra|french|ger|german|spa|esp|jap|jpn|kor|rus|ukr|hin|tam|tel|chi|pl)"
# subtítulos, que no son audio: «Sub iTA EnG», «ENG SUB», «ESub», «VOSTFR», «Napisy PL», «HC-Sub»
_SUBS = re.compile(r"\b(?:e|m|multi|hc[\s._-]*)?subs?\b(?:[\s._:+-]*\b%s\b)*|\b%s[\s._-]*subs?\b|vostfr|subfrench|"
                   r"\bnapisy\b\W*\w*|\bsubt\w*" % (_LT, _LT))
# TMDB (ISO 639-1; «cn» = cantonés) → códigos de las pistas (ISO 639-2 B y T)
_ISO = {"en": ("eng",), "es": ("spa",), "ja": ("jpn",), "ko": ("kor",), "fr": ("fre", "fra"), "de": ("ger", "deu"),
        "it": ("ita",), "pt": ("por",), "zh": ("chi", "zho", "cmn", "yue"), "cn": ("chi", "zho", "yue", "zh", "cmn"),
        "ru": ("rus",), "hi": ("hin",), "sv": ("swe",), "da": ("dan",), "no": ("nor", "nob", "nb", "nno"),
        "fi": ("fin",), "nl": ("dut", "nld"), "pl": ("pol",), "tr": ("tur",), "ar": ("ara",), "he": ("heb",),
        "th": ("tha",), "id": ("ind",), "el": ("gre", "ell"), "cs": ("cze", "ces"), "hu": ("hun",),
        "ro": ("rum", "ron"), "uk": ("ukr",), "ca": ("cat",), "eu": ("baq", "eus"), "gl": ("glg",),
        "fa": ("per", "fas"), "ta": ("tam",), "te": ("tel",), "ml": ("mal",), "bn": ("ben",), "vi": ("vie",),
        "is": ("ice", "isl"), "sr": ("srp",), "hr": ("hrv",), "bg": ("bul",), "et": ("est",), "tl": ("tgl", "fil"),
        "ms": ("may", "msa"), "kn": ("kan",), "mr": ("mar",), "pa": ("pan",), "ur": ("urd",), "sk": ("slo", "slk"),
        "sl": ("slv",), "lt": ("lit",), "lv": ("lav",), "ka": ("geo", "kat"), "hy": ("arm", "hye"), "ga": ("gle",)}
_UNTAGGED = ("", "und", "mul", "mis", "zxx", "qaa")


def _norm(s):
    """minúsculas, sin acentos y sin signos: «Blu-ray» → «blu ray»"""
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch)).lower()
    return " ".join(re.sub(r"[^0-9a-z]+", " ", s).split())


def _date(d):
    d = (d or "")[:10]
    return d if re.match(r"\d{4}-\d{2}-\d{2}$", d) else ""


def release_info(d):
    """de la respuesta de TMDB /movie/<id>?append_to_response=release_dates: la primera fecha de cada clase en
    cualquier país. {"pre": preestreno (1), "cine": cines (2, 3), "casa": digital / físico / TV (4, 5, 6)}"""
    out = {"pre": "", "cine": "", "casa": ""}
    for r in ((d or {}).get("release_dates") or {}).get("results") or []:
        for x in r.get("release_dates") or []:
            day, typ = _date(x.get("release_date")), x.get("type")
            k = "pre" if typ == 1 else "cine" if typ in (2, 3) else "casa" if typ in (4, 5, 6) else None
            if k and day and (not out[k] or day < out[k]):
                out[k] = day
    return out


def build(kind, year, premiered, titles, rel, runtime, lang):
    """la ficha que usan las reglas. rel: release_info (None = sin datos / serie); runtime en segundos"""
    return {"kind": kind, "year": int(year or 0), "premiered": _date(premiered),
            "titles": [t for t in dict.fromkeys(titles or ()) if t], "rel": rel, "runtime": int(runtime or 0),
            "lang": (lang or "").lower()}


def from_sheet(sheet):
    """de una ficha de Ker0n3 (catalog.movie / catalog.show); None si es de antes de estas reglas (sin «lang», o
    película sin «rel»): no se sabe"""
    if not sheet or "lang" not in sheet or (sheet.get("kind") == "movie" and "rel" not in sheet):
        return None
    movie = sheet.get("kind") == "movie"
    return build("movie" if movie else "tv", sheet.get("year"), sheet.get("premiered"),
                 [sheet.get("title"), sheet.get("original_title")], sheet.get("rel") if movie else None,
                 sheet.get("duration") if movie else 0, sheet.get("lang"))


def _today(today=None):
    return today or time.strftime("%Y-%m-%d")


def _days(a, b):
    try:
        return (datetime.date.fromisoformat(b) - datetime.date.fromisoformat(a)).days
    except ValueError:
        return 0


def level(meta, today=None):
    """«sin_estrenar», «cine» (modo estricto) o «casa» (como siempre). Series y fichas sin datos: «casa»"""
    if not meta or meta.get("kind") != "movie" or meta.get("rel") is None:
        return "casa"
    today, rel = _today(today), meta["rel"]
    casa = rel.get("casa") or ""
    if casa and casa <= today:
        return "casa"
    starts = [d for d in (rel.get("cine"), meta.get("premiered")) if d and d <= today]
    if not starts:
        return "sin_estrenar"
    if _days(min(starts), today) >= (HOME_AFTER_KNOWN if casa else HOME_AFTER):
        return "casa"
    return "cine"


def _years(text, titles, today):
    """años que lleva un nombre, sin los números del propio título (una vez cada uno) ni lo que no puede ser un año"""
    top = int(_today(today)[:4]) + 1
    own = collections.Counter()
    for t in titles:
        for y, n in collections.Counter(_YEAR.findall(_norm(t))).items():
            own[y] = max(own[y], n)
    out = []
    for y in _YEAR.findall(_norm(text)):
        if own[y] > 0:
            own[y] -= 1
        elif 1900 <= int(y) <= top:
            out.append(int(y))
    return out


def _strip_titles(text, titles):
    """el nombre normalizado sin el título (para no leer marcas dentro de él: «Cam», «The Web»)"""
    text = " %s " % _norm(text)
    for t in sorted({_norm(x) for x in titles} - {""}, key=len, reverse=True):
        text = text.replace(" %s " % t, "  ", 1)
    return text


_BRACKET_CODE = re.compile(r"\[\s*[A-Z]{2,3}(?:-[A-Z]{2,3})?\s*\]")


def name_langs(label, original=None):
    """idiomas de audio que dice el nombre (sin castellano ni latino), quitando lo que habla de subtítulos: también
    las listas del anime («[Multiple Subtitle] [ENG][POR-BR][SPA]…», 17-nov) y, si la original es japonés, un código
    suelto entre corchetes («[New-raws] … [ENG]»: subtítulos; un doblaje lo dice con palabras, «English Dub»)"""
    import flix_src_list
    t, _ = flix_src_list.strip_sub_lists(label or "")
    if original == "ja":
        t = _BRACKET_CODE.sub(" ", t)
    t = _SUBS.sub(" ", t.lower())
    return {k for k, rx in _NAME_LANGS if rx.search(t)}


def _lang_reason(c, lang):
    if c.get("esp"):
        return ""
    if c.get("lat"):
        return "" if lang == "es" or c.get("multi") else "latino"
    if not lang or c.get("multi"):
        return ""
    said = name_langs(c.get("label"), lang)
    if said and ("zh" if lang == "cn" else lang) not in said:
        return "otro idioma (%s)" % ", ".join(sorted(said))
    return ""


def reason(c, meta, today=None, lang=True):
    """por qué NO vale esta versión ("" = vale). lang=False: sin la regla del idioma («Elegir versión», a mano)"""
    meta = meta or {}
    titles = meta.get("titles") or []
    names = [x for x in (c.get("label"), c.get("filename")) if x]
    clean = [_strip_titles(x, titles) for x in names]
    in_title = " ".join(_norm(t) for t in titles)
    for word, rx, text in _MARKS:
        if word not in in_title.split() and any(rx.search(x) for x in clean):
            return "marca de otra película (%s)" % text
    lvl = level(meta, today)
    if lvl == "sin_estrenar":
        return "sin estrenar"
    year, movie = meta.get("year") or 0, meta.get("kind") == "movie"
    # manda el fichero (en un pack es lo que se va a ver); si no lleva año, el nombre del torrent
    years = next((ys for ys in (_years(x, titles, today) for x in reversed(names)) if ys), [])
    if year and years:
        if movie and not min(years) - YEAR_SLACK <= year <= max(years) + YEAR_SLACK:
            return "año distinto (%s; es de %d)" % ("-".join(str(y) for y in sorted(set(years))), year)
        if not movie and max(years) < year - YEAR_SLACK:
            return "año anterior a la serie (%d; es de %d)" % (max(years), year)
    if lvl == "cine":
        if any(_CINEMA.search(x) for x in clean):
            return "en cines: grabación de sala"
        if year and not any(year + STRICT_YEARS[0] <= y <= year + STRICT_YEARS[1] for y in years):
            return "en cines: sin el año en el nombre"
        if not any(_HOME.search(x) for x in clean):
            return "en cines: sin origen doméstico"
    return _lang_reason(c, meta.get("lang") or "") if lang else ""


def keep(cands, meta, today=None, lang=True, log=None):
    """las versiones que valen, en su orden. log(texto): una línea por cada descartada, con el motivo"""
    out = []
    for c in cands or []:
        why = reason(c, meta, today, lang)
        if not why:
            out.append(c)
        elif log is not None:
            log("descartada (%s): %s" % (why, (c.get("label") or c.get("filename") or "")[:90]))
    return out


def lang_match(track, code):
    """¿el idioma de una pista («jpn», «ja», «ja-JP») es el de TMDB («ja»)?"""
    code = (code or "").lower()
    primary = re.split(r"[-_]", (track or "").strip().lower())[0]
    return bool(primary) and bool(code) and (primary == code or primary in _ISO.get(code, ()))


def vo(tracks, code):
    """¿trae audio en el idioma original? tracks: pistas de audio de flix_src_audio.probe ({"lang", "name",
    "tagged"}). «si», «no» (todas con idioma y ninguna es) o «?» (sin pistas leídas o alguna sin idioma)"""
    if not tracks:
        return "?"
    if any(lang_match(t.get("lang"), code) and t.get("tagged", True) for t in tracks):
        return "si"
    if any((t.get("lang") or "").lower() in _UNTAGGED or not t.get("tagged", True) for t in tracks):
        return "?"
    return "no"


def duration_reason(secs, meta):
    """película: la duración del fichero (s) contra la de TMDB. Vale entre −15 % (mínimo 10 min) y +35 % (mínimo
    15 min: los montajes largos duran hasta un tercio más; otra película más corta es lo habitual en los falsos).
    Sin duración en el fichero o en TMDB, o capítulos (dobles, resúmenes, especiales): no se comprueba"""
    run = (meta or {}).get("runtime") or 0
    if not secs or run <= 0 or (meta or {}).get("kind") != "movie":
        return ""
    if secs < run - max(0.15 * run, 600) or secs > run + max(0.35 * run, 900):
        return "dura %d min y la película %d" % (round(secs / 60), round(run / 60))
    return ""


# ---------- ficha para reproducir desde la skin (el addon usa su catálogo: from_sheet) ----------
def _cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/src_meta.json" % xbmc.getSkinDir())


def _year_of(d):
    return int(d[:4]) if d and d[:4].isdigit() else 0


def get(kind, tmdb, opener=None, cache_path=None, now=time.time):
    """la ficha de TMDB para las reglas (una petición, guardada META_TTL); None si no se pudo (las reglas que
    necesitan ficha no se aplican: como antes). Nunca lanza"""
    try:
        path = cache_path or _cache_path()
        key = "%s/%s" % (kind, tmdb)
        try:
            with open(path, encoding="utf-8") as f:
                cache = json.load(f)
        except (OSError, ValueError):
            cache = {}
        if not isinstance(cache, dict):
            cache = {}
        hit = cache.get(key)
        if isinstance(hit, list) and len(hit) == 2 and isinstance(hit[1], dict) and now() - hit[0] < META_TTL:
            return hit[1]
        from flix_common import TMDB_KEY
        url = "https://api.themoviedb.org/3/%s/%s?api_key=%s&language=es-ES%s" % (
            kind, tmdb, TMDB_KEY, "&append_to_response=release_dates" if kind == "movie" else "")
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
            d = json.loads(r.read().decode())
        if kind == "movie":
            date = d.get("release_date") or ""
            meta = build("movie", _year_of(date), date, [d.get("title"), d.get("original_title")], release_info(d),
                         int(d.get("runtime") or 0) * 60, d.get("original_language"))
        else:
            date = d.get("first_air_date") or ""
            meta = build("tv", _year_of(date), date, [d.get("name"), d.get("original_name")], None, 0,
                         d.get("original_language"))
        cache = {k: v for k, v in cache.items()
                 if isinstance(v, list) and len(v) == 2 and now() - v[0] < META_TTL}
        cache[key] = [now(), meta]
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            from flix_common import atomic_write
            atomic_write(path, json.dumps(cache))
        except OSError:
            pass
        return meta
    except Exception:  # noqa: BLE001  (sin red, TMDB caído, respuesta rota: sin ficha)
        return None
