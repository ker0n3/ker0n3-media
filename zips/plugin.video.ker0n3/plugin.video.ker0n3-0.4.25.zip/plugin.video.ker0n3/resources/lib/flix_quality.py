"""Prioridad de reproducción (Ajustes): reproducción automática sí/no, orden de calidades con interruptor por calidad
y remux sí/no. La usa flix_src_play.py para elegir versión (mejor primero; con la automática apagada, «Elegir versión»).

Vive en el addon Ker0n3 (lógica; docs/arquitectura-skin-addon.md). Lo de pantalla está en la skin:
  RunScript(special://skin/scripts/flix_editor.py,quality)   -> editor único (Ajustes → «Orden de calidades»)
  RunScript(special://skin/scripts/flix_follow.py,upnext)    -> «Aviso de siguiente capítulo»
first_run.py llama a migrate() al arrancar: pasa el modo viejo (4k / 1080) al formato nuevo y escribe el resumen

Guardado por aparato en los ajustes del skin:
  Skin.String(flix_autoplay)        "on" / "off" (valores viejos "4k" y "1080" = on)
  Skin.String(flix_quality_order)   "4k|dv|-4khdr10|…" (orden; "-" = desactivada; sin comas: Skin.SetString corta
                                    el valor en la primera coma)
  Skin.HasSetting(flix_remux)       remux (R) permitidos dentro de su calidad
  Skin.String(flix_quality_summary) resumen para la pantalla de Ajustes ("4K → DV → 4K HDR10 …")

Calidades (medido el 19-oct en 484 títulos): 1080p, DV HDR10, DV HDR10+, DV, 4K HDR10, 4K, HD, 4K HDR10+, 1080p HDR10,
más SD; variantes (R) = remux, (IMAX) = cuenta como su calidad base, (3D) = «Resto».
"""
TIERS = (
    ("4k", "4K"),
    ("dv", "Dolby Vision"),
    ("4khdr10", "4K HDR10"),
    ("4khdr10p", "4K HDR10+"),
    ("dvhdr10", "Dolby Vision HDR10"),
    ("dvhdr10p", "Dolby Vision HDR10+"),
    ("1080", "1080p"),
    ("720", "720p (HD)"),
    ("rest", "Resto (SD, 3D…)"),
)
KEYS = [k for k, _ in TIERS]
LABEL = dict(TIERS)
SHORT = {"4k": "4K", "dv": "DV", "4khdr10": "4K HDR10", "4khdr10p": "4K HDR10+", "dvhdr10": "DV HDR10",
         "dvhdr10p": "DV HDR10+", "1080": "1080p", "720": "720p", "rest": "Resto"}
DEFAULT = [(k, True) for k in KEYS]     # = el modo «4k» de antes (más 720p y resto al final, antes del selector)


def tier(q):
    """calidad del selector ('4K HDR10+', 'DV HDR10 (R) (IMAX)', '1080p (3D)', 'HD'…) -> clave de TIERS"""
    u = (q or "").upper()
    if "3D" in u:
        return "rest"
    hdr = "hdr10p" if "HDR10+" in u else "hdr10" if "HDR" in u else ""
    if u.startswith("4K"):
        return "4k" + hdr
    if u.startswith("DV"):
        return "dv" + hdr
    if u.startswith("1080"):
        return "1080"
    if u.startswith("720") or u.startswith("HD"):
        return "720"
    return "rest"


def parse(text):
    """'4k|-dv|…' -> [(clave, encendida)] con todas las claves (las que falten, al final y encendidas)"""
    out, seen = [], set()
    for part in (text or "").replace(",", "|").split("|"):
        part = part.strip().lower()
        on = not part.startswith("-")
        k = part.lstrip("-")
        if k in LABEL and k not in seen:
            out.append((k, on))
            seen.add(k)
    if not out:
        return list(DEFAULT)
    return out + [(k, True) for k in KEYS if k not in seen]


def dump(order):
    return "|".join(("" if on else "-") + k for k, on in order)


def summary(order):
    on = [SHORT[k] for k, o in order if o]
    if not on:
        return "ninguna calidad activa"
    return " → ".join(on[:4]) + (" …" if len(on) > 4 else "")


def legacy_order(mode):
    """orden equivalente al modo viejo: '1080' = solo 1080p"""
    if (mode or "").strip().lower() == "1080":
        return [("1080", True)] + [(k, False) for k in KEYS if k != "1080"]
    return list(DEFAULT)


def is_on(mode):
    return (mode or "").strip().lower() not in ("off", "")


class Conf:
    def __init__(self, auto=True, order=None, remux=False):
        self.auto, self.order, self.remux = auto, list(order or DEFAULT), remux


# ---------- Kodi ----------
def load():
    import xbmc
    mode = xbmc.getInfoLabel("Skin.String(flix_autoplay)")
    text = xbmc.getInfoLabel("Skin.String(flix_quality_order)")
    order = parse(text) if text else legacy_order(mode)
    return Conf(is_on(mode), order, xbmc.getCondVisibility("Skin.HasSetting(flix_remux)"))


def save(conf):
    import xbmc
    xbmc.executebuiltin("Skin.SetString(flix_autoplay,%s)" % ("on" if conf.auto else "off"))
    xbmc.executebuiltin("Skin.SetString(flix_quality_order,%s)" % dump(conf.order))
    xbmc.executebuiltin("Skin.SetString(flix_quality_summary,%s)" % summary(conf.order).replace(",", " "))
    xbmc.executebuiltin("%s(flix_remux)" % ("Skin.SetBool" if conf.remux else "Skin.Reset"))


# «Solo en castellano» (16-nov, fuentes propias): qué se ENSEÑA en las filas del Inicio y en el buscador de Ker0n3.
# Apagado (de serie): lo que tenga versión en castellano o en versión original. Encendido: solo lo que la tenga en
# castellano. Lo lee el addon (ker0n3.avail.solo_esp); su servicio ve el cambio y vuelve a pedir las filas
SOLO_ESP = "flix_solo_castellano"
SOLO_ESP_NAME = "Solo en castellano"
SOLO_ESP_NOTE = "Oculta lo que solo está en versión original"


def solo_esp():
    import xbmc
    return bool(xbmc.getCondVisibility("Skin.HasSetting(%s)" % SOLO_ESP))


def solo_esp_toggle():
    """enciende o apaga el ajuste y devuelve el valor nuevo (el builtin va por la cola de Kodi: se espera, acotado, a
    que se vea; como flix_menu_preview.toggle)"""
    import xbmc
    on = not solo_esp()
    xbmc.executebuiltin("Skin.%s(%s)" % ("SetBool" if on else "Reset", SOLO_ESP))
    for _ in range(40):
        if solo_esp() == on:
            break
        xbmc.sleep(50)
    return on


def migrate():
    """modo viejo (4k / 1080) -> formato nuevo, una vez; y resumen siempre al día"""
    import xbmc
    if not xbmc.getInfoLabel("Skin.String(flix_quality_order)") or not xbmc.getInfoLabel("Skin.String(flix_quality_summary)"):
        save(load())
