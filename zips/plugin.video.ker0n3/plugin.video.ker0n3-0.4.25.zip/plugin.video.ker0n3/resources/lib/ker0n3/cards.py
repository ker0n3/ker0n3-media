"""Filas de tarjetas de las secciones (bloques 4 y 5; 17-nov): sagas, géneros y años. Diseño:
docs/superpowers/specs/2026-11-17-menu-secciones-sin-palantir-design.md.

Ruta tarjetas/<grupo>[/todo]: las tarjetas del grupo (flix_sections_own.cards, sin red), cada una abre su lista
(lista/<clave>). Regla de lo que se enseña también por tarjeta (Carlos, 17-nov: «en esta skin solo se ven cosas que
tenemos enlace»): una tarjeta sale si su lista tiene algún título con versión (castellano u original; con «Solo en
castellano», castellano) o si aún no se sabe; la que se sabe vacía no sale. La ruta NO comprueba nada: mira lo
guardado. La comprobación va por detrás, en el servicio (check, una tarjeta cada vez, solo de las filas de tarjetas
pedidas en la semana): pide la primera página de la lista y comprueba sus títulos en orden hasta dar con uno que se
enseñe (la lista entera la repasa lists.warm cuando se abre la tarjeta). Si lo que enseña una fila cambia, avisa a la
skin con la clave «tarjetas-<grupo>» (lists.signal), como las listas.

En listas.json:
  UT/<grupo>[/todo]  cuándo se pidió la fila (el servicio solo comprueba las de filas pedidas en la última semana)
  C/<clave>          lo sabido de la lista de una tarjeta: {"t", "ok", "esp"}; ok True (alguno con versión), False
                     (ninguno: todos comprobados), None (los primeros no tienen y el resto no se miró: sale);
                     esp igual para el castellano (None = no se miró)"""
import time

CHECK_TTL = 86400           # lo sabido de una tarjeta vale un día (las comprobaciones de cada título, 1-3 días)
USED = "UT/"
STATE = "C/"
MAX_CHUNKS = 3              # tandas (de lists.CHUNK) como mucho por tarjeta: con 18 títulos sin versión, «no se sabe»
BATCH = 8                   # tarjetas como mucho por trabajo del servicio
BATCH_BUDGET = 40           # s como mucho por trabajo
REV_PREFIX = "tarjetas-"    # clave del aviso a la skin (flix_rows.k3_list_key)


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.cards] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def state(key, cache, now=time.time):
    return cache.get(STATE + key, CHECK_TTL, now=now)


def shows(st, solo=False):
    """¿sale la tarjeta? Sin saber, sí; se sabe que su lista no tiene nada (o nada en castellano con solo), no"""
    if not st:
        return True
    if st.get("ok") is False:
        return False
    return not (solo and st.get("esp") is False)


def needs_check(st, solo=False):
    return not st or (solo and st.get("ok") and st.get("esp") is None)


def rev_key(group):
    return REV_PREFIX + group.split("/")[0]


def directory(handle, group, whole=False, cache=None, now=time.time, solo=None):
    """ruta tarjetas/<grupo>[/todo]: las CARD_MAX primeras tarjetas que se enseñan y «Más…» (o, whole, todas)"""
    import xbmcgui
    import xbmcplugin
    import flix_sections_own as so
    from ker0n3 import avail, handlers, lists, router
    items = so.cards(group)
    if not items:
        handlers.log("tarjetas desconocidas: %s" % group)
        handlers._end(handle, "", ok=False)
        return
    cache = cache or lists.default_cache()
    solo = avail.solo_esp() if solo is None else solo
    vis = [c for c in items if shows(state(c["key"], cache, now), solo)]
    used(group + ("/todo" if whole else ""), cache, now)
    top = vis if whole else vis[:so.CARD_MAX]
    for c in top:
        url = router.url_list(c["key"], whole=True)     # la tarjeta abre su lista entera (sección de una fila)
        li = xbmcgui.ListItem(c["label"], path=url)
        if c["art"]:
            li.setArt(c["art"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    if not whole and len(vis) > len(top):
        more = router.url_cards(group, whole=True)
        xbmcplugin.addDirectoryItem(handle, more, xbmcgui.ListItem(lists.MORE, path=more), isFolder=True)
    handlers.log("tarjetas %s%s: %d de %d" % (group, " (todas)" if whole else "", len(top), len(items)))
    handlers._end(handle, "")


def used(group, cache, now=time.time):
    from ker0n3 import lists
    if cache.get(USED + group, lists.USED_EVERY, now=now) is None:
        cache.put(USED + group, {"t": now()}, now=now)


def due(cache, now=time.time, retry=None, solo=False):
    """(clave, grupo) de la primera tarjeta por comprobar de las filas de tarjetas pedidas en la semana (en el orden
    de la fila); None si todas están al día"""
    import flix_sections_own as so
    from ker0n3 import lists
    for ug in cache.keys(USED):
        if cache.get(ug, lists.USED_KEEP, now=now) is None:
            continue
        group, whole = so.parse(so.CARDS + ug[len(USED):])
        for key in so.card_keys(group, whole):
            if (retry or {}).get(key, 0) > now():
                continue
            if needs_check(state(key, cache, now), solo):
                return key, group
    return None


def check(key, cache=None, tcache=None, should_stop=None, now=time.time, sheets=None, many=None, solo=None,
          fetch=None):
    """comprueba la lista de una tarjeta hasta dar con un título que se enseñe (lists.check_chunk: misma caché y mismas
    reglas que las filas). Guarda C/<clave> y devuelve lo guardado; None si no se pudo saber (sin red, cortado)"""
    from ker0n3 import avail, lists, personal
    cache, tcache = cache or lists.default_cache(), lists._tcache(tcache)
    sheets, many = sheets or personal.sheets, many or avail.many
    stop = should_stop or (lambda: False)
    solo = avail.solo_esp() if solo is None else solo
    todo = cache.get("L/" + key, lists.LIST_TTL, now=now)       # la lista ya guardada (tarjeta abierta), si la hay
    if todo is None:
        try:
            todo = (fetch or (lambda k: lists._fetcher(k)(k, pages=1)))(key)[:lists.MAX_ENTRIES]
        except Exception as e:  # noqa: BLE001  (sin red: otra vez será)
            log("%s: no llega la lista (%s)" % (key, type(e).__name__))
            return None

    def one(kind, tmdb, last=None):
        return avail.check(kind, tmdb, last, cache=tcache, now=now)
    ok = esp = False
    checked = unknown = 0
    cut = False
    for n, i in enumerate(range(0, len(todo), lists.CHUNK)):
        if esp or (ok and not solo):
            break
        if n >= MAX_CHUNKS or stop():
            cut = True
            break
        chunk = todo[i:i + lists.CHUNK]
        res = lists.check_chunk(chunk, sheets, many, one, stop)
        for e in chunk:
            a = res.get((e["kind"], e["tmdb"]))
            checked += 1
            if a is None:
                unknown += 1
            elif a.get("ok"):
                ok = True
                esp = esp or bool(a.get("esp", True))
    complete = not cut and checked == len(todo) and unknown * 10 <= checked
    if not ok and not complete and (stop() or checked == 0 or unknown * 10 > checked):
        return None                         # cortado, o sin poder preguntar: no se sabe nada nuevo
    st = {"t": now(), "ok": True if ok else (False if complete else None),
          "esp": True if esp else (False if complete else None)}
    cache.put(STATE + key, st, now=now)
    return st


def job(home, st, should_stop, now=time.time, cache=None, tcache=None, check_fn=None):
    """un trabajo del servicio con las tarjetas (cuando no hay listas que repasar): hasta BATCH tarjetas o BATCH_BUDGET
    s. Si lo que enseña una fila de tarjetas cambia, se avisa a la skin. Devuelve las claves comprobadas"""
    from ker0n3 import avail, lists
    solo = avail.solo_esp()
    done, changed, t0 = [], set(), now()
    while len(done) < BATCH and now() - t0 < BATCH_BUDGET and not should_stop():
        nxt = due(cache, now, st["retry"], solo)
        if not nxt:
            break
        key, group = nxt
        before = shows(state(key, cache, now), solo)
        got = (check_fn or check)(key, cache, tcache, should_stop=should_stop, now=now, solo=solo)
        done.append(key)
        if got is None:
            st["retry"][key] = now() + CHECK_TTL / 4        # sin saber: dentro de unas horas (no cada vuelta)
            continue
        st["retry"].pop(key, None)
        if shows(got, solo) != before:
            changed.add(rev_key(group))
    for k in sorted(changed):
        lists.signal(home, k, now)
    if done:
        log("%d tarjetas comprobadas%s" % (len(done), (", avisadas: " + ", ".join(sorted(changed))) if changed else ""))
    return done


def refilter(home, cache, now=time.time):
    """el interruptor «Solo en castellano» cambió: las filas de tarjetas en uso se vuelven a pedir"""
    from ker0n3 import lists
    keys = sorted({rev_key(ug[len(USED):]) for ug in cache.keys(USED)
                   if cache.get(ug, lists.USED_KEEP, now=now) is not None})
    for k in keys:
        lists.signal(home, k, now)
    return keys
