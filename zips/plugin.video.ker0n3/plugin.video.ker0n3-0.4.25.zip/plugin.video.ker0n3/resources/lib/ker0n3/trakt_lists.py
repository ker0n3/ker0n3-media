"""Listas de Trakt para la sección Trakt de la skin (bloques 4 y 5; 17-nov). SOLO LECTURA: GET
/users/me/lists, /users/me/lists/<id>/items/movie,show y /sync/watchlist/<movies|shows>. El servicio deja en
trakt_listas.json si Trakt es el servicio en uso, sus listas personales y cuántos tiene en la watchlist (la skin lo
lee sin red: flix_rows.k3_trakt_lists). Cada lista es la ruta lista/trakt-<id> y la watchlist lista/trakt-watchlist-
<pelis|series> (lists.py, con la regla de lo que se enseña). Los favoritos de la skin son los «Favorites» de Trakt
(trakt_sync, base propia): su fila es favoritos/<tipo>, no esto."""
import json
import os
import re
import time

REFRESH = 6 * 3600          # las listas de la cuenta, como mucho cada tanto
KEY_RE = re.compile(r"^trakt-(\d+|watchlist-(pelis|series))$")
WATCHLIST = {"pelis": "movies", "series": "shows"}


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.trakt_lists] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def path():
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/trakt_listas.json")


def load(p=None):
    try:
        with open(p or path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(data, p=None):
    p = p or path()
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tmp = "%s.%d.tmp" % (p, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, p)


def _fetch():
    """(listas personales [{id, name, n}], {"pelis": n, "series": n} de la watchlist). Excepción = red o sin acceso"""
    from ker0n3 import trakt
    out = []
    for x in trakt.get("/users/me/lists") or []:
        ids = (x or {}).get("ids") or {}
        if str(ids.get("trakt", "")).isdigit() and str(x.get("name") or "").strip():
            out.append({"id": int(ids["trakt"]), "name": str(x["name"]).strip(), "n": int(x.get("item_count") or 0)})
    wl = {k: len(trakt.watchlist(v)) for k, v in WATCHLIST.items()}
    return out, wl


def refresh(p=None, now=time.time, active=None, fetch=None):
    """con Trakt en uso, sus listas en el fichero (cada REFRESH como mucho; sin red, se queda lo de antes); sin él,
    {"on": False} al momento y sin red. Devuelve lo escrito, o None si no tocaba o falló. Nunca lanza"""
    try:
        if active is None:
            from ker0n3 import syncsvc
            active = syncsvc.active()
        cur = load(p)
        if active != "trakt":
            if cur.get("on") is False:
                return None
            data = {"on": False, "t": now()}
            _save(data, p)
            return data
        if cur.get("on") and now() - float(cur.get("t") or 0) < REFRESH:
            return None
        lists, wl = (fetch or _fetch)()
        data = {"on": True, "t": now(), "lists": lists, "watchlist": wl}
        _save(data, p)
        log("%d listas de la cuenta; watchlist %s" % (len(lists), wl))
        return data
    except Exception as e:  # noqa: BLE001
        log("listas sin refrescar: %s" % type(e).__name__)
        return None


def _entries(data):
    out = []
    for it in data or []:
        if not isinstance(it, dict):
            continue
        typ = it.get("type") or ("movie" if "movie" in it else "show" if "show" in it else "")
        kind = {"movie": "movie", "show": "tv"}.get(typ)
        tmdb = str(((it.get(typ) or {}).get("ids") or {}).get("tmdb") or "") if kind else ""
        if kind and tmdb.isdigit() and not any(e["tmdb"] == int(tmdb) and e["kind"] == kind for e in out):
            out.append({"tmdb": int(tmdb), "kind": kind})
    return out


def items(key, get_list=None, watchlist=None):
    """entradas de la lista trakt-<id> o trakt-watchlist-<pelis|series> ({tmdb, kind}, en el orden de la cuenta;
    las fichas las pone la ruta). Excepción = red o sin acceso (lists.entries se queda con lo guardado)"""
    m = KEY_RE.match(key or "")
    if not m:
        return []
    from ker0n3 import trakt
    if m.group(2):
        return _entries((watchlist or trakt.watchlist)(WATCHLIST[m.group(2)]))
    get_list = get_list or trakt.get_list
    return _entries(get_list("/users/me/lists/%s/items/movie,show" % m.group(1)))


# ---------- añadir / quitar / crear desde la pulsación larga (18-nov, Carlos) ----------
LIMIT = 420         # Trakt: límite de la cuenta (listas o títulos por lista de una cuenta gratis)


def mine(p=None):
    """tus listas personales [{id, name, n}] de lo guardado (refresh las pone al día); [] sin Trakt"""
    d = load(p)
    return [x for x in d.get("lists") or [] if isinstance(x, dict) and x.get("id")] if d.get("on") else []


def _cache(cache=None):
    if cache is not None:
        return cache
    from ker0n3 import lists
    return lists.default_cache()


def members(list_id, cache=None):
    """{(kind, tmdb)} de lo guardado de la lista (lo que enseña su fila, aunque haya caducado; sin red)"""
    ents = _cache(cache).get("L/trakt-%d" % int(list_id), 0, stale=True) or []
    return {(e.get("kind"), int(e.get("tmdb"))) for e in ents if isinstance(e, dict) and str(e.get("tmdb", "")).isdigit()}


def _body(kind, tmdb):
    return {"movies" if kind == "movie" else "shows": [{"ids": {"tmdb": int(tmdb)}}]}


def _signal(key):
    """aviso a la skin de que la lista cambió (lists.signal: el Inicio de la TV y las filas táctiles la vuelven a
    pedir). Nunca lanza"""
    try:
        import xbmcgui
        from ker0n3 import lists
        lists.signal(xbmcgui.Window(10000), key)
    except Exception:  # noqa: BLE001
        pass


def _touch(list_id, kind, tmdb, added, cache=None, p=None, now=time.time):
    """lo guardado, al día sin esperar a Trakt: la fila de la lista y su recuento"""
    c = _cache(cache)
    key = "L/trakt-%d" % int(list_id)
    ents = [e for e in (c.get(key, 0, stale=True) or []) if not (e.get("kind") == kind and e.get("tmdb") == int(tmdb))]
    if added:
        ents = [{"tmdb": int(tmdb), "kind": kind}] + ents
    c.put(key, ents, now=now)
    try:
        c.flush()
    except Exception:  # noqa: BLE001
        pass
    d = load(p)
    for x in d.get("lists") or []:
        if x.get("id") == int(list_id):
            x["n"] = max(0, int(x.get("n") or 0) + (1 if added else -1))
    if d:
        _save(d, p)
    _signal("trakt-%d" % int(list_id))


def add(list_id, kind, tmdb, post=None, cache=None, p=None):
    """añade la película (kind movie) o la serie (tv) a la lista. TraktError si Trakt no lo acepta"""
    from ker0n3 import trakt
    (post or trakt.post)("/users/me/lists/%d/items" % int(list_id), _body(kind, tmdb))
    _touch(list_id, kind, tmdb, True, cache, p)
    log("añadido %s %s a la lista %s" % (kind, tmdb, list_id))


def remove(list_id, kind, tmdb, post=None, cache=None, p=None):
    from ker0n3 import trakt
    (post or trakt.post)("/users/me/lists/%d/items/remove" % int(list_id), _body(kind, tmdb))
    _touch(list_id, kind, tmdb, False, cache, p)
    log("quitado %s %s de la lista %s" % (kind, tmdb, list_id))


def create(name, post=None, p=None, now=time.time):
    """crea una lista privada en tu Trakt y la guarda; devuelve su id. TraktError si no se puede (LIMIT: cuenta)"""
    from ker0n3 import trakt
    r = (post or trakt.post)("/users/me/lists", {"name": name, "privacy": "private"}) or {}
    lid = int(((r.get("ids") or {}).get("trakt")) or 0)
    if not lid:
        raise trakt.TraktError("otro", "Trakt no devolvió la lista nueva")
    d = load(p) or {"on": True, "t": now(), "lists": [], "watchlist": {}}
    d.setdefault("lists", []).append({"id": lid, "name": name, "n": 0})
    _save(d, p)
    log("lista nueva «%s» (%d)" % (name, lid))
    return lid


def delete_list(list_id, call=None, cache=None, p=None, now=time.time):
    """borra la lista entera de tu Trakt (19-nov, Carlos) y lo guardado de ella. TraktError si Trakt no lo acepta"""
    from ker0n3 import trakt
    (call or trakt.request)("DELETE", "/users/me/lists/%d" % int(list_id))
    d = load(p)
    if d:
        d["lists"] = [x for x in d.get("lists") or [] if not (isinstance(x, dict) and x.get("id") == int(list_id))]
        _save(d, p)
    c = _cache(cache)
    c.put("L/trakt-%d" % int(list_id), [], now=now)
    try:
        c.flush()
    except Exception:  # noqa: BLE001
        pass
    _signal("trakt-%d" % int(list_id))
    log("lista %s borrada" % list_id)


# la watchlist de Trakt, como una lista más del menú (Carlos no tenía listas personales: solo ella)
WATCHLIST_ID = 0


def wl_key(kind):
    return "trakt-watchlist-" + ("pelis" if kind == "movie" else "series")


def in_watchlist(kind, tmdb, cache=None):
    ents = _cache(cache).get("L/" + wl_key(kind), 0, stale=True) or []
    return any(e.get("kind") == kind and e.get("tmdb") == int(tmdb) for e in ents if isinstance(e, dict))


def watchlist_set(kind, tmdb, on, post=None, cache=None, now=time.time, p=None):
    """añade (on) o quita el título de la watchlist de Trakt, y lo guardado al día (también su recuento: la sección
    Trakt no enseña la fila de una watchlist vacía, y el servicio solo lo repasa cada REFRESH)"""
    from ker0n3 import trakt
    (post or trakt.post)("/sync/watchlist" + ("" if on else "/remove"), _body(kind, tmdb))
    c = _cache(cache)
    key = "L/" + wl_key(kind)
    old = c.get(key, 0, stale=True)
    ents = [e for e in (old or []) if not (e.get("kind") == kind and e.get("tmdb") == int(tmdb))]
    new = ([{"tmdb": int(tmdb), "kind": kind}] if on else []) + ents
    c.put(key, new, now=now)
    try:
        c.flush()
    except Exception:  # noqa: BLE001
        pass
    d = load(p)
    if d.get("on"):
        cat = "pelis" if kind == "movie" else "series"
        wl = d["watchlist"] if isinstance(d.get("watchlist"), dict) else {}
        if old is not None:                 # la lista guardada: el recuento exacto
            wl[cat] = len(new)
        elif isinstance(wl.get(cat), int):  # sin ella: el de antes ±1 (sin saber cuántos: se queda sin saber)
            wl[cat] = max(0, wl[cat] + (1 if on else -1))
        elif on:
            wl[cat] = 1
        d["watchlist"] = wl
        _save(d, p)
    _signal(wl_key(kind))
    log("%s %s %s la watchlist" % (kind, tmdb, "a" if on else "fuera de"))
