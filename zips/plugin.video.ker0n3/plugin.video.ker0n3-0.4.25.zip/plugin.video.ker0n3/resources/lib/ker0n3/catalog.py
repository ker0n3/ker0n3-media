"""Catálogo de TMDB para Ker0n3, con caché en disco (parte 2b+2c; 15-nov)"""
import atexit
import copy
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/"
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
TTL_SHEET, TTL_SEASON, TTL_SEARCH = 7 * 86400, 86400, 86400
MAX_AGE = 8 * 86400    # la caché poda lo más viejo al escribir


class Cache:
    """{clave: [hora, valor]} en un JSON; escritura atómica y segura entre procesos (Kodi lanza cada ruta del plugin
    como proceso aparte, a veces varios a la vez): al escribir se relee el disco y se mezcla, gana lo más nuevo.
    put guarda en memoria; flush escribe el disco UNA vez con todo lo pendiente (router.run lo llama al acabar cada
    ruta; atexit, de respaldo, por si nadie lo llama)"""

    def __init__(self, path):
        self.path, self.lock, self.data, self.dirty = path, threading.Lock(), None, {}
        self.hooked = False

    def _read_disk(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _mtime(self):
        try:
            return os.stat(self.path).st_mtime_ns
        except OSError:
            return None

    def _load(self):
        if self.data is None:
            self.mtime, self.read_at = self._mtime(), time.time()
            self.data = self._read_disk()
        return self.data

    def reload_if_changed(self, min_age=0, now=time.time):
        """relee el disco si otro proceso lo cambió desde la última lectura (20-nov: la skin usa la caché en su propio
        proceso, que vive horas; el addon y su servicio no lo necesitan). min_age: no antes de esos s desde la última
        lectura (el servicio la reescribe cada pocos segundos y releer 6,5 MB eran ~0,3 s del clic en la Shield). Lo
        pendiente de aquí se conserva"""
        with self.lock:
            if self.data is None:
                return
            if min_age and now() - getattr(self, "read_at", 0) < min_age:
                return
            m = self._mtime()
            if m == getattr(self, "mtime", None):
                return
            self.mtime, self.data, self.read_at = m, self._read_disk(), now()
            for k, v in self.dirty.items():
                self.data[k] = v

    def get(self, key, ttl, now=time.time, stale=False):
        """copia del valor si no ha caducado (stale=True: aunque haya caducado)"""
        with self.lock:
            hit = self._load().get(key)
            if isinstance(hit, list) and len(hit) == 2 and (stale or now() - hit[0] < ttl):
                return copy.deepcopy(hit[1])
        return None

    def keys(self, prefix=""):
        """claves guardadas que empiezan así (caducadas o no)"""
        with self.lock:
            return [k for k in self._load() if k.startswith(prefix)]

    def put(self, key, value, now=time.time):
        """en memoria (se lee ya) hasta flush; nunca lanza"""
        with self.lock:
            try:
                entry = [now(), copy.deepcopy(value)]
            except Exception:  # noqa: BLE001  (valor que no se puede copiar: no se guarda)
                return
            self._load()[key] = entry
            self.dirty[key] = entry
            if not self.hooked:
                self.hooked = True
                atexit.register(self.flush)

    def flush(self):
        """escribe lo pendiente mezclado con el disco (atómico); nunca lanza: si no se puede, no se guarda"""
        with self.lock:
            if not self.dirty:
                return
            pending, self.dirty = self.dirty, {}
            tmp = "%s.%d.%d.tmp" % (self.path, os.getpid(), threading.get_ident())
            try:
                t = max(v[0] for v in pending.values())      # la poda, respecto a lo más nuevo que se guarda
                merged = dict(self._load())
                for k, v in self._read_disk().items():
                    if isinstance(v, list) and len(v) == 2 and (
                            k not in merged or not isinstance(merged[k], list) or v[0] > merged[k][0]):
                        merged[k] = v
                for k, v in pending.items():                  # lo de este proceso, salvo que el disco tenga algo más nuevo
                    if not (isinstance(merged.get(k), list) and merged[k][0] > v[0]):
                        merged[k] = v
                merged = {k: v for k, v in merged.items()
                          if isinstance(v, list) and len(v) == 2 and t - v[0] <= MAX_AGE}
                os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(merged, f)
                os.replace(tmp, self.path)
                self.data = merged
            except (OSError, ValueError, TypeError):
                try:
                    os.remove(tmp)
                except OSError:
                    pass

    def refresh(self):
        """para el servicio, que vive horas: guarda lo pendiente y suelta la copia en memoria, para que la siguiente
        lectura vea lo que hayan escrito las rutas del addon (otros procesos). Nunca lanza"""
        self.flush()
        with self.lock:
            if not self.dirty:
                self.data = None


_DEFAULT = []
TMP_AGE = 3600      # s: un .tmp de guardado así de viejo ya no lo está escribiendo nadie


def clean_tmp(folder, max_age=TMP_AGE, now=time.time):
    """borra los .tmp de guardado a medias (listas.json.<pid>.<hilo>.tmp, tmdb.json…) que deja Kodi cerrado de golpe
    mientras se escribía la caché (23-nov: 3 de listas, ~10 MB, en la Shield). Solo los de más de max_age s: uno
    reciente puede estar escribiéndose. Devuelve cuántos; nunca lanza"""
    n = 0
    try:
        names = os.listdir(folder)
    except OSError:
        return 0
    for name in names:
        if not name.endswith(".tmp"):
            continue
        p = os.path.join(folder, name)
        try:
            if os.path.isfile(p) and now() - os.path.getmtime(p) > max_age:
                os.remove(p)
                n += 1
        except OSError:
            pass
    return n


def flush_default():
    """guarda la caché de la ruta (si se llegó a crear); nunca lanza"""
    if _DEFAULT:
        try:
            _DEFAULT[0].flush()
        except Exception:  # noqa: BLE001
            pass


def default_cache():
    if not _DEFAULT:
        import xbmcvfs
        _DEFAULT.append(Cache(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/tmdb.json")))
    return _DEFAULT[0]


def _get(path, params=None, opener=None):
    from flix_common import TMDB_KEY
    q = {"api_key": TMDB_KEY, "language": "es-ES"}
    q.update(params or {})
    req = urllib.request.Request("%s%s?%s" % (API, path, urllib.parse.urlencode(q)), headers={"User-Agent": UA})
    with (opener or urllib.request.urlopen)(req, timeout=10) as r:
        return json.loads(r.read().decode())


def _img(p, size):
    return IMG + size + p if p else ""


def _year(d):
    return int(d[:4]) if d and d[:4].isdigit() else 0


def logo_url(url):
    """el logo en PNG: TMDB da algunos en SVG (Naruto, 20-nov) y Kodi no los pinta; la ficha escondía además el nombre
    (hay logo). TMDB sirve el mismo logo en PNG cambiando la extensión. Vale también para lo ya guardado"""
    url = url or ""
    return url[:-4] + ".png" if url.lower().endswith(".svg") else url


def _logo(images):
    logos = (images or {}).get("logos") or []
    for lang in ("es", None, "en"):
        for l in logos:
            if l.get("iso_639_1") == lang and l.get("file_path"):
                return logo_url(_img(l["file_path"], "w500"))
    return logo_url(_img(logos[0].get("file_path"), "w500")) if logos else ""


def _common(d, kind):
    title = d.get("title") or d.get("name") or ""
    date = d.get("release_date") or d.get("first_air_date") or ""
    return {"kind": kind, "tmdb": d.get("id"), "title": title,
            "original_title": d.get("original_title") or d.get("original_name") or title, "plot": d.get("overview") or "",
            "year": _year(date), "premiered": date, "genres": [g.get("name") for g in d.get("genres") or [] if g.get("name")],
            "rating": float(d.get("vote_average") or 0), "votes": int(d.get("vote_count") or 0),
            "poster": _img(d.get("poster_path"), "w500"), "fanart": _img(d.get("backdrop_path"), "w1280"),
            "clearlogo": _logo(d.get("images"))}


_REFRESHING, _REFRESHING_LOCK = set(), threading.Lock()


def _refresh_later(cache, key, fetch):
    """pide de nuevo por detrás lo caducado (una vez por clave a la vez) y lo guarda; nunca lanza"""
    with _REFRESHING_LOCK:
        if key in _REFRESHING:
            return
        _REFRESHING.add(key)

    def run():
        try:
            cache.put(key, fetch())
            cache.flush()
        except Exception:  # noqa: BLE001  (sin red: se queda lo guardado y se pedirá otra vez)
            pass
        finally:
            with _REFRESHING_LOCK:
                _REFRESHING.discard(key)
    threading.Thread(target=run, name="k3_refresh_%s" % key, daemon=True).start()


def _cached(cache, key, ttl, fetch, valid=None, stale_ok=False):
    """valid(valor): False = lo guardado es de una versión anterior de la ficha (le faltan campos): se pide otra vez;
    sin red vale igual (mejor la vieja que nada). stale_ok (20-nov, la skin al pulsar una serie: Frieren y Off Campus
    tardaban 2 s pidiendo a TMDB su ficha caducada): lo caducado se devuelve YA y se renueva por detrás; sin nada
    guardado, se pide como siempre"""
    cache = cache or default_cache()
    hit = cache.get(key, ttl)
    if hit is not None and (valid is None or valid(hit)):
        return hit
    if stale_ok:
        old = cache.get(key, ttl, stale=True)
        if old is not None and (valid is None or valid(old)):
            _refresh_later(cache, key, fetch)
            return old
    try:
        value = fetch()
    except (urllib.error.URLError, OSError, ValueError):     # HTTPError y timeout son OSError/URLError
        old = cache.get(key, ttl, stale=True)
        if old is not None:
            return old      # sin red: mejor lo caducado que nada
        raise
    cache.put(key, value)   # put no lanza; si no guarda, se devuelve igual
    return value


def _imdb(d):
    """id de IMDb que trae la ficha (append external_ids, 21-nov: la misma respuesta que /external_ids, sin otra
    petición por título al comprobar en el buscador); "" si TMDB no lo tiene"""
    return ((d.get("external_ids") or {}).get("imdb_id") or "").strip()


def sheet_imdb(kind, tmdb, cache=None):
    """el id de IMDb de la ficha guardada (de la edad que sea: no cambia), sin red; "" si no está o es de antes del
    21-nov (sin «imdb»). Nunca lanza"""
    try:
        key = ("m%s" if kind == "movie" else "tv%s") % tmdb
        hit = (cache or default_cache()).get(key, TTL_SHEET if kind == "movie" else TTL_SEASON, stale=True)
        return (hit or {}).get("imdb") or ""
    except Exception:  # noqa: BLE001
        return ""


def movie(tmdb, opener=None, cache=None):
    def fetch():
        d = _get("/movie/%s" % tmdb, {"append_to_response": "images,release_dates,external_ids",
                                      "include_image_language": "es,null,en"}, opener)
        out = _common(d, "movie")
        out["duration"] = int(d.get("runtime") or 0) * 60
        cert = ""
        for r in (d.get("release_dates") or {}).get("results") or []:
            if r.get("iso_3166_1") == "ES":
                cert = next((x.get("certification") for x in r.get("release_dates") or [] if x.get("certification")), "")
        out["mpaa"] = cert
        # 16-nov, enlaces falsos (flix_src_check): fechas de estreno (cines / doméstico) e idioma original. Van con
        # la ficha: se piden en el repaso por detrás o al comprobar una búsqueda, nunca al pintar
        import flix_src_check
        out["rel"] = flix_src_check.release_info(d)
        out["lang"] = d.get("original_language") or ""
        out["imdb"] = _imdb(d)
        return out
    return _cached(cache, "m%s" % tmdb, TTL_SHEET, fetch, valid=lambda hit: "rel" in hit and "lang" in hit)


TTL_HALF = 3600     # s que vale una ficha de serie a medias (half_done)
HALF_DAYS = 7       # días tras estrenarse una temporada en que su ficha puede estar a medias


def half_done(sheet, today=None):
    """¿ficha de serie a medias? Una temporada estrenada en los últimos HALF_DAYS días y TMDB aún sin «último
    capítulo emitido» o sin id de IMDb: pasa las primeras horas tras un estreno (lo rellenan a mano). Las series
    antiguas que nunca tendrán IMDb no cuentan: no se piden cada hora"""
    today = today or time.strftime("%Y-%m-%d")
    since = time.strftime("%Y-%m-%d", time.localtime(time.mktime(time.strptime(today, "%Y-%m-%d"))
                                                     - HALF_DAYS * 86400))
    recent = any(x.get("air_date") and since <= x["air_date"] <= today for x in sheet.get("seasons") or [])
    return recent and (not sheet.get("last_aired") or not sheet.get("imdb"))


def last_aired_guess(sheet, today=None):
    """el último capítulo emitido según la ficha; si TMDB aún no lo dice pero hay temporada estrenada (half_done), el
    1.º de la última estrenada (su fecha es la de ese capítulo). None si no hay nada estrenado"""
    if sheet.get("last_aired"):
        return tuple(sheet["last_aired"])
    today = today or time.strftime("%Y-%m-%d")
    aired = [x.get("n") for x in sheet.get("seasons") or [] if x.get("air_date") and x["air_date"] <= today and x.get("n")]
    return (max(aired), 1) if aired else None


def show(tmdb, opener=None, cache=None, today=None, stale_ok=False):
    """TTL de 1 día a propósito (TTL_SEASON): last_aired cambia con cada capítulo nuevo, a diferencia de la película (7 días).
    Solo temporadas ya estrenadas (con fecha y no posterior a hoy): la caché las guarda todas y se filtran al leer"""
    today = today or time.strftime("%Y-%m-%d")

    def fetch():
        d = _get("/tv/%s" % tmdb, {"append_to_response": "images,content_ratings,external_ids",
                                   "include_image_language": "es,null,en"}, opener)
        out = _common(d, "tv")
        rt = d.get("episode_run_time") or []
        mins = rt[0] if rt else (d.get("last_episode_to_air") or {}).get("runtime")
        out["duration"] = int(mins or 0) * 60
        out["mpaa"] = next((r.get("rating") for r in (d.get("content_ratings") or {}).get("results") or []
                            if r.get("iso_3166_1") == "ES" and r.get("rating")), "")
        out["seasons"] = [{"n": s.get("season_number"), "name": s.get("name") or "Temporada %s" % s.get("season_number"),
                           "episodes": int(s.get("episode_count") or 0), "poster": _img(s.get("poster_path"), "w500"),
                           "plot": s.get("overview") or "", "year": _year(s.get("air_date") or ""),
                           "air_date": s.get("air_date") or ""}
                          for s in d.get("seasons") or [] if (s.get("season_number") or 0) > 0]
        last = d.get("last_episode_to_air") or {}
        out["last_aired"] = (last.get("season_number"), last.get("episode_number")) if last.get("season_number") else None
        out["lang"] = d.get("original_language") or ""      # idioma original (flix_src_check, 16-nov)
        out["imdb"] = _imdb(d)
        return out
    # «tv»: con air_date en cada temporada (las de antes, con clave «t», no la traían y se quedarían sin temporadas)
    cache = cache or default_cache()
    key = "tv%s" % tmdb

    def valid(hit):
        # ficha a medias de una serie recién estrenada (21-nov, «El camino azul» en el S24: guardada a la hora del
        # estreno, sin último capítulo emitido ni IMDb, valía 1 día y la serie daba «sin versión» sin preguntar a
        # nadie): vale solo TTL_HALF; luego se pide otra vez
        return "lang" in hit and not (half_done(hit, today) and cache.get(key, TTL_HALF) is None)
    s = _cached(cache, key, TTL_SEASON, fetch, valid=valid, stale_ok=stale_ok)
    if s.get("last_aired") is not None:     # s es copia: no se toca lo guardado
        s["last_aired"] = tuple(s["last_aired"])
    every = s.get("seasons") or []
    s["seasons"] = [x for x in every if x.get("air_date") and x["air_date"] <= today]
    # las que aún no se han estrenado (con fecha posterior o sin fecha): no salen en la ficha; «Al día» dice cuándo
    # llega la siguiente (series.state)
    s["upcoming"] = [{"n": x.get("n"), "air_date": x.get("air_date") or ""} for x in every
                     if not (x.get("air_date") and x["air_date"] <= today)]
    return s


def season_all(tmdb, season, opener=None, cache=None):
    """todos los capítulos de la temporada según TMDB, también los que aún no se han emitido (premiered posterior a
    hoy o vacío)"""
    def fetch():
        d = _get("/tv/%s/season/%s" % (tmdb, season), None, opener)
        return [{"n": e.get("episode_number"), "title": e.get("name") or "", "plot": e.get("overview") or "",
                 "still": _img(e.get("still_path"), "w780"), "premiered": e.get("air_date") or "",
                 "duration": int(e.get("runtime") or 0) * 60, "rating": float(e.get("vote_average") or 0)}
                for e in d.get("episodes") or []]
    return _cached(cache, "s%s/%s" % (tmdb, season), TTL_SEASON, fetch)


def season_cached(tmdb, season, cache=None):
    """lo mismo, solo de lo guardado (tenga la edad que tenga: las fechas no caducan) y sin red; None si no hay.
    Para lo que no puede esperar: qué capítulo toca al abrir la serie (series.state)"""
    return (cache or default_cache()).get("s%s/%s" % (tmdb, season), TTL_SEASON, stale=True)


def episodes(tmdb, season, opener=None, cache=None, today=None):
    today = today or time.strftime("%Y-%m-%d")
    return [e for e in season_all(tmdb, season, opener, cache) if e["premiered"] and e["premiered"] <= today]


def search(text, kind, opener=None, cache=None):
    def fetch():
        d = _get("/search/%s" % kind, {"query": text, "include_adult": "false"}, opener)
        out = []
        for x in d.get("results") or []:
            date = x.get("release_date") or x.get("first_air_date") or ""
            out.append({"kind": kind, "tmdb": x.get("id"), "title": x.get("title") or x.get("name") or "",
                        "year": _year(date), "plot": x.get("overview") or "", "poster": _img(x.get("poster_path"), "w500"),
                        "fanart": _img(x.get("backdrop_path"), "w1280"), "rating": float(x.get("vote_average") or 0),
                        "genre_ids": x.get("genre_ids") or [], "popularity": float(x.get("popularity") or 0),
                        "votes": int(x.get("vote_count") or 0)})
        return out
    return _cached(cache, "q%s/%s" % (kind, text.strip().lower()), TTL_SEARCH, fetch)
