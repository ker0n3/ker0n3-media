"""Aviso diario del addon para las estadísticas de Carlos (17-nov; el de la skin es flix_ping.py): una vez al día
manda la versión del addon con el MISMO id anónimo del aparato que la skin (addon_data/<skin>/device_id), así el
Worker no cuenta el aparato dos veces y enseña qué addon lleva cada uno. Sin id de la skin, no se avisa (no se
inventa otro). Va por xbmcvfs (el Worker saca la plataforma del User-Agent de Kodi); un fallo no importa: ese día
no se cuenta. Los Kodi de pruebas llevan KER0N3_SIN_AVISO=1."""
import datetime
import os

URL = "https://ker0n3-media.ker0n3.workers.dev/ping"
DAY_FILE = "ping_day"


def ping_url(device, version):
    return "%s?d=%s&s=addon&v=%s" % (URL, device, version)


def skin_device(folder):
    """el id de la skin (32 hex) o None"""
    try:
        with open(os.path.join(folder, "device_id"), encoding="utf-8") as fh:
            d = fh.read().strip()
    except OSError:
        return None
    return d if len(d) == 32 and all(c in "0123456789abcdef" for c in d) else None


def due(day_path, today):
    try:
        with open(day_path, encoding="utf-8") as fh:
            return fh.read().strip() != today
    except OSError:
        return True


def send(skin_folder, day_path, version, opener, today=None, env=os.environ):
    """True si se mandó hoy. opener(url): lo abre (xbmcvfs.File en Kodi)"""
    if env.get("KER0N3_SIN_AVISO"):
        return False
    today = today or datetime.date.today().isoformat()
    if not due(day_path, today):
        return False
    device = skin_device(skin_folder)
    if not device:
        return False
    try:
        os.makedirs(os.path.dirname(day_path), exist_ok=True)
        with open(day_path, "w", encoding="utf-8") as fh:      # como mucho un intento al día
            fh.write(today)
    except OSError:
        return False
    try:
        opener(ping_url(device, version))
    except Exception:  # noqa: BLE001
        return False
    return True


def main():
    import xbmc
    import xbmcaddon
    import xbmcvfs

    def opener(url):
        f = xbmcvfs.File(url)
        f.read()
        f.close()
    skin = xbmcvfs.translatePath("special://profile/addon_data/%s/" % xbmc.getSkinDir())
    day = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/%s" % DAY_FILE)
    try:
        send(skin, day, xbmcaddon.Addon("plugin.video.ker0n3").getAddonInfo("version"), opener)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[ker0n3.ping] %s" % e, xbmc.LOGINFO)
