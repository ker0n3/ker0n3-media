"""Qué servicio sincroniza lo visto (16-nov). Diseño: docs/superpowers/specs/2026-11-16-trakt-propio-design.md.

Una base de vistos y UN servicio en uso a la vez: Trakt (el principal) o Simkl. Manda el elegido
(sync_service.json en addon_data de Ker0n3; lo apunta link.py al vincular o con «Usar para sincronizar») mientras
siga vinculado; si no, el que esté vinculado, Trakt antes. service.py, marks.py y sync.py preguntan aquí y no saben
cuál es."""
import json

NAMES = ("trakt", "simkl")      # por orden de preferencia


def module(name):
    if name == "trakt":
        from ker0n3 import trakt
        return trakt
    from ker0n3 import simkl
    return simkl


def choice_path():
    import xbmcvfs
    import flix_common
    return xbmcvfs.translatePath(flix_common.K3DATA_REL + "sync_service.json")


def chosen(path=None):
    try:
        with open(path or choice_path(), encoding="utf-8") as f:
            name = json.load(f).get("service")
    except (OSError, ValueError, AttributeError):
        return ""
    return name if name in NAMES else ""


def set_active(name, path=None):
    import flix_common
    if name not in NAMES:
        raise ValueError(name)
    flix_common.atomic_write(path or choice_path(), json.dumps({"service": name}))


def active(mods=None, path=None):
    """«trakt», «simkl» o «» (ninguno vinculado). mods: {nombre: módulo} para las pruebas"""
    def linked(name):
        try:
            return bool((mods[name] if mods else module(name)).linked())
        except Exception:  # noqa: BLE001
            return False
    name = chosen(path)
    if name and linked(name):
        return name
    for name in NAMES:
        if linked(name):
            return name
    return ""


def api(mods=None, path=None):
    """el módulo del servicio en uso, o None"""
    name = active(mods, path)
    return (mods[name] if mods else module(name)) if name else None


def linked():
    return bool(active())
