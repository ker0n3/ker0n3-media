"""Ajustes → «Cuentas» → «AllDebrid» (16-nov): vincular con el código de alldebrid.com/pin, comprobar la
cuenta o desvincular. Lo abre la skin con RunPlugin (proceso del addon, no el hilo de la interfaz), como Simkl
(link.py). La clave la guarda y la lee flix_alldebrid (alldebrid.json en addon_data de la skin en uso, la misma que
usa para reproducir) y de ahí no sale: ni al registro, ni a un diálogo, ni a una propiedad; en Skin.String solo va el
nombre de la cuenta. Desvincular borra ese fichero y nada más: en la cuenta de AllDebrid no se toca nada."""
import re
import time

HEADING = "AllDebrid"
USER = "k3_ad_user"             # Skin.String con la cuenta (Ajustes: «Ahora»); vacío = sin vincular
NONE, LINKED = "Sin vincular", "Vinculado"
POLL = 5                        # s entre preguntas a AllDebrid; cancelar se mira cada segundo
MAX_WAIT = 600                  # el código vale 10 min


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.adlink] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def code_text(code, url):
    """texto del diálogo del código (también Trakt y Simkl, link.py): primero el código, grande; debajo dónde se
    escribe. Antes iba al final y en el móvil quedaba debajo de la caja, que se desplaza y vuelve arriba (17-nov)"""
    return "[B]%s[/B][CR]Escríbelo en [B]%s[/B] desde el móvil o el ordenador." % (code, url)


def link(dlg, api, now=time.time, sleep=time.sleep):
    """muestra el código y espera a que se escriba en alldebrid.com/pin. «ok» (clave guardada), «cancelado» o
    «caducado». Un corte de red al preguntar no tumba la espera: se vuelve a preguntar"""
    d = api.pin_get()
    total = max(1, min(int(d.get("expires_in") or MAX_WAIT), MAX_WAIT))
    end = now() + total
    # el código arriba del todo: la caja del diálogo es baja (táctil ~4 líneas, TV 3) y lo de abajo se desplaza
    dlg.create(HEADING, code_text(d["pin"], "alldebrid.com/pin"))
    try:
        tick = 0
        while now() < end:
            sleep(1)
            tick += 1
            dlg.update(int(100 * max(0, end - now()) / total))
            if dlg.iscanceled():
                return "cancelado"
            if tick % POLL:
                continue
            try:
                key = api.pin_check(d["check"], d["pin"])
            except api.ADError as e:
                if e.kind == "caducado":
                    return "caducado"
                log("pregunto otra vez: %s" % e.kind)
                continue
            if key:
                api.save_key(key)
                return "ok"
        return "caducado"
    finally:
        dlg.close()


def safe_name(user):
    """el nombre sin lo que rompe un builtin (comas y paréntesis)"""
    return " ".join(re.sub(r"[,()]", " ", user or "").split())


def account(u):
    """lo que se apunta y se enseña de la cuenta: «nombre · premium hasta dd/mm/aaaa»"""
    name = safe_name((u or {}).get("username") or "")
    if not name:
        return LINKED
    try:
        until = int(u.get("premiumUntil") or 0)
    except (TypeError, ValueError):
        until = 0
    if not u.get("isPremium"):
        return name + " · sin premium"
    return name + (" · premium hasta " + time.strftime("%d/%m/%Y", time.localtime(until)) if until > 0 else " · premium")


def state(api, saved=""):
    """lo que dice Ajustes: manda la clave guardada, no lo apuntado"""
    return (saved or LINKED) if api.load_key() else NONE


def refresh(api, saved, run):
    """pone al día lo apuntado sin red (clave puesta a mano o borrada por fuera). Devuelve el estado"""
    st = state(api, saved)
    if st == NONE and saved:
        run("Skin.Reset(%s)" % USER)
    elif st != NONE and not saved:
        run("Skin.SetString(%s,%s)" % (USER, LINKED))
    return st


def _note(api, run):
    """pregunta la cuenta y la apunta; (texto, error): si no se puede leer, se queda «Vinculado»"""
    try:
        who, err = account(api.user()), None
    except api.ADError as e:
        log("no leo la cuenta: %s" % e.kind)
        who, err = LINKED, e.kind
    if err != "sin_clave":
        run("Skin.SetString(%s,%s)" % (USER, who))
    return who, err


def menu(handle=-1, api=None, dialog=None, run=None, progress=None, sleep=time.sleep):
    import xbmc
    import xbmcgui
    if api is None:
        import flix_alldebrid as api
    dialog = dialog or xbmcgui.Dialog()
    run = run or xbmc.executebuiltin
    if api.load_key():
        saved = xbmc.getInfoLabel("Skin.String(%s)" % USER)
        pick = dialog.select("AllDebrid: %s" % state(api, saved), ["Comprobar", "Desvincular"])
        if pick == 0:
            who, err = _note(api, run)
            if err == "sin_clave":
                dialog.ok(HEADING, "La clave guardada ya no vale. Desvincula y vuelve a vincular con un código nuevo.")
            elif err:
                dialog.ok(HEADING, "No he podido hablar con AllDebrid. Prueba otra vez en un momento.")
            else:
                dialog.ok(HEADING, "Cuenta: %s" % who.replace(" · premium hasta", "[CR]Premium hasta")
                          .replace(" · sin premium", "[CR]Sin premium: no se podrá reproducir"))
        elif pick == 1 and dialog.yesno(HEADING, "¿Desvincular AllDebrid en este aparato?[CR]Se borra la clave "
                                                 "guardada aquí; en tu cuenta de AllDebrid no se toca nada."):
            api.forget_key()
            run("Skin.Reset(%s)" % USER)
            log("AllDebrid desvinculado")
            dialog.notification(HEADING, "Desvinculado", time=3000)
        return
    try:
        result = link(progress or xbmcgui.DialogProgress(), api, sleep=sleep)
    except api.ADError as e:
        log("no vinculo: %s" % e.kind)
        dialog.ok(HEADING, "No he podido hablar con AllDebrid. Prueba otra vez en un momento.")
        return
    if result == "caducado":
        dialog.ok(HEADING, "El código ha caducado. Pide otro y escríbelo antes de 10 minutos.")
    if result != "ok":
        return
    who, _err = _note(api, run)
    log("AllDebrid vinculado")
    dialog.notification(HEADING, "Vinculado: %s" % who.split(" · ")[0] if who != LINKED else "Vinculado", time=4000)
