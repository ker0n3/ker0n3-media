"""Datos de más de una versión para «Elegir versión» (20-nov, Carlos: «sacar más info de las calidades, audio, etc.»):
idiomas del audio, subtítulos, tipo de copia, códec de vídeo, 10 bits, plataforma de origen y semillas. Todo sale del
texto que ya mandan las fuentes (nombre del torrent, fichero, banderas, el bingeGroup de Torrentio), sin pedir nada
más. Solo se ENSEÑAN: no cambian el orden ni cuál se elige sola, ni el castellano/latino (eso es flix_src_list, con
sus reglas: aquí el español no se decide, los idiomas de aquí son «los demás»).

Al leer las fuentes solo se guarda el texto (raw, en c["raw"]; add une el de dos fuentes con el mismo torrent en
flix_src_list.merge); of(c) lo lee al abrir «Elegir versión», una vez por versión (leerlo siempre triplicaba lo que
cuesta leer una fuente, también en filas y buscador). extract(texto, ficheros, banderas_audio, banderas_subs) → dict
con langs, subs, forced, copy, vcodec, bit10, service; seeds(texto) → semillas o None; join los une.
Las claves de idioma: las de LANG_NAMES («eng», «fre»…); «esp»/«lat» solo en subs (el audio en español lo dice
flix_src_list)."""
import re

LANG_NAMES = {"esp": "castellano", "lat": "latino", "eng": "inglés", "fre": "francés", "ger": "alemán",
              "ita": "italiano", "jpn": "japonés", "kor": "coreano", "por": "portugués", "rus": "ruso",
              "ukr": "ucraniano", "pol": "polaco", "cze": "checo", "cat": "catalán", "chi": "chino", "hin": "hindi",
              "tur": "turco", "dut": "neerlandés", "swe": "sueco", "dan": "danés", "nor": "noruego", "fin": "finés",
              "hun": "húngaro", "gre": "griego", "ara": "árabe", "heb": "hebreo", "tha": "tailandés", "vie": "vietnamita",
              "ind": "indonesio", "rum": "rumano", "bul": "búlgaro", "hrv": "croata", "slv": "esloveno",
              "slk": "eslovaco", "est": "estonio", "lav": "letón", "lit": "lituano", "glg": "gallego", "eus": "euskera"}
FLAGS = {"🇪🇸": "esp", "🇲🇽": "lat", "🇦🇷": "lat", "🇬🇧": "eng", "🇺🇸": "eng", "🇫🇷": "fre", "🇩🇪": "ger",
         "🇮🇹": "ita", "🇯🇵": "jpn", "🇰🇷": "kor", "🇵🇹": "por", "🇧🇷": "por", "🇷🇺": "rus", "🇺🇦": "ukr",
         "🇵🇱": "pol", "🇨🇿": "cze", "🇨🇳": "chi", "🇹🇼": "chi", "🇭🇰": "chi", "🇮🇳": "hin", "🇹🇷": "tur",
         "🇳🇱": "dut", "🇸🇪": "swe", "🇩🇰": "dan", "🇳🇴": "nor", "🇫🇮": "fin", "🇭🇺": "hun", "🇬🇷": "gre",
         "🇸🇦": "ara", "🇮🇱": "heb", "🇹🇭": "tha", "🇻🇳": "vie", "🇮🇩": "ind", "🇷🇴": "rum", "🇧🇬": "bul",
         "🇭🇷": "hrv", "🇸🇮": "slv", "🇸🇰": "slk", "🇪🇪": "est", "🇱🇻": "lav", "🇱🇹": "lit",
         "\U0001F3F4\U000E0065\U000E0073\U000E0063\U000E0074\U000E007F": "cat"}     # bandera de Cataluña
_FLAG = re.compile("|".join(re.escape(f) for f in sorted(FLAGS, key=len, reverse=True)))
# idiomas por el nombre (con puntos, guiones o corchetes alrededor). Sin el español (lo decide flix_src_list) y sin
# códigos que sean palabras corrientes en un título («cat», «cz», «por» de «Todo por la pasta»…)
_NAME_LANG = (
    ("eng", r"eng|english|ingl[eé]s"), ("fre", r"fre|fra|french|truefrench|vff|vfq"), ("ger", r"ger|deu|german"),
    ("ita", r"ita|italian"), ("jpn", r"jpn|jap|japanese"), ("kor", r"kor|korean"), ("por", r"portuguese|portugu[eé]s"),
    ("rus", r"rus|russian"), ("ukr", r"ukr|ukrainian"), ("pol", r"pol|polish"), ("cze", r"cze|ces|czech"),
    ("cat", r"catal[aà]n?|catal[aà]"), ("chi", r"chi|chinese|mandarin"), ("hin", r"hin|hindi"),
    ("tur", r"tur|turkish"),
)
_NAME_LANG_RX = [(k, re.compile(r"(?<![a-z0-9])(?:%s)(?![a-z0-9])" % rx, re.I)) for k, rx in _NAME_LANG]
# tipo de copia: lo peor primero (una «CAM» que además dice «HDRip» es una CAM). El remux lo dice flix_src_list
_COPY = (
    ("CAM", r"(?<![a-z])(?:hd)?cam(?:rip)?(?![a-z])"), ("TS", r"(?<![a-z.])(?:hd)?(?:ts|telesync)(?![a-z])"),
    ("Screener", r"screener|(?<![a-z])(?:dvd)?scr(?![a-z])"),
    ("BDRip", r"bd-?rip|br-?rip|bdrip"), ("BluRay", r"blu-?ray|(?<![a-z])bd(?:25|50|mv)(?![a-z])|(?<![a-z])uhd\s?bd"),
    ("WEB-DL", r"web-?dl|webdl"), ("WEBRip", r"web-?rip"), ("WEB", r"(?<![a-z])web(?![a-z])"),
    ("HDTV", r"hdtv"), ("MicroHD", r"micro-?hd"), ("HDRip", r"hd-?rip"), ("DVDRip", r"dvd-?rip|(?<![a-z])dvd(?![a-z])"),
)
_COPY_RX = [(k, re.compile(rx, re.I)) for k, rx in _COPY]
_VCODEC = (("AV1", r"(?<![a-z0-9])av1(?![0-9])"), ("HEVC", r"hevc|[xh][.\s]?265"), ("H.264", r"(?<![a-z])avc(?![a-z])|[xh][.\s]?264"),
           ("VP9", r"(?<![a-z])vp9"), ("XviD", r"xvid|divx"))
_VCODEC_RX = [(k, re.compile(rx, re.I)) for k, rx in _VCODEC]
_BIT10 = re.compile(r"10[\s.-]?bits?|hi10p?", re.I)
# plataforma de origen (la etiqueta de los grupos de WEB-DL): solo etiquetas inequívocas («MAX» suelto es «Mad Max»)
_SERVICE = (("Netflix", r"nf|netflix"), ("Amazon", r"amzn|amazon"), ("Disney+", r"dsnp|dsny|disney\+?"),
            ("Apple TV+", r"atvp|aptv"), ("Max", r"hmax"), ("HBO", r"hbo"), ("SkyShowtime", r"skst|skyshowtime"),
            ("Peacock", r"pcok"), ("Paramount+", r"pmtp"), ("Movistar+", r"movistar\+?|mvst"), ("Filmin", r"flmn|filmin"),
            ("Atresplayer", r"atresplayer|atres"), ("RTVE", r"rtve"), ("Hulu", r"hulu"), ("Crunchyroll", r"crunchyroll|cr(?=[.\s-]web)"))
_SERVICE_RX = [(k, re.compile(r"(?<![a-z0-9])(?:%s)(?![a-z0-9])" % rx, re.I)) for k, rx in _SERVICE]
_EXT = re.compile(r"\.(mkv|mp4|avi|m2ts|ts|mov|wmv)$", re.I)
_SUBS_WORD = re.compile(r"\bv\.?o\.?s\.?e\b|subs?\b|subt[ií]tul|forzados|\bsrt\b", re.I)
_VOSE = re.compile(r"\bv\.?o\.?s\.?e\b", re.I)
_FORCED = re.compile(r"forzados|forced", re.I)


def flags(text):
    """claves de idioma de las banderas del texto, en orden y sin repetir"""
    return list(dict.fromkeys(FLAGS[f] for f in _FLAG.findall(text or "")))


def _first(rules, text):
    return next((k for k, rx in rules if rx.search(text)), "")


def extract(text, files=(), audio_flags="", sub_flags=""):
    """text: nombre(s) del torrent/versión (sin listas de subtítulos del anime: flix_src_list.strip_sub_lists); files:
    nombres de fichero y el bingeGroup; audio_flags/sub_flags: el texto con las banderas del audio y de los subtítulos
    (Meteor las separa; Torrentio y Peerflix dan una sola línea, que va como audio)"""
    names = " ".join([text or ""] + [_EXT.sub("", f or "") for f in files])
    langs = [k for k, rx in _NAME_LANG_RX if rx.search(names)]
    for k in flags(audio_flags):
        if k not in langs:
            langs.append(k)
    langs = [k for k in langs if k not in ("esp", "lat")]       # el español lo dice flix_src_list
    subs = flags(sub_flags)
    if _VOSE.search(names) and "esp" not in subs:
        subs.insert(0, "esp")
    forced = bool(_FORCED.search(names))
    t = names.lower()
    return {"langs": langs, "subs": subs, "forced": forced, "copy": _first(_COPY_RX, t),
            "vcodec": _first(_VCODEC_RX, t), "bit10": bool(_BIT10.search(t)), "service": _first(_SERVICE_RX, t)}


def seeds(text):
    """semillas: «👤 25» (Torrentio, Peerflix) o «👥 47 seeders» (Meteor); None si no lo dice (PeLis cuenta
    «👤 N fuentes», que es otra cosa)"""
    m = re.search(r"(?:👤|👥)\s*(\d+)(?!\s*fuente)", text or "")
    return int(m.group(1)) if m else None


def join(old, new):
    """lo de una segunda fuente con el mismo torrent: idiomas y subtítulos juntos, semillas las mayores, lo demás si
    faltaba"""
    for k in ("langs", "subs"):
        a = list(old.get(k) or [])
        for x in new.get(k) or []:
            if x not in a:
                a.append(x)
        old[k] = a
    s = [x for x in (old.get("seeds"), new.get("seeds")) if x is not None]
    old["seeds"] = max(s) if s else None
    old["forced"] = bool(old.get("forced") or new.get("forced"))
    old["bit10"] = bool(old.get("bit10") or new.get("bit10"))
    for k in ("copy", "vcodec", "service"):
        old[k] = old.get(k) or new.get(k) or ""


FIRST = ("esp", "lat", "eng")     # primero lo que más importa aquí; luego en el orden en que venían


def names(keys, limit=3):
    """«inglés, francés +2» (castellano, latino e inglés delante)"""
    keys = [k for k in keys if k in LANG_NAMES]
    keys = [k for k in FIRST if k in keys] + [k for k in keys if k not in FIRST]
    out = ", ".join(LANG_NAMES[k] for k in keys[:limit])
    return out + (" +%d" % (len(keys) - limit) if len(keys) > limit else "")


RAW_MAX = 400       # caracteres por texto guardado (la lista se guarda 1 h en disco: flix_src_play.candidates)


def raw(text, files=(), audio_flags="", sub_flags="", seed_text=""):
    """lo que hace falta para extract y seeds, guardado tal cual (lista: va a JSON)"""
    return [(text or "")[:RAW_MAX], [(f or "")[:RAW_MAX] for f in files if f], (audio_flags or "")[:RAW_MAX],
            (sub_flags or "")[:RAW_MAX], (seed_text or "")[:RAW_MAX]]


def add(old, new):
    """el texto de una segunda fuente con el mismo torrent (flix_src_list.merge)"""
    old["raw"] = list(old.get("raw") or []) + list(new.get("raw") or [])
    for k in ("langs", "subs"):     # Linkañol los trae ya leídos
        if new.get(k):
            old[k] = list(dict.fromkeys(list(old.get(k) or []) + list(new[k])))


def of(c):
    """los datos de más de una versión (langs, subs, forced, copy, vcodec, bit10, service, seeds), leídos de su
    texto la primera vez y guardados en c["_info"]"""
    got = c.get("_info")
    if isinstance(got, dict):
        return got
    # lo que la versión ya trae leído (Linkañol: idiomas) cuenta, y se le suma lo de su texto
    out = {"langs": list(c.get("langs") or []), "subs": list(c.get("subs") or []), "seeds": c.get("seeds"),
           "forced": c.get("forced"), "bit10": c.get("bit10"), "copy": c.get("copy"), "vcodec": c.get("vcodec"),
           "service": c.get("service")}
    for r in c.get("raw") or []:
        try:
            text, files, au, sb, st = r
        except (TypeError, ValueError):
            continue
        x = extract(text, files, au, sb)
        x["seeds"] = seeds(st)
        join(out, x)
    for k in ("forced", "bit10"):
        out[k] = bool(out.get(k))
    for k in ("copy", "vcodec", "service"):
        out[k] = out.get(k) or ""
    c["_info"] = out
    return out


def mbps(gb, runtime):
    """bitrate medio en Mb/s (tamaño en GB y duración en s); None si falta algo"""
    if not gb or not runtime or runtime < 600:
        return None
    return gb * 8000.0 / runtime
