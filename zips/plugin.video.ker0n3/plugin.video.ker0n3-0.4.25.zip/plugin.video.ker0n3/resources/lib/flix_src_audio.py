"""¿El fichero trae audio en castellano? Lee los primeros READ bytes por HTTP (Range) y busca las pistas en la cabecera
Matroska: Segment → Tracks → TrackEntry (TrackType 2 = audio; Language, LanguageBCP47, Name). MP4 u otra cosa: «?».
Fuentes propias, parte 1 (15-nov): los nombres de las versiones engañan (4K DV «🇪🇸» con solo inglés).
Medido en AllDebrid: las pistas caen dentro de los primeros 16-64 KB (2 MB tardaban 10-22 s; 64 KB ~1 s). Si 64 KB
llenos de un Matroska no traen pistas, una segunda petición de hasta 512 KB (READ_MORE); más que eso no se lee.

16-nov (enlaces falsos; «La Odisea» de The Asylum, 90 min en vez de 173): de la MISMA lectura sale la duración del
fichero (Segment → Info → Duration × TimecodeScale) y el idioma de cada pista de audio (para la versión original):
probe(). Ninguna petición más. Info va antes que Tracks en lo que escriben mkvmerge y ffmpeg, así que si las pistas
caben, la duración también (probado con un fichero de ffmpeg en los tests). Sin Duration (directos, ficheros sin
cerrar) o si no es Matroska: duración None y quien la usa no comprueba nada (flix_src_check.duration_reason).
"""
import struct
import urllib.request

READ = 64 * 1024
READ_MORE = 512 * 1024
TIMEOUT = 7         # s por operación; con datos móviles 4 s se quedaba corto (Elena de Ávalor, S24, 15-nov)
SEGMENT, TRACKS, ENTRY, CLUSTER = 0x18538067, 0x1654AE6B, 0xAE, 0x1F43B675
INFO, TIMESCALE, DURATION = 0x1549A966, 0x2AD7B1, 0x4489
TYPE, LANG, BCP47, NAME = 0x83, 0x22B59C, 0x22B59D, 0x536E
LATIN = ("latino", "latin", "lat.", "(lat)", "méxico", "mexico", "es-419", "es-mx",
         "latam", "latinoam", "es-us", "es-ar", "es-co", "hispanoam")
CASTILIAN = ("castellano", "spain", "españa", "european", "es-es", "castilian")
# pista sin idioma (und, o el «eng» que Matroska pone por defecto) pero con el nombre en español: cuenta como española
SPANISH_NAME = ("castellano", "español", "espanol", "spanish")
UNTAGGED = ("und", "eng", "")
EBML = b"\x1a\x45\xdf\xa3"     # comienzo de un Matroska: sin él (MP4…) no se pide más


def _id(buf, pos):
    b = buf[pos]
    n = 1 if b & 0x80 else 2 if b & 0x40 else 3 if b & 0x20 else 4 if b & 0x10 else 0
    if not n or pos + n > len(buf):
        raise ValueError("id")
    return int.from_bytes(buf[pos:pos + n], "big"), n


def _size(buf, pos):
    b = buf[pos]
    n = next((i + 1 for i in range(8) if b & (0x80 >> i)), 0)
    if not n or pos + n > len(buf):
        raise ValueError("size")
    v = int.from_bytes(buf[pos:pos + n], "big") & ((1 << (7 * n)) - 1)
    return (None if v == (1 << (7 * n)) - 1 else v), n


def _children(buf, start, end):
    pos = start
    while pos < end and pos < len(buf):
        eid, a = _id(buf, pos)
        size, b = _size(buf, pos + a)
        data = pos + a + b
        # sin recortar a len(buf): quien lo necesite compara con len(buf) (elemento cortado por el final)
        stop = end if size is None else data + size
        yield eid, data, stop
        if size is None:
            return
        pos = data + size


def _entry(buf, start, end):
    # tagged: el fichero dice el idioma (sin Language, Matroska supone «eng»: no es un dato)
    t = {"type": 0, "lang": "eng", "name": "", "tagged": False}
    bcp = ""
    for eid, a, b in _children(buf, start, end):
        raw = buf[a:b]
        if eid == TYPE:
            t["type"] = int.from_bytes(raw, "big")
        elif eid == LANG:
            t["lang"] = raw.decode("utf-8", "replace").strip("\x00")
            t["tagged"] = True
        elif eid == BCP47:
            bcp = raw.decode("utf-8", "replace").strip("\x00")
        elif eid == NAME:
            t["name"] = raw.decode("utf-8", "replace").strip("\x00")
    if bcp:
        t["lang"], t["tagged"] = bcp, True
    return t


def _duration(buf, start, end):
    """segundos de Info (Duration, float de 4 u 8 bytes, × TimecodeScale en ns; 1 ms si no viene), o None"""
    scale, dur = 1000000, None
    for eid, a, b in _children(buf, start, end):
        if b > len(buf):
            break
        if eid == TIMESCALE:
            scale = int.from_bytes(buf[a:b], "big")
        elif eid == DURATION and b - a in (4, 8):
            dur = struct.unpack(">f" if b - a == 4 else ">d", buf[a:b])[0]
    secs = dur * scale / 1e9 if dur and scale else 0
    return secs if 0 < secs < 10 ** 7 else None     # también fuera NaN e infinito


def header(buf):
    """(pistas, duración en s o None) de la cabecera. Pistas: [] si no es un MKV o si Tracks no cabe entero en buf"""
    out, dur, done = [], None, False
    try:
        for eid, a, b in _children(buf, 0, len(buf)):
            if eid != SEGMENT:
                continue
            for cid, ca, cb in _children(buf, a, b):
                if cid == CLUSTER:
                    break
                if cid == INFO:
                    try:
                        dur = _duration(buf, ca, cb)
                    except (ValueError, IndexError, struct.error):
                        dur = None
                elif cid == TRACKS:
                    done = True
                    if cb > len(buf):  # Tracks cortado por el final del buffer: lista incompleta, no sirve
                        return [], dur
                    for tid, ta, tb in _children(buf, ca, cb):
                        if tid == ENTRY:
                            out.append(_entry(buf, ta, tb))
                if done and dur is not None:
                    break
            break
    except (ValueError, IndexError):
        pass
    return out, dur


def tracks(buf):
    """pistas de la cabecera; [] si no es un MKV o si Tracks no cabe entero en buf"""
    return header(buf)[0]


def _es_castellano_o_latino(lang):
    """idioma español: «spa», «es» o «es-XX»/«es_XX» (no «est», que es estonio)"""
    return lang in ("spa", "es") or lang.startswith(("es-", "es_"))


def classify(tr):
    audio = [t for t in tr if t["type"] == 2]
    if not audio:
        return "?"
    spanish = [t for t in audio if _es_castellano_o_latino(t["lang"].lower()) or (
        t["lang"].lower() in UNTAGGED and any(w in t["name"].lower() for w in SPANISH_NAME))]
    if not spanish:
        return "otro"
    for t in spanish:
        text = (t["lang"] + " " + t["name"]).lower()
        if any(w in text for w in CASTILIAN) or not any(w in text for w in LATIN):
            return "cast"
    return "lat"


def cast_named(tr):
    """¿alguna pista española dice expresamente que es castellano («Castellano», «España», es-ES…)? Para los ficheros
    cuyo NOMBRE dice latino (Cinecalidad «Dual-Lat», La Odisea, S24 16-nov): su pista viene marcada «spa» a secas y
    classify() la daba por castellana"""
    for t in tr or []:
        text = ((t.get("lang") or "") + " " + (t.get("name") or "")).lower()
        if any(w in text for w in CASTILIAN):
            return True
    return False


def _get(url, n, opener):
    req = urllib.request.Request(url, headers={"Range": "bytes=0-%d" % (n - 1),
                                               "User-Agent": "Mozilla/5.0 (Ker0n3Media-skin)"})
    with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
        return r.read(n)


def probe(url, opener=None):
    """{"audio": «cast» / «lat» / «otro» / «?», "tracks": pistas de audio ({"lang", "name", "tagged"}), "duration": s o
    None} con la lectura de siempre (64 KB; hasta 512 KB más solo si las pistas no caben). Nunca lanza"""
    try:
        buf = _get(url, READ, opener)
        if not tracks(buf) and len(buf) == READ and buf.startswith(EBML):
            buf = _get(url, READ_MORE, opener)
        tr, dur = header(buf)
    except Exception:  # noqa: BLE001
        return {"audio": "?", "tracks": [], "duration": None}
    return {"audio": classify(tr), "duration": dur,
            "tracks": [{"lang": t["lang"], "name": t["name"], "tagged": t["tagged"]} for t in tr if t["type"] == 2]}


def check(url, opener=None):
    return probe(url, opener)["audio"]
