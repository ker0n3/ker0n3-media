"""Audio y canales de una versión, leídos de su nombre (18-nov, «Elegir versión» con insignias).

RANK y TOKENS eran de la skin (scripts/flix_audio.py, la insignia de audio de la cabecera): viven aquí, una sola vez,
y flix_audio los importa. audio(texto) → la clave del mejor códec que nombre el texto (la de la insignia
flix/badges/<atmos | au_…>), '' si ninguno; channels(texto) → '71' / '51' / '20' (insignia au_71…), '' si no lo dice.
El texto es el del torrent (nombre, descripción y fichero): «…DDP5.1.Atmos…», «TrueHD 7.1», «AAC2.0», «DTS-HD MA»…
Solo se lee: no cambia el orden de las versiones ni cuál se elige sola."""
import re

RANK = ("atmos", "dtsx", "truehd", "dtshd", "dts", "ddplus", "dd", "aac")     # de mejor a peor; = flix/badges/…
TOKENS = {"ATMOS": "atmos", "DTS-X": "dtsx", "DTSX": "dtsx", "DTS:X": "dtsx", "TRUEHD": "truehd",
          "DTSHD-MA": "dtshd", "DTSHD-HRA": "dtshd", "DTS-HD": "dtshd", "DTSHD": "dtshd", "DTS": "dts", "DTS-ES": "dts",
          "EAC3": "ddplus", "DD+": "ddplus", "DDP": "ddplus", "AC3": "dd", "DD": "dd", "AAC": "aac", "ACC": "aac"}
# en el nombre de un torrent las palabras van con puntos, guiones o pegadas a los canales («DDP5.1», «AAC2.0»): por
# expresiones, no por palabras sueltas. Cada una con su clave de RANK
_AUDIO = (
    ("atmos", re.compile(r"atmos")),
    ("dtsx", re.compile(r"dts[\s.:-]?x(?![a-z])")),
    ("truehd", re.compile(r"true[\s.-]?hd")),
    ("dtshd", re.compile(r"dts[\s.-]?hd|dts[\s.-]?ma(?![a-z])|dtshd")),
    ("dts", re.compile(r"(?<![a-z])dts(?![a-z])|dts[\s.-]?es(?![a-z])")),
    ("ddplus", re.compile(r"(?<![a-z])ddp|dd\+|(?<![a-z])e-?ac-?3|dolby[\s.]?digital[\s.]?plus")),
    ("dd", re.compile(r"(?<![a-z])ac-?3(?![a-z])|(?<![a-z])dd(?=[\s.]?[257][\s.][01])|(?<![a-z])dd(?![a-z+])|"
                      r"dolby[\s.]?digital")),
    ("aac", re.compile(r"(?<![a-z])aac|(?<![a-z])acc(?![a-z])")),
)
# canales: «7.1», «5.1», «2.0» pegados o no a un códec («DDP5.1», «AAC2.0», «TrueHD 7.1»), sin ser parte de otro
# número (tamaños «5.1 GB», versiones «1.5.1»): el tamaño se quita antes (_SIZE)
_N = r"(?<!\d)(?<!\d\.)%s[\s.]%s(?:(?!\d|\.\d)|[\s.][24](?!\d|\.\d))"      # también «7.1.2», «5.1.4» (Atmos)
_CH = (("71", re.compile(_N % (7, 1))), ("51", re.compile(_N % (5, 1))),
       ("20", re.compile(_N % (2, 0) + r"|stereo|est[eé]reo")))
_SIZE = re.compile(r"[\d.,]+\s*(?:gb|mb|gib|mib)\b|💾\s*[\d.,]+")


def audio(text):
    """el mejor códec que nombre el texto ('' si ninguno conocido)"""
    t = (text or "").lower()
    found = {key for key, rx in _AUDIO if rx.search(t)}
    return next((k for k in RANK if k in found), "")


def channels(text):
    """'71', '51' o '20' (el mayor que nombre el texto), '' si no lo dice"""
    t = _SIZE.sub(" ", (text or "").lower())
    return next((key for key, rx in _CH if rx.search(t)), "")


def badge(au):
    """nombre de la insignia (flix/badges/<…>.png) de una clave de audio; '' sin audio"""
    return "" if not au else "atmos" if au == "atmos" else "au_" + au
