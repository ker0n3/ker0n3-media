"""Sincronizar un subtítulo español hecho para otra versión del vídeo (17-nov, Brooklyn Nine-Nine 4x06).

El caso: el único subtítulo en español era de la emisión de TV (FLEET) y sonaba el Blu-ray (REMUX): mismo diálogo, pero
el Blu-ray mete un par de segundos de negro en cada pausa de anuncios, así que el español iba ADELANTADO a tramos:
+2,0 s hasta el minuto 7, +3,4 hasta el 13, +5,5 hasta el 17 y +7,2 hasta el final. Un retraso fijo no lo arregla.

Cómo: la fuente de subtítulos (OpenSubtitles v3) casi siempre tiene uno en inglés de la MISMA versión que suena
(flix_src_extsubs.reference). Ese va a tiempo con el vídeo. Los dos son el mismo diálogo, así que las frases empiezan
casi a la vez: se busca, frase a frase, cuánto hay que mover el español para que caiga sobre una del inglés.
  1. Desfases posibles: histograma de (inicio inglés − inicio español) a menos de LIMIT s, en cajas de 0,1 s; los picos
     (hasta PEAKS) son los candidatos. También con el español estirado por 25/23,976 o al revés (otra velocidad).
  2. Tramos: Viterbi sobre las frases, un estado por desfase; cada frase suma 1 si cae a menos de TOL de una inglesa
     y cambiar de desfase cuesta SWITCH (así no salta por una frase suelta).
  3. Solo se usa si mejora de verdad: al menos MIN_HIT de las frases casan y GAIN más que sin tocar. Si no, None y el
     subtítulo se queda como venía.
Solo SRT y VTT (los .ass se quedan como vienen). Funciones puras, sin red ni Kodi: las usa flix_src_extsubs."""
import bisect
import re

LIMIT = 60.0            # s: desfase máximo que se busca
BIN = 0.1               # s: caja del histograma
PEAKS = 6               # desfases candidatos por velocidad
TOL = 0.25              # s: «empieza a la vez»
SWITCH = 12.0           # coste de cambiar de tramo (en frases; con 4 movía tramos de uno que ya iba bien)
MIN_HIT = 0.45          # parte de las frases que tienen que casar después
GAIN = 0.15             # y cuánto más que sin tocar (parte de las frases; mínimo MIN_GAIN frases)
MIN_GAIN = 10
MIN_CUES = 20           # con menos frases no se intenta
SPEEDS = (1.0, 25.0 / 23.976, 23.976 / 25.0)

_TS = re.compile(r"(?:(\d{1,2}):)?(\d{1,2}):(\d\d)[,.](\d{1,3})")
_CUE = re.compile(r"^(?P<pre>\s*)(?P<a>(?:\d{1,2}:)?\d{1,2}:\d\d[,.]\d{1,3})(?P<mid>\s*-->\s*)"
                  r"(?P<b>(?:\d{1,2}:)?\d{1,2}:\d\d[,.]\d{1,3})", re.M)


def _secs(ts):
    m = _TS.fullmatch(ts.strip())
    if not m:
        return None
    h, mi, s, ms = m.groups()
    return int(h or 0) * 3600 + int(mi) * 60 + int(s) + int(ms.ljust(3, "0")) / 1000.0


def _fmt(t, vtt):
    ms = max(0, int(round(t * 1000)))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return "%02d:%02d:%02d%s%03d" % (h, m, s, "." if vtt else ",", ms)


def starts(text):
    """inicio (s) de cada frase de un SRT o VTT, en el orden del fichero"""
    out = []
    for m in _CUE.finditer(text or ""):
        a = _secs(m.group("a"))
        if a is not None:
            out.append(a)
    return out


def _hits(ref, t):
    i = bisect.bisect_left(ref, t - TOL)
    return i < len(ref) and ref[i] <= t + TOL


def _peaks(ref, sub):
    hist = {}
    for s in sub:
        lo = bisect.bisect_left(ref, s - LIMIT)
        hi = bisect.bisect_right(ref, s + LIMIT)
        for r in ref[lo:hi]:
            k = int(round((r - s) / BIN))
            hist[k] = hist.get(k, 0) + 1
    smooth = {k: hist.get(k - 1, 0) + hist.get(k, 0) + hist.get(k + 1, 0) for k in hist}
    out = []
    for k, v in sorted(smooth.items(), key=lambda kv: (-kv[1], abs(kv[0]))):
        if v < max(5, 0.03 * len(sub)):
            break
        if all(abs(k - o) * BIN >= 0.5 for o in out):
            out.append(k)
        if len(out) >= PEAKS:
            break
    return [k * BIN for k in out]


def _viterbi(ref, sub, offs):
    """(frases que casan, desfase de cada frase)"""
    n, m = len(sub), len(offs)
    emit = [[1.0 if _hits(ref, s + o) else 0.0 for o in offs] for s in sub]
    score, back = emit[0][:], []
    for i in range(1, n):
        best_k = max(range(m), key=lambda k: score[k])
        new, bk = [], []
        for k in range(m):
            stay, move = score[k], score[best_k] - SWITCH
            if stay >= move:
                new.append(stay + emit[i][k])
                bk.append(k)
            else:
                new.append(move + emit[i][k])
                bk.append(best_k)
        score = new
        back.append(bk)
    k = max(range(m), key=lambda j: score[j])
    path = [k]
    for bk in reversed(back):
        k = bk[k]
        path.append(k)
    path.reverse()
    hits = sum(emit[i][path[i]] for i in range(n))
    return hits, [offs[k] for k in path]


def plan(ref_starts, sub_starts):
    """(velocidad, [desfase por frase], casan antes, casan después) o None si no mejora de verdad"""
    sub = list(sub_starts)
    ref = sorted(ref_starts)
    n = len(sub)
    if n < MIN_CUES or len(ref) < MIN_CUES:
        return None
    before = sum(1 for s in sub if _hits(ref, s))
    best = None
    for speed in SPEEDS:
        scaled = [s * speed for s in sub]
        offs = _peaks(ref, scaled)
        if not offs:
            continue
        hits, path = _viterbi(ref, scaled, offs)
        if best is None or hits > best[0]:
            best = (hits, speed, path)
    if best is None:
        return None
    hits, speed, path = best
    if hits < MIN_HIT * n or hits < before + max(MIN_GAIN, GAIN * n):
        return None
    return speed, path, before, int(hits)


def shift(text, speed, path):
    """el mismo SRT/VTT con cada frase movida a su tramo (inicio y fin). None si no cuadra con el plan"""
    vtt = (text or "").lstrip().lower().startswith("webvtt")
    cues = list(_CUE.finditer(text or ""))
    if len(cues) != len(path):
        return None
    out, last = [], 0
    for m, off in zip(cues, path):
        a, b = _secs(m.group("a")), _secs(m.group("b"))
        if a is None or b is None:
            return None
        out.append(text[last:m.start()])
        out.append("%s%s%s%s" % (m.group("pre"), _fmt(a * speed + off, vtt), m.group("mid"), _fmt(b * speed + off, vtt)))
        last = m.end()
    out.append(text[last:])
    return "".join(out)


def tramos(path):
    """«+2.0 s, +3.4 s…» para el registro: los desfases en el orden en que aparecen"""
    seen = []
    for o in path:
        if not seen or abs(seen[-1] - o) > 1e-9:
            seen.append(o)
    return ", ".join("%+.1f s" % o for o in seen[:8])
