"""Subtítulos en castellano al ver una versión sin audio en castellano (Carlos, 15-nov tarde; 16-nov: «¿Quieres verla
en VO subtitulada?» → sí; con `audio` = idioma original de TMDB, además pone la pista de audio en ese idioma si el
fichero trae varias y Kodi eligió otra: un dual latino + inglés se oía en latino). Espera a que el vídeo arranque (como mucho WAIT s), mira las pistas de subtítulos del fichero por
JSON-RPC y enciende la de castellano (si no hay, cualquiera en español; latino al final, forzados lo último).
Nunca en el hilo de la interfaz:
  * skin (flix_src_play.start_playback): start(url), hilo aparte (no daemon: el RunScript espera a que acabe).
  * addon Ker0n3: RunScript(special://home/addons/plugin.video.ker0n3/resources/lib/flix_src_subs.py[,idioma]) antes de setResolvedUrl, porque el proceso del
    addon termina al resolver y no conviene que un hilo suyo lo mantenga vivo.
16-nov: si el fichero no trae NINGUNA pista en español (o ninguna pista), se busca un subtítulo fuera y se carga
(flix_src_extsubs, mismo hilo, después de mirar). Con español dentro no sale ninguna petición."""
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

WAIT = 20           # s como mucho esperando al vídeo y a sus pistas
STEP = 0.5
EMPTY_WAIT = 4      # s con el vídeo en marcha y la lista de pistas vacía antes de darla por vacía (y buscar fuera)
CASTILIAN = ("castellano", "españa", "espana", "spain", "european", "castilian", "(es-es)")
LATIN = ("latino", "latin", "latam", "419", "méxico", "mexico", "hispanoam")
SPANISH = ("español", "espanol", "spanish", "castellano")


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_src_subs] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def _rank(s):
    """(forzado, idioma) o None si no es español: castellano 0, español sin más 1, latino 2"""
    lang = (s.get("language") or "").strip().lower()
    name = (s.get("name") or "").strip().lower()
    spanish = lang in ("spa", "es", "esp") or lang.startswith("es-") or any(w in name for w in SPANISH)
    if not spanish:
        return None
    if "419" in lang or any(w in name for w in LATIN):
        kind = 2
    elif lang == "es-es" or any(w in name for w in CASTILIAN):
        kind = 0
    else:
        kind = 1
    # forzados = solo los carteles y las frases en otro idioma: con el audio en inglés no sirven de casi nada
    return (1 if s.get("isforced") else 0, kind)


def pick(subs):
    """índice de la pista a encender, o None"""
    best = None
    for s in subs or []:
        r = _rank(s)
        if r is not None and (best is None or r < best[0]):
            best = (r, s.get("index"))
    return None if best is None else best[1]


def _ours(url, label):
    playing = label("Player.Filenameandpath") or ""
    if "plugin.video.youtube" in playing:
        return False            # el tráiler de la ficha, no la película
    return not url or not playing or playing == url or playing.startswith(url) or url.startswith(playing)


def set_audio(res, audio, rpc):
    """pone la pista de audio en el idioma original si la que suena es otra y el fichero la trae"""
    import flix_src_check
    streams = (res or {}).get("audiostreams") or []
    cur = (res or {}).get("currentaudiostream") or {}
    if not streams or flix_src_check.lang_match(cur.get("language"), audio):
        return
    idx = next((s.get("index") for s in streams if flix_src_check.lang_match(s.get("language"), audio)), None)
    if idx is None:
        log("ninguna pista de audio en «%s» (%d pistas)" % (audio, len(streams)))
        return
    try:
        rpc("Player.SetAudioStream", {"playerid": 1, "stream": idx})
        log("audio original («%s»): pista %s" % (audio, idx))
    except Exception as e:  # noqa: BLE001
        log("SetAudioStream: %s" % e)


LATIN_HINT = ("latino", "latin", "lat.", "(lat)", "méxico", "mexico", "es-419", "es-mx", "latam")
CAST_HINT = ("castellano", "spain", "españa", "es-es", "castilian", "european")


def pick_castellano(streams):
    """índice de la pista de audio en castellano entre las del fichero: la que dice castellano/España, luego una en
    español sin más; las que dicen latino, solo si no hay otra. None si no hay ninguna en español"""
    import flix_src_check
    best = None
    for s in streams or []:
        if not flix_src_check.lang_match(s.get("language"), "es"):
            continue
        text = ("%s %s" % (s.get("language") or "", s.get("name") or "")).lower()
        r = 0 if any(w in text for w in CAST_HINT) else 2 if any(w in text for w in LATIN_HINT) else 1
        if best is None or r < best[0]:
            best = (r, s.get("index"))
    return None if best is None else best[1]


def castellano(url=None, wait=WAIT, rpc=None, cond=None, label=None, sleep=None, now=time.monotonic):
    """versión con castellano y varias pistas: si Kodi arranca con otra (un «Ita.Eng.Spa» sonaba en italiano: Slow
    Horses 3x05, S24 16-nov), pone la de castellano. Una consulta cuando el vídeo ya suena; sin subtítulos.
    Devuelve el índice puesto, o None si no hizo falta o no se pudo"""
    if rpc is None or cond is None or label is None or sleep is None:
        import xbmc
        import flix_common
        rpc = rpc or flix_common.rpc
        cond = cond or xbmc.getCondVisibility
        label = label or xbmc.getInfoLabel
        if sleep is None:
            mon = flix_common.quit_monitor()
            sleep = lambda s: flix_common.wait_quit(mon, s)      # noqa: E731  (True = Kodi se cierra)
    end = now() + wait
    while now() < end:
        if cond("Player.HasVideo") and _ours(url, label):
            try:
                res = (rpc("Player.GetProperties", {"playerid": 1, "properties": ["audiostreams", "currentaudiostream"]})
                       or {}).get("result") or {}
            except Exception as e:  # noqa: BLE001
                log("GetProperties: %s" % e)
                res = {}
            streams = res.get("audiostreams") or []
            if streams:
                idx = pick_castellano(streams)
                cur = (res.get("currentaudiostream") or {}).get("index")
                if idx is None or idx == cur:
                    return None
                try:
                    rpc("Player.SetAudioStream", {"playerid": 1, "stream": idx})
                    log("audio en castellano: pista %s (sonaba la %s de %d)" % (idx, cur, len(streams)))
                    return idx
                except Exception as e:  # noqa: BLE001
                    log("SetAudioStream: %s" % e)
                    return None
        if sleep(STEP):
            return None
    return None


def _safe_cast(url):
    try:
        castellano(url)
    except Exception as e:  # noqa: BLE001
        log("falló (audio): %s" % e)


def start_castellano(url=None):
    """en segundo plano, como start()"""
    threading.Thread(target=_safe_cast, args=(url,), name="flix_src_audio_es", daemon=False).start()


def enable(url=None, wait=WAIT, rpc=None, cond=None, label=None, sleep=None, now=time.monotonic, audio="",
           external=None):
    """espera al vídeo (url: el que se ha pedido; None = el que suene) y enciende los subtítulos. Índice o None.
    audio: idioma original (TMDB, «ja»): además, la pista de audio en ese idioma (misma consulta, una sola vez).
    external (sin argumentos): se llama UNA vez si el vídeo ya suena y no trae ninguna pista en español (o ninguna
    pista tras EMPTY_WAIT s): busca el subtítulo fuera. Sin vídeo, o si no se pudo mirar, no se llama"""
    if rpc is None or cond is None or label is None or sleep is None:
        import xbmc
        import flix_common
        rpc = rpc or flix_common.rpc
        cond = cond or xbmc.getCondVisibility
        label = label or xbmc.getInfoLabel
        if sleep is None:
            mon = flix_common.quit_monitor()
            sleep = lambda s: flix_common.wait_quit(mon, s)      # noqa: E731  (True = Kodi se cierra)
    end = now() + wait
    props = ["subtitles"] + (["audiostreams", "currentaudiostream"] if audio else [])
    audio_done = not audio
    empty_since = None
    while now() < end:
        if cond("Player.HasVideo") and _ours(url, label):
            try:
                res = (rpc("Player.GetProperties", {"playerid": 1, "properties": props}) or {}).get("result")
            except Exception as e:  # noqa: BLE001
                log("GetProperties: %s" % e)
                res = None
            if not audio_done and (res or {}).get("audiostreams"):
                audio_done = True
                set_audio(res, audio, rpc)
            streams = (res or {}).get("subtitles") or []
            if streams:
                idx = pick(streams)
                if idx is None:
                    log("ninguna pista en español (%d pistas)" % len(streams))
                    if external:
                        external()
                    return None
                try:
                    rpc("Player.SetSubtitle", {"playerid": 1, "subtitle": idx, "enable": True})
                except Exception as e:  # noqa: BLE001
                    log("SetSubtitle: %s" % e)
                    return None
                log("subtítulos en español: pista %s" % idx)
                return idx
            if external and isinstance(res, dict) and (audio_done or not res.get("audiostreams")):
                # el vídeo suena y contesta, sin pistas de subtítulos: se le dan unos segundos por si llegan tarde
                if empty_since is None:
                    empty_since = now()
                elif now() - empty_since >= EMPTY_WAIT:
                    log("el fichero no trae subtítulos")
                    external()
                    return None
        if sleep(STEP):
            return None
    log("sin vídeo o sin pistas de subtítulos en %d s" % wait)
    return None


def external():
    """subtítulo de fuera (flix_src_extsubs.auto), sin dejar escapar ningún fallo. True si quedó puesto"""
    try:
        import flix_src_extsubs
        return bool(flix_src_extsubs.auto())
    except Exception as e:  # noqa: BLE001
        log("subtítulos externos: %s" % type(e).__name__)
        return False


def _safe(url, audio=""):
    try:
        enable(url, audio=audio, external=external)
    except Exception as e:  # noqa: BLE001
        log("falló: %s" % e)


def start(url=None, audio=""):
    """en segundo plano; no daemon: el RunScript de la skin sigue vivo hasta que acabe (≤ WAIT s, más los
    flix_src_extsubs.BUDGET s de buscar fuera si hace falta)"""
    threading.Thread(target=_safe, args=(url, audio), name="flix_src_subs", daemon=False).start()


def main(argv):
    """RunScript desde el addon Ker0n3 (su proceso termina al resolver el enlace)"""
    if len(argv) > 1 and argv[1].strip().lower() == "castellano":
        _safe_cast(None)        # versión en castellano con varias pistas: solo el audio, sin subtítulos
        return
    try:
        enable(audio=argv[1].strip().lower() if len(argv) > 1 else "", external=external)
    except Exception as e:  # noqa: BLE001
        log("falló: %s" % e)


if __name__ == "__main__":
    main(sys.argv)
