"""Límite de PeLis (19-nov, Carlos): PeLis bloquea 24 h la configuración que pide «más de 60 títulos o episodios en 10
minutos» (contesta con un único stream «Error · Demasiadas peticiones… El addon queda bloqueado para esta configuración
24 horas, hasta el 20/11 a las 10:10»). La skin le preguntaba por cada título de las filas, del «Ver más» y del
buscador, y se agotaba (Shield, 19-nov: La bola negra sin sus 4K de PeLis; Stremio, con la misma configuración,
bloqueado hasta el día siguiente).

Aquí, por aparato (cada aparato tiene su propia dirección de PeLis: flix_src_list.pelis_path), en
addon_data/<skin>/pelis_uso.json:
  · cuántas peticiones a PeLis van en los últimos WINDOW s: lo de por detrás (comprobar si hay versión) para en BG_MAX;
    lo que pulsas («Ver», «Elegir versión», la precarga de la ficha) sigue hasta ALL_MAX: un aparato con su propia
    configuración nunca llega a 60;
  · hasta cuándo está bloqueada (lo que diga su aviso): hasta entonces no se le pregunta nada.
Varios procesos a la vez (el servicio, cada ruta del addon, los scripts de la skin): cerrojo de fichero."""
import json
import os
import re
import time

WINDOW = 600            # s: la ventana de PeLis (10 min)
BG_MAX = 40             # peticiones por detrás por aparato en la ventana (PeLis corta a 60 por configuración)
ALL_MAX = 55            # contando lo que pulsas: por encima, nada (la ficha de una serie precarga hasta 6 capítulos)
BLOCK_DEFAULT = 24 * 3600     # si el aviso no dice hasta cuándo
_LIMIT_RX = re.compile(r"demasiadas\s+peticiones|too\s+many\s+requests", re.I)
_UNTIL_RX = re.compile(r"hasta\s+el\s+(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\s+a\s+las\s+(\d{1,2}):(\d{2})", re.I)


def path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/pelis_uso.json" % xbmc.getSkinDir())


class _Lock:
    """cerrojo entre procesos (fcntl; sin él, en Windows, sin cerrojo: lo peor es contar una de menos)"""

    def __init__(self, p):
        self.p, self.fh = p + ".lock", None

    def __enter__(self):
        try:
            import fcntl
            os.makedirs(os.path.dirname(self.p) or ".", exist_ok=True)
            self.fh = open(self.p, "a")
            fcntl.flock(self.fh, fcntl.LOCK_EX)
        except Exception:  # noqa: BLE001
            self.fh = None
        return self

    def __exit__(self, *a):
        if self.fh is not None:
            try:
                import fcntl
                fcntl.flock(self.fh, fcntl.LOCK_UN)
            finally:
                self.fh.close()
        return False


def _load(p):
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return {"hits": [], "until": 0}
    if not isinstance(d, dict):
        return {"hits": [], "until": 0}
    hits = [h for h in d.get("hits") or [] if isinstance(h, (int, float))]
    until = d.get("until") if isinstance(d.get("until"), (int, float)) else 0
    return {"hits": hits, "until": until}


def _save(p, d):
    try:
        os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        tmp = "%s.%d.tmp" % (p, os.getpid())
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, p)
    except OSError:
        pass


def allow(background, p=None, now=time.time):
    """¿se le puede preguntar a PeLis ahora? Si sí, apunta la petición. background: comprobar si hay versión (filas,
    «Ver más», buscador); si no, algo que has pulsado tú"""
    p = p or path()
    with _Lock(p):
        d, t = _load(p), now()
        if d["until"] > t:
            return False
        hits = [h for h in d["hits"] if t - h < WINDOW]
        if len(hits) >= (BG_MAX if background else ALL_MAX):
            if len(hits) != len(d["hits"]):
                _save(p, {"hits": hits, "until": d["until"]})
            return False
        _save(p, {"hits": hits + [t], "until": d["until"]})
        return True


def room(background, p=None, now=time.time):
    """¿quedaría cupo para preguntar a PeLis ahora? Como allow, sin apuntar nada (21-nov: el buscador solo deja a
    PeLis para después si por detrás se le podrá preguntar; si no, decide ya, como siempre)"""
    p = p or path()
    with _Lock(p):
        d, t = _load(p), now()
        if d["until"] > t:
            return False
        return len([h for h in d["hits"] if t - h < WINDOW]) < (BG_MAX if background else ALL_MAX)


def blocked_until(p=None, now=time.time):
    """hora (epoch) hasta la que PeLis está bloqueada, o 0"""
    d = _load(p or path())
    return d["until"] if d["until"] > now() else 0


def limit_notice(streams, now=time.time):
    """si la respuesta de PeLis es su aviso de «Demasiadas peticiones», hasta cuándo (epoch, hora de aquí); si no, None"""
    for s in streams or []:
        if not isinstance(s, dict):
            continue
        text = " ".join(str(s.get(k) or "") for k in ("name", "title", "description"))
        if not _LIMIT_RX.search(text):
            continue
        m = _UNTIL_RX.search(text)
        t = now()
        if m:
            day, month, year, hh, mm = m.groups()
            y = int(year) if year else time.localtime(t).tm_year
            y = y + 2000 if y < 100 else y
            try:
                until = time.mktime((y, int(month), int(day), int(hh), int(mm), 0, 0, 0, -1))
                if not year and until < t - 86400:          # «hasta el 2/1» dicho en diciembre: el año que viene
                    until = time.mktime((y + 1, int(month), int(day), int(hh), int(mm), 0, 0, 0, -1))
                if t < until <= t + 2 * BLOCK_DEFAULT:
                    return until
            except (OverflowError, ValueError):
                pass
        return t + BLOCK_DEFAULT
    return None


def block(until, p=None):
    """apunta el bloqueo de PeLis hasta `until` (lo que dijo su aviso)"""
    p = p or path()
    with _Lock(p):
        d = _load(p)
        d["until"] = max(d["until"], until)
        _save(p, d)


def reset(p=None):
    """dirección de PeLis nueva (otra configuración): su límite empieza de cero"""
    try:
        os.remove(p or path())
    except OSError:
        pass
