"""Filas que no salen de TMDB (18-nov, Carlos: fase B): listas públicas de Trakt, listas públicas de MDBList y anime
de AniList. Cada una da los ids de TMDB de su lista, en su orden y sin repetir; la ficha de cada título la pone el
addon como con las de Simkl (lists: las listas que solo traen ids). Nada necesita cuenta del aparato.

  trakt:list/<id>          lista pública de Trakt (/lists/<id>/items/<movie|show>), con el client id de la app
                           (ker0n3/trakt.py). trakt:watched/<weekly|monthly>: las más vistas (reserva de los Top 10)
  mdblist:<usuario>/<lista>  lista pública de MDBList: https://mdblist.com/lists/<usuario>/<lista>/json, SIN clave (no
                           gasta las ~1000 consultas diarias de las notas). Si algún día pidieran clave (401/403): con la
                           del aparato (Skin.String flix_mdblist_key) por la API; sin clave, la fila se queda vacía (no sale)
  anilist:<consulta>       AniList (GraphQL, sin clave): top-tv, top-movie, trending-movie, season-tv. AniList → TMDB:
                           el mapa compacto anilist_tmdb.json (tools/gen_anilist_map.py, de la lista de Fribb) y, lo que
                           no esté, búsqueda en TMDB por título y año, guardada para siempre (anilist_map.json en
                           addon_data del addon). Las temporadas de una serie son la misma serie en TMDB: una vez.
Excepción = red (quien llama, lists.entries, se queda con lo último guardado)."""
import json
import os
import time
import urllib.parse

TIMEOUT = 10
MAX = 60                    # títulos de la lista (los de una fila de 3 páginas de TMDB)
UA = "Ker0n3Media/1.0"
TRAKT = "https://api.trakt.tv"
MDBLIST = "https://mdblist.com/lists/%s/json"
MDBLIST_API = "https://api.mdblist.com/lists/%s/items?apikey=%s"
ANILIST = "https://graphql.anilist.co"
TMDB = "https://api.themoviedb.org/3/"
MISS_RETRY = 7 * 86400      # un anime que TMDB no tenía: se vuelve a buscar a la semana
_MAP = []                   # el mapa compacto, una vez por proceso


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_extlists] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def _json(url, opener=None, headers=None, data=None):
    import urllib.request
    req = urllib.request.Request(url, data=data, headers=dict({"User-Agent": UA}, **(headers or {})))
    with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace") or "null")


def _uniq(ids):
    out = []
    for i in ids:
        try:
            i = int(i)
        except (TypeError, ValueError):
            continue
        if i > 0 and i not in out:
            out.append(i)
    return out[:MAX]


def ids(ep, kind, opener=None, extra=None):
    """ids de TMDB de una fuente externa (ver arriba); kind: 'movie' / 'tv'. extra["reserva"]: otra fuente si esta
    falla o viene vacía. Excepción = red (de la última que se probó)"""
    srcs = [ep] + ([extra["reserva"]] if (extra or {}).get("reserva") else [])
    err = None
    for src in srcs:
        try:
            got = _one(src, kind, opener)
        except Exception as e:  # noqa: BLE001
            log("%s: %s" % (src, type(e).__name__))
            err = e
            continue
        if got:
            return got
        log("%s: sin títulos" % src)
    if err is not None:
        raise err
    return []


def is_external(ep):
    return str(ep or "").split(":", 1)[0] in ("trakt", "mdblist", "anilist")


def _one(src, kind, opener):
    scheme, _, rest = src.partition(":")
    if scheme == "trakt":
        if rest.startswith("list/"):
            return trakt_list(rest[5:], kind, opener)
        return trakt_watched(rest.split("/", 1)[1] if "/" in rest else "weekly", kind, opener)
    if scheme == "mdblist":
        return mdblist(rest, kind, opener)
    if scheme == "anilist":
        return anilist(rest, kind, opener)
    raise ValueError(src)


# ---------- Trakt (público, client id de la app) ----------
def _trakt(path, opener):
    from ker0n3 import trakt
    return _json(TRAKT + path, opener, {"trakt-api-version": "2", "trakt-api-key": trakt.CLIENT_ID,
                                        "Content-Type": "application/json"})


def trakt_list(list_id, kind, opener=None):
    t = "movie" if kind == "movie" else "show"
    data = _trakt("/lists/%s/items/%s?page=1&limit=%d" % (urllib.parse.quote(str(list_id)), t, MAX), opener)
    return _uniq(((x.get(t) or {}).get("ids") or {}).get("tmdb") for x in data or [] if isinstance(x, dict))


def trakt_watched(period, kind, opener=None):
    """las más vistas en Trakt (weekly / monthly): la reserva de los Top 10 si Simkl no contesta"""
    t = "movies" if kind == "movie" else "shows"
    data = _trakt("/%s/watched/%s?limit=%d" % (t, period, MAX), opener)
    return _uniq(((x.get(t[:-1]) or {}).get("ids") or {}).get("tmdb") for x in data or [] if isinstance(x, dict))


# ---------- MDBList (listas públicas, sin clave) ----------
def _device_key():
    try:
        import xbmc
        key = xbmc.getInfoLabel("Skin.String(flix_mdblist_key)").strip()
        return key if key not in ("", "-") else ""
    except Exception:  # noqa: BLE001
        return ""


def mdblist(path, kind, opener=None, key=None):
    want = "movie" if kind == "movie" else "show"
    import urllib.error
    try:
        data = _json(MDBLIST % path, opener)
    except urllib.error.HTTPError as e:
        if e.code not in (401, 403):
            raise
        key = _device_key() if key is None else key
        if not key:
            log("MDBList pide clave para %s y este aparato no tiene: la fila no sale" % path)
            return []
        api = _json(MDBLIST_API % (path, urllib.parse.quote(key)), opener)        # la clave no va al registro
        data = (api.get("movies") or []) + (api.get("shows") or []) if isinstance(api, dict) else api
    return _uniq(x.get("id") for x in data or [] if isinstance(x, dict) and x.get("mediatype") == want)


# ---------- AniList ----------
_QUERY = ("query($sort:[MediaSort],$season:MediaSeason,$year:Int,$fmt:[MediaFormat]){Page(perPage:50){media("
          "type:ANIME,sort:$sort,season:$season,seasonYear:$year,format_in:$fmt,isAdult:false){id format seasonYear "
          "startDate{year} title{romaji english native}}}}")
TV_FORMATS = ["TV", "TV_SHORT", "ONA"]
QUERIES = {"top-tv": {"sort": ["SCORE_DESC"], "fmt": TV_FORMATS},
           "top-movie": {"sort": ["SCORE_DESC"], "fmt": ["MOVIE"]},
           "trending-movie": {"sort": ["TRENDING_DESC"], "fmt": ["MOVIE"]},
           "season-tv": {"sort": ["POPULARITY_DESC"], "fmt": TV_FORMATS}}


def season_now(today=None):
    """(temporada de AniList, año) de una fecha: invierno ene-mar, primavera abr-jun, verano jul-sep, otoño oct-dic"""
    import datetime
    today = today or datetime.date.today()
    return ("WINTER", "SPRING", "SUMMER", "FALL")[(today.month - 1) // 3], today.year


def variables(name, today=None):
    v = dict(QUERIES[name])
    if name == "season-tv":
        v["season"], v["year"] = season_now(today)
    return v


def bundled():
    """{anilist: (tipo, tmdb)} del mapa del addon (tools/gen_anilist_map.py)"""
    if not _MAP:
        m = {}
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "anilist_tmdb.json"),
                      encoding="utf-8") as f:
                for k, v in (json.load(f).get("m") or {}).items():
                    m[int(k)] = ("tv" if v[0] == "t" else "movie", int(v[1:]))
        except (OSError, ValueError, AttributeError):
            pass
        _MAP.append(m)
    return _MAP[0]


def _found_path():
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/anilist_map.json")


def _load_found(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def search_tmdb(m, opener=None):
    """(tipo, tmdb) del anime m (de AniList) buscado en TMDB por título (inglés, romaji, japonés) y año, entre la
    animación japonesa; None si no aparece"""
    from flix_common import TMDB_KEY
    kind = "movie" if m.get("format") == "MOVIE" else "tv"
    year = m.get("seasonYear") or (m.get("startDate") or {}).get("year")
    t = m.get("title") or {}
    for q in (t.get("english"), t.get("romaji"), t.get("native")):
        if not q:
            continue
        for y in ((year, None) if year else (None,)):
            p = {"api_key": TMDB_KEY, "query": q, "language": "en-US"}
            if y:
                p["year" if kind == "movie" else "first_air_date_year"] = y
            d = _json(TMDB + "search/%s?%s" % (kind, urllib.parse.urlencode(p)), opener) or {}
            for r in d.get("results") or []:
                if 16 in (r.get("genre_ids") or []) and (r.get("original_language") == "ja" or
                                                         "JP" in (r.get("origin_country") or [])):
                    return kind, int(r["id"])
    return None


def map_media(media, opener=None, path=None, now=time.time):
    """[(tipo, tmdb)] de los anime de AniList, en su orden, sin repetir (las temporadas de una serie son la misma
    serie en TMDB): el mapa del addon y, lo que falte, TMDB (guardado en anilist_map.json)"""
    path = path or _found_path()
    found, changed = _load_found(path), False
    base, out = bundled(), []
    for m in media or []:
        aid = m.get("id")
        hit = base.get(aid)
        if hit is None and aid is not None:
            saved = found.get(str(aid))
            if isinstance(saved, list) and len(saved) == 2 and saved[1]:
                hit = (saved[0], int(saved[1]))
            elif not (isinstance(saved, list) and len(saved) == 2 and now() - (saved[0] or 0) < MISS_RETRY and
                      not saved[1]):
                try:
                    hit = search_tmdb(m, opener)
                except Exception as e:  # noqa: BLE001  (sin red: sin ese título esta vez)
                    log("búsqueda de %s en TMDB: %s" % (aid, type(e).__name__))
                    continue
                found[str(aid)] = list(hit) if hit else [now(), 0]
                changed = True
        if hit and hit not in out:
            out.append(hit)
    if changed:
        try:
            from flix_common import atomic_write
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            atomic_write(path, json.dumps(found, separators=(",", ":")))
        except Exception as e:  # noqa: BLE001
            log("no guardo el mapa de AniList: %s" % type(e).__name__)
    return out


def anilist(name, kind, opener=None, path=None, today=None):
    body = json.dumps({"query": _QUERY, "variables": variables(name, today)}).encode()
    d = _json(ANILIST, opener, {"Content-Type": "application/json", "Accept": "application/json"}, body) or {}
    media = ((d.get("data") or {}).get("Page") or {}).get("media") or []
    return _uniq(t for k, t in map_media(media, opener, path) if k == kind)
