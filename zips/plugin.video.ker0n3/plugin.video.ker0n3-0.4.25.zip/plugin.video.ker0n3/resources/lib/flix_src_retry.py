"""Un enlace que Kodi no puede abrir → otra versión (17-nov, Carlos: «si un enlace no reproduce te sale un mensaje
de error, lo suyo sería que te dé alternativa»).

Lo lanza el servicio de Ker0n3 cuando Kodi avisa de un error al reproducir (Player.onPlayBackError) y la marca de lo
que se iba a ver (flix_src_play.mark_playing) es de hace poco. La versión que falló se apunta como mala para ese
título durante la sesión (Window(10000).flix_src_bad) y se busca otra sin ella:
  * reproducción automática: la siguiente, sola (como dice su ayuda: «si un enlace falla, se prueba el siguiente»),
    hasta AUTO_MAX veces;
  * elegida a mano, sin reproducción automática o pasadas AUTO_MAX: «Elegir versión» sin las que fallaron.
Vive en el addon Ker0n3 (lógica); para volver a reproducir usa la pantalla de la skin (flix_play.own_sources), que se
importa de special://skin/scripts (skin_scripts()).
Uso: RunScript(special://home/addons/plugin.video.ker0n3/resources/lib/flix_src_retry.py)"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

FRESH = 180             # s: una marca más vieja no es de este error
AUTO_MAX = 2
BAD = "flix_src_bad"    # Window(10000): {"tv/1399/2/3": ["hash", …]} durante la sesión
BUSY = "flix_src_retry_busy"
HEADING = "KER0N3 MEDIA"


def skin_scripts(path=None):
    """pone special://skin/scripts (las pantallas de la skin en uso) al final de sys.path, si falta; la carpeta o ''.
    Lanzado con RunScript desde el addon, este intérprete solo tiene la carpeta de la lógica"""
    path = sys.path if path is None else path
    try:
        import xbmcvfs
        d = xbmcvfs.translatePath("special://skin/scripts")
    except Exception:  # noqa: BLE001
        return ""
    if d and os.path.isdir(d) and d not in path:
        path.append(d)
    return d if d and os.path.isdir(d) else ""


def log(msg):
    import xbmc
    xbmc.log("[flix_src_retry] %s" % msg, xbmc.LOGINFO)


def title_key(m):
    return "%s/%s/%s/%s" % (m.get("kind"), m.get("tmdb"), m.get("season"), m.get("episode"))


def plan(mark_raw, bad_raw, now):
    """(info, offset, a_mano, malas, malas_json) o None si no hay nada que hacer"""
    try:
        m = json.loads(mark_raw or "")
    except ValueError:
        return None
    if not isinstance(m, dict) or m.get("kind") not in ("movie", "tv") or not m.get("tmdb"):
        return None
    try:
        if now - float(m.get("at") or 0) > FRESH:
            return None
    except (TypeError, ValueError):
        return None
    try:
        bad = json.loads(bad_raw or "{}")
    except ValueError:
        bad = {}
    if not isinstance(bad, dict):
        bad = {}
    key = title_key(m)
    lst = [x for x in bad.get(key) or [] if isinstance(x, str)]
    if m.get("pick") and m["pick"] not in lst:
        lst.append(m["pick"])
    bad[key] = lst
    info = {"tmdb": m["tmdb"], "content": "movies" if m["kind"] == "movie" else "episodes"}
    if m["kind"] == "tv":
        info.update(season=m.get("season"), episode=m.get("episode"))
    manual = bool(m.get("manual")) or len(lst) > AUTO_MAX
    return info, int(m.get("offset") or 0), manual, set(lst), json.dumps(bad)


def main():
    import xbmc
    import xbmcgui
    import flix_src_play
    home = xbmcgui.Window(10000)
    if home.getProperty(BUSY):
        return
    raw = home.getProperty(flix_src_play.K3_PLAYING)        # se borra cuando un vídeo nuestro arranca bien
    p = plan(raw, home.getProperty(BAD), time.time())
    if not p:
        return
    info, offset, manual, bad, bad_json = p
    home.setProperty(BAD, bad_json)
    home.clearProperty(flix_src_play.OWN_PLAYING)
    home.clearProperty(flix_src_play.K3_PLAYING)
    home.setProperty(BUSY, "1")
    try:
        log("%s/%s: el enlace no abre (%d malas): %s" % (info["content"], info["tmdb"], len(bad),
                                                        "elegir a mano" if manual else "pruebo otra"))
        xbmc.executebuiltin("Dialog.Close(okdialog,true)")      # el «No se pudo reproducir» de Kodi, si lo hay
        xbmcgui.Dialog().notification(HEADING, "Ese enlace no se puede abrir: " +
                                      ("elige otra versión" if manual else "pruebo otra"),
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        skin_scripts()
        import flix_play
        flix_play.own_sources("", info, offset, exclude=bad, pick=manual)
    finally:
        home.clearProperty(BUSY)


if __name__ == "__main__":
    main()
