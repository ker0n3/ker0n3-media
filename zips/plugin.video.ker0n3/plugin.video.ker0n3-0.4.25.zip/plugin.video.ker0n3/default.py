"""Ker0n3: punto de entrada del addon (Kodi lo lanza con sys.argv = [ruta, handle, «?…»])"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

from ker0n3 import router  # noqa: E402

router.run(sys.argv)
