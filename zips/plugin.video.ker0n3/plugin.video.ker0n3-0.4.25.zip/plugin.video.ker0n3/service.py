"""Ker0n3: servicio (Kodi lo arranca con el addon): apunta lo visto en la base propia y sincroniza con Simkl"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

from ker0n3 import service  # noqa: E402

service.run()
