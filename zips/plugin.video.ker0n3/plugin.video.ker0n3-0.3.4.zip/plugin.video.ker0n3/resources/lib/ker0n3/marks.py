"""Marcas del menú de pulsación larga de la skin (16-nov): con fuentes propias el menú de un título de Ker0n3 es el
mismo de siempre (FlixMenu.xml; flix_k3menu.py en la skin) y sus acciones llegan aquí por la ruta
marcar/<acción>/<tipo>/<tmdb>[/<temporada>/<capítulo>] (RunPlugin: la skin nunca importa módulos del addon).

  vista / novista   película, serie y capítulo (16-nov: «no visto» de un capítulo, desde la ficha de la serie)
  hasta             capítulo: él y todos los emitidos anteriores quedan vistos («Marcar vistos hasta aquí»)
  sinpausa          película o capítulo a medias: fuera de «Seguir viendo»
  noseguir          serie: fuera de «Series en seguimiento»
  favorita / nofavorita   película y serie: añadir o quitar de favoritos (bloque 3; ver apply)

Todo se apunta en la base de vistos de Ker0n3 (store). Lo visto y lo desmarcado se encola para el servicio en uso (Trakt o Simkl;
sync: con Simkl el anime no sale, como lo reproducido). Quitar una pausa, «vista» y «no vista» encolan además quitar la
pausa que el servicio guarde de ese título (sync.UNPAUSE, 16-nov: si no, otro aparato la volvía a bajar); salvo un
capítulo «no visto» que no estaba visto, que aquí se queda con su pausa. «Quitar progreso» vale también para la pausa
que solo tiene el servicio (sync.service_paused: la lista de la última bajada; sale de ella al momento).
Dejar de seguir (16-nov) se encola también (sync.HIDE: en Trakt oculta la serie del progreso; con Simkl se queda en
este aparato) y marcar visto un capítulo de una serie que no se seguía la vuelve a seguir también allí (sync.UNHIDE).
Al acabar se deja el resultado en Window(10000).k3_mark_done («ok», «igual» o «error», y la hora) y, si algo cambió,
se repinta como al parar un vídeo (service.poke)."""
import time

OPS = ("vista", "novista", "sinpausa", "noseguir", "hasta", "favorita", "nofavorita")
FAV_OPS = ("favorita", "nofavorita")
KINDS = {"pelicula": "movie", "serie": "tv", "capitulo": "episode"}
DONE = "k3_mark_done"       # = flix_k3menu.DONE (test_k3_menu_unico)


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.marks] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def aired(show):
    """[(temporada, capítulo)] ya emitidos según la ficha de la serie (catalog.show: solo temporadas estrenadas): las
    anteriores enteras y la del último capítulo emitido, hasta él"""
    last = show.get("last_aired")
    out = []
    for s in show.get("seasons") or []:
        n, count = int(s.get("n") or 0), int(s.get("episodes") or 0)
        if n <= 0 or (last and n > int(last[0])):
            continue
        if last and n == int(last[0]):
            count = min(count, int(last[1])) if count else int(last[1])
        out += [(n, e) for e in range(1, count + 1)]
    return out


def apply(op, kind, tmdb, season=None, episode=None, now=None, db_path=None, show=None, linked=None, enqueue=None,
          service=None, remote=None):
    """hace la marca; True si cambió algo. ValueError si esa acción no existe para ese tipo; lo demás que lance
    (sin red para la ficha de la serie, base rota) es «no se ha podido»"""
    from ker0n3 import store
    now = time.time() if now is None else now
    tmdb = int(tmdb)
    if op not in OPS or kind not in ("movie", "tv", "episode") or tmdb <= 0:
        raise ValueError("marca desconocida: %s %s" % (op, kind))
    if kind == "episode":
        if op not in ("vista", "novista", "sinpausa", "hasta") or season is None or episode is None:
            raise ValueError("marca de capítulo desconocida: %s" % op)
        season, episode = int(season), int(episode)
    if (op == "noseguir" and kind != "tv") or (op == "sinpausa" and kind == "tv") or \
            (op == "hasta" and kind != "episode"):
        raise ValueError("marca desconocida: %s %s" % (op, kind))

    def active():
        if service is not None:
            return service
        from ker0n3 import syncsvc
        return syncsvc.active()

    def push(qop, what, **kw):
        on = bool(active()) if linked is None else linked()
        if on:
            if enqueue is None:
                from ker0n3 import sync
                sync.enqueue(qop, what, **kw)
            else:
                enqueue(qop, what, **kw)

    def unpause(kind_, s=None, e=None, eps=None):
        """quitar en el servicio la pausa de lo que aquí ya no tiene (kind_: movie o tv; sin s/e ni eps, la serie)"""
        push("unpause", {"kind": kind_, "tmdb": tmdb, "season": s, "episode": e}, at=at, eps=eps)

    def sheet():
        if show is not None:
            return show(tmdb)
        from ker0n3 import catalog
        return catalog.show(tmdb)
    at = store.stamp(now)
    if op in FAV_OPS:
        # favoritos = «guardado para ver» (una sola lista; en Trakt, la watchlist; en Simkl, «Pendientes de ver»). A
        # Simkl solo va lo que no tiene nada visto: allí un título está en UNA lista (añadir uno empezado lo sacaría
        # de «viendo») y la única forma de quitarlo borra también su historial. En Trakt la watchlist no depende
        # del historial: va todo
        if kind not in ("movie", "tv"):
            raise ValueError("marca desconocida: %s %s" % (op, kind))
        changed = store.set_favorite(kind, tmdb, op == "favorita", db_path)
        if changed and (not store.has_views(kind, tmdb, db_path) or active() == "trakt"):
            push("fav_add" if op == "favorita" else "fav_del", {"kind": kind, "tmdb": tmdb})
        return changed
    if op == "sinpausa":
        from ker0n3 import sync
        changed = store.clear_pause("movie" if kind == "movie" else "tv", tmdb, season, episode, now, db_path)
        # la que solo tenía el servicio (lista de la última bajada) sale ya: el menú deja de ofrecerla
        there = sync.forget_paused({"op": sync.UNPAUSE, "kind": "movie" if kind == "movie" else "tv", "tmdb": tmdb,
                                    "eps": None if kind == "movie" else [[season, episode]]}, remote)
        unpause("movie" if kind == "movie" else "tv", season, episode)     # aunque aquí ya no estuviera
        return changed or there
    if op == "noseguir":
        changed = store.unfollow(tmdb, db_path)
        if changed:     # Trakt: oculta del progreso (en los demás aparatos tampoco sale); Simkl: solo aquí
            push("hide", {"kind": "tv", "tmdb": tmdb}, at=at)
        return changed
    if kind == "movie":
        changed = store.mark_movie(tmdb, op == "vista", now, db_path)
        if changed:
            push("watched" if op == "vista" else "unwatched", {"kind": "movie", "tmdb": tmdb}, at=at)
        unpause("movie")            # vista o no, aquí queda sin pausa (sync/history no toca sync/playback)
        return changed
    if kind == "episode" and op == "novista":
        changed = store.unmark_episode(tmdb, season, episode, db_path)
        if changed:     # una sola entrada con el capítulo, como la serie desmarcada (el anime no sale: sync.push_one)
            push("unwatched_eps", {"kind": "tv", "tmdb": tmdb}, eps=[(season, episode)])
            unpause("tv", season, episode)      # su fila (con su pausa, si la tenía) ya no está
        return changed
    def follow_again(was_hidden):
        """un capítulo visto de una serie que no se seguía la vuelve a seguir (store): también en el servicio"""
        if was_hidden:
            push("unhide", {"kind": "tv", "tmdb": tmdb}, at=at)
    if kind == "episode" and op == "hasta":
        eps = aired(sheet())            # sin ficha (sin red) lanza: no se toca nada
        upto = [x for x in eps if x <= (season, episode)]
        if not upto:
            raise ValueError("serie %s sin capítulos emitidos hasta T%s E%s" % (tmdb, season, episode))
        hidden = store.is_hidden(tmdb, db_path)
        new = store.mark_show_watched(tmdb, upto, now, db_path, total=len(eps))
        if new:
            push("watched_eps", {"kind": "tv", "tmdb": tmdb}, at=at, eps=new)
        unpause("tv", eps=upto)
        follow_again(hidden)
        return bool(new)
    if kind == "episode":
        try:
            total = len(aired(sheet())) or None
        except Exception as e:  # noqa: BLE001  (sin la ficha no se sabe si la serie queda completa; lo visto, sí)
            log("capítulos de %s: %s" % (tmdb, type(e).__name__))
            total = None
        hidden = store.is_hidden(tmdb, db_path)
        store.mark_episode(tmdb, season, episode, now, total, db_path)
        push("watched", {"kind": "tv", "tmdb": tmdb, "season": season, "episode": episode}, at=at)
        unpause("tv", season, episode)
        follow_again(hidden)
        return True
    if op == "vista":
        eps = aired(sheet())
        if not eps:
            raise ValueError("serie %s sin capítulos emitidos" % tmdb)
        new = store.mark_show_watched(tmdb, eps, now, db_path)
        if new:
            push("watched_eps", {"kind": "tv", "tmdb": tmdb}, at=at, eps=new)
        unpause("tv", eps=eps)      # lo emitido queda sin pausa (los especiales no se tocan)
        return bool(new)
    seen, n = store.mark_show_unwatched(tmdb, db_path)
    if seen:
        push("unwatched_eps", {"kind": "tv", "tmdb": tmdb}, eps=seen)
    unpause("tv")                   # fuera todos sus capítulos, y con ellos sus pausas
    return n > 0


def run(op, tipo, tmdb, season=None, episode=None, home=None, builtin=None, now=time.time):
    """la ruta marcar/…: hace la marca, deja el resultado para la skin (DONE) y, si cambió algo, repinta como al
    parar un vídeo. Devuelve «ok», «igual» (no había nada que cambiar) o «error». Nunca lanza"""
    result = "error"
    try:
        changed = apply(op, KINDS.get(tipo, tipo), int(tmdb), int(season) if season is not None else None,
                        int(episode) if episode is not None else None)
        result = "ok" if changed else "igual"
    except Exception as e:  # noqa: BLE001
        log("%s %s %s: %r" % (op, tipo, tmdb, e))
    try:
        if home is None:
            import xbmcgui
            home = xbmcgui.Window(10000)
        if result == "ok" and op not in FAV_OPS:        # un favorito no cambia ✓, barras ni las filas personales
            if builtin is None:
                import xbmc
                builtin = xbmc.executebuiltin
            from ker0n3 import service
            service.poke(home, builtin)
        home.setProperty(DONE, "%s|%f" % (result, now()))
    except Exception as e:  # noqa: BLE001
        log("sin avisar a la skin: %r" % e)
    log("%s %s %s%s: %s" % (op, tipo, tmdb, " T%s E%s" % (season, episode) if season is not None else "", result))
    return result
