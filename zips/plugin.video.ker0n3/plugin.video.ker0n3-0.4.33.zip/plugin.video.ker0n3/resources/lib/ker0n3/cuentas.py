"""Ajustes → «Cuentas»: AllDebrid, TorBox o Real-Debrid (para reproducir: una basta, flix_playaccount), Trakt (lo visto entre aparatos), PeLis (fuente extra, opcional)
y MDBList (notas, opcional), cada una con su estado.

18-nov (Carlos): la pantalla es la del editor de la skin, como «Nota de los títulos» y «Orden de calidades»
(flix_editor.py,cuentas → flix_editor_sources.AccountsSource): título, una línea de explicación y una fila por cuenta
con su estado debajo. Lo que dice cada fila lo decide rows() (aquí, en el addon, sin red); la skin solo lo pinta y, al
elegir una, abre lo suyo: adlink.menu / link.menu (rutas alldebrid / trakt / simkl del addon, con RunPlugin; mientras
están abiertas, Window(10000).k3_cuentas_run, para que la pantalla espere y se ponga al día al volver),
flix_pelis.py y flix_mdblist.py (el asistente de la clave) de la skin.
Simkl ya no se ofrece: fuera de la lista, salvo en el aparato que lo tenga vinculado (una fila para gestionarlo o
desvincularlo; sigue sincronizando igual, syncsvc). menu() es la lista de Kodi de antes, para la ruta cuentas (otra
skin o una vieja). De PeLis aquí solo se sabe si hay dirección guardada; de MDBList, si hay clave: ni la dirección ni la
clave se leen a ninguna variable de este módulo que salga de él"""

PELIS_SCRIPT = "RunScript(special://skin/scripts/flix_pelis.py)"
MDBLIST_SCRIPT = "RunScript(special://skin/scripts/flix_mdblist.py)"
DEBRIDKEY_SCRIPT = "RunScript(special://skin/scripts/flix_debridkey.py,%s)"
# TorBox y Real-Debrid (24-nov): clave pegada (skin, flix_debridkey.py); en Skin.String solo el nombre de la cuenta
KEYED = {"torbox": ("flix_torbox", "k3_tb_user"), "realdebrid": ("flix_realdebrid", "k3_rd_user")}
RUNNING = "k3_cuentas_run"      # Window(10000): un menú de cuenta del addon abierto (handlers: alldebrid, trakt, simkl)
OPTIONAL = "Opcional"
ICONS = {"alldebrid": "flix/icons/play.png", "torbox": "flix/icons/play.png", "realdebrid": "flix/icons/play.png",
         "trakt": "flix/icons/trakt.png", "pelis": "flix/icons/film.png",
         "mdblist": "flix/icons/star.png", "simkl": "flix/icons/history.png"}
HELP = ("Para reproducir hace falta una cuenta: AllDebrid, TorBox o Real-Debrid. Trakt apunta lo que ves y lo lleva a tus otros aparatos. PeLis (más "
        "versiones) y MDBList (notas de IMDb, Metacritic…) son opcionales.")


def _pelis_linked():
    try:
        import flix_src_list
        return bool(flix_src_list.load_pelis_url())
    except Exception:  # noqa: BLE001
        return False


def _mdblist_on(info):
    key = (info("Skin.String(flix_mdblist_key)") or "").strip()
    return bool(key) and key != "-"


def sync_states(trakt_on, simkl_on, active, info):
    """(estado de Trakt, estado de Simkl): la cuenta o «Sin vincular»; con los dos vinculados, cuál sincroniza"""
    from ker0n3 import adlink, link
    out = []
    for name, on in (("trakt", trakt_on), ("simkl", simkl_on)):
        st = (info("Skin.String(%s)" % link.SERVICES[name]["user"]) or "tu cuenta") if on else adlink.NONE
        if on and trakt_on and simkl_on:
            st += " · en uso" if name == active else " · en pausa"
        out.append(st)
    return tuple(out)


def _linked(who):
    """«Vinculado · carlos» (o «Vinculado» a secas si no se sabe la cuenta)"""
    from ker0n3 import adlink
    return adlink.LINKED if who in ("", adlink.LINKED, "tu cuenta") else "%s · %s" % (adlink.LINKED, who)


def keyed_state(which, info, run, mod=None):
    """TorBox / Real-Debrid: lo apuntado (o «Vinculado») si hay clave guardada; si no, «Sin vincular». Pone al día lo
    apuntado sin red, como adlink.refresh"""
    import importlib
    from ker0n3 import adlink
    name, user = KEYED[which]
    try:
        on = bool((mod or importlib.import_module(name)).load_key())
    except Exception:  # noqa: BLE001
        on = False
    saved = info("Skin.String(%s)" % user)
    if not on:
        if saved:
            run("Skin.Reset(%s)" % user)
        return adlink.NONE
    if not saved:
        run("Skin.SetString(%s,%s)" % (user, adlink.LINKED))
    return saved or adlink.LINKED


def rows(ad_api=None, trakt_api=None, simkl_api=None, active=None, info=None, run=None, pelis_linked=None,
         keyed=None):
    """[{"id", "label", "sub", "icon"}] de la pantalla Cuentas, sin red: AllDebrid, Trakt, PeLis, MDBList (y Simkl
    solo si está vinculado en este aparato)"""
    from ker0n3 import adlink
    if info is None or run is None:
        import xbmc
        info, run = info or xbmc.getInfoLabel, run or xbmc.executebuiltin
    if ad_api is None:
        import flix_alldebrid as ad_api
    if simkl_api is None:
        from ker0n3 import simkl as simkl_api
    if trakt_api is None:
        from ker0n3 import trakt as trakt_api
    if active is None:
        from ker0n3 import syncsvc
        active = syncsvc.active({"trakt": trakt_api, "simkl": simkl_api})
    ad = adlink.refresh(ad_api, info("Skin.String(%s)" % adlink.USER), run)
    trakt_on, simkl_on = trakt_api.linked(), simkl_api.linked()
    trakt, simkl = sync_states(trakt_on, simkl_on, active, info)
    # sin cuenta, a secas: lo que falta lo dice el aviso de la pantalla (missing)
    kst = {w: (keyed or {}).get(w) or keyed_state(w, info, run) for w in KEYED}
    out = [("alldebrid", "AllDebrid", _linked(ad) if ad != adlink.NONE else adlink.NONE),
           ("trakt", "Trakt", _linked(trakt) if trakt_on else adlink.NONE),
           ("pelis", "PeLis", "%s · %s" % (OPTIONAL, adlink.LINKED if (pelis_linked or _pelis_linked)() else
                                             adlink.NONE)),
           ("mdblist", "MDBList", "%s · notas · %s" % (OPTIONAL, adlink.LINKED if _mdblist_on(info) else adlink.NONE))]
    if simkl_on:        # ya no se ofrece: solo para quien lo tiene (gestionarlo o desvincularlo)
        out.append(("simkl", "Simkl", "%s · ya no se ofrece" % _linked(simkl)))
    # 24-nov: otras cuentas para reproducir (en lugar de AllDebrid), al final: la de siempre sigue arriba
    out += [("torbox", "TorBox", _linked(kst["torbox"]) if kst["torbox"] != adlink.NONE else adlink.NONE),
            ("realdebrid", "Real-Debrid", _linked(kst["realdebrid"]) if kst["realdebrid"] != adlink.NONE
             else adlink.NONE)]
    return [{"id": i, "label": label, "sub": sub, "icon": ICONS[i]} for i, label, sub in out]


def missing(rws):
    """el aviso corto de la pantalla: lo que falta para ver algo (ninguna cuenta para reproducir)"""
    from ker0n3 import adlink
    play = [r for r in rws if r["id"] in ("alldebrid", "torbox", "realdebrid")]
    return "Falta una cuenta para reproducir" if play and all(r["sub"] == adlink.NONE for r in play) else ""


def menu(handle=-1, ad_api=None, simkl_api=None, dialog=None, run=None, info=None, open_ad=None, open_simkl=None,
         pelis_linked=None, open_pelis=None, trakt_api=None, open_trakt=None, active=None, open_mdblist=None):
    """la lista de Kodi (ruta cuentas): las mismas filas que la pantalla de la skin"""
    import xbmc
    import xbmcgui
    from ker0n3 import adlink, link
    dialog = dialog or xbmcgui.Dialog()
    run = run or xbmc.executebuiltin
    info = info or xbmc.getInfoLabel
    rws = rows(ad_api, trakt_api, simkl_api, active, info, run, pelis_linked)
    pick = dialog.select("Cuentas", ["%s: %s" % (r["label"], r["sub"]) for r in rws])
    what = rws[pick]["id"] if 0 <= pick < len(rws) else None
    if what == "alldebrid":
        (open_ad or adlink.menu)()
    elif what in KEYED:
        run(DEBRIDKEY_SCRIPT % what)
    elif what == "trakt":
        (open_trakt or (lambda: link.menu(service="trakt")))()
    elif what == "simkl":
        (open_simkl or link.menu)()
    elif what == "pelis":
        (open_pelis or (lambda: run(PELIS_SCRIPT)))()
    elif what == "mdblist":
        (open_mdblist or (lambda: run(MDBLIST_SCRIPT)))()
