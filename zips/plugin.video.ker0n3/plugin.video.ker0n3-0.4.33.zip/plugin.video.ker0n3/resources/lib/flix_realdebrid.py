"""Real-Debrid para reproducir (24-nov, Carlos: «si alguien tiene Real-Debrid, que pueda usarlo», sin complicarse).
Mismas funciones que flix_alldebrid, para que flix_src_play no sepa cuál es: flix_playaccount elige.

Real-Debrid retiró en noviembre de 2024 la pregunta «¿lo tienes ya?» (/torrents/instantAvailability), así que la
única forma de saberlo es subir el torrent y mirar si sale descargado al momento. Por eso (PRECHECK = False):
  - upload prueba como mucho MAX_TRY versiones, de una en una: la sube, elige todos sus ficheros y mira si está
    «downloaded»; si no, la QUITA de la cuenta (solo la que acaba de subir: nada más se borra nunca) y sigue;
  - «Elegir versión» enseña las versiones sin comprobar y comprueba solo la que se elige (flix_src_play.choose).
API REST 1.0 (api.real-debrid.com/rest/1.0, Authorization: Bearer). La clave es el token privado de
real-debrid.com/apitoken, pegado por la skin (flix_debridkey.py); se guarda en realdebrid.json (addon_data de la skin,
0600) como la de AllDebrid."""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from flix_alldebrid import ADError, pick_file

ID, NAME = "realdebrid", "Real-Debrid"
PRECHECK = False        # no sabe si está lista sin subirla
UNLOCK = True           # abre enlaces de descarga (Linkañol, 1fichier: /unrestrict/link)
MAX_TRY = 3             # versiones que se suben para probar, como mucho, en una búsqueda
BASE = "https://api.real-debrid.com/rest/1.0"
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
SITE = "https://real-debrid.com/apitoken"
KEY_RE = r"[A-Za-z0-9]{30,64}"
READY = "downloaded"
POLLS, POLL_WAIT = 3, 0.5   # vueltas mirando el estado tras elegir los ficheros (lo que tiene lo pasa al momento)


def key_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/realdebrid.json" % xbmc.getSkinDir())


def load_key(path=None):
    try:
        with open(path or key_path(), encoding="utf-8") as f:
            return ((json.load(f) or {}).get("apikey") or "").strip()
    except (OSError, ValueError, AttributeError, TypeError):
        return ""


def save_key(key, path=None):
    path = path or key_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"apikey": key}, f)
    os.replace(tmp, path)


def forget_key(path=None):
    """desvincular: borra la clave de ESTE aparato (en la cuenta de Real-Debrid no se toca nada)"""
    try:
        os.remove(path or key_path())
    except OSError:
        pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ADError("otro", "redirección %s a otro sitio" % code)


def _open(req, timeout):
    return urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout)


def _call(method, path, data=None, opener=None, key=None):
    key = key or load_key()
    if not key:
        raise ADError("sin_clave", "no hay clave guardada")
    headers = {"User-Agent": UA, "Authorization": "Bearer " + key}
    body = urllib.parse.urlencode(data).encode() if data is not None else None
    req = urllib.request.Request(BASE + path, data=body, method=method, headers=headers)
    try:
        with (opener or _open)(req, timeout=15) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        code = 0
        try:
            code = int((json.loads(e.read().decode() or "{}") or {}).get("error_code") or 0)
        except (ValueError, AttributeError, TypeError, OSError):
            pass
        # 401 / 8 bad_token: la clave no vale; 403 / 9 permission_denied, 20 premium: sin premium o cuenta bloqueada
        kind = "sin_clave" if e.code == 401 or code == 8 else "no_premium" if e.code == 403 else "otro"
        raise ADError(kind, "HTTP %s %s %s" % (e.code, path, code or ""))
    except (urllib.error.URLError, OSError) as e:
        raise ADError("sin_red", "%s %s" % (path, type(e).__name__))
    if not raw.strip():
        return {}               # 204: elegir ficheros, borrar
    try:
        d = json.loads(raw.decode())
    except ValueError:
        raise ADError("otro", "respuesta no JSON %s" % path)
    return d if isinstance(d, dict) else {}


def user(opener=None, key=None):
    """la cuenta de la clave: {username, type, expiration…}; sirve para comprobar que la clave vale"""
    return _call("GET", "/user", opener=opener, key=key)


def account(u):
    """«nombre · premium hasta dd/mm/aaaa» (o «· sin premium»)"""
    import re
    name = " ".join(re.sub(r"[,()]", " ", str((u or {}).get("username") or "")).split()) or "Vinculado"
    if (u or {}).get("type") != "premium":
        return name + " · sin premium"
    until = str(u.get("expiration") or "")[:10]
    if len(until) == 10 and until[4] == "-":
        return "%s · premium hasta %s/%s/%s" % (name, until[8:10], until[5:7], until[:4])
    return name + " · premium"


def _try(h, opener=None, sleep=time.sleep):
    """sube una versión y mira si está lista: su id o None (la que no lo está se quita de la cuenta)"""
    tid = _call("POST", "/torrents/addMagnet", {"magnet": "magnet:?xt=urn:btih:%s" % h}, opener=opener).get("id")
    if not tid:
        return None
    try:
        _call("POST", "/torrents/selectFiles/%s" % tid, {"files": "all"}, opener=opener)
        for i in range(POLLS):
            if _call("GET", "/torrents/info/%s" % tid, opener=opener).get("status") == READY:
                return tid
            if i < POLLS - 1:
                sleep(POLL_WAIT)
    except ADError as err:
        if err.kind in ("sin_clave", "no_premium"):
            raise
    try:                        # solo lo que acabamos de subir y no estaba listo: nada más se borra nunca
        _call("DELETE", "/torrents/delete/%s" % tid, opener=opener)
    except ADError:
        pass
    return None


def upload(hashes, opener=None, sleep=time.sleep):
    """{huella: (id, lista)} de las MAX_TRY primeras, probadas de una en una; se para en la primera lista (con una
    basta: lo que falte de comprobar el audio lo hace flix_src_play con la que hay). Las demás: (None, False)"""
    out = {}
    for h in [x.lower() for x in hashes]:
        if len(out) >= MAX_TRY or any(r for _i, r in out.values()):
            out[h] = (None, False)
            continue
        tid = _try(h, opener=opener, sleep=sleep)
        out[h] = (tid, bool(tid))
    return out


def files_of(tid, opener=None):
    """los ficheros elegidos con la forma de AllDebrid (n, s, l = su enlace): Real-Debrid da un enlace por fichero
    elegido, en el mismo orden"""
    import posixpath
    d = _call("GET", "/torrents/info/%s" % tid, opener=opener)
    chosen = [f for f in d.get("files") or [] if f.get("selected")]
    links = d.get("links") or []
    return [{"n": posixpath.basename(str(f.get("path") or "")), "s": f.get("bytes") or 0, "l": link}
            for f, link in zip(chosen, links)]


def video_link(magnet_id, season=None, episode=None, opener=None, filename="", alias=None):
    f = pick_file(files_of(magnet_id, opener=opener), season, episode, filename, alias=alias)
    if not f or not f.get("l"):
        return None
    return _call("POST", "/unrestrict/link", {"link": f["l"]}, opener=opener).get("download") or None


def unlock(link, opener=None, info=None):
    """enlace de descarga (1fichier… de Linkañol) abierto con la cuenta: el que se reproduce, o None"""
    d = _call("POST", "/unrestrict/link", {"link": link}, opener=opener)
    if info is not None:
        if d.get("filename"):
            info["filename"] = str(d["filename"])
        try:
            info["gb"] = round(float(d.get("filesize") or 0) / 1e9, 2) or info.get("gb", 0)
        except (TypeError, ValueError):
            pass
    return d.get("download") or None
