"""TorBox para reproducir (24-nov, Carlos: «si alguien tiene TorBox, que pueda usarlo»). Mismas funciones que
flix_alldebrid (upload, video_link, unlock, user, clave), para que flix_src_play no sepa cuál es: flix_playaccount elige.

API v1 (SDK oficial TorBox-App/torbox-sdk-py, 24-nov): https://api.torbox.app/v1/api, clave en la cabecera
Authorization: Bearer. /torrents/checkcached?hash=a,b (¿lo tiene ya?: sin subir nada), /torrents/createtorrent
(POST multipart, magnet), /torrents/mylist?id= (sus ficheros), /torrents/requestdl?token=&torrent_id=&file_id= (el
enlace; esta pide la clave como parámetro: es la API la que lo exige) y /user/me. La clave es la API key de
torbox.app/settings, pegada por la skin (flix_debridkey.py); se guarda en torbox.json (addon_data de la skin, 0600)
como la de AllDebrid. Nunca borra nada de la cuenta: solo sube lo que ya está listo (upload no sube: pregunta)."""
import json
import os
import urllib.error
import urllib.parse
import urllib.request
import uuid

from flix_alldebrid import ADError, pick_file

ID, NAME = "torbox", "TorBox"
PRECHECK = True         # sabe si una versión está lista sin subirla (checkcached)
UNLOCK = False          # enlaces de descarga (Linkañol, 1fichier): no
BASE = "https://api.torbox.app/v1/api"
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
SITE = "https://torbox.app/settings"
KEY_RE = r"[A-Za-z0-9-]{20,80}"
CHUNK = 50              # huellas por pregunta a checkcached


def key_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/torbox.json" % xbmc.getSkinDir())


def load_key(path=None):
    try:
        with open(path or key_path(), encoding="utf-8") as f:
            return ((json.load(f) or {}).get("apikey") or "").strip()
    except (OSError, ValueError, AttributeError, TypeError):
        return ""


def save_key(key, path=None):
    path = path or key_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"apikey": key}, f)
    os.replace(tmp, path)


def forget_key(path=None):
    """desvincular: borra la clave de ESTE aparato (en la cuenta de TorBox no se toca nada)"""
    try:
        os.remove(path or key_path())
    except OSError:
        pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """la API no redirige: si lo hiciera, urllib reenviaría la clave a otro sitio"""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ADError("otro", "redirección %s a otro sitio" % code)


def _open(req, timeout):
    return urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout)


def _multipart(fields):
    """cuerpo multipart/form-data (createtorrent no admite otro): (cabecera Content-Type, bytes)"""
    b = uuid.uuid4().hex
    out = b""
    for k, v in fields.items():
        out += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (b, k, v)).encode("utf-8")
    return "multipart/form-data; boundary=%s" % b, out + ("--%s--\r\n" % b).encode()


def _call(method, path, params=None, form=None, opener=None, key=None):
    key = key or load_key()
    if not key:
        raise ADError("sin_clave", "no hay clave guardada")
    headers = {"User-Agent": UA, "Authorization": "Bearer " + key}
    body = None
    if form is not None:
        headers["Content-Type"], body = _multipart(form)
    q = ("?" + urllib.parse.urlencode(params, doseq=True)) if params else ""
    req = urllib.request.Request(BASE + path + q, data=body, method=method, headers=headers)
    try:
        with (opener or _open)(req, timeout=15) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        raise ADError("sin_clave" if e.code in (401, 403) else "otro", "HTTP %s %s" % (e.code, path))
    except (urllib.error.URLError, OSError) as e:
        raise ADError("sin_red", "%s %s" % (path, type(e).__name__))
    try:
        d = json.loads(raw.decode() or "{}")
    except ValueError:
        raise ADError("otro", "respuesta no JSON %s" % path)
    if not isinstance(d, dict):
        raise ADError("otro", "respuesta inesperada %s" % path)
    if d.get("success") is False:
        code = str(d.get("error") or "").upper()
        kind = ("sin_clave" if "AUTH" in code or "TOKEN" in code else
                "no_premium" if "PLAN" in code or "PREMIUM" in code else "otro")
        raise ADError(kind, "%s %s" % (path, code))
    return d.get("data")


def user(opener=None, key=None):
    """la cuenta de la clave: {email, plan, premium_expires_at…}; sirve para comprobar que la clave vale"""
    u = _call("GET", "/user/me", opener=opener, key=key)
    return u if isinstance(u, dict) else {}


def account(u):
    """«correo · plan» de /user/me (lo que se apunta y se enseña en Cuentas)"""
    import re
    name = " ".join(re.sub(r"[,()]", " ", str((u or {}).get("email") or "")).split())
    try:
        plan = int(float((u or {}).get("plan") or 0))
    except (TypeError, ValueError):
        plan = 0
    return (name or "Vinculado") + (" · plan gratis" if plan == 0 else "")


def upload(hashes, opener=None):
    """{huella: (huella, lista)} sin subir nada: TorBox dice cuáles tiene ya (checkcached). La «id» es la huella:
    video_link la sube entonces, y solo esa"""
    hashes = [h.lower() for h in hashes]
    ready = set()
    for i in range(0, len(hashes), CHUNK):
        part = hashes[i:i + CHUNK]
        d = _call("GET", "/torrents/checkcached", {"hash": ",".join(part), "format": "list"}, opener=opener)
        for x in (d or []) if isinstance(d, list) else (d or {}).values() if isinstance(d, dict) else []:
            if isinstance(x, dict) and x.get("hash"):
                ready.add(str(x["hash"]).lower())
    return {h: (h, h in ready) for h in hashes}


def _add(h, opener=None):
    d = _call("POST", "/torrents/createtorrent", form={"magnet": "magnet:?xt=urn:btih:%s" % h}, opener=opener)
    tid = (d or {}).get("torrent_id") or (d or {}).get("id")
    if not tid:
        raise ADError("otro", "createtorrent sin id")
    return tid


def files_of(tid, opener=None):
    """los ficheros del torrent con la forma de AllDebrid (n nombre, s tamaño, l = id del fichero) para pick_file"""
    d = _call("GET", "/torrents/mylist", {"id": tid, "bypass_cache": "true"}, opener=opener) or {}
    out = []
    for f in d.get("files") or []:
        name = f.get("short_name") or os.path.basename(str(f.get("name") or ""))
        out.append({"n": name, "s": f.get("size") or 0, "l": f.get("id")})
    return out


def video_link(magnet_id, season=None, episode=None, opener=None, filename="", alias=None):
    """magnet_id = la huella (upload): se sube (ya estaba lista: es al momento), se elige el fichero y se pide el
    enlace"""
    tid = _add(magnet_id, opener=opener)
    f = pick_file(files_of(tid, opener=opener), season, episode, filename, alias=alias)
    if not f or f.get("l") is None:
        return None
    url = _call("GET", "/torrents/requestdl", {"token": load_key(), "torrent_id": tid, "file_id": f["l"]},
                opener=opener)
    return url if isinstance(url, str) and url.startswith("http") else None


def unlock(link, opener=None, info=None):
    """TorBox no abre enlaces de descarga al momento: las versiones de Linkañol no se usan con él (UNLOCK)"""
    return None
