"""¿Con qué cuenta se reproduce? (24-nov) AllDebrid, TorBox o Real-Debrid: la primera vinculada en este aparato, en
ese orden (sin mezclar). Los tres módulos tienen las mismas funciones (upload, video_link, unlock, user, clave) y dicen
lo que saben hacer: PRECHECK (saber si una versión está lista sin subirla) y UNLOCK (abrir enlaces de descarga de
Linkañol). Sin ninguna vinculada: AllDebrid, que avisa como siempre («sin_clave» → «Vincula… en Cuentas»)."""
import importlib

ORDER = ("flix_alldebrid", "flix_torbox", "flix_realdebrid")
NAMES = "AllDebrid, TorBox o Real-Debrid"


def modules():
    return [importlib.import_module(m) for m in ORDER]


def active(mods=None):
    mods = mods if mods is not None else modules()
    for m in mods:
        try:
            if m.load_key():
                return m
        except Exception:  # noqa: BLE001  (sin Kodi o sin addon_data: como sin clave)
            continue
    return mods[0]


def any_linked(mods=None):
    mods = mods if mods is not None else modules()
    for m in mods:
        try:
            if m.load_key():
                return True
        except Exception:  # noqa: BLE001
            continue
    return False


def error_text(kind, mod=None):
    """el aviso de un fallo de la cuenta (play / handlers)"""
    name = getattr(mod, "NAME", "AllDebrid")
    return {"sin_clave": "Vincula %s en Ajustes → Cuentas" % NAMES,
            "no_premium": "%s sin premium" % name}.get(kind, "No puedo buscar enlaces ahora")
