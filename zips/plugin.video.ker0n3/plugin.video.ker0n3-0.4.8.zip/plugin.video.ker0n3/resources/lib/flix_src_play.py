"""Reproducir con fuentes propias (parte 1, 15-nov): Torrentio + Peerflix (+ PeLis) → AllDebrid → castellano primero →
Kodi Player.
Lo llama flix_play.start. Diseño:
docs/superpowers/specs/2026-11-15-enlaces-sin-palantir-design.md

16-nov (enlaces falsos y versión original; docs/superpowers/specs/2026-11-16-inicio-sin-palantir-design.md):
  * antes de subir nada, las versiones pasan flix_src_check.keep (la misma función que decide qué ENSEÑA Ker0n3):
    nivel de estreno, año, marcas de imitación e idioma por el nombre. La ficha de TMDB que piden las reglas se pide
    a la vez que las fuentes (guardada un día); sin ficha, todo como antes.
  * al comprobar el audio (la lectura de siempre, sin peticiones nuevas) se mira también la duración: la película que
    no dura lo que dice TMDB se descarta y se prueba la siguiente.
  * sin castellano ya no es «en inglés»: la versión ORIGINAL (idioma de rodaje) con subtítulos, preguntando antes."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402

import flix_src_check  # noqa: E402
import flix_src_list  # noqa: E402
import flix_src_pick  # noqa: E402

MAX_UPLOAD = 8
MAX_CHECKS = 3
MAX_LIST = 12
CACHE_TTL = 3600
HEADING = "KER0N3 MEDIA"
# plazo total de la búsqueda (listas + AllDebrid + audio), por debajo de flix_play.SEARCH_MAX (30 s), lo que aguanta la
# capa de carga sin nada que cargue: pasado el plazo se usa lo mejor comprobado hasta entonces
SEARCH_DEADLINE = 25
TMDB_IMG = "https://image.tmdb.org/t/p/original"
META_WAIT = 6       # s como mucho esperando la ficha de TMDB (se pide a la vez que las fuentes; flix_src_check.TIMEOUT 5)
# sin ninguna versión en castellano (Carlos, 15-nov tarde, Elena de Ávalor: 13 torrents, ninguno en castellano, y se
# ponía otro idioma sin avisar): se pregunta. 16-nov: lo que se ofrece es la versión ORIGINAL (el idioma en que se
# rodó) con subtítulos en castellano. La misma pregunta en flix_play y en el addon Ker0n3
VO_Q = "No está en castellano.[CR]¿Quieres ver%s en VO subtitulada?"


def vo_question(kind):
    """kind «movie» (verla) o «tv» (un capítulo: verlo)"""
    return VO_Q % ("la" if kind == "movie" else "lo")


class NoCast(str):
    """resultado «no_cast» de play(): hay enlace, pero sin castellano; quien llama hace la pregunta (flix_play).
    Es un str: se compara con "no_cast" como los demás resultados"""
    def __new__(cls, url, cand):
        o = str.__new__(cls, "no_cast")
        o.url, o.cand = url, cand
        return o


def is_cast(c):
    """castellano confirmado (audio leído) o probable (nombre); lo demás (multi, sin datos, latino, otro) no"""
    return flix_src_pick.lang_of(c or {}) in ("cast", "esp")


def direct(c):
    """¿se pone sin preguntar? Castellano, o la versión original de un título rodado en español (cualquier español,
    también latino: ES su versión original y no necesita subtítulos)"""
    c = c or {}
    return is_cast(c) or (c.get("vo_lang") == "es" and c.get("vo") in ("si", "?"))


def want_vo(kind="movie"):
    import xbmcgui
    return bool(xbmcgui.Dialog().yesno(HEADING, vo_question(kind)))


def kind_of(info):
    return "movie" if (info or {}).get("content") == "movies" else "tv"


def tell_no_version(tmdb):
    """ninguna versión de la película pasa las reglas: se le dice al addon Ker0n3 (ruta nover/…), que la apunta como
    «sin versión» y hace que sus filas se vuelvan a pedir: el usuario no se la encuentra otra vez (16-nov, S24,
    «Godzilla Minus Zero»). Por RunPlugin: la skin no importa módulos del addon. Solo con fuentes propias"""
    try:
        import xbmc
        import flix_common
        xbmc.executebuiltin("RunPlugin(%snover/pelicula/%d)" % (flix_common.K3_ROOT, int(tmdb)))
    except Exception as e:  # noqa: BLE001
        log("sin avisar al addon: %s" % e)


def tell_no_episode(tmdb, season, episode):
    """lo mismo con un capítulo que no tiene ninguna versión lista (bloque 3): el addon lo apunta unas horas como
    «Aún no disponible» y la ficha de la serie lo pinta así, debajo de los disponibles"""
    try:
        import xbmc
        import flix_common
        xbmc.executebuiltin("RunPlugin(%snover/capitulo/%d/%d/%d)" % (flix_common.K3_ROOT, int(tmdb), int(season),
                                                                      int(episode)))
    except Exception as e:  # noqa: BLE001
        log("sin avisar al addon: %s" % e)


def usable(cands, meta, lang=True):
    """las versiones que pasan las reglas de flix_src_check (las mismas que deciden qué enseña Ker0n3). lang=False:
    sin la regla del idioma («Elegir versión»: a mano se ve todo lo que sea de verdad el título)"""
    return flix_src_check.keep(cands, meta, lang=lang, log=log)


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_src_play] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


PLAYLOAD_PROP = "flix_playload"     # Window(10000): marca de la capa de carga de la skin (flix_playload.PROP)


def ours(stamp):
    """¿sigue puesta NUESTRA capa de carga? Si no (se quitó sola tras SEARCH_MAX s sin nada que cargue, u otra
    pulsación la renovó), el usuario ya no espera este vídeo: ni se reproduce ni se pregunta nada. Sin marca: sí"""
    if not stamp:
        return True
    # = flix_playload.PROP de la skin (capa de carga, Custom_1198_FlixPlayLoad.xml): la lógica no importa pantallas.
    # Si la skin ya la cargó en este intérprete se usa su Window(home) (en Kodi es la misma; en los tests, la falsa)
    pl = sys.modules.get("flix_playload")
    if pl is not None:
        return pl.HOME.getProperty(PLAYLOAD_PROP) == stamp
    import xbmcgui
    return xbmcgui.Window(10000).getProperty(PLAYLOAD_PROP) == stamp


def _img(v):
    v = v or ""
    return TMDB_IMG + v if v.startswith("/") else v


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def target(info):
    tmdb = _int((info or {}).get("tmdb"))
    if not tmdb:
        return None
    if info.get("content") == "movies":
        return ("movie", tmdb, None, None)
    s, e = _int(info.get("season")), _int(info.get("episode"))
    if info.get("content") == "episodes" and s and s > 0 and e and e > 0:
        return ("tv", tmdb, s, e)
    return None


K3_PLAYING = "k3_playing"   # Window(10000): qué va a reproducirse, para el servicio de Ker0n3 (base de vistos)
# lo mismo para la skin (flix_follow.own_episode): al acabar un capítulo puesto con fuentes propias, el siguiente lo
# pone ella
OWN_PLAYING = "flix_own_playing"
# lista de subtítulos externos del vídeo anterior (= flix_src_extsubs.PROP / PROP_N, test_src_extsubs): al empezar
# otro vídeo se borra, y con ella el botón «Otro subtítulo» de los controles
EXTSUBS, EXTSUBS_N = "flix_extsubs", "flix_extsubs_n"


def pick_key(c):
    """cómo se reconoce una versión (17-nov, enlace que no abre → otra): el hash del torrent; la de PeLis, una huella
    de su enlace (que lleva la dirección del usuario: nunca se guarda tal cual)"""
    if not c:
        return ""
    if c.get("hash"):
        return str(c["hash"])
    if c.get("url"):
        import hashlib
        return "pelis:" + hashlib.sha1(str(c["url"]).encode("utf-8")).hexdigest()[:16]
    return ""


def mark_playing(info, url, home=None, now=time.time, cand=None, offset=0, manual=False):
    """deja en Window(10000).k3_playing qué se va a reproducir (JSON kind/tmdb/season/episode/file/at): el servicio de
    Ker0n3 lo apunta en su base al parar. Con la versión (pick), dónde empezaba (offset) y si se eligió a mano: si Kodi
    no puede abrir el enlace, flix_src_retry busca otra. Nunca falla hacia fuera: la reproducción va antes"""
    t = target(info)
    if not t:
        return False
    kind, tmdb, s, e = t
    try:
        if home is None:
            import xbmcgui
            home = xbmcgui.Window(10000)
        try:
            home.clearProperty(EXTSUBS)
            home.clearProperty(EXTSUBS_N)
        except Exception:  # noqa: BLE001
            pass
        mark = json.dumps({"kind": kind, "tmdb": tmdb, "season": s, "episode": e, "file": url or "", "at": now(),
                           "pick": pick_key(cand), "offset": int(offset or 0), "manual": bool(manual)})
        home.setProperty(K3_PLAYING, mark)
        home.setProperty(OWN_PLAYING, mark)     # y para la skin (el servicio borra la suya al empezar el vídeo)
        return True
    except Exception as ex:  # noqa: BLE001
        log("k3_playing: %s" % ex)
        return False


def _cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/src_cache.json" % xbmc.getSkinDir())


def _fresh(v, now):
    """entrada de la caché con forma [hora, [versiones]] y de hace menos de CACHE_TTL"""
    return (isinstance(v, list) and len(v) == 2 and isinstance(v[0], (int, float)) and isinstance(v[1], list)
            and now() - v[0] < CACHE_TTL
            # guardada antes de 0.4.0 (sin audio ni canales): como caducada, para que «Elegir versión» los enseñe ya
            and all(isinstance(c, dict) and "au" in c for c in v[1][:1]))


_ANSWERED = [None, False]   # [clave de la última consulta a las fuentes, ¿contestaron todas?]


def mark_fresh_missing(tmdb, season, episode):
    """la precarga de la ficha no encontró ninguna versión: «Aún no disponible» durante series.FRESH_TTL (no las 6 h de
    cuando se pulsa «Ver»: un estreno de hoy puede llegar en unas horas) y la ficha, si está abierta, se repinta"""
    try:
        from ker0n3 import catalog, series
        series.mark_unavailable(tmdb, season, episode, ttl=series.FRESH_TTL)
        catalog.flush_default()
        import xbmcgui
        home = xbmcgui.Window(10000)
        if home.getProperty("flix_sheet"):
            home.setProperty("flix_eps_refresh", "0,0")
    except Exception as ex:  # noqa: BLE001
        log("sin marcar «Aún no disponible»: %s" % ex)


def no_version(found, kind, tmdb, season, episode):
    """¿de verdad no hay ninguna versión? (ni una que pase las reglas, sin contar el idioma: la versión original vale);
    con fuentes caídas no se sabe (False)"""
    if not found:
        return answered(kind, tmdb, season, episode)
    try:
        return not usable(found, flix_src_check.get(kind, tmdb), lang=False)
    except Exception:  # noqa: BLE001
        return False


def answered(kind, tmdb, season, episode):
    """¿la última búsqueda de candidates fue de ese título y contestaron todas las fuentes? («no hay torrents» de
    verdad, no fuentes caídas)"""
    return _ANSWERED[0] == "%s/%s/%s/%s" % (kind, tmdb, season, episode) and bool(_ANSWERED[1])


def _alias_kw(c):
    """la numeración de IMDb del capítulo, si es otra (flix_src_epmap), para elegir el fichero dentro del torrent"""
    return {"alias": tuple(c["alias"])} if c.get("alias") else {}


PELIS_WAIT = 0.5    # s que se espera a PeLis al reproducir si las demás ya traen castellano en la primera calidad


def top_esp(conf):
    """enough() de flix_src_list.fetch al reproducir solo (17-nov, Carlos: «si es igual de buena me da igual de dónde
    venga»): ¿hay castellano en la primera calidad encendida (y con remux, solo si se permite)?"""
    import flix_src_pick
    top = next((k for k, on in conf.order if on), None)

    def enough(cands):
        for c in cands:
            if not c.get("esp") or not flix_src_pick.allowed(c, conf):
                continue
            t = flix_src_pick.tier_of(c)
            if t == top or (t == "dv" and top == "dvhdr10"):
                return True
        return False
    return enough


def candidates(kind, tmdb, season, episode, now=time.time, cache_path=None, conf=None):
    """versiones de las fuentes (guardadas 1 h). conf (reproducir solo): a PeLis no se la espera si las demás ya traen
    castellano en la primera calidad (top_esp); entonces lo encontrado NO se guarda (le faltaría PeLis para «Elegir
    versión»)"""
    path = cache_path or _cache_path()
    key = "%s/%s/%s/%s" % (kind, tmdb, season, episode)
    try:
        with open(path, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    if not isinstance(cache, dict):
        cache = {}
    hit = cache.get(key)
    if _fresh(hit, now):
        return hit[1]
    imdb = flix_src_list.imdb_of(kind, tmdb)
    if not imdb:
        return []
    status = {}
    al = None
    if kind == "tv":        # anime largo (Naruto): la numeración de IMDb no es la de TMDB (flix_src_epmap)
        try:
            import flix_src_epmap
            al = flix_src_epmap.alias(tmdb, imdb, season, episode)
        except Exception:  # noqa: BLE001
            al = None
        if al and tuple(al) == (0, 0, 0):        # flix_src_epmap.FUERA: esa temporada es otra ficha en IMDb
            log("%s %sx%s: esa temporada no está en la ficha de IMDb %s: sin versiones" % (tmdb, season, episode, imdb))
            return []
        if al and len(al) > 3:                  # está en otra ficha de IMDb (Bleach 2x49 = tt14986406 4x9)
            log("%s %sx%s: en IMDb es %s %sx%s (otra ficha)" % (tmdb, season, episode, al[3], al[0], al[1]))
            imdb, al = al[3], tuple(al[:3])
    kw = {"pelis_wait": PELIS_WAIT, "enough": top_esp(conf)} if conf is not None else {}
    found = flix_src_list.fetch(kind, imdb, al[0] if al else season, al[1] if al else episode, status=status, **kw)
    if al:
        for c in found:
            c["alias"] = list(al)
    _ANSWERED[:] = [key, bool(status) and all(status.values())]
    # sin PeLis (no contestó, no se la esperó o su límite: flix_pelis_gate): no se guarda. Antes la lista de «Elegir
    # versión» se guardaba igual y PeLis faltaba un buen rato (19-nov, La bola negra sin sus 4K)
    if found and status.get("pelis") is not False:
        cache = {k: v for k, v in cache.items() if _fresh(v, now)}
        cache[key] = [now(), found]
        try:
            from flix_common import atomic_write
            atomic_write(path, json.dumps(cache))
        except OSError:
            pass
    return found


def resolve(cands, conf, season=None, episode=None, ad=None, audio=None, deadline=None, now=time.monotonic,
            meta=None):
    """(enlace, versión) o (None, None). Sube a AllDebrid los MAX_UPLOAD primeros torrents (antes los que dejan los
    Ajustes: calidad encendida y remux con permiso), comprueba el audio de hasta MAX_CHECKS listos (se para en el
    primer castellano) y se queda con el mejor de lo comprobado. Los que no dejan los Ajustes solo se prueban si
    ninguno de los otros tiene enlace. PeLis (15-nov): su enlace listo (⚡) se usa tal cual, sin subir nada (también
    se le mira el audio); el pendiente (⏳) nunca se pone solo. La subida se hace solo cuando hace falta el primer
    torrent: si el primero es de PeLis y vale, AllDebrid ni se toca. deadline (en el reloj now): pasado, no se prueba
    ninguno más. No borra nada de la cuenta.
    meta (ficha de flix_src_check; None = sin ella, todo como antes): la película cuya duración no cuadra con TMDB se
    descarta (se apunta por qué) y se sigue con la siguiente; y, sabiendo el idioma original, sin castellano solo
    vale una versión con audio en ese idioma (confirmado antes que sin datos; después, el orden de calidades): queda
    apuntado en la versión («vo»: si / ?, «vo_lang»). Ni castellano ni original: (None, None). Las descartadas y las
    de otro idioma no gastan las MAX_CHECKS comprobaciones; el plazo manda igual"""
    if ad is None:
        import flix_alldebrid as ad
    if audio is None:
        import flix_src_audio as audio
    from flix_alldebrid import ADError

    def late():
        return deadline is not None and now() >= deadline
    lang = (meta or {}).get("lang") or ""
    probe = getattr(audio, "probe", None)
    ranked = [c for c in flix_src_pick.order(cands, conf) if not flix_src_pick.pending(c)]
    first = [c for c in ranked if flix_src_pick.allowed(c, conf)]
    ranked = first + [c for c in ranked if not flix_src_pick.allowed(c, conf)]
    torrents = [c for c in ranked if not c.get("url")][:MAX_UPLOAD]
    keep = {id(c) for c in torrents}
    ranked = [c for c in ranked if c.get("url") or id(c) in keep]
    if not ranked or late():
        return None, None
    state = {"up": None, "err": None}

    def uploaded():
        if state["up"] is None:
            try:
                state["up"] = ad.upload([c["hash"] for c in torrents])
            except ADError as err:
                if not any(c.get("url") for c in ranked):
                    raise
                log("AllDebrid al subir: %s (sigo con PeLis)" % err.kind)
                state["up"], state["err"] = {}, err
        return state["up"]

    def check(group):
        checked, good = [], 0
        for c in group:
            if late():
                log("plazo de %d s agotado: me quedo con lo comprobado (%d)" % (SEARCH_DEADLINE, len(checked)))
                break
            if c.get("unlock"):
                link = _unlock(ad, c, ADError)      # Linkañol: el enlace de 1fichier lo abre AllDebrid ahora
                if not link:
                    continue
            elif c.get("url"):
                link = c["url"]     # PeLis listo: enlace ya abierto
            else:
                mid, ready = uploaded().get(c["hash"], (None, False))
                if not ready:
                    continue
                try:
                    link = ad.video_link(mid, season, episode, filename=c.get("filename") or "", **_alias_kw(c))
                except ADError as err:
                    if err.kind in ("sin_clave", "no_premium"):
                        raise
                    log("video_link: %s" % err.kind)
                    continue
                if not link:
                    continue
            p = probe(link) if probe else {"audio": audio.check(link)}
            got = p.get("audio") or "?"
            if got == "cast" and c.get("lat") and not c.get("esp") and not audio.cast_named(p.get("tracks")):
                got = "lat"     # el nombre dice latino y la pista es «spa» sin más: es latino, no castellano
            if got != "?":
                c["audio"] = got
            why = flix_src_check.duration_reason(p.get("duration"), meta)
            if why:
                log("descartada (%s): %s" % (why, (c.get("label") or "")[:90]))
                continue
            if lang:
                c["vo"], c["vo_lang"] = flix_src_check.vo(p.get("tracks"), lang), lang
            checked.append((c, link))
            if flix_src_pick.lang_of(c) == "cast":
                break
            good += not lang or is_cast(c) or c["vo"] != "no"
            if good >= MAX_CHECKS:
                break
        return checked

    def best_of(checked):
        cs = [c for c, _ in checked]
        if not lang or not cs:
            return flix_src_pick.order(cs, conf)[0] if cs else None
        cast = [c for c in cs if is_cast(c)]
        if cast:
            return flix_src_pick.order(cast, conf)[0]
        vo = [c for c in cs if c.get("vo") in ("si", "?")]      # sin castellano: la original, y nunca un tercer idioma
        return flix_src_pick.order(vo, conf, lang=lambda c: 0 if c["vo"] == "si" else 1)[0] if vo else None
    ok = {id(c) for c in first}
    for group in ([c for c in ranked if id(c) in ok], [c for c in ranked if id(c) not in ok]):
        checked = check(group)
        best = best_of(checked)
        if best is not None:
            return next(link for c, link in checked if c is best), best
        if checked:
            log("ninguna en castellano ni en versión original (%s) entre %d comprobadas" % (lang, len(checked)))
    if state["err"] is not None:
        raise state["err"]
    return None, None


def pick_index(ready, sub=""):
    """qué versión elige el usuario (-1 = Atrás). La ventana «Elegir versión» de la skin, con insignias
    (flix_src_pickwin, filas de flix_src_pick.row); si la skin no la trae, la lista de Kodi de siempre"""
    import xbmcgui
    import flix_src_pickwin
    try:
        return flix_src_pickwin.select(sub, [flix_src_pick.row(c) for c in ready])
    except flix_src_pickwin.Unavailable as e:
        log("«Elegir versión» con la lista de Kodi (%s)" % e)
    return xbmcgui.Dialog().select("Elegir versión", [flix_src_pick.label(c) for c in ready])


def pick_sub(info):
    """lo que va debajo de «Elegir versión»: el título, o la serie y el capítulo con la numeración que se ve
    (ker0n3.parts: «T20 E9» en las series por partes)"""
    info = info or {}
    t = target(info)
    if not t or t[0] != "tv":
        return str(info.get("title") or "")
    try:
        from ker0n3 import parts
        ep = parts.label(t[1], t[2], t[3])
    except Exception:  # noqa: BLE001
        ep = "T%d E%d" % (t[2], t[3])
    show = str(info.get("tvshowtitle") or "")
    return "%s  ·  %s" % (show, ep) if show else ep


def choose(cands, conf, season, episode, ad=None, sub=""):
    """«Elegir resolución»: lista de las listas en AllDebrid y las de PeLis (las pendientes, avisadas), y la
    elegida tal cual. sub: el título o el capítulo, debajo de «Elegir versión» (pick_sub)"""
    if ad is None:
        import flix_alldebrid as ad
    from flix_alldebrid import ADError
    ranked = flix_src_pick.order(cands, conf)[:MAX_LIST]
    torrents = [c["hash"] for c in ranked if not c.get("url")]
    try:
        up = ad.upload(torrents) if torrents else {}
    except ADError as err:
        if not any(c.get("url") for c in ranked):
            raise
        log("AllDebrid al subir: %s (solo PeLis)" % err.kind)
        up = {}
    ready = [c for c in ranked if c.get("url") or up.get(c["hash"], (None, False))[1]]
    if not ready:
        return None, None
    i = pick_index(ready, sub)
    if i < 0:
        return "cancel", None
    c = ready[i]
    if c.get("unlock"):
        return _unlock(ad, c, ADError), c
    if c.get("url"):
        return c["url"], c
    return ad.video_link(up[c["hash"]][0], season, episode, filename=c.get("filename") or "", **_alias_kw(c)), c


def _unlock(ad, c, ADError):
    """enlace de Linkañol abierto con AllDebrid, o None (se apunta por qué; sin clave o sin premium, para arriba)"""
    try:
        return ad.unlock(c["url"], info=c)
    except ADError as err:
        if err.kind in ("sin_clave", "no_premium"):
            raise
        log("Linkañol: AllDebrid no abre el enlace (%s)" % err.kind)
        return None


PREFETCH_TTL = 600      # s que vale lo precargado con la ficha abierta (el enlace directo de PeLis dura mucho más)
# s como mucho que «Ver» espera a una precarga a medias (antes que repetirla). Corto (Carlos, 18-nov: «que no aumente la
# posibilidad de fallos»): la precarga espera a PeLis entera y, si PeLis va lenta, «Ver» buscando él mismo es más rápido
PREFETCH_WAIT = 3
PREFETCH_XWAIT = 3      # s como mucho esperando a la precarga de OTRO proceso (si va lenta, se busca aquí)
_PRE = {}               # {destino: {"t": hora, "done": Event, "res": (enlace, versión) | None, "meta": ficha}}


def _pre_path():
    """lo precargado, también en disco: el clic en un capítulo de la ficha de serie (o «Seguir viendo») reproduce en
    otro proceso de Python (RunScript), que no ve _PRE"""
    return os.path.join(os.path.dirname(_cache_path()), "src_pre.json")


def _pre_key(t):
    return "%s/%s/%s/%s" % t


def _pre_save(t, url, best, now=time.time, path=None, running=False):
    """running: la precarga empieza (sin enlace aún): «Ver» desde otro proceso espera a que acabe (_pre_load)"""
    try:
        from flix_common import atomic_write
        atomic_write(path or _pre_path(), json.dumps({"key": _pre_key(t), "t": now(), "url": url, "best": best,
                                                      "running": running}))
    except (OSError, TypeError, ValueError):
        pass


def _pre_read(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _pre_load(t, now=time.time, path=None, wait=0.0, sleep=time.sleep, step=0.2):
    """(enlace, versión) del fichero si es de t y reciente; se borra al usarlo. wait: si otro proceso la está
    preparando (running, empezada hace menos de PREFETCH_WAIT s), se le espera hasta wait s: repetir la búsqueda a la
    vez gastaba el doble (Fire TV: filtrar 204 torrents ~2,5 s de CPU) y pedía todo dos veces"""
    path = path or _pre_path()
    end = now() + wait
    while True:
        d = _pre_read(path)
        if d.get("key") != _pre_key(t):
            return None
        age = now() - float(d.get("t") or 0)
        if d.get("running") and 0 <= age < PREFETCH_WAIT and now() < end:
            sleep(step)
            continue
        break
    if not d.get("url"):
        return None
    try:
        os.remove(path)
    except OSError:
        pass
    if not 0 <= age < PREFETCH_TTL:
        return None
    return d["url"], d.get("best") or {}


def _prefix_direct(cands, conf):
    """las primeras versiones en el orden de resolve() mientras sean enlaces directos de PeLis (sin subir nada a
    AllDebrid): si resolve() se queda con una de ellas, es la misma que elegiría con todas"""
    ranked = [c for c in flix_src_pick.order(cands, conf) if not flix_src_pick.pending(c)]
    first = [c for c in ranked if flix_src_pick.allowed(c, conf)]
    ranked = first + [c for c in ranked if not flix_src_pick.allowed(c, conf)]
    out = []
    for c in ranked:
        if not c.get("url") or c.get("unlock"):
            break
        out.append(c)
    return out


def prefetch(info, now=time.time):
    """agilidad (18-nov, plan aprobado por Carlos): con la ficha abierta, en segundo plano, las fuentes (guardadas 1 h:
    «Ver» ya no las pide) y la ficha de TMDB; y si lo mejor es un enlace directo de PeLis en castellano, también su
    audio, para que «Ver» arranque sin buscar. NUNCA sube nada a AllDebrid (la cuenta no se llena de lo que solo se
    miró). Solo con la reproducción automática (sin ella «Ver» abre «Elegir versión»: solo las fuentes). Devuelve el
    hilo (o None si no hay nada que precargar)"""
    t = target(info)
    if not t:
        return None
    old = _PRE.get(t)
    if old and now() - old["t"] < PREFETCH_TTL:
        return None
    entry = {"t": now(), "done": threading.Event(), "res": None, "meta": None}
    _PRE.clear()                # solo la última ficha: lo de otra ya no se va a usar
    _PRE[t] = entry

    def run():
        _pre_save(t, "", {}, now=now, running=True)
        try:
            import flix_quality
            kind, tmdb, s, e = t
            conf = flix_quality.load()
            found = candidates(kind, tmdb, s, e)
            if kind == "tv" and s and e and no_version(found, kind, tmdb, s, e):
                # capítulo sin ninguna versión de verdad (19-nov, Carlos: Nocturno 1x05 salía disponible el día de su
                # estreno y al pulsar «Ver» decía que no): «Aún no disponible» en la ficha antes de pulsar nada
                log("%s: precarga: ninguna versión: «Aún no disponible» (1 h)" % (t,))
                mark_fresh_missing(tmdb, s, e)
                return
            if not found or not conf.auto:
                return
            meta = flix_src_check.get(kind, tmdb)
            entry["meta"] = meta
            direct_first = _prefix_direct(usable(found, meta, lang=meta is not None), conf)
            if not direct_first:
                return
            url, best = resolve(direct_first, conf, s, e, deadline=time.monotonic() + SEARCH_DEADLINE, meta=meta)
            if url and direct(best):
                entry["res"] = (url, best)
                _pre_save(t, url, best)
                log("%s: precargado %s" % (t, flix_src_pick.label(best)))
        except Exception as ex:  # noqa: BLE001
            log("%s: precarga: %s" % (t, ex))
        finally:
            if not entry["res"] and _pre_read(_pre_path()).get("key") == _pre_key(t):
                _pre_save(t, "", {}, now=now)      # acabó sin enlace: nadie espera más
            entry["done"].set()
    th = threading.Thread(target=run, name="flix_src_prefetch", daemon=True)
    th.start()
    return th


def _prefetched(t, now=time.time, wait=PREFETCH_WAIT):
    """(enlace, versión, ficha) precargados para t, esperando hasta wait s si la precarga sigue; None si no hay"""
    entry = _PRE.get(t)
    if not entry or now() - entry["t"] >= PREFETCH_TTL:
        hit = _pre_load(t, now=now, wait=min(wait, PREFETCH_XWAIT))     # preparado (o preparándose) en otro proceso
        return hit + (None,) if hit else None
    if not entry["done"].wait(wait):
        return None
    if not entry["res"]:
        return None
    _PRE.pop(t, None)           # se usa una vez: «Ver» otra vez (o «Otra versión») busca de nuevo
    _pre_load(t, now=now)       # y el fichero, también
    return entry["res"] + (entry["meta"],)


def play(info, offset=0, pick=False, stamp=None, exclude=()):
    """"played" (empezó), "cancelled" (el usuario cerró «Elegir versión»), "none" (nada listo), "error" (AllDebrid, ya
    avisado), "abandoned" (la capa de carga stamp ya no es nuestra: nada que hacer, sin avisos) o NoCast ("no_cast":
    lo mejor no es castellano sino la versión original; no se reproduce: flix_play pregunta). En none/error flix_play
    avisa. Lo elegido a mano en «Elegir versión» se reproduce tal cual"""
    import xbmcgui
    import flix_quality
    import flix_alldebrid
    t = target(info)
    if not t:
        return "none"
    kind, tmdb, s, e = t
    t0 = time.monotonic()
    conf = flix_quality.load()
    cands, url, best, err, found = [], None, None, None, []
    manual = pick or not conf.auto
    hit = None if manual or exclude else _prefetched(t)
    if hit:                 # precargado con la ficha abierta (prefetch): sin buscar
        url, best, meta = hit
        if not ours(stamp):
            log("%s: la capa de carga ya no es nuestra tras %.1f s: no reproduzco ni pregunto" % (t, time.monotonic() - t0))
            return "abandoned"
        log("%s: %s (precargado, %.1f s)" % (t, flix_src_pick.label(best), time.monotonic() - t0))
        start_playback(info, url, best, offset, subs=manual_vo(best, meta))
        return "played"
    # la ficha de TMDB para las reglas, a la vez que las fuentes (guardada un día: lo normal es que no pida nada)
    got = {}
    th = threading.Thread(target=lambda: got.update(meta=flix_src_check.get(kind, tmdb)), name="flix_src_meta",
                          daemon=True)
    th.start()
    try:
        found = candidates(kind, tmdb, s, e, conf=None if manual else conf)
        if found:               # sin versiones no hay nada que filtrar: no se espera a TMDB
            th.join(META_WAIT)
        meta = got.get("meta")
        # sin ficha no se sabe el idioma original: la regla del idioma no se aplica (como antes)
        cands = usable(found, meta, lang=not manual and meta is not None)
        if exclude:         # las que Kodi no pudo abrir (flix_src_retry)
            cands = [c for c in cands if pick_key(c) not in exclude]
        if not cands:
            log("%s: %s" % (t, "ninguna versión pasa las reglas (%d torrents)" % len(found) if found
                            else "ningún torrent"))
            if found and meta is not None and kind == "movie":
                tell_no_version(tmdb)
        elif manual:
            url, best = choose(cands, conf, s, e, sub=pick_sub(info))
        else:
            url, best = resolve(cands, conf, s, e, deadline=t0 + SEARCH_DEADLINE, meta=meta)
    except flix_alldebrid.ADError as ex:
        err = ex
    if not ours(stamp):
        log("%s: la capa de carga ya no es nuestra tras %.1f s: no reproduzco ni pregunto" % (t, time.monotonic() - t0))
        return "abandoned"
    if err is not None:
        log("AllDebrid: %s" % err.kind)
        msg = {"sin_clave": "Vincula AllDebrid en Ajustes → Cuentas", "no_premium": "AllDebrid sin premium"}.get(
            err.kind, "No puedo buscar enlaces ahora")
        xbmcgui.Dialog().notification(HEADING, msg, xbmcgui.NOTIFICATION_WARNING, 4000)
        return "error"
    if url == "cancel":
        return "cancelled"
    if not url:
        if cands:
            log("%s: nada listo en AllDebrid (%d torrents, %.1f s)" % (t, len(cands), time.monotonic() - t0))
        if kind == "tv" and (found or answered(kind, tmdb, s, e)):
            # capítulo sin ninguna versión que se pueda poner (no fuentes caídas): «Aún no disponible» en su ficha
            tell_no_episode(tmdb, s, e)
        return "none"
    log("%s: %s (%.1f s, %d torrents)" % (t, flix_src_pick.label(best), time.monotonic() - t0, len(cands)))
    if conf.auto and not pick and not direct(best):       # lo elegido a mano va tal cual
        log("%s: sin versión en castellano: no pongo la original sin preguntar" % (t,))
        return NoCast(url, best)
    vo = manual_vo(best, meta if found else None)
    start_playback(info, url, best, offset, subs=vo, manual=manual)
    return "played"


def manual_vo(best, meta):
    """lo elegido a mano (o sin reproducción automática) que no es castellano: también con subtítulos en castellano y
    el audio en el idioma original (Taboo 1x01 «VO probable» elegida a mano salía sin subtítulos, S24 16-nov). True
    si hay que pedirlos; apunta el idioma original en la versión para flix_src_subs"""
    if not best or is_cast(best) or direct(best):
        return False
    lang = (meta or {}).get("lang") or ""
    if lang and not best.get("vo_lang"):
        best["vo_lang"] = lang
    return True


def show_name(tmdb):
    """nombre de la serie de lo que ya tiene guardado el addon (su ficha, aunque haya caducado; sin red): el capítulo
    lanzado sin abrir la ficha de la serie («Seguir viendo» del Inicio, el siguiente encadenado) no lo traía y el
    reproductor ponía «1x02» a secas (Carlos, 18-nov). '' si no está"""
    try:
        from ker0n3 import catalog
        d = catalog.default_cache().get("tv%s" % tmdb, 0, stale=True) or {}
        return str(d.get("title") or "")
    except Exception:  # noqa: BLE001
        return ""


def start_playback(info, url, cand=None, offset=0, subs=False, manual=False):
    """reproduce url con el título y las imágenes de la ficha. subs: después, subtítulos en castellano y, si la
    versión trae varias pistas, el audio en el idioma original (cand «vo_lang»): flix_src_subs, en otro hilo"""
    import xbmc
    import xbmcgui
    title = info.get("title") or ""
    li = xbmcgui.ListItem(label=title, path=url)
    li.setArt({"fanart": _img(info.get("fanart")), "poster": _img(info.get("poster") or info.get("thumb"))})
    t = target(info)
    if t and t[0] == "tv" and not title:
        # capítulo de Ker0n3: su ruta no trae el nombre. «20x09» en las series por partes (parts.short: solo lo guardado)
        try:
            from ker0n3 import parts
            title = parts.short(t[1], t[2], t[3])
        except Exception:  # noqa: BLE001
            title = "%dx%02d" % (t[2], t[3])
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if t:
            # su ficha (bloque 3): con ella el reproductor sabe qué suena (VideoPlayer.Season / Episode /
            # UniqueID(tmdb)) → aviso «Siguiente capítulo», «Saltar intro» y «Similares» también con fuentes propias
            tag.setMediaType("movie" if t[0] == "movie" else "episode")
            tag.setUniqueIDs({"tmdb": str(t[1])}, "tmdb")
            if t[0] == "tv":
                tag.setSeason(int(t[2]))
                tag.setEpisode(int(t[3]))
                show = info.get("tvshowtitle") or show_name(t[1])
                if show:
                    tag.setTvShowTitle(str(show))
    except (AttributeError, TypeError):     # Kodi sin InfoTag (anterior a 20)
        li.setInfo("video", {"title": title})
    if offset > 0:
        li.setProperty("StartOffset", str(int(offset)))
    mark_playing(info, url, cand=cand, offset=offset, manual=manual)    # el servicio lo apunta al parar (vistos)
    xbmc.Player().play(url, li, False)
    if subs:
        import flix_src_subs
        lang = (cand or {}).get("vo_lang") or ""
        if lang:
            flix_src_subs.start(url, audio=lang)
        else:
            flix_src_subs.start(url)
    elif flix_src_pick.lang_of(cand or {}) == "cast":
        import flix_src_subs
        flix_src_subs.start_castellano(url)     # varias pistas: que no arranque en italiano o inglés
