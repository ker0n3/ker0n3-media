"""Listados y reproducción de Ker0n3: lo que Kodi pide por cada ruta (sin Palantir, parte 2b+2c; 15-nov)"""
import threading
import time

from ker0n3 import avail, catalog, router

HEADING = "KER0N3 MEDIA"
SEARCH_BUDGET = 20      # s para toda la búsqueda de series (buscar + fichas + disponibilidad)
MOVIE_AVAIL_BUDGET = 12     # s para la disponibilidad de las películas (la fila de películas sale antes)


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def notify(msg):
    import xbmcgui
    xbmcgui.Dialog().notification(HEADING, msg, xbmcgui.NOTIFICATION_WARNING, 4000)


def label_of(title, year, q, esp=True):
    lab = "%s (%d)" % (title, year) if year else title
    # flix_items.langs_from_label necesita ≥2 corchetes para leer el idioma; «?» = calidad desconocida.
    # esp=False: comprobado que no hay castellano y sí versión original (16-nov: también se enseña) → «VO».
    # esp=None: no se sabe (sin comprobar) → UN solo corchete, sin rótulo de idioma (16-nov, «Manhunt»: decía «[Esp]»)
    return lab + ("" if esp is None else " [%s]" % ("Esp" if esp else "VO")) + " [%s]" % (q or "?")


def _tag(li, d, mediatype):
    t = li.getVideoInfoTag()
    t.setMediaType(mediatype)
    t.setTitle(d.get("title") or "")
    if d.get("plot"):
        t.setPlot(d["plot"])
    if d.get("year"):
        t.setYear(int(d["year"]))
    if d.get("genres"):
        t.setGenres(list(d["genres"]))
    if d.get("rating"):
        t.setRating(float(d["rating"]))
    if d.get("duration"):
        t.setDuration(int(d["duration"]))
    if d.get("mpaa"):
        t.setMpaa(d["mpaa"])
    if d.get("premiered"):
        t.setPremiered(d["premiered"])
    if d.get("tmdb"):
        t.setUniqueIDs({"tmdb": str(d["tmdb"])}, "tmdb")
    return t


def _art(d):
    return {k: v for k, v in (("poster", d.get("poster")), ("fanart", d.get("fanart")), ("thumb", d.get("poster")),
                              ("clearlogo", d.get("clearlogo"))) if v}


def movie_item(d, q="", esp=True):
    import xbmcgui
    li = xbmcgui.ListItem(label_of(d.get("title") or "", d.get("year") or 0, q, esp), path=router.url_play_movie(d["tmdb"]))
    _tag(li, d, "movie")
    li.setArt(_art(d))
    li.setProperty("IsPlayable", "true")
    return li


def show_item(d, q="", esp=True):
    import xbmcgui
    li = xbmcgui.ListItem(label_of(d.get("title") or "", d.get("year") or 0, q, esp), path=router.url_show(d["tmdb"]))
    _tag(li, d, "tvshow")
    li.setArt(_art(d))
    return li


def _end(handle, content, ok=True):
    import xbmcplugin
    if content:
        xbmcplugin.setContent(handle, content)
    xbmcplugin.endOfDirectory(handle, succeeded=ok, cacheToDisc=False)


def query_changed(text):
    """el buscador de la skin ya busca otra cosa (Window(home).flix_query, flix_search.run_search): lo que quede de
    esta búsqueda no lo va a ver nadie. Sin la propiedad (ruta abierta desde otro sitio) no se da por cambiada"""
    try:
        import xbmcgui
        now = xbmcgui.Window(10000).getProperty("flix_query") or ""
    except Exception:  # noqa: BLE001
        return False
    return bool(now.strip()) and now.strip().lower() != (text or "").strip().lower()


def _last_aired_many(tmdbs, workers=6, timeout=12, cancel=None):
    """{tmdb: last_aired o None} de las fichas que SÍ se obtuvieron (en paralelo, con plazo). Las que fallan o no llegan
    a tiempo quedan ausentes: son desconocidas, no «nada emitido». cancel(): True = no coger más"""
    out, lock, queue = {}, threading.Lock(), list(tmdbs)
    stop = threading.Event()

    def worker():
        while True:
            with lock:
                if stop.is_set() or not queue:
                    return
            if cancel is not None and cancel():
                return
            with lock:
                if not queue:
                    return
                tmdb = queue.pop(0)
            try:
                last = (catalog.show(tmdb) or {}).get("last_aired")
            except Exception:  # noqa: BLE001
                continue
            with lock:
                out[tmdb] = last
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(max(1, min(workers, len(queue))))]
    for th in threads:
        th.start()
    end = time.monotonic() + timeout
    for th in threads:
        th.join(max(0, end - time.monotonic()))
    stop.set()
    with lock:
        return dict(out)


def search(handle, kind, text):
    import xbmcplugin
    tmdb_kind = "tv" if kind == "series" else "movie"
    if not (text or "").strip():
        _end(handle, "tvshows" if tmdb_kind == "tv" else "movies")
        return
    t0 = time.monotonic()
    results = catalog.search(text, tmdb_kind)[:20]

    def left():
        return max(1, SEARCH_BUDGET - (time.monotonic() - t0))

    def cancel():
        return query_changed(text)
    if tmdb_kind == "tv":
        lasts = _last_aired_many([r["tmdb"] for r in results], timeout=left() * 0.6, cancel=cancel)
        items = [("tv", r["tmdb"], lasts[r["tmdb"]]) for r in results if r["tmdb"] in lasts]
        budget = left()
    else:
        items = [("movie", r["tmdb"], None) for r in results]
        budget = MOVIE_AVAIL_BUDGET
    ok = avail.many(items, timeout=budget, cancel=cancel) if items else {}
    shown, solo = 0, avail.solo_esp()
    for r in results:
        a = ok.get(r["tmdb"])
        if a is not None and not avail.shows(a, solo):
            continue
        q, esp = (a or {}).get("q", ""), avail.has_esp(a)
        if tmdb_kind == "tv":
            xbmcplugin.addDirectoryItem(handle, router.url_show(r["tmdb"]), show_item(r, q, esp), isFolder=True)
        else:
            xbmcplugin.addDirectoryItem(handle, router.url_play_movie(r["tmdb"]), movie_item(r, q, esp), isFolder=False)
        shown += 1
    log("buscar %s %r: %d de %d" % (kind, text, shown, len(results)))
    _end(handle, "tvshows" if tmdb_kind == "tv" else "movies")


def seasons(handle, tmdb):
    import xbmcgui
    import xbmcplugin
    s = catalog.show(tmdb)
    for x in s.get("seasons") or []:
        li = xbmcgui.ListItem(x["name"], path=router.url_season(tmdb, x["n"]))
        t = li.getVideoInfoTag()
        t.setMediaType("season")
        t.setSeason(int(x["n"]))
        t.setTitle(x["name"])
        t.setTvShowTitle(s.get("title") or "")
        if x.get("plot") or s.get("plot"):
            t.setPlot(x.get("plot") or s.get("plot"))
        if x.get("year"):
            t.setYear(int(x["year"]))
        if s.get("genres"):
            t.setGenres(list(s["genres"]))
        li.setArt({k: v for k, v in (("poster", x.get("poster") or s.get("poster")), ("fanart", s.get("fanart")),
                                     ("clearlogo", s.get("clearlogo"))) if v})
        li.setProperty("TotalEpisodes", str(x.get("episodes") or 0))
        li.setProperty("WatchedEpisodePercent", "0")    # ✓ y «En progreso»: la skin, de la base (flix_series.seasons_seen)
        xbmcplugin.addDirectoryItem(handle, router.url_season(tmdb, x["n"]), li, isFolder=True)
    # qué capítulo toca («Seguir viendo · T1 E4», «Al día», «Ver de nuevo»): con lo guardado, para la skin (bloque 3)
    try:
        from ker0n3 import series
        series.publish(tmdb, series.of(tmdb, show=s))
    except Exception as e:  # noqa: BLE001  (sin base o sin ficha: la skin se queda con «Ver»)
        log("estado de la serie %s: %r" % (tmdb, e))
    _end(handle, "seasons")


def _episode_marks(tmdb, season):
    """({capítulo: (visto, %, duración)}, {capítulos sin versión}) de lo guardado; nunca lanza"""
    marks, off = {}, set()
    try:
        from ker0n3 import series, store
        marks = store.season_marks(tmdb, season)
        off = series.unavailable(tmdb, season)
    except Exception as e:  # noqa: BLE001
        log("vistos de %s T%s: %r" % (tmdb, season, e))
    return marks, off


def episodes(handle, tmdb, season):
    """capítulos EMITIDOS de la temporada, como los daba Palantir (bloque 3): «1x03 Título», ✓ y barra de la base
    propia, fecha a la española (flix_date: «5 nov»). Los emitidos que se sabe que no tienen versión no salen
    (series.unavailable): la ficha los pinta debajo con los que están por llegar"""
    import xbmcgui
    import xbmcplugin
    import flix_common
    from ker0n3 import series
    s = catalog.show(tmdb)
    marks, off = _episode_marks(tmdb, season)
    today = series.today()
    for e in catalog.episodes(tmdb, season):        # solo los ya emitidos
        n = e.get("n")
        if not isinstance(n, int) or n in off:
            continue
        url = router.url_play_episode(tmdb, season, n)
        li = xbmcgui.ListItem(("%sx%02d %s" % (int(season), n, e.get("title") or "")).strip(), path=url)
        t = li.getVideoInfoTag()
        t.setMediaType("episode")
        t.setTitle(e.get("title") or "")
        t.setTvShowTitle(s.get("title") or "")
        t.setSeason(int(season))
        t.setEpisode(int(n))
        if e.get("plot"):
            t.setPlot(e["plot"])
        if e.get("duration"):
            t.setDuration(int(e["duration"]))
        if e.get("premiered"):
            t.setPremiered(e["premiered"])
        if e.get("rating"):
            t.setRating(float(e["rating"]))
        t.setUniqueIDs({"tmdb": str(tmdb)}, "tmdb")
        seen, pct, runtime = marks.get(n, (0, 0.0, 0))
        total = runtime or e.get("duration") or s.get("duration") or 0
        if pct > 0 and total:
            t.setResumePoint(round(total * pct / 100.0, 3), float(total))      # barra; el clic pregunta «Te quedaste en…»
        elif seen > 0:
            t.setPlaycount(int(seen))                                          # ✓
        li.setArt({k: v for k, v in (("thumb", e.get("still") or s.get("fanart")), ("fanart", s.get("fanart")),
                                     ("poster", s.get("poster")), ("clearlogo", s.get("clearlogo"))) if v})
        li.setProperty("IsPlayable", "true")
        li.setProperty("flix_date", flix_common.date_es(e.get("premiered") or "", today))
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    _end(handle, "episodes")


def info_movie(handle, tmdb):
    """un solo elemento con la ficha entera (la skin lo pide por JSON-RPC para su ficha de película)"""
    import xbmcplugin
    d = catalog.movie(tmdb)
    a = avail.cached("movie", int(tmdb)) or {}       # solo caché: la ficha no espera a la red
    xbmcplugin.addDirectoryItem(handle, router.url_play_movie(tmdb), movie_item(d, a.get("q", ""), avail.has_esp(a)),
                                isFolder=False)
    _end(handle, "movies")


def _tag_episode(li, tmdb, season, episode):
    t = li.getVideoInfoTag()
    t.setMediaType("episode")
    t.setSeason(int(season))
    t.setEpisode(int(episode))
    t.setUniqueIDs({"tmdb": str(tmdb)}, "tmdb")     # «Saltar intro» y el aviso del siguiente saben qué serie es
    try:
        t.setTvShowTitle((catalog.show(tmdb) or {}).get("title") or "")
    except Exception:  # noqa: BLE001
        pass
    try:
        for e in catalog.episodes(tmdb, season):
            if e.get("n") == int(episode):
                t.setTitle(e.get("title") or "")
                break
    except Exception:  # noqa: BLE001
        pass


def _play(handle, kind, tmdb, season=None, episode=None):
    import xbmcgui
    import xbmcplugin
    import flix_alldebrid
    import flix_quality
    import flix_src_play
    conf = flix_quality.load()
    t0 = time.monotonic()
    url, found = None, 0
    try:
        cands = flix_src_play.candidates(kind, int(tmdb), season, episode)
        if cands:
            # la ficha para las reglas contra enlaces falsos (flix_src_check, 16-nov): del catálogo, la misma que usa
            # la disponibilidad; ya guardada (y la película la pide de todos modos más abajo). Sin ficha: como antes
            try:
                import flix_src_check
                meta = flix_src_check.from_sheet(catalog.movie(tmdb) if kind == "movie" else catalog.show(tmdb))
            except Exception as e:  # noqa: BLE001
                log("ficha para las reglas: %s" % e)
                meta = None
            found = len(cands)
            cands = flix_src_play.usable(cands, meta, lang=bool(conf.auto) and meta is not None)
            if not cands and meta is not None and kind == "movie":
                # ninguna pasa las reglas: «sin versión» ya, para que no vuelva a salir en las filas
                log("ninguna versión pasa las reglas (%d torrents)" % found)
                try:
                    from ker0n3 import lists
                    lists.no_version("movie", int(tmdb))
                    lists.flush_default()
                except Exception as e:  # noqa: BLE001
                    log("sin apuntar: %r" % e)
        if cands and conf.auto:
            url, best = flix_src_play.resolve(cands, conf, season, episode,
                                              deadline=t0 + flix_src_play.SEARCH_DEADLINE, meta=meta)
        elif cands:
            import xbmc
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
            url, best = flix_src_play.choose(cands, conf, season, episode)
            if url == "cancel":
                url = None
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return
    except flix_alldebrid.ADError as e:
        log("AllDebrid: %s" % e.kind)
        notify({"sin_clave": "Vincula AllDebrid en Ajustes → Cuentas", "no_premium": "AllDebrid sin premium"}.get(
            e.kind, "No puedo buscar enlaces ahora"))
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    if not url:
        if kind == "tv" and (found or flix_src_play.answered(kind, int(tmdb), season, episode)):
            no_episode(handle, tmdb, season, episode)       # «Aún no disponible» en la ficha (no con fuentes caídas)
        notify("No hay versión lista ahora mismo")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    if conf.auto and not flix_src_play.direct(best):
        # ninguna en castellano (15-nov tarde): se pregunta por la versión original (16-nov; lo elegido a mano en el
        # selector va tal cual)
        import xbmc
        log("sin versión en castellano: pregunto por la original")
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
        if not flix_src_play.want_vo(kind):
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        # subtítulos en castellano (y la pista de audio original) cuando arranque: script aparte, porque este proceso
        # acaba al resolver
        lang = (best or {}).get("vo_lang") or ""
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_src_subs.py%s)" % ("," + lang if lang else ""))
    elif not conf.auto and best and not flix_src_play.is_cast(best) and not flix_src_play.direct(best):
        # elegido a mano y no castellano (Taboo 1x01, S24 16-nov): subtítulos en castellano y el audio original
        import xbmc
        lang = (best or {}).get("vo_lang") or ((meta or {}).get("lang") if cands else "") or ""
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_src_subs.py%s)" % ("," + lang if lang else ""))
    elif (best or {}).get("audio") == "cast":
        # castellano confirmado en un fichero con varias pistas: que suene esa (Slow Horses 3x05 arrancaba en italiano)
        import xbmc
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_src_subs.py,castellano)")
    li = xbmcgui.ListItem(path=url)
    try:        # el enlace ya está: ninguna ficha que falle puede perderlo
        if kind == "movie":
            _tag(li, catalog.movie(tmdb), "movie")
        else:
            _tag_episode(li, tmdb, season, episode)
    except Exception as e:  # noqa: BLE001
        log("ficha al reproducir: %s" % e)
    # para el servicio de Ker0n3: qué se reproduce (base de vistos; flix_src_play.mark_playing)
    flix_src_play.mark_playing({"tmdb": tmdb, "content": "movies" if kind == "movie" else "episodes",
                                "season": season, "episode": episode}, url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def play_movie(handle, tmdb):
    _play(handle, "movie", tmdb)


def play_episode(handle, tmdb, season, episode):
    _play(handle, "tv", tmdb, int(season), int(episode))


def resume(handle):
    """fila «Seguir viendo» de la base de Ker0n3 (personal.resume)"""
    from ker0n3 import personal
    personal.resume(handle)


def follow(handle):
    """fila «Series en seguimiento» de la base de Ker0n3 (personal.follow)"""
    from ker0n3 import personal
    personal.follow(handle)


def favorites(handle, tipo, todo=None):
    """filas de favoritos de la base de Ker0n3 (personal.favorites): peliculas o series; todo: todos («Ver más»)"""
    from ker0n3 import personal
    personal.favorites(handle, tipo, whole=todo == "todo")


def similar(handle, tipo, tmdb):
    """«Ver similares» de un título (lists.similar): parecidos de TMDB con la regla de las filas"""
    from ker0n3 import lists
    lists.similar(handle, tipo, tmdb)


def list_row(handle, key):
    """fila de una lista del Inicio (lists.directory): Top 10, novedades, plataformas, géneros…"""
    from ker0n3 import lists
    lists.directory(handle, key)


def list_all(handle, key):
    """la lista entera («Ver más» de la fila)"""
    from ker0n3 import lists
    lists.directory(handle, key, whole=True)


def list_rest(handle, key, shown):
    """«Ver más» de una fila: solo lo que viene tras los `shown` títulos que ya enseña"""
    from ker0n3 import lists
    lists.directory(handle, key, rest=int(shown))


def cards_row(handle, group):
    """fila de tarjetas de una sección (cards.directory): sagas, géneros, años"""
    from ker0n3 import cards
    cards.directory(handle, group)


def cards_all(handle, group):
    """todas las tarjetas del grupo («Más…» de la fila)"""
    from ker0n3 import cards
    cards.directory(handle, group, whole=True)


def no_version(handle, tipo, tmdb):
    """la skin, al reproducir: ninguna versión de la película pasó las reglas → «sin versión» ya, y sus filas al día"""
    try:
        from ker0n3 import lists
        lists.no_version("movie", int(tmdb))
        lists.flush_default()
    except Exception as e:  # noqa: BLE001
        log("nover %s: %r" % (tmdb, e))


def no_episode(handle, tmdb, season, episode):
    """la skin, al reproducir: ninguna versión del capítulo → «Aún no disponible» unas horas (series.unavailable), y
    la ficha de la serie, si está abierta, repinta su lista (flix_eps_refresh, como tras una marca del menú)"""
    try:
        from ker0n3 import series
        series.mark_unavailable(tmdb, season, episode)
        catalog.flush_default()
        import xbmcgui
        home = xbmcgui.Window(10000)
        if home.getProperty("flix_sheet"):
            home.setProperty("flix_eps_refresh", "0,0")
    except Exception as e:  # noqa: BLE001
        log("nover capítulo %s %sx%s: %r" % (tmdb, season, episode, e))


def mark(handle, op, tipo, tmdb, season=None, episode=None):
    """menú de pulsación larga de la skin: vista / no vista, quitar la pausa, dejar de seguir (marks.run)"""
    from ker0n3 import marks
    marks.run(op, tipo, tmdb, season, episode)


def simkl_menu(handle):
    """Ajustes → «Simkl» (RunPlugin): vincular, sincronizar ahora o desvincular (link.menu)"""
    from ker0n3 import link
    link.menu(handle)


def trakt_menu(handle):
    """Cuentas → «Trakt» (RunPlugin): vincular con código, sincronizar ahora, comprobar o desvincular (link.menu)"""
    from ker0n3 import link
    link.menu(handle, service="trakt")


def alldebrid_menu(handle):
    """Cuentas → «AllDebrid» (RunPlugin): vincular con código, comprobar o desvincular (adlink.menu)"""
    from ker0n3 import adlink
    adlink.menu(handle)


def cuentas_menu(handle):
    """Ajustes → «Cuentas» (RunPlugin): AllDebrid, Trakt y Simkl con su estado (cuentas.menu)"""
    from ker0n3 import cuentas
    cuentas.menu(handle)


def root(handle):
    _end(handle, "", ok=True)


HANDLERS = {"search": search, "seasons": seasons, "episodes": episodes, "play_movie": play_movie,
            "play_episode": play_episode, "info_movie": info_movie, "root": root,
            "simkl": simkl_menu, "trakt": trakt_menu, "alldebrid": alldebrid_menu, "cuentas": cuentas_menu, "resume": resume, "follow": follow,
            "list": list_row, "list_all": list_all, "list_rest": list_rest, "mark": mark, "no_version": no_version,
            "no_episode": no_episode, "favorites": favorites, "similar": similar, "cards": cards_row,
            "cards_all": cards_all}
