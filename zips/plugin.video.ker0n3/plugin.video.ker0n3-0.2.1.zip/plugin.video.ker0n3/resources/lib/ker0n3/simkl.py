"""Lo único de Ker0n3 que habla con Simkl (sin Palantir, bloque 1; 15-nov). Viene de flix_simkl_api del plan 3
(docs/superpowers/plans/2026-11-15-simkl-3-vincular-y-bajar.md), ahora en el addon.

El acceso se guarda en addon_data de Ker0n3 (simkl.json, permisos 600), por aparato. Nunca se escribe en el registro.
Cupo de Simkl (plan gratuito): 500 peticiones al día por usuario, también las lecturas; 1 POST por segundo."""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

NAME, LABEL = "simkl", "Simkl"
CLIENT_ID = "f1629d8b79b16a1010c3e0b1c23b6c1b00a9a4fa47fa28252ad2f33895f12d52"
BASE = "https://api.simkl.com"
APP, APP_VERSION, UA = "ker0n3-media", "addon", "Ker0n3Media-addon"
POST_GAP = 1.1                  # s entre dos POST (Simkl: 1 por segundo)
RENEW_BEFORE = 86400            # s: se renueva el acceso cuando le queda menos de un día
_last_post = [0.0]
_sleep = time.sleep


class SimklError(Exception):
    """kind: sin_red, sin_cupo, sin_vinculo u otro"""

    def __init__(self, kind, msg=""):
        Exception.__init__(self, "%s %s" % (kind, msg))
        self.kind = kind


Error = SimklError      # nombre común a los dos servicios (sync.py)


def token_path():
    import xbmcvfs
    import flix_common
    return xbmcvfs.translatePath(flix_common.K3DATA_REL + "simkl.json")


def load_token(path=None):
    try:
        with open(path or token_path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_token(tok, path=None, now=time.time):
    """guarda el acceso (600) con la hora a la que caduca; devuelve lo guardado"""
    path = path or token_path()
    d = {"access_token": tok["access_token"], "refresh_token": tok.get("refresh_token", ""),
         "expires_at": int(now()) + int(tok.get("expires_in") or 0)}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, path)
    return d


def forget(path=None):
    try:
        os.remove(path or token_path())
    except OSError:
        pass


def linked(path=None):
    return bool(load_token(path).get("access_token"))


def _url(path, params=None):
    q = {"client_id": CLIENT_ID, "app-name": APP, "app-version": APP_VERSION}
    q.update(params or {})
    return "%s%s?%s" % (BASE, path, urllib.parse.urlencode(q))


def call(method, path, body=None, token=None, params=None, opener=None):
    """JSON de la respuesta (None si vacía). Errores como SimklError con su tipo. Las escrituras (POST y DELETE)
    esperan POST_GAP entre ellas"""
    if method != "GET":
        wait = POST_GAP - (time.time() - _last_post[0])
        if wait > 0:
            _sleep(wait)
        _last_post[0] = time.time()
    headers = {"User-Agent": UA, "Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(_url(path, params), data=data, headers=headers, method=method)
    try:
        with (opener or urllib.request.urlopen)(req, timeout=20) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        kind = {401: "sin_vinculo", 403: "sin_vinculo", 429: "sin_cupo"}.get(e.code, "otro")
        try:
            err = json.loads(e.read().decode() or "{}").get("error", "")
        except (ValueError, AttributeError, OSError):
            err = ""
        raise SimklError(kind, "HTTP %s %s %s" % (e.code, path, err))
    except (urllib.error.URLError, OSError) as e:
        raise SimklError("sin_red", "%s %s" % (path, e))
    try:
        return json.loads(raw.decode() or "null")
    except ValueError:
        raise SimklError("otro", "%s: respuesta que no es JSON" % path)


def device_code(opener=None):
    return call("POST", "/oauth2/device", {"client_id": CLIENT_ID, "scope": "media:write"}, opener=opener)


def poll_token(device_code, opener=None):
    """el acceso si ya se escribió el código en simkl.com/pin; si no, "pending" o "slow_down" """
    body = {"grant_type": "urn:ietf:params:oauth:grant-type:device_code", "device_code": device_code,
            "client_id": CLIENT_ID}
    try:
        d = call("POST", "/oauth2/token", body, opener=opener)
    except SimklError as e:
        if e.kind == "otro" and "slow_down" in str(e):
            return "slow_down"
        if e.kind == "otro" and "HTTP 400" in str(e):
            return "pending"
        raise
    if isinstance(d, dict) and d.get("access_token"):
        return d
    return "pending"


def access(opener=None, path=None, now=time.time):
    """acceso válido; lo renueva si le queda menos de un día. Renovación rechazada: se olvida y SimklError sin_vinculo"""
    tok = load_token(path)
    if not tok.get("access_token"):
        raise SimklError("sin_vinculo", "sin acceso guardado")
    if tok.get("expires_at", 0) - now() >= RENEW_BEFORE:
        return tok["access_token"]
    try:
        d = call("POST", "/oauth2/token", {"grant_type": "refresh_token", "refresh_token": tok.get("refresh_token"),
                                          "client_id": CLIENT_ID}, opener=opener)
    except SimklError as e:
        if e.kind == "sin_vinculo" or (e.kind == "otro" and "HTTP 400" in str(e)):
            forget(path)
            raise SimklError("sin_vinculo", "renovación rechazada")
        raise
    if not (isinstance(d, dict) and d.get("access_token")):
        raise SimklError("otro", "renovación sin acceso")
    return save_token(d, path=path, now=now)["access_token"]


def user_name(opener=None):
    d = call("POST", "/users/settings", token=access(opener=opener), opener=opener) or {}
    return ((d.get("user") or {}).get("name") or "").strip()


def activities(opener=None):
    return call("GET", "/sync/activities", token=access(opener=opener), opener=opener) or {}


def all_items(kind, status="", date_from=None, opener=None):
    """kind: movies o shows (el anime no se pide: no se sincroniza). Con status solo esos. Vacío: {}"""
    params = {"extended": "full", "episode_watched_at": "yes"}
    if date_from:
        params["date_from"] = date_from
    path = "/sync/all-items/%s%s" % (kind, "/" + status if status else "")
    d = call("GET", path, token=access(opener=opener), params=params, opener=opener)
    return d if isinstance(d, dict) else {}


def playback(kind, opener=None):
    """kind: movies o episodes. Pausas guardadas en la cuenta (7 días en la gratuita)"""
    d = call("GET", "/sync/playback/%s" % kind, token=access(opener=opener), opener=opener)
    return d if isinstance(d, list) else []


def remove_playback(pid, opener=None):
    """quita una pausa por su id (DELETE sync/playback/<id> → 204, comprobado con la cuenta real el 15-nov). True si
    la quitó; False si Simkl da 404 (ya no estaba)"""
    try:
        call("DELETE", "/sync/playback/%d" % int(pid), token=access(opener=opener), opener=opener)
    except SimklError as e:
        if e.kind == "otro" and "HTTP 404 " in str(e):
            return False
        raise
    return True


def post(path, body, opener=None):
    return call("POST", path, body, token=access(opener=opener), opener=opener)


def scrobble(action, body, opener=None):
    """action: pause o stop (start no crea pausa: resultados del 15-nov)"""
    return post("/scrobble/%s" % action, body, opener=opener)


def history_add(body, opener=None):
    return post("/sync/history", body, opener=opener)


def add_to_list(body, opener=None):
    return post("/sync/add-to-list", body, opener=opener)
