"""La serie de Ker0n3 sin Palantir (bloque 3; 16-nov): qué capítulo toca, y qué capítulos emitidos no se dan por
disponibles. Todo con lo ya guardado (base de vistos propia, ficha de la serie y temporadas de TMDB en la caché del
catálogo): nada pide a la red al pintar.

Qué toca (state), con la regla de siempre (flix_common.current_episode: manda lo último tocado):
  · sin nada visto: «Ver» = el primer capítulo de la primera temporada (sin especiales);
  · un capítulo a medias: ese, en su minuto («Seguir viendo · T1 E4 (37 %)»);
  · si no, el siguiente al último visto: si ya se ha emitido es el que toca («Seguir viendo · T1 E4»); si aún no,
    «Al día · T1 E3» (con la fecha del que viene, si TMDB la tiene); si no hay más ni anunciados, «Ver de nuevo».
«Emitido» sale de las fechas de la temporada si están guardadas y, si no, del último capítulo emitido de la ficha
de la serie. El siguiente es el siguiente número que EXISTE en TMDB (numeraciones que siguen la cuenta de una
temporada a otra o se saltan números). Los especiales (temporada 0) no cuentan ni se enseñan.

Qué capítulos emitidos no están disponibles (unavailable): un capítulo emitido se enseña como cualquiera, sin
comprobarlo contra las fuentes al pintar. Deja de darse por disponible, unas horas, en dos casos que ya se saben sin
preguntar: al ir a reproducirlo no hubo ninguna versión (mark_unavailable, NONE_TTL), o la disponibilidad de la
serie ya guardada (avail.check) dice que del último emitido aún no hay ninguna (MISS_TTL). La ruta de la temporada no
los da y la ficha los pinta debajo, atenuados: «Aún no disponible · emitido el 12 nov»."""
import json
import time

NONE_TTL = 6 * 3600     # un capítulo que al reproducir no tuvo versión: «Aún no disponible» durante este tiempo
MISS_TTL = 12 * 3600    # el último emitido sin versión según la disponibilidad guardada de la serie
STATE = "k3_serie_"     # Window(10000) + tmdb: el estado (JSON) que deja la carpeta de la serie para la skin


def today():
    return time.strftime("%Y-%m-%d")


def _numbers(eps):
    """[(número, fecha)] de una temporada guardada, sin el «capítulo 0», por número"""
    return sorted((int(e["n"]), e.get("premiered") or "") for e in eps or [] if isinstance(e.get("n"), int) and e["n"] > 0)


def state(show, rows, season_eps=None, today=None):
    """{"next": [T, C] o None, "pct", "at" (s), "upto": [T, C] o None, "soon": [T, C, fecha] o None, "done",
    "first": [T, C]}. show: ficha de catalog.show; rows: sus filas vistas como store._shows (lo último tocado
    primero); season_eps(T): capítulos guardados de la temporada (catalog.season_cached) o None"""
    today = today or globals()["today"]()
    season_eps = season_eps or (lambda s: None)
    last = tuple(show.get("last_aired") or ()) or None
    counts = {int(s["n"]): int(s.get("episodes") or 0) for s in show.get("seasons") or [] if (s.get("n") or 0) > 0}
    memo = {}

    def nums(s):
        if s not in memo:
            try:
                memo[s] = _numbers(season_eps(s)) or None
            except Exception:  # noqa: BLE001
                memo[s] = None
        return memo[s]

    def first_of(s):
        return nums(s)[0][0] if nums(s) else 1

    def after(s, e):
        """(capítulo, fecha o None si no se sabe) del siguiente al e en la temporada s; None si no hay más"""
        if nums(s):
            return next(((n, d) for n, d in nums(s) if n > e), None)
        return (e + 1, None) if e < counts.get(s, 0) else None

    def aired(s, e, date):
        if date is not None:
            return bool(date) and date <= today
        return bool(last) and (s, e) <= (int(last[0]), int(last[1]))

    order = sorted(counts)
    out = {"next": None, "pct": 0, "at": 0, "upto": None, "soon": None, "done": False,
           "first": [order[0], first_of(order[0])] if order else [1, 1]}
    import flix_common
    row, _late = flix_common.current_episode([r for r in rows or [] if int(r[0]) > 0])
    if not row:
        return out
    s, e, pct = int(row[0]), int(row[1]), float(row[2] or 0)
    if pct > 0:
        total = float(row[4] or 0) if len(row) > 4 else 0.0
        out.update(next=[s, e], pct=int(pct), at=int(total * pct / 100.0))
        return out
    nxt = after(s, e)
    if nxt:
        if aired(s, nxt[0], nxt[1]):
            out["next"] = [s, nxt[0]]
        else:
            out.update(upto=[s, e], soon=[s, nxt[0], nxt[1] or ""])
        return out
    later = [n for n in order if n > s]
    if later:                       # catalog.show solo da temporadas ya estrenadas: su primer capítulo está emitido
        out["next"] = [later[0], first_of(later[0])]
        return out
    coming = sorted((int(x["n"]), x.get("air_date") or "") for x in show.get("upcoming") or []
                    if (x.get("n") or 0) > s)
    if coming:
        out.update(upto=[s, e], soon=[coming[0][0], 1, coming[0][1]])
    else:
        out["done"] = True
    return out


def label(se):
    return "T%d E%d" % (int(se[0]), int(se[1])) if se else ""


def of(tmdb, show=None, db_path=None, cache=None):
    """state() de una serie con lo guardado: su ficha (catalog.show si no se pasa), sus filas de la base y las
    temporadas en caché"""
    from ker0n3 import catalog, store
    tmdb = int(tmdb)
    show = show if show is not None else catalog.show(tmdb, cache=cache)
    rows = store.show_rows(tmdb, db_path)
    out = state(show, rows, season_eps=lambda s: catalog.season_cached(tmdb, s, cache=cache))
    out["tmdb"] = tmdb
    return out


def publish(tmdb, st, home=None):
    """deja el estado en Window(10000).k3_serie_<tmdb> (la skin lo lee al abrir la ficha y tras cada recarga de la
    carpeta de la serie: flix_series.k3_state). Nunca lanza"""
    try:
        if home is None:
            import xbmcgui
            home = xbmcgui.Window(10000)
        home.setProperty("%s%d" % (STATE, int(tmdb)), json.dumps(dict(st, t=time.time())))
    except Exception:  # noqa: BLE001
        pass


def _cache(cache):
    if cache is not None:
        return cache
    from ker0n3 import catalog
    return catalog.default_cache()


def mark_unavailable(tmdb, season, episode, cache=None, now=time.time):
    """al ir a reproducirlo no hubo ninguna versión: «Aún no disponible» durante NONE_TTL"""
    _cache(cache).put("ne/%d/%d/%d" % (int(tmdb), int(season), int(episode)), {"t": 1}, now=now)


def unavailable(tmdb, season, cache=None, now=time.time):
    """{capítulos} de la temporada que no se dan por disponibles ahora mismo (ver arriba). Solo lee la caché"""
    from ker0n3 import avail
    cache, out = _cache(cache), set()
    tmdb, season = int(tmdb), int(season)
    try:
        miss = cache.get("%s%d" % (avail.MISS, tmdb), MISS_TTL, now=now) or []
        if len(miss) == 2 and int(miss[0]) == season:
            out.add(int(miss[1]))
    except (TypeError, ValueError):
        pass
    prefix = "ne/%d/%d/" % (tmdb, season)
    for key in cache.keys(prefix):
        if cache.get(key, NONE_TTL, now=now) is not None:
            try:
                out.add(int(key[len(prefix):]))
            except ValueError:
                pass
    return out
