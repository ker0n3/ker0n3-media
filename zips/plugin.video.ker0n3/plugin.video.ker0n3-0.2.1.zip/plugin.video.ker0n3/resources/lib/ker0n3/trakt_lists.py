"""Listas de Trakt para la sección Trakt de la skin (sin Palantir, bloques 4 y 5; 17-nov). SOLO LECTURA: GET
/users/me/lists, /users/me/lists/<id>/items/movie,show y /sync/watchlist/<movies|shows>. El servicio deja en
trakt_listas.json si Trakt es el servicio en uso, sus listas personales y cuántos tiene en la watchlist (la skin lo
lee sin red: flix_rows.k3_trakt_lists). Cada lista es la ruta lista/trakt-<id> y la watchlist lista/trakt-watchlist-
<pelis|series> (lists.py, con la regla de lo que se enseña). Los favoritos de la skin son los «Favorites» de Trakt
(trakt_sync, base propia): su fila es favoritos/<tipo>, no esto."""
import json
import os
import re
import time

REFRESH = 6 * 3600          # las listas de la cuenta, como mucho cada tanto
KEY_RE = re.compile(r"^trakt-(\d+|watchlist-(pelis|series))$")
WATCHLIST = {"pelis": "movies", "series": "shows"}


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.trakt_lists] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def path():
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/trakt_listas.json")


def load(p=None):
    try:
        with open(p or path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(data, p=None):
    p = p or path()
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tmp = "%s.%d.tmp" % (p, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, p)


def _fetch():
    """(listas personales [{id, name, n}], {"pelis": n, "series": n} de la watchlist). Excepción = red o sin acceso"""
    from ker0n3 import trakt
    out = []
    for x in trakt.get("/users/me/lists") or []:
        ids = (x or {}).get("ids") or {}
        if str(ids.get("trakt", "")).isdigit() and str(x.get("name") or "").strip():
            out.append({"id": int(ids["trakt"]), "name": str(x["name"]).strip(), "n": int(x.get("item_count") or 0)})
    wl = {k: len(trakt.watchlist(v)) for k, v in WATCHLIST.items()}
    return out, wl


def refresh(p=None, now=time.time, active=None, fetch=None):
    """con Trakt en uso, sus listas en el fichero (cada REFRESH como mucho; sin red, se queda lo de antes); sin él,
    {"on": False} al momento y sin red. Devuelve lo escrito, o None si no tocaba o falló. Nunca lanza"""
    try:
        if active is None:
            from ker0n3 import syncsvc
            active = syncsvc.active()
        cur = load(p)
        if active != "trakt":
            if cur.get("on") is False:
                return None
            data = {"on": False, "t": now()}
            _save(data, p)
            return data
        if cur.get("on") and now() - float(cur.get("t") or 0) < REFRESH:
            return None
        lists, wl = (fetch or _fetch)()
        data = {"on": True, "t": now(), "lists": lists, "watchlist": wl}
        _save(data, p)
        log("%d listas de la cuenta; watchlist %s" % (len(lists), wl))
        return data
    except Exception as e:  # noqa: BLE001
        log("listas sin refrescar: %s" % type(e).__name__)
        return None


def _entries(data):
    out = []
    for it in data or []:
        if not isinstance(it, dict):
            continue
        typ = it.get("type") or ("movie" if "movie" in it else "show" if "show" in it else "")
        kind = {"movie": "movie", "show": "tv"}.get(typ)
        tmdb = str(((it.get(typ) or {}).get("ids") or {}).get("tmdb") or "") if kind else ""
        if kind and tmdb.isdigit() and not any(e["tmdb"] == int(tmdb) and e["kind"] == kind for e in out):
            out.append({"tmdb": int(tmdb), "kind": kind})
    return out


def items(key, get_list=None, watchlist=None):
    """entradas de la lista trakt-<id> o trakt-watchlist-<pelis|series> ({tmdb, kind}, en el orden de la cuenta;
    las fichas las pone la ruta). Excepción = red o sin acceso (lists.entries se queda con lo guardado)"""
    m = KEY_RE.match(key or "")
    if not m:
        return []
    from ker0n3 import trakt
    if m.group(2):
        return _entries((watchlist or trakt.watchlist)(WATCHLIST[m.group(2)]))
    get_list = get_list or trakt.get_list
    return _entries(get_list("/users/me/lists/%s/items/movie,show" % m.group(1)))
