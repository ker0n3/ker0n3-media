"""Piezas comunes a los scripts del skin (sin xbmc: se prueban fuera de Kodi). Antes había 5 copias de COLOR_RE,
3 de decode_route y 2 de encode_route (auditoría PY-12).
Lo carga el clic en una carátula (flix_play): cada RunScript es un intérprete nuevo y en la Shield cada import pesa
(tempfile 47 ms, base64 10 ms; test_click_imports.py) → aquí solo lo barato y lo demás dentro de su función."""
import binascii
import math
import os
import re
import threading

PLUGIN_ROOT = "plugin://plugin.video.palantir3/"
# la única frase para pedir que se reintente (revisión 29-oct TV-12; antes «OK para reintentar», «Inténtalo en unos
# segundos», «vuelve a intentarlo» y esta). En pantalla, con OK que reintenta: «Pulsa OK para probar otra vez»
RETRY_LATER = "Prueba otra vez en un momento"
NO_ANSWER_RETRY = "Palantir no responde ahora mismo. %s" % RETRY_LATER     # avisos sin punto final (X5a)
K3_NO_ANSWER_RETRY = "Ker0n3 no responde ahora mismo. %s" % RETRY_LATER     # lo mismo con carpetas del addon Ker0n3
# datos de Palantir: la ruta en un solo sitio (antes, en 6; revisión 29-oct DAT-21). Cada módulo la traduce con
# xbmcvfs.translatePath y guarda la suya en WATCHED_DB (los tests la cambian por una base de prueba)
P3DATA_REL = "special://profile/addon_data/plugin.video.palantir3/"
WATCHED_DB_REL = P3DATA_REL + "watched.db"
# base de vistos de Ker0n3 (sin Palantir, bloque 1; 15-nov): con fuentes propias la skin lee esta (watched_rel)
K3DATA_REL = "special://profile/addon_data/plugin.video.ker0n3/"
K3_WATCHED_DB_REL = K3DATA_REL + "watched.db"

# títulos del addon Ker0n3 en las filas (sin Palantir, bloque 2; 16-nov): k3_ref saca de su ruta lo que de una ruta de
# Palantir se saca decodificando su JSON (tipo y tmdb)
K3_ROOT = "plugin://plugin.video.ker0n3/"
_K3_TITLE = re.compile(r"^(?:(?:play|info)/pelicula/(\d+)|serie/(\d+)(?:/\d+)?|play/capitulo/(\d+)/\d+/\d+)/?$")


def k3_ref(path):
    """('movie' | 'tv', tmdb) de un título de Ker0n3 (película, serie, temporada o capítulo); None si la ruta no lo
    es (otra cosa del addon —listas, búsquedas, seguir— o de otro sitio)"""
    path = str(path or "")
    if not path.startswith(K3_ROOT):
        return None
    m = _K3_TITLE.match(re.split(r"[?&]", path[len(K3_ROOT):], maxsplit=1)[0])
    if not m:
        return None
    return ("movie", int(m.group(1))) if m.group(1) else ("tv", int(m.group(2) or m.group(3)))


def k3_similar(kind, tmdb):
    """ruta del addon con los parecidos a un título («Ver similares» con fuentes propias): kind movie | tv / show"""
    return "%ssimilares/%s/%d" % (K3_ROOT, "pelicula" if kind == "movie" else "serie", int(tmdb))


def fuentes_on():
    """¿fuentes propias (Skin.HasSetting(flix_fuentes))? Sin Kodi (herramientas): no. En las pruebas está apagado
    (conftest) salvo que el test lo encienda. Llamarla siempre como flix_common.fuentes_on()"""
    try:
        import xbmc
        return bool(xbmc.getCondVisibility("Skin.HasSetting(flix_fuentes)"))
    except Exception:  # noqa: BLE001
        return False


def watched_rel():
    """watched.db que lee la skin (la única función para la ruta): con fuentes propias la base de Ker0n3; si no, la de
    Palantir. flix_p3sync y flix_playload siguen con la de Palantir: escriben lo que Palantir apunta"""
    return K3_WATCHED_DB_REL if fuentes_on() else WATCHED_DB_REL


def watched_path():
    import xbmcvfs
    return xbmcvfs.translatePath(watched_rel())


# Clave pública del scraper oficial de Kodi (metadata.themoviedb.org.python): búsqueda (títulos alternativos) y
# siguiente capítulo (qué hay ya emitido)
TMDB_KEY = "f090bb54758cabf231fb605d3e3e0468"
# Window(home): fondo de la ficha que tapa el Inicio al ir y volver de «Títulos de X» (flix_info; FlixTrailerCover). Aparte
# del del tráiler (flix_trailer_cover): flix_play quita ese al cerrarse la ficha, justo cuando este tiene que seguir
INFO_COVER = "flix_info_cover"
# etiquetas de formato de Kodi que Palantir mete en títulos y menús
COLOR_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)[^\]]*\]")
# códigos de «Atrás» que cierran una ventana Python: 9 ParentDir, 10 PreviousMenu, 92 NavBack, 216/247/257/275
# (atrás del mando según el aparato), 61467 y 61448 (retroceso crudo). Una sola lista para todas las ventanas
# (revisión 29-oct TV-28: la ficha de película solo cerraba con 10 y 92, y Reanudar, los avisos, el menú KER0N3 y
# Telegram no tenían onAction)
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)


def clean(label):
    return COLOR_RE.sub("", label or "").strip()


def fresh(stamp, now, secs):
    """la marca de hora stamp (texto de time.time()) tiene menos de secs segundos; vacía, rota o del futuro: no
    (margen de 1 s: "%.3f" redondea hacia arriba y la marca recién puesta puede ir unas décimas de ms por delante)"""
    try:
        return -1 < now - float(stamp) < secs
    except (TypeError, ValueError):
        return False


def decode_route(url):
    """JSON (como texto) de una ruta de Palantir: base64 invertido y rotado ceil(len/4). Algunas llegan con el «+» del
    base64 como «%2B» (Ataque a los Titanes T3, Shield 8-nov: su menú no salía): sin deshacerlo la rotación se
    descuadra y sale basura. «%» no es del base64: a las demás no les toca. A mano y no con urllib.parse: este módulo
    lo cargan los arranques medidos (test_log_medidas) y en base64 solo pueden venir así «+», «/» y «=»"""
    blob = url.split("?", 1)[-1].split("&", 1)[0]
    if "%" in blob:
        for code, ch in (("%2B", "+"), ("%2F", "/"), ("%3D", "=")):
            blob = blob.replace(code, ch).replace(code.lower(), ch)
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    return binascii.a2b_base64(b64).decode("utf-8", "replace")


def encode_route(text):
    rb = binascii.b2a_base64(text.encode(), newline=False).decode().rstrip("=")[::-1]
    n = len(rb)
    k = math.ceil(n / 4)
    return PLUGIN_ROOT + "?" + rb[n - k:] + rb[:n - k]


# ---------- variables del skin (<variable name=…> de los XML) ----------
# Una sola copia (revisión 29-oct DAT-19; antes flix_rows.skin_var, flix_search.skin_var y flix_inicio.skin_vars) y
# cada XML se lee y se procesa una vez por proceso: el buscador pedía 5 seguidas y cada una abría y recorría
# Includes_Palantir3.xml entero. Se vuelve a leer si cambia su huella (la skin se actualiza sola con Kodi abierto).
_SKIN_VARS = {}     # fichero -> ((inodo, mtime en ns, tamaño), {variable: valor})


def unescape(v):
    """html.unescape del valor. En las 375 variables solo hay &amp;: entonces basta un replace, que da lo mismo, y no
    se importa html (~7 ms propios y html.entities ~12 en proot, en el camino de C1; revisión 29-oct ARR-19)"""
    if "&" not in v.replace("&amp;", ""):
        return v.replace("&amp;", "&")
    import html
    return html.unescape(v)


def vars_of(texts):
    """{nombre: último <value>} de las variables de esos textos (el por defecto, como en tools/gen_touch_home.py; si
    un nombre se repite, gana el último)"""
    out = {}
    for t in texts:
        for name, body in re.findall(r'<variable name="([^"]+)">(.*?)</variable>', t, re.S):
            vals = re.findall(r"<value[^>]*>(.*?)</value>", body, re.S)
            if vals:
                out[name] = unescape(vals[-1].strip())
    return out


def _xml_vars(name):
    """vars_of() de special://skin/xml/<name>, guardado mientras su huella no cambie; {} si no se puede leer. Sin
    huella (stat falla) no se guarda: se lee en cada llamada, como antes. El dict es compartido: no se toca"""
    import xbmc
    import xbmcvfs
    path = "special://skin/xml/%s" % name
    try:
        st = os.stat(xbmcvfs.translatePath(path))
        sig = (st.st_ino, st.st_mtime_ns, st.st_size)       # ANTES de leer: si cambia mientras, se relee luego
    except Exception:  # noqa: BLE001
        sig = None
    hit = _SKIN_VARS.get(name)
    if sig is not None and hit and hit[0] == sig:
        return hit[1]
    try:
        with xbmcvfs.File(path) as fh:
            text = fh.read()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_common] no leo %s: %s" % (name, e), xbmc.LOGWARNING)
        _SKIN_VARS.pop(name, None)
        return {}
    out = vars_of([text])
    if sig is not None:
        _SKIN_VARS[name] = (sig, out)
    return out


def skin_vars(names):
    """{variable: valor por defecto} de esos XML de la skin, en orden (si se repite, gana el último). Las filas del
    Inicio TV: Includes_Flix.xml, Includes_Palantir3.xml y Variables.xml (375)"""
    out = {}
    for name in names:
        out.update(_xml_vars(name))
    return out


def skin_var(name):
    """valor por defecto de una variable de Includes_Palantir3.xml (rutas fijas de las secciones); "" si no está"""
    return _xml_vars("Includes_Palantir3.xml").get(name, "")


def atomic_write(path, text):
    """escribe en un temporal único del mismo directorio y lo cambia de golpe por el fichero"""
    import tempfile
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + ".", suffix=".tmp", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# Imágenes que hacen los scripts (QR del buscador y del teclado, QR de Telegram): en una subcarpeta de special://temp.
# Al parar un vídeo Kodi lista special://temp (DeleteVideoDatabaseDirectoryCache busca sus .fi) y guarda la lista en su
# caché de carpetas; un fichero hecho después desde Python no está en ella y CFile::Open lo da por inexistente sin
# avisar: el QR salía en blanco hasta el siguiente listado (APA-02, 30-oct). Esta subcarpeta no la lista nadie
IMG_DIR = "special://temp/flix_img/"


def temp_image(name):
    """ruta real de una imagen hecha por un script, en IMG_DIR (la carpeta se crea si falta)"""
    import xbmcvfs
    path = xbmcvfs.translatePath(IMG_DIR + name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


# ---------- JSON-RPC de Kodi ----------
# Un solo envoltorio (revisión 29-oct DAT-20; antes había siete, cinco de Files.GetDirectory). La petición es el mismo
# texto que escribían todos a mano. Cada uno conserva su manejo de errores: una respuesta que no es JSON lanza
# ValueError donde ya lanzaba (rpc, list_dir), quien devolvía [] lo captura y p3sync ni la lee (rpc_send). Los
# reintentos, solo en el buscador (flix_search.list_dir).
def rpc_send(method, params=None):
    """manda la petición y devuelve la respuesta tal cual (texto)"""
    import json
    import xbmc
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    return xbmc.executeJSONRPC(json.dumps(req))


def rpc(method, params=None):
    """respuesta como dict; ValueError si no es JSON"""
    import json
    return json.loads(rpc_send(method, params))


def play_kodi(path):
    """reproducir algo de fuera de Palantir (biblioteca de Kodi, carpetas, otros complementos) como lo hace Kodi: desde
    donde se dejó si Kodi lo tiene apuntado (biblioteca). Sin la pantalla de carga ni el selector de Palantir"""
    rpc_send("Player.Open", {"item": {"file": path}, "options": {"resume": True}})


# carpetas del NAS, USB… (fuentes de Kodi) en otros orígenes: fotos y vídeos juntos, como una carpeta de móvil (Carlos,
# 13-nov: «fotos boda Ana»). Kodi, con media="video", se calla las fotos; con "files" lo da todo y aquí se filtra
PICTURE_EXT = (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".heic", ".heif", ".tif", ".tiff")
VIDEO_EXT = (".mkv", ".mp4", ".m4v", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".mts", ".mpg", ".mpeg", ".webm", ".3gp",
             ".flv", ".iso", ".vob", ".divx", ".ogv")
FS_SCHEMES = ("smb://", "nfs://", "ftp://", "ftps://", "sftp://", "dav://", "davs://", "upnp://", "/")


def is_fs(path):
    """¿carpeta o archivo de una fuente de Kodi (NAS, USB, disco)? (no biblioteca, complementos ni favoritos)"""
    p = str(path or "")
    return p.startswith(FS_SCHEMES) or bool(re.match(r"[A-Za-z]:[\\/]", p))


def file_kind(f):
    """"dir", "picture", "video" o "" (lo demás: .nfo, .srt, .txt…) de un elemento de Files.GetDirectory"""
    if f.get("filetype") == "directory":
        return "dir"
    ext = os.path.splitext(str(f.get("file") or ""))[1].lower()
    return "picture" if ext in PICTURE_EXT else "video" if ext in VIDEO_EXT else ""


def list_fs(path, props=None):
    """carpeta de una fuente: subcarpetas, fotos y vídeos; fuera lo oculto del NAS (@eaDir, #recycle, .algo)"""
    return [f for f in list_dir(path, props, media="files")
            if not str(f.get("label") or "").startswith((".", "@", "#")) and file_kind(f)]


def parent_of(path):
    """carpeta que contiene path ("smb://nas/Fotos/a.jpg" -> "smb://nas/Fotos/")"""
    return re.sub(r"[^/\\]+[/\\]?$", "", str(path or ""))


def show_picture(path):
    """una foto de otros orígenes: el pase de Kodi de su carpeta, en pausa y empezando por ella (← → para pasar)"""
    import xbmc
    xbmc.executebuiltin('SlideShow("%s",pause,beginslide="%s")' % (parent_of(path), path))


def list_dir(path, props=None, media="video"):
    """«files» de Files.GetDirectory ([] si no hay result: error de Palantir o carpeta vacía); ValueError si la
    respuesta no es JSON. Sin props, la petición va sin «properties». Si vino un error, dir_failed() lo dice"""
    params = {"directory": path, "media": media}
    if props is not None:
        params["properties"] = props
    r = rpc("Files.GetDirectory", params)
    _dir_state().error = r.get("error")
    return (r.get("result") or {}).get("files") or []


_DIR_STATE = []     # threading.local() creado al primer uso (import perezoso: el clic en una carátula no lo carga)


def _dir_state():
    if not _DIR_STATE:
        import threading
        _DIR_STATE.append(threading.local())
    return _DIR_STATE[0]


def dir_failed(reset=False):
    """¿la última list_dir de este hilo trajo un error (Palantir no contestó) en vez de una carpeta, aunque esté vacía?
    Separa «Palantir no responde» de «Sin contenido» (revisión 29-oct TV-12). reset=True: lo olvida (antes de pedir)"""
    st = _dir_state()
    failed = bool(getattr(st, "error", None))
    if reset:
        st.error = None
    return failed


# ---------- servidor HTTP en casa (QR del móvil, pasar ajustes) ----------
def http_server(addr, handler, threads=False):
    """HTTPServer (o ThreadingHTTPServer) sin el socket.getfqdn() de su server_bind: una consulta de DNS inversa
    que con un DNS lento tardaba hasta 35 s (Mac, 3-nov) antes de enseñar el QR. El nombre no se usa para nada"""
    import socketserver
    from http.server import HTTPServer, ThreadingHTTPServer

    class Server(ThreadingHTTPServer if threads else HTTPServer):
        allow_reuse_address = True

        def server_bind(self):
            socketserver.TCPServer.server_bind(self)
            self.server_name, self.server_port = self.server_address[:2]
    return Server(addr, handler)


# ---------- cierre de Kodi ----------
# A los scripts lanzados con RunScript SIN addon (todos los de la skin) Kodi no les avisa del cierre por
# Monitor.abortRequested() / waitForAbort(): CPythonInvoker::stop solo llama a AbortNotification() si el script tiene
# addon (Kodi 20-22). Esperaba 5 s a cada uno y lo mataba («script didn't stop in 5 seconds - let's kill it»: flix_ratings
# y flix_progress, revisión 29-oct APA-03). Lo que sí llega a todos los Monitor es el anuncio System.OnQuit
# (onNotification), al empezar a cerrarse Kodi y antes de parar los scripts. Llega al hilo que creó el Monitor
# mientras espera en waitForAbort: lo crea el hilo principal del script, que espera así entre vuelta y vuelta. Con
# Kodi abierto no cambia nada; abortRequested se sigue mirando (por si algún día van en un addon).
_QUIT = []      # [threading.Event] de este intérprete: puesto al anunciar Kodi su cierre (quit_monitor)


def current_episode(rows):
    """El capítulo «que toca» de UNA serie. rows: sus filas de episodes_watched como (temporada, capítulo, progreso,
    lastPlayed, …), ordenadas por lo último tocado (lastPlayed DESC, temporada DESC, capítulo DESC). Devuelve
    (fila, rezagado) o (None, False).

    La regla de siempre: manda la última fila tocada (a medias si lleva progreso; si no, toca el siguiente). Excepción
    (Carlos, 13-nov: «La isla de las tentaciones» T11 E30 a medias en el móvil y sin tarjeta en la Shield): cuando
    Palantir ve que una serie en seguimiento tiene un capítulo más nuevo en su catálogo, le cambia la fecha al último
    capítulo tocado por la hora de ese momento, para subirla en «Series en seguimiento» (Watched.setShowUpdated).
    Así el visto (E29) queda «más reciente» que la pausa del siguiente (E30). Si la última fila es un
    capítulo visto y el INMEDIATAMENTE siguiente está a medias, toca ese. `rezagado` lo marca: Palantir no lo sabe y
    lo empezaría de cero, así que quien lo reproduzca tiene que ponerlo él en su minuto. Solo el siguiente inmediato:
    volver a ver un capítulo antiguo no cambia nada"""
    rows = list(rows or [])
    if not rows:
        return None, False
    first = rows[0]
    try:
        if first[2] and float(first[2]) > 0:
            return first, False
        s, e = int(first[0]), int(first[1])
        for r in rows[1:]:
            if r[2] and float(r[2]) > 0 and (int(r[0]), int(r[1])) in ((s, e + 1), (s + 1, 1)):
                return r, True
    except (TypeError, ValueError, IndexError):
        pass
    return first, False


MONTHS = ("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")


def date_es(d, today):
    """«14 nov» (este año) o «14 nov 2027» (otro); '' si la fecha no es AAAA-MM-DD. La fecha de la skin: capítulos
    por llegar («Sale el 14 nov», flix_series) y, con Ker0n3, la de emisión de cada capítulo (la de Kodi salía con el
    formato de la región del aparato: 10/29/2026)"""
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", d or "")
    if not m or not 1 <= int(m.group(2)) <= 12:
        return ""
    y, mo, da = m.group(1), MONTHS[int(m.group(2)) - 1], int(m.group(3))
    return "%d %s" % (da, mo) if y == (today or "")[:4] else "%d %s %s" % (da, mo, y)


FAV_PROPS = {"movie": "flix_fav_movie", "show": "flix_fav_show"}


def favorite_prop(kind, tmdb, on=None):
    """corazón de las fichas (Carlos, 13-nov): Window(home).Property(flix_fav_movie / flix_fav_show) = tmdb del título
    si está en los favoritos de Palantir (tabla favorites de watched.db); vacío si no. on=None: se mira en la base (al
    abrir la ficha); True/False: lo que acaba de confirmar flix_menu.after_favorite. Nunca falla hacia fuera"""
    prop = FAV_PROPS.get(kind)
    if not prop or not str(tmdb or "").isdigit():
        return
    try:
        import xbmcgui
        if on is None:
            rows = watched_query(watched_path(), "SELECT 1 FROM favorites WHERE tmdb_id=? AND content=?",
                                 (str(tmdb), "movies" if kind == "movie" else "shows"), timeout=1)
            on = bool(rows)
        home = xbmcgui.Window(10000)
        if on:
            home.setProperty(prop, str(tmdb))
        else:
            home.clearProperty(prop)
    except Exception:  # noqa: BLE001
        pass


def quit_monitor():
    """xbmc.Monitor que se entera de que Kodi se cierra (System.OnQuit): quitting() pasa a True"""
    import threading
    import xbmc
    if not _QUIT:
        _QUIT.append(threading.Event())
    event = _QUIT[0]

    class QuitMonitor(xbmc.Monitor):
        def onNotification(self, sender, method, data):
            if method == "System.OnQuit":
                event.set()
    return QuitMonitor()


def quitting(monitor=None):
    """¿Kodi se está cerrando? (System.OnQuit visto por el quit_monitor de este intérprete o, con monitor,
    abortRequested). Vale desde cualquier hilo"""
    if _QUIT and _QUIT[0].is_set():
        return True
    return monitor is not None and bool(monitor.abortRequested())


def wait_quit(monitor, secs, step=0.25):
    """como monitor.waitForAbort(secs), en trozos de step s: True en cuanto Kodi se cierra (abort o System.OnQuit),
    False si pasó el tiempo. Para el hilo que creó el monitor (el que recibe el anuncio)"""
    import time
    end = time.time() + secs
    while True:
        if quitting():
            return True
        left = end - time.time()
        if left <= 0:
            return False
        if monitor.waitForAbort(min(step, left)):
            return True


def quit_sleep(secs):
    """time.sleep(secs) para los hilos secundarios: vuelve al momento (True) si Kodi se cierra"""
    if _QUIT:
        return _QUIT[0].wait(secs)
    import time
    time.sleep(secs)
    return False


# Avisos de arranque a pantalla completa (grupo de Telegram; antes también el de novedades de la versión, quitado el
# 14-nov a petición de Carlos): nunca dos a la vez. Cada uno
# coge este cerrojo de Window(home) antes de enseñarse y lo suelta al cerrarse; el que lo encuentra cogido espera
# (con el mismo tope que para el Inicio libre). Valor: quién lo tiene
POPUP = "flix_popup"


def popup_take(home, owner):
    """coge el cerrojo de los avisos de arranque para owner; False si lo tiene otro"""
    cur = home.getProperty(POPUP)
    if cur and cur != owner:
        return False
    home.setProperty(POPUP, owner)
    return home.getProperty(POPUP) == owner


def popup_free(home, owner):
    """suelta el cerrojo, solo si lo tiene owner"""
    if home.getProperty(POPUP) == owner:
        home.clearProperty(POPUP)


# flix_trailer (flix_trailer.py: «1» mientras hay un tráiler; la quita done() 2 s después o flix_play.trailer_over): si se
# queda colgada, el Inicio táctil salta sync_progress y la TV flix_progress toda la sesión (revisión 7-nov TAC-07)
HIDE_FLAGS = ("flix_resolving", "flix_searching", "flix_trailer")
HIDE_MAX = 120      # s


def expire_hide_flags(seen, now=None):
    """flix_resolving / flix_searching ocultan los avisos de Palantir (DialogConfirm, notificaciones...). Si se quedan
    puestas porque quien las quitaba murió o llegó tarde (selector que se cierra después, búsqueda cerrada con
    Palantir aún respondiendo), cualquier aviso sale invisible pero modal y el mando parece muerto (auditoría 22-oct
    A-08 / A-11, NAV-04). Las quitan los bucles del Inicio si llevan más de HIDE_MAX s y no hay nada en marcha.
    `seen` = {marca: desde cuándo está puesta} del que llama"""
    import time
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    now = time.time() if now is None else now
    for k in HIDE_FLAGS:
        if not home.getProperty(k):      # puesta = «true» (resolving, searching) o «1» (trailer)
            seen.pop(k, None)
            continue
        if now - seen.setdefault(k, now) > HIDE_MAX and not xbmc.getCondVisibility(
                "Player.HasMedia | Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)"):
            home.clearProperty(k)
            seen.pop(k, None)
            xbmc.log("[flix_common] %s puesta desde hace %d s sin nada en marcha: la quito" % (k, HIDE_MAX), xbmc.LOGINFO)


BUSY_MAX = 180      # s: la sincronización de arranque tarda ~20-60 s (como mucho WATCH = 120 s)


def p3sync_busy():
    """¿flix_p3sync está rehaciendo las pausas? La marca lleva la hora: si Kodi corta el script a mitad (al cerrarse,
    al recargar la skin) no se queda puesta toda la sesión"""
    import time
    import xbmcgui
    try:
        return 0 <= time.time() - float(xbmcgui.Window(10000).getProperty("flix_p3sync_busy") or 0) < BUSY_MAX
    except ValueError:
        return False


def watched_db(db_path):
    """watched.db que hay que leer: mientras flix_p3sync rehace las pausas al arrancar (flix_p3sync_busy) las pelis y
    capítulos a medias no están en watched.db (~20-60 s; hasta 120 s sin conexión) y la ficha ofrecía «Ver» desde el
    principio, con riesgo de pisar el punto bueno en Trakt (auditoría 22-oct B-01): se lee la foto de antes"""
    bak = db_path + ".flixbak"
    if p3sync_busy() and os.path.exists(bak):
        return bak
    return db_path


def later(secs, fn, *args):
    """threading.Timer daemon: uno normal retenía el intérprete hasta saltar (6 s más tras Atrás en la ficha, y al cerrar
    Kodi; revisión 7-nov PY-21). Lo usan flix_info (cubiertas), flix_play y flix_series_sheet; aquí para que la ficha no
    importe flix_info solo por esto (lote 11d)"""
    t = threading.Timer(secs, fn, args)
    t.daemon = True
    t.start()
    return t


def watched_connect(db_path, snapshot=True, timeout=5):
    """conexión de solo lectura a watched.db (mode=ro: en escritura SQLite CREA una base vacía si aún no existe y la
    sincronización de arranque creía que Palantir ya tenía datos, auditoría 22-oct B-03). Con snapshot, la foto
    .flixbak mientras p3sync rehace las pausas (watched_db). timeout = el de cada sitio. Un solo acceso para todos
    (revisión 29-oct DAT-21); sqlite3 se importa aquí: el clic en una carátula no lo carga si no lo usa"""
    import sqlite3
    path = watched_db(db_path) if snapshot else db_path
    return sqlite3.connect("file:%s?mode=ro" % path, uri=True, timeout=timeout)


def watched_query(db_path, sql, args=(), snapshot=True, timeout=5):
    """filas de una consulta a watched.db (watched_connect); None si la base no existe. Los errores de SQLite se
    propagan: cada uno los trata como antes"""
    path = watched_db(db_path) if snapshot else db_path
    if not os.path.exists(path):
        return None
    db = watched_connect(path, snapshot=False, timeout=timeout)
    try:
        return db.execute(sql, args).fetchall()
    finally:
        db.close()


def watched_movies(db_path):
    """watched.db de Palantir: {tmdb(str): (playcount, progress %, runtime s, lastPlayed)}; None si no existe.
    Aquí y no en flix_progress para que el clic en una carátula no cargue ese módulo (pickle, json, flix_rows…)."""
    rows = watched_query(db_path, "SELECT tmdb_id, playcount, progress, runtime, lastPlayed FROM movies_watched")
    return None if rows is None else {str(r[0]): (r[1], r[2], r[3], r[4]) for r in rows}


def watched_movie(db_path, tmdb):
    """UNA película de watched.db: (playcount, progress %, runtime s, lastPlayed); () si Palantir tiene películas pero
    no esa; None si la base no existe o no tiene ninguna (vale lo que diga la carátula). Para el clic en una carátula
    (flix_play.sheet): antes cargaba movies_watched entera para mirar una fila (revisión 7-nov PY-12). tmdb_id es
    INTEGER en Palantir: el texto de la ruta se compara bien (afinidad), como en flix_menu"""
    path = watched_db(db_path)
    if not os.path.exists(path):
        return None
    db = watched_connect(path, snapshot=False)
    try:
        row = db.execute("SELECT playcount, progress, runtime, lastPlayed FROM movies_watched WHERE tmdb_id=?",
                         (str(tmdb),)).fetchone()
        if row:
            return tuple(row)
        return () if db.execute("SELECT 1 FROM movies_watched LIMIT 1").fetchone() else None
    finally:
        db.close()


# Series: Palantir no da su estado en las listas (Top 10 de series sin ✓ ni ▶, Carlos 20-oct) pero SÍ pasa al
# póster el playCount de la caché. Vista = playCount 1 (✓); a medias = SHOW_STARTED (▶ en Includes_Flix.xml y
# flix_home.py; el ✓ excluye ese valor). Kodi no tiene otro campo de series que Palantir respete (percentPlayed no).
SHOW_STARTED = 99


def show_rule(total, complete, hidden, seen, partial):
    """playCount que toca a una serie (1 vista, SHOW_STARTED a medias, 0 nada) con su fila de shows_watched
    (num_total_episodios, completa, ocultar) y sus capítulos vistos (playcount > 0) y empezados (progress > 0).
    La única copia de la regla del ▶: la usan flix_progress.truth_shows (todas) y show_state (una)"""
    if complete or (total and seen >= total):
        return 1
    if not hidden and (seen or partial):
        return SHOW_STARTED
    return 0


def show_state(db_path, tmdb):
    """playCount que toca a UNA serie según watched.db (show_rule); None si no existe. Para el clic en una serie
    (flix_series.started): antes importaba flix_progress (pickle, flix_rows… 45-128 ms en proot) y agregaba TODAS
    las series para mirar una (revisión 29-oct DAT-06). Sin fila en shows_watched: 0, como truth_shows"""
    db_path = watched_db(db_path)
    if not os.path.exists(db_path):
        return None
    db = watched_connect(db_path, snapshot=False)
    try:
        row = db.execute("SELECT num_total_episodios, completa, ocultar FROM shows_watched WHERE tmdb_id=?",
                         (tmdb,)).fetchone()
        if not row:
            return 0
        seen, partial = db.execute("SELECT SUM(playcount > 0), SUM(progress > 0) FROM episodes_watched "
                                   "WHERE tmdb_id=?", (tmdb,)).fetchone()
        return show_rule(row[0], row[1], row[2], seen or 0, partial or 0)
    finally:
        db.close()


def ctx_path(base, sig, stored_sig, current, now_ms):
    """ruta de la lista oculta 7990 del Inicio táctil -> (ruta nueva, firma guardada).
    Esa lista vive siempre en la ventana: con la MISMA ruta Kodi no la recarga y Palantir decide su menú con la copia
    de antes de marcar («Tenzing», Top 10 películas, 26-oct: «no visto» y luego «visto» tres veces y el submenú seguía
    ofreciendo solo «no visto»). Si la firma (ruta + estado visto/caché) cambió desde la última carga se añade
    &reload=<ms>, que las rutas de Palantir aceptan; si no cambió se deja la actual y el menú sigue siendo instantáneo"""
    base = re.sub(r"&reload=\d+$", "", base)
    key = "%s|%s" % (base, sig)
    if current and key == stored_sig:
        return current, stored_sig
    return "%s&reload=%d" % (base, now_ms), key


# marcas que Palantir cambia al rehacer una lista (CACHE.actualizarWidgetsByIds: Window(home).Property(P3Reload…), en
# las rutas como &reload=$INFO[…]). Solo las de listas que cambian con lo de Trakt (otro aparato): al sincronizar,
# Palantir marca TODAS sus listas de películas o series y pedirlas todas otra vez en cada arranque sería el doble de
# trabajo; las ✓ y barras de las demás ya las corrige flix_progress. Con nuestro skin Palantir NO las marca al parar
# un vídeo (solo con el suyo, ISESTUARYPALANTIR): eso lo cubre flix_progress.reload_resume_row
P3RELOAD = re.compile(r"Window\(home\)\.Property\((P3Reload\w+)\)", re.I)
P3PERSONAL = ("P3ReloadPeliculasNoFinalizadas", "P3ReloadSeriesSeguimiento", "P3ReloadPelisFavoritas",
              "P3ReloadSeriesFavoritas", "P3ReloadPelisWatchlist", "P3ReloadSeriesWatchlist")


def p3_marks(path):
    """marcas personales de Palantir (P3PERSONAL) que lleva una ruta de fila, ya con sus $VAR resueltas"""
    return tuple(sorted(m for m in set(P3RELOAD.findall(path or "")) if m in P3PERSONAL))


# ---------- intro de arranque (Custom_1113_FlixIntro.xml) ----------
BOOT = "flix_boot"      # Startup.xml la pone; el diálogo de la intro la quita al cerrarse (y first_run, por si acaso)
INTRO_MAX = 12.0        # s: la intro dura ~4


def wait_intro(limit=INTRO_MAX, home=None, sleep=None):
    """espera a que acabe la intro del arranque (capa 1113 encima de Home, a la vista mientras flix_boot está puesta):
    el Inicio de Python (TV flix_inicio, táctil flix_home) se abre después, como cuando la intro era la ventana
    Startup; mientras, las teclas las recibe Home, que solo sabe saltarla. Devuelve los segundos esperados; nunca más
    de limit"""
    import time
    import xbmc
    import xbmcgui
    home = home or xbmcgui.Window(10000)
    sleep = sleep or xbmc.sleep
    t0 = time.time()
    while home.getProperty(BOOT) and time.time() - t0 < limit:
        sleep(50)
    return time.time() - t0
