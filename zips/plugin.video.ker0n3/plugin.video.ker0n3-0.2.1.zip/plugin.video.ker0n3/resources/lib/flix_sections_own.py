"""Secciones sin Palantir (bloques 4 y 5; diseño docs/superpowers/specs/2026-11-17-menu-secciones-sin-palantir-design.md).
Lógica pura (sin xbmc), compartida con el addon (tools/build_addon.py, SHARED): el menú propio de cada sección con
LAS MISMAS ETIQUETAS que daba Palantir (lo que el usuario tocó en «Editar filas» va por etiqueta), lo que no tiene
equivalente (LOST: la migración única lo borra de la configuración, Carlos 17-nov), las secciones que se pueden añadir
y las tarjetas de las filas de sagas, géneros y años (las monta la ruta tarjetas/<grupo> del addon, que quita las
que se sabe que no tienen nada que ver: regla de lo que se enseña). Sin «Especiales» ni «Especial…» (Carlos, 17-nov:
fuera). flix_rows.own_menu usa esto con fuentes propias."""
import datetime
import json
import os
import re

K3 = "plugin://plugin.video.ker0n3/"
LIST = K3 + "lista/"
CARDS = K3 + "tarjetas/"    # fila de tarjetas: ruta tarjetas/<grupo>[/todo] del addon
TRAKT = "p3PathTrakt"
CARD_MAX = 40               # tarjetas por fila (las de una fila de sección: flix_section.ROW_LIMIT); el resto, «Más…»
IMG = "https://image.tmdb.org/t/p/"
SAGA_CATS = ("pelis", "dibujos", "anime")


def _l(key):
    return LIST + key


def _cats(cat, sagas=True):
    """filas de Dibujos / Anime / Documentales (Palantir: películas arriba, series abajo)"""
    rows = [("Novedades", _l("%s-pelis" % cat)), ("Últimas añadidas", _l("%s-pelis-ultimas" % cat))]
    if sagas:
        rows.append(("Sagas", CARDS + "sagas-" + cat))
    return rows + [("Últimas actualizaciones", _l("%s-series-actualizadas" % cat)),
                   ("Nuevas series", _l("%s-series-nuevas" % cat))]


MENUS = {
    "p3Peliculas": [("Novedades", _l("novedades-pelis")), ("Últimas añadidas", _l("ultimas-pelis")),
                    ("Recomendadas", _l("recomendadas-pelis")), ("Más vistas", _l("populares-pelis")),
                    ("Más vistas este mes", _l("masvistas-pelis-mes")), ("Sagas", CARDS + "sagas-pelis"),
                    ("Por géneros", CARDS + "generos-pelis"), ("Por año", CARDS + "anios-pelis")],
    "p3Series": [("Últimas actualizaciones", _l("actualizadas-series")), ("Nuevas series", _l("nuevas-series")),
                 ("Series en seguimiento", K3 + "siguiendo"), ("Recomendadas", _l("recomendadas-series")),
                 ("Más vistas", _l("populares-series")), ("Más vistas este mes", _l("masvistas-series-mes")),
                 ("Clásicas", _l("clasicas-series")), ("Reality", _l("reality-series")),
                 ("Por géneros", CARDS + "generos-series"), ("Por año", CARDS + "anios-series")],
    "p3Dibujos": _cats("dibujos"),
    "p3Anime": _cats("anime"),
    "p3Documentales": _cats("documentales", sagas=False),
    "p3Favoritos": [("Películas favoritas", K3 + "favoritos/peliculas"), ("Series favoritas", K3 + "favoritos/series")],
    "own:telenovelas": [("Últimas actualizaciones", _l("telenovelas-series-actualizadas")),
                        ("Nuevas series", _l("telenovelas-series-nuevas"))],
    "own:musica": [("Novedades", _l("musica-pelis")), ("Últimas añadidas", _l("musica-pelis-ultimas"))],
    "own:seleccion": [("Lo mejor de A · Películas", _l("prime-pelis")), ("Lo mejor de N · Películas", _l("netflix-pelis")),
                      ("Lo mejor de D · Películas", _l("disney-pelis")), ("Lo mejor de H · Películas", _l("max-pelis")),
                      ("Basado o inspirado en una historia real", _l("historia-real-pelis")),
                      ("Lo mejor de A · Series", _l("prime-series")), ("Lo mejor de N · Series", _l("netflix-series")),
                      ("Lo mejor de D · Series", _l("disney-series")), ("Lo mejor de H · Series", _l("max-series")),
                      ("Lo mejor de AP", _l("apple-series"))],
}
# filas que daba Palantir y que no tienen equivalente: la migración única (flix_sections.migrate_own) borra su
# configuración; cualquier otra etiqueta guardada que el menú propio no tenga, también
_ABC = ["Por orden alfabético · Películas", "Por orden alfabético · Series"]
LOST = {
    "p3Peliculas": ["Especiales", "Por orden alfabético", "Por calidad"],
    "p3Series": ["Por orden alfabético"],
    "p3Dibujos": ["Especiales", "Por calidad"] + _ABC,
    "p3Anime": ["Especiales"] + _ABC,
    "p3Documentales": ["Sagas", "Especiales"] + _ABC,
    "p3Favoritos": ["Películas de dibujos favoritas", "Películas Anime favoritas", "Películas documentales favoritas",
                    "Música", "Series de dibujos favoritas", "Series Anime favoritas", "Series documentales favoritas",
                    "Telenovelas"],
    "own:telenovelas": ["Por orden alfabético"],
}
# secciones que se pueden añadir con fuentes propias (en vez de las entradas del menú raíz de Palantir)
EXTRA = [("Telenovelas", "own:telenovelas", "rows"), ("Música", "own:musica", "rows"),
         ("Nuestra selección", "own:seleccion", "rows"), ("Películas no finalizadas", K3 + "seguir", "list"),
         ("Series en seguimiento", K3 + "siguiendo", "list")]
# menú de Palantir (menu_id de su tabla «menus») -> menú propio
_BY_MENU_ID = {"20": "p3Peliculas", "40": "p3Series", "50": "p3Dibujos", "60": "p3Anime", "80": "p3Documentales",
               "30": "own:telenovelas", "70": "own:musica", "110": "own:seleccion"}
_ACTION = re.compile(r'"action": \'?([^\',}]+)')
_ESPECIAL = re.compile(r'"especial": \'?([^\',}]+)')
_MENU_ID = re.compile(r"menu_id=(-?\d+)")


def own_var(src, route=""):
    """menú propio de una sección: por su variable (las de serie y las propias «own:…») o por su ruta de Palantir
    decodificada (route, las añadidas «p3:…»); '' si no tiene"""
    if src in MENUS or src == TRAKT:
        return src
    m = _ACTION.search(route or "")
    act = m.group(1) if m else ""
    if act == "menu":
        n = _MENU_ID.search(route)
        return _BY_MENU_ID.get(n.group(1), "") if n else ""
    return {"favoritos": "p3Favoritos", "listas_trakt": TRAKT}.get(act, "")


def list_path(src, route=""):
    """sección de rejilla con equivalente: «Series en seguimiento» y «Películas no finalizadas» de Palantir (o ya la
    ruta propia, si se añadió con fuentes propias); '' si no"""
    if str(src or "").startswith(K3):
        return src
    m = _ACTION.search(route or "")
    act = m.group(1) if m else ""
    if act == "Mis_serieS":
        return K3 + "siguiendo"
    e = _ESPECIAL.search(route or "")
    if act == "listado_peliculaS" and e and e.group(1) == "no_finalizadas":
        return K3 + "seguir"
    return ""


def _row(label, path):
    return {"label": label, "path": path, "kind": "coll" if path.startswith(CARDS) else "list", "group": ""}


def rows_for(var, trakt=None):
    """filas del menú propio; None si la sección no tiene. Trakt: solo si está en uso (trakt = trakt_listas.json del
    addon): sus favoritos (= «Favorites» de Trakt, la base propia), su watchlist y sus listas personales, las dos
    últimas de solo lectura y sin las que se sabe vacías"""
    if var == TRAKT:
        t = trakt if isinstance(trakt, dict) else {}
        if not t.get("on"):
            return []
        wl = t.get("watchlist") if isinstance(t.get("watchlist"), dict) else {}
        out = [_row("Películas favoritas", K3 + "favoritos/peliculas"), _row("Series favoritas", K3 + "favoritos/series")]
        out += [_row("Watchlist %s" % name, _l("trakt-watchlist-" + cat))
                for cat, name in (("pelis", "Películas"), ("series", "Series")) if wl.get(cat) != 0]
        seen = {"Películas favoritas", "Series favoritas", "Watchlist Películas", "Watchlist Series"}
        for x in t.get("lists") or []:
            if not isinstance(x, dict) or not str(x.get("id", "")).isdigit() or not str(x.get("name") or "").strip():
                continue
            if x.get("n") == 0:
                continue                    # lista vacía: sin fila
            name = str(x["name"]).strip()
            name = name if name not in seen else "%s (Trakt)" % name
            seen.add(name)
            out.append(_row(name, "%strakt-%d" % (LIST, int(x["id"]))))
        return out
    if var not in MENUS:
        return None
    return [_row(label, path) for label, path in MENUS[var]]


# ---------- tarjetas (ruta tarjetas/<grupo>[/todo] del addon) ----------
_SAGAS = []


def load_sagas(path=None):
    """flix_sagas.json (tools/gen_sagas.py), una vez por proceso; [] si falta o no se lee"""
    if not _SAGAS:
        try:
            with open(path or os.path.join(os.path.dirname(os.path.abspath(__file__)), "flix_sagas.json"),
                      encoding="utf-8") as fh:
                data = json.load(fh)
            _SAGAS.append([d for d in data if isinstance(d, dict) and d.get("id")] if isinstance(data, list) else [])
        except (OSError, ValueError):
            _SAGAS.append([])
    return _SAGAS[0]


def _card(label, key, poster="", fanart=""):
    art = {}
    if poster:
        art.update(poster=IMG + "w342" + poster, thumb=IMG + "w342" + poster)
    if fanart:
        art["fanart"] = IMG + "w1280" + fanart
    return {"label": label, "key": key, "art": art}


def _years(cat, today):
    year = (today or datetime.date.today()).year
    out = [_card(str(y), "anio-%s-%d" % (cat, y)) for y in range(year, 1999, -1)]
    out += [_card("%d-%d" % (d, d + 9), "decada-%s-%d" % (cat, d)) for d in range(1990, 1949, -10)]
    return out + [_card("Antes de 1950", "antes-%s-1950" % cat)]


def parse(path):
    """(grupo, ¿todas?) de una ruta de tarjetas (K3/tarjetas/<grupo>[/todo]); ('', False) si no lo es"""
    path = str(path or "")
    if not path.startswith(CARDS):
        return "", False
    group, _, rest = re.split(r"[?&]", path[len(CARDS):], maxsplit=1)[0].partition("/")
    return group, rest == "todo"


def cards(group, sagas=None, today=None):
    """todas las tarjetas de un grupo ([] si no existe), en su orden: [{label, key (lista de Ker0n3), art}]"""
    import flix_tmdblists as tl
    what, _, cat = str(group or "").partition("-")
    if what == "generos" and cat in ("pelis", "series"):
        return [_card(name, "genero-%s-%s" % (cat, slug)) for slug, name, _gid in tl.GENRES["movie" if cat == "pelis" else "tv"]]
    if what == "anios" and cat in ("pelis", "series"):
        return _years(cat, today)
    if what == "sagas" and cat in SAGA_CATS:
        return [_card(s["name"], "col-%d" % int(s["id"]), s.get("poster") or "", s.get("fanart") or "")
                for s in (load_sagas() if sagas is None else sagas) if s.get("cat") == cat]
    return []


def card_keys(group, whole=False):
    """claves de las listas de las tarjetas que una fila de ese grupo puede enseñar (las CARD_MAX primeras o, tras su
    «Más…», todas): las que el servicio del addon comprueba por detrás"""
    keys = [c["key"] for c in cards(group)]
    return keys if whole else keys[:CARD_MAX + 20]      # margen: las que suben si se esconden las vacías
