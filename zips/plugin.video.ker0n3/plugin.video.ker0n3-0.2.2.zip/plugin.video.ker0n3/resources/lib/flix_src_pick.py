"""Orden de las versiones (fuentes propias, parte 1; 15-nov). Primero el idioma (Carlos: castellano siempre primero;
Dolby Vision en inglés solo a mano), luego el orden de calidades de Ajustes (flix_quality), el remux según su
ajuste y, a igualdad, la más grande hasta 40 GB. PeLis (15-nov): con el mismo idioma y la misma calidad, su enlace listo
(⚡: sin subir nada a AllDebrid, al momento) va antes que un torrent; el pendiente (⏳), después."""
LANG_RANK = {"cast": 0, "esp": 1, "multi": 2, "lat": 3, "?": 4, "otro": 5}
LANG_TEXT = {"cast": "castellano ✓", "esp": "castellano", "multi": "varios idiomas", "lat": "latino",
             "?": "VO probable", "otro": "VO"}
# «?»: el nombre no dice idioma. Casi siempre es la versión original (RARBG, ThePirateBay…: Carlos, S24 16-nov, «idioma sin
# datos» y luego la pista era inglés). «otro»: leído del fichero, sin español → versión original


def lang_of(c):
    """lo leído del fichero (flix_src_audio) manda sobre lo que dice el nombre"""
    if c.get("audio") in ("cast", "lat", "otro"):
        return c["audio"]
    return "lat" if c.get("lat") else "esp" if c.get("esp") else "multi" if c.get("multi") else "?"


def tier_of(c):
    if c.get("res") == 2160:
        hdr = "hdr10p" if c.get("hdr10p") else "hdr10" if c.get("hdr") else ""
        if c.get("dv"):
            return "dv" + ("hdr10p" if c.get("hdr10p") else "")
        return "4k" + hdr
    return "1080" if c.get("res") == 1080 else "720" if c.get("res") == 720 else "rest"


def instant(c):
    """enlace ya abierto y listo (PeLis ⚡): se reproduce tal cual, sin AllDebrid"""
    return bool(c.get("url")) and bool(c.get("ready"))


def pending(c):
    """enlace de PeLis que AllDebrid aún tiene que descargar (⏳): solo a mano, nunca solo"""
    return bool(c.get("url")) and not c.get("ready")


def order(cands, conf, lang=None):
    """lang: otra forma de ordenar por idioma (función versión → número) en vez de LANG_RANK; flix_src_play la usa
    sin castellano, para la versión original (confirmada antes que sin datos)"""
    pos = {}
    for i, (k, on) in enumerate(conf.order):
        pos[k] = i if on else 100 + i

    def key(c):
        rx = bool(c.get("remux"))
        t = tier_of(c)
        p = pos.get(t, 200)
        if t == "dv":       # el nombre no distingue DV de DV HDR10 (casi todas llevan HDR10 de base)
            p = min(p, pos.get("dvhdr10", 200))
        lr = LANG_RANK[lang_of(c)]
        # castellano primero; lo demás (varios idiomas, sin datos, versión original) va JUNTO y manda la calidad
        # elegida: con «1080p» la primera, un 4K «multi» pasaba delante de todos los 1080p sin idioma en el nombre y
        # solo se comprobaban esos (Nocturno 1x04, S24 16-nov). El latino sigue donde estaba (delante de lo que no
        # es español: sin ficha se elige como siempre; con ficha, flix_src_check ya lo ha quitado). El idioma desempata
        group = lr if lr <= 1 else 2 if lang_of(c) == "lat" else 3
        return (lang(c) if lang else group, 1000 if rx and not conf.remux else 0, p, rx,
                0 if lang else lr, 0 if instant(c) else 2 if pending(c) else 1, -min(c.get("gb") or 0, 40))
    return sorted(cands, key=key)


def allowed(c, conf):
    """¿la dejan los Ajustes? Calidad encendida (DV vale también con DV HDR10 encendida, como en order) y remux solo
    con permiso. flix_src_play prueba primero estas; las demás, solo si ninguna de estas tiene enlace"""
    if c.get("remux") and not conf.remux:
        return False
    on = {k: v for k, v in conf.order}
    t = tier_of(c)
    return bool(on.get(t) or (t == "dv" and on.get("dvhdr10")))


def label(c):
    res = {2160: "4K", 1080: "1080p", 720: "720p"}.get(c.get("res"), "SD")
    vid = " DV" if c.get("dv") else " HDR10+" if c.get("hdr10p") else " HDR" if c.get("hdr") else ""
    gb = c.get("gb") or 0
    lang = lang_of(c)
    # leído del fichero y sin la pista original (doblaje a un tercer idioma): no es la versión original
    text = "otro idioma" if lang == "otro" and c.get("vo") == "no" else LANG_TEXT[lang]
    parts = [res + vid + (" remux" if c.get("remux") else ""), text]
    if gb > 0:      # sin tamaño (la fuente no lo dio): nada, mejor que «0.0 GB»
        parts.append(("%d GB" % round(gb)) if gb >= 9.95 else ("%.1f GB" % gb))    # 9.97 → «10 GB», no «10.0 GB»
    if c.get("provider"):
        parts.append(c["provider"])
    if pending(c):
        parts.append("⏳ pendiente")
    return " · ".join(parts)
