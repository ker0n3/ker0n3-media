"""Lo único de Ker0n3 que habla con Trakt (16-nov). Diseño: docs/superpowers/specs/2026-11-16-trakt-propio-design.md.

Aplicación propia «Ker0n3 Media»: solo Client ID, sin secreto (Trakt ya no lo da; documentación del 1-oct-2026). Se
entra con el código de aparato (trakt.tv/activate), que solo pide el Client ID. Todo OAuth va a auth.trakt.tv.
El acceso se guarda en addon_data de Ker0n3 (trakt.json, permisos 600), por aparato; nunca se escribe en el registro.
Dura 7 días y se renueva con un refresh de UN solo uso: cada renovación trae otro, que se guarda antes de seguir.
Cupo de Trakt: 1 escritura por segundo y 500 lecturas cada 5 min por usuario."""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from ker0n3 import simkl as _files     # mismo fichero de acceso (600, escritura atómica) que Simkl

NAME, LABEL = "trakt", "Trakt"
# La aplicación de Trakt. Para pasar a otra (la de producción tiene otro Client ID) se cambian SOLO estas dos líneas:
# el acceso guardado con la anterior deja de valer y cada aparato pide vincular otra vez (stale)
CLIENT_ID = "E-Qu50Stp3YXbXX9Ypf4DBMC0gXh6OOtY2Mki8GjqZ0"
# la renovación pide una redirect_uri aunque el código de aparato no redirige a ningún sitio: tiene que ser una de
# las apuntadas en los ajustes de la aplicación. En pruebas vale cualquiera (la de siempre de las aplicaciones sin
# navegador); la de producción solo admite https:// en un dominio propio
REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob"
API, AUTH = "https://api.trakt.tv", "https://auth.trakt.tv"
UA = "Ker0n3Media/1.0"
POST_GAP = 1.1                  # s entre dos escrituras (Trakt: 1 por segundo)
RENEW_BEFORE = 86400            # s: se renueva el acceso cuando le queda menos de un día (dura 7)
QUOTA_WAIT = 300                # s que espera el servicio tras un 429 sin Retry-After (la ventana es de 5 min)
PAGES_MAX = 50                  # tope de páginas de una lista (por si una cabecera viene mal)
_last_post = [0.0]
_retry_after = [0]              # el Retry-After del último 429 (s)
_sleep = time.sleep


class TraktError(Exception):
    """kind: sin_red, sin_cupo, sin_vinculo u otro. code: el de HTTP (0 sin respuesta). error: el de OAuth, si vino"""

    def __init__(self, kind, msg="", code=0, error=""):
        Exception.__init__(self, "%s %s" % (kind, msg))
        self.kind, self.code, self.error = kind, code, error


Error = TraktError      # nombre común a los dos servicios (sync.py)


def token_path():
    import xbmcvfs
    import flix_common
    return xbmcvfs.translatePath(flix_common.K3DATA_REL + "trakt.json")


def load_token(path=None):
    """el acceso guardado, solo si es de ESTA aplicación (CLIENT_ID): el de otra no vale aquí ni se puede renovar"""
    d = _files.load_token(path or token_path())
    return d if d.get("client_id") == CLIENT_ID else {}


def stale(path=None):
    """¿hay guardado un acceso de otra aplicación de Trakt? (cambió CLIENT_ID: de la de pruebas a la de producción).
    Hay que vincular otra vez; quien lo ve avisa y lo olvida (service.py, link.py)"""
    d = _files.load_token(path or token_path())
    return bool(d.get("access_token")) and d.get("client_id") != CLIENT_ID


def save_token(tok, path=None, now=time.time):
    """guarda el acceso (600) con la hora a la que caduca y la aplicación que lo pidió; devuelve lo guardado"""
    path = path or token_path()
    d = {"access_token": tok["access_token"], "refresh_token": tok.get("refresh_token", ""),
         "expires_at": int(now()) + int(tok.get("expires_in") or 0), "client_id": CLIENT_ID}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, path)
    return d


def forget(path=None):
    _files.forget(path or token_path())


def linked(path=None):
    return bool(load_token(path).get("access_token"))


def call(method, path, body=None, token=None, params=None, opener=None, base=API, meta=None):
    """JSON de la respuesta (None si vacía). Errores como TraktError con su tipo. meta: dict donde dejar las
    cabeceras de la respuesta (paginación)"""
    if method != "GET":
        wait = POST_GAP - (time.time() - _last_post[0])
        if wait > 0:
            _sleep(wait)
        _last_post[0] = time.time()
    headers = {"User-Agent": UA, "Content-Type": "application/json", "trakt-api-key": CLIENT_ID,
               "trakt-api-version": "2"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode() if body is not None else None
    url = base + path + ("?" + urllib.parse.urlencode(params) if params else "")
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with (opener or urllib.request.urlopen)(req, timeout=20) as r:
            raw = r.read()
            if meta is not None:
                meta.update({k.lower(): v for k, v in dict(getattr(r, "headers", None) or {}).items()})
    except urllib.error.HTTPError as e:
        kind = {401: "sin_vinculo", 403: "sin_vinculo", 429: "sin_cupo"}.get(e.code, "otro")
        try:
            err = json.loads(e.read().decode() or "{}").get("error", "")
        except (ValueError, AttributeError, OSError):
            err = ""
        err = err if isinstance(err, str) else ""
        if e.code == 429:
            try:
                _retry_after[0] = int((e.headers or {}).get("Retry-After") or 0)
            except (TypeError, ValueError, AttributeError):
                _retry_after[0] = 0
        raise TraktError(kind, "HTTP %s %s %s" % (e.code, path, err), code=e.code, error=err)
    except (urllib.error.URLError, OSError) as e:
        raise TraktError("sin_red", "%s %s" % (path, e))
    try:
        return json.loads(raw.decode() or "null")
    except ValueError:
        raise TraktError("otro", "%s: respuesta que no es JSON" % path)


def quota_wait():
    """s que hay que esperar tras un 429: lo que dijo Trakt (Retry-After) con un margen, o QUOTA_WAIT si no dijo"""
    return min(max(_retry_after[0] + 5, 10), 3600) if _retry_after[0] > 0 else QUOTA_WAIT


# ---------- entrar: código de aparato (sin secreto ni redirección) ----------
def device_code(opener=None):
    """{device_code, user_code, verification_url, expires_in, interval}"""
    return call("POST", "/oauth/device/code", {"client_id": CLIENT_ID}, opener=opener, base=AUTH)


def poll_token(device_code, opener=None):
    """el acceso si ya se escribió el código en trakt.tv/activate; si no, "pending", "slow_down", "expired" (código
    caducado, usado o desconocido) o "denied" (el usuario dijo que no)"""
    try:
        d = call("POST", "/oauth/device/token", {"code": device_code, "client_id": CLIENT_ID}, opener=opener,
                 base=AUTH)
    except TraktError as e:
        r = {400: "pending", 429: "slow_down", 404: "expired", 409: "expired", 410: "expired", 418: "denied"}.get(e.code)
        if r:
            return r
        raise
    if isinstance(d, dict) and d.get("access_token"):
        return d
    return "pending"


def access(opener=None, path=None, now=time.time, force=False):
    """acceso válido; lo renueva si le queda menos de un día (o siempre con force). Renovación rechazada
    (invalid_grant): se olvida y TraktError sin_vinculo. Cualquier otro fallo al renovar no borra nada: mientras el
    acceso guardado no haya caducado se sigue con él"""
    tok = load_token(path)
    if not tok.get("access_token"):
        raise TraktError("sin_vinculo", "sin acceso guardado")
    left = tok.get("expires_at", 0) - now()
    if not force and left >= RENEW_BEFORE:
        return tok["access_token"]
    body = {"grant_type": "refresh_token", "refresh_token": tok.get("refresh_token"), "client_id": CLIENT_ID,
            "redirect_uri": REDIRECT_URI}
    try:
        try:
            d = call("POST", "/oauth/token", body, opener=opener, base=AUTH)
        except TraktError as e:
            if e.code != 400 or e.error == "invalid_grant":
                raise
            # un 400 que no es por el refresh (p. ej. la redirect_uri no es la de la aplicación): sin ella, que el
            # código de aparato no usa ninguna. No gasta el refresh: Trakt no llegó a canjearlo
            d = call("POST", "/oauth/token", {k: v for k, v in body.items() if k != "redirect_uri"}, opener=opener,
                     base=AUTH)
    except TraktError as e:
        if e.error == "invalid_grant" or e.code == 401:
            again = load_token(path)        # ¿lo renovó otro proceso entre medias? (el refresh es de un solo uso)
            if again.get("access_token") and again.get("refresh_token") != tok.get("refresh_token"):
                return again["access_token"]
            forget(path)
            raise TraktError("sin_vinculo", "renovación rechazada", code=e.code, error=e.error)
        if left > 0 and not force:
            return tok["access_token"]
        raise
    if not (isinstance(d, dict) and d.get("access_token")):
        raise TraktError("otro", "renovación sin acceso")
    return save_token(d, path=path, now=now)["access_token"]


def revoke(opener=None):
    """le dice a Trakt que este acceso ya no vale (al desvincular: que la aplicación no quede conectada en la
    cuenta). True si Trakt lo aceptó; nunca lanza"""
    tok = load_token().get("access_token")
    if not tok:
        return False
    try:
        call("POST", "/oauth/revoke", {"token": tok, "client_id": CLIENT_ID}, opener=opener, base=AUTH)
        return True
    except TraktError:
        return False


# ---------- con la cuenta ----------
def request(method, path, body=None, params=None, opener=None, meta=None):
    """llamada con el acceso; a un 401 (acceso revocado o caducado antes de tiempo) renueva una vez y repite"""
    try:
        return call(method, path, body, token=access(opener=opener), params=params, opener=opener, meta=meta)
    except TraktError as e:
        if e.code != 401:
            raise
    return call(method, path, body, token=access(opener=opener, force=True), params=params, opener=opener, meta=meta)


def get(path, params=None, opener=None):
    return request("GET", path, params=params, opener=opener)


def post(path, body, opener=None):
    return request("POST", path, body, opener=opener)


class Page(list):
    """una lista de Trakt; complete = False si no se pudo leer entera (algo que no es lista, o más páginas que
    PAGES_MAX): con ella no se hace espejo (sync.mirror) aunque lo que trae sí se use"""
    complete = True


def get_list(path, params=None, opener=None):
    """una lista entera: si Trakt la pagina (cabeceras X-Pagination-*), todas sus páginas. Lo que no sea lista: [].
    sync/watched/* viene de 100 en 100 (comprobado con una cuenta real el 16-nov). Devuelve una Page (complete)"""
    meta = {}
    d = request("GET", path, params=params, opener=opener, meta=meta)
    out = Page(d if isinstance(d, list) else [])
    out.complete = isinstance(d, list)
    try:
        pages, limit = int(meta.get("x-pagination-page-count") or 1), int(meta.get("x-pagination-limit") or 0)
    except (TypeError, ValueError):
        pages, limit = 1, 0
        out.complete = False
    if pages > PAGES_MAX:
        out.complete = False
    for page in range(2, min(pages, PAGES_MAX) + 1):
        more = dict(params or {}, page=page)
        if limit:
            more["limit"] = limit
        d = request("GET", path, params=more, opener=opener)
        out += d if isinstance(d, list) else []
        if not isinstance(d, list):
            out.complete = False
    return out


def user_name(opener=None):
    d = get("/users/settings", opener=opener) or {}
    u = d.get("user") or {}
    return (u.get("username") or u.get("name") or "").strip()


def last_activities(opener=None):
    return get("/sync/last_activities", opener=opener) or {}


def watched(kind, opener=None):
    """kind: movies o shows. Todo lo visto de la cuenta, con veces y última vez. Las series, con extended=progress:
    sin él ya no traen los capítulos (comprobado con una cuenta real el 16-nov)"""
    return get_list("/sync/watched/%s" % kind, params={"extended": "progress"} if kind == "shows" else None,
                    opener=opener)


def playback(kind, opener=None):
    """kind: movies o episodes. Pausas guardadas en la cuenta"""
    return get_list("/sync/playback/%s" % kind, opener=opener)


def remove_playback(pid, opener=None):
    """quita una pausa de la cuenta por su id (el «id» de sync/playback): DELETE sync/playback/<id> → 204. True si la
    quitó; False si Trakt da 404 (el id ya no vale: otro aparato la quitó o se reanudó). Es una escritura (call
    espera POST_GAP). El resto de errores, como siempre"""
    try:
        request("DELETE", "/sync/playback/%d" % int(pid), opener=opener)
    except TraktError as e:
        if e.code == 404:
            return False
        raise
    return True


def hidden(opener=None):
    """series ocultas del progreso («Dejar de seguir la serie»; 16-nov): [{hidden_at, type: show, show: {ids}}].
    type=show es obligatorio; sin limit Trakt da pocas por página, así que se piden de 100 en 100 (y todas)"""
    return get_list("/users/hidden/progress_watched", params={"type": "show", "limit": 100}, opener=opener)


def favorites(kind, opener=None):
    """kind: movies o shows. «Favorites» de la cuenta (los favoritos de la skin)"""
    return get_list("/sync/favorites/%s" % kind, opener=opener)


def watchlist(kind, opener=None):
    """kind: movies o shows. La lista de pendientes de la cuenta"""
    return get_list("/sync/watchlist/%s/rank/asc" % kind, opener=opener)


def show_progress(show, opener=None):
    """lo visto de UNA serie (id de Trakt), capítulo a capítulo: {aired, completed, reset_at, seasons: [{number,
    episodes: [{number, completed, last_watched_at}]}]}. Con las temporadas ocultas y sin especiales. Solo se usa
    si sync/watched/shows llegara sin los capítulos (trakt_sync.read_all_shows)"""
    d = get("/shows/%d/progress/watched" % int(show), params={"hidden": "true", "specials": "false"}, opener=opener)
    return d if isinstance(d, dict) else {}


def show_id(tmdb, opener=None):
    """id de Trakt de una serie a partir del de TMDB; None si Trakt no la tiene"""
    d = get("/search/tmdb/%d" % int(tmdb), params={"type": "show"}, opener=opener)
    for it in d if isinstance(d, list) else []:
        t = ((it.get("show") or {}).get("ids") or {}).get("trakt")
        if t:
            return int(t)
    return None


def episode_id(show, season, episode, opener=None):
    """id de Trakt de un capítulo (la referencia de scrobble solo admite el id del capítulo)"""
    d = get("/shows/%d/seasons/%d/episodes/%d" % (int(show), int(season), int(episode)), opener=opener) or {}
    t = (d.get("ids") or {}).get("trakt")
    return int(t) if t else None
