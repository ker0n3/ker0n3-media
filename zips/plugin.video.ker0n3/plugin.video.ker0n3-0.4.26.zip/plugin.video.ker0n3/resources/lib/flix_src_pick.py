"""Orden de las versiones (fuentes propias, parte 1; 15-nov). Primero el idioma (Carlos: castellano siempre primero;
Dolby Vision en inglés solo a mano), luego el orden de calidades de Ajustes (flix_quality), el remux según su
ajuste y, a igualdad, la más grande hasta 40 GB. PeLis (15-nov): con el mismo idioma y la misma calidad, su enlace listo
(⚡: sin subir nada a AllDebrid, al momento) va antes que un torrent; el pendiente (⏳), después."""
LANG_RANK = {"cast": 0, "esp": 1, "multi": 2, "lat": 3, "?": 4, "otro": 5}
LANG_TEXT = {"cast": "castellano ✓", "esp": "castellano", "multi": "varios idiomas", "lat": "latino",
             "?": "VO probable", "otro": "VO"}
# «?»: el nombre no dice idioma. Casi siempre es la versión original (RARBG, ThePirateBay…: Carlos, S24 16-nov, «idioma sin
# datos» y luego la pista era inglés). «otro»: leído del fichero, sin español → versión original


def lang_of(c):
    """lo leído del fichero (flix_src_audio) manda sobre lo que dice el nombre"""
    if c.get("audio") in ("cast", "lat", "otro"):
        return c["audio"]
    return "lat" if c.get("lat") else "esp" if c.get("esp") else "multi" if c.get("multi") else "?"


def tier_of(c):
    if c.get("res") == 2160:
        hdr = "hdr10p" if c.get("hdr10p") else "hdr10" if c.get("hdr") else ""
        if c.get("dv"):
            return "dv" + ("hdr10p" if c.get("hdr10p") else "")
        return "4k" + hdr
    return "1080" if c.get("res") == 1080 else "720" if c.get("res") == 720 else "rest"


def instant(c):
    """enlace ya abierto y listo (PeLis ⚡): se reproduce tal cual, sin AllDebrid"""
    return bool(c.get("url")) and bool(c.get("ready"))


def pending(c):
    """enlace de PeLis que AllDebrid aún tiene que descargar (⏳): solo a mano, nunca solo"""
    return bool(c.get("url")) and not c.get("ready")


def order(cands, conf, lang=None):
    """lang: otra forma de ordenar por idioma (función versión → número) en vez de LANG_RANK; flix_src_play la usa
    sin castellano, para la versión original (confirmada antes que sin datos)"""
    pos = {}
    for i, (k, on) in enumerate(conf.order):
        pos[k] = i if on else 100 + i

    def key(c):
        rx = bool(c.get("remux"))
        t = tier_of(c)
        p = pos.get(t, 200)
        if t == "dv":       # el nombre no distingue DV de DV HDR10 (casi todas llevan HDR10 de base)
            p = min(p, pos.get("dvhdr10", 200))
        lr = LANG_RANK[lang_of(c)]
        # castellano primero; lo demás (varios idiomas, sin datos, versión original) va JUNTO y manda la calidad
        # elegida: con «1080p» la primera, un 4K «multi» pasaba delante de todos los 1080p sin idioma en el nombre y
        # solo se comprobaban esos (Nocturno 1x04, S24 16-nov). El latino sigue donde estaba (delante de lo que no
        # es español: sin ficha se elige como siempre; con ficha, flix_src_check ya lo ha quitado). El idioma desempata
        group = lr if lr <= 1 else 2 if lang_of(c) == "lat" else 3
        # sin castellano, a igual calidad, la que trae subtítulos en castellano dentro (anime de Nyaa, 17-nov): sin
        # depender de los de fuera
        subs = 0 if c.get("esp_subs") and lr > 1 else 1
        return (lang(c) if lang else group, 1000 if rx and not conf.remux else 0, p, rx,
                0 if lang else lr, subs, 0 if instant(c) else 2 if pending(c) else 1, -min(c.get("gb") or 0, 40))
    return sorted(cands, key=key)


def allowed(c, conf):
    """¿la dejan los Ajustes? Calidad encendida (DV vale también con DV HDR10 encendida, como en order) y remux solo
    con permiso. flix_src_play prueba primero estas; las demás, solo si ninguna de estas tiene enlace"""
    if c.get("remux") and not conf.remux:
        return False
    on = {k: v for k, v in conf.order}
    t = tier_of(c)
    return bool(on.get(t) or (t == "dv" and on.get("dvhdr10")))


def label(c):
    res = {2160: "4K", 1080: "1080p", 720: "720p"}.get(c.get("res"), "SD")
    vid = " DV" if c.get("dv") else " HDR10+" if c.get("hdr10p") else " HDR" if c.get("hdr") else ""
    gb = c.get("gb") or 0
    lang = lang_of(c)
    # leído del fichero y sin la pista original (doblaje a un tercer idioma): no es la versión original
    text = "otro idioma" if lang == "otro" and c.get("vo") == "no" else LANG_TEXT[lang]
    if c.get("esp_subs") and lang not in ("cast", "esp"):
        text += " + subs castellano"
    parts = [res + vid + (" remux" if c.get("remux") else ""), text]
    if gb > 0:      # sin tamaño (la fuente no lo dio): nada, mejor que «0.0 GB»
        parts.append(("%d GB" % round(gb)) if gb >= 9.95 else ("%.1f GB" % gb))    # 9.97 → «10 GB», no «10.0 GB»
    if c.get("provider"):
        parts.append(c["provider"])
    if pending(c):
        parts.append("⏳ pendiente")
    return " · ".join(parts)


# --- «Elegir versión» con insignias (18-nov): una fila por versión, columnas fijas -----------------------------------
RES_BADGE = {2160: "4k", 1080: "1080", 720: "720"}
NOT_READY = "No lista aún en AllDebrid"


def lang_text(c):
    """el idioma como lo dice label(), con mayúscula: «Castellano ✓», «VO + subs castellano», «Latino»…"""
    lang = lang_of(c)
    text = "otro idioma" if lang == "otro" and c.get("vo") == "no" else LANG_TEXT[lang]
    if c.get("esp_subs") and lang not in ("cast", "esp"):
        text += " + subs castellano"
    return text[:1].upper() + text[1:]


def size_text(gb):
    """«62 GB» / «2.9 GB»; '' sin tamaño"""
    gb = gb or 0
    if gb <= 0:
        return ""
    return ("%d GB" % round(gb)) if gb >= 9.95 else ("%.1f GB" % gb)


def _cap(text):
    return text[:1].upper() + text[1:]


def langs_text(c):
    """1.ª línea: el idioma como siempre (lang_text, con «+ subs castellano») y los demás idiomas del audio que trae
    (flix_src_info): «Castellano · Inglés, francés», «VO · Inglés» (sin castellano, con el idioma sabido)"""
    import flix_src_info
    lang = lang_of(c)
    other = [k for k in flix_src_info.of(c)["langs"] if k not in ("esp", "lat")]
    if lang in ("?", "otro") and other:
        base = "VO · " + _cap(flix_src_info.names(other))
        return base + (" + subs castellano" if c.get("esp_subs") else "")
    return lang_text(c) + (" · " + _cap(flix_src_info.names(other)) if other else "")


# banderas del idioma delante del texto (Carlos, 23-nov; media/flix/flags/<clave>.png, tools/make_flags.py): la del
# idioma de siempre (castellano, latino, «multi» = varios, «vo» = VO sin idioma sabido) y las de los demás idiomas del
# audio que trae; como mucho FLAGS_MAX. Las de idiomas sin bandera se quedan solo en el texto
FLAGS_MAX = 3
_FIRST_FLAG = {"cast": "esp", "esp": "esp", "lat": "lat", "multi": "multi", "?": "vo", "otro": "vo"}


def lang_flags(c):
    import flix_src_info
    first = _FIRST_FLAG[lang_of(c)]
    other = [k for k in flix_src_info.of(c)["langs"] if k not in ("esp", "lat") and k in flix_src_info.LANG_NAMES]
    out = [] if first == "vo" and other else [first]
    return (out + other)[:FLAGS_MAX]


SEP = "  ·  "
# 2.ª línea (20-nov, Carlos: más datos de cada versión SIN cambiar el diseño de «Elegir versión»: las 2 líneas de
# siempre). Caben unos LINE_MAX caracteres en el hueco de la TV (el más estrecho; con 44 ya se cortaba en la Shield);
# lo que no quepa se queda fuera por este orden de importancia: tamaño, copia, códec, subtítulos, semillas, plataforma,
# bitrate. El aviso en ámbar («No lista aún en AllDebrid») va detrás y siempre cabe
LINE_MAX = 40


def detail_parts(c):
    """[(importancia, texto)] de la 2.ª línea, en el orden en que se enseñan"""
    import flix_src_info
    i = flix_src_info.of(c)
    subs = [k for k in i["subs"] if not (k == "esp" and c.get("esp_subs"))]     # «+ subs castellano» ya va arriba
    rate = flix_src_info.mbps(c.get("gb"), c.get("runtime"))
    seeds = i["seeds"]
    sub = ("Subs: " + flix_src_info.names(subs, limit=2) + (" (forzados)" if i["forced"] else "")) if subs else \
        ("Subs forzados" if i["forced"] else "")
    return [(0, size_text(c.get("gb"))),
            (1, "Remux" if c.get("remux") else i["copy"]),
            (2, (i["vcodec"] + (" 10bit" if i["bit10"] and i["vcodec"] else "")).strip()),
            (5, i["service"]),
            (3, sub),
            (6, (("%d Mbps" % round(rate)) if rate >= 9.5 else ("%.1f Mbps" % rate).replace(".", ",")) if rate else ""),
            (4, ("%d semilla%s" % (seeds, "" if seeds == 1 else "s")) if seeds is not None else "")]


def sub_text(c, room=LINE_MAX):
    """2.ª línea: lo que quepa en room caracteres, por importancia, en el orden de detail_parts"""
    parts = [(k, n, t) for n, (k, t) in enumerate(detail_parts(c)) if t]
    keep = set()
    for k, n, t in sorted(parts):
        trial = keep | {n}
        if len(SEP.join(t2 for _k, n2, t2 in parts if n2 in trial)) <= room or not keep:
            keep = trial
    return SEP.join(t for _k, n, t in parts if n in keep)


def row(c):
    """lo que enseña la fila de una versión en «Elegir versión» (FlixPick.xml): insignias de calidad (q), imagen (v),
    audio (a) y canales (ch) — nombres de flix/badges/, '' = la fuente no lo dice («–») —; qt: la calidad en texto si no
    tiene insignia (SD); lang: idiomas; fl1-fl3: sus banderas (lang_flags, '' = ninguna); sub: tamaño · copia · códec · plataforma · subtítulos · bitrate · semillas, lo
    que quepa (sub_text); warn: aviso si no está lista en AllDebrid. Sin el nombre de la fuente (Carlos, 18-nov: no
    ayuda a decidir)"""
    import re
    import flix_src_codec
    text = ("%s %s" % (c.get("label") or "", c.get("filename") or "")).lower()
    vid = ("dv" if c.get("dv") else "hdr10plus" if c.get("hdr10p") else
           ("hdr10" if re.search(r"hdr10(?!\+|plus|p)", text) else "hdr") if c.get("hdr") else "")
    q = RES_BADGE.get(c.get("res"), "")
    warn = NOT_READY if pending(c) else ""
    fl = lang_flags(c) + ["", "", ""]
    return {"q": q, "qt": "" if q else "SD", "v": vid, "a": flix_src_codec.badge(c.get("au") or ""),
            "ch": ("au_" + c["ch"]) if c.get("ch") else "", "lang": langs_text(c),
            "fl1": fl[0], "fl2": fl[1], "fl3": fl[2],
            "sub": sub_text(c, LINE_MAX - (len(SEP + NOT_READY) if warn else 0)), "warn": warn}
