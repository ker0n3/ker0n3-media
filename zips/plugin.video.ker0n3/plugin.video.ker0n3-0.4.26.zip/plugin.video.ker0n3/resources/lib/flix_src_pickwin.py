"""«Elegir versión» con insignias (18-nov): la ventana FlixPick.xml de la skin (tools/gen_pick_dialog.py, TV y táctil).

Qué versiones y en qué orden lo decide flix_src_play.choose (lógica, aquí en el addon); cada fila la arma
flix_src_pick.row (insignias de calidad, imagen, audio y canales; idioma; tamaño y remux; aviso si no está lista).
Esta ventana solo las enseña y devuelve cuál se eligió. La abren tanto la skin (flix_play → flix_src_play.play) como
el addon (ruta play/…, handlers._play): una WindowXMLDialog con la ruta de la skin en uso; Kodi busca el XML en la
skin. Si la skin no lo trae (otra skin, una vieja) o la ventana falla, select() lanza Unavailable y quien llama usa la
lista de Kodi de siempre (Dialog().select). Atrás = -1 (cancelar), como la lista de Kodi."""
XML = "FlixPick.xml"
LIST = 100
FIELDS = ("q", "qt", "v", "a", "ch", "lang", "fl1", "fl2", "fl3", "sub", "warn")
HEADING = "Elegir versión"
FOOT = "Arriba, la que se pondría sola con tu orden de calidades  ·  «–» = la versión no lo dice"


class Unavailable(Exception):
    """la skin no tiene la ventana: la lista de Kodi"""


def skin_has_window():
    """¿la skin en uso trae FlixPick.xml? (TV: resources/skins/Default/1080i; táctil: xml/)"""
    import xbmcvfs
    return any(xbmcvfs.exists("special://skin/%s/%s" % (d, XML)) for d in ("resources/skins/Default/1080i", "xml"))


def select(sub, rows, heading=HEADING):
    """índice elegido o -1. rows: [flix_src_pick.row(c)]. Unavailable si no se puede enseñar"""
    rows = list(rows)
    got = _show(sub, list(range(len(rows))), lambda i: rows[i], None, lambda i: i, heading)
    return got if got is not None else -1


def select_live(sub, items, rowfn, live, key=lambda x: x, heading=HEADING):
    """la versión elegida (de items o de lo que llegue después) o None (Atrás). live(cb): cb(lista nueva) cada vez que
    llega algo (20-nov: PeLis tarde); la lista se rehace en su sitio y el foco sigue en la misma versión (key)"""
    return _show(sub, list(items), rowfn, live, key, heading)


def _show(sub, items, rowfn, live, key, heading):
    import threading
    import xbmcgui
    import xbmcvfs
    if not skin_has_window():
        raise Unavailable(XML)
    lock = threading.Lock()

    class Win(xbmcgui.WindowXMLDialog):
        choice, shown, done = None, items, False

        def _fill(self, keep=None):
            lst = self.getControl(LIST)
            lst.reset()
            lis = []
            for it in self.shown:
                r = rowfn(it)
                li = xbmcgui.ListItem(r.get("lang") or "")
                for k in FIELDS:
                    li.setProperty(k, r.get(k) or "")
                lis.append(li)
            lst.addItems(lis)
            keys = [key(it) for it in self.shown]
            if keep is not None and keep in keys:
                lst.selectItem(keys.index(keep))

        def onInit(self):
            self.setProperty("pk_title", heading)
            self.setProperty("pk_sub", sub or "")
            self.setProperty("pk_foot", FOOT)
            with lock:
                self._fill()
            self.setFocusId(LIST)
            if live is not None:
                live(self.update)

        def update(self, new_items):
            """lo que llega con la ventana abierta (desde otro hilo)"""
            with lock:
                if self.done or not new_items:
                    return
                pos = self.getControl(LIST).getSelectedPosition()
                keep = key(self.shown[pos]) if 0 <= pos < len(self.shown) else None
                self.shown = list(new_items)
                self._fill(keep)

        def onClick(self, cid):
            if cid == LIST:
                with lock:
                    pos = self.getControl(LIST).getSelectedPosition()
                    self.choice = self.shown[pos] if 0 <= pos < len(self.shown) else None
                    self.done = True
                self.close()

        def onAction(self, action):
            import flix_common
            if action.getId() in flix_common.A_BACK:
                with lock:
                    self.choice, self.done = None, True
                self.close()
    try:
        w = Win(XML, xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    except Exception as e:  # noqa: BLE001  (XML que no está o roto: la lista de Kodi)
        raise Unavailable(str(e)) from None
    w.doModal()
    with lock:
        w.done = True
    choice = w.choice
    del w
    return choice
