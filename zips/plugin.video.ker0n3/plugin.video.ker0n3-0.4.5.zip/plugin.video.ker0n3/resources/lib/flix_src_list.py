"""Torrents de una película o capítulo en Torrentio y Peerflix (fuentes propias, parte 1; 15-nov). Diseño:
docs/superpowers/specs/2026-11-15-enlaces-sin-palantir-design.md.

La bandera 🇪🇸 de Torrentio NO dice nada (comprobado: 4K DV marcados así traían solo inglés). Pistas de idioma por el
nombre: «[Esp]», «Castellano», «Spa», «ESP-ENG» → castellano probable; «Latino», «LAT», «es-419» → latino;
«Dual», «MULTi» o varias lenguas → puede llevar castellano. Peerflix con solo la bandera 🇪🇸 = castellano.

PeLis (tercera fuente, 15-nov; Stremio, castellano de España): dirección propia de cada usuario (lleva su id y, en su
servidor, su clave de AllDebrid), guardada por aparato en addon_data/<skin>/pelis.json (permisos 600). Sin ella no se
le pregunta. NUNCA se escribe en el registro (ni la dirección ni los enlaces, que la llevan dentro). Sus streams traen
`url` (enlace ya abierto, sin infoHash): ⚡ = listo en AllDebrid, ⏳ = AllDebrid tiene que descargarlo.

Linkañol (cuarta fuente, 17-nov; Stremio, «enlaces en español de España», github USB-5V/stremiospanishaddon): una base
de enlaces de 1fichier con los idiomas del audio exactos («1080p esp», «DV HDR10 eng,esp», «1080p lat,eng»). Se le pide
SIN clave (en Stremio pide la de AllDebrid y la pasa por un servidor intermedio de terceros: aquí no). Cada stream trae
un enlace a su /proxy/debrid con ?link=<1fichier>: se queda solo el enlace de 1fichier y lo abre este aparato con su
AllDebrid (flix_alldebrid.unlock) al reproducir («unlock»: True). Opcional: si no contesta, no vuelve desconocido nada
(no entra en `status`); probado 17-nov en 30 títulos: castellano en todos, 0,4-1,5 s."""
import hashlib
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import flix_src_codec

TORRENTIO = ("https://torrentio.strem.fun/providers=yts,eztv,rarbg,1337x,thepiratebay,kickasstorrents,torrentgalaxy,"
             "magnetdl,nyaasi,mejortorrent,wolfmax4k,cinecalidad,besttorrents|language=spanish")
PEERFLIX = "https://peerflix.mov"
LINKANOL = "https://8bcec99c5d97-spanish-links-addon.baby-beamup.club"
SOURCES = (("torrentio", TORRENTIO), ("peerflix", PEERFLIX))
OPTIONAL = (("linkanol", LINKANOL),)    # se preguntan siempre; si fallan, no cuentan en `status`
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
TIMEOUT = 8
ESP_PROVIDERS = ("mejortorrent", "wolfmax4k")
LAT_PROVIDERS = ("cinecalidad",)
_LAT = re.compile(r"latino|\blat\b|\blatam\b|es-419|castellano-latino", re.I)
# 16-nov («Manhunt» rotulada «[Esp]» sin serlo): «cast» suelto no vale (es una palabra inglesa: «Cast Away»), solo
# entre corchetes o paréntesis; y lo que habla de SUBTÍTULOS en español (VOSE, «Spanish Subs», «Sub Esp») se quita
# antes de mirar: no es audio
_ESP = re.compile(r"\[esp\]|castellano|[\[(]cast[\])]|\bspa\b|\besp\b|esp-eng|spanish|español", re.I)
_ESP_SUBS = re.compile(r"\bv\.?o\.?s\.?e\b|\bsub(?:s|t\w*)?[\s._-]*(?:en[\s._-]*)?(?:spanish|espa[ñn]ol|castellano|esp|spa)\b"
                       r"|\b(?:spanish|espa[ñn]ol|esp|spa)[\s._-]*sub\w*", re.I)
# anime (Nyaa, 17-nov, Frieren): «[Multiple Subtitle] [ENG][POR-BR][SPA-LA][SPA]…» o «[Multi-Subs] (ENG, SPA)» son
# listas de SUBTÍTULOS (el audio es japonés): se quitan antes de buscar el idioma del audio, y «SPA» en ellas (no
# «SPA-LA») queda como «subtítulos en castellano dentro» (esp_subs)
_LANG_CODE = r"[A-Z]{2,3}(?:-[A-Z]{2,3})?"
_SUB_LIST = re.compile(r"(?:\[\s*%s\s*\]\s*){2,}" % _LANG_CODE)
_SUB_WORD = re.compile(r"multiple[\s._-]*subtitles?|multi[\s._-]*subs?\b", re.I)
_SUB_PAREN = re.compile(r"[\[(]\s*(?:%s\s*[,/]\s*)+%s\s*[\])]" % (_LANG_CODE, _LANG_CODE))
_SPA_SUB = re.compile(r"(?<![A-Z])(?:SPA|ESP)(?![A-Z-])")
_SIZE = re.compile(r"💾\s*[\d.,]+\s*(?:GB|MB)|👤\s*\d+", re.I)
_MULTI = re.compile(r"\bdual\b|\bmulti\b|eng\.fre|\.spa\.|\bspa\b.*\beng\b|\beng\b.*\bspa\b", re.I)
_VIDEO = re.compile(r"\.(mkv|mp4|avi|m2ts|ts|mov)$", re.I)


def _filename(stream, origin):
    """nombre del fichero que trae la versión (packs de películas: flix_alldebrid.pick_file elige ese). Torrentio lo da
    en behaviorHints.filename; Peerflix, en la 2.ª línea de la descripción. "" si no se sabe"""
    hints = stream.get("behaviorHints")
    name = hints.get("filename") if isinstance(hints, dict) else None
    if isinstance(name, str) and name.strip():
        return name.strip()
    if origin == "peerflix":
        lines = (stream.get("description") or "").split("\n")
        if len(lines) > 1 and _VIDEO.search(lines[1].strip()):
            return lines[1].strip()
    return ""


def _gb(text):
    m = re.search(r"💾\s*([\d.]+)\s*(GB|MB)", text)
    if not m:
        return 0.0
    v = float(m.group(1))
    return round(v / 1024 if m.group(2) == "MB" else v, 2)


def strip_sub_lists(name):
    """(el nombre sin las listas de subtítulos del anime, ¿alguna dice castellano?). Lo usa también
    flix_src_check.name_langs: «[ENG][GER][ITA]» de una lista de subtítulos no son doblajes"""
    name = name or ""
    lists = _SUB_LIST.findall(name)
    if _SUB_WORD.search(name):
        lists += _SUB_PAREN.findall(name)
    out = name
    for x in lists:
        out = out.replace(x, " ")
    return _SUB_WORD.sub(" ", out), any(_SPA_SUB.search(x) for x in lists)


def parse(stream, origin):
    h = (stream.get("infoHash") or "").lower()
    if not h:
        return None
    body = "\n".join([stream.get("title") or "", stream.get("description") or ""])
    text = (stream.get("name") or "") + "\n" + body
    t = text.lower()
    first = (body.strip().split("\n") or [""])[0].strip()
    prov = re.search(r"(?:⚙️|🌐)\s*([^\s|]+)", text)
    provider = prov.group(1) if prov else ""
    sin_tam = _SIZE.sub(" ", t)     # sin tamaño ni seeds: «1.720 GB» no es 720p
    res = (2160 if re.search(r"\b(2160p|4k|uhd)\b", sin_tam) else 1080 if re.search(r"\b1080[pi]?\b", sin_tam)
           else 720 if re.search(r"\b720p?\b", sin_tam) else 480)
    dv = bool(re.search(r"\bdv\b|dolby.?vision|\bdovi\b", t))
    hdr10p = bool(re.search(r"hdr10\+|hdr10plus|hdr10p", t))
    filename = _filename(stream, origin)
    # latino por el NOMBRE (del torrent o del fichero: Peerflix los da en líneas distintas) o por el sitio
    lat_name = bool(_LAT.search(first)) or bool(_LAT.search(filename))
    lat = lat_name or provider.lower() in LAT_PROVIDERS
    sub_free, esp_subs = strip_sub_lists(first)
    audio_name = _ESP_SUBS.sub(" ", sub_free)   # el nombre sin lo que dice de los subtítulos
    esp_name = not lat_name and bool(_ESP.search(audio_name))       # el nombre dice castellano expresamente
    esp = not lat and (esp_name or provider.lower() in ESP_PROVIDERS)
    if origin == "peerflix" and "🇪🇸" in text and not re.search(r"🇬🇧|🇲🇽|🇦🇷", text) and not lat \
            and audio_name == first:
        esp = True
    # audio y canales (solo para enseñarlos en «Elegir versión»: no cuentan para el orden ni la elección)
    au_text = sin_tam + "\n" + filename.lower()
    return {"hash": h, "origin": origin, "res": res, "dv": dv, "hdr": dv or hdr10p or "hdr" in t,
            "hdr10p": hdr10p, "remux": "remux" in t, "gb": _gb(text), "provider": provider,
            "esp": esp, "lat": lat, "multi": bool(_MULTI.search(sub_free)), "label": first[:120], "esp_subs": esp_subs,
            "filename": filename, "lat_name": lat_name, "esp_name": esp_name,
            "au": flix_src_codec.audio(au_text), "ch": flix_src_codec.channels(au_text)}


_PELIS_SEG = re.compile(r"\s*(?:\n|\|)\s*")


def _seg(segs, icon):
    return next((x[len(icon):].strip() for x in segs if x.startswith(icon)), "")


def parse_pelis(stream):
    """un stream de PeLis con la misma forma que parse() más url, ready (⚡), direct (sin 🧲: enlace de descarga
    directa) y hash sintético «pelis:»+sha1(url) (para unir y quitar repetidos). None: el banner de donativos
    («Colabora»), sin url, o ⏳ con «👤 0 fuentes» (no va a descargar)"""
    url = stream.get("url")
    name = stream.get("name") or ""
    if not isinstance(url, str) or not url.startswith(("https://", "http://")) or "colabora" in name.lower():
        return None
    body = "\n".join([stream.get("title") or "", stream.get("description") or ""])
    ready = "⚡" in name
    src = re.search(r"👤\s*(\d+)\s*fuente", body)
    if not ready and src and int(src.group(1)) == 0:
        return None
    segs = [x for x in _PELIS_SEG.split(body) if x.strip()]
    file_ = _seg(segs, "📄")
    audio = _seg(segs, "🔊").lower()
    langs = [x for x in re.split(r"\s*[-,/·+]\s*|\s+y\s+", audio) if x.strip()]
    hints = stream.get("behaviorHints")
    hint_name = hints.get("filename") if isinstance(hints, dict) and isinstance(hints.get("filename"), str) else ""
    q = (name + "\n" + file_).lower()      # calidad: lo que dice PeLis y el nombre del fichero
    n = name.lower()
    res = (2160 if re.search(r"\b(4k|2160p?|uhd)\b", n) else 1080 if re.search(r"\b1080[pi]?\b", n)
           else 720 if re.search(r"\b720p?\b", n) else 480 if re.search(r"\bsd\b|\b480p?\b", n)
           else 2160 if re.search(r"\b(4k|2160p|uhd)\b", q) else 1080 if re.search(r"\b1080[pi]?\b", q)
           else 720 if re.search(r"\b720p\b", q) else 480)
    dv = bool(re.search(r"dolby.?vision|\bdv\b|\bdovi\b", q))
    hdr10p = bool(re.search(r"hdr10\+|hdr10plus", q))
    lat = "latino" in audio
    title = _seg(segs, "🎬")
    au_text = q + "\n" + hint_name.lower()     # audio y canales: solo para «Elegir versión»
    return {"hash": "pelis:" + hashlib.sha1(url.encode()).hexdigest(), "origin": "pelis", "url": url,
            "ready": ready, "direct": "🧲" not in body, "res": res, "dv": dv,
            "hdr": dv or hdr10p or bool(re.search(r"\bhdr", q)), "hdr10p": hdr10p,
            "remux": "remux" in q or "remux" in hint_name.lower(), "gb": _gb(body), "provider": "PeLis",
            "esp": not lat and ("español" in audio or "castellano" in audio), "lat": lat, "multi": len(langs) > 1,
            "label": (title + (" · " + file_ if file_ else ""))[:120], "filename": hint_name.strip(),
            "au": flix_src_codec.audio(au_text), "ch": flix_src_codec.channels(au_text)}


def pelis_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/pelis.json" % xbmc.getSkinDir())


def _clean_base(url):
    url = (url or "").strip()
    if url.endswith("/manifest.json"):
        url = url[:-len("/manifest.json")]
    return url.rstrip("/")


def load_pelis_url(path=None):
    """dirección de PeLis de este aparato, o "" si no hay (o el fichero no vale)"""
    try:
        with open(path or pelis_path(), encoding="utf-8") as f:
            url = _clean_base((json.load(f) or {}).get("base"))
    except Exception:  # noqa: BLE001  (sin fichero, roto o sin Kodi: sin PeLis)
        return ""
    return url if url.startswith("https://") else ""


def save_pelis_url(url, path=None):
    """guarda la dirección (admite la del manifest.json); permisos 600 como la clave de AllDebrid. ValueError si no
    parece una dirección https (sin decir cuál: no se escribe en ningún sitio)"""
    url = _clean_base(url)
    if not re.match(r"https://[^/\s]+/\S+$", url):
        raise ValueError("dirección de PeLis no válida")
    path = path or pelis_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"base": url}, f)
    os.replace(tmp, path)


def forget_pelis_url(path=None):
    """desvincular PeLis: borra la dirección de ESTE aparato y nada más"""
    try:
        os.remove(path or pelis_path())
    except OSError:
        pass


_LK_LANGS = {"esp", "eng", "lat", "cat", "glg", "eus", "fra", "fre", "ita", "ger", "deu", "jpn", "por", "kor", "chi",
             "zho", "rus", "vos", "spa"}


def parse_linkanol(stream):
    """un stream de Linkañol con la misma forma que parse_pelis (url = enlace de 1fichier SIN abrir, unlock=True). None si
    no trae enlace. Idiomas: los códigos de su nombre («4K eng,esp»); «esp» = castellano; «lat» sin «esp» = latino"""
    raw = stream.get("url") or stream.get("externalUrl") or ""
    if not isinstance(raw, str):
        return None
    q = urllib.parse.parse_qs(urllib.parse.urlsplit(raw).query)
    link = (q.get("link") or [""])[0]
    if not link.startswith(("https://", "http://")):
        return None
    name = (stream.get("name") or "").strip()
    audio = (stream.get("description") or "").strip()
    toks = [t for t in re.split(r"[\s,]+", name.lower()) if t]
    langs = [t for t in toks if t in _LK_LANGS]
    n = name.lower()
    dv = bool(re.search(r"\bdv\b", n))
    hdr10p = "hdr10+" in n
    res = (2160 if (re.search(r"\b4k\b", n) or dv or "hdr" in n) else 1080 if "1080" in n else 720 if re.search(r"\bhd\b|720", n)
           else 480)
    esp = "esp" in langs or "spa" in langs
    lat = "lat" in langs and not esp
    return {"hash": "linkanol:" + hashlib.sha1(link.encode()).hexdigest(), "origin": "linkanol", "url": link,
            "unlock": True, "ready": True, "direct": True, "res": res, "dv": dv, "hdr": dv or hdr10p or "hdr" in n,
            "hdr10p": hdr10p, "remux": "(r)" in n, "gb": 0, "provider": "Linkañol", "esp": esp, "lat": lat,
            "multi": len(langs) > 1, "label": ("%s · %s" % (name, audio))[:120], "filename": "", "esp_name": esp,
            "lat_name": lat, "au": flix_src_codec.audio(name + " " + audio),
            "ch": flix_src_codec.channels(name + " " + audio)}


def merge(lists):
    out, by = [], {}
    for lst in lists:
        for c in lst:
            if not c:
                continue
            if c["hash"] in by:
                old = by[c["hash"]]
                esp = old["esp"] or c["esp"]
                lat_name = bool(old.get("lat_name") or c.get("lat_name"))
                esp_name = bool(old.get("esp_name") or c.get("esp_name"))
                if lat_name and not esp_name:
                    # un nombre dice latino y ninguno dice castellano (16-nov, La Odisea «Dual-Lat» de Cinecalidad
                    # que Peerflix da con solo la bandera 🇪🇸): latino, como lo tratará el reproductor
                    esp, old["lat"] = False, True
                else:
                    old["lat"] = False if esp else (old["lat"] or c["lat"])     # esp y lat nunca juntos
                old["esp"], old["lat_name"], old["esp_name"] = esp, lat_name, esp_name
                old["multi"] = old["multi"] or c["multi"]
                old["filename"] = old.get("filename") or c.get("filename") or ""
                continue
            by[c["hash"]] = dict(c)     # copia: no tocar los dicts de quien llama
            out.append(by[c["hash"]])
    return out


def stream_path(kind, imdb, season, episode):
    if kind == "movie":
        return "/stream/movie/%s.json" % imdb
    return "/stream/series/%s:%d:%d.json" % (imdb, season, episode)


def _get(url, opener=None):
    """JSON de una dirección. Se pide comprimido (16-nov, bloque 2: una lista de versiones de Torrentio pesa ~100 KB
    y comprimida ~34; las filas del Inicio comprueban cientos de títulos por detrás). Si el servidor no comprime,
    llega tal cual: se mira por los dos primeros bytes, no por la cabecera"""
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip"})
    with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
        raw = r.read()
    if raw[:2] == b"\x1f\x8b":
        import gzip
        raw = gzip.decompress(raw)
    return json.loads(raw.decode())


_HOST_MAX = 2       # peticiones a la vez a Torrentio en este proceso (contesta 429 si se le satura)
_HOST_MAX_OTHER = 6     # a las demás (19-nov, Shield: PeLis tarda 4-8 s y con 2 a la vez la página de 60 series de
                        # «Ver más» iba a 3-4 títulos cada 10 s; idea de Carlos del 18-nov: «solo Torrentio limitado»)
_host_sems, _host_lock = {}, threading.Lock()


def _sem(url):
    host = urllib.parse.urlsplit(url).netloc
    with _host_lock:
        if host not in _host_sems:
            _host_sems[host] = threading.BoundedSemaphore(
                _HOST_MAX if host == urllib.parse.urlsplit(TORRENTIO).netloc else _HOST_MAX_OTHER)
        return _host_sems[host]


def _get_limited(url, opener=None, deadline=None, sleep=time.sleep):
    """_get con tope de _HOST_MAX peticiones simultáneas por servidor; ante un 429, UN reintento tras esperar
    Retry-After (máx. 2 s; 1 s si no viene) y solo si queda tiempo antes de `deadline` (time.monotonic)"""
    for intento in (0, 1):
        try:
            with _sem(url):
                return _get(url, opener)
        except urllib.error.HTTPError as e:
            if e.code != 429 or intento:
                raise
            try:
                espera = min(2.0, max(0.0, float((e.headers or {}).get("Retry-After"))))
            except (TypeError, ValueError):
                espera = 1.0
            if deadline is not None and time.monotonic() + espera >= deadline:
                raise
            sleep(espera)


def fetch(kind, imdb, season=None, episode=None, opener=None, status=None, sleep=time.sleep, pelis=None,
          pelis_wait=None, enough=None):
    """las fuentes a la vez (Torrentio, Peerflix y, si este aparato tiene su dirección, PeLis); la que falle o tarde
    más de TIMEOUT no cuenta. pelis: dirección de PeLis (None = la guardada; "" = sin PeLis).
    status (dict opcional; «pelis» solo si se le preguntó): status[fuente] = True si contestó con JSON (aunque sin streams), False si falló o no llegó.
    Un 404 cuenta como contestado sin streams (Peerflix lo da cuando no tiene el título).
    Si status tiene un atributo `limited` (lista), recibe el nombre de las fuentes que siguieron dando 429.
    pelis_wait (s): cuánto más se espera a PeLis una vez han contestado las demás (17-nov: PeLis tarda 4-8 s con lo
    que no tiene guardado y las otras menos de 1; el buscador no puede esperar eso por cada título). Si no llega a
    tiempo, cuenta como no contestada. Solo si las demás ya trajeron castellano (o lo que diga enough(versiones de las
    demás) → bool: al reproducir, castellano en la primera calidad); si no, se la espera hasta el plazo de siempre.
    None: hasta el plazo de siempre"""
    limited = getattr(status, "limited", None)
    path = stream_path(kind, imdb, season, episode)
    got, answered = {}, set()
    end = time.monotonic() + TIMEOUT + 1     # un único plazo para todas las fuentes
    pelis = load_pelis_url() if pelis is None else _clean_base(pelis)
    required = SOURCES + ((("pelis", pelis),) if pelis else ())
    sources = required + OPTIONAL

    def quiet(e):
        """el error sin la dirección de PeLis (lleva el id del usuario)"""
        return str(e).replace(pelis, "<pelis>") if pelis else str(e)

    def one(name, base):
        try:
            streams = _get_limited(base + path, opener, end, sleep).get("streams") or []
        except urllib.error.HTTPError as e:
            got[name] = []
            if e.code == 404:       # «no tengo nada de esto»: contestó, sin streams
                answered.add(name)
                return
            if e.code == 429 and limited is not None:
                limited.append(name)
            _log("%s no responde: %s" % (name, quiet(e)))
            return
        except Exception as e:  # noqa: BLE001
            got[name] = []
            _log("%s no responde: %s" % (name, quiet(e)))
            return
        parsed = []
        for s in streams:
            try:
                parsed.append(parse_pelis(s) if name == "pelis" else parse_linkanol(s) if name == "linkanol"
                              else parse(s, name))
            except Exception:  # noqa: BLE001
                continue    # un stream malo no tira la fuente entera
        got[name] = parsed
        answered.add(name)
    threads = [threading.Thread(target=one, args=s, daemon=True) for s in sources]
    for th in threads:
        th.start()
    slow = [th for (n, _), th in zip(sources, threads) if n == "pelis"] if pelis_wait is not None else []
    for th in threads:
        if th not in slow:
            th.join(max(0, end - time.monotonic()))
    # a PeLis solo se la deja de esperar si las demás ya trajeron castellano: así lo que solo tiene PeLis (o lo que en
    # PeLis está en castellano y en las demás solo en versión original) no se pierde ni sale como «VO» (Carlos, 17-nov)
    others = [c for n, lst in list(got.items()) if n != "pelis" for c in lst if c]
    esp_ya = bool(slow) and (enough(others) if enough else any(c.get("esp") for c in others))
    for th in slow:
        limit = min(end, time.monotonic() + pelis_wait) if esp_ya else end
        th.join(max(0, limit - time.monotonic()))
    # foto de lo llegado: lo que llegue tarde (PeLis cortada) ya no cuenta (los hilos siguen escribiendo en got)
    got_now, answered_now = dict(got), set(answered)
    if status is not None:
        for n, _ in required:
            status[n] = n in answered_now
        for n, _ in OPTIONAL:       # opcional: solo si contestó (si no, no vuelve desconocido nada)
            if n in answered_now:
                status[n] = True
    return merge([got_now.get(n) or [] for n, _ in sources])


def _log(msg):
    try:
        import xbmc
        xbmc.log("[flix_src_list] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def _cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/src_imdb.json" % xbmc.getSkinDir())


def imdb_of(kind, tmdb, opener=None, cache_path=None, raise_errors=False):
    """id de IMDb desde TMDB (/external_ids), guardado para siempre en disco. None si TMDB no lo tiene (o no conoce el
    título: 404) y también, por defecto, si no se pudo preguntar. raise_errors=True: sin red (o respuesta rota) lanza la
    excepción, para quien necesite distinguir «no tiene» de «no se sabe» (Ker0n3, avail.check)"""
    from flix_common import TMDB_KEY
    path = cache_path or _cache_path()
    key = "%s/%s" % (kind, tmdb)
    try:
        with open(path, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    if not isinstance(cache, dict):     # fichero de otra forma (estropeado): como si no hubiera
        cache = {}
    if cache.get(key):
        return cache[key]
    try:
        d = _get("https://api.themoviedb.org/3/%s/%s/external_ids?api_key=%s" % (kind, tmdb, TMDB_KEY), opener)
    except Exception as e:  # noqa: BLE001
        _log("TMDB sin IMDb para %s: %s" % (key, e))
        if raise_errors and getattr(e, "code", None) != 404:     # 404: TMDB contestó que no conoce el título
            raise
        return None
    imdb = d.get("imdb_id") or None
    if imdb:
        cache[key] = imdb
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            from flix_common import atomic_write
            atomic_write(path, json.dumps(cache))
        except OSError:
            pass
    return imdb
