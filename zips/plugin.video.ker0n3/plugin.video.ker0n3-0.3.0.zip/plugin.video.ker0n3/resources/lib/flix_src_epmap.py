"""Numeración de capítulos TMDB → IMDb para pedir versiones (17-nov, Naruto).

Las versiones se piden a Torrentio y Peerflix por id de IMDb con temporada y capítulo, y la skin usa los de TMDB. En
casi todas las series coinciden; en el anime largo no: Naruto son 220 capítulos en los dos, pero TMDB los reparte
52/52/54/62 e IMDb 35/48/48/48/41. El «1x45» de TMDB para IMDb no existe (su temporada 1 acaba en el 35) y Torrentio
devolvía 1 torrent. Es el capítulo 45 de la serie: para IMDb el «2x10» (65 torrents).

Cómo: capítulos por temporada en TMDB (/tv/<id>) y en IMDb (Cinemeta, el catálogo público de Stremio: los mismos
números que usa Torrentio). Si coinciden, nada. Si no, número absoluto (los capítulos de las temporadas anteriores
más este) y se busca en el reparto de IMDb. Solo si los totales casi coinciden (como mucho MAX_DIFF de diferencia:
series en emisión): si no, los dos repartos no son la misma lista y mejor no traducir.
Guardado un día por serie en addon_data/<skin>/epmap.json. Un fallo de red: sin traducción, como antes."""
import json
import os
import time

TTL = 86400
MAX_DIFF = 3
CINEMETA = "https://v3-cinemeta.strem.io/meta/series/%s.json"


def counts_tmdb(d):
    """{temporada: capítulos} (sin especiales) de la respuesta de /tv/<id> de TMDB"""
    out = {}
    for s in (d or {}).get("seasons") or []:
        try:
            n, c = int(s.get("season_number")), int(s.get("episode_count") or 0)
        except (TypeError, ValueError):
            continue
        if n >= 1 and c > 0:
            out[n] = c
    return out


def counts_imdb(d):
    """{temporada: capítulos} (sin especiales) de la ficha de Cinemeta"""
    out = {}
    for v in ((d or {}).get("meta") or {}).get("videos") or []:
        try:
            s, e = int(v.get("season")), int(v.get("episode"))
        except (TypeError, ValueError):
            continue
        if s >= 1 and e >= 1:
            out[s] = max(out.get(s, 0), e)
    return out


def translate(season, episode, tmdb, imdb):
    """(temporada, capítulo, absoluto) en IMDb, o None si no hace falta o no se fía"""
    if not tmdb or not imdb or season is None or episode is None or season < 1:
        return None
    if tmdb == imdb:
        return None
    if abs(sum(tmdb.values()) - sum(imdb.values())) > MAX_DIFF:
        return None
    if season not in tmdb:
        return None
    if episode > tmdb[season]:
        # TMDB numera algunos animes de forma absoluta dentro de cada temporada (Naruto: la 2 va del 53 al 104; el
        # último emitido es el «4x220»): el número ya es el absoluto
        if episode > sum(tmdb.values()):
            return None
        absolute = episode
    else:
        absolute = sum(c for s, c in tmdb.items() if s < season) + episode
    left = absolute
    for s in sorted(imdb):
        if left <= imdb[s]:
            return (s, left, absolute) if (s, left) != (season, episode) else None
        left -= imdb[s]
    return None


def _path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/epmap.json" % xbmc.getSkinDir())


def _get_json(url, opener=None):
    import flix_src_list
    return flix_src_list._get(url, opener)


def counts(tmdb_id, imdb_id, opener=None, path=None, now=time.time):
    """(reparto TMDB, reparto IMDb) de la serie, guardados un día. ({}, {}) si no se pudo preguntar"""
    from flix_common import TMDB_KEY
    path = path or _path()
    key = "%s/%s" % (tmdb_id, imdb_id)
    try:
        with open(path, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    if not isinstance(cache, dict):
        cache = {}
    hit = cache.get(key)
    if isinstance(hit, list) and len(hit) == 3 and now() - hit[0] < TTL:
        return ({int(k): v for k, v in hit[1].items()}, {int(k): v for k, v in hit[2].items()})
    try:
        t = counts_tmdb(_get_json("https://api.themoviedb.org/3/tv/%s?api_key=%s" % (tmdb_id, TMDB_KEY), opener))
        i = counts_imdb(_get_json(CINEMETA % imdb_id, opener))
    except Exception:  # noqa: BLE001  (sin red: sin traducción)
        return {}, {}
    cache = {k: v for k, v in cache.items() if isinstance(v, list) and v and now() - v[0] < TTL}
    cache[key] = [now(), t, i]
    try:
        from flix_common import atomic_write
        os.makedirs(os.path.dirname(path), exist_ok=True)
        atomic_write(path, json.dumps(cache))
    except Exception:  # noqa: BLE001
        pass
    return t, i


def alias(tmdb_id, imdb_id, season, episode, opener=None, path=None, now=time.time):
    """(temporada, capítulo, absoluto) de IMDb para pedir versiones, o None (se pide con los de TMDB)"""
    if season is None or episode is None:
        return None
    t, i = counts(tmdb_id, imdb_id, opener=opener, path=path, now=now)
    return translate(int(season), int(episode), t, i)
