"""Ker0n3 ⇄ Trakt (16-nov). Diseño: docs/superpowers/specs/2026-11-16-trakt-propio-design.md.

Lo propio de Trakt para sync.py (la cola, la base y las reglas de mezcla son las mismas que con Simkl): con qué
petición se sube cada entrada de la cola y qué hay que pedir al bajar según sync/last_activities.
Con Trakt el anime SÍ se sincroniza: numera por serie, temporada y capítulo de TMDB, sin «entradas enteras»."""
from ker0n3 import sync

MIN_PROGRESS = 1.0      # scrobble/stop con menos del 1 % da 422: una pausa siempre sube con 1 como poco


def ids_path():
    return sync._data("trakt_ids.json")


def episode_ref(api, it, path=None):
    """id de Trakt del capítulo de una entrada de la cola. El de la serie se guarda (una búsqueda por serie)"""
    path = path or ids_path()
    cache = sync._load(path, {})
    key = str(it["tmdb"])
    show = cache.get(key)
    if not show:
        show = api.show_id(it["tmdb"])
        if not show:
            raise api.Error("otro", "Trakt no tiene la serie %s" % it["tmdb"])
        cache[key] = show
        sync._save(path, cache)
    ep = api.episode_id(show, it["season"], it["episode"])
    if not ep:
        raise api.Error("otro", "Trakt no tiene %s T%s E%s" % (it["tmdb"], it["season"], it["episode"]))
    return ep


def request_of(it, episode=None):
    """(ruta, cuerpo) de Trakt para una entrada de la cola. episode(): id de Trakt del capítulo (solo para pausas de
    capítulo). Visto y no visto llevan la misma forma que con Simkl (sync.body_of)"""
    ids = {"ids": {"tmdb": it["tmdb"]}}
    if it["op"] == "pause":
        body = {"progress": max(float(it.get("progress") or 0), MIN_PROGRESS)}
        if it["kind"] == "movie":
            body["movie"] = ids
        else:
            body["episode"] = {"ids": {"trakt": episode()}}
        return "/scrobble/stop", body       # entre 1 y 79 % Trakt lo guarda como pausa (sync/playback)
    if it["op"] in sync.FAV:
        group = "movies" if it["kind"] == "movie" else "shows"
        return ("/sync/watchlist" if it["op"] == "fav_add" else "/sync/watchlist/remove"), {group: [ids]}
    return sync.body_of(it)


def send(api, it, path=None, queue=None):
    """sube una entrada de la cola. «unpause» (quitar pausas, 16-nov): DELETE sync/playback/<id>, con los ids de UNA
    lectura de sync/playback para todas las de la cola (sync.send_unpause); queue: la cola donde guardarlos"""
    if it["op"] == sync.UNPAUSE:
        return sync.send_unpause(api, it, queue or sync.queue_path())
    api.post(*request_of(it, lambda: episode_ref(api, it, path)))


# ---------- bajar ----------
def stamps(acts):
    """las fechas de last_activities que mueven algo aquí"""
    def at(sec, key):
        return (acts.get(sec) or {}).get(key) or ""
    return {"movies": at("movies", "watched_at"), "episodes": at("episodes", "watched_at"),
            "movie_pauses": at("movies", "paused_at"), "episode_pauses": at("episodes", "paused_at"),
            "watchlist": "|".join((at("watchlist", "updated_at"), at("movies", "watchlisted_at"),
                                   at("shows", "watchlisted_at"))).strip("|")}


def read_movies(data):
    """sync/watched/movies → [(tmdb, lastPlayed, 0)]"""
    out = []
    for it in data or []:
        t = sync.tmdb_of(it.get("movie"))
        if t and it.get("last_watched_at"):
            out.append((t, sync.p3date(it["last_watched_at"]), 0))
    return out


def read_shows(data):
    """sync/watched/shows?extended=progress (los capítulos vienen dentro: seasons[].episodes[]) → (capítulos vistos
    [(tmdb, temporada, capítulo, lastPlayed)], series [(tmdb, emitidos, completa, 0)]). Sin especiales. La serie solo
    sale si Trakt dice cuántos capítulos lleva emitidos. Con reset_at (la está viendo otra vez) solo cuenta lo visto
    desde esa fecha, como pide Trakt"""
    eps, shows = [], []
    for it in data or []:
        show = it.get("show") or {}
        t = sync.tmdb_of(show)
        if not t:
            continue
        reset = sync.p3date(it["reset_at"]) if it.get("reset_at") else ""
        seen = 0
        for season in it.get("seasons") or []:
            n = season.get("number")
            if not isinstance(n, int) or n < 1:
                continue
            for e in season.get("episodes") or []:
                if not e.get("last_watched_at") or not isinstance(e.get("number"), int) or e.get("completed") is False:
                    continue
                last = sync.p3date(e["last_watched_at"])
                if reset and last < reset:
                    continue
                eps.append((t, n, e["number"], last))
                seen += 1
        try:
            aired = int(show.get("aired_episodes") or 0)
        except (TypeError, ValueError):
            aired = 0
        if aired > 0:
            shows.append((t, aired, int(seen >= aired), 0))
    return eps, shows


def read_progress(tmdb, data, aired=0):
    """shows/<id>/progress/watched de una serie → (capítulos vistos [(tmdb, temporada, capítulo, lastPlayed)], serie
    [(tmdb, emitidos, completa, 0)] o [] si no se sabe cuántos lleva). Sin especiales. Con reset_at (la está viendo
    otra vez) solo cuenta lo visto desde esa fecha, como pide Trakt"""
    if not data or not isinstance(data, dict):
        return [], []
    reset = sync.p3date(data.get("reset_at")) if data.get("reset_at") else ""
    eps = []
    for season in data.get("seasons") or []:
        n = season.get("number")
        if not isinstance(n, int) or n < 1:
            continue
        for e in season.get("episodes") or []:
            if not (e.get("completed") and e.get("last_watched_at") and isinstance(e.get("number"), int)):
                continue
            last = sync.p3date(e["last_watched_at"])
            if not reset or last >= reset:
                eps.append((tmdb, n, e["number"], last))
    try:
        aired = int(aired or data.get("aired") or 0)
    except (TypeError, ValueError):
        aired = 0
    return eps, ([(tmdb, aired, int(len(eps) >= aired), 0)] if aired > 0 else [])


def read_all_shows(items, stamps_prev, api):
    """lo visto de las series de sync/watched/shows: (capítulos, series, {id de Trakt: last_updated_at} de las leídas
    por la vía de reserva, ¿completo?). Lo normal: los capítulos vienen dentro (extended=progress) y no se pide nada
    más. Reserva, por si una serie llegara sin «seasons»: su progreso con una petición (shows/<id>/progress/watched),
    solo si su last_updated_at cambió; sin red, sin cupo o sin vínculo a media lista se devuelve lo hecho e
    «incompleto» (la siguiente bajada sigue por donde iba), y una serie que Trakt no da (404…) se salta"""
    eps, shows, done, complete = [], [], {}, True
    for it in items or []:
        show = it.get("show") or {}
        tmdb, trakt_id = sync.tmdb_of(show), (show.get("ids") or {}).get("trakt")
        if not tmdb:
            continue
        if "seasons" in it:
            e, s = read_shows([it])
            eps += e
            shows += s
            continue
        if not trakt_id:
            continue
        key, stamp = str(trakt_id), it.get("last_updated_at") or it.get("last_watched_at") or ""
        if stamp and stamps_prev.get(key) == stamp:
            done[key] = stamp
            continue
        if not complete:            # tras un corte no se pide más, pero las que no cambiaron siguen apuntadas
            continue
        try:
            e, s = read_progress(tmdb, api.show_progress(trakt_id), show.get("aired_episodes"))
        except api.Error as err:
            if err.kind in ("sin_red", "sin_cupo", "sin_vinculo"):
                sync.log("bajada de Trakt a medias (%s): sigo en la próxima" % err.kind)
                complete = False
                continue
            sync.log("Trakt no da la serie %s: %s" % (tmdb, err))
            e, s = [], []
        eps += e
        shows += s
        done[key] = stamp
    return eps, shows, done, complete


def read_watchlist(data, inner):
    """ids de TMDB de sync/watchlist/<movies|shows>"""
    return {t for t in (sync.tmdb_of(it.get(inner)) for it in data or []) if t}


def plan_changes(acts, prev, api):
    """lo que hay que pedir según qué fechas de last_activities se movieron desde prev: (cambios para sync.write,
    estado nuevo). Primera vez (prev vacío): todo lo que tenga fecha. Trakt da las listas enteras"""
    now, was = stamps(acts), prev.get("acts") or {}
    if prev and "shows" not in prev:
        # estado de la primera versión (16-nov), que bajaba las series sin capítulos: se vuelven a pedir una vez
        was = dict(was, episodes="")
    fav_prev = prev.get("fav") or {}

    def moved(key):
        return bool(now[key]) and now[key] != was.get(key)

    ch = {"movies": [], "episodes": [], "shows": [], "movie_pauses": [], "episode_pauses": [],
          "fav_add": [], "fav_del": []}
    if moved("movies"):
        ch["movies"] = read_movies(api.watched("movies"))
    seen = dict(prev.get("shows") or {})
    if moved("episodes"):
        ch["episodes"], ch["shows"], seen, complete = read_all_shows(api.watched("shows"), seen, api)
        if not complete:
            now["episodes"] = was.get("episodes") or ""     # sin acabar: la próxima bajada vuelve a mirar las series
    if moved("movie_pauses") or moved("episode_pauses"):
        ch["movie_pauses"], ch["episode_pauses"] = sync.read_pauses(api.playback("movies"), api.playback("episodes"))
    fav = {"movies": list(fav_prev.get("movies") or []), "shows": list(fav_prev.get("shows") or [])}
    if moved("watchlist"):
        for content, inner in (("movies", "movie"), ("shows", "show")):
            now_ids, mine = read_watchlist(api.watchlist(content), inner), set(fav[content])
            ch["fav_add"] += [(t, content) for t in sorted(now_ids - mine)]
            ch["fav_del"] += [(t, content) for t in sorted(mine - now_ids)]
            fav[content] = sorted(now_ids)
    return ch, {"acts": now, "fav": fav, "shows": seen}
