"""Filas personales de Ker0n3 (sin Palantir, bloque 1; 15-nov): «Seguir viendo» (ruta seguir: películas y capítulos a
medias) y «Series en seguimiento» (ruta siguiendo), de la base de vistos de Ker0n3 (store). La skin las pide por
Files.GetDirectory para sus filas 5101 y 5102 con fuentes propias (flix_rows.k3_personal).

16-nov: estas filas NO se filtran con «Solo en castellano» ni por disponibilidad (lo que el usuario sigue o tiene a
medias no se esconde) y no comprueban nada; su rótulo de idioma sale de lo que haya guardado (avail.cached) y, si no
hay nada, no lleva rótulo (antes decía «[Esp]» sin saberlo: «Manhunt»)"""
import threading
import time

LIMIT = 20                  # elementos por fila (el Inicio enseña de 8 a 30)
WORKERS, BUDGET = 6, 10     # fichas de TMDB en paralelo y plazo (s): lo que no llegue a tiempo no sale esta vez


def _sheet(key):
    from ker0n3 import catalog
    kind, tmdb, season = key
    if kind == "movie":
        return catalog.movie(tmdb)
    d = catalog.show(tmdb)
    if season:
        d = dict(d, eps={e["n"]: e for e in catalog.episodes(tmdb, season)})
    return d


def sheets(keys, fetch=None, workers=WORKERS, timeout=BUDGET):
    """{clave: ficha} de las que se obtuvieron (en paralelo, con plazo; las que fallan no están)"""
    fetch = fetch or _sheet
    out, lock, queue = {}, threading.Lock(), list(dict.fromkeys(keys))

    def worker():
        while True:
            with lock:
                if not queue:
                    return
                key = queue.pop(0)
            try:
                d = fetch(key)
            except Exception:  # noqa: BLE001  (sin red y sin caché: ese no sale)
                continue
            if d:
                with lock:
                    out[key] = d
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(max(1, min(workers, len(queue))))]
    for th in threads:
        th.start()
    end = time.monotonic() + timeout
    for th in threads:
        th.join(max(0, end - time.monotonic()))
    with lock:
        return dict(out)


def next_episode(season, episode, pct, seasons):
    """(temporada, capítulo) que toca: el mismo si quedó a medias; si no, el siguiente según las temporadas
    estrenadas de TMDB; None si no hay (al día)"""
    if pct and pct > 0:
        return season, episode
    counts = {int(s["n"]): int(s.get("episodes") or 0) for s in seasons or [] if s.get("n")}
    if episode < counts.get(season, 0):
        return season, episode + 1
    later = sorted(n for n in counts if n > season and counts[n] > 0)
    return (later[0], 1) if later else None


def episode_item(d, tmdb, season, episode):
    import xbmcgui
    from ker0n3 import router
    ep = (d.get("eps") or {}).get(episode) or {}
    li = xbmcgui.ListItem(d.get("title") or "", path=router.url_play_episode(tmdb, season, episode))
    t = li.getVideoInfoTag()
    t.setMediaType("episode")
    t.setTitle(ep.get("title") or d.get("title") or "")
    t.setTvShowTitle(d.get("title") or "")
    t.setSeason(int(season))
    t.setEpisode(int(episode))
    if ep.get("plot") or d.get("plot"):
        t.setPlot(ep.get("plot") or d.get("plot"))
    if ep.get("duration") or d.get("duration"):
        t.setDuration(int(ep.get("duration") or d.get("duration")))
    t.setUniqueIDs({"tmdb": str(tmdb)}, "tmdb")
    li.setArt({k: v for k, v in (("thumb", ep.get("still") or d.get("fanart")), ("fanart", d.get("fanart")),
                                 ("poster", d.get("poster")), ("clearlogo", d.get("clearlogo"))) if v})
    li.setProperty("IsPlayable", "true")
    return li


def _resume(li, pct, total):
    if total and total > 0:
        li.getVideoInfoTag().setResumePoint(round(total * pct / 100.0, 3), float(total))


def resume(handle, db_path=None, now=None):
    """ruta seguir: películas a medias y el capítulo a medias de cada serie, por lo último visto"""
    import xbmcplugin
    from ker0n3 import avail, handlers, router, store
    rows = [("movie", r[0], r) for r in store.resume_movies(db_path, now=now)] + \
           [("tv", r[0], r) for r in store.resume_episodes(db_path, now=now)]
    rows.sort(key=lambda x: x[2][-1], reverse=True)
    rows = rows[:LIMIT]
    got = sheets([(k, t, r[1] if k == "tv" else None) for k, t, r in rows])
    n = 0
    for kind, tmdb, r in rows:
        if kind == "movie":
            d = got.get(("movie", tmdb, None))
            if not d:
                continue
            a = avail.cached("movie", tmdb)
            li = handlers.movie_item(d, (a or {}).get("q", ""), avail.has_esp(a))
            _resume(li, r[1], r[2] or d.get("duration") or 0)
            xbmcplugin.addDirectoryItem(handle, router.url_play_movie(tmdb), li, isFolder=False)
        else:
            d = got.get(("tv", tmdb, r[1]))
            if not d:
                continue
            li = episode_item(d, tmdb, r[1], r[2])
            _resume(li, r[3], r[4] or ((d.get("eps") or {}).get(r[2]) or {}).get("duration") or d.get("duration") or 0)
            xbmcplugin.addDirectoryItem(handle, router.url_play_episode(tmdb, r[1], r[2]), li, isFolder=False)
        n += 1
    handlers.log("seguir: %d de %d" % (n, len(rows)))
    handlers._end(handle, "videos")


def follow(handle, db_path=None):
    """ruta siguiendo: series con algo visto, la última tocada primero, con el capítulo que toca (propiedad k3_next)"""
    import xbmcplugin
    from ker0n3 import avail, handlers, router, series, store
    rows = store.followed(db_path)[:LIMIT]
    got = sheets([("tv", r[0], None) for r in rows])
    n = 0
    for tmdb, season, episode, pct in rows:
        d = got.get(("tv", tmdb, None))
        if not d:
            continue
        a = avail.cached("tv", tmdb)
        li = handlers.show_item(d, (a or {}).get("q", ""), avail.has_esp(a))
        # el capítulo que toca con la misma regla que la ficha (series.state): solo si ya se ha emitido; al día,
        # k3_upto (el último visto)
        try:
            st = series.of(tmdb, show=d, db_path=db_path)
        except Exception:  # noqa: BLE001
            st = {}
        if st.get("next"):
            li.setProperty("k3_next", series.label(st["next"]))
        elif st.get("upto"):
            li.setProperty("k3_upto", series.label(st["upto"]))
        xbmcplugin.addDirectoryItem(handle, router.url_show(tmdb), li, isFolder=True)
        n += 1
    handlers.log("siguiendo: %d de %d" % (n, len(rows)))
    handlers._end(handle, "tvshows")


def favorites(handle, tipo, db_path=None):
    """ruta favoritos/<peliculas|series>: los favoritos de la base, lo último añadido primero. Como las otras filas
    personales: lo que el usuario guardó no se esconde por disponibilidad ni se comprueba nada"""
    import xbmcplugin
    from ker0n3 import avail, handlers, router, store
    kind = "movie" if tipo == "peliculas" else "tv"
    ids = store.favorites(kind, db_path)[:LIMIT]
    got = sheets([(kind, t, None) for t in ids])
    n = 0
    for t in ids:
        d = got.get((kind, t, None))
        if not d:
            continue
        a = avail.cached(kind, t)
        if kind == "movie":
            xbmcplugin.addDirectoryItem(handle, router.url_play_movie(t),
                                        handlers.movie_item(d, (a or {}).get("q", ""), avail.has_esp(a)), isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, router.url_show(t),
                                        handlers.show_item(d, (a or {}).get("q", ""), avail.has_esp(a)), isFolder=True)
        n += 1
    handlers.log("favoritos %s: %d de %d" % (tipo, n, len(ids)))
    handlers._end(handle, "movies" if kind == "movie" else "tvshows")
