"""Cuentas → «Trakt» y «Simkl» (15-nov Simkl; 16-nov Trakt, el principal): vincular con un código que se escribe
en el móvil (trakt.tv/activate, simkl.com/pin), sincronizar ahora, elegir cuál sincroniza o desvincular. Lo abre la
skin con RunPlugin (proceso del addon, no el hilo de la interfaz). El acceso se guarda en addon_data de Ker0n3
(trakt.py, simkl.py), nunca en la skin: en Skin.String solo va el nombre de la cuenta. Sincroniza el servicio, con
el que esté en uso (syncsvc). Diseño de Trakt: docs/superpowers/specs/2026-11-16-trakt-propio-design.md"""
import os
import re
import time

HEADING = "Simkl"
USER = "k3_simkl_user"          # Skin.String con el nombre de la cuenta de Simkl (Ajustes: «Ahora»)
TRAKT_USER = "k3_trakt_user"    # lo mismo, de Trakt
SYNC_NOW = "k3_sync_now"        # Window(10000): el servicio baja en cuanto puede (= service.SYNC_NOW)
SERVICES = {"simkl": {"heading": HEADING, "user": USER, "url": "simkl.com/pin"},
            "trakt": {"heading": "Trakt", "user": TRAKT_USER, "url": "trakt.tv/activate"}}
# aviso que Trakt pide enseñar tal cual (API Use Policy): en la ventana del código y en la ayuda de «Cuentas»
TRAKT_NOTICE = "Ker0n3 Media uses Trakt but is not endorsed or certified by Trakt."
SYNC, USE, CHECK, UNLINK = "Sincronizar ahora", "Usar para sincronizar", "Comprobar", "Desvincular"


def log(msg):
    try:
        import xbmc
        xbmc.log("[ker0n3.link] %s" % msg, xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


def _name(api):
    return getattr(api, "NAME", "simkl")


def _error(api):
    return getattr(api, "Error", None) or api.SimklError


def link(dlg, api, now=time.time, sleep=time.sleep):
    """muestra el código y espera a que se escriba en la web del servicio. Nombre de la cuenta, o None (cancelado,
    caducado o denegado)"""
    svc = SERVICES[_name(api)]
    d = api.device_code()
    wait, end = int(d.get("interval") or 5), now() + min(int(d.get("expires_in") or 900), 900)
    url = (d.get("verification_uri") or d.get("verification_url") or svc["url"]).replace("https://", "")
    text = "Entra en [B]%s[/B] desde el móvil o el ordenador y escribe:[CR][CR][B]%s[/B]" % (url, d["user_code"])
    if _name(api) == "trakt":
        text += "[CR][CR][COLOR gray]%s[/COLOR]" % TRAKT_NOTICE
    dlg.create(svc["heading"], text)
    try:
        while now() < end:
            sleep(wait)
            dlg.update(int(100 * max(0, end - now()) / 900))
            if dlg.iscanceled():
                return None
            r = api.poll_token(d["device_code"])
            if r == "slow_down":
                wait += 5
            elif r in ("expired", "denied"):
                return None
            elif isinstance(r, dict):
                api.save_token(r)
                return api.user_name() or "tu cuenta"
        return None
    finally:
        dlg.close()


def unlink(api, files, run):
    """olvida el acceso y borra de este aparato los ficheros que se le pasan (estado y, si no queda otro servicio,
    la cola). La base se queda: lo visto sigue aquí. Si el servicio lo admite, antes le dice que el acceso ya no
    vale (que la aplicación no quede conectada en la cuenta)"""
    svc = SERVICES[_name(api)]
    revoke = getattr(api, "revoke", None)
    if revoke:
        try:
            revoke()
        except Exception as e:  # noqa: BLE001
            log("sin revocar: %s" % type(e).__name__)
    api.forget()
    for p in files:
        try:
            os.remove(p)
        except OSError:
            pass
    run("Skin.Reset(%s)" % svc["user"])
    log("%s desvinculado" % svc["heading"])


def safe_name(user):
    """el nombre sin lo que rompe un builtin (comas y paréntesis)"""
    return " ".join(re.sub(r"[,()]", " ", user or "").split()) or "tu cuenta"


def options(name, active):
    """lo que ofrece el menú de un servicio vinculado: si sincroniza otro, usar este en su lugar"""
    if active and active != name:
        return [USE, UNLINK]
    return [SYNC] + ([CHECK] if name == "trakt" else []) + [UNLINK]


def check(api, dialog, run):
    """Trakt → «Comprobar»: renueva el acceso (lo que pasará sola cada semana) y lee la cuenta"""
    svc = SERVICES[_name(api)]
    try:
        api.access(force=True)
        user = api.user_name() or "tu cuenta"
    except _error(api) as e:
        log("comprobar %s: %s" % (svc["heading"], e.kind))
        if not api.linked():
            run("Skin.Reset(%s)" % svc["user"])
            dialog.ok(svc["heading"], "%s no ha aceptado renovar el acceso. Hay que vincular otra vez."
                      % svc["heading"])
        else:
            dialog.ok(svc["heading"], "No he podido hablar con %s. Prueba otra vez en un momento." % svc["heading"])
        return False
    run("Skin.SetString(%s,%s)" % (svc["user"], safe_name(user)))
    dialog.ok(svc["heading"], "Cuenta: %s[CR]Acceso renovado." % user)
    return True


def menu(handle=-1, api=None, home=None, dialog=None, run=None, progress=None, sleep=time.sleep, service="simkl",
         svcs=None):
    """service: «simkl» o «trakt». svcs: syncsvc (para las pruebas)"""
    import xbmc
    import xbmcgui
    from ker0n3 import sync
    if svcs is None:
        from ker0n3 import syncsvc as svcs
    if api is None:
        api = svcs.module(service)
    name = _name(api)
    svc = SERVICES[name]
    heading = svc["heading"]
    home = home or xbmcgui.Window(10000)
    dialog = dialog or xbmcgui.Dialog()
    run = run or xbmc.executebuiltin
    if getattr(api, "stale", None) and api.stale():
        # acceso guardado con otra aplicación de Trakt (cambió el Client ID): no vale ni se puede renovar
        api.forget()
        run("Skin.Reset(%s)" % svc["user"])
        dialog.ok(heading, "La aplicación de %s ha cambiado: hay que vincular otra vez." % heading)
    if api.linked():
        user = xbmc.getInfoLabel("Skin.String(%s)" % svc["user"]) or "tu cuenta"
        active = svcs.active()
        opts = options(name, active)
        pick = dialog.select("%s: %s%s" % (heading, user, " (en pausa)" if USE in opts else ""), opts)
        what = opts[pick] if 0 <= pick < len(opts) else None
        if what == SYNC:
            home.setProperty(SYNC_NOW, "1")
            dialog.notification(heading, "Sincronizo en un momento", time=3000)
        elif what == USE:
            svcs.set_active(name)
            home.setProperty(SYNC_NOW, "1")
            log("ahora sincroniza %s" % heading)
            dialog.notification(heading, "Ahora sincroniza %s" % heading, time=3000)
        elif what == CHECK:
            check(api, dialog, run)
        elif what == UNLINK and dialog.yesno(heading, "¿Desvincular %s en este aparato?[CR]Lo visto se queda en el "
                                                      "aparato y en tu cuenta de %s." % (heading, heading)):
            other = active and active != name
            # la cola es de lo que falta por subir: si sigue sincronizando el otro servicio, es suya
            unlink(api, (sync.state_path(name),) + (() if other else (sync.queue_path(),)), run)
            dialog.notification(heading, "Desvinculado", time=3000)
        return
    try:
        user = link(progress or xbmcgui.DialogProgress(), api, sleep=sleep)
    except _error(api) as e:
        log("no vinculo %s: %s %s" % (heading, e.kind, getattr(e, "code", "")))
        if getattr(e, "code", 0) == 403:
            dialog.ok(heading, "%s no deja entrar con esta aplicación. Si la cuenta no es la del dueño de la "
                               "aplicación, tiene que estar invitada en ella." % heading)
        else:
            dialog.ok(heading, "No he podido hablar con %s. Prueba otra vez en un momento." % heading)
        return
    if not user:
        return
    run("Skin.SetString(%s,%s)" % (svc["user"], safe_name(user)))
    svcs.set_active(name)       # el recién vinculado es el que sincroniza
    home.setProperty(SYNC_NOW, "1")
    log("%s vinculado" % heading)
    dialog.notification(heading, "Vinculado: %s" % user, time=4000)
