"""Numeración de capítulos TMDB → IMDb para pedir versiones (17-nov, Naruto).

Las versiones se piden a Torrentio y Peerflix por id de IMDb con temporada y capítulo, y la skin usa los de TMDB. En
casi todas las series coinciden; en el anime largo no: Naruto son 220 capítulos en los dos, pero TMDB los reparte
52/52/54/62 e IMDb 35/48/48/48/41. El «1x45» de TMDB para IMDb no existe (su temporada 1 acaba en el 35) y Torrentio
devolvía 1 torrent. Es el capítulo 45 de la serie: para IMDb el «2x10» (65 torrents).

Cómo: capítulos por temporada en TMDB (/tv/<id>) y en IMDb (Cinemeta, el catálogo público de Stremio: los mismos
números que usa Torrentio). Si coinciden, nada. Si no, número absoluto (los capítulos de las temporadas anteriores
más este) y se busca en el reparto de IMDb. Solo si los totales casi coinciden (como mucho MAX_DIFF de diferencia:
series en emisión): si no, los dos repartos no son la misma lista y mejor no traducir.
Guardado un día por serie en addon_data/<skin>/epmap.json. Un fallo de red: sin traducción, como antes."""
import json
import os
import time

TTL = 86400
MAX_DIFF = 3
# la temporada de TMDB no está en esta ficha de IMDb (Bleach, 17-nov: TMDB 366 + 50 de «Thousand-Year Blood War»; IMDb
# tt0434665 son solo los 366, la otra parte es otra ficha): no se pide nada (antes se pedía su «2xN» y era OTRO capítulo)
FUERA = (0, 0, 0)
CINEMETA = "https://v3-cinemeta.strem.io/meta/series/%s.json"


def counts_tmdb(d):
    """{temporada: capítulos} (sin especiales) de la respuesta de /tv/<id> de TMDB"""
    out = {}
    for s in (d or {}).get("seasons") or []:
        try:
            n, c = int(s.get("season_number")), int(s.get("episode_count") or 0)
        except (TypeError, ValueError):
            continue
        if n >= 1 and c > 0:
            out[n] = c
    return out


def counts_imdb(d):
    """{temporada: capítulos} (sin especiales) de la ficha de Cinemeta"""
    out = {}
    for v in ((d or {}).get("meta") or {}).get("videos") or []:
        try:
            s, e = int(v.get("season")), int(v.get("episode"))
        except (TypeError, ValueError):
            continue
        if s >= 1 and e >= 1:
            out[s] = max(out.get(s, 0), e)
    return out


def translate(season, episode, tmdb, imdb):
    """(temporada, capítulo, absoluto) en IMDb, None si no hace falta o no se fía, o FUERA si esa temporada de TMDB no
    está en la ficha de IMDb (no hay que pedir nada)"""
    if not tmdb or not imdb or season is None or episode is None or season < 1:
        return None
    if tmdb == imdb:
        return None
    if season not in tmdb:
        return None
    total = sum(imdb.values())
    if abs(sum(tmdb.values()) - total) > MAX_DIFF:
        # ¿las primeras temporadas de TMDB son toda la ficha de IMDb? (Bleach: la 1 de TMDB = los 366 de IMDb; la 2 es
        # otra ficha en IMDb). Si sí, esas se traducen y las de después están FUERA; si no, no se fía
        acc, k = 0, None
        for n in sorted(tmdb):
            acc += tmdb[n]
            if abs(acc - total) <= MAX_DIFF:
                k = n
                break
            if acc > total + MAX_DIFF:
                break
        if k is None:
            return None
        if season > k:
            return FUERA
        tmdb = {n: c for n, c in tmdb.items() if n <= k}
    if episode > tmdb[season]:
        # TMDB numera algunos animes de forma absoluta dentro de cada temporada (Naruto: la 2 va del 53 al 104; el
        # último emitido es el «4x220»): el número ya es el absoluto
        if episode > sum(tmdb.values()):
            return None
        absolute = episode
    else:
        absolute = sum(c for s, c in tmdb.items() if s < season) + episode
    left = absolute
    for s in sorted(imdb):
        if left <= imdb[s]:
            return (s, left, absolute) if (s, left) != (season, episode) else None
        left -= imdb[s]
    return None


def _path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/epmap.json" % xbmc.getSkinDir())


def _get_json(url, opener=None):
    import flix_src_list
    return flix_src_list._get(url, opener)


def counts(tmdb_id, imdb_id, opener=None, path=None, now=time.time):
    """(reparto TMDB, reparto IMDb) de la serie, guardados un día. ({}, {}) si no se pudo preguntar"""
    from flix_common import TMDB_KEY
    path = path or _path()
    key = "%s/%s" % (tmdb_id, imdb_id)
    try:
        with open(path, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    if not isinstance(cache, dict):
        cache = {}
    hit = cache.get(key)
    if isinstance(hit, list) and len(hit) == 3 and now() - hit[0] < TTL:
        return ({int(k): v for k, v in hit[1].items()}, {int(k): v for k, v in hit[2].items()})
    try:
        t = counts_tmdb(_get_json("https://api.themoviedb.org/3/tv/%s?api_key=%s" % (tmdb_id, TMDB_KEY), opener))
        i = counts_imdb(_get_json(CINEMETA % imdb_id, opener))
    except Exception:  # noqa: BLE001  (sin red: sin traducción)
        return {}, {}
    cache = {k: v for k, v in cache.items() if isinstance(v, list) and v and now() - v[0] < TTL}
    cache[key] = [now(), t, i]
    try:
        from flix_common import atomic_write
        os.makedirs(os.path.dirname(path), exist_ok=True)
        atomic_write(path, json.dumps(cache))
    except Exception:  # noqa: BLE001
        pass
    return t, i


def alias(tmdb_id, imdb_id, season, episode, opener=None, path=None, now=time.time):
    """(temporada, capítulo, absoluto) de IMDb para pedir versiones, o None (se pide con los de TMDB)"""
    if season is None or episode is None:
        return None
    season, episode = int(season), int(episode)
    t, i = counts(tmdb_id, imdb_id, opener=opener, path=path, now=now)
    al = translate(season, episode, t, i)
    if not t or not i or t == i:
        return al
    # 18-nov: los repartos no cuadran (temporada única de 1.464 capítulos, partes en otra ficha, capítulos dobles
    # contados distinto, temporadas por año...): el capítulo se identifica por su FECHA de emisión, no por su número
    try:
        when = episode_date(tmdb_id, season, episode, opener=opener, path=path, now=now)
        if when:
            absolute = sum(c for n, c in t.items() if n < season) + episode
            hit = match_date(when, videos(imdb_id, opener=opener, path=path, now=now))
            if hit:
                return None if hit == (season, episode) else (hit[0], hit[1], absolute)
            # no está en la ficha de la serie: ¿es una parte con ficha propia en IMDb (Bleach 2x49, Kimi ni Todoke 3)?
            other = elsewhere(tmdb_id, imdb_id, season, episode, when, opener=opener, path=path, now=now)
            if other:
                return (other[1], other[2], episode, other[0])
    except Exception:  # noqa: BLE001  (sin red: lo de siempre)
        pass
    return al


# --- por fecha de emisión (18-nov) -------------------------------------------------------------------------------
DATE_SLACK = 1      # días de margen (Japón / EE. UU.: el mismo capítulo sale con un día de diferencia)
_GENERIC = ("season", "temporada", "series", "serie", "part", "parte", "specials", "especiales")
CINEMETA_SEARCH = "https://v3-cinemeta.strem.io/catalog/series/top/search=%s.json"


def _load(path):
    try:
        with open(path, encoding="utf-8") as f:
            cache = json.load(f)
        return cache if isinstance(cache, dict) else {}
    except (OSError, ValueError):
        return {}


def _cached(key, fetch, path=None, now=time.time):
    """fetch() guardado un día en epmap.json bajo key (lo que devuelva, si no es None)"""
    path = path or _path()
    cache = _load(path)
    hit = cache.get(key)
    if isinstance(hit, list) and len(hit) == 2 and now() - hit[0] < TTL:
        return hit[1]
    val = fetch()
    if val is None:
        return None
    cache = {k: v for k, v in cache.items() if isinstance(v, list) and v and now() - v[0] < TTL}
    cache[key] = [now(), val]
    try:
        from flix_common import atomic_write
        os.makedirs(os.path.dirname(path), exist_ok=True)
        atomic_write(path, json.dumps(cache))
    except Exception:  # noqa: BLE001
        pass
    return val


def videos_of(meta):
    """[[temporada, capítulo, 'AAAA-MM-DD'], …] (sin especiales) de la ficha de Cinemeta, en orden"""
    out = []
    for v in ((meta or {}).get("meta") or {}).get("videos") or []:
        try:
            s, e = int(v.get("season")), int(v.get("episode"))
        except (TypeError, ValueError):
            continue
        if s >= 1 and e >= 1:
            out.append([s, e, str(v.get("released") or "")[:10]])
    return sorted(out)


def videos(imdb_id, opener=None, path=None, now=time.time):
    return _cached("vid/%s" % imdb_id, lambda: videos_of(_get_json(CINEMETA % imdb_id, opener)) or None,
                   path=path, now=now) or []


def season_dates(tmdb_id, season, opener=None, path=None, now=time.time):
    """{capítulo: 'AAAA-MM-DD'} de una temporada de TMDB"""
    from flix_common import TMDB_KEY

    def fetch():
        d = _get_json("https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s" % (tmdb_id, season, TMDB_KEY), opener)
        if not isinstance(d, dict):
            return None
        return {str(x["episode_number"]): x.get("air_date") or "" for x in d.get("episodes") or []}
    return _cached("sea/%s/%s" % (tmdb_id, season), fetch, path=path, now=now) or {}


def episode_date(tmdb_id, season, episode, opener=None, path=None, now=time.time):
    """(fecha, puesto entre los de esa fecha) del capítulo en TMDB, o None. El puesto: varios capítulos el mismo día
    (temporada entera de golpe, capítulos dobles) se emparejan por orden"""
    dates = season_dates(tmdb_id, season, opener=opener, path=path, now=now)
    when = dates.get(str(episode))
    if not when:
        return None
    rank = sum(1 for k, v in dates.items() if v == when and int(k) < int(episode))
    return when, rank


def _shift(day, n):
    import datetime
    return (datetime.date.fromisoformat(day) + datetime.timedelta(days=n)).isoformat()


def match_date(when, vids):
    """(temporada, capítulo) de IMDb emitido ese día (el mismo puesto entre los de ese día; si IMDb tiene menos, el
    último). Primero el día exacto; si no, ±DATE_SLACK solo si hay uno. None si ninguno"""
    day, rank = when
    same = [(v[0], v[1]) for v in vids if v[2] == day]
    if same:
        return same[min(rank, len(same) - 1)]
    try:
        near = [(v[0], v[1]) for v in vids for n in range(1, DATE_SLACK + 1)
                if v[2] in (_shift(day, n), _shift(day, -n))]
    except ValueError:
        return None
    return near[0] if len(near) == 1 else None


def season_query(show, season_name):
    """«Bleach Thousand-Year Blood War» para una temporada con nombre propio; None si es «Season 2» o similar"""
    name = (season_name or "").strip()
    if not name or not show or name.lower().split(" ")[0] in _GENERIC or name.lower() == show.lower():
        return None
    return name if name.lower().startswith(show.lower()) else "%s %s" % (show, name)


def others(tmdb_id, imdb_id, season, opener=None, path=None, now=time.time):
    """[imdb] de otras fichas de Cinemeta que pueden tener capítulos de la serie (búsqueda por el nombre de la serie +
    el de la temporada, si tiene), guardadas un día. Sin verificar: eso es cosa de quien las usa (por fecha)"""
    import urllib.parse
    from flix_common import TMDB_KEY

    def fetch():
        d = _get_json("https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en-US" % (tmdb_id, TMDB_KEY), opener) or {}
        show = d.get("original_name") or d.get("name") or ""
        sea = next((x for x in d.get("seasons") or [] if x.get("season_number") == int(season)), {}) or {}
        out, seen = [], set()
        for q in (season_query(d.get("name") or show, sea.get("name")), d.get("name"), show):
            if not q or q in seen:
                continue
            seen.add(q)
            for m in ((_get_json(CINEMETA_SEARCH % urllib.parse.quote(q), opener) or {}).get("metas") or [])[:8]:
                mid = m.get("id") or ""
                if mid.startswith("tt") and mid != imdb_id and mid not in out:
                    out.append(mid)
        return out
    return _cached("otras/%s" % tmdb_id, fetch, path=path, now=now) or []


def elsewhere(tmdb_id, imdb_id, season, episode, when, opener=None, path=None, now=time.time):
    """(imdb, temporada, capítulo) de otra ficha de IMDb con ese capítulo (mismo día de emisión): partes que IMDb
    tiene como serie aparte (Bleach «Thousand-Year Blood War», Kimi ni Todoke 3, Cardcaptor Sakura «Clear Card»).
    Se busca en Cinemeta por el nombre de la serie (+ el de la temporada, si tiene) y se verifica por la fecha"""
    for mid in others(tmdb_id, imdb_id, season, opener=opener, path=path, now=now):
        hit = match_date(when, videos(mid, opener=opener, path=path, now=now))
        if hit:
            return mid, hit[0], hit[1]
    return None

