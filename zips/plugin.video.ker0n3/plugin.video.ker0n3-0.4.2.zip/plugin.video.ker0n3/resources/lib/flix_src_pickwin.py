"""«Elegir versión» con insignias (18-nov): la ventana FlixPick.xml de la skin (tools/gen_pick_dialog.py, TV y táctil).

Qué versiones y en qué orden lo decide flix_src_play.choose (lógica, aquí en el addon); cada fila la arma
flix_src_pick.row (insignias de calidad, imagen, audio y canales; idioma; tamaño y remux; aviso si no está lista).
Esta ventana solo las enseña y devuelve cuál se eligió. La abren tanto la skin (flix_play → flix_src_play.play) como
el addon (ruta play/…, handlers._play): una WindowXMLDialog con la ruta de la skin en uso; Kodi busca el XML en la
skin. Si la skin no lo trae (otra skin, una vieja) o la ventana falla, select() lanza Unavailable y quien llama usa la
lista de Kodi de siempre (Dialog().select). Atrás = -1 (cancelar), como la lista de Kodi."""
XML = "FlixPick.xml"
LIST = 100
FIELDS = ("q", "qt", "v", "a", "ch", "lang", "sub", "warn")
HEADING = "Elegir versión"
FOOT = "Arriba, la que se pondría sola con tu orden de calidades  ·  «–» = la versión no lo dice"


class Unavailable(Exception):
    """la skin no tiene la ventana: la lista de Kodi"""


def skin_has_window():
    """¿la skin en uso trae FlixPick.xml? (TV: resources/skins/Default/1080i; táctil: xml/)"""
    import xbmcvfs
    return any(xbmcvfs.exists("special://skin/%s/%s" % (d, XML)) for d in ("resources/skins/Default/1080i", "xml"))


def select(sub, rows, heading=HEADING):
    """índice elegido o -1. rows: [flix_src_pick.row(c)]. Unavailable si no se puede enseñar"""
    import xbmcgui
    import xbmcvfs
    if not skin_has_window():
        raise Unavailable(XML)

    class Win(xbmcgui.WindowXMLDialog):
        choice = -1

        def onInit(self):
            self.setProperty("pk_title", heading)
            self.setProperty("pk_sub", sub or "")
            self.setProperty("pk_foot", FOOT)
            lst = self.getControl(LIST)
            lst.reset()
            items = []
            for r in rows:
                li = xbmcgui.ListItem(r.get("lang") or "")
                for k in FIELDS:
                    li.setProperty(k, r.get(k) or "")
                items.append(li)
            lst.addItems(items)
            self.setFocusId(LIST)

        def onClick(self, cid):
            if cid == LIST:
                self.choice = self.getControl(LIST).getSelectedPosition()
                self.close()

        def onAction(self, action):
            import flix_common
            if action.getId() in flix_common.A_BACK:
                self.choice = -1
                self.close()
    try:
        w = Win(XML, xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    except Exception as e:  # noqa: BLE001  (XML que no está o roto: la lista de Kodi)
        raise Unavailable(str(e)) from None
    w.doModal()
    choice = w.choice
    del w
    return choice if 0 <= choice < len(rows) else -1
