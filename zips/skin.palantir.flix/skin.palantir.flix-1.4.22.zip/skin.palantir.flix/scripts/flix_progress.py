"""Progreso de películas igual en todas las filas.

Palantir guarda el progreso real en addon_data/plugin.video.palantir3/watched.db (lo sube a Trakt y lo baja al
sincronizar), pero cada fila del Inicio sale de su caché (cache.db, hasta 3 días) con el porcentaje del momento en
que se generó, y Kodi no vuelve a pedir una fila mientras su ruta no cambie. Resultado: la misma película con 35 %
en Top 10, 21 % en Tendencias y sin barra en otra fila.

Este script (solo lee watched.db; no toca Trakt ni el scrobbling de Palantir):
  1. corrige percentPlayed/playCount/totalTime/lastPlayed de cada película en las listas de cache.db
     (pickle de Palantir, reescrito byte a byte igual salvo esos campos); "Seguir viendo" se borra de la caché si
     ha cambiado o hay algo visto después, para que Palantir la regenere con su orden y sus reglas;
  2. corrige el "resume" de la caché de las pantallas de sección (rows_cache.json del skin);
  3. mira lo que enseña cada fila del Inicio (Container(N).ListItemAbsolute(i).PercentPlayed) y recarga SOLO las
     filas que no cuadran, cambiando Window(home).Property(flix_rl_<variable>) que va pegada al reload= de su ruta
     (cada carga de Palantir consulta la API de GitHub, 60/h por IP: no se recarga nada sin necesidad).
Se lanza al abrir el Inicio, al cerrar el vídeo y al cerrar el menú contextual (limpiar progreso, marcar como
vista); repite la pasada unos segundos después porque Palantir escribe watched.db con algo de retraso.
Uso: RunScript(special://skin/scripts/flix_progress.py,home|video|menu)
"""
import json
import os
import pickle
import re
import sqlite3
import sys
import time
import types

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/")
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
ROWS_CACHE = flix_rows.CACHE_FILE
PASSES = {"home": [0, 4, 12], "video": [2, 6, 15, 30], "menu": [1, 3, 8, 15]}
TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')
CONTENT_RE = re.compile(r'"content": \'(\w+)')


def log(msg):
    xbmc.log("[flix_progress] %s" % msg, xbmc.LOGINFO)
    HOME.setProperty("flix_progress_log", msg[:500])     # legible por JSON-RPC (en Fire OS no se puede leer kodi.log)


# ---------- verdad: watched.db de Palantir ----------
def truth():
    """{tmdb(str): (playcount, progress %, runtime s, lastPlayed)}; None si no se puede leer."""
    if not os.path.exists(WATCHED_DB):
        return None
    db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
    try:
        return {str(r[0]): (r[1], r[2], r[3], r[4]) for r in
                db.execute("SELECT tmdb_id, playcount, progress, runtime, lastPlayed FROM movies_watched")}
    finally:
        db.close()


def fields(row):
    """campos de un P3Item de película tal como los escribe Palantir al generar la lista"""
    if row is None:
        return {"percentPlayed": None, "playCount": None, "totalTime": None, "lastPlayed": None}
    playcount, progress, runtime, last = row
    return {"percentPlayed": progress, "playCount": playcount, "totalTime": runtime, "lastPlayed": last}


def shown_pct(row):
    """porcentaje que debería enseñar la barra (Kodi trunca a entero)"""
    return int(row[1] or 0) if row else 0


# ---------- 1. cache.db de Palantir ----------
class _Unpickler(pickle.Unpickler):
    """las clases de Palantir (libs.*) no se pueden importar fuera de su proceso: se sustituyen por clases vacías
    con el mismo módulo y nombre, registradas en sys.modules para que pickle.dumps las vuelva a escribir igual"""

    def find_class(self, module, name):
        if module.split(".")[0] == "libs":
            mod = sys.modules.get(module)
            if mod is None:
                parts = module.split(".")
                for i in range(1, len(parts) + 1):
                    sys.modules.setdefault(".".join(parts[:i]), types.ModuleType(".".join(parts[:i])))
                mod = sys.modules[module]
            cls = getattr(mod, name, None)
            if cls is None:
                cls = type(name, (), {})
                cls.__module__, cls.__qualname__ = module, name
                setattr(mod, name, cls)
            return cls
        return super().find_class(module, name)


def _loads(data):
    import io
    return _Unpickler(io.BytesIO(data)).load()


def fix_palantir_cache(W):
    """devuelve nº de listas corregidas/borradas"""
    if not os.path.exists(CACHE_DB):
        return 0
    db = sqlite3.connect(CACHE_DB, timeout=5)
    changed = 0
    try:
        rows = db.execute("SELECT id, data FROM simplecache WHERE type='pickle'").fetchall()
        for cid, data in rows:
            try:
                items = _loads(data)
                if pickle.dumps(items, protocol=4) != data:
                    log("%s: no se reescribe igual, no se toca" % cid)
                    continue
            except Exception as e:  # noqa: BLE001
                log("no leo %s: %s" % (cid, e))
                continue
            if not isinstance(items, list):
                continue
            dirty, unfinished, newest = False, False, ""
            for it in items:
                v = getattr(it, "__dict__", None)
                if not isinstance(v, dict) or v.get("content") != "movies" or not v.get("tmdb"):
                    continue
                unfinished = unfinished or v.get("especial") == "no_finalizadas"
                newest = max(newest, v.get("lastPlayed") or "")
                want = fields(W.get(str(v["tmdb"])))
                for k, val in want.items():
                    if v.get(k) != val:
                        v[k] = val
                        dirty = True
            if unfinished:
                # "Seguir viendo": Palantir decide qué entra y en qué orden -> que la regenere
                played_after = any((r[3] or "") > newest and (r[1] or 0) > 0 for r in W.values())
                if dirty or played_after:
                    db.execute("DELETE FROM simplecache WHERE id=? AND data=?", (cid, data))
                    changed += 1
                    log("%s borrada (seguir viendo cambió)" % cid)
                continue
            if dirty:
                db.execute("UPDATE simplecache SET data=? WHERE id=? AND data=?",
                           (pickle.dumps(items, protocol=4), cid, data))
                changed += 1
                log("%s corregida" % cid)
        db.commit()
    finally:
        db.close()
    return changed


# ---------- 2. listas JSON-RPC (pantallas de sección, Inicio táctil) ----------
_TRUTH = [0.0, None]


def truth_cached(max_age=5):
    """watched.db leída como mucho una vez cada max_age s (una pantalla pide varias filas seguidas)"""
    if _TRUTH[1] is None or time.time() - _TRUTH[0] > max_age:
        try:
            _TRUTH[:] = [time.time(), truth()]
        except Exception as e:  # noqa: BLE001
            log("watched.db: %s" % e)
            return None
    return _TRUTH[1]


def fix_files(files, W=None):
    """pone en cada película de una lista de Files.GetDirectory el resume/playcount reales; devuelve cuántas cambió"""
    W = truth_cached() if W is None else W
    if not W or not files:
        return 0
    changed = 0
    for f in files:
        if not isinstance(f, dict) or f.get("filetype", "file") != "file" or \
                not str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/"):
            continue
        try:
            route = flix_rows.decode_route(f["file"])
        except Exception:  # noqa: BLE001
            continue
        m, c = TMDB_RE.search(route), CONTENT_RE.search(route)
        if not m or (c and c.group(1) != "movies"):
            continue
        row = W.get(m.group(1))
        total = float(row[2] or 0) if row else 0.0
        pos = round(total * float(row[1] or 0) / 100, 3) if row else 0.0
        want_pc = int(row[0] or 0) if row else 0
        old = f.get("resume") or {}
        if abs(float(old.get("position") or 0) - pos) > 1 or int(f.get("playcount") or 0) != want_pc:
            f["resume"], f["playcount"] = {"position": pos, "total": total}, want_pc
            changed += 1
    return changed


def fix_rows_cache(W):
    try:
        with open(ROWS_CACHE, encoding="utf-8") as fh:
            cache = json.load(fh)
    except Exception:  # noqa: BLE001
        return 0
    changed = 0
    for _key, entry in cache.items():
        if isinstance(entry, list) and len(entry) == 2 and isinstance(entry[1], list):
            changed += fix_files(entry[1], W)
    if changed:
        tmp = ROWS_CACHE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cache, fh, ensure_ascii=False)
        os.replace(tmp, ROWS_CACHE)
        log("rows_cache: %d películas corregidas" % changed)
    return changed


# ---------- 3. filas del Inicio en pantalla ----------
def home_rows():
    """{list_id: nombre de la variable de su ruta} leído de Home.xml (el orden lo cambia flix_home_order.py)"""
    try:
        with xbmcvfs.File("special://skin/xml/Home.xml") as fh:
            text = fh.read()
    except Exception:  # noqa: BLE001
        return {}
    out = {}
    for block in re.findall(r'<include content="FlixRow">(.*?)</include>', text, re.S):
        lid = re.search(r'name="list_id" value="(\d+)"', block)
        # src = variable de la ruta real (de serie: FlixPath…; añadida: FlixRowPath<id>); la de path es la de carga
        # diferida (FlixRowPath<id>, vacía hasta que la fila está cerca). Home.xml antiguo: solo path
        var = re.search(r'name="src" value="(\w+)"', block) or re.search(r'name="path" value="\$VAR\[(\w+)\]"', block)
        if lid and var:
            out[lid.group(1)] = var.group(1)
    return out


def refresh_rows(W):
    if xbmcgui.getCurrentWindowId() != 10000:
        return 0
    bumped = 0
    for lid, var in home_rows().items():
        n = int(xbmc.getInfoLabel("Container(%s).NumItems" % lid) or 0)
        wrong = []
        for i in range(n):
            path = xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).FileNameAndPath" % (lid, i))
            if not path.startswith("plugin://plugin.video.palantir3/"):
                continue
            try:
                route = flix_rows.decode_route(path)
            except Exception:  # noqa: BLE001
                continue
            m, c = TMDB_RE.search(route), CONTENT_RE.search(route)
            if not m or not c or c.group(1) != "movies":
                continue
            want = shown_pct(W.get(m.group(1)))
            got = int(xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).PercentPlayed" % (lid, i)) or 0)
            if abs(want - got) > 1:
                wrong.append("%s:%d" % (m.group(1), want))
        if not wrong:
            continue
        sig = ",".join(wrong)
        # cada carga gasta API de GitHub: por la misma discrepancia, como mucho 3 recargas y 5 s entre ellas
        # (una recarga puede llegar antes de que Palantir haya guardado el cambio y no servir)
        prev = HOME.getProperty("flix_rl_sig_" + var).split("|")
        tries = int(prev[1]) if len(prev) == 3 and prev[0] == sig else 0
        last = float(prev[2]) if len(prev) == 3 and prev[0] == sig else 0.0
        if tries >= 3 or time.time() - last < 5:
            continue
        HOME.setProperty("flix_rl_sig_" + var, "%s|%d|%f" % (sig, tries + 1, time.time()))
        HOME.setProperty("flix_rl_" + var, str(int(time.time() * 10)))
        bumped += 1
        log("recargo fila %s (%s, intento %d): %s" % (lid, var, tries + 1, sig))
    return bumped


def one_pass():
    W = truth()
    if not W:
        log("sin watched.db en %s" % WATCHED_DB)
        return
    a = fix_palantir_cache(W)
    b = fix_rows_cache(W)
    c = refresh_rows(W)
    if a or b or c:
        log("pasada: cache.db %d, secciones %d, filas recargadas %d" % (a, b, c))


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "home"
    busy = HOME.getProperty("flix_progress_busy")
    if busy and time.time() - float(busy or 0) < 60:
        HOME.setProperty("flix_progress_again", mode)
        return
    HOME.setProperty("flix_progress_busy", str(time.time()))
    monitor = xbmc.Monitor()
    log("inicio (%s)" % mode)
    try:
        while True:
            last = 0
            for t in PASSES.get(mode, PASSES["home"]):
                # waitForAbort(0) no vuelve en algunas versiones: solo se espera si hay algo que esperar
                if t > last and monitor.waitForAbort(t - last):
                    return
                last = t
                HOME.setProperty("flix_progress_busy", str(time.time()))
                try:
                    one_pass()
                except Exception as e:  # noqa: BLE001
                    log("error: %s" % e)
            mode = HOME.getProperty("flix_progress_again")
            HOME.clearProperty("flix_progress_again")
            if not mode:
                break
    finally:
        HOME.clearProperty("flix_progress_busy")


if __name__ == "__main__":
    main()
