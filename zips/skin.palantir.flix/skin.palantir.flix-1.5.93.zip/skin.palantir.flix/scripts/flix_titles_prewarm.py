"""Lista de títulos del buscador (flix_search.load_titles) preparada por detrás al arrancar, si la base de Palantir
cambió desde la última vez (actualización de su catálogo): la primera búsqueda tras la 3.3.11 tardó ~45 s (Shield,
28-oct: 18 s rehaciendo la lista + las 8 secciones una a una). Espera a que el Inicio esté pintado, a que acabe la
sincronización de Palantir y a que no haya vídeo ni mando en uso (como las filas al azar). Lo lanza first_run.py."""
import json
import os
import sys
import time

import xbmc
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

DELAY = 60          # s tras arrancar: Inicio pintado y sincronización de Palantir hecha
WAIT_IDLE = 900     # s como mucho esperando un rato tranquilo; si no, lo hará la primera búsqueda


def log(msg):
    xbmc.log("[flix_titles_prewarm] %s" % msg, xbmc.LOGINFO)


def needs_rebuild(db, cache, version):
    """¿la lista guardada no corresponde a la base de Palantir de ahora (fecha y tamaño)? Sin base: no"""
    try:
        stamp = [os.path.getmtime(db), os.path.getsize(db)]
    except OSError:
        return False
    try:
        with open(cache, encoding="utf-8") as fh:
            d = json.load(fh)
        return not (d.get("v") == version and d.get("db") == stamp)
    except (OSError, ValueError):
        return True


def main():
    import flix_search as fs
    db, cache = xbmcvfs.translatePath(fs.CONTENT_DB), xbmcvfs.translatePath(fs.TITLES_FILE)
    if not needs_rebuild(db, cache, fs.TITLES_VERSION):
        return
    import flix_random_rows as rr          # «tranquilo»: sin vídeo, enlace, tráiler, mando, ni Palantir ocupado
    mon = xbmc.Monitor()
    if mon.waitForAbort(DELAY):
        return
    end = time.time() + WAIT_IDLE
    while not rr.idle():
        if time.time() > end or mon.waitForAbort(10):
            log("sin un rato tranquilo: la lista la hará la primera búsqueda")
            return
    t0 = time.time()
    blobs = fs.load_titles([fs.view_of(r) for _, r in fs.section_search_routes()])
    log("lista de títulos %s en %.1f s" % ("preparada" if blobs else "sin hacer (base no disponible)", time.time() - t0))


if __name__ == "__main__":
    main()
