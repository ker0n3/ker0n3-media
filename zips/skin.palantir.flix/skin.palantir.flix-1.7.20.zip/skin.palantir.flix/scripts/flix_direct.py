# -*- coding: utf-8 -*-
"""Listados de Palantir hechos por la skin, sin lanzar Palantir (Carlos, 12-nov: agilidad).

Cada llamada a Palantir arranca un intérprete, recompila sus 12 módulos e importa sus librerías de red: ~2,2 s fijos
en la Shield (2,3 s hasta para una lista de 1 título; 3,4 s de media por fila; más en un Fire TV), y sus vistas
recalculan los idiomas de cada título recorriendo todos los enlaces en cada consulta. Pero un listado normal de
películas o series es solo la consulta SQL que viaja en la ruta de la fila, sobre su base de contenido local, más lo
visto de watched.db: sin red. Aquí se hace lo mismo dentro de la skin, con un índice propio para esos agregados.

Comprobado el 12-nov contra Palantir 3.3.11 en la Shield: 31 filas, 1.062 elementos, idénticos en la ruta de cada
elemento y en lo que Kodi devuelve por JSON-RPC (salvo la hora `time` y el orden de idiomas/calidades entre
corchetes, que en Palantir sale de un set() y cambia en cada llamada; aquí va ordenado).

NUNCA rompe una fila: `list_files()` devuelve None en cuanto algo no cuadra y el que llama se la pide a Palantir como
siempre. Protecciones:
  - SOMBRA: para cada pareja (versión de Palantir, estructura de su base) las primeras filas se piden a Palantir como
    hoy y, con su respuesta en la mano, se comparan con las directas (`shadow`): tras SHADOW_OK coincidencias seguidas
    el modo directo queda activo para esa pareja; a la primera diferencia, apagado (y apuntado en el registro). Una
    versión nueva de Palantir o un cambio en sus vistas vuelve a pasar por la sombra sola.
  - Cada RECHECK s, una fila vuelve a ir por Palantir y se compara (una llamada a la semana).
  - Solo filas normales: nada que Palantir resuelva con Trakt (Top 10, más vistas, recomendadas, watchlist) ni
    «Seguir viendo» / «Mis series» / colecciones (se le siguen pidiendo).
  - Con Palantir actualizando su contenido (flix_tmdblists.palantir_busy) o con el índice aún sin hacer, a Palantir.
  - Skin.HasSetting(flix_direct_off) lo apaga del todo."""
import ast
import copy
import functools
import hashlib
import json
import os
import re
import sqlite3
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common

HOME = xbmcgui.Window(10000)
P3 = "plugin.video.palantir3"
ROOT = flix_common.PLUGIN_ROOT + "?"
SHADOW_OK = 6               # coincidencias seguidas (con al menos una fila de pelis y una de series) para activarlo
SEARCH_OK = 6                # ídem para las búsquedas (con resultados; al menos una de películas y una de series)
PERSONAL_OK = 2             # ídem para «Seguir viendo» y para «Series en seguimiento» (se piden en cada arranque y tras cada vídeo)
# tipos de fila que se hacen aquí. Cada uno se comprueba y se activa por separado:
#   normal  listado de películas o series con su consulta (géneros, plataformas, novedades…)
#   resume  «Seguir viendo»: películas a medias de watched.db (Palantir: especial no_finalizadas)
#   follow  «Series en seguimiento»: series con capítulos tocados (Palantir: Mis_serieS)
KINDS = ("normal", "resume", "follow", "search")
RECHECK = 7 * 86400         # s: cada cuánto una fila vuelve a compararse con Palantir
SETTINGS_TTL = 60           # s que valen los ajustes de Palantir leídos
MORE_ID = 30031             # «más...» (cadena de Palantir)
ACTIONS = ("listado_peliculaS", "listado_serieS")
PERSONAL_VOLATILE = ("time", "playCount", "percentPlayed", "totalTime", "lastPlayed", "newEpisodes")
TRAKT_SPECIAL = ("mas_vista_mes", "mas_vistas", "recomendadas")
TRAKT_WIDGETS = ("WidgetTop10Pelis", "WidgetPelisWatchlist", "WidgetTop10Series", "WidgetSeriesWatchlist")
VOLATILE = ("time",)        # lo único que cambia entre dos llamadas iguales
_lock = threading.Lock()
_mem = {"state": None, "state_sig": None, "settings": None, "settings_at": 0.0, "building": False, "sig": None,
        "sig_at": 0.0, "more": None}


def log(msg):
    xbmc.log("[flix_direct] %s" % msg, xbmc.LOGINFO)


def data_dir():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/" % xbmc.getSkinDir())


def state_file():
    return os.path.join(data_dir(), "direct.json")


def index_file():
    return os.path.join(data_dir(), "direct_index.db")


def content_db():
    return xbmcvfs.translatePath("special://profile/addon_data/script.module/settings.xml")


def watched_db():
    return xbmcvfs.translatePath(flix_common.WATCHED_DB_REL)


# ---------- rutas ----------
def b64dec(s):
    from urllib import parse
    import base64
    s = parse.unquote(s).encode()
    full = (len(s) + 3) // 4 * 4
    q = full // 4
    return base64.b64decode(s[:q][::-1] + s[q:][::-1] + b"=" * (full - len(s))).decode("utf-8")


def b64enc(text):
    from urllib import parse
    import base64
    value = base64.b64encode(text.encode())
    q = int(len(value) / 4)
    value = value.replace(b"=", b"")
    return parse.quote(value[:q][::-1] + value[q:][::-1])


def decode(path):
    """(diccionario del elemento de Palantir, parámetros sueltos tras el primer &) o (None, '') si no es una ruta suya"""
    if not str(path or "").startswith(ROOT):
        return None, ""
    code, _, extra = path[len(ROOT):].partition("&")
    try:
        d = ast.literal_eval(b64dec(code))
    except Exception:  # noqa: BLE001
        return None, ""
    return (d, extra) if isinstance(d, dict) else (None, "")


def encode(d):
    """como P3Item.tourl: claves ordenadas, "clave": repr(valor)"""
    return ROOT + b64enc("{%s}" % ", ".join('"%s": %s' % (k, repr(d[k])) for k in sorted(d)))


def kind_of(item, extra):
    """tipo de fila que se puede hacer aquí ('normal', 'resume', 'follow') o '' si hay que pedírsela a Palantir"""
    if not item or not item.get("sql"):
        return ""
    # parámetros sueltos de la ruta: &reload=… no cambia nada. &limit=… (lo llevan las filas personales del Inicio)
    # Palantir solo lo mira con su skin, Estuary Palantir: con limit=15 devuelve las 53 de siempre (Shield, 12-nov);
    # solo se acepta en esas dos filas, que es donde está comprobado. Cualquier otro, que decida él
    names = [p.split("=", 1)[0] for p in extra.split("&") if p]
    if not all(n in ("reload", "limit") for n in names):
        return ""
    action = item.get("action")
    if action == "Mis_serieS":
        return "follow" if "%s" in item["sql"] else ""
    if action not in ACTIONS:
        return ""
    if action == "listado_peliculaS" and item.get("especial") == "no_finalizadas":
        return "resume" if "%s" in item["sql"] else ""
    if "limit" in names:
        return ""
    if item.get("especial") in TRAKT_SPECIAL or item.get("nameWidget") in TRAKT_WIDGETS:
        return ""
    if item.get("sub_categoria") == "Mis_series" or item.get("isWidget") or item.get("especial"):
        return ""
    if "enlaces_" in item["sql"]:
        # consultas que unen los enlaces directamente («Clásicas», «Reality» de la sección Series): el índice no las
        # acelera y aquí tardaron MÁS que con Palantir (5-6 s frente a ~4 s en la Shield, 12-nov) → a Palantir
        return ""
    if re.search(r"iREGEXP", item["sql"], re.I):
        # consulta «Por título» del buscador (flix_search.direct_route): su comparación de texto y su orden por
        # relevancia se verifican aparte de las filas, con búsquedas de verdad
        return "search"
    return "normal"


def usable(item, extra):
    return bool(kind_of(item, extra))


# ---------- comparación de textos de Palantir (su intercalación «latin1» y REGEXP / iREGEXP / INICIAL) ----------
_ROWS = {0x20: " " + "\0" * 15, 0x30: "0123456789" + "\0" * 6, 0x40: "\0ABCDEFGHIJKLMNO", 0x50: "PQRSTUVWXYZ" + "\0" * 5,
         0x60: "\0ABCDEFGHIJKLMNO", 0x70: "PQRSTUVWXYZ" + "\0" * 5, 0xA0: "\0" * 10 + "A" + "\0" * 5,
         0xB0: "\0\0" + "23" + "\0\0" + "P" + "\0\0" + "1O" + "\0" * 5, 0xC0: "AA\0AAAACEEEEIIII",
         0xD0: "DNOOOOO\0OUOUUY\0B", 0xE0: "AAAAAAACEEEEIIII", 0xF0: "DNOOOOO\0OUOUUY\0Y"}
LATIN1 = [""] * 256
for _base, _row in _ROWS.items():
    for _i, _c in enumerate(_row):
        LATIN1[_base + _i] = "" if _c == "\0" else _c


def map_string(s):
    out = ""
    for ch in s.strip():
        if ord(ch) == 32 and not out:
            continue
        if ord(ch) <= 255:
            out += LATIN1[ord(ch)]
    return out


@functools.lru_cache(maxsize=60000)
def mapped(s):
    """map_string con memoria: las vistas de Palantir comparan y ordenan miles de títulos en cada consulta, y una
    búsqueda pasa esta función por TODOS los títulos de la sección (24.868 películas: 0,6-0,9 s en el móvil y 2 s en un
    Fire TV solo en esto; con memoria, la primera búsqueda la paga una vez y las siguientes van en milisegundos)"""
    return map_string(s)


@functools.lru_cache(maxsize=512)
def compiled(expr):
    return re.compile(expr)


def collate(x, y):
    a, b = mapped(x), mapped(y)
    return 1 if a > b else -1 if a < b else 0


def inicial(s):
    out = ""
    for ch in s.strip():
        if ord(ch) == 32:
            continue
        if ord(ch) <= 255:
            out = LATIN1[ord(ch)]
        if out:
            break
    return out


def _inicial(s1, s2):
    a = inicial(s1)
    if s2 == "0-9":
        try:
            int(a)
            return True
        except ValueError:
            return False
    return a == inicial(s2)


@functools.lru_cache(maxsize=8192)
def _regexp(expr, text):
    return bool(text) and compiled(expr).search(text) is not None


def _iregexp(expr, text):
    if not text or not expr:
        return False
    return compiled(mapped(expr)).search(mapped(text)) is not None


# ---------- estructura de la base de Palantir e índice propio ----------
def uri(path, ro=True):
    """ruta como URI de SQLite. Las bases se abren SIEMPRE así (uri=True): el ATTACH con «file:…?mode=ro» solo vale
    en una conexión abierta como URI (en la Shield, con una conexión normal: «unable to open database»)"""
    from urllib import parse
    return "file:%s%s" % (parse.quote(path), "?mode=ro" if ro else "")


INDEX_RETRY = 600           # s sin reintentar el índice tras un fallo (no uno por fila)
def content_sig(path=None):
    """huella del FICHERO de contenido (cambia cuando Palantir actualiza su catálogo): tamaño:mtime"""
    try:
        st = os.stat(path or content_db())
        return "%d:%d" % (st.st_size, st.st_mtime_ns)
    except OSError:
        return ""


def schema_sig(db):
    """huella de la ESTRUCTURA (tablas y vistas que se usan): si Palantir la cambia, vuelta a la sombra"""
    rows = db.execute("SELECT name, sql FROM sqlite_master WHERE type IN ('table', 'view') AND "
                      "(name IN ('pelis', 'series', 'enlaces_pelis', 'enlaces_series') OR name LIKE 'v\\_%' ESCAPE '\\') "
                      "ORDER BY name").fetchall()
    return hashlib.sha1(repr([(n, " ".join((s or "").split())) for n, s in rows]).encode("utf-8")).hexdigest()[:16]


def build_index(content=None, index=None):
    """idiomas y calidades por título, y temporadas y nº de capítulos por serie: lo que Palantir recalcula en cada
    consulta recorriendo todos los enlaces. Una vez por actualización de su catálogo; escrito aparte y puesto de golpe"""
    content, index = content or content_db(), index or index_file()
    sig = content_sig(content)
    tmp = index + ".tmp"
    try:
        os.remove(tmp)
    except OSError:
        pass
    t = time.time()
    db = sqlite3.connect(uri(tmp, ro=False), uri=True)
    try:
        db.execute("ATTACH DATABASE ? AS c", (uri(content),))
        db.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
        db.execute("CREATE TABLE a_pelis (tmdb INTEGER PRIMARY KEY, audio TEXT, calidad TEXT)")
        db.execute("INSERT INTO a_pelis SELECT tmdb, group_concat(audio, '#'), group_concat(calidad, '#') "
                   "FROM c.enlaces_pelis GROUP BY tmdb")
        db.execute("CREATE TABLE a_series (tmdb INTEGER PRIMARY KEY, audio TEXT, temporadas TEXT, capitulos INTEGER)")
        db.execute("INSERT INTO a_series (tmdb, audio) SELECT tmdb, group_concat(audio, '#') FROM c.enlaces_series GROUP BY tmdb")
        seasons = {}
        for tmdb, s in db.execute("SELECT tmdb, temporada FROM c.enlaces_series WHERE temporada > 0 GROUP BY tmdb, temporada"):
            seasons.setdefault(tmdb, []).append(s)
        eps = dict(db.execute("SELECT tmdb, count(*) FROM (SELECT tmdb, temporada, episodio FROM c.enlaces_series "
                              "WHERE temporada > 0 GROUP BY tmdb, temporada, episodio) GROUP BY tmdb"))
        db.executemany("UPDATE a_series SET temporadas = ?, capitulos = ? WHERE tmdb = ?",
                       [(json.dumps(seasons.get(k)) if k in seasons else None, eps.get(k), k) for k in set(seasons) | set(eps)])
        db.executemany("INSERT INTO meta VALUES (?, ?)", [("content", sig), ("schema", schema_sig_of(content))])
        db.commit()
    finally:
        db.close()
    if content_sig(content) != sig:
        os.remove(tmp)                  # Palantir cambió su base mientras tanto: este índice no vale
        return False
    os.replace(tmp, index)
    log("índice hecho en %.1f s (%d KB)" % (time.time() - t, os.path.getsize(index) // 1024))
    return True


def schema_sig_of(content):
    db = sqlite3.connect(uri(content), uri=True, timeout=2)
    try:
        return schema_sig(db)
    finally:
        db.close()


def index_meta(index=None):
    """{'content': …, 'schema': …} del índice guardado; {} si no hay o no se lee. Se guarda en memoria mientras el
    fichero no cambie (se mira varias veces por fila)"""
    index = index or index_file()
    try:
        st = os.stat(index)
        sig = (index, st.st_mtime_ns, st.st_size)
    except OSError:
        return {}
    if _mem.get("meta_sig") == sig:
        return _mem["meta"]
    try:
        db = sqlite3.connect(uri(index), uri=True, timeout=2)
        try:
            meta = dict(db.execute("SELECT k, v FROM meta"))
        finally:
            db.close()
    except sqlite3.Error:
        return {}
    _mem["meta"], _mem["meta_sig"] = meta, sig
    return meta


def present(kind, ids):
    """los ids («movie» / «tv») que Palantir tiene CON enlaces (lo que dan sus vistas v_pelis / v_series), en el mismo
    orden, mirando el índice en vez de la vista (que agrupa todos los enlaces: décimas de segundo por fila en la
    Shield). None si el modo directo no está activo o el índice no es el del catálogo actual: que lo mire el de siempre"""
    try:
        table, base = {"movie": ("a_pelis", "pelis"), "tv": ("a_series", "series")}[kind]
        ids = [int(i) for i in ids]
        st = settings()
        if not ids or st is None or mode(st) != "on" or busy() or index_meta().get("content") != content_sig():
            return None
        db = sqlite3.connect(uri(index_file()), uri=True, timeout=5)
        try:
            db.execute("ATTACH DATABASE ? AS c", (uri(content_db()),))
            have = {r[0] for r in db.execute("SELECT a.tmdb FROM %s AS a JOIN c.%s AS p ON p.tmdb = a.tmdb WHERE a.tmdb IN (%s)"
                                             % (table, base, ",".join(str(i) for i in ids)))}
        finally:
            db.close()
        return [i for i in ids if i in have]
    except Exception as e:  # noqa: BLE001
        log("títulos presentes: %s" % e)
        return None


def ensure_index():
    """¿hay índice del catálogo actual? Si no, se hace en un hilo (y mientras, las filas van por Palantir)"""
    if index_meta().get("content") == content_sig():
        return True
    with _lock:
        if _mem["building"] or time.time() - _mem.get("index_failed", 0) < INDEX_RETRY:
            return False
        _mem["building"] = True

    def run():
        try:
            build_index()
        except Exception as e:  # noqa: BLE001
            _mem["index_failed"] = time.time()
            log("índice sin hacer: %s" % e)
        finally:
            _mem["building"] = False
    threading.Thread(target=run, daemon=True, name="flix_direct_index").start()
    return False


def open_db(content=None, index=None):
    """conexión de solo lectura al índice con la base de Palantir adjunta y vistas rápidas con los MISMOS nombres y
    columnas que las suyas (v_pelis, v_series y, encima, sus vistas por categoría tal cual): las consultas de las filas
    se ejecutan sin tocar"""
    db = sqlite3.connect(uri(index or index_file()), uri=True, timeout=5)
    try:
        db.create_collation("latin1", collate)
        db.create_function("iREGEXP", 2, _iregexp)
        db.create_function("REGEXP", 2, _regexp)
        db.create_function("INICIAL", 2, _inicial)
        db.execute("ATTACH DATABASE ? AS c", (uri(content or content_db()),))
        db.execute("CREATE TEMP VIEW v_pelis AS SELECT p.tmdb, p.titulo, p.fecha, p.plot, p.poster, p.fondo, p.categoria, "
                   "p.genero, p.coleccion, p.duration, p.updated, a.audio AS audio, a.calidad AS calidad, p.mpaa, p.trailer, "
                   "p.clearlogo, p.rating FROM c.pelis AS p JOIN a_pelis AS a ON p.tmdb = a.tmdb ORDER BY p.tmdb ASC")
        db.execute("CREATE TEMP VIEW v_series AS SELECT s.tmdb, s.titulo, s.fecha, s.plot, s.poster, s.fondo, s.categoria, "
                   "s.genero, s.updated, a.audio AS audio, s.mpaa, s.trailer, s.clearlogo, s.rating FROM c.series AS s "
                   "JOIN a_series AS a ON s.tmdb = a.tmdb ORDER BY s.tmdb ASC")
        for (sql,) in db.execute("SELECT sql FROM c.sqlite_master WHERE type = 'view' AND name NOT IN ('v_pelis', 'v_series')").fetchall():
            db.execute(sql.replace("CREATE VIEW", "CREATE TEMP VIEW", 1))
    except Exception:
        db.close()
        raise
    return db


# ---------- ajustes de Palantir y lo visto ----------
def settings():
    """los ajustes de Palantir que entran en un listado (solo se leen); None si no se pueden leer"""
    now = time.time()
    if _mem["settings"] is not None and now - _mem["settings_at"] < SETTINGS_TTL:
        return _mem["settings"]
    try:
        import xbmcaddon
        a = xbmcaddon.Addon(P3)
        s = {"limit": int(a.getSetting("limitItemList") or 53), "news": " " + a.getSetting("OrderNovedades").strip(),
             "special": " " + a.getSetting("OrderSpecial").strip(), "labels": a.getSetting("IdiomaCalidad") != "false",
             "color": a.getSetting("conColor") != "false", "hide_watched": a.getSetting("hide_watched") == "true",
             "unfinished_days": int(a.getSetting("hideUnfinished") or 30),
             "more": a.getLocalizedString(MORE_ID), "version": a.getAddonInfo("version")}
    except Exception as e:  # noqa: BLE001
        log("ajustes de Palantir sin leer: %s" % e)
        return None
    _mem["settings"], _mem["settings_at"] = s, now
    return s


def mis_series(wdb, hide_watched, done=None):
    """como Watched.getMisSeries de Palantir: {tmdb(str): (temporada, capítulo, progreso)} del último capítulo tocado de
    cada serie, de la más reciente a la más antigua; sin las ocultas ni (con su ajuste hide_watched) las completas"""
    q = flix_common.watched_query
    hidden = set(r[0] for r in q(wdb, "SELECT tmdb_id FROM shows_watched WHERE ocultar = 1"))
    if done is None:
        done = set(r[0] for r in q(wdb, "SELECT tmdb_id FROM shows_watched WHERE completa = 1"))
    out = {}
    for tmdb, season, episode, progress in q(
            wdb, "SELECT ew.tmdb_id, ew.season, ew.episode, ew.progress FROM episodes_watched ew INNER JOIN "
                 "(SELECT tmdb_id, MAX(lastPlayed) AS max_lastPlayed FROM episodes_watched GROUP BY tmdb_id) ew2 "
                 "ON ew.tmdb_id = ew2.tmdb_id AND ew.lastPlayed = ew2.max_lastPlayed ORDER by ew.lastPlayed DESC"):
        if tmdb in hidden or (hide_watched and tmdb in done):
            continue
        k = str(tmdb)
        if k not in out or (season, episode) > out[k][:2]:
            out[k] = (season, episode, progress)
    return out


def unfinished(wdb, days, now=None):
    """como Watched.getMoviesUnfinished: ids (texto) de las películas con progreso tocadas en los últimos `days` días,
    de la más reciente a la más antigua. La fecha se compara como texto, igual que allí"""
    import datetime
    cut = (datetime.datetime.fromtimestamp(time.time() if now is None else now, tz=datetime.timezone.utc)
           - datetime.timedelta(days=days))
    rows = flix_common.watched_query(wdb, "SELECT tmdb_id FROM movies_watched WHERE progress > 0.0 AND lastPlayed > ? "
                                          "ORDER BY lastPlayed DESC", (str(cut),))
    return [str(r[0]) for r in rows or []]


def watched_state(hide_watched):
    """(progreso de películas {tmdb: (playcount, %, s, fecha)}, series completas, series con capítulo nuevo, «mis series»
    {tmdb: último capítulo} como Watched.getMisSeries). Todo vacío si watched.db aún no existe"""
    wdb = watched_db()
    q = flix_common.watched_query
    movies = q(wdb, "SELECT tmdb_id, playcount, progress, runtime, lastPlayed FROM movies_watched")
    if movies is None:
        return {}, set(), set(), {}
    # la marca de la repetición de la sincronización (flix_p3sync: Z final → z) no sale de aquí
    progress = {r[0]: (r[1], r[2], r[3], r[4][:-1] + "Z" if isinstance(r[4], str) and r[4].endswith("z") else r[4])
                for r in movies}
    done = set(r[0] for r in q(wdb, "SELECT tmdb_id FROM shows_watched WHERE completa = 1"))
    new = set(r[0] for r in q(wdb, "SELECT tmdb_id FROM shows_watched WHERE actualizada = 1"))
    return progress, done, new, mis_series(wdb, hide_watched, done)


# ---------- el listado ----------
def idiomas(audio):
    out = []
    for p in audio.replace("[", "").replace("]", "").replace("#", ",").split(","):
        out += p.strip().split(" ") if " " in p else [p]
    low = set(x.strip().lower() for x in out)
    return sorted(set({"spa": "Esp"}.get(x, x.capitalize()) for x in low))


def clone(item, **kw):
    d = copy.deepcopy(item)
    for k in ("label", "sql", "contextMenu", "playCount", "isWidget", "nameWidget"):
        d.pop(k, None)
    d.update(kw)
    return d


def info_tag(o):
    """lo que setInfoTag de Palantir le cambia al elemento antes de hacer su ruta"""
    if not o.get("plot"):
        o["plot"] = o.get("label") or o.get("title", "")    # sin sinopsis, su etiqueta (el «más...» de una fila sin plot)
    if "fanart" not in o:
        o["fanart"] = "special://home/addons/plugin.video.palantir3/fanart.gif"
    if o.get("genre") and isinstance(o["genre"], str):
        o["genre"] = o["genre"].split("#")
    if o.get("isPlayable"):
        o.pop("icon", None)
        try:
            if o.get("percentPlayed") and float(o["percentPlayed"]) > 0.0 and o.get("totalTime") and int(o["totalTime"]) > 0:
                o.pop("playCount", None)
        except (TypeError, ValueError):
            pass
    return o


def items_of(item, db, st, state=None, now=None):
    """los elementos (diccionarios como los P3Item de Palantir, ya pasados por setInfoTag) de una fila normal.
    st: settings(); state: watched_state()"""
    item = copy.deepcopy(item)
    kind = kind_of(item, "")
    widget = bool(item.get("isWidget"))
    if item["action"] == "Mis_serieS":                  # Palantir: Mis_serieS → listado_serieS con esta marca
        item["sub_categoria"] = "Mis_series"
    movie = item["action"] == "listado_peliculaS"
    if item.get("limitItemList"):
        n = int(item.pop("limitItemList")) - (1 if widget else 0)
    else:
        n = st["limit"]
    if not item.get("page"):
        item["page"] = 0
    label = item.get("label") or ""
    sql = item["sql"]
    if movie and ("News" in label or "Novedades" in label):
        item["sql"] = sql = sql + st["news"]
    progress, done, new, mine = state if state is not None else watched_state(st["hide_watched"])
    now = time.time() if now is None else now
    q = sql
    if movie and "saga" in q:
        q = q.replace(" order by sagas", " order by fecha asc")
    elif "coleccion" in q:
        q = q.split("order")[0] + st["special"]
    q = q.replace(";", "")
    ids = None
    if kind == "resume":
        ids = unfinished(watched_db(), st["unfinished_days"], now)
    elif kind == "follow":
        # sin las que solo tienen el T1 E1 empezado (un piloto a medias no es «seguir» la serie)
        ids = [k for k, (season, episode, pct) in mine.items() if not (season == 1 and episode == 1 and (pct or 0) > 0.0)]
    if ids is not None:
        if not ids:
            return []                   # Palantir tampoco consulta: fila vacía
        q = q % ",".join(ids) + " ORDER BY CASE %s END" % " ".join("WHEN tmdb = %s THEN %d" % (t, i) for i, t in enumerate(ids))
    q += " limit {0} offset {1}".format(n + 1, int(item["page"]) * n)
    rows = db.execute(q).fetchall()
    if movie and ids:
        rows.sort(key=lambda r: ids.index(str(r[7])))
    out = []
    if movie:
        for r in rows[:n]:
            title, fecha, plot, poster, fondo, audio, qlt, tmdb, duration, mpaa, genre, trailer, logo, rating = r[:14]
            cat = None if len(r) == 14 else r[14]
            title = title.replace("\\n", "")
            lab = " %s" % title
            if fecha:
                lab = "%s (%s)" % (lab, fecha[:4])
            if audio:
                lab += " [%s]" % ", ".join(idiomas(audio))
            if qlt:
                lab += " [%s]" % ", ".join(sorted(set(qlt.split("#"))))
            o = clone(item, label=lab, title=title, fecha=fecha, plot=plot, poster=poster, icon="", fanart=fondo,
                      content="movies", tmdb=str(tmdb), isPlayable=True, duration=duration, mpaa=mpaa if mpaa else "",
                      genre=genre, trailer=trailer, clearlogo=logo, rating=rating, action="selectvideos_")
            o["time"] = now
            if cat:
                o["categoria"] = cat
                o["sub_categoria"] = {"Película": "pelis_Pelicula", "Música": "pelis_Musica"}.get(cat, "pelis_" + cat)
            if tmdb in progress:
                o["playCount"], o["percentPlayed"], o["totalTime"], o["lastPlayed"] = progress[tmdb]
            out.append(info_tag(o))
    else:
        if item.get("sub_categoria"):
            sub = item["sub_categoria"]
        elif label == "SeriesFavoritas":
            sub = "SeriesFavoritas"
        else:
            sub = re.findall(r"\sv_(.*?)\s", item["sql"] + " ")[0]
            if "_" not in sub:
                sub = None
        ids = [r[5] for r in rows[:n]]
        extra = {}
        if ids:
            marks = ",".join("?" * len(ids))
            extra = {t: (json.loads(s) if s else None, e)
                     for t, s, e in db.execute("SELECT tmdb, temporadas, capitulos FROM a_series WHERE tmdb IN (%s)" % marks, ids)}
        for r in rows[:n]:
            title, fecha, plot, poster, fondo, tmdb, audio, mpaa, genre, trailer, logo, rating = r[:12]
            cat = None if len(r) == 12 else r[12]
            lab = ""
            if fecha:
                lab = "%s (%s)" % (" %s" % title, fecha[:4])
            if audio:
                lab += " [%s]" % ", ".join(idiomas(audio))
            o = clone(item, label=lab, tvshowtitle=title, page=0, fecha=fecha, plot=plot, poster=poster, tmdb=str(tmdb),
                      fanart=fondo, mpaa=mpaa if mpaa else "", content="tvshows", genre=genre, trailer=trailer,
                      clearlogo=logo, rating=rating,
                      action="listado_temporadaS" if str(tmdb) not in mine else "play_mis_serieS")
            if cat and sub != "Mis_series":
                o["categoria"] = cat
                o["sub_categoria"] = "series_" + cat
            if tmdb in done:
                o["playCount"] = 1
            if tmdb in new:
                o["newEpisodes"] = True
            seasons, eps = extra.get(tmdb, (None, None))
            if seasons is not None:
                o["p3Seasons"] = seasons
                o["p3TotalSeasons"] = len(seasons)
            if eps is not None:
                o["p3TotalEpisodes"] = eps
            out.append(info_tag(o))
    if len(rows) > n:
        more = clone(item, label=st["more"], specialSort="bottom", page=item["page"] + 1,
                     action="listado_peliculaS" if movie else "listado_serieS", limitItemList=n, sql=item["sql"])
        if widget:
            more["page"], more["limitItemList"] = item["page"], st["limit"]
        out.append(info_tag(more))
    return out


# ---------- lo que Kodi le devuelve a la skin por JSON-RPC para cada elemento ----------
TMDB_IMG = "https://image.tmdb.org/t/p/"
ART_SIZES = (("poster", "w500"), ("icon", "w300"), ("fanart", "w1280"), ("thumb", "w300"), ("clearlogo", "w500"),
             ("season_poster", "w500"), ("still", "w500"))
P3_HOME = "special://home/addons/plugin.video.palantir3"
NEW_MARK = "[COLOR red][B]* [/B][/COLOR]"
_HEX = re.compile(r"%[0-9A-F]{2}")


def art_of(o):
    out = {}
    for key, size in ART_SIZES:
        v = o.get(key)
        if v:
            if not (v.lower().startswith("http") or v.startswith(P3_HOME)):
                v = TMDB_IMG + size + (v if v.startswith("/") else "/%s" % v)
            out[key.replace("_", ".")] = v
    if out.get("still") and not out.get("poster"):
        out["poster"] = out["still"]
    if not out.get("thumb"):
        out["thumb"] = out.get("poster") or out.get("icon")
    if not out.get("icon"):
        out["icon"] = out.get("poster", "")
    return out


def kodi_image(url):
    from urllib import parse
    return "image://" + _HEX.sub(lambda m: m.group(0).lower(), parse.quote(url, safe="-_.!()")) + "/"


def as_file(o, labels=True):
    """el elemento como en Files.GetDirectory (title, art, year, genre, rating, runtime, resume, playcount, file, plot)"""
    content = o.get("content")
    label = o.get("label", "")
    title = label
    if not labels:
        title = o.get("title", "") if content == "movies" else o.get("tvshowtitle", "") if content == "tvshows" else label
    elif o.get("newEpisodes") and content == "tvshows":
        title = NEW_MARK + label
    rating = 0.0
    parts = (o.get("rating") or "").split("/")
    for p in parts[1:2] + parts[0:1]:           # primero la de Trakt, luego la de TMDB (queda la última que es número)
        try:
            rating = float(p)
        except ValueError:
            pass
    resume = {"position": 0.0, "total": 0.0}
    playable = bool(o.get("isPlayable"))
    try:
        if playable and o.get("percentPlayed") and float(o["percentPlayed"]) > 0.0 and o.get("totalTime") and int(o["totalTime"]) > 0:
            pos = int(o["totalTime"]) * float(o["percentPlayed"]) / 100
            if pos > 180:
                resume = {"position": pos, "total": float(o["totalTime"])}
    except (TypeError, ValueError):
        pass
    fecha = o.get("fecha") or ""
    # premiered, mpaa y uniqueid: los pide el buscador (flix_search.fetch); como los pone setInfoTag de Palantir
    return {"file": encode(o), "label": label, "title": title.strip(),
            "premiered": fecha, "mpaa": o.get("mpaa") or "", "uniqueid": {"tmdb": str(o["tmdb"])} if o.get("tmdb") else {},
            "art": {k: kodi_image(v) for k, v in art_of(o).items() if v},
            "year": int(fecha.split("-")[0]) if fecha else 0,
            "genre": list(o["genre"]) if isinstance(o.get("genre"), list) else [],
            "rating": rating, "runtime": int(o.get("duration") or 0), "duration": int(o.get("duration") or 0),
            "resume": resume, "playcount": int(o.get("playCount") or 0), "plot": (o.get("plot") or "").strip(),
            "type": {"movies": "movie", "tvshows": "tvshow"}.get(content, "unknown"),
            "filetype": "file" if playable else "directory"}


# ---------- estado: sombra, activo o apagado para (versión de Palantir, estructura de su base) ----------
def load_state():
    path = state_file()
    try:
        sig = os.stat(path).st_mtime_ns
    except OSError:
        sig = None
    if _mem["state"] is None or sig != _mem["state_sig"]:
        try:
            with open(path, encoding="utf-8") as f:
                _mem["state"] = json.load(f)
        except (OSError, ValueError):
            _mem["state"] = {}
        _mem["state_sig"] = sig
    return _mem["state"]


def save_state(key, entry):
    st = dict(load_state())
    st[key] = entry
    try:
        os.makedirs(data_dir(), exist_ok=True)
        flix_common.atomic_write(state_file(), json.dumps(st))
    except Exception as e:  # noqa: BLE001
        log("estado sin guardar: %s" % e)
    _mem["state"], _mem["state_sig"] = st, None      # se relee del disco la próxima vez (otros intérpretes escriben)


def pair_key(st):
    """versión de Palantir + estructura de su base: lo que hay que haber comparado para fiarse"""
    return "%s|%s" % (st["version"], index_meta().get("schema", ""))


def entry(st, kind):
    """lo apuntado de ese tipo de fila para esta versión de Palantir: {'ok': n, 'bad': …, 'checked': hora, …}"""
    return (load_state().get(pair_key(st)) or {}).get(kind) or {}


def verified(e, kind):
    if kind in ("normal", "search"):
        return e.get("ok", 0) >= (SHADOW_OK if kind == "normal" else SEARCH_OK) and bool(e.get("movies")) and bool(e.get("series"))
    return e.get("ok", 0) >= PERSONAL_OK


def mode(st, kind="normal", now=None):
    """'on' (se lista aquí), 'shadow' (se pide a Palantir y se compara) u 'off', para ese tipo de fila"""
    if xbmc.getCondVisibility("Skin.HasSetting(flix_direct_off)") or st is None or st["color"] or kind not in KINDS:
        return "off"                    # con colores de Palantir en las etiquetas no se ha comparado: a Palantir
    e = entry(st, kind)
    if e.get("bad"):
        return "off"
    if verified(e, kind):
        now = time.time() if now is None else now
        return "shadow" if now - e.get("checked", 0) > RECHECK else "on"
    return "shadow"


def norm_label(s):
    return re.sub(r"\[([^\]]*)\]", lambda m: "[" + ", ".join(sorted(x.strip() for x in m.group(1).split(","))) + "]", s or "")


def item_diff(m, t):
    """en qué difieren mi elemento y el de Palantir: (clave, texto) o None. Todo salvo la hora, el orden dentro de los
    corchetes de la etiqueta y la marca de «serie empezada» que la propia skin pone en la caché de Palantir"""
    for k in sorted(set(m) | set(t)):
        if k in VOLATILE:
            continue
        a, b = m.get(k, "<falta>"), t.get(k, "<falta>")
        if k in ("label", "plot"):                      # plot: sin sinopsis lleva la etiqueta
            a, b = norm_label(a), norm_label(b)
        if k == "playCount" and b == flix_common.SHOW_STARTED:
            continue                    # no es de Palantir: la pone flix_progress en SU caché
        if a != b:
            return k, "%s: %r y Palantir %r" % (k, str(a)[:60], str(b)[:60])
    return None


FOLLOW = "play_mis_serieS"


def same(mine, theirs):
    """¿mis elementos son los de Palantir? Se comparan las rutas decodificadas, en su sitio. Única tolerancia de orden:
    las series «en seguimiento» pueden venir permutadas entre sí, porque la skin las reordena en la caché de Palantir
    cuando una lista empieza por una de ellas (flix_progress.fix_palantir_cache; Shield 12-nov, «Populares en Apple
    TV+»): ocupan los mismos huecos y son las mismas. Devuelve (qué difiere o '', ¿es solo progreso?): una diferencia
    solo en lo visto de un título (playCount, %, fecha) puede ser de ese instante (se acaba de parar algo, o Palantir
    contesta de su caché de 10 min) y no dice nada del listado"""
    if len(mine) != len(theirs):
        return "%d elementos y Palantir %d" % (len(mine), len(theirs)), False
    dec = []
    for i, f in enumerate(theirs):
        t, _ = decode(f.get("file", ""))
        if t is None:
            return "elemento %d de Palantir sin ruta legible" % i, False
        dec.append(t)
    follow_m = {m.get("tmdb"): m for m in mine if m.get("action") == FOLLOW}
    follow_t = {t.get("tmdb"): t for t in dec if t.get("action") == FOLLOW}
    pairs = []
    for i, (m, t) in enumerate(zip(mine, dec)):
        if m.get("action") == FOLLOW and t.get("action") == FOLLOW and m.get("tmdb") != t.get("tmdb"):
            continue                    # hueco de serie en seguimiento con otra de ellas: se comparan por título abajo
        pairs.append(("elemento %d" % i, m, t))
    if sorted(follow_m, key=str) != sorted(follow_t, key=str):
        return "series en seguimiento distintas", False
    pairs += [("serie %s" % k, m, follow_t[k]) for k, m in follow_m.items()]
    soft = ""
    for name, m, t in pairs:
        d = item_diff(m, t)
        if d is None:
            continue
        if d[0] in PERSONAL_VOLATILE:
            soft = soft or "%s, %s" % (name, d[1])
            continue
        return "%s, %s" % (name, d[1]), False
    return soft, bool(soft)


def same_personal(mine, theirs):
    """«Seguir viendo» y «Series en seguimiento»: Palantir las sirve de una caché suya de hasta 3 días que además
    retoca la skin (orden, marcas, lo ya visto fuera), así que la lista puede no ser la de ahora mismo. Se comparan,
    título a título, los que estén en las dos: todo lo que no es progreso tiene que coincidir. Devuelve
    (diferencia o '', nº de títulos comparados)"""
    by = {}
    for f in theirs:
        t, _ = decode(f.get("file", ""))
        if t and t.get("tmdb") and t.get("action") not in ACTIONS:
            by[t["tmdb"]] = t
    n = 0
    for m in mine:
        t = by.get(m.get("tmdb"))
        if t is None or m.get("action") in ACTIONS:
            continue
        n += 1
        d = item_diff({k: v for k, v in m.items() if k not in PERSONAL_VOLATILE},
                      {k: v for k, v in t.items() if k not in PERSONAL_VOLATILE})
        if d:
            return "título %s, %s" % (m.get("tmdb"), d[1]), n
    return "", n


def shadow(path, palantir_files):
    """con la respuesta de Palantir a `path` en la mano: se compara con la directa y se apunta. Nunca lanza nada"""
    try:
        item, extra = decode(path)
        kind = kind_of(item, extra)
        st = settings()
        if not kind or st is None or mode(st, kind) != "shadow" or (not palantir_files and kind != "search"):
            return
        if busy() or not ensure_index():
            return
        if kind in ("normal", "search") and flix_common.p3sync_busy():
            return                      # lo visto está cambiando ahora mismo: se compara otra vez
        db = open_db()
        try:
            mine = items_of(item, db, st)
        finally:
            db.close()
        if kind == "search" and not palantir_files:
            if not mine:
                return                  # sin resultados los dos: no dice nada (ni cuenta ni apaga)
            diff, soft = "%d resultados y Palantir ninguno" % len(mine), False
        elif kind in ("normal", "search"):
            diff, soft = same(mine, palantir_files)
        if kind in ("normal", "search"):
            if soft:
                log("comparación sin contar (solo cambia lo visto de un título: %s)" % diff)
                return
        else:
            diff, n = same_personal(mine, palantir_files)
            if not diff and not n:
                return                  # ningún título en común (caché vieja de Palantir, fila vacía): no dice nada
        key = pair_key(st)
        whole = dict(load_state().get(key) or {})
        e = dict(whole.get(kind) or {})
        name = {"normal": "filas normales", "resume": "«Seguir viendo»", "follow": "«Series en seguimiento»",
                "search": "búsquedas"}[kind]
        if diff:
            # una sola diferencia lo apaga para esta versión: mejor lento que distinto
            e.update(bad=diff, at=time.time())
            log("%s: NO coincide con Palantir %s (%s): se le siguen pidiendo a él" % (name, st["version"], diff))
        else:
            before = verified(e, kind)
            e["ok"] = e.get("ok", 0) + 1
            if kind in ("normal", "search"):
                e["movies" if item["action"] == "listado_peliculaS" else "series"] = True
            e["checked"] = time.time()
            if verified(e, kind) and not before:
                log("%s: coinciden con Palantir %s en %d comparaciones: las hace la skin" % (name, st["version"], e["ok"]))
        whole[kind] = e
        save_state(key, whole)
    except Exception as e:  # noqa: BLE001
        log("comparación con Palantir sin hacer: %s: %s" % (type(e).__name__, e))


def personal_on():
    """¿«Seguir viendo» y «Series en seguimiento» se hacen aquí ahora (comprobadas contra Palantir, sin apagar)?"""
    try:
        st = settings()
        return st is not None and mode(st, "resume") == "on" and mode(st, "follow") == "on" and not busy()
    except Exception:  # noqa: BLE001
        return False


def personal_stat():
    """fecha y tamaño de la watched.db que se lee ahora (y de su -wal): si no cambian, lo visto tampoco. Para no
    consultar la base en cada vuelta de la vigilancia del Inicio"""
    path = flix_common.watched_db(watched_db())
    out = [path]
    for f in (path, path + "-wal"):
        try:
            st = os.stat(f)
            out.append((st.st_mtime_ns, st.st_size))
        except OSError:
            out.append(None)
    return tuple(out)


def personal_last():
    """la fecha más reciente de lo visto (películas y capítulos), '' si no hay nada, None si no se puede leer. En
    mayúsculas: flix_p3sync marca las pausas cambiando la Z final por z mientras Palantir las vuelve a bajar. La usa el
    Inicio para repintar las filas personales en cuanto Palantir guarda el progreso al parar un vídeo, sin esperar el
    tiempo fijo de antes (flix_inicio.personal_changed). Solo cuenta que AUMENTE: al empezar a reproducir algo a medias
    Palantir BORRA su fila (la reescribe al parar) y con eso la fila no debe repintarse"""
    try:
        out = ""
        for table in ("movies_watched", "episodes_watched"):
            rows = flix_common.watched_query(watched_db(), "SELECT max(upper(lastPlayed)) FROM %s" % table, timeout=1)
            if rows is None:
                return None
            out = max(out, rows[0][0] or "")
        return out
    except Exception:  # noqa: BLE001
        return None


PERSONAL_QUIET = 0.6        # s de calma tras lo último que guardó Palantir antes de recargar las filas personales


def personal_last_on():
    """personal_last() si las filas personales las hace ahora la skin; None si no (entonces no se adelanta nada)"""
    return personal_last() if personal_on() else None


def personal_watch():
    """estado de personal_changed: stat = última huella barata del fichero, last = fecha más reciente de lo visto,
    moved = desde cuándo hay algo más reciente sin recargar"""
    return {"stat": None, "last": None, "moved": None}


def personal_changed(st, now, playing, stat_fn=None, last_fn=None, quiet=PERSONAL_QUIET):
    """¿hay algo visto más reciente y toca recargar ya las filas personales (modo directo)? La usan las vigilancias
    del Inicio de la TV (flix_inicio.tick) y del táctil (flix_home.personal_tick). Cada vuelta solo se mira la fecha
    del fichero; la base se consulta cuando cambia. True una vez por cambio, sin vídeo en marcha (playing) y `quiet`
    s después del último movimiento"""
    stat = (stat_fn or personal_stat)()
    if stat != st["stat"]:
        first = st["stat"] is None
        st["stat"] = stat
        cur = (last_fn or personal_last_on)()
        if cur is None:
            st["moved"] = None
        elif not first and st["last"] is not None and cur > st["last"]:
            st["moved"] = now
        st["last"] = cur
        return False
    if st["moved"] is not None and not playing and now - st["moved"] >= quiet:
        st["moved"] = None
        return True
    return False


def busy():
    """Palantir actualizando su CONTENIDO (sus cerrojos, o la base a medias: sin vistas): ni se le lee la base ni se
    hace el índice. Su sincronización de lo visto con Trakt NO cuenta: lo visto se lee por flix_common.watched_query
    (la foto mientras dura la del arranque) y es justo cuando «Seguir viendo» y «Series en seguimiento» se repintan"""
    try:
        if HOME.getProperty("p3UpdateLock") == "true" or HOME.getProperty("p3get_moriaLock") == "true":
            return True
        sig = content_sig()
        if not sig:
            return True
        if _mem.get("views_sig") != sig:
            db = sqlite3.connect(uri(content_db()), uri=True, timeout=2)
            try:
                ok = bool(db.execute("SELECT 1 FROM sqlite_master WHERE type = 'view' AND name = 'v_pelis'").fetchone())
            finally:
                db.close()
            if not ok:
                return True
            _mem["views_sig"] = sig
        return False
    except Exception:  # noqa: BLE001
        return True


def list_files(path):
    """la fila en directo (lista de elementos como los de Files.GetDirectory) o None si hay que pedírsela a Palantir"""
    try:
        item, extra = decode(path)
        kind = kind_of(item, extra)
        if not kind:
            return None
        st = settings()
        if st is None or mode(st, kind) != "on" or busy() or not ensure_index():
            return None
        t = time.time()
        db = open_db()
        try:
            items = items_of(item, db, st)
        finally:
            db.close()
        files = [as_file(o, st["labels"]) for o in items]
        log("%s: %d en %.0f ms" % (re.sub(r"\[/?COLOR[^\]]*\]", "", item.get("label") or "").strip() or item.get("nameWidget")
                                   or item["action"], len(files), (time.time() - t) * 1000))
        if files or kind in ("resume", "search"):
            return files                # «Seguir viendo» sin películas a medias, o una búsqueda sin resultados en una
                                        # sección, es una respuesta, no un fallo
        return None                     # vacío: que decida Palantir (su aviso de «sin resultados», o un fallo mío)
    except Exception as e:  # noqa: BLE001
        log("fila a Palantir (%s: %s)" % (type(e).__name__, e))
        return None
