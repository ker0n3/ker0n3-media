"""Reproducir una película de Palantir preguntando si reanudar (como hace Kodi en sus listas).

Desde las filas del skin la película se abría con PlayMedia(ruta): Kodi crea un elemento nuevo sin la posición
de reanudación que Palantir pone en la carátula y empezaba siempre desde el principio sin preguntar.

Uso desde XML: RunScript(special://skin/scripts/flix_play.py,<ruta>,<porcentaje visto>,<duración en s>)
Uso desde Python: flix_play.play(ruta, posicion_s, total_s)
Reanudar = xbmc.Player().play(ruta, ListItem con StartOffset) (Kodi conserva el desplazamiento al resolver
la ruta del plugin); desde el inicio = PlayMedia(ruta,noresume) (sin el «Reanudar desde…» propio de Kodi).
"""
import re
import threading
import time
import sys

import xbmc
import xbmcgui
import xbmcvfs
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import COLOR_RE, decode_route, fresh, watched_movies  # noqa: E402,F401

# Clic en carátula → aviso/ficha cuanto antes: cada RunScript es un intérprete nuevo y en la Shield los imports se
# llevaban ~390 ms de ~490 (22-oct). Aquí nada de flix_progress/flix_rows (pickle, json, urllib.parse…) y las notas
# no cargan urllib hasta pedir una a internet (test_click_imports.py)
WATCHED_DB = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db")
ACTION_PREVIOUS_MENU, ACTION_NAV_BACK = 10, 92
HOME = xbmcgui.Window(10000)
COVER = "flix_trailer_cover"    # Window(home): fanart que tapa la ventana de debajo durante el tráiler (FlixTrailerCover)
# Dos reproducciones a la vez cierran Kodi («Logic error due to two concurrent busydialogs… The application will
# exit»; Shield 26-oct: OK en Black Clover y otra vez antes de que saliera su aviso, ya en Naruto, test_doble_apertura)
LAUNCH = "flix_launch"          # Window(home): hora del clic en un título, hasta que su script decide (aviso o ficha)
LAUNCH_SECS = 30                # marca más vieja = script muerto sin quitarla: no cuenta
LOAD_SECS = 120                 # = flix_playload.MAX_SECS: la capa de carga nunca dura más
LOAD_START = 2.0                # s tras flix_playload.begin en que la rueda de Palantir aún puede no haber salido
LOADING = ("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog) | "
           "Window.IsActive(progressdialog) | Player.HasMedia")



class ResumeDialog(xbmcgui.WindowXMLDialog):
    """FlixResume.xml (tools/gen_resume_dialog.py): 10 = Seguir viendo, 11 = Desde el principio, 14 = Ver ficha;
    Atrás = nada"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.choice = -1

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        try:
            self.getControl(30).setPercent(float(self.props.get("fr_pct") or 0))
        except (RuntimeError, ValueError):
            pass

    def onClick(self, cid):
        if cid in (10, 11, 14):           # 14 y no 12: Kodi escribe «N objetos» en el id 12 de las ventanas Python
            self.choice = {10: 0, 11: 1, 14: 2}[cid]
            self.close()


def fmt(secs):
    secs = int(secs)
    return "%d:%02d:%02d" % (secs // 3600, secs % 3600 // 60, secs % 60)


def choose(title, sub, btn10, btn11="Desde el principio", more="", pct=0, fanart=""):
    """pop-up FlixResume: 0 = seguir viendo, 1 = desde el principio, 2 = ver ficha (solo con more), -1 = Atrás"""
    props = {"fr_title": COLOR_RE.sub("", title or "").strip(), "fr_sub": sub, "fr_btn10": btn10, "fr_btn11": btn11,
             "fr_more": more, "fr_pct": str(int(pct)), "fr_fanart": fanart or ""}
    w = ResumeDialog("FlixResume.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props)
    w.doModal()
    choice = w.choice
    del w
    # Inicio táctil: el gesto Atrás de Android que cierra el pop-up le llega después como pulsación larga (dos, con y
    # sin coordenadas) y abría el menú de otra carátula (móvil, 21-oct): flix_home.py las ignora un rato
    xbmcgui.Window(10000).setProperty("flix_dlg_closed", "%f" % time.time())
    return choice


def ask(position, total, title="", fanart=""):
    sub = "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else "")
    return choose(title, sub, "Reanudar", "Desde el inicio",      # el tiempo ya va en sub
                  pct=100 * position / total if total else 0, fanart=fanart)


def loading_other(now=None):
    """otro título cargando su vídeo: capa de flix_playload puesta y recién pulsado o con algo cargando"""
    stamp = HOME.getProperty("flix_playload")
    now = now or time.time()
    if not fresh(stamp, now, LOAD_SECS):
        return False
    return fresh(stamp, now, LOAD_START) or xbmc.getCondVisibility(LOADING)


def opening_other(now=None):
    """ya se abre otro título: su clic aún no ha sacado aviso ni ficha (LAUNCH) o carga su vídeo"""
    now = now or time.time()
    return fresh(HOME.getProperty(LAUNCH), now, LAUNCH_SECS) or loading_other(now)


def launch_begin():
    mark = "%.3f" % time.time()
    HOME.setProperty(LAUNCH, mark)
    return mark


def launch_end(mark):
    if HOME.getProperty(LAUNCH) == mark:
        HOME.clearProperty(LAUNCH)


def refuse_if_loading():
    """True (y aviso) si otro título está cargando: no se lanza un 2.º vídeo"""
    if not loading_other():
        return False
    xbmc.log("[flix_play] otro título cargando: no lanzo otro vídeo", xbmc.LOGINFO)
    xbmcgui.Dialog().notification("Ker0n3 Media", "Espera: ya se está abriendo otro título", xbmcgui.NOTIFICATION_INFO,
                                  2500)
    return True


def resume_series(play, fanart):
    """«Seguir viendo» de una serie: Palantir pone el capítulo a medias o el siguiente (play_mis_serieS)"""
    if refuse_if_loading():
        return
    import flix_playload
    flix_playload.begin(fanart, play)          # una sola rueda hasta el vídeo
    xbmc.executebuiltin('PlayMedia("%s")' % play)


def start(path, offset=0):
    """reproduce la ruta de Palantir; offset > 0 = reanudar ahí (StartOffset se conserva al resolver el plugin)"""
    if refuse_if_loading():
        return
    HOME.clearProperty("flix_trailer_gen")      # un tráiler cancelado que llegue tarde ya no se para (flix_trailer)
    import flix_playload
    flix_playload.begin(_img(route_info(path).get("fanart")) or HOME.getProperty("flix_open_fanart"), path)
    HOME.setProperty("flix_play_offset", str(int(offset)) if offset > 0 else "")   # reintentos: flix_autoplay salta ahí
    if offset > 0:
        li = xbmcgui.ListItem(path=path)
        li.setProperty("StartOffset", str(int(offset)))
        xbmc.log("[flix_play] reanudar en %s: %s" % (fmt(offset), path[:80]), xbmc.LOGINFO)
        xbmc.Player().play(path, li)
    else:
        # noresume: la ficha ya decidió (progreso de Palantir/Trakt). Sin esto Kodi preguntaba «Reanudar desde…» con
        # su PROPIO marcador local (otro progreso, distinto en cada aparato: «Resume from 00:18:52», móvil 19-oct)
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % path)


def play(path, position=0, total=0, title="", fanart=""):
    if path.startswith("special://skin/"):
        return              # carátula de relleno de una fila que aún carga (flix_home_conf.IDLE_PATH): abría una ficha vacía
    if opening_other():
        xbmc.log("[flix_play] ya se abre otro título: ignoro el clic en %s" % (title or path[:60]), xbmc.LOGINFO)
        return
    mark = launch_begin()
    try:
        _play(path, position, total, title, fanart)
    finally:
        launch_end(mark)


def _play(path, position, total, title, fanart):
    position, total = float(position or 0), float(total or 0)
    if not xbmc.getCondVisibility("Skin.HasSetting(flix_nosheet)"):
        # TV y táctil: pulsar una película abre su ficha (info + Ver / Seguir viendo / Desde el principio)
        return sheet(path, position, total, title, fanart)
    if position > 30 and (not total or position < total - 60):
        choice = ask(position, total, title, fanart)
        if choice < 0:
            return
        if choice == 0:
            start(path, position)
            return
    start(path)


# ---------- ficha de película (TV: xml/FlixMovie.xml, táctil: touch/xml/FlixMovie.xml) ----------
TMDB_IMG = "https://image.tmdb.org/t/p/original"


def _img(v):
    v = v or ""
    return TMDB_IMG + v if v.startswith("/") else v


def route_info(path):
    """el elemento entero de Palantir va dentro de su ruta (JSON con comillas de Python)"""
    try:
        import ast
        return ast.literal_eval(decode_route(path))
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_play] ruta de Palantir ilegible (%s): %s" % (e, path[:80]), xbmc.LOGWARNING)
        return {}


class MovieSheet(xbmcgui.WindowXMLDialog):
    """FlixMovie.xml: 10 = Ver / Seguir viendo, 11 = Desde el principio, 14 = Tráiler, 90 = volver.
    Tráiler (flix_trailer): la ficha sigue abierta con «Cargando…» mientras el addon YouTube lo resuelve y se cierra
    cuando ya hay vídeo (choice 2); sheet() la reabre al acabar. NO usar el id 12: en las ventanas Python Kodi lo
    reserva para «N objetos» (CONTROL_LABELFILES) y al volver de un vídeo pisaba la etiqueta (20-oct)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.trailer = kwargs.get("trailer")
        self.focus = kwargs.get("focus", 10)
        self.choice = -1
        self.loading = False
        self.cancel = False

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        if self.trailer is not None and self.trailer.url:     # si llega después, lo pone TrailerLookup
            self.setProperty("fm_trailer", self.trailer.url)
        try:
            self.getControl(30).setPercent(float(self.props.get("fm_pct") or 0))
        except (RuntimeError, ValueError):
            pass
        self.setFocusId(self.focus)
        if HOME.getProperty(COVER):         # vuelta del tráiler: la ficha ya tapa (tras su fundido); fuera la cubierta
            threading.Timer(0.5, HOME.clearProperty, (COVER,)).start()

    def onClick(self, cid):
        if self.loading:
            return
        if cid in (10, 11):
            self.choice = cid - 10
            self.close()
        elif cid == 14:
            url = self.trailer.url if self.trailer is not None else ""
            if url:
                self.loading = True
                self.setProperty("fm_trailer_btn", "Cargando…")
                threading.Thread(target=self.play_trailer, args=(url,), daemon=True).start()
        elif cid == 90:
            self.close()

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.cancel = self.loading      # Atrás mientras carga el tráiler: se cancela (si empieza, se para)
            self.close()

    def play_trailer(self, url):
        import flix_trailer
        if flix_trailer.start(url, cancelled=lambda: self.cancel):
            HOME.setProperty(COVER, self.props.get("fm_fanart") or "flix/white.png")
            self.choice = 2
            self.close()
            return
        self.loading = False
        self.setProperty("fm_trailer_btn", "Tráiler")


def sheet(path, position, total, title, fanart):
    import sys as _s
    import os as _o
    _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
    info = route_info(path)
    label = info.get("label") or title or ""
    clean_label = COLOR_RE.sub("", label)
    parts = re.findall(r"\[([^\]]*)\]", clean_label)
    name = info.get("title") or re.split(r"\s+\(\d{4}\)|\s+\[", clean_label)[0].strip()
    watched = 0
    # progreso real (watched.db de Palantir), no el que trae la carátula
    try:
        W = watched_movies(WATCHED_DB) or {}
        row = W.get(str(info.get("tmdb") or ""))
        if row:
            watched = int(row[0] or 0)
            total = float(row[2] or 0) or total or float(info.get("duration") or 0)
            position = total * float(row[1] or 0) / 100
        elif W:
            position = 0.0
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_play] progreso: %s" % e, xbmc.LOGWARNING)
    total = total or float(info.get("duration") or 0)
    started = position > 30 and (not total or position < total - 60)
    if started:
        # empezada: pop-up en vez de la ficha (la ficha queda como 3.ª opción)
        choice = choose(name, "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else ""),
                        "Seguir viendo", more="Ver ficha",                 # el tiempo ya va en sub
                        pct=100 * position / total if total else 0, fanart=fanart or _img(info.get("fanart")))
        if choice == 0:
            return start(path, position)
        if choice == 1:
            return start(path)
        if choice != 2:
            return
    quality = parts[-1] if len(parts) >= 2 else ""
    up = quality.upper()
    q = "4K · DV" if "4K" in up and "DV" in up else next(
        (v for k, v in (("4K", "4K"), ("DV", "DV"), ("HDR", "HDR"), ("1080", "1080p"), ("720", "720p")) if k in up), "")
    year = (info.get("fecha") or "")[:4]
    mins = int(float(info.get("duration") or total or 0) // 60)
    rating = str(info.get("rating") or "").split("/")[0]

    def meta_with(rt):              # rt: «Metacritic 82» (flix_ratings) o '' -> la ★ de TMDB de siempre
        return "  ·  ".join(x for x in (year, "%d min" % mins if mins else "", q,
                                         rt or ("★ %s" % rating if rating and rating not in ("0", "0.0") else ""),
                                         parts[0].strip() if len(parts) >= 2 else "") if x and x.strip())
    try:
        import flix_ratings
        rt = flix_ratings.label_for(path)
    except Exception as e:  # noqa: BLE001
        flix_ratings, rt = None, ""
        xbmc.log("[flix_play] nota: %s" % e, xbmc.LOGWARNING)
    meta = meta_with(rt)
    genre = info.get("genre") or []
    props = {
        "fm_title": name,
        "fm_logo": _img(info.get("clearlogo")),
        "fm_fanart": fanart or _img(info.get("fanart")),
        "fm_meta": meta,
        "fm_genre": " / ".join(genre) if isinstance(genre, list) else str(genre),
        "fm_plot": COLOR_RE.sub("", info.get("plot") or ""),
        "fm_state": "started" if started else "watched" if watched else "new",
        "fm_pos": fmt(position) if started else "",
        "fm_total": fmt(total) if total else "",
        "fm_pct": str(int(100 * position / total)) if started and total else "0",
        "fm_btn": ("Seguir viendo  ·  %s" % fmt(position)) if started else "Ver de nuevo" if watched else "Ver",
        "fm_trailer_btn": "Tráiler",
    }
    trailer, focus = TrailerLookup(info), 10
    ask_late = flix_ratings and not rt and flix_ratings.wanted(path)
    while True:
        w = MovieSheet("FlixMovie.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props,
                       trailer=trailer, focus=focus)
        if ask_late:            # sin nota guardada: se pide sin esperar (una vez: no al reabrir tras el tráiler)
            ask_late = False

            def late(w=w):
                r = flix_ratings.label_for(path, wait=flix_ratings.TIMEOUT)
                if r:
                    props["fm_meta"] = meta_with(r)
                    w.setProperty("fm_meta", props["fm_meta"])
            threading.Thread(target=late, daemon=True).start()
        trailer.win = w
        w.doModal()
        choice = w.choice
        trailer.win = None
        del w
        if choice != 2:
            break
        import flix_trailer
        try:
            flix_trailer.watch()            # al acabar (o Atrás) se vuelve a la ficha, en «Tráiler»
        except Exception:  # noqa: BLE001
            HOME.clearProperty(COVER)
            raise
        props["fm_trailer_btn"], focus = "Tráiler", 14
    HOME.clearProperty(COVER)               # por si la ficha no llegó a reabrirse
    if choice == 0:
        start(path, position if started else 0)
    elif choice == 1:
        start(path)


class TrailerLookup:
    """URL del tráiler de la ficha (flix_trailer: TMDB y si no Palantir), buscada en un hilo al abrirla: el botón
    aparece en cuanto llega. Sin el addon YouTube ni se busca (sin botón, como antes)."""

    def __init__(self, info):
        self.url, self.win = "", None
        if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
            return
        tmdb, palantir = str(info.get("tmdb") or ""), info.get("trailer") or ""

        def run():         # flix_trailer (urllib) se importa aquí: la ficha no espera a esos imports
            try:
                import flix_trailer
                self.url = flix_trailer.resolve("movie", tmdb, palantir)
            except Exception as e:  # noqa: BLE001
                xbmc.log("[flix_play] tráiler: %s" % e, xbmc.LOGWARNING)
                self.url = "plugin://plugin.video.youtube/play/?video_id=%s" % palantir if palantir else ""
            w = self.win
            if w is not None and self.url:
                w.setProperty("fm_trailer", self.url)
        threading.Thread(target=run, daemon=True).start()


def resume_focused(resume_label):
    """la pregunta «Reanudar desde… / Reproducir desde el principio» de Kodi (capítulo empezado de la pantalla de serie,
    elemento de una rejilla) sale con el estilo genérico y junto al dedo: DialogContextMenu.xml la cierra y aquí se
    hace la nuestra, centrada, con el elemento enfocado. resume_label: su 1.er botón («Reanudar desde 00:12:34»)"""
    end = time.time() + 2
    while time.time() < end and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
        xbmc.sleep(50)
    cid = xbmc.getInfoLabel("System.CurrentControlId")
    c = "Container(%s).ListItem." % cid if cid.isdigit() else "ListItem."
    path = xbmc.getInfoLabel(c + "FileNameAndPath")
    m = re.search(r"(?:(\d+):)?(\d+):(\d\d)\s*$", resume_label or "")
    position = (int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + int(m.group(3))) if m else 0
    if not path or not position:
        xbmc.log("[flix_play] reanudar: sin elemento o sin tiempo (%r, %r)" % (path[:60], resume_label), xbmc.LOGINFO)
        return
    dur = xbmc.getInfoLabel(c + "Duration(secs)")
    total = float(dur) if dur.isdigit() else 0.0
    title = xbmc.getInfoLabel(c + "Label")
    fanart = xbmc.getInfoLabel(c + "Art(fanart)") or xbmcgui.Window(10000).getProperty("flix_open_fanart")
    choice = choose(title, "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else ""),
                    "Seguir viendo", pct=100 * position / total if total else 0, fanart=fanart)
    if choice == 0:
        start(path, position)
    elif choice == 1:
        start(path)


def resume_of(f):
    """(posición, total) de un elemento JSON-RPC (propiedad resume)"""
    r = f.get("resume") or {}
    return r.get("position") or 0, r.get("total") or 0


if __name__ == "__main__" and sys.argv[1:2] == ["resume"]:
    resume_focused(sys.argv[2] if len(sys.argv) > 2 else "")
elif __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    title = sys.argv[4] if len(sys.argv) > 4 else ""
    fanart = sys.argv[5] if len(sys.argv) > 5 else ""
    try:
        pct = float(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] else 0.0
        dur = float(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3] else 0.0
    except ValueError:
        pct, dur = 0.0, 0.0
    # desde el XML solo hay porcentaje entero: se redondea hacia atrás (reanuda como mucho ~1 % antes)
    pos = max(0.0, (pct - 1) * dur / 100.0) if pct > 0 and dur > 0 else 0.0
    play(path, pos, dur, title, fanart)
