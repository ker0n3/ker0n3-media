"""Utilidades de caché sin Kodi (para poder probarlas con pytest): claves, frescura, limpieza, comparación de
listados y escritura atómica con temporal único (dos procesos a la vez no pueden dejar un JSON mezclado:
auditoría PY-NUEVO-01).
"""
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import atomic_write  # noqa: E402,F401  (aquí desde el lote 2: lo usan otros scripts)

DAY = 86400


def key_of(path, keep_headers=False):
    """clave de caché de una ruta: sin el parámetro &reload= (cambia en cada sesión)"""
    return re.sub(r"&reload=[^&]*", "", path) + ("#h" if keep_headers else "")


def is_fresh(entry, now=None, ttl=1800):
    """entry = [marca de tiempo, items]"""
    if not entry:
        return False
    now = time.time() if now is None else now
    try:
        return now - float(entry[0]) < ttl
    except (TypeError, ValueError, IndexError):
        return False


def purge(cache, now=None, max_age=DAY, ages=None):
    """quita del dict las entradas de más de max_age (o rotas); devuelve cuántas quitó. ages = [(prefijo de la clave,
    max_age)]: otra edad para esas entradas"""
    now = time.time() if now is None else now
    old = []
    for k, v in cache.items():
        limit = next((a for pre, a in ages or () if k.startswith(pre)), max_age)
        try:
            if now - float(v[0]) > limit:
                old.append(k)
        except (TypeError, ValueError, IndexError, KeyError):
            old.append(k)
    for k in old:
        del cache[k]
    return len(old)


class file_lock:
    """cerrojo entre scripts de Kodi (hilos del mismo proceso: flock va por fichero abierto, así que se excluyen)
    para leer, mezclar y escribir un fichero compartido sin perder lo que escribió otro. Si no se consigue en
    `wait` s (o no hay fcntl), se sigue sin él: nunca bloquea la carga de filas"""

    def __init__(self, path, wait=5.0):
        self.path, self.wait, self.fh = path + ".lock", wait, None

    def __enter__(self):
        try:
            import fcntl
            self.fh = open(self.path, "a")
            end = time.time() + self.wait
            while True:
                try:
                    fcntl.flock(self.fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    return self
                except OSError:
                    if time.time() > end:
                        break
                    time.sleep(0.05)
        except (ImportError, OSError):
            pass
        if self.fh:
            self.fh.close()
            self.fh = None
        return self

    def __exit__(self, *exc):
        if self.fh:
            try:
                import fcntl
                fcntl.flock(self.fh, fcntl.LOCK_UN)
            finally:
                self.fh.close()
                self.fh = None
        return False


def stamp(entry):
    try:
        return float(entry[0])
    except (TypeError, ValueError, IndexError, KeyError):
        return 0.0


def merge_newer(disk, mine, keys):
    """en `disk` (lo que hay en el fichero) pone las entradas `keys` de `mine` que sean más nuevas"""
    for k in keys:
        if k in mine and stamp(mine[k]) >= stamp(disk.get(k)):
            disk[k] = mine[k]
    return disk


def same_items(a, b):
    """mismos títulos en el mismo orden (por ruta): si es así no hace falta repintar la fila"""
    return [f.get("file") for f in a or []] == [f.get("file") for f in b or []]


def save_json(path, obj, lock):
    """serializa obj con el lock cogido (otro hilo puede estar añadiendo entradas) y lo escribe de golpe.
    Devuelve False si no se pudo (nunca lanza: guardar la caché no debe tumbar la carga de filas)."""
    try:
        with lock:
            text = json.dumps(obj)
        atomic_write(path, text)
        return True
    except Exception:  # noqa: BLE001
        return False
