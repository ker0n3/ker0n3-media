"""Ajustes → «Color de los detalles»: el color de acento de la skin (lo que antes era siempre rojo: barra del menú
lateral, barras de progreso, ✓ de visto, interruptores, botón principal de la táctil…).

Se guarda en Skin.String(flix_accent) con la clave; las variables FlixAccentR / FlixAccentR30 / FlixAccentOn /
FlixAccentName de xml/Includes_Flix.xml (TV y táctil) lo convierten en color, así que el cambio se ve al momento.
COLORS es la única lista: test_color_acento.py comprueba que las variables dicen lo mismo.
"""
import os
import sys

# (clave, nombre, color ARGB) — el primero es el de siempre (vacío = rojo)
COLORS = [
    ("rojo", "Rojo", "FFE50914"),
    ("azul", "Azul", "FF1E88E5"),
    ("verde", "Verde", "FF2EBD59"),
    ("morado", "Morado", "FF8E44EC"),
    ("naranja", "Naranja", "FFFF7A1A"),
    ("amarillo", "Amarillo", "FFFFC107"),
    ("rosa", "Rosa", "FFEC407A"),
    ("turquesa", "Turquesa", "FF00BFA5"),
]


def light(argb):
    """¿color claro? (luminancia relativa > 0,3): encima va texto negro (FlixAccentOn) para que se lea"""
    def lin(c):
        c /= 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (int(argb[i:i + 2], 16) for i in (2, 4, 6))
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b) > 0.3


def current(value):
    """clave guardada -> índice en COLORS (vacía o desconocida = rojo)"""
    keys = [k for k, _, _ in COLORS]
    return keys.index(value) if value in keys else 0


def pick():
    import xbmc
    import flix_picker
    cur = current(xbmc.getInfoLabel("Skin.String(flix_accent)"))
    labels = ["[COLOR %s]●[/COLOR]  %s%s" % (hexa, name, "  ·  por defecto" if n == 0 else "")
              for n, (_key, name, hexa) in enumerate(COLORS)]
    i = flix_picker.pick("Color de los detalles", labels,
                         "El color de la barra del menú, las barras de progreso, la marca de visto, los interruptores y "
                         "los botones destacados. Cambia al momento.", cur)
    if i >= 0:
        xbmc.executebuiltin("Skin.SetString(flix_accent,%s)" % COLORS[i][0])


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    pick()
