"""Lista para elegir una opción con el estilo Flix (ventana FlixPicker.xml, TV y táctil).

pick(título, [etiquetas], ayuda, posición inicial, current=opción puesta ahora) -> índice elegido, o -1 con Atrás.
La opción puesta ahora (current) lleva un ✓ a la derecha aunque se mueva el foco (TV-25; FlixPicker.xml lo pinta con
ListItem.Property(current)); las listas de «Añadir…» no tienen opción puesta y no la pasan.
No usa Dialog().select: en esta skin DialogSelect.xml está rediseñado para el selector de versiones de Palantir.
"""
import xbmc
import xbmcgui
import xbmcvfs

LIST = 100
from flix_common import A_BACK  # noqa: E402,F401  (los códigos de Atrás, comunes: TV-28)


class PickerWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = kwargs.get("title", "")
        self.labels = kwargs.get("labels", [])
        self.help = kwargs.get("help", "")
        self.select = kwargs.get("select", 0)
        self.current = kwargs.get("current", -1)
        self.choice = -1

    def onInit(self):
        self.setProperty("title", self.title)
        self.setProperty("help", self.help)
        lst = self.getControl(LIST)
        lst.reset()
        lst.addItems(items(self.labels, self.current))
        if 0 < self.select < len(self.labels):
            lst.selectItem(self.select)
        self.setFocusId(LIST)

    def onClick(self, cid):
        if cid == LIST:
            self.choice = self.getControl(LIST).getSelectedPosition()
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.choice = -1
            self.close()
            return
        super().onAction(action)


def items(labels, current=-1):
    """ListItems de la lista; el de la opción puesta ahora, con Property(current)=1 (✓ a la derecha)"""
    out = []
    for n, lab in enumerate(labels):
        li = xbmcgui.ListItem(lab)
        if n == current:
            li.setProperty("current", "1")
        out.append(li)
    return out


def pick(title, labels, help_text="", select=0, current=-1):
    """current: índice de la opción puesta ahora (lleva ✓); sin select, el foco empieza en ella"""
    if not labels:
        return -1
    if current >= 0 and not select:
        select = current
    win = PickerWindow("FlixPicker.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                       title=title, labels=labels, help=help_text, select=select, current=current)
    win.doModal()
    choice = win.choice
    del win
    return choice


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")
