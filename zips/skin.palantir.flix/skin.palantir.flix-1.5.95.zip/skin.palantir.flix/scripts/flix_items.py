"""Carátula de Palantir -> ListItem de Kodi (filas de las secciones, del Inicio y del buscador).

Aquí y no en flix_search (revisión 29-oct ARR-19, lote 21): flix_section, y con él el Inicio TV, importaban el
buscador entero (urllib, difflib, unicodedata, hilos… ~17 ms propios en proot) solo por to_listitem. flix_search la
vuelve a exportar (from flix_items import …), así que flix_search.to_listitem sigue siendo la misma función."""
import os
import re
import sys

import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import clean  # noqa: E402


def brackets(label):
    return re.findall(r"\[([^\]]*)\]", clean(label))


def clean_title(label):
    return re.split(r"\s+\(\d{4}\)|\s+\[", clean(label))[0].strip()


def quality_from_label(label):
    m = brackets(label)
    up = (m[-1] if m else "").upper()
    if "4K" in up and "DV" in up:
        return "4K · DV"
    for key, val in (("4K", "4K"), ("DV", "DV"), ("HDR", "HDR"), ("1080", "1080p"), ("720", "720p")):
        if key in up:
            return val
    return ""


def langs_from_label(label):
    m = brackets(label)
    return m[0] if len(m) >= 2 else ""


def to_listitem(f):
    label = f.get("label", "")
    li = xbmcgui.ListItem(label)
    li.setPath(f.get("file", ""))
    li.setArt(f.get("art") or {})
    li.setProperty("IsPlayable", "false")
    li.setProperty("P3Titulo", clean_title(label))
    li.setProperty("P3Calidad", quality_from_label(label))
    li.setProperty("P3IdiomaStr", langs_from_label(label))
    li.setProperty("filetype", f.get("filetype", "file"))
    tag = li.getVideoInfoTag()
    tag.setTitle(clean_title(label))
    tag.setPlot(f.get("plot") or "")
    if f.get("year"):
        tag.setYear(int(f["year"]))
    if f.get("rating"):
        tag.setRating(float(f["rating"]))
    if f.get("genre"):
        tag.setGenres(list(f["genre"]))
    if f.get("duration"):
        tag.setDuration(int(f["duration"]))
    if f.get("mpaa"):
        tag.setMpaa(f["mpaa"])
    if f.get("premiered"):
        tag.setPremiered(f["premiered"])
    tag.setMediaType("tvshow" if f.get("filetype") == "directory" else "movie")
    r = f.get("resume") or {}
    if r.get("position"):
        tag.setResumePoint(float(r["position"]), float(r.get("total") or 0))
    if f.get("playcount"):
        tag.setPlaycount(int(f["playcount"]))   # ✓ de vista en el póster (secciones y buscador; faltaba)
    return li
