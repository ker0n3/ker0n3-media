"""La stdlib y scripts/ delante de las carpetas de addons en el sys.path de los RunScript de la skin (revisión 29-oct
ARR-02, lote 6).

Los scripts de la skin se lanzan con RunScript(special://skin/scripts/…), sin addon, y Kodi («Script invoked without
an addon. Adding all addon modules installed to python path as fallback») pone delante de todo las carpetas de módulos
de los addons instalados: 35 en la Shield (script.module.*, plugin.video.asgard, plugin.video.youtube), 11 en la Fire
TV, 7 en el móvil; después scripts/ y al final la stdlib. Cada import de algo que aún no está cargado (json, sqlite3,
un flix_*…) miraba antes esas 35 carpetas: los stat al importar se multiplicaban por 4-6 (medido en proot).

Al importarlo (lo primero de cada script que se lanza con RunScript, justo después de poner scripts/ delante) las
carpetas de addons pasan al FINAL, en el mismo orden: no se quita ninguna, solo se reordena, y lo que solo esté en un
addon se sigue encontrando. Lo de la skin (scripts/ y scripts/vendor, con segno para los QR) no se mueve. Comprobado en
la Shield (29-oct): ningún módulo de esas carpetas se llama como uno de la stdlib o de la skin, así que cada import
sigue cargando el mismo fichero. Sin carpetas de addons (pytest, o un Kodi que deje de añadirlas) no hace nada.
Solo os y sys: lo importa cada RunScript.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _norm(p):
    return os.path.normcase(os.path.normpath(p))


def is_addon_dir(p, here=HERE):
    """¿carpeta de módulos de un addon (…/addons/<id con punto>/…) que no es de la skin?"""
    if not isinstance(p, str) or not p:
        return False
    n, h = _norm(p), _norm(here)
    if n == h or n.startswith(h.rstrip("\\/") + os.sep):
        return False
    parts = p.replace("\\", "/").split("/")
    return any(a == "addons" and "." in b for a, b in zip(parts, parts[1:]))


def reorder(path=None, here=HERE):
    """pasa al final, en su orden, las carpetas de addons de path (sys.path: la MISMA lista); cuántas"""
    path = sys.path if path is None else path
    moved = [p for p in path if is_addon_dir(p, here)]
    if moved:
        path[:] = [p for p in path if not is_addon_dir(p, here)] + moved
    return len(moved)


reorder()
