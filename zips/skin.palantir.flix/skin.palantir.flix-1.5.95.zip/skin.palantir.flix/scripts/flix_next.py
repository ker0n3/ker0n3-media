"""Botón "Siguiente capítulo" del OSD: salta a 2 s del final y deja que el capítulo ACABE.
Al terminar, Palantir (ajuste NextEpisode) abre él solo el selector del siguiente capítulo y el autoplay
lo reproduce: es el mismo camino que cuando el capítulo acaba por sí mismo (visto en la Shield 17-oct)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re

import xbmc
import xbmcgui

player = xbmc.Player()
episode = bool(xbmc.getInfoLabel("VideoPlayer.Episode")) or re.search(r"\d+x\d+", xbmc.getInfoLabel("Player.Title")) is not None
if not episode and xbmc.getCondVisibility("Integer.IsGreater(Playlist.Length(video),1)"):
    xbmc.executebuiltin("PlayerControl(Next)")      # lista de reproducción normal (no Palantir)
elif player.isPlayingVideo():
    total = player.getTotalTime()
    if total > 10:
        xbmcgui.Window(10000).setProperty("flix_upnext_choice", "next")   # flix_autoplay.py deja pasar el siguiente
        player.seekTime(total - 2)
        xbmc.log("[flix_next] salto al final (%.0f s) -> siguiente capítulo de Palantir" % total, xbmc.LOGINFO)
