"""Filas del Inicio (versión TV y táctil): orden, ocultar, eliminar, añadir y elementos por fila.

RunScript(special://skin/scripts/flix_home_order.py,edit)   -> editor único (flix_editor.py,menu)
RunScript(special://skin/scripts/flix_home_order.py,check)  -> al arrancar: reaplica la configuración si una
                                                               actualización del skin trajo FlixInicio.xml de serie
Configuración en special://profile/addon_data/<skin>/home_order.json; formato y reglas en flix_home_conf.py
(lógica pura, con tests en tools/tests).

TV: las filas son includes FlixRowStatic en xml/FlixInicio.xml (entre FLIX_ROWS_BEGIN y FLIX_ROWS_END), la ventana
Python del Inicio (flix_inicio.py). Este script reescribe ese trozo (flix_home_conf.render_tv) y avisa a la ventana
(Window(home).Property(fi_reload)) para que se vuelva a abrir con las filas nuevas: ya no recarga el skin.
La copia de serie del trozo de filas se guarda en addon_data (home_rows_default.xml) para restaurar filas.
Táctil: flix_home.py lee la misma configuración y monta sus filas al cargar.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re

import xbmc
import xbmcgui
import xbmcvfs

import flix_home_conf as hc  # noqa: E402
# temporal único por escritura: el de aquí era «.tmp<pid>» y los dos check() del arranque (Startup.xml y flix_inicio)
# corren en el mismo proceso de Kodi, así que compartían temporal para FlixInicio.xml (revisión 29-oct ARR-13/DAT-15)
from flix_common import atomic_write  # noqa: E402,F401

HOME = xbmcgui.Window(10000)
SKIN_ID = xbmc.getSkinDir()
TOUCH = SKIN_ID.endswith(".touch")
SKIN = xbmcvfs.translatePath("special://skin/")
DATA = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
CONF = os.path.join(DATA, "home_order.json")
DEFAULT_ROWS = os.path.join(DATA, "home_rows_default.xml")
INICIO_XML = os.path.join(SKIN, "xml", "FlixInicio.xml")
BEGIN, END = "<!-- FLIX_ROWS_BEGIN", "<!-- FLIX_ROWS_END -->"
SIG_RE = re.compile(r"[ \t]*<!-- FLIX_ORDER_SIG ([^ ]*) -->\n?")


def log(msg):
    xbmc.log("[flix_home_order] %s" % msg, xbmc.LOGINFO)


def load_conf():
    """configuración normalizada, o None si el usuario nunca la ha guardado"""
    try:
        with open(CONF, encoding="utf-8") as fh:
            return hc.normalize(json.load(fh))
    except (OSError, ValueError):
        return None


def lite():
    """Ajustes → «Modo ligero» (flix_lite.py)"""
    return xbmc.getCondVisibility("Skin.HasSetting(flix_lite)")


def effective(conf):
    """la configuración con la que se monta el Inicio: la guardada, o la del modo modesto si está puesto (la guardada
    no se toca: vuelve al apagarlo)"""
    conf = conf or hc.normalize(None)
    return hc.lite_conf(conf) if lite() else conf


def save_conf(conf):
    os.makedirs(DATA, exist_ok=True)
    atomic_write(CONF, json.dumps(hc.normalize(conf)))


def ordered(rows, conf):
    """compatibilidad: rows = [(id, label, …)] -> en el orden guardado (las nuevas al final)"""
    if not conf:
        return list(rows)
    pos = {i: k for k, i in enumerate(conf["order"])}
    return sorted(rows, key=lambda r: pos.get(r[0], 1000 + rows.index(r)))


# ---------- TV: FlixInicio.xml ----------
def _region(text):
    a = text.index("-->", text.index(BEGIN)) + 4    # tras el comentario de la marca (ocupa 2 líneas)
    b = text.index(END)
    b = text.rindex("\n", 0, b) + 1
    return a, b


def tv_default_blocks():
    """filas de serie [{id, label, path, src, top10, extra}] en su orden"""
    with open(INICIO_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    region = text[a:b]
    if not SIG_RE.search(region) or not os.path.exists(DEFAULT_ROWS):
        # FlixInicio.xml de serie (instalación o actualización): su trozo de filas es el nuevo "de serie"
        os.makedirs(DATA, exist_ok=True)
        atomic_write(DEFAULT_ROWS, SIG_RE.sub("", region))
    with open(DEFAULT_ROWS, encoding="utf-8") as fh:
        return hc.parse_tv_blocks(fh.read())


def tv_apply(conf):
    conf = hc.normalize(conf)
    rows = hc.compose(tv_default_blocks(), conf)
    if not any(not r["hidden"] for r in rows):
        return False
    region = hc.render_tv(rows, conf["items"])
    with open(INICIO_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    atomic_write(INICIO_XML, text[:a] + "\t\t\t\t<!-- FLIX_ORDER_SIG %s -->\n" % hc.signature(conf) + region + text[b:])
    log("FlixInicio.xml reescrito: %s (elementos %d)" % ([r["id"] for r in rows if not r["hidden"]], conf["items"]))
    return True


def _read(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def tv_current_sig():
    with open(INICIO_XML, encoding="utf-8") as fh:
        m = SIG_RE.search(fh.read())
    return m.group(1) if m else None


# ---------- táctil ----------
def touch_default_rows():
    with open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8") as fh:
        return json.load(fh)


def default_rows():
    """filas de serie como dicts con al menos id y label"""
    return touch_default_rows() if TOUCH else tv_default_blocks()


# ---------- arranque ----------
def check():
    """antes de abrir el Inicio TV (flix_inicio.py) y al arrancar: si FlixInicio.xml no lleva la configuración guardada
    (actualización del skin = trozo de serie, o se cambió en otro sitio) la escribe. True si lo reescribió."""
    try:
        import flix_random_rows
        flix_random_rows.promote_saved()        # Filas al azar: el sorteo preparado, antes de montar el Inicio
    except Exception as e:  # noqa: BLE001
        log("filas al azar: %s" % e)
    if TOUCH:
        return False
    conf = load_conf()
    try:
        factory = not SIG_RE.search(_read(INICIO_XML))
        if not conf and not factory and not lite():
            return False
        conf = effective(conf)
        if (factory or tv_current_sig() != hc.signature(conf)) and tv_apply(conf):
            return True
    except Exception as e:  # noqa: BLE001
        log("check: %s" % e)
    return False


def apply_saved():
    """tras cambiar las filas del Inicio: el táctil las monta al momento; la TV reescribe FlixInicio.xml y el Inicio
    se vuelve a abrir con ellas al volver a él (flix_inicio.py mira fi_reload)"""
    if TOUCH:
        HOME.setProperty("fh_reorder", "1")             # flix_home.py lo aplica al momento (lo mira cada segundo)
        return
    conf = load_conf()
    if (conf or lite()) and tv_apply(effective(conf)):
        HOME.setProperty("fi_reload", "1")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        if check():
            HOME.setProperty("fi_reload", "1")      # Inicio ya abierto: que se rehaga con las filas escritas
    else:
        import flix_editor
        flix_editor.run("menu")          # acceso viejo (flix_home_order.py,edit)
