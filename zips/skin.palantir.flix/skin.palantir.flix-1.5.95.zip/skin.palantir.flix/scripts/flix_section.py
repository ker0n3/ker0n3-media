"""Sección de Palantir desplegada en filas (versión TV, ventana FlixSection.xml).

Uso: RunScript(special://skin/scripts/flix_section.py,<clave de la sección>)   (flix_sections: sections.json)
Las filas son los submenús de la sección en Palantir, con el orden y los interruptores elegidos en Ajustes →
Secciones del menú → Editar filas (flix_sections_conf.apply_rows).
Se carga SOLO al entrar: las filas se piden a Palantir una a una (Palantir atiende de una en una, ~4 s cada
una) y van apareciendo; con caché de 30 min (flix_rows.fetch) volver a entrar es instantáneo.
  fila de listado  -> carátulas (película = reproducir, serie = temporadas vía flix_series.py)
  fila de submenú  -> tarjetas (sagas, calidad, letras…): al abrir una, su rejilla de carátulas
  último "Más…" de un listado -> tarjeta "Ver más" que abre la página siguiente en rejilla
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import threading
import time

import xbmc
import xbmcgui

import flix_cache  # noqa: E402
import flix_common  # noqa: E402
import flix_rows  # noqa: E402
import flix_sections_conf  # noqa: E402
from flix_items import to_listitem  # noqa: E402  (sin el buscador entero: revisión 29-oct ARR-19)

HOME = xbmcgui.Window(10000)
FIRST, NROWS = 5401, 16
RETRY = 5490            # botón de reserva (FlixSection.xml): foco mientras no hay filas; OK = reintentar
ROW_LIMIT = 40
from flix_common import A_BACK  # noqa: E402,F401  (comunes: TV-28; flix_inicio lo importa de aquí)
A_CONTEXT = (117,)              # mantener OK / tecla menú: menú KER0N3 de la carátula, como en el Inicio (28-oct)
MENU_WAIT = 180                 # s: lo más que se espera a que acabe flix_menu (diálogos de Palantir) para repintar
LOADING, MISSING = flix_rows.LOADING, flix_rows.MISSING     # tarjeta de una fila que aún no ha llegado / que no dio nada


def log(msg):
    xbmc.log("[flix_section] %s" % msg, xbmc.LOGINFO)


def small_screen():
    """pantalla de 1080 o menos (Fire TV): las carátulas de las filas se dibujan a 168x252 y Palantir las da a 342x513.
    En la Shield (4K) y el móvil se quedan como estaban"""
    global _SMALL
    if _SMALL is None:
        try:
            _SMALL = 0 < int(xbmc.getInfoLabel("System.ScreenWidth") or 0) <= 1920
        except ValueError:
            _SMALL = False
    return _SMALL


_SMALL = None


def small_art(art):
    """póster y miniatura de TMDB a w185 (~ -65 % de memoria de textura por carátula; auditoría 22-oct C-02). Solo en
    las filas: la ficha y el selector siguen con las suyas"""
    out = dict(art)
    for k in ("poster", "thumb"):
        v = out.get(k) or ""
        if "image.tmdb.org" in v:
            out[k] = v.replace("%2fw342%2f", "%2fw185%2f").replace("/w342/", "/w185/")
    return out


def make_item(f, row):
    if small_screen() and f.get("art"):
        f = dict(f, art=small_art(f["art"]))
    li = to_listitem(f)
    if flix_rows.is_more(f):
        li.setLabel("Ver más")
        li.setProperty("card", "text")
        li.setProperty("open", "grid")
    elif row["kind"] == "coll":
        li.setProperty("card", "text" if flix_rows.is_generic(f) else "band")
        li.setProperty("open", "grid")
    elif f.get("filetype") == "directory":
        li.setProperty("open", "series")
    else:
        li.setProperty("open", "play")
    return li


def placeholder(label):
    """tarjeta de texto de una fila sin títulos todavía: no abre nada (onClick mira «open»)"""
    li = xbmcgui.ListItem(label)
    li.setProperty("card", "text")
    li.setProperty("open", "")
    return li


class SectionWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.var = kwargs.get("var")
        self.title = kwargs.get("title")
        self.rconf = kwargs.get("rconf") or {}     # filas elegidas (orden / apagadas)
        self.t0 = kwargs.get("t0")       # hora de la pulsación (main): la 1.ª carga apunta «lista en X s» desde ahí
        self.stop = False
        self.started = False
        self.rows = {}           # id de lista -> fila
        self.slot_of = {}        # ruta de la fila -> id de lista
        self.shown = {}          # id de lista -> títulos pintados

    def onInit(self):
        self.setProperty("fs_title", self.title)
        if not self.started:
            self.started = True
            threading.Thread(target=self.load, daemon=True).start()
        else:
            self.repaint()

    def repaint(self):
        """tras recargar la skin (actualización automática con la sección abierta) Kodi vuelve a montar la ventana
        desde el XML con las listas vacías y llama otra vez a onInit: se repinta lo que había y se devuelve el foco.
        Antes quedaba en negro, sin foco, y solo respondía Atrás (auditoría 22-oct A-06). Solo con "0": al volver de
        un vídeo onInit puede llegar con la ventana del vídeo aún delante y entonces da "" """
        for lid, row in sorted(self.rows.items()):
            if xbmc.getInfoLabel("Container(%d).NumItems" % lid) != "0":
                continue
            files = self.shown.get(lid)
            if files:
                items = [make_item(f, row) for f in files]
            else:
                items = [placeholder(MISSING if getattr(self, "loaded", False) else LOADING)]
            log("fila %s vacía al volver (skin recargada): repinto" % row["label"])
            self.refill(lid, items)
        if self.focus_id() is None:
            self.setFocusId(FIRST if self.getProperty("fs_row1") else RETRY)

    def load(self, refocus=True):
        try:
            self._load(refocus)
        except RuntimeError:
            if not self.stop:
                raise
            # sección cerrada mientras cargaba: Kodi ya destruyó la ventana (antes: traceback en el log, PY-10)

    def _load(self, refocus=True):
        """1) lo guardado al momento, aunque esté caducado; 2) Palantir solo para lo caducado o sin caché, por detrás,
        en orden, sin mover la selección (auditoría REND-02: antes ~40 s con la caché caducada).
        refocus=False: repintado tras el menú KER0N3 (el foco se queda en la carátula)"""
        t0 = getattr(self, "t0", None) or time.time()      # recargas (reintentar, tras el menú): desde que empiezan
        self.t0 = None
        self.setProperty("fs_empty", "")
        self.setProperty("fs_error", "")
        self.setProperty("fs_status", "cargando…")
        # Favoritos / Listas Trakt con el menú guardado caducado: se pinta ya con él y el de Palantir se pide después
        # de las filas (abajo); antes se esperaba ~11 s en «Cargando Favoritos…» con las filas en la caché (APA-01)
        recheck = flix_rows.live_stale(self.var)
        # ¿Palantir no contesta o no hay nada? (TV-12: antes las dos cosas salían como «Sin contenido»)
        failed, answered = False, False
        flix_common.dir_failed(reset=True)
        try:
            rows = flix_sections_conf.apply_rows(flix_rows.section_rows(self.var, stale_ok=True, live_later=True),
                                                 self.rconf)
        except Exception as e:  # noqa: BLE001  (antes el hilo moría y la sección se quedaba en «Cargando…»)
            log("menú de %s: %s" % (self.title, e))
            rows, failed = [], True
        failed = flix_common.dir_failed(reset=True) or failed
        # todas las filas cogen su hueco ya, en su orden y con «Cargando…»: se puede bajar sin esperar a Palantir
        # (antes cada fila cogía hueco al llegar: no había adónde bajar y salían en orden de llegada)
        for row in rows[:NROWS]:
            if self.stop:
                return
            self.place(row)
        if rows and not self.stop and refocus:
            self.setFocusId(FIRST)
        pending = []
        for row in rows:
            if self.stop:
                return
            files, fresh = flix_rows.peek(row["path"])
            if files:
                self.show(row, files, "caché" if fresh else "caché antigua")
            if not fresh:
                pending.append(row)
        # menú caducado: primero las filas del guardado y después el menú (~10 s de Palantir en la Shield); antes, al
        # revés, y sin filas guardadas la 1.ª salía a los 14 s (Carlos, 30-oct). Lo que cambie se recoloca al final
        failed, answered = self.fetch_rows(pending, failed, answered)
        if recheck and not self.stop:
            failed, answered = self.fetch_rows(self.recheck_menu(rows, []), failed, answered)
        flix_rows.flush()
        self.setProperty("fs_status", "")
        self.loaded = True
        if self.stop:
            return
        for lid, files in self.shown.items():
            if files is None:                       # Palantir no dio nada para esta fila
                self.refill(lid, [placeholder(MISSING)])
        if not any(self.shown.values()):
            # botón 5490 (FlixState): «Palantir no responde» si nada contestó, si no «Sin contenido»; OK = reintentar
            self.setProperty("fs_error", "1" if failed and not answered else "")
            self.setProperty("fs_empty", "1")
            self.setFocusId(RETRY)
            log("sección %s sin filas%s" % (self.title, " (Palantir no responde)" if failed and not answered else ""))
        log("%s: lista en %.1f s" % (self.title, time.time() - t0))     # fin de C5 sin depuración (DAT-22)

    def fetch_rows(self, pending, failed, answered):
        """pide a Palantir las filas de pending, en orden, y las pinta; devuelve (failed, answered) al día"""
        for k, row in enumerate(pending):
            if self.stop:
                break
            try:
                files, _ = flix_rows.fetch(row["path"], force=True, save=False)
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row["label"], e))
                failed = True
                continue
            if flix_common.dir_failed(reset=True):
                failed = True
            else:
                answered = True
            if files and not self.stop:
                self.show(row, files, "Palantir")
            if k % 4 == 3:
                flix_rows.flush(keep=True)      # vienen más: sin releer el fichero si nadie lo ha tocado (DAT-02)
        return failed, answered

    def recheck_menu(self, rows, pending):
        """pide a Palantir el menú de la sección (estaba guardado y caducado: las cuentas y qué categorías tienen algo
        cambian) y, si cambió, recoloca las filas (relayout). Devuelve las filas que quedan por pedir"""
        try:
            new = flix_sections_conf.apply_rows(flix_rows.section_rows(self.var, force=True), self.rconf)
        except Exception as e:  # noqa: BLE001
            log("menú de %s: %s" % (self.title, e))
            return pending
        if self.stop or not new:
            return pending              # Palantir no dio nada: se queda lo guardado
        if [(r["label"], r["path"]) for r in new[:NROWS]] == [(r["label"], r["path"]) for r in rows[:NROWS]]:
            return pending
        log("menú de %s cambiado: %s -> %s" % (self.title, [r["label"] for r in rows], [r["label"] for r in new]))
        changed = self.relayout(new)
        keep = {r["path"] for r in new}
        pending = [r for r in pending if r["path"] in keep and r not in changed]
        for row in changed:             # filas nuevas (o con otra ruta): lo guardado al momento, Palantir después
            files, fresh = flix_rows.peek(row["path"])
            if files:
                self.show(row, files, "caché" if fresh else "caché antigua")
            if not fresh:
                pending.append(row)
        order = {r["path"]: k for k, r in enumerate(new)}
        return sorted(pending, key=lambda r: order.get(r["path"], 0))

    def relayout(self, rows):
        """recoloca las filas con el menú nuevo, en su orden. Las que siguen (misma etiqueta) conservan lo pintado y
        el foco (Kodi no puede mover una lista: si cambia de hueco se vuelve a pintar en el suyo); las nuevas salen con
        «Cargando…»; los huecos que sobran se vacían (fila oculta). Devuelve las filas nuevas o con otra ruta"""
        focus = self.focus_id()
        old_rows, old_items = dict(self.rows), dict(self.items_of())
        old = {r["label"]: (lid, r) for lid, r in old_rows.items()}
        shown = {r["label"]: self.shown.get(lid) for lid, r in old_rows.items()}
        flabel = old_rows[focus]["label"] if focus in old_rows else None
        fpos = self.sel_pos(focus) if flabel is not None else 0
        self.rows, self.slot_of, self.shown = {}, {}, {}
        self.items_of().clear()
        changed = []
        for k, row in enumerate(rows[:NROWS]):
            lid = FIRST + k
            prev = old.get(row["label"])
            self.rows[lid], self.slot_of[row["path"]] = row, lid
            self.setProperty("fs_row%d" % (k + 1), row.get("title") or row["label"])
            if prev is None or prev[1]["path"] != row["path"]:
                changed.append(row)
            files = shown.get(row["label"]) if prev is not None else None
            self.shown[lid] = files
            if prev is not None and prev[0] == lid and prev[1]["path"] == row["path"]:
                self.items_of()[lid] = old_items.get(lid, [])       # misma fila en su sitio: no se toca
                continue
            items = [make_item(f, row) for f in files] if files else [placeholder(LOADING)]
            self.refill(lid, items, fpos if row["label"] == flabel else 0)
        for k in range(len(rows[:NROWS]), len(old_rows)):
            lid = FIRST + k                 # hueco que sobra: vacío (la fila se oculta); el foco se pone abajo
            self.setProperty("fs_row%d" % (k + 1), "")
            self.getControl(lid).reset()
        if focus is not None and focus in old_rows:
            to = next((lid for lid, r in self.rows.items() if r["label"] == flabel), None)
            self.setFocusId(to or (FIRST if self.rows else RETRY))
        return changed

    def place(self, row):
        """hueco de una fila antes de que lleguen sus títulos (al reintentar, vuelve a «Cargando…»)"""
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            lid = FIRST + len(self.slot_of)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = None
            self.setProperty("fs_row%d" % (lid - FIRST + 1), row.get("title") or row["label"])
        elif self.shown.get(lid) is not None:
            return
        self.refill(lid, [placeholder(LOADING)])

    def focus_id(self):
        try:
            return self.getFocusId() or None
        except RuntimeError:                        # ningún control de la ventana tiene el foco
            return None

    def refill(self, lid, items, pos=0):
        """vacía y rellena una fila. Kodi suelta el foco de una lista vacía: si la fila lo tenía (o nadie lo tiene y
        es la 1.ª) se le devuelve. Sin esto la 1.ª entrada a una sección se quedaba sin responder al mando hasta salir
        y volver (Carlos, 22-oct; desde la 1.5.38: la 1.ª fila coge el foco con «Cargando…» y luego se rellena)"""
        focus = self.focus_id()
        lst = self.getControl(lid)
        lst.reset()
        lst.addItems(items)
        self.items_of()[lid] = list(items)
        if pos > 0:
            lst.selectItem(min(pos, len(items) - 1))
        if focus == lid or (lid == FIRST and focus in (None, RETRY)):
            self.setFocusId(lid)

    def show(self, row, files, origin):
        """pinta una fila: su hueco ya está (place); solo si cambió, conservando la selección"""
        if files and flix_rows.follow_tmdb(files[0]):
            import flix_progress
            files = flix_progress.ordered_follow(files)     # Series en seguimiento: por lo visto de verdad
        files = flix_rows.head(files, ROW_LIMIT)
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            lid = FIRST + len(self.slot_of)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = files
            self.setProperty("fs_row%d" % (lid - FIRST + 1), row.get("title") or row["label"])
            items = [make_item(f, row) for f in files]
            self.getControl(lid).addItems(items)
            self.items_of()[lid] = items
            if lid == FIRST:
                self.setFocusId(lid)
        else:
            if flix_cache.same_items(self.shown.get(lid), files):
                return
            self.shown[lid] = files
            self.refill(lid, [make_item(f, row) for f in files], self.sel_pos(lid))
        log("fila %s [%s]: %d (%s)" % (row["label"], row["kind"], len(files), origin))

    def items_of(self):
        if not hasattr(self, "items"):
            self.items = {}             # id de lista -> ListItems pintados (los nuestros)
        return self.items

    def sel_pos(self, lid):
        """posición seleccionada preguntando a Kodi: ControlList.getSelectedPosition/getSelectedItem usan la lista
        de antes de recargar la skin (actualización automática con la sección abierta) y Kodi se caía (SIGSEGV)"""
        try:
            return max(0, int(xbmc.getInfoLabel("Container(%d).CurrentItem" % lid) or 0) - 1)
        except ValueError:
            return 0

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.stop = True
            self.close()
            return
        if action.getId() in A_CONTEXT and self.focus_id() in self.rows:
            if HOME.getProperty("flix_ctx_auto"):
                super().onAction(action)        # flix_menu abriendo por detrás el menú de Kodi (lista oculta FlixCtx)
                return
            self.open_menu(self.focus_id())
            return
        if self.focus_id() is None:                 # foco perdido: la tecla no iría a ningún sitio
            self.setFocusId(FIRST if self.getProperty("fs_row1") else RETRY)
        super().onAction(action)

    def open_menu(self, lid):
        """menú KER0N3 (flix_menu.py) de la carátula con foco. Las filas son listas de Python sin menú de Kodi: como en
        el Inicio, flix_menu pulsa la opción de Palantir desde una lista oculta (FlixCtx) con el listado de la fila"""
        items = self.items_of().get(lid) or []
        pos = self.sel_pos(lid)
        item = items[pos] if pos < len(items) else None
        path = item.getPath() if item else ""
        if not item or item.getProperty("open") in ("", "grid") or not path.startswith("plugin://plugin.video.palantir3/"):
            return                      # «Cargando…», «Ver más», colecciones: sin menú
        HOME.setProperty("flix_ctx_src", flix_rows.directory(self.rows[lid]["path"], offline=True))     # sin red (DAT-16)
        t0 = time.time()
        xbmc.executebuiltin('RunScript(special://skin/scripts/flix_menu.py,"%s","%s","%s",sec)'
                            % (path, item.getArt("poster"), item.getLabel().replace('"', "'")))
        threading.Thread(target=self.after_menu, args=(t0,), daemon=True).start()

    def after_menu(self, t0):
        """cuando flix_menu acaba (flix_menu_done) se repinta lo que cambió (✓…) sin mover el foco. Un favorito
        quitado lo saca la sección de sus filas: Palantir tarda unos segundos en dar sus listados sin él (Shield,
        28-oct: 1 s después aún salía) y volver a pedírselas lo devolvía a la fila"""
        mon, end = xbmc.Monitor(), t0 + MENU_WAIT
        while not self.stop and time.time() < end and not mon.abortRequested():
            done = HOME.getProperty("flix_menu_done")
            if done and float(done) > t0:
                break
            mon.waitForAbort(0.5)
        else:
            return
        if self.stop:
            return
        change = HOME.getProperty("flix_fav_change").split("|")
        if len(change) == 3 and change[1] == "del" and float(change[0] or 0) > t0:
            self.drop_title(change[2])
            return
        self.load(refocus=False)

    def drop_title(self, key):
        """saca el título key («content:tmdb») de las filas de FAVORITOS pintadas, sin pedir nada (en Películas o en
        un Top 10 la película sigue estando aunque deje de ser favorita)"""
        for lid, files in list(self.shown.items()):
            if not flix_rows.is_fav_path(self.rows[lid]["path"]):
                continue
            keep = [f for f in files or [] if flix_rows.title_key(f) != key]
            if files and len(keep) != len(files):
                self.shown[lid] = keep
                self.refill(lid, [make_item(f, self.rows[lid]) for f in keep] or [placeholder(MISSING)],
                            self.sel_pos(lid))
                log("fila %s: quitado %s (favorito)" % (self.rows[lid]["label"], key))

    def onClick(self, control_id):
        if control_id == RETRY and self.getProperty("fs_empty") == "1":
            threading.Thread(target=self.load, daemon=True).start()
            return
        if control_id not in self.rows:
            return
        items, pos = self.items_of().get(control_id) or [], self.sel_pos(control_id)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open"):     # «Cargando…» / «No disponible»
            return
        path, how = item.getPath(), item.getProperty("open")
        HOME.setProperty("flix_title", item.getProperty("P3Titulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.title, item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def main():
    t0 = time.time()        # la pulsación (sin el arranque del intérprete ni los imports: eso solo con depuración)
    import flix_sections
    import xbmcvfs
    key = sys.argv[1] if len(sys.argv) > 1 else "peliculas"
    s = flix_sections.section(key) or flix_sections.section("peliculas")
    import flix_sections_conf
    log("%s: abierta" % flix_sections_conf.shown(s))     # principio de C5 sin depuración (revisión 29-oct DAT-22)
    HOME.setProperty("flix_section", flix_sections_conf.shown(s))
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                        var=s["src"], title=flix_sections_conf.shown(s), rconf=s.get("rows") or {}, t0=t0)
    win.doModal()
    win.stop = True
    del win


if __name__ == "__main__":
    main()
