"""Ajustes → «Color de los detalles»: el color de acento de la skin (lo que antes era siempre rojo: barra del menú
lateral, interruptores, botón principal de la táctil…; las barras de progreso, el ▶ de empezada y el ✓ de visto no
cambian: TV-09 + TCT-21).

Se guarda en Skin.String(flix_accent) con la clave; las variables FlixAccentR / FlixAccentR30 / FlixAccentOn /
FlixAccentName de xml/Includes_Flix.xml (TV y táctil) lo convierten en color, así que el cambio se ve al momento.
COLORS es la única lista: test_color_acento.py comprueba que las variables dicen lo mismo.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

# (clave, nombre, color ARGB) — el primero es el de siempre (vacío = rojo)
COLORS = [
    ("rojo", "Rojo", "FFE50914"),
    ("azul", "Azul", "FF1E88E5"),
    ("verde", "Verde", "FF2EBD59"),
    ("morado", "Morado", "FF8E44EC"),
    ("naranja", "Naranja", "FFFF7A1A"),
    ("amarillo", "Amarillo", "FFFFC107"),
    ("rosa", "Rosa", "FFEC407A"),
    ("turquesa", "Turquesa", "FF00BFA5"),
]


# aparato de Eren (Skin.String(flix_brand)=eren) sin color elegido: verde neón, como FlixAccentR (TV-26: el ajuste
# decía «Rojo»). Vacío = sin elegir; elegir «Verde neón» lo deja vacío otra vez
EREN = ("", "Verde neón", "FF39FF14")

# ayuda de «Color de los detalles» (TV-11): lo que cambia de verdad en cada versión. Las barras de progreso van en
# este color (Carlos 30-oct); lo empezado (▶ y «En progreso»), siempre en rojo y lo visto, en verde (TV-09 + TCT-21).
# La de la TV la usa también tools/gen_settings.py
HELP_TV = ("El color de la barra del menú lateral, los interruptores, las barras de progreso y la fila que mueves al "
           "ordenar. Lo empezado va siempre en rojo, y lo visto, en verde. Cambia al momento.")
HELP_TOUCH = ("El color de los botones destacados, los interruptores, las barras de progreso y las teclas «Buscar» y "
              "«Hecho». Lo empezado va siempre en rojo, y lo visto, en verde. Cambia al momento.")


def choices(brand=""):
    """opciones del selector: la primera es la de sin elegir (rojo; en el aparato de Eren, verde neón)"""
    return [EREN] + COLORS if brand == "eren" else list(COLORS)


def light(argb):
    """¿color claro? (luminancia relativa > 0,3): encima va texto negro (FlixAccentOn) para que se lea"""
    def lin(c):
        c /= 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (int(argb[i:i + 2], 16) for i in (2, 4, 6))
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b) > 0.3


def tint(argb, key=""):
    """tono claro del color, para texto sobre su versión translúcida (FlixAccentR30; chip REMUX táctil, TCT-06): 45 %
    hacia el blanco. El rojo se queda en FF6B6B, el de siempre"""
    if key == "rojo":
        return "FFFF6B6B"
    r, g, b = (int(argb[i:i + 2], 16) for i in (2, 4, 6))
    return "FF" + "".join("%02X" % round(c + (255 - c) * 0.45) for c in (r, g, b))


def current(value, brand=""):
    """clave guardada -> índice en choices(brand) (vacía o desconocida = la primera: rojo, o verde neón con Eren)"""
    keys = [k for k, _, _ in choices(brand)]
    return keys.index(value) if value in keys else 0


def pick():
    import xbmc
    import flix_picker
    brand = xbmc.getInfoLabel("Skin.String(flix_brand)")
    opts = choices(brand)
    cur = current(xbmc.getInfoLabel("Skin.String(flix_accent)"), brand)
    labels = ["[COLOR %s]●[/COLOR]  %s%s" % (hexa, name, "  ·  por defecto" if n == 0 else "")
              for n, (_key, name, hexa) in enumerate(opts)]
    touch = xbmc.getSkinDir().endswith(".touch")          # la táctil es otra skin (como flix_editor)
    i = flix_picker.pick("Color de los detalles", labels, HELP_TOUCH if touch else HELP_TV, current=cur)
    if i >= 0:
        key = opts[i][0]
        xbmc.executebuiltin("Skin.SetString(flix_accent,%s)" % key if key else "Skin.Reset(flix_accent)")


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    pick()
