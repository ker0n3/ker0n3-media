"""Explorador de los menús reales de Palantir para añadir una fila al Inicio (editor flix_home_order.py).

browse() -> (nombre, ruta) o None. En cada carpeta, la primera opción es "Añadir «X» como fila (N títulos)" si la
carpeta lista títulos; el resto son sus subcarpetas. Atrás sube un nivel; arriba del todo cancela.
Qué carpetas se ofrecen lo decide flix_home_conf.classify (sin búsquedas, ajustes ni "Más…").
Palantir atiende de una en una (~3-4 s por carpeta): se muestra el aviso de carga mientras tanto.
"""
import os
import sys

import xbmc
import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_home_conf as hc  # noqa: E402
import flix_picker  # noqa: E402

ROOT = "plugin://plugin.video.palantir3/"
HELP = "Abre un menú y elige «Añadir … como fila». Atrás sube un nivel."


def log(msg):
    xbmc.log("[flix_palantir_browse] %s" % msg, xbmc.LOGINFO)


def listing(path):
    try:
        return flix_common.list_dir(path, ["title"])      # JSON-RPC común (revisión 29-oct DAT-20)
    except ValueError:
        return []                                          # respuesta que no es JSON: nada, como antes


def browse():
    stack = [("Palantir", ROOT)]
    seen = {}                                   # ruta -> listado (volver atrás no repite la llamada a Palantir)
    while stack:
        label, path = stack[-1]
        if path not in seen:
            flix_picker.busy(True)
            try:
                seen[path] = hc.classify(listing(path))
            finally:
                flix_picker.busy(False)
        folders, titles = seen[path]
        add = ["Añadir «%s» como fila (%d %s)" % (label, titles, "título" if titles == 1 else "títulos")] \
            if titles and len(stack) > 1 else []
        labels = add + [f["label"] for f in folders]
        if not labels:
            xbmcgui.Dialog().notification("Palantir", "Aquí no hay nada que añadir", xbmcgui.NOTIFICATION_INFO, 2500)
            stack.pop()
            continue
        title = " › ".join(s[0] for s in stack[1:]) or "Explorar Palantir"
        k = flix_picker.pick(title, labels, HELP)
        if k < 0:
            stack.pop()
            continue
        if add and k == 0:
            name = xbmcgui.Dialog().input("Nombre de la fila", defaultt=label).strip()
            if name:
                log("fila añadida: %s" % name)
                return name, path
            continue
        f = folders[k - len(add)]
        stack.append((f["label"], f["file"]))
    return None
