"""Lista de títulos del buscador: dónde está la base de Palantir y dónde se guarda la lista (formato TITLES_VERSION).
Aparte de flix_search para que flix_titles_prewarm (cada arranque) mire si hay que rehacerla sin importar el buscador
entero (~143 ms en proot; revisión 29-oct ARR-08). flix_search las importa de aquí: una sola definición."""
import xbmc

CONTENT_DB = "special://profile/addon_data/script.module/settings.xml"   # base de contenido de Palantir (SQLite)
TITLES_FILE = "special://profile/addon_data/%s/search_titles2.json" % xbmc.getSkinDir()   # 2: otro formato que el de la 1.5.84
TITLES_VERSION = 2  # 2: con ids TMDB y vistas base (la caché de la 1.5.84 se rehace sola)
