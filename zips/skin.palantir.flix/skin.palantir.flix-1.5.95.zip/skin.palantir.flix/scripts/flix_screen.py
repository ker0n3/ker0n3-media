"""Pantalla de la skin táctil: qué resolución de la skin usa Kodi en este aparato y cómo pasar las coordenadas del
dedo (píxeles de pantalla) a coordenadas de la skin. Lo usan el Inicio táctil (flix_home.py) y la ficha de serie
(flix_series_sheet.py)."""
import xbmcgui

# = <res> de tools/build_touch.py: Kodi elige la de aspecto más parecido a la pantalla
RES = [(1920, 1080), (1920, 1200), (2160, 1080), (2338, 1080), (2400, 1080), (2520, 1080)]


def skin_res():
    """(ancho, alto) de la skin y (ancho, alto) de la pantalla"""
    sw, sh = xbmcgui.getScreenWidth(), xbmcgui.getScreenHeight()
    w, h = min(RES, key=lambda r: abs(r[0] / r[1] - sw / sh))
    return w, h, sw, sh


def to_skin(x, y, res):
    """coordenadas del dedo -> coordenadas de la skin; res = skin_res()"""
    w, h, sw, sh = res
    return x * w / sw, y * h / sh
