"""Prioridad de reproducción (Ajustes): reproducción automática sí/no, orden de calidades con interruptor por calidad
y remux sí/no. La usa flix_autoplay.py para elegir versión en el selector de Palantir.

RunScript(special://skin/scripts/flix_quality.py)          -> editor único (flix_editor.run("quality"))
RunScript(special://skin/scripts/flix_quality.py,migrate)  -> al arrancar (first_run.py): pasa el modo viejo
                                                              (4k / 1080) al formato nuevo y escribe el resumen

Guardado por aparato en los ajustes del skin:
  Skin.String(flix_autoplay)        "on" / "off" (valores viejos "4k" y "1080" = on)
  Skin.String(flix_quality_order)   "4k|dv|-4khdr10|…" (orden; "-" = desactivada; sin comas: Skin.SetString corta
                                    el valor en la primera coma)
  Skin.HasSetting(flix_remux)       remux (R) permitidos dentro de su calidad
  Skin.String(flix_quality_summary) resumen para la pantalla de Ajustes ("4K → DV → 4K HDR10 …")

Calidades que trae Palantir (caché del móvil, 19-oct, 484 títulos): 1080p, DV HDR10, DV HDR10+, DV, 4K HDR10, 4K,
HD, 4K HDR10+, 1080p HDR10, más SD; variantes (R) = remux, (IMAX) = cuenta como su calidad base, (3D) = «Resto».
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

TIERS = (
    ("4k", "4K"),
    ("dv", "Dolby Vision"),
    ("4khdr10", "4K HDR10"),
    ("4khdr10p", "4K HDR10+"),
    ("dvhdr10", "Dolby Vision HDR10"),
    ("dvhdr10p", "Dolby Vision HDR10+"),
    ("1080", "1080p"),
    ("720", "720p (HD)"),
    ("rest", "Resto (SD, 3D…)"),
)
KEYS = [k for k, _ in TIERS]
LABEL = dict(TIERS)
SHORT = {"4k": "4K", "dv": "DV", "4khdr10": "4K HDR10", "4khdr10p": "4K HDR10+", "dvhdr10": "DV HDR10",
         "dvhdr10p": "DV HDR10+", "1080": "1080p", "720": "720p", "rest": "Resto"}
DEFAULT = [(k, True) for k in KEYS]     # = el modo «4k» de antes (más 720p y resto al final, antes del selector)


def tier(q):
    """calidad del selector ('4K HDR10+', 'DV HDR10 (R) (IMAX)', '1080p (3D)', 'HD'…) -> clave de TIERS"""
    u = (q or "").upper()
    if "3D" in u:
        return "rest"
    hdr = "hdr10p" if "HDR10+" in u else "hdr10" if "HDR" in u else ""
    if u.startswith("4K"):
        return "4k" + hdr
    if u.startswith("DV"):
        return "dv" + hdr
    if u.startswith("1080"):
        return "1080"
    if u.startswith("720") or u.startswith("HD"):
        return "720"
    return "rest"


def parse(text):
    """'4k|-dv|…' -> [(clave, encendida)] con todas las claves (las que falten, al final y encendidas)"""
    out, seen = [], set()
    for part in (text or "").replace(",", "|").split("|"):
        part = part.strip().lower()
        on = not part.startswith("-")
        k = part.lstrip("-")
        if k in LABEL and k not in seen:
            out.append((k, on))
            seen.add(k)
    if not out:
        return list(DEFAULT)
    return out + [(k, True) for k in KEYS if k not in seen]


def dump(order):
    return "|".join(("" if on else "-") + k for k, on in order)


def summary(order):
    on = [SHORT[k] for k, o in order if o]
    if not on:
        return "ninguna calidad activa"
    return " → ".join(on[:4]) + (" …" if len(on) > 4 else "")


def legacy_order(mode):
    """orden equivalente al modo viejo: '1080' = solo 1080p"""
    if (mode or "").strip().lower() == "1080":
        return [("1080", True)] + [(k, False) for k in KEYS if k != "1080"]
    return list(DEFAULT)


def is_on(mode):
    return (mode or "").strip().lower() not in ("off", "")


class Conf:
    def __init__(self, auto=True, order=None, remux=False):
        self.auto, self.order, self.remux = auto, list(order or DEFAULT), remux


def _quality(label):
    import re
    m = re.search(r"\((.+?)\)\s*\[", label)
    return (m.group(1) if m else "").strip()


def _remux(label):
    return "(R)" in _quality(label)


def _esp(label):
    import re
    m = re.search(r"\)\s*\[([^\]]*)\]", label)
    return "Esp" in (m.group(1) if m else "")


def preferred(items, conf):
    """índices aptos en orden: calidades encendidas en su orden; dentro de cada una, primero con audio Esp y, si hay
    remux permitidos, la versión normal antes que el remux. Sin autoplay: []"""
    if not conf.auto:
        return []
    out = []
    for k, on in conf.order:
        if not on:
            continue
        idxs = [i for i, l in enumerate(items) if tier(_quality(l)) == k and (conf.remux or not _remux(l))]
        for esp in (True, False):
            for rx in (False, True):
                out += [i for i in idxs if _esp(items[i]) == esp and _remux(items[i]) == rx]
    return out


def fallback_order(items, conf, first=None):
    """orden completo de reintentos: aptos, luego el resto (desde el elegido a mano si lo hay; calidades apagadas
    incluidas: mejor que nada), remux al final"""
    n = len(items)
    rest = list(range(first + 1, n)) + list(range(0, first)) if first is not None else list(range(n))
    out = preferred(items, conf)
    out += [i for i in rest if i not in out and not _remux(items[i])]
    out += [i for i in rest if i not in out]
    return out


# ---------- Kodi ----------
def load():
    import xbmc
    mode = xbmc.getInfoLabel("Skin.String(flix_autoplay)")
    text = xbmc.getInfoLabel("Skin.String(flix_quality_order)")
    order = parse(text) if text else legacy_order(mode)
    return Conf(is_on(mode), order, xbmc.getCondVisibility("Skin.HasSetting(flix_remux)"))


def save(conf):
    import xbmc
    xbmc.executebuiltin("Skin.SetString(flix_autoplay,%s)" % ("on" if conf.auto else "off"))
    xbmc.executebuiltin("Skin.SetString(flix_quality_order,%s)" % dump(conf.order))
    xbmc.executebuiltin("Skin.SetString(flix_quality_summary,%s)" % summary(conf.order).replace(",", " "))
    xbmc.executebuiltin("%s(flix_remux)" % ("Skin.SetBool" if conf.remux else "Skin.Reset"))


def migrate():
    """modo viejo (4k / 1080) -> formato nuevo, una vez; y resumen siempre al día"""
    import xbmc
    if not xbmc.getInfoLabel("Skin.String(flix_quality_order)") or not xbmc.getInfoLabel("Skin.String(flix_quality_summary)"):
        save(load())


def edit():
    """Ajustes → «Prioridad de reproducción»: el editor único (flix_editor_sources.QualitySource), mismo diseño que
    «Personalizar menú e Inicio» (antes ventana propia FlixQuality.xml, Carlos 24-oct)"""
    import flix_editor
    flix_editor.run("quality")


def upnext():
    """Ajustes → «Aviso de siguiente capítulo»: a cuántos segundos del final sale (flix_autoplay.upnext_secs)"""
    import xbmc
    import flix_autoplay
    import flix_picker
    choices = flix_autoplay.UPNEXT_CHOICES
    cur = flix_autoplay.upnext_secs()
    labels = ["%d segundos antes del final%s" % (s, "  ·  por defecto" if s == flix_autoplay.UPNEXT_SECS else "")
              for s in choices]
    i = flix_picker.pick("Aviso de siguiente capítulo", labels,
                         "Cuándo sale el aviso para pasar al siguiente capítulo. Si los créditos de tu serie son largos, "
                         "más segundos; si sale antes de que acabe el capítulo, menos.",
                         current=choices.index(cur))
    if i >= 0:
        xbmc.executebuiltin("Skin.SetString(flix_upnext_secs,%d)" % choices[i])


if __name__ == "__main__":     # RunScript lo ejecuta como __main__; importado (tests, autoplay) no hace nada
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    {"migrate": migrate, "upnext": upnext}.get(mode, edit)()
