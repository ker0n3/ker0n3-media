"""Secciones de Palantir desplegadas en filas (compartido TV / táctil).

section_rows(var) lee el menú de una sección (rutas fijas p3Peliculas… de Includes_Palantir3.xml) y lo
convierte en filas:
  kind "list" = listado de títulos (action listado_peliculaS / listado_serieS) -> fila de carátulas
  kind "coll" = submenú (sagas, especiales, calidad, géneros, alfabético…) -> fila de tarjetas; al abrir
               una tarjeta se ve su rejilla de carátulas (vista 51)
Las cabeceras ("Películas de Dibujos:") agrupan; "Buscar por título" se omite (ya está el buscador).
fetch() cachea en disco 30 min: cada llamada a Palantir consulta además la API de GitHub (60/h por IP).
peek() da lo guardado aunque esté caducado (las secciones lo enseñan al momento y refrescan por detrás).
Con save=False fetch() no escribe el fichero: el que llama hace flush() cada pocas filas (antes se reescribían
~2,6 MB tras cada fila). flush() quita lo de más de un día y escribe de forma atómica.
"""
import ast
import json
import os
import re
import time
import urllib.parse
import sys

import xbmc
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# skin_var: una sola copia en flix_common, con el XML leído una vez por proceso (revisión 29-oct DAT-19)
from flix_common import COLOR_RE, clean, decode_route, list_dir, skin_var  # noqa: E402,F401
import flix_cache  # noqa: E402

# tarjeta de una fila que aún no ha llegado / que no dio nada: la misma en la Sección de TV (flix_section) y en el
# Inicio y las secciones táctiles (flix_home; revisión 29-oct TCT-08)
LOADING, MISSING = "Cargando…", "No disponible"

CACHE_TTL = 1800            # filas personales (Seguir viendo, Series en seguimiento…): cambian al ver algo
STATIC_TTL = 6 * 3600       # las demás (Top 10, novedades, plataformas, géneros…): como mucho cambian a diario.
# cuánto se guarda una fila aunque esté caducada: se enseña al momento y se refresca por detrás. Era 1 día y con el
# Inicio «Aleatoria» (listas de TMDB) ya nadie refrescaba las filas de las secciones: entrar en Películas o Anime tras
# un día salía todo en «Cargando…» (Carlos, 24-oct). Son siempre las mismas rutas (se reemplazan, no se acumulan).
# Las listas de TMDB pesan mucho (5 de 8 MB en la Fire TV) y se sortean en cada arranque: siguen en 1 día
KEEP = 7 * 86400
KEEP_TMDB = 86400
# Cada fila pedida a Palantir es una consulta a la API de GitHub (60/h por IP, compartida por todos los aparatos de
# casa): antes se pedían las ~18 cada 30 min (auditoría 22-oct C-07, aprobado por Carlos)
TMDB_LIST = "flix://tmdb/"     # filas con listas de TMDB hechas de títulos de Palantir (flix_tmdblists.py)
PERSONAL_RE = re.compile(r"no_finalizadas|Mis_|Seguimiento|watchlist|favorit|historial", re.I)
FAV_RE = re.compile(r"favorit", re.I)       # rutas de Favoritos de Palantir (menú y sus listas)
TRAKT_RE = re.compile(r"listas_trakt|listado_trakt")     # menú «Listas Trakt.tv» de Palantir y cada lista
# «Películas favoritas (9)» / «Watchlist Películas [1]»: la cuenta sale fuera de la etiqueta (la configuración de
# filas va por etiqueta y la cuenta cambia al añadir) y las que están a 0 no son fila («Música (0)»…)
COUNT_RE = re.compile(r"^(.*?)\s*[(\[](\d+)[)\]]$")
# secciones cuyo menú cambia (cuentas, listas nuevas): guardado y caducado se pide otra vez al entrar
LIVE_MENUS = ("p3Favoritos", "p3PathTrakt")
# entradas de menú que no son listados sino acciones (abren el teclado): nunca fila
SKIP_ACTIONS = ("add_lista_trakt",)


def route_of(path):
    """ruta de Palantir decodificada ("" si no es de Palantir o no se entiende)"""
    if not path.startswith("plugin://plugin.video.palantir3/?"):
        return ""
    try:
        return decode_route(path.split("&")[0]) or ""
    except Exception:  # noqa: BLE001
        return ""


def title_key(f):
    """«content:tmdb» de la ruta de Palantir de un título ("" si no se entiende): el mismo título en filas distintas"""
    try:
        info = ast.literal_eval(decode_route(f.get("file", "")))
    except Exception:  # noqa: BLE001
        return ""
    return "%s:%s" % (info.get("content"), info["tmdb"]) if isinstance(info, dict) and info.get("tmdb") else ""


def is_fav_path(path):
    """¿es un listado de Favoritos de Palantir? (menú de Favoritos o una de sus categorías)"""
    return bool(FAV_RE.search(route_of(path)))


def ttl_of(path):
    """caducidad de la caché de una fila según sea personal o no (CACHE_TTL / STATIC_TTL)"""
    if path.startswith(TMDB_LIST):
        return STATIC_TTL
    route = route_of(path)
    if not route:
        return CACHE_TTL
    return CACHE_TTL if PERSONAL_RE.search(route) else STATIC_TTL
# «2»: las rutas guardadas antes de la 1.4.52/1.0.71 pueden llevar progreso a None (flix_progress) y Palantir revienta
# al reproducirlas -> caché nueva; la vieja (rows_cache.json) la borra first_run al arrancar
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache2.json" % xbmc.getSkinDir())
GENERIC_ART = "plugin.video.palantir3/resources/media"   # icono genérico de Palantir (calidad, letras, "Más…")
SECTION_VARS = {"Películas": "p3Peliculas", "Series": "p3Series", "Anime": "p3Anime",
                "Dibujos": "p3Dibujos", "Documentales": "p3Documentales"}
PROPS = ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file", "plot", "duration"]


def log(msg):
    xbmc.log("[flix_rows] %s" % msg, xbmc.LOGINFO)




def action_of(path):
    try:
        m = re.search(r'"action": \'?([^\',}]+)', decode_route(path))
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


_cache = None
_dirty = set()      # claves que este proceso ha pedido a Palantir y aún no ha guardado
# Lo que este proceso dejó en el fichero en su último guardado con más guardados detrás (flush(keep=True)), para no
# volver a leerlo entero si nadie lo ha cambiado (revisión 29-oct DAT-02; json.load de 33-126 ms con 8 MB y la Shield
# ya tiene 10 MB). {clave: (marca, texto JSON de la entrada)}: texto y no los objetos, porque _progress corrige en
# sitio las filas que se enseñan y el fichero tiene que salir igual, byte a byte, que releyéndolo.
_saved = None
_saved_sig = None   # huella del fichero justo después de ese guardado: (ruta, inodo, mtime en ns, tamaño)


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _file_sig():
    try:
        st = os.stat(CACHE_FILE)
    except OSError:
        return None
    return (CACHE_FILE, st.st_ino, st.st_mtime_ns, st.st_size)


def _sig_ok(before, after, nbytes):
    """¿la huella de después de escribir sirve para saber, la próxima vez, que nadie ha tocado el fichero? Todos los
    que escriben rows_cache2.json (flix_rows, expire, flix_progress.fix_rows_cache) lo hacen con el cerrojo y de forma
    atómica (fichero nuevo = inodo nuevo). Ante cualquier duda, no: el siguiente guardado lee el fichero como siempre.
      - tenía que haber fichero antes y el inodo tiene que haber cambiado (si no, el sistema no da inodos de verdad);
      - la hora tiene que tener fracción de segundo (por segundos, dos escrituras seguidas no se distinguirían);
      - el tamaño tiene que ser el de lo que acabamos de escribir."""
    return bool(before and after) and after[0] == before[0] and after[1] != before[1] and \
        after[2] % 1000000000 != 0 and after[3] == nbytes


def _dumps(parts):
    """json.dumps de un dict a partir de {clave: (marca, texto JSON de la entrada)}: el mismo texto, byte a byte
    (separadores ', ' y ': ' por defecto; claves y valores con el mismo codificador). Un solo join: ~10 MB se copian
    una vez"""
    out = ["{"]
    for k, (_s, t) in parts.items():
        out += (json.dumps(k), ": ", t, ", ")
    if len(out) > 1:
        out[-1] = "}"
    else:
        out.append("}")
    return "".join(out)


def _forget():
    global _saved, _saved_sig
    _saved = _saved_sig = None


def _cache_save(keep=False):
    """guarda lo pedido por este proceso MEZCLADO con el fichero (gana lo más nuevo), con cerrojo. Antes se volcaba
    la copia entera del proceso: el Inicio, que vive toda la sesión, pisaba lo que guardaban las secciones y
    flix_progress (auditoría 22-oct B-05 / REND-04), y reescribía ~2,6 MB aunque no hubiera nada nuevo (C-04).
    keep=True: vienen más guardados enseguida (cada 4 filas). Se recuerda lo escrito y, si en el siguiente la huella
    del fichero es la misma, no se vuelve a leer ni a volcar entero: se mezcla y se purga sobre lo recordado (DAT-02).
    Sin keep (el último del lote, fetch con save) la copia se suelta: pesa tanto como el fichero"""
    global _saved, _saved_sig
    if not _dirty:
        if not keep:
            _forget()
        return
    try:
        with flix_cache.file_lock(CACHE_FILE) as lock:
            locked = getattr(lock, "fh", None) is not None
            before = _file_sig()
            parts = _saved if locked and _saved is not None and before == _saved_sig else None
            _forget()
            keys = list(_dirty)
            if parts is None:
                # como siempre: el fichero entero
                try:
                    with open(CACHE_FILE, encoding="utf-8") as fh:
                        disk = json.load(fh)
                except (OSError, ValueError):
                    disk = {}
                if not isinstance(disk, dict):
                    disk = {}
                flix_cache.merge_newer(disk, _cache, keys)
                flix_cache.purge(disk, max_age=KEEP, ages=[(TMDB_LIST, KEEP_TMDB)])
                if keep and locked:
                    parts = {k: (v[0], json.dumps(v)) for k, v in disk.items()}   # tras purge: todas con v[0]
                    text = _dumps(parts)
                else:
                    text = json.dumps(disk)
            else:
                # nadie ha escrito desde nuestro último guardado: lo recordado ES el fichero
                disk = parts
                flix_cache.merge_newer(disk, _cache, keys)
                flix_cache.purge(disk, max_age=KEEP, ages=[(TMDB_LIST, KEEP_TMDB)])
                for k in keys:
                    v = disk.get(k)
                    if v is not None and not isinstance(v, tuple):
                        disk[k] = (v[0], json.dumps(v))
                text = _dumps(disk)
            flix_cache.atomic_write(CACHE_FILE, text)
            if keep and locked:
                after = _file_sig()
                if _sig_ok(before, after, len(text) if text.isascii() else len(text.encode("utf-8"))):
                    _saved, _saved_sig = parts, after
        _dirty.difference_update(keys)
        for k, v in disk.items():               # y lo nuevo de los demás, para el siguiente peek
            if flix_cache.stamp(v) > flix_cache.stamp(_cache.get(k)):
                _cache[k] = json.loads(v[1]) if isinstance(v, tuple) else v
    except OSError as e:
        _forget()
        log("no guardo caché: %s" % e)


flush = _cache_save


def expire(rx):
    """da por caducado lo guardado cuya ruta de Palantir cumpla rx: se sigue enseñando al momento y se pide otra vez.
    Sobre el fichero y con cerrojo: merge_newer nunca deja «envejecer» una entrada. Cuántas"""
    def hit(key):
        return bool(rx.search(route_of(key[:-2] if key.endswith("#h") else key)))

    # marca de hace algo más de STATIC_TTL: caducada con cualquier ttl, pero no para la purga (KEEP). Con 0, el siguiente
    # guardado de cualquier script la borraba y Favoritos abría sin nada que enseñar (30 s; Carlos, 30-oct)
    old = time.time() - STATIC_TTL - 1

    def age(v):
        try:
            v[0] = min(float(v[0]), old)
        except (TypeError, ValueError):
            v[0] = old
    n = 0
    try:
        with flix_cache.file_lock(CACHE_FILE):
            try:
                with open(CACHE_FILE, encoding="utf-8") as fh:
                    disk = json.load(fh)
            except (OSError, ValueError):
                disk = {}
            for k, v in disk.items():
                if isinstance(v, list) and v and hit(k):
                    age(v)
                    n += 1
            if n:
                flix_cache.atomic_write(CACHE_FILE, json.dumps(disk))
    except OSError as e:
        log("no caduco caché: %s" % e)
    for k, v in (_cache or {}).items():
        if isinstance(v, list) and v and hit(k):
            age(v)
    log("caducadas %d filas guardadas (%s)" % (n, rx.pattern))
    return n


def peek(path, keep_headers=False):
    """(items guardados o None, ¿frescos?) sin llamar a Palantir"""
    hit = _cache_load().get(flix_cache.key_of(path, keep_headers))
    if not hit:
        return None, False
    return _progress(hit[1]), flix_cache.is_fresh(hit, ttl=ttl_of(path))


def is_fresh(path, keep_headers=False):
    """¿lo guardado de esa fila está fresco? Lo mismo que peek(path)[1] sin corregir el progreso de los títulos
    (refresh_stale del Inicio solo quiere saber qué filas volver a pedir; revisión 29-oct ARR-01)"""
    hit = _cache_load().get(flix_cache.key_of(path, keep_headers))
    return bool(hit) and flix_cache.is_fresh(hit, ttl=ttl_of(path))


def fetch(path, force=False, keep_headers=False, save=True):
    """(items, de_caché). Clave sin &reload=. Un fallo de Palantir (0 items) no machaca una caché buena."""
    key = flix_cache.key_of(path, keep_headers)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and time.time() - hit[0] < ttl_of(path):
        return _progress(hit[1]), True
    files = list_files(directory(path), PROPS, tmdb=path.startswith(TMDB_LIST))
    files = [f for f in files if f.get("label") and (keep_headers or not clean(f["label"]).endswith(":"))]
    if files:          # vacío = fallo de Palantir: ni machaca una caché buena ni se guarda (el reintento volvería a dar vacío)
        cache[key] = [time.time(), files]
        _dirty.add(key)
        if save:
            _cache_save()
    return _progress(files or (hit[1] if hit else [])), False


def directory(path, offline=False):
    """ruta que se pide a Kodi: las filas de listas de TMDB se convierten en un listado de Palantir. offline: sin red
    ni base de Palantir, con los ids guardados (menú KER0N3; flix_tmdblists.directory)"""
    if path.startswith(TMDB_LIST):
        import flix_tmdblists
        return flix_tmdblists.directory(path, offline=offline)
    return path


def is_tmdb_row(path):
    """¿fila de lista de TMDB? (lee la base de Palantir al pedirla: espera si está ocupada, palantir_busy)"""
    return str(path or "").startswith(TMDB_LIST)


def list_files(directory_path, props, tmdb=False):
    """Files.GetDirectory; [] sin ruta (lista de TMDB sin títulos o sin red). tmdb: fila de lista de TMDB, fuera el
    elemento suelto que Palantir añade sin título («*» en rojo)"""
    if not directory_path:
        return []
    files = list_dir(directory_path, props)     # JSON-RPC común (DAT-20); respuesta que no es JSON: ValueError, como antes
    return [f for f in files if clean(f.get("label") or "").strip("* ")] if tmdb else files


def _progress(files):
    """progreso real de Palantir (watched.db) en vez del que trae la caché (flix_progress.py)"""
    try:
        import flix_progress
        flix_progress.fix_files(files)
    except Exception as e:  # noqa: BLE001
        log("progreso: %s" % e)
    return files


def is_generic(f):
    a = f.get("art") or {}
    art = urllib.parse.unquote(a.get("poster") or a.get("thumb") or "")   # llega como image://special%3a%2f%2f…
    return not art or GENERIC_ART in art


def is_more(f):
    """último elemento "Más…/More…" de un listado (página siguiente)"""
    return f.get("filetype") == "directory" and re.match(r"^(m[aá]s|more|siguiente|next)\b", clean(f.get("label")).lower()) is not None


FOLLOW_ACTION = "\"action\": 'play_mis_serieS'"
FOLLOW_TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')


def follow_tmdb(f):
    """tmdb de una serie de «Series en seguimiento» (cualquier página o sección); None si no lo es. Aquí y no en
    flix_progress para que las secciones lo miren sin cargar ese módulo"""
    if not isinstance(f, dict) or not str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/"):
        return None
    try:
        route = decode_route(f["file"])
    except Exception:  # noqa: BLE001
        return None
    m = FOLLOW_TMDB_RE.search(route) if FOLLOW_ACTION in route else None
    return m.group(1) if m else None


def head(files, n, more=True):
    """los n primeros de un listado y su «más…» al final aunque quede fuera del recorte (tarjeta «Ver más»);
    more=False lo quita (Top 10)"""
    out = [f for f in files[:n] if more or not is_more(f)]
    return out + [f for f in files[n:] if is_more(f)][:1] if more else out


def is_search(label):
    l = label.lower().replace("í", "i")
    return "titulo" in l or "title" in l or l.startswith("buscar") or l.startswith("search")


def menu_path(var):
    """ruta del menú de una sección (variable p3… del skin o ruta de Palantir); '' si no hay"""
    path = var if var.startswith("plugin://") else skin_var(var)
    return path if path.startswith("plugin://") else ""


def live_stale(var):
    """¿es un menú que cambia (LIVE_MENUS: Favoritos, Listas Trakt) con lo guardado caducado? Entonces la sección se
    pinta ya con lo guardado (section_rows con live_later) y después pide el menú a Palantir (force) y corrige las
    filas (revisión 29-oct APA-01: «Cargando Favoritos…» 11 s esperando el menú, con las filas en la caché)"""
    if var not in LIVE_MENUS:
        return False
    path = menu_path(var)
    if not path:
        return False
    menu, fresh = peek(path, keep_headers=True)
    return bool(menu) and not fresh


def section_rows(var, stale_ok=False, live_later=False, force=False):
    """[{label, path, kind}] de la sección (en el orden del menú de Palantir). var: variable p3… del skin o ruta de
    Palantir (secciones añadidas en Ajustes → Secciones del menú). stale_ok: vale el menú guardado aunque esté
    caducado (cambia muy poco). Los de LIVE_MENUS caducados se piden otra vez, salvo con live_later (el que llama
    pinta lo guardado y luego pide el menú con force=True). force: el menú de Palantir, sin mirar lo guardado."""
    path = menu_path(var)
    if not path:
        return []
    menu, fresh = peek(path, keep_headers=True) if stale_ok and not force else (None, False)
    if menu and not fresh and var in LIVE_MENUS and not live_later:
        menu = None                 # Favoritos: las cuentas (y qué categorías tienen algo) cambian
    if not menu:
        menu, _ = fetch(path, keep_headers=True, force=force)
    out, group = [], ""
    groups = set()
    for f in menu:
        lab = clean(f.get("label"))
        if not lab:
            continue
        if lab.endswith(":"):
            group = "Series" if "serie" in lab.lower() else "Películas"
            groups.add(group)
            continue
        if is_search(lab) or f.get("filetype") != "directory":
            continue
        m = COUNT_RE.match(lab)
        if m:
            if m.group(2) == "0":
                continue            # categoría vacía: sin fila
            lab = m.group(1)
        act = action_of(f.get("file", ""))
        if act in SKIP_ACTIONS:
            continue                # «Añadir lista nueva...» de Trakt
        kind = "list" if act in ("listado_peliculaS", "listado_serieS", "listado_trakt") else "coll"
        out.append({"label": lab, "path": f["file"], "kind": kind, "group": group})
    # etiquetas repetidas (p. ej. "Por orden alfabético" en pelis y en series) llevan el grupo detrás
    names = [r["label"] for r in out]
    for r in out:
        if names.count(r["label"]) > 1 and r["group"]:
            r["label"] = "%s · %s" % (r["label"], r["group"])
    log("sección %s: %d filas (%s)" % (var, len(out), ", ".join("%s[%s]" % (r["label"], r["kind"]) for r in out)))
    return out
