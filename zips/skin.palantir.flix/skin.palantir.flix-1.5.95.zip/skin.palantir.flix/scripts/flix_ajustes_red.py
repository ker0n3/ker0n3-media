"""Pasar ajustes por la red de casa (flix_ajustes). El que envía sirve su paquete por HTTP a quien dé el código de 4
cifras y contesta a la búsqueda por UDP; el que recibe busca (la búsqueda NO lleva el código: cualquier envío activo
contesta con su puerto y su nombre), elige y entonces da el código por HTTP; si no encuentra nada (redes separadas),
prueba la dirección escrita a mano. Solo redes privadas; el código solo se comprueba por HTTP, con 5 fallos o tras
darlo una vez deja de atender (y contestar); cada conexión tiene tiempo máximo, así que una que se queda callada no
bloquea a las demás ni el cierre; todo se cierra con el aviso o a los 10 minutos. Todo fallo llega como RedError, con
el aviso en español y sin punto final. Solo stdlib (se prueba sin Kodi)."""
import http.client
import ipaddress
import json
import secrets
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORTS = range(47811, 47820)         # HTTP (el QR del móvil, flix_phonekb, usa 47801-47810)
DISCOVERY = 47820                   # UDP: «KER0N3-AJUSTES ?» -> «KER0N3-AJUSTES OK <puerto> <nombre>» (sin código)
MAGIC = "KER0N3-AJUSTES"
LIFETIME = 600                      # el aviso de enviar espera como mucho 10 min
MAX_FAILS = 5
MAX_BYTES = 1000000                 # un paquete de ajustes real ocupa unos KB
NO_LLEGA = "No llega al otro aparato: ¿está en la misma red y con Enviar abierto?"


class RedError(Exception):
    """aviso para el usuario (sin punto final). other_port: en ese puerto no hay nadie, se puede probar otro"""

    timed_out = False                   # el aparato no contestó a tiempo: no tiene sentido probar otro puerto

    def __init__(self, msg, other_port=False):
        super().__init__(msg)
        self.other_port = other_port


def private(ip):
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return False


def new_code():
    return "%04d" % secrets.randbelow(10000)


def _handler(owner):
    class Handler(BaseHTTPRequestHandler):
        timeout = 5                         # una conexión callada no se queda para siempre

        def log_message(self, *a):          # sin ruido en kodi.log
            pass

        def _send(self, status, body=b"", ctype="text/plain; charset=utf-8"):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            url = urllib.parse.urlsplit(self.path)
            if url.path != "/ajustes" or not private(self.client_address[0]):
                return self._send(404)
            q = urllib.parse.parse_qs(url.query)
            status = owner.check_code(q.get("codigo", [""])[0], q.get("aparato", [""])[0])
            if status != 200:
                return self._send(status)
            self._send(200, json.dumps(owner.pkg, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
    return Handler


class Sender:
    """el aparato que envía: start() abre el HTTP (primer puerto libre de ports) y la escucha UDP; stop() lo cierra"""

    def __init__(self, pkg, name="", code=None, ports=PORTS, udp_port=DISCOVERY, lifetime=LIFETIME):
        self.pkg, self.name = pkg, name
        self.code = code or new_code()
        self.ports, self.udp_port, self.lifetime = ports, udp_port, lifetime
        self.port, self.server, self.udp = None, None, None
        self.fails, self.served_to = 0, ""
        self.served = threading.Event()
        self.lock = threading.Lock()
        self.t0 = time.time()

    def check_code(self, code, who):
        """200 = dar el paquete; 401 = código malo; 403 = ya no atiende (dado una vez, 5 fallos o pasado el tiempo)"""
        with self.lock:
            if self.fails >= MAX_FAILS or self.served.is_set() or self.expired():
                return 403
            if code != self.code:
                self.fails += 1
                return 401
            self.served_to = who[:60]
            self.served.set()
            return 200

    def active(self):
        with self.lock:
            return not (self.fails >= MAX_FAILS or self.served.is_set() or self.expired())

    def start(self):
        for port in self.ports:
            try:
                self.server = ThreadingHTTPServer(("0.0.0.0", port), _handler(self))
                self.port = port
                break
            except OSError:
                continue
        if self.server is None:
            raise RedError("No se pudo preparar el envío. Prueba otra vez en un momento")
        self.server.daemon_threads = True   # una conexión colgada no impide cerrar
        self.server.block_on_close = False  # ni server_close() espera a una conexión lenta
        threading.Thread(target=self.server.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True).start()
        udp = None
        try:
            udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            udp.bind(("0.0.0.0", self.udp_port))
            udp.settimeout(0.5)
            self.udp = udp
            threading.Thread(target=self._answer, daemon=True).start()
        except OSError:
            if udp is not None:
                udp.close()
            self.udp = None                 # sin búsqueda: el otro tendrá que escribir la dirección
        return self

    def _answer(self):
        want = ("%s ?" % MAGIC).encode("ascii")
        reply = ("%s OK %d %s" % (MAGIC, self.port, self.name.replace("\n", " ")[:60])).encode("utf-8")
        while True:
            sock = self.udp
            if sock is None:
                return
            try:
                data, addr = sock.recvfrom(256)
            except socket.timeout:
                continue
            except OSError:
                return
            if data.strip() == want and private(addr[0]) and self.active():
                try:
                    sock.sendto(reply, addr)
                except OSError:
                    pass

    def remaining(self, now=None):
        return max(0.0, self.lifetime - ((now if now is not None else time.time()) - self.t0))

    def expired(self, now=None):
        return self.remaining(now) <= 0

    def stop(self):
        udp, self.udp = self.udp, None
        server, self.server = self.server, None
        if udp is not None:
            udp.close()
        if server is not None:
            server.shutdown()
            server.server_close()


def broadcast_targets(ip):
    """a quién preguntar: toda la red y la difusión de la red de este aparato (a.b.c.255)"""
    out = ["255.255.255.255"]
    if ip and ip.count(".") == 3:
        out.append(ip.rsplit(".", 1)[0] + ".255")
    return out


def _parse_reply(data, addr):
    """(ip, puerto, nombre) de una respuesta «KER0N3-AJUSTES OK <puerto> <nombre>»; None si no lo es"""
    parts = data.decode("utf-8", "replace").split(" ", 3)
    if len(parts) < 3 or parts[0] != MAGIC or parts[1] != "OK" or not private(addr[0]):
        return None
    if not (parts[2].isascii() and parts[2].isdigit()):
        return None
    try:
        port = int(parts[2])
    except ValueError:
        return None
    if not 1 <= port <= 65535:
        return None
    name = "".join(c for c in (parts[3] if len(parts) > 3 else "") if c.isprintable())[:60]
    return addr[0], port, name


def discover(targets, udp_port=DISCOVERY, timeout=3.0):
    """[(ip, puerto, nombre)] de todos los que envían y contestan en ese tiempo (sin código: se pide después, por HTTP)"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    found = []
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.settimeout(0.3)
        msg = ("%s ?" % MAGIC).encode("ascii")
        end, sent = time.time() + timeout, 0
        while time.time() < end:
            if sent < 3:                    # 3 veces, por si se pierde alguno
                for t in targets:
                    try:
                        s.sendto(msg, (t, udp_port))
                    except OSError:
                        pass
                sent += 1
            try:
                data, addr = s.recvfrom(256)
            except socket.timeout:
                continue
            except OSError:
                break
            one = _parse_reply(data, addr)
            if one is not None and all(one[:2] != f[:2] for f in found):
                found.append(one)
    finally:
        s.close()
    return found


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):    # en casa, ni un desvío saca la petición de la red
        return None


def _timed_out(e):
    return isinstance(e, TimeoutError) or isinstance(getattr(e, "reason", None), TimeoutError)


def fetch(ip, port, code, me="", timeout=8):
    """el paquete del aparato que envía; RedError con el aviso si no se puede"""
    if not private(ip):
        raise RedError("Esa dirección no es de la red de casa")
    url = "http://%s:%d/ajustes?%s" % (ip, port, urllib.parse.urlencode({"codigo": code, "aparato": me}))
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)    # nunca por un proxy
    try:
        with opener.open(url, timeout=timeout) as r:
            body = r.read(MAX_BYTES + 1)
        if len(body) > MAX_BYTES:
            raise ValueError("demasiado grande")
        pkg = json.loads(body.decode("utf-8"))
        if not isinstance(pkg, dict):
            raise ValueError("no es un paquete")
        return pkg
    except urllib.error.HTTPError as e:
        status = e.code
        e.close()
        if status == 401:
            raise RedError("Código incorrecto: míralo en el otro aparato")
        if status == 403:
            raise RedError("El otro aparato ya no acepta este envío: vuelve a darle a Enviar")
        raise RedError("En esa dirección no hay ningún envío de ajustes", other_port=True)
    except (OSError, ValueError, http.client.HTTPException) as e:
        err = RedError(NO_LLEGA, other_port=True)
        err.timed_out = _timed_out(e)
        raise err


def fetch_any_port(ip, code, me="", ports=PORTS):
    """dirección escrita a mano: el que envía usa el primer puerto libre de PORTS, así que se prueban en orden"""
    if not private(ip):
        raise RedError("Esa dirección no es de la red de casa")
    last = RedError(NO_LLEGA)
    for port in ports:
        try:
            return fetch(ip, port, code, me, timeout=3)
        except RedError as e:
            if not e.other_port:
                raise
            if e.timed_out:                 # el aparato no contesta: probar más puertos solo alarga la espera
                raise
            last = e
    raise last
