"""«Filas al azar» del Inicio (spec docs/superpowers/specs/2026-10-24-filas-al-azar-design.md): debajo de las 4 filas
fijas, listas de TMDB (flix_tmdblists) sorteadas. Sorteo ADELANTADO: al arrancar se enseña el que se precargó la vez
anterior (promote) y por detrás se sortea y precarga el de la próxima (prepare), así nunca sale «Cargando…».

Lógica pura arriba (tests en tools/tests/test_random_rows.py); lo que toca Kodi, abajo.
Configuración: home_order.json → "random" (flix_home_conf). Sorteo siguiente: addon_data/<skin>/random_state.json
  {"next": [claves], "ready": bool, "for": [n, [apartados]]} (aparte: sortear no cambia la firma del Inicio)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import random

import flix_home_conf as hc  # noqa: E402
import flix_tmdblists as tl  # noqa: E402

MIN_TITLES = 8          # una lista con menos títulos en Palantir no vale (se cambia por otra del mismo tipo)
START_DELAY = 45        # la precarga empieza cuando el Inicio ya ha cargado sus filas
GAP = 5                 # entre lista y lista: Palantir atiende una llamada cada vez
EXTRA_TRIES = 8         # listas de más que se prueban si alguna no llega a MIN_TITLES
IDLE_MAX = 600          # s como mucho esperando a que no haya vídeo / tráiler / enlace (si no, se deja para otra vez)


def kind_of(key):
    return tl.BY_KEY[key][1]


def pool_of(groups):
    """claves de las listas de esos apartados (flix_tmdblists.GROUPS), sin repetir"""
    out = []
    for g in groups:
        if 0 <= g < len(tl.GROUPS):
            out += [k for k in tl.GROUPS[g][1] if k not in out]
    return out


def draw(groups, n, avoid=(), exclude=(), rng=None, good=None, max_tries=None):
    """hasta n claves alternando película / serie (empieza una al azar; si un tipo se acaba, sigue el otro).
    avoid: solo si no quedan otras (las del sorteo anterior). exclude: nunca. good(clave) False = no vale, se pasa a la
    siguiente del mismo tipo. max_tries: cuántas se prueban como mucho (cada good puede costar una consulta)"""
    rng = rng or random.Random()
    qs = {"movie": [], "tv": []}
    pool = [k for k in pool_of(groups) if k not in exclude]
    fresh, old = [k for k in pool if k not in avoid], [k for k in pool if k in avoid]
    rng.shuffle(fresh)
    rng.shuffle(old)
    for k in fresh + old:
        qs[kind_of(k)].append(k)
    turn = rng.choice(("movie", "tv"))
    out, tries = [], 0
    while len(out) < n and (qs["movie"] or qs["tv"]):
        if max_tries is not None and tries >= max_tries:
            break
        if not qs[turn]:
            turn = "tv" if turn == "movie" else "movie"
        k = qs[turn].pop(0)
        tries += 1
        if good is None or good(k):
            out.append(k)
            turn = "tv" if turn == "movie" else "movie"
    return out


def resize(current, groups, n, rng=None):
    """al cambiar «Filas al azar: N» con el modo Aleatoria en uso: recorta o añade sorteadas (sin repetir) al momento"""
    if len(current) >= n:
        return list(current[:n])
    return list(current) + draw(groups, n - len(current), exclude=current, rng=rng)


def promote(conf, state):
    """al arrancar: el sorteo preparado pasa a ser el de ahora (solo si está listo y es para esta configuración).
    Cambia conf y state en el sitio; True si cambió algo."""
    if not hc.random_on(conf):
        return False
    r = conf["random"]
    if not state.get("ready") or not state.get("next") or state.get("for") != [r["n"], r["groups"]]:
        return False
    r["current"] = list(state["next"])
    state.update(next=[], ready=False)
    return True


def load_state(path):
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        d = {}
    d = d if isinstance(d, dict) else {}
    return {"next": [k for k in d.get("next") or [] if isinstance(k, str)], "ready": bool(d.get("ready")),
            "for": d.get("for")}


def save_state(path, state):
    from flix_common import atomic_write
    atomic_write(path, json.dumps(state))


# ---------- Kodi ----------
class _Abort(Exception):
    pass


def log(msg):
    import xbmc
    xbmc.log("[flix_random_rows] %s" % msg, xbmc.LOGINFO)


def state_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/random_state.json" % xbmc.getSkinDir())


def home():
    import xbmcgui
    return xbmcgui.Window(10000)


def promote_saved():
    """al arrancar, antes de montar el Inicio (TV: flix_home_order.check; táctil: flix_home.home_rows), una vez por
    sesión: el sorteo preparado pasa a ser el de ahora y se pide preparar el siguiente. True si cambió el Inicio."""
    if home().getProperty("flix_rnd_done"):
        return False
    home().setProperty("flix_rnd_done", "1")
    import flix_home_order as fho
    if fho.lite():
        return False                            # modo modesto: sin filas al azar ni su precarga
    conf = fho.load_conf()
    if conf is None and fresh_install(fho.DATA):
        conf = hc.normalize({"random": {"on": True}, "deleted": list(hc.DEFAULT_DELETED)})   # de serie (Carlos, 24-oct)
        log("instalación nueva: filas al azar activadas")
    if not conf or not hc.random_on(conf):
        return False
    st = load_state(state_path())
    changed = promote(conf, st)
    if changed:
        save_state(state_path(), st)
        log("sorteo preparado en uso: %s" % conf["random"]["current"])
    elif not conf["random"]["current"]:
        r = conf["random"]                      # aún sin sorteo preparado: uno ya (estas se cargan en directo)
        r["current"] = draw(r["groups"], r["n"])
        changed = bool(r["current"])
    if changed:
        fho.save_conf(conf)
    request_prepare()
    return changed


def fresh_install(data):
    """skin recién instalada: sin caché de filas del Inicio (TV rows_cache2.json, táctil home_cache2.json); quien ya
    la usaba sin tocar el Inicio (sin home_order.json) la tiene y sigue con sus filas de siempre"""
    return not any(os.path.exists(os.path.join(data, f)) for f in ("rows_cache2.json", "home_cache2.json"))


def request_prepare():
    """sortear y precargar el siguiente por detrás. TV: script aparte (la caché de filas de la TV se mezcla al
    guardar); táctil: dentro del propio Inicio (flix_home.py lo mira cada segundo: su caché la guarda él entera)"""
    import xbmc
    if xbmc.getSkinDir().endswith(".touch"):
        home().setProperty("flix_rnd_prep", "1")
    else:
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_random_rows.py,prepare)")


IDLE_SECS = 15          # s sin tocar el mando antes de pedir nada a Palantir


def idle():
    """nada que estorbar: sin vídeo, sin enlace resolviéndose, sin tráiler cargando (Shield 24-oct: una consulta a
    Palantir de la precarga en mitad de la carga de un tráiler) y con el mando quieto un rato: Palantir atiende de una
    en una y una consulta de la precarga retrasaba abrir una ficha justo después de arrancar (auditoría 24-oct)"""
    import xbmc
    h = home()
    return not xbmc.getCondVisibility("Player.HasMedia") and not h.getProperty("flix_resolving") and \
        not h.getProperty("flix_trailer") and xbmc.getGlobalIdleTime() >= IDLE_SECS and not tl.palantir_busy()


def prepare(fetch, delay=START_DELAY, flush=None):
    """sortea el siguiente probando cada lista con fetch(ruta) -> (títulos, de_caché), que la deja en la caché de
    filas; solo valen las de MIN_TITLES o más. Sin prisa: espera a que no haya vídeo ni enlace resolviéndose.
    flush: fetch no guarda la caché (TV: flix_rows con save=False) y se guarda UNA vez, antes de dar el sorteo por
    listo; antes se reescribía rows_cache2.json entero tras cada lista, 8-16 veces por sorteo (revisión 29-oct
    DAT-03). La táctil pasa su fetch, que guarda él, y no lo usa"""
    import xbmc
    if home().getProperty("flix_rnd_running"):
        return
    home().setProperty("flix_rnd_running", "1")
    try:
        import flix_common      # al cerrarse Kodi se para en menos de 1 s (System.OnQuit; APA-03)
        _prepare(fetch, delay, flix_common.quit_monitor(), flush)
    except _Abort:
        pass
    except Exception as e:  # noqa: BLE001
        log("preparar: %s" % e)
    finally:
        try:
            if flush:
                flush()                         # cortado (Kodi se cierra, espera de más) o fallo: lo pedido se guarda
        except Exception as e:  # noqa: BLE001
            log("preparar: %s" % e)
        home().clearProperty("flix_rnd_running")


def _wait(mon, secs):
    """monitor.waitForAbort(secs) que vuelve en cuanto Kodi se cierra (flix_common.wait_quit)"""
    import flix_common
    return flix_common.wait_quit(mon, secs)


def _prepare(fetch, delay, mon, flush=None):
    import flix_home_order as fho
    if _wait(mon, delay) or fho.lite():
        return
    conf = fho.load_conf() or hc.normalize(None)
    if not hc.random_on(conf):
        return
    r = conf["random"]
    want = [r["n"], r["groups"]]
    st = load_state(state_path())
    if st["ready"] and st["next"] and st["for"] == want:
        return

    def good(key):
        waited = 0
        while not idle():
            waited += 10
            if _wait(mon, 10) or waited > IDLE_MAX:
                raise _Abort                    # una marca colgada (p. ej. flix_trailer) no lo deja esperando siempre
        n = len(fetch(hc.TMDB_PREFIX + key)[0] or [])
        log("%s: %d títulos%s" % (key, n, "" if n >= MIN_TITLES else " (no vale)"))
        if _wait(mon, GAP):
            raise _Abort
        return n >= MIN_TITLES

    nxt = draw(r["groups"], r["n"], avoid=r["current"], good=good, max_tries=r["n"] + EXTRA_TRIES)
    if flush:
        flush()                                 # las listas probadas, en la caché ANTES de marcar el sorteo listo
    now = hc.random_conf(fho.load_conf() or hc.normalize(None))
    if not nxt or not now["on"] or [now["n"], now["groups"]] != want:
        log("sorteo siguiente descartado (%d listas; configuración cambiada o sin respuesta)" % len(nxt))
        return
    save_state(state_path(), {"next": nxt, "ready": True, "for": want})
    log("sorteo siguiente listo: %s" % nxt)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "prepare":
        import flix_rows
        prepare(lambda path: flix_rows.fetch(path, save=False), flush=flix_rows.flush)
