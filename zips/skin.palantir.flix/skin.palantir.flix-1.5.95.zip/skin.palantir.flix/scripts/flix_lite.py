"""Ajustes → «Modo ligero» (Carlos, 24-oct): enciende o apaga Skin.Bool(flix_lite) y rehace el Inicio.

Encendido: Inicio de 6 filas (Seguir viendo, Series en seguimiento, Top 10 películas y series, Novedades, Nuevas series)
con 10 títulos (flix_home_conf.lite_conf), sin precarga de notas (flix_ratings) ni filas al azar (flix_random_rows).
Lo guardado en «Personalizar menú e Inicio» no se toca: al apagarlo vuelve tal cual.
Uso: RunScript(special://skin/scripts/flix_lite.py)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import xbmc
import xbmcgui
import xbmcvfs


def main():
    on = not xbmc.getCondVisibility("Skin.HasSetting(flix_lite)")
    xbmc.executebuiltin("Skin.%s(flix_lite)" % ("SetBool" if on else "Reset"))
    for _ in range(40):                     # el builtin va por la cola de Kodi
        if xbmc.getCondVisibility("Skin.HasSetting(flix_lite)") == on:
            break
        xbmc.sleep(50)
    import flix_home_order
    if not on:
        import flix_home_conf as hc
        conf = flix_home_order.load_conf()
        if conf and hc.random_on(conf):
            import flix_random_rows
            if not conf["random"]["current"]:    # con el modo ligero puesto al arrancar no se sorteó: ya
                r = conf["random"]
                r["current"] = flix_random_rows.draw(r["groups"], r["n"])
                flix_home_order.save_conf(conf)
            flix_random_rows.request_prepare()
    flix_home_order.apply_saved()           # TV: FlixInicio.xml con sus filas; táctil: al momento
    xbmc.log("[flix_lite] modo ligero %s" % ("activado" if on else "desactivado"), xbmc.LOGINFO)
    xbmcgui.Dialog().notification("KER0N3 MEDIA", "Modo ligero %s" % ("activado" if on else "desactivado"),
                                  xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)


if __name__ == "__main__":
    main()
