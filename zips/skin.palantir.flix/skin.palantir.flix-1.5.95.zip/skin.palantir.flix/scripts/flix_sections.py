"""Secciones del menú: barra lateral de la TV (Home.xml, lista 9000: Inicio + 14 huecos fijos) y tarjetas de arriba de
la táctil (flix_home.py, las 7 primeras). Qué secciones salen, en qué orden y qué filas lleva cada una lo decide
flix_sections_conf (sections.json, por aparato); apply() lo copia a Window(home).Property(flix_sec<N>_*) y
flix_chip<N>, que es lo que pintan los huecos: el menú cambia al momento, sin recargar el skin.
Uso: RunScript(special://skin/scripts/flix_sections.py)              -> editor único (flix_editor.py,menu)
     RunScript(special://skin/scripts/flix_sections.py,apply)        -> rellena el menú (Home.xml si no lo está)
     RunScript(special://skin/scripts/flix_sections.py,open,<clave>) -> abre una sección de rejilla (Trakt, Favoritos…)
     RunScript(special://skin/scripts/flix_sections.py,follow)       -> al arrancar: secciones «Especial…» al día"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re

import flix_sections_conf  # noqa: E402

CONF_NAME = "sections.json"


def setting(key):
    """ajuste viejo (antes de sections.json) que ocultaba una sección de serie"""
    return "flix_hide_%s" % key


def hidden_now():
    import xbmc
    return {d["key"] for d in flix_sections_conf.DEFAULTS
            if xbmc.getCondVisibility("Skin.HasSetting(%s)" % setting(d["key"]))}


def conf_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/%s" % (xbmc.getSkinDir(), CONF_NAME))


def load_conf():
    import json
    try:
        with open(conf_path(), encoding="utf-8") as fh:
            raw = json.load(fh)
    except OSError:
        return flix_sections_conf.default_conf(hidden_now())     # sin fichero: lo de siempre (y flix_hide_<clave>)
    except ValueError as e:
        import xbmc
        xbmc.log("[flix_sections] %s ilegible (%s): secciones de serie" % (CONF_NAME, e), xbmc.LOGWARNING)
        return flix_sections_conf.default_conf(set())
    return flix_sections_conf.normalize(raw)


def save_conf(conf):
    import json
    from flix_common import atomic_write     # temporal único (antes «.tmp» fijo) (revisión 29-oct ARR-13/DAT-15)
    atomic_write(conf_path(), json.dumps(conf, ensure_ascii=False, indent=1))


def menu_props(conf, resolve=None):
    """{propiedad: valor} del menú: huecos flix_sec<N>_* (TV) y flix_chip<N> (táctil, los TOUCH_MAX primeros)"""
    act = flix_sections_conf.active(conf)
    out = {}
    for n in range(1, flix_sections_conf.MAX_SECTIONS + 1):
        s = act[n - 1] if n <= len(act) else {}
        out.update({"flix_sec%d_label" % n: flix_sections_conf.shown(s) if s else "", "flix_sec%d_icon" % n: s.get("icon", ""),
                    "flix_sec%d_kind" % n: s.get("kind", ""), "flix_sec%d_key" % n: s.get("key", "")})
        out["flix_chip%d" % n] = flix_sections_conf.shown(s) if s and n <= flix_sections_conf.TOUCH_MAX else ""
    return out


def apply(conf=None):
    import xbmcgui
    conf = conf or load_conf()
    home = xbmcgui.Window(10000)
    for k, v in menu_props(conf).items():
        home.setProperty(k, v)
    home.setProperty("flix_sec_ok", "1")        # Home.xml: si falta (skin recién instalado) lo pide al cargar
    return flix_sections_conf.active(conf)


def chips_props():
    """táctil: tarjetas de arriba (flix_chip<N>) = las primeras secciones activas"""
    return apply()[:flix_sections_conf.TOUCH_MAX]


def section(key, conf=None):
    """sección por clave; también por variable p3… (accesos de antes: flix_section.py,p3Dibujos,Dibujos)"""
    secs = (conf or load_conf())["sections"]
    return next((s for s in secs if s["key"] == key), None) or next((s for s in secs if s["src"] == key), None)


def src_path(s):
    """ruta de Palantir de una sección: la guardada (añadidas) o la variable p3… del skin; con los $INFO[...] que
    llevan algunas (&reload=…) ya resueltos"""
    import xbmc
    src = s.get("src", "")
    if not src.startswith("plugin://"):
        import flix_rows
        src = flix_rows.skin_var(src)
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: xbmc.getInfoLabel(m.group(1)), src)


def open_list(key):
    """sección de rejilla (Trakt, Favoritos, Series en seguimiento…): su listado en la ventana Vídeos"""
    import xbmc
    import xbmcgui
    s = section(key)
    path = src_path(s) if s else ""
    if not path:
        xbmc.log("[flix_sections] sección %s sin ruta" % key, xbmc.LOGWARNING)
        return
    xbmcgui.Window(10000).setProperty("flix_section", flix_sections_conf.shown(s))     # cabecera de la ventana Vídeos
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)


PALANTIR_ROOT = "plugin://plugin.video.palantir3/"
NO_ANSWER = "Palantir no responde ahora mismo"
FOLLOW_DELAY = 20       # s tras arrancar: que el Inicio pida lo suyo antes (Palantir atiende una llamada cada vez)
# Window(home): flix_p3sync ya listó la 1.ª raíz de la sesión (la única que baja de Trakt, 724f84e). follow lista la
# raíz DESPUÉS: si no, con una sección «Especial…» la gastaba follow (empezaba ~1,5 s antes) y p3sync podía devolver
# las pausas quitadas creyendo que Palantir no las había rellenado (revisión 29-oct ARR-09). Como mucho P3SYNC_MAX s
# (p3sync espera 20 s y su raíz, hasta 120): si no arrancó o murió, follow sigue como antes
P3SYNC_DONE = "flix_p3sync_done"
P3SYNC_MAX = 150
P3SYNC_STEP = 1


def log(msg):
    import xbmc
    xbmc.log("[flix_sections] %s" % msg, xbmc.LOGINFO)


_MON = []          # el Monitor del script (follow): se entera del cierre de Kodi (System.OnQuit; APA-03)


def wait(seconds):
    """True si Kodi se cierra mientras espera (también sin addon: flix_common.wait_quit)"""
    import flix_common
    if not _MON:
        _MON.append(flix_common.quit_monitor())
    return flix_common.wait_quit(_MON[0], seconds)


def wait_p3sync():
    """espera a que flix_p3sync haya listado la 1.ª raíz de la sesión (P3SYNC_DONE), como mucho P3SYNC_MAX s. True si
    Kodi se cierra mientras"""
    import xbmcgui
    waited = 0
    while not xbmcgui.Window(10000).getProperty(P3SYNC_DONE):
        if waited >= P3SYNC_MAX:
            log("especial: flix_p3sync no ha acabado en %d s; sigo" % P3SYNC_MAX)
            return False
        if wait(P3SYNC_STEP):
            return True
        waited += P3SYNC_STEP
    return False


def palantir_root():
    """menú principal de Palantir sin rueda de espera (al arrancar, por detrás)"""
    import flix_palantir_browse
    return flix_palantir_browse.listing(PALANTIR_ROOT)


def follow():
    """al arrancar (Startup.xml): las secciones «Especial…» toman el especial que tenga ahora Palantir (nombre y
    ruta) o se esconden si no tiene ninguno; si Palantir no responde, no se toca nada"""
    if not any(s.get("follow") for s in load_conf()["sections"]):
        return
    if wait(FOLLOW_DELAY):
        return
    if wait_p3sync():
        return
    import flix_home_conf
    folders, _ = flix_home_conf.classify(palantir_root())
    if not folders:
        log("especial: Palantir no responde")
        return
    conf = load_conf()          # pudo cambiar mientras esperaba
    if flix_sections_conf.follow_update(conf, [{"label": f["label"], "path": f["file"]} for f in folders]):
        save_conf(conf)
        apply(conf)
        log("especial al día: %s" % ", ".join("%s%s" % (s["label"], " (sin especial ahora)" if s.get("gone") else "")
                                                for s in conf["sections"] if s.get("follow")))


def kind_of(files):
    """al añadir una sección: "rows" si su menú son submenús (filas), "list" si lista títulos (Películas no
    finalizadas, Series en seguimiento); None si Palantir no ha dado nada"""
    import flix_home_conf
    folders, titles = flix_home_conf.classify(files)
    if not folders and not titles:
        return None
    return "list" if titles > len(folders) else "rows"


def rows_conf(items):
    """[(etiqueta, encendida)] del editor de filas -> {"order", "off"} de sections.json"""
    return {"order": [l for l, _ in items], "off": [l for l, on in items if not on]}


def count_text(n, touch):
    if touch and n > flix_sections_conf.TOUCH_MAX:
        return "%d de %d · en el móvil se ven %d" % (n, flix_sections_conf.MAX_SECTIONS, flix_sections_conf.TOUCH_MAX)
    return "%d de %d secciones" % (n, flix_sections_conf.MAX_SECTIONS)


def palantir_menu(path):
    """listado de un menú de Palantir (sin caché: al añadir se quiere lo de ahora)"""
    import flix_palantir_browse
    import flix_picker
    flix_picker.busy(True)
    try:
        return flix_palantir_browse.listing(path)
    finally:
        flix_picker.busy(False)


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "open":
        open_list(sys.argv[2])
    elif len(sys.argv) > 1 and sys.argv[1] == "follow":
        follow()
    elif len(sys.argv) > 1 and sys.argv[1] == "apply":
        apply()
    else:
        import flix_editor
        flix_editor.run("menu")          # acceso viejo (Ajustes de antes)
