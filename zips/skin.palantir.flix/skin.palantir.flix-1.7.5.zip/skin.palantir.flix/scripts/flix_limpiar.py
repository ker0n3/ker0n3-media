"""«Limpiar Kodi» (Carlos, 3-nov): libera espacio sin tocar add-ons, cuentas ni vistos. Borra los zips de
addons/packages (copias de instalaciones), los temporales de temp/ (menos los registros de Kodi) y las imágenes
sin usar en 30 días (flix_textures.py: es la única limpieza de imágenes, ya no hay una semanal automática). Solo
ficheros, nunca carpetas ni enlaces.
Lo lanza Ajustes → OTROS → «Limpiar Kodi» (tools/gen_settings.py), en la TV y en la táctil."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import time

import xbmc
import xbmcgui
import xbmcvfs

KEEP = ("kodi.log", "kodi.old.log")     # los registros no se borran nunca (flix_informe.py los necesita)
CRASH = "kodi_crashlog"                 # prefijo de los informes de fallos: sirven para un bug report
# s como mucho, contados desde que empieza el borrado de imágenes, esperando entre lotes a que acabe un vídeo, enlace o
# tráiler; pasados, el borrado para y se avisa «no ha terminado»
WAIT = 30


def human(n):
    """tamaño legible: 500 B, 2 KB, 5 MB, 1,5 GB"""
    n = float(n)
    for unit in ("B", "KB", "MB"):
        if n < 1024:
            return "%d %s" % (round(n), unit) if unit == "B" else "%s %s" % (_num(n), unit)
        n /= 1024
    return "%s GB" % _num(n)


def _num(x):
    s = "%.1f" % x
    return (s[:-2] if s.endswith(".0") else s).replace(".", ",")


def _files(folder):
    """ficheros de folder y subcarpetas, sin enlaces (ni de fichero ni de carpeta)"""
    out = []
    for base, dirs, names in os.walk(folder):      # followlinks=False: no entra en enlaces
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(base, d))]
        out += [os.path.join(base, n) for n in names if not os.path.islink(os.path.join(base, n))]
    return sorted(out)


def _protected(name):
    return name in KEEP or name.startswith(CRASH)


def package_files(packages_dir):
    if not os.path.isdir(packages_dir):
        return []
    return [p for p in _files(packages_dir) if p.lower().endswith(".zip")]


def temp_files(temp_dir):
    if not os.path.isdir(temp_dir):
        return []
    fonts = os.path.join(os.path.realpath(temp_dir), "fonts") + os.sep     # las fuentes que Kodi tiene extraídas
    return [p for p in _files(temp_dir) if not _protected(os.path.basename(p)) and not os.path.realpath(p).startswith(fonts)]


def _allowed(path, bases):
    """solo dentro de una de las dos carpetas (rutas reales), y nunca un registro, un enlace ni una carpeta"""
    if os.path.islink(path) or os.path.isdir(path) or _protected(os.path.basename(path)):
        return False
    real = os.path.realpath(path)
    for base in bases:
        rb = os.path.realpath(base)
        try:
            if os.path.commonpath([real, rb]) == rb:
                return True
        except ValueError:      # rutas de unidades distintas o mezcla relativa/absoluta
            continue
    return False


def size_of(paths):
    total = 0
    for p in paths:
        try:
            total += os.path.getsize(p)
        except OSError:
            pass
    return total


def remove_files(paths, bases):
    """borra los ficheros permitidos y devuelve los bytes liberados; los que fallen se ignoran"""
    freed = 0
    for p in paths:
        if not _allowed(p, bases) or not os.path.isfile(p):
            continue
        try:
            size = os.path.getsize(p)
            os.remove(p)
            freed += size
        except OSError:
            pass
    return freed


def notify(msg):
    xbmcgui.Dialog().notification("Limpiar Kodi", msg, xbmcgui.NOTIFICATION_INFO, 4000)


def main():
    if xbmc.getCondVisibility("Player.HasMedia"):
        notify("Para el vídeo antes de limpiar")
        return
    import flix_common
    import flix_textures
    packages_dir = xbmcvfs.translatePath("special://home/addons/packages/")
    temp_dir = xbmcvfs.translatePath("special://temp/")      # no siempre cuelga de special://home
    files = package_files(packages_dir) + temp_files(temp_dir)
    try:
        ids = flix_textures.list_old(flix_common, flix_textures.cutoff(time.time()))
    except Exception as e:
        xbmc.log("[flix_limpiar] imágenes no listadas: %s" % type(e).__name__, xbmc.LOGWARNING)
        ids = []        # Kodi no contestó: se limpian solo los ficheros
    if not files and not ids:
        notify("Kodi ya está limpio")
        return
    ok = xbmcgui.Dialog().yesno(
        "Limpiar Kodi",
        "Se borran %s de copias y temporales, y %d imágenes sin usar en 30 días.\n"
        "No se borran add-ons, cuentas ni vistos." % (human(size_of(files)), len(ids)),
        nolabel="Cancelar", yeslabel="Limpiar")
    if not ok:
        return
    if xbmc.getCondVisibility("Player.HasMedia"):      # un vídeo pudo empezar con el diálogo abierto
        notify("Para el vídeo antes de limpiar")
        return
    bar = xbmcgui.DialogProgressBG()
    bar.create("Limpiar Kodi", "Borrando…")
    freed, removed, finished = 0, 0, True
    try:
        freed = remove_files(files, [packages_dir, temp_dir])
        if ids:
            mon = flix_common.quit_monitor()
            try:
                removed, finished = flix_textures.remove(ids, mon, flix_common, time.time() + WAIT)
            except ValueError:
                finished = False        # Kodi dejó de contestar a medias: se informa de lo liberado
    finally:
        bar.close()
    msg = "Liberados %s · %d imágenes" % (human(freed), removed)
    notify(msg if finished else msg + " (no ha terminado)")


if __name__ == "__main__":
    main()
