"""Parada diferida al salir del vídeo (VideoFullScreen.xml: onunload -> AlarmClock de 1 s -> este script).

Para solo si de verdad se ha salido de la reproducción. Al recargar la skin (actualización automática) Kodi descarga y
vuelve a cargar la pantalla del vídeo: el onunload salta igual y la película se cortaba (auditoría 22-oct A-05).

Tampoco para el tráiler automático de la ficha (flix_tr_auto, flix_autotrailer): «Tráiler» lo pasa a pantalla completa y
Atrás vuelve a la ficha con él sonando en su recuadro. Se mira al cumplirse el segundo: si la ficha lo para (Ver, salir),
flix_tr_auto ya se ha quitado y no queda nada que este script deba tocar."""
import xbmc

if xbmc.getCondVisibility("Player.HasMedia") and \
        not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd)") and \
        not xbmc.getInfoLabel("Window(home).Property(flix_tr_auto)"):
    xbmc.executebuiltin("PlayerControl(Stop)")
