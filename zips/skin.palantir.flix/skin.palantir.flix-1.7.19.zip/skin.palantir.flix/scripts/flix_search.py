# -*- coding: utf-8 -*-
"""Búsqueda unificada Palantir Flix (ventana Python WindowXML).

Uso desde el skin:
  RunScript(special://skin/scripts/flix_search.py)            -> pide texto con el teclado
  RunScript(special://skin/scripts/flix_search.py, <texto>)   -> busca directamente

Cómo funciona:
- Se usa la búsqueda global de Palantir (item "Buscar por título" del menú raíz, descubierto en
  tiempo de ejecución). Devuelve carpetas por categoría ("Películas (8)", "Series (2)", ...).
- Palantir abre su propio teclado al recibir esa ruta: un hilo (KeyboardAccepter) escribe el texto
  y acepta en cuanto aparece. Las carpetas de categoría se listan sin teclado.
- Palantir pone Window(home).Property(p3_play)=true tras buscar y mientras esté puesto reutiliza
  la búsqueda anterior sin preguntar: se limpia antes de cada búsqueda (igual que el skin original).
- Las consultas van por JSON-RPC (Files.GetDirectory) porque en cargas de widget Kodi no muestra
  el teclado del plugin. Codec de rutas Palantir: tools/p3route.py.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import threading
import time
import unicodedata
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import flix_builtin  # noqa: E402
from flix_common import A_BACK, COLOR_RE, PLUGIN_ROOT, TMDB_KEY, atomic_write, clean, decode_route, encode_route  # noqa: E402,F401
from flix_common import skin_var  # noqa: E402,F401  (una sola copia, XML leído una vez: revisión 29-oct DAT-19)
# to_listitem y compañía viven en flix_items: la sección y el Inicio no cargan el buscador entero por ellas
# (revisión 29-oct ARR-19); aquí se vuelven a exportar
from flix_items import brackets, clean_title, langs_from_label, quality_from_label, to_listitem  # noqa: E402,F401

HOME = xbmcgui.Window(10000)
HIST_MAX = 5
SKIN_PATH = xbmcvfs.translatePath("special://skin/")
ROW_IDS = [5201, 5202, 5203, 5204, 5205, 5206, 5207, 5208]
CHIPS = {5301: 1, 5302: 2, 5303: 3, 5304: 4, 5305: 5}
BTN_NEW = 5309
SEARCH_PARALLEL = 1  # Palantir serializa: con 3 hilos cada consulta pasa de 3 a 7-12 s y el total no baja (medido 16-oct)
MAX_ALT_TITLES = 3
EXTRA_TITLES_MAX = 3    # consultas tmdb_title_es (6 s de tope cada una) por búsqueda: antes hasta 16 (PY-14)


def log(msg):
    xbmc.log("[flix_search] %s" % msg, xbmc.LOGINFO)


# JSON-RPC común (revisión 29-oct DAT-20): la misma petición y ValueError si la respuesta no es JSON, como antes
from flix_common import rpc  # noqa: E402



# ---------- rutas Palantir ----------




def list_dir(route, props=("file",), retries=2):
    """listado de Palantir; si viene vacío o con error (p. ej. Palantir ocupado sincronizando Trakt al
    arrancar) lo reintenta. Deja el error en el log (antes se perdía y la búsqueda daba 0 sin explicación)."""
    for attempt in range(retries + 1):
        r = rpc("Files.GetDirectory", {"directory": route, "media": "video", "properties": list(props)})
        files = (r.get("result") or {}).get("files") or []
        if files:
            return files
        log("listado vacío (intento %d) %s: %s" % (attempt + 1, route[:70], r.get("error") or "sin elementos"))
        if attempt < retries:
            xbmc.sleep(1500)
    return []


def global_search_route():
    """Item 'Buscar por título' del menú raíz de Palantir (búsqueda global; devuelve carpetas por categoría)."""
    cached = HOME.getProperty("flix_root_search")
    if cached:
        return cached
    for f in list_dir(PLUGIN_ROOT):
        lab = _plain(clean(f.get("label")))
        if (lab.startswith("buscar") or lab.startswith("search")) and ("titulo" in lab or "title" in lab):
            HOME.setProperty("flix_root_search", f["file"])
            return f["file"]
    return ""


SECTIONS = ["películas", "series", "dibujos", "anime", "documentales"]
SINGULAR = {"películas": "película", "series": "serie", "documentales": "documental"}


def count_label(n, label):
    """resumen de una fila: «3 películas», «1 película», «1 película de dibujos», «1 serie», «1 documental» (TV-27:
    nunca «1 películas»). Solo cambia la 1.ª palabra; si no acaba en -s (Anime, Música) se queda igual"""
    first, _, rest = label.lower().partition(" ")
    if n == 1:
        first = SINGULAR.get(first) or (first[:-1] if first.endswith("s") and not first.endswith("ss") else first)
    return "%d %s" % (n, first + (" " + rest if rest else ""))


def _plain(text):
    return "".join(c for c in unicodedata.normalize("NFD", text.lower()) if unicodedata.category(c) != "Mn")


def is_title_search(label):
    """'Por título', 'Buscar por título', 'For title', 'Search by title', '[B]Por título[/B]'…"""
    t = _plain(label)
    # Palantir sigue el idioma de Kodi: en inglés es "For title" / "Search by title" (móvil 16-oct)
    return ("titulo" in t or "title" in t) and not t.rstrip().endswith(":")


ROUTES_FILE = "special://profile/addon_data/%s/search_routes.json" % xbmc.getSkinDir()
# 2: la de antes podía estar incompleta y sigue en memoria si se actualiza la skin sin reiniciar Kodi (móvil, 4-nov)
ROUTES_PROP = "flix_section_routes2"
ROUTES_PARTIAL = "flix_routes_partial"   # Window(home): esta búsqueda no ha podido ver todas las secciones
# la lista a medias (Palantir ocupado) y la hora en que se hizo, en Window(home) y nunca a disco: el índice de títulos y
# la búsqueda la piden una tras otra y cada recorrido de menús son ~27 s; se reutiliza ROUTES_PARTIAL_TTL s
ROUTES_PARTIAL_LIST = "flix_routes_partial_list"
ROUTES_PARTIAL_TTL = 60
ROUTES_TTL = 7 * 86400   # las rutas "Por título" de Palantir apenas cambian; averiguarlas cuesta ~27 s (5 menús)


def _routes_disk(save=None, stale_ok=False):
    path = xbmcvfs.translatePath(ROUTES_FILE)
    lang = xbmc.getLanguage(xbmc.ISO_639_1)
    if save is not None:
        try:
            atomic_write(path, json.dumps({"ts": time.time(), "lang": lang, "routes": save, "complete": True}))
        except OSError as e:
            log("no guardo rutas: %s" % e)
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        # sin «complete» (de antes del 4-nov) pueden faltar secciones: se rehacen una vez
        if d.get("routes") and d.get("complete") and d.get("lang") == lang and (stale_ok or time.time() - d.get("ts", 0) < ROUTES_TTL):
            return d["routes"]
    except (OSError, ValueError):
        pass
    return None


def forget_routes():
    """si una búsqueda no da nada en ninguna sección, las rutas guardadas pueden haber caducado"""
    HOME.clearProperty(ROUTES_PROP)
    HOME.clearProperty(ROUTES_PARTIAL_LIST)
    try:
        os.remove(xbmcvfs.translatePath(ROUTES_FILE))
    except OSError:
        pass


def expire_routes():
    """Palantir no contestó a NINGUNA consulta (tras actualizarse, las rutas guardadas pueden dar error en todas): se
    marcan caducadas (ts 0) pero siguen en disco como respaldo (stale_ok). La siguiente búsqueda recorre los menús; un
    recorrido completo las sustituye y uno a medias vuelve a este respaldo. Borrarlas dejaría sin nada si Palantir está caído"""
    HOME.clearProperty(ROUTES_PROP)
    HOME.clearProperty(ROUTES_PARTIAL_LIST)
    path = xbmcvfs.translatePath(ROUTES_FILE)
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        if isinstance(d, dict) and d.get("routes"):
            d["ts"] = 0
            atomic_write(path, json.dumps(d))
    except (OSError, ValueError):
        pass


# ---------- qué secciones tienen algo (antes de preguntar a Palantir) ----------
# Palantir atiende una consulta a la vez (~1-2 s cada una en la Shield) y se le preguntaba en las 8 secciones aunque de
# media solo 1,7 tienen algo (104 casos de la auditoría). La lista de títulos de cada sección sale de su base (solo
# lectura) y se guarda en disco hasta que la base cambie; mirar en ella cuesta ~0,02 s por búsqueda.
# CONTENT_DB (base de contenido de Palantir), TITLES_FILE y TITLES_VERSION: en flix_titles, para que el prewarm del
# arranque no importe este módulo (revisión 29-oct ARR-08)
from flix_titles import CONTENT_DB, TITLES_FILE, TITLES_VERSION  # noqa: E402,F401
# si al buscar aún se está leyendo la lista (base de Palantir cambiada: ~18 s en la Shield), se espera: preguntar a las
# 8 secciones una a una tardaba más (~25 s, «el padrino» tras la actualización 3.3.11, 28-oct). Normalmente ya está
# hecha (flix_titles_prewarm.py la prepara al arrancar) y la espera es nula; sin base, load_titles da None enseguida
TITLES_WAIT = 25


def loose(text):
    """más permisiva que iREGEXP de Palantir, que quita tildes, mayúsculas y signos pero respeta los espacios y busca
    la ú como «o»: aquí sin espacios y u = o. Si Palantir encuentra un título, esto también (comprobado contra su
    función real en el banco)."""
    t = "".join(c for c in unicodedata.normalize("NFKD", (text or "").lower()) if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9]", "", t.replace("u", "o"))


def view_of(route):
    """vista de Palantir que consulta una ruta «Por título» (v_pelis_Pelicula…); None si la ruta no lleva SQL"""
    try:
        m = re.search(r"FROM\s+(v_\w+)", decode_route(route), re.I)   # sin \b: Palantir escribe «\r\nFROM»
    except Exception:  # noqa: BLE001
        return None
    return m.group(1) if m else None


class Titles:
    """lista de títulos por vista de Palantir: texto loose (un título por línea) y su id TMDB en el mismo orden;
    bases = vistas base que existen (v_pelis / v_series) para juntar secciones en una consulta"""

    def __init__(self, views, bases=()):
        self.views = views
        self.bases = set(bases)

    def __eq__(self, other):
        return isinstance(other, Titles) and (self.views, self.bases) == (other.views, other.bases)

    def blob(self, view):
        v = self.views.get(view or "")
        return v[0] if v else None

    def ids(self, view, keys):
        """ids TMDB de los títulos de la vista que contienen alguna de las claves (loose)"""
        blob, ids = self.views[view]
        return [ids[n] for n, line in enumerate(blob.split("\n")) if any(k in line for k in keys)]


def load_titles(views, db=None, cache=None):
    """Titles de las vistas pedidas; de la caché si la base no ha cambiado (fecha y tamaño). None si no se puede leer
    la base (entonces se pregunta a todas las secciones, como antes)."""
    import sqlite3
    db = db or xbmcvfs.translatePath(CONTENT_DB)
    cache = cache or xbmcvfs.translatePath(TITLES_FILE)
    views = sorted({v for v in views if v})
    try:
        stamp = [os.path.getmtime(db), os.path.getsize(db)]
    except OSError:
        return None
    try:
        with open(cache, encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("v") == TITLES_VERSION and d.get("db") == stamp and all(v in d.get("views", {}) for v in views):
            return Titles({v: tuple(d["views"][v]) for v in views}, d.get("bases", ()))
    except (OSError, ValueError):
        pass
    import flix_tmdblists
    if flix_tmdblists.palantir_busy(db):      # base a medias (actualizando su contenido): no se lee
        log("Palantir está actualizando su contenido: el buscador pregunta a todas las secciones")
        return None
    t0 = time.time()
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=5)
        try:
            con.create_function("REGEXP", 2, lambda p, v: 1 if v is not None and re.search(p, v, re.I) else 0)
            have = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'view'")}
            out = {}
            for v in views:
                if v in have:
                    rows = con.execute("SELECT titulo, tmdb FROM %s" % v).fetchall()
                    out[v] = ("\n".join(loose(r[0]) for r in rows), [int(r[1]) for r in rows])
            bases = sorted(b for b in {base_of(v) for v in views} if b in have)
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("no leo los títulos de Palantir: %s" % e)
        return None
    log("títulos de %d secciones leídos de la base en %.1f s" % (len(out), time.time() - t0))
    try:
        atomic_write(cache, json.dumps({"v": TITLES_VERSION, "db": stamp, "views": out, "bases": bases}))
    except OSError as e:
        log("no guardo %s: %s" % (cache, e))
    return Titles(out, bases)


def sections_with(routes, titles, terms):
    """índices de las secciones donde algún término puede salir; las que no se pueden comprobar, siempre"""
    keys = [loose(t) for t in terms]
    out = []
    for i, (_label, rt) in enumerate(routes):
        blob = titles.blob(view_of(rt))
        if blob is None or any(k in blob for k in keys):
            out.append(i)
    return out


# ---------- secciones del mismo tipo en una sola consulta ----------
# Palantir tarda lo mismo en una sección que en todas las películas juntas (v_pelis): las secciones de un tipo con algo
# se piden juntas, limitadas a los ids candidatos, y cada resultado vuelve a la fila de su sección (por su id TMDB).
# Solo si todo cabe: ninguna sección pasa de su cupo (53, el de la ruta) ni el total de COMBINE_MAX; si no, sección a
# sección como antes. Así ninguna sección pequeña pierde resultados.
COMBINE_MAX = 150


def base_of(view):
    """v_pelis_Dibujo -> v_pelis; v_series_General -> v_series"""
    m = re.match(r"(v_(?:pelis|series))_\w+$", view or "")
    return m.group(1) if m else None


def limit_of(route):
    try:
        m = re.search(r'"limitItemList":\s*(\d+)', decode_route(route))
    except Exception:  # noqa: BLE001
        return 0
    return int(m.group(1)) if m else 0


def combined_route(route, text, terms, ids, limit):
    """ruta de listado de la sección pero sobre su vista base y solo con esos ids (orden por relevancia igual)"""
    r = direct_route(route, text, terms)
    if not r:
        return None
    j = decode_route(r)
    j = re.sub(r"FROM\s+(v_(?:pelis|series))_\w+\s+where\s+",
               lambda m: "FROM %s where tmdb IN (%s) AND " % (m.group(1), ",".join(str(int(i)) for i in ids)),
               j, count=1, flags=re.I)
    j = re.sub(r'"limitItemList":\s*\d+', '"limitItemList": %d' % max(1, limit), j, count=1)
    return encode_route(j)


def plan(routes, titles, terms, only, per=None):
    """consultas a hacer, en el orden de las secciones: ("one", i, None) o ("group", [i, ...], ids). Si se pasa per
    (dict), queda {sección: set(ids candidatos)} de las de cada grupo: group() los reutiliza en vez de volver a
    calcularlos cuando responde Palantir (revisión 29-oct DAT-18)"""
    keys = [loose(t) for t in terms]
    groups, order = {}, []
    for i in only:
        view = view_of(routes[i][1])
        base = base_of(view) if titles is not None and titles.blob(view) is not None else None
        key = base if base in getattr(titles, "bases", ()) else ("one", i)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(i)
    out = []
    for key in order:
        idx = groups[key]
        if isinstance(key, tuple) or len(idx) < 2:
            out.extend(("one", i, None) for i in idx)
            continue
        per_lists = [titles.ids(view_of(routes[i][1]), keys) for i in idx]
        ids = []
        for lst in per_lists:
            ids.extend(x for x in lst if x not in ids)
        fits = all(len(lst) <= limit_of(routes[i][1]) for i, lst in zip(idx, per_lists)) and len(ids) <= COMBINE_MAX
        if fits and all(limit_of(routes[i][1]) for i in idx):
            out.append(("group", idx, ids))
            if per is not None:
                per.update((i, set(lst)) for i, lst in zip(idx, per_lists))
        else:
            out.extend(("one", i, None) for i in idx)
    return sorted(out, key=lambda u: u[1][0] if u[0] == "group" else u[1])    # en el orden de las secciones


class TitleIndex(threading.Thread):
    """lee la lista de títulos al abrir el buscador, mientras se escribe"""

    def __init__(self):
        super().__init__(daemon=True)
        self.blobs = None
        self.done = threading.Event()

    def run(self):
        try:
            self.blobs = load_titles([view_of(r) for _, r in section_search_routes()])
        except Exception as e:  # noqa: BLE001
            log("índice de títulos: %s" % e)
        finally:
            self.done.set()

    def wait(self, timeout=TITLES_WAIT):
        return self.blobs if self.done.wait(timeout) else None


_ROUTES_LOCK = threading.Lock()     # el índice de títulos y la búsqueda las pedían a la vez: los menús, dos veces


def section_search_routes():
    """[(etiqueta, ruta 'Por título'), ...] de cada sección de Palantir, en orden de prioridad.
    Cacheado en home (sesión) y en disco 7 días (la Shield reinicia Kodi a menudo: sin disco, cada primera
    búsqueda costaba ~27 s de menús antes de empezar). Una sola petición a la vez: la segunda espera y usa la caché."""
    with _ROUTES_LOCK:
        return _section_search_routes()


def _partial_clear():
    """con rutas buenas (memoria, disco o un recorrido completo) no queda aviso ni lista a medias: otro intérprete
    (flix_titles_prewarm) puede haberlos puesto después"""
    HOME.clearProperty(ROUTES_PARTIAL)
    HOME.clearProperty(ROUTES_PARTIAL_LIST)


def _partial_recent():
    """la lista a medias de hace menos de ROUTES_PARTIAL_TTL s (con el aviso que tenía), o None"""
    try:
        d = json.loads(HOME.getProperty(ROUTES_PARTIAL_LIST))
        if isinstance(d["routes"], list) and 0 <= time.time() - float(d["ts"]) < ROUTES_PARTIAL_TTL:
            if d.get("partial"):
                HOME.setProperty(ROUTES_PARTIAL, "1")
            else:
                HOME.clearProperty(ROUTES_PARTIAL)
            return d["routes"]
    except (ValueError, KeyError, TypeError):
        pass
    return None


def _section_search_routes():
    cached = HOME.getProperty(ROUTES_PROP)
    if cached:
        try:
            out = json.loads(cached)
            _partial_clear()
            return out
        except ValueError:
            pass
    disk = _routes_disk()
    if disk:
        _partial_clear()
        HOME.setProperty(ROUTES_PROP, json.dumps(disk))
        log("rutas de búsqueda desde disco: %s" % [o[0] for o in disk])
        return disk
    recent = _partial_recent()
    if recent is not None:
        log("rutas a medias de hace poco (Palantir ocupado): no se recorren los menús otra vez")
        return recent
    out, complete = [], True
    # rutas de sección: primero las fijas de la skin (no dependen del menú raíz de Palantir, que en el
    # móvil llegó vacío al arrancar); si faltan, las del menú raíz
    secs = {}
    for name, var in zip(SECTIONS, ("p3Peliculas", "p3Series", "p3Dibujos", "p3Anime", "p3Documentales")):
        path = skin_var(var)
        if path.startswith("plugin://"):
            secs[name] = {"label": name.capitalize(), "file": path}
    if len(secs) < len(SECTIONS):
        for f in list_dir(PLUGIN_ROOT):
            if f.get("filetype") == "directory":
                secs.setdefault(clean(f.get("label")).lower(), f)
    for name in SECTIONS:
        sec = secs.get(name)
        if not sec:
            complete = False
            continue
        header = clean(sec.get("label"))
        items = list_dir(sec["file"])
        got = False
        log("menú %s: %s" % (name, [clean(i.get("label")) for i in items][:25]))
        for it in items:
            lab = clean(it.get("label"))
            if lab.endswith(":") and "buscar" not in lab.lower() and "search" not in lab.lower():
                header = lab.rstrip(":").strip()
                continue
            if is_title_search(lab):
                out.append([header, it["file"]])
                got = True
        if not items:
            complete = False                # menú vacío = Palantir ocupado: la sección falta
        elif not got:
            # menú con cosas pero sin «Por título»: si de verdad no la tiene, exigirla dejaría la búsqueda a medias para siempre
            log("menú %s sin ruta «Por título»: se sigue como completo" % name)
    log("rutas de búsqueda por sección: %s" % [o[0] for o in out])
    # menú vacío = Palantir ocupado (móvil, 4-nov: instalando su catálogo). Esta búsqueda usa lo que hay, pero no se
    # guarda: se quedaba 7 días sin Películas ni Series y «el padrino» daba «Sin resultados»
    if out and complete:
        _partial_clear()
        HOME.setProperty(ROUTES_PROP, json.dumps(out))
        _routes_disk(save=out)
        return out
    log("rutas incompletas (Palantir ocupado): no se guardan")
    old = _routes_disk(stale_ok=True)       # las últimas buenas, aunque caducadas, valen más que media lista
    if old:
        HOME.clearProperty(ROUTES_PARTIAL)
        log("uso las rutas guardadas, caducadas: %s" % [o[0] for o in old])
    else:
        HOME.setProperty(ROUTES_PARTIAL, "1")   # sin todas las secciones, «Sin resultados» sería mentira
    # lo que se use ahora se reutiliza un minuto (ROUTES_PARTIAL_TTL): no se recorren los menús dos veces
    res = old or out
    if res:         # una lista vacía no se reutiliza: Palantir puede recuperarse en segundos y devolvería [] un minuto
        HOME.setProperty(ROUTES_PARTIAL_LIST, json.dumps({"ts": time.time(), "routes": res, "partial": not old}))
    return res


# ---------- TMDB: títulos alternativos ----------
def norm(t):
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


# ---------- resultados de la sesión ----------
# La misma búsqueda otra vez no vuelve a preguntar a Palantir (revisión 29-oct APA-04, aprobado por Carlos: «matrix»
# dos veces seguidas, 2,5 -> 2,2 s en la Shield y 4,7 -> 3,2 s en la Fire TV). Cada apertura del buscador es otro
# intérprete: se guardan en Window(home) (memoria de la sesión de Kodi), RESULTS_TTL s, con clave el texto normalizado
# y las secciones. Si Palantir cambia entre medias, esos 10 min sale lo de antes (decisión de Carlos).
RESULTS_TTL = 600
RESULTS_MAX = 5                     # búsquedas guardadas como mucho (las más viejas se sueltan)
RESULTS_INDEX = "flix_sr_index"     # {hueco: [hora, clave]}; cada búsqueda en Window(home).Property(flix_sr_<hueco>)
RESULTS_BYTES = 500000              # una búsqueda más grande no se guarda (antes 2 MB: hasta 10 MB de JSON en
                                    # propiedades de Window(home); revisión 7-nov PY-27)


def _results_slot(text, routes):
    import zlib
    key = json.dumps([norm(text), routes], ensure_ascii=False)
    return key, "%08x" % zlib.crc32(key.encode("utf-8"))


def _results_index():
    try:
        idx = json.loads(HOME.getProperty(RESULTS_INDEX) or "{}")
    except ValueError:
        idx = {}
    return idx if isinstance(idx, dict) else {}


def results_get(text, routes):
    """{"rows": [[sección, títulos]], "paths": {...}, "summary": [...]} de esa búsqueda si se hizo hace menos de
    RESULTS_TTL s; None si no"""
    key, slot = _results_slot(text, routes)
    hit = _results_index().get(slot)
    try:
        if not hit or not 0 <= time.time() - float(hit[0]) < RESULTS_TTL:
            return None
        data = json.loads(HOME.getProperty("flix_sr_" + slot) or "null")
    except (TypeError, ValueError, IndexError):
        return None
    return data if isinstance(data, dict) and data.get("key") == key else None


def results_put(text, routes, rows, paths, summary):
    """guarda los resultados de una búsqueda acabada (rows: {sección: títulos}, en su orden)"""
    key, slot = _results_slot(text, routes)
    blob = json.dumps({"key": key, "rows": [[k, v] for k, v in rows.items()], "paths": paths or {},
                       "summary": summary})
    if len(blob) > RESULTS_BYTES:
        return
    now = time.time()
    idx = _results_index()
    idx[slot] = [now, key]
    for old in sorted(idx, key=lambda k: idx[k][0] if isinstance(idx[k], list) else 0)[:-RESULTS_MAX]:
        HOME.clearProperty("flix_sr_" + old)
        idx.pop(old, None)
    HOME.setProperty("flix_sr_" + slot, blob)
    HOME.setProperty(RESULTS_INDEX, json.dumps(idx))


def results_forget():
    for slot in _results_index():
        HOME.clearProperty("flix_sr_" + slot)
    HOME.clearProperty(RESULTS_INDEX)


def _tmdb_get(url):
    try:
        import urllib.request       # aquí: flix_section importa este módulo (to_listitem) y no busca en TMDB (C-03)
        with urllib.request.urlopen(url, timeout=6) as r:
            return json.load(r)
    except Exception as e:  # noqa: BLE001
        log("tmdb: %s" % e)
        return {}


def tmdb_search(query, lang="es-ES"):
    """[(tipo, id, título en 'lang', título original), ...] de TMDB (películas y series)"""
    data = _tmdb_get("https://api.themoviedb.org/3/search/multi?" + urllib.parse.urlencode(
        {"api_key": TMDB_KEY, "language": lang, "query": query, "include_adult": "false"}))
    out = []
    for it in data.get("results", []):
        if it.get("media_type") not in ("movie", "tv"):
            continue
        title = it.get("title") or it.get("name") or ""
        orig = it.get("original_title") or it.get("original_name") or ""
        if title:
            out.append((it["media_type"], it.get("id"), title, orig))
    return out


def tmdb_title_es(mtype, tid):
    d = _tmdb_get("https://api.themoviedb.org/3/%s/%s?%s" % (mtype, tid, urllib.parse.urlencode(
        {"api_key": TMDB_KEY, "language": "es-ES"})))
    return d.get("title") or d.get("name") or ""


ALT_SIMILAR = 0.75
ALT_LANGS = ("es-ES", "es-MX", "en-US")     # títulos de España (los de Palantir), latinos e ingleses


RENAMED_MAX = 3


def _bare(n):
    """título normalizado sin artículo delante («the colony» -> «colony»)"""
    for art in ARTICLES:
        if n.startswith(art):
            return n[len(art):]
    return n


def alt_titles(text, stale=None, renamed=None):
    """_alt_titles + el título sin número de secuela: TMDB da antes la secuela («home alone» -> «Solo en casa 3»).
    stale(): True si la búsqueda ya no vale (cancelada, otra encima): no se pide nada más a TMDB.
    renamed: lista que se rellena con los títulos de España de lo que se llama EXACTAMENTE como lo escrito en su idioma
    original o en inglés (ver _alt_titles)"""
    out = _alt_titles(text, stale, renamed)
    for a in list(out):
        base = re.sub(r"\s+(\d+|[ivx]+)$", "", a, flags=re.I)
        if base != a and base not in out:
            out.append(base)
    return out


def _alt_titles(text, stale=None, renamed=None):
    """Títulos en castellano (TMDB) para lo que escribió el usuario en otro idioma, en latino o con erratas: solo se
    aceptan resultados cuyo título ORIGINAL contiene el texto (evita falsos amigos: "dune" ≈ "Anatomie d'une chute")
    o cuyo título (en ese idioma u original) se parece a lo escrito. es-MX / en-US -> título de España del mismo id
    (como mucho EXTRA_TITLES_MAX consultas, y ninguna si stale(): revisión 7-nov PY-14).
    Tolera erratas recortando el texto si TMDB no devuelve nada.
    renamed (lista): los que se llaman EXACTAMENTE como lo escrito en su título original o en inglés y en España de otra
    manera («colony» -> «Zona cero», la coreana «군체» de 2026; Carlos, 11-nov: «no me encuentra Colonia»). Se buscan
    aunque lo escrito ya dé algo parecido («The Colony», la serie «Colony»): con looks_found nunca se miraban"""
    res = {}
    threads = [threading.Thread(target=lambda lg=lg: res.__setitem__(lg, tmdb_search(text, lg)), daemon=True)
               for lg in ALT_LANGS]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=8)
    q = text
    while not res.get("es-ES") and len(q) > 4:
        q = q[:-1]
        res["es-ES"] = tmdb_search(q)
    n0, nq = norm(text), norm(q)
    es_titles = {(m, i): t for m, i, t, _ in res.get("es-ES") or []}
    out, extra = [], 0
    for lang in ALT_LANGS:
        for mtype, tid, title, orig in (res.get(lang) or [])[:8]:
            nl, no = norm(title), norm(orig)
            # vale si el título original contiene lo escrito, o si lo escrito se PARECE al título entero (erratas,
            # títulos latinos: "interestelar" -> Interstellar 0,92; "dune" vs "anatomie d une chute" 0,33)
            close = max(_ratio(n0, no).ratio(), _ratio(n0, nl).ratio()) >= ALT_SIMILAR
            same = n0 in (no, _bare(no)) or (lang == "en-US" and n0 in (nl, _bare(nl)))
            contains = lang == "es-ES" and len(nq) > SHORT_MAX and re.search(r"\b%s\b" % re.escape(nq), no)
            if not close and not contains:          # «up» no vale por estar en «Keeping Up with the Kardashians»
                continue
            want_ren = same and renamed is not None and len(renamed) < RENAMED_MAX
            if len(out) >= MAX_ALT_TITLES and not want_ren:
                continue                            # lleno: sin más consultas a TMDB que no sirvan para nada
            if lang == "es-ES":
                t = title
            elif es_titles.get((mtype, tid)):
                t = es_titles[(mtype, tid)]
            else:
                if extra >= EXTRA_TITLES_MAX or (stale and stale()):
                    continue
                extra += 1
                t = tmdb_title_es(mtype, tid)
            nt = norm(t)
            if not nt or nt == n0 or nt in n0 or n0 in nt:
                continue
            if want_ren and nt not in [norm(x) for x in renamed]:
                renamed.append(t)
            if nt not in [norm(x) for x in out] and len(out) < MAX_ALT_TITLES:
                out.append(t)
    return out


class AltTitles(threading.Thread):
    """alt_titles en segundo plano mientras Palantir busca lo escrito: si hacen falta, ya están (no suma tiempo)"""

    def __init__(self, text, stale=None):
        super().__init__(daemon=True)
        self.text, self.stale = text, stale
        self.result = []
        self.renamed = []           # títulos de España de lo que se llama así en su idioma original o en inglés

    def run(self):
        try:
            self.result = alt_titles(self.text, stale=self.stale, renamed=self.renamed)
        except Exception as e:  # noqa: BLE001
            log("tmdb: %s" % e)


# ---------- variantes (solo si lo escrito no da nada parecido) ----------
ARTICLES = ("el ", "la ", "los ", "las ", "lo ", "un ", "una ", "the ", "a ")
SIMILAR = 0.85
NUMS = [("1", "uno", "one"), ("2", "ii", "dos", "two"), ("3", "iii", "tres", "three"), ("4", "iv", "cuatro", "four"),
        ("5", "v", "cinco", "five"), ("6", "vi", "seis", "six"), ("7", "vii", "siete", "seven"),
        ("8", "viii", "ocho", "eight"), ("9", "ix", "nueve", "nine"), ("10", "x", "diez", "ten")]
MAX_VARIANTS = 16   # cada variante es un iREGEXP más por fila en Palantir (Python): pocas


def _ratio(a, b):
    from difflib import SequenceMatcher     # solo al buscar (C-03)
    return SequenceMatcher(None, a, b)


def looks_found(text, titles):
    """¿algún resultado se parece a lo buscado? (si no, se prueban variantes y TMDB). «fight club» -> «The Good Fight
    Club» NO; «padrino» -> «El padrino», «harry potter» -> «Harry Potter y la piedra filosofal» SÍ."""
    n0 = norm(text)
    if not n0:
        return True
    for title in titles:
        nt = norm(title)
        for art in ARTICLES:
            if nt.startswith(art):
                nt = nt[len(art):]
                break
        if nt == n0 or nt.startswith(n0 + " ") or _ratio(n0, nt).ratio() >= SIMILAR:
            return True
        if len(n0.split()) >= 3 and re.search(r"\b%s\b" % re.escape(n0), nt):
            return True
    return False


SHORT_MAX = 3   # «up», «it», «f1»: Palantir da cientos de títulos con esas letras dentro de otras palabras


def is_short(text):
    n = norm(text)
    return bool(n) and " " not in n and len(n) <= SHORT_MAX


def word_match(text, title):
    """¿lo buscado está en el título como palabra entera? («up» en «Up» o «Pop-Up», no en «Superficie»)"""
    return re.search(r"\b%s\b" % re.escape(norm(text)), norm(title)) is not None


def is_exact(text, title):
    """el título es lo buscado (sin mayúsculas, tildes, signos ni artículo delante: «padrino» = «El padrino»)"""
    n0, nt = norm(text), norm(title)
    for art in ARTICLES:
        if nt.startswith(art) and not n0.startswith(art):
            nt = nt[len(art):]
            break
    return bool(n0) and nt == n0


def exact_first(rows, text):
    """orden de las filas: primero las que empiezan por el título exacto; si son todas o ninguna, como venían"""
    labels = list(rows)
    hit = [k for k in labels if rows[k] and is_exact(text, clean_title(rows[k][0].get("title") or rows[k][0].get("label")))]
    if not hit or len(hit) == len(labels):
        return labels
    return hit + [k for k in labels if k not in hit]


def variants(text):
    """otras formas de escribir lo buscado para la misma consulta de Palantir (OR): u -> ú (Palantir busca la ú como
    «o»: «ultima» no da «última»), espacios juntos/separados, números 2/II/dos (+ «parte 2») y plural sin s"""
    t = " ".join(text.lower().split())
    out = []

    def add(v):
        if v and v != t and v not in out:
            out.append(v)
    us = [i for i, c in enumerate(t) if c == "u"]
    for i in us[:3]:
        add(t[:i] + "ú" + t[i + 1:])
    if len(us) > 1:
        add(t.replace("u", "ú"))
    if "ú" in t:
        add(t.replace("ú", "u"))
    words = t.split(" ")
    if len(words) > 1:
        add("".join(words))
        for k in range(min(len(words) - 1, 3)):
            add(" ".join(words[:k] + [words[k] + words[k + 1]] + words[k + 2:]))
    elif 6 <= len(t) <= 10 and t.isalpha():
        for k in range(3, len(t) - 2):            # «shinchan» -> «shin chan» (trozos de 3 letras o más)
            add(t[:k] + " " + t[k:])
    for k, w in enumerate(words):
        for g in NUMS:
            if w in g and (w != "v" or k):         # «v de vendetta»: la v inicial no es un número
                for alt in g:
                    add(" ".join(words[:k] + [alt] + words[k + 1:]))
                if k and words[k - 1] != "parte":  # «dune 2» -> «Dune: Parte dos»
                    for alt in g[:3]:
                        add(" ".join(words[:k] + ["parte", alt] + words[k + 1:]))
    for k, w in enumerate(words):
        if len(w) > 4 and w.endswith("s"):
            add(" ".join(words[:k] + [w[:-1]] + words[k + 1:]))
    return out[:MAX_VARIANTS]


# ---------- teclado de Palantir ----------
class KeyboardAccepter(threading.Thread):
    """Mientras dura la consulta: escribe el texto en el teclado de Palantir y cierra su diálogo
    "No se han encontrado resultados" (okdialog) si aparece."""

    def __init__(self, text, timeout=180.0):
        super().__init__(daemon=True)
        self.text = text
        self.timeout = timeout
        self.stop = False
        self.typed = False

    def run(self):
        mon = xbmc.Monitor()
        t0 = time.time()
        while not self.stop and time.time() - t0 < self.timeout and not mon.abortRequested():
            if not self.typed and xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                xbmc.sleep(300)
                if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                    rpc("Input.SendText", {"text": self.text, "done": True})
                    self.typed = True
            elif xbmc.getCondVisibility("Window.IsActive(okdialog)"):
                xbmc.executebuiltin("Dialog.Close(okdialog,true)")
                log("cerrado diálogo de Palantir")
            xbmc.sleep(100)


def _sql_text(text):
    """texto para meter entre comillas en la SQL de Palantir (es un regex suyo: metacaracteres -> cualquier carácter)"""
    return re.sub(r"[\\'\"()\[\]{}*+?|^$]", ".", text).strip()


def relevance_order(terms):
    """ORDER BY: título exacto > empieza igual > el resto; dentro, los más cortos primero («Up», «It», «El padrino»
    quedaban fuera de la 1.ª página por el orden alfabético)"""
    ts = [re.sub(r"[\\'\"]", "", t).strip().lower() for t in terms]
    ts = [t for t in ts if t]
    if not ts:
        return "ORDER BY titulo COLLATE latin1"
    exact = " OR ".join("lower(titulo) = '%s'" % t for t in ts)
    start = " OR ".join("substr(lower(titulo), 1, %d) = '%s'" % (len(t), t) for t in ts)
    return "ORDER BY CASE WHEN %s THEN 0 WHEN %s THEN 1 ELSE 2 END, length(titulo), titulo COLLATE latin1" % (exact, start)


def direct_route(route, text, terms=None):
    """Ruta 'buscar3' (Palantir pide el texto con su teclado) -> misma SQL ya rellenada con acción de
    listado normal (listado_peliculaS / listado_serieS): sin teclado y ~2 s. None si no es convertible.
    terms: buscar estas variantes (OR) en vez de 'text'. Orden por relevancia en vez de alfabético."""
    try:
        j = decode_route(route)
    except Exception:
        return None
    if "'buscar3'" not in j or "'%s'" not in j:
        return None
    sql = re.search(r'"sql": "(.*?)"[,}]', j, re.S)
    if not sql or "FROM" not in sql.group(1).upper():
        return None
    tbl = re.search(r'FROM\s+(\S+)', sql.group(1), re.I).group(1).lower()
    if "serie" in tbl:
        action, content = "listado_serieS", "tvshows"
    else:
        action, content = "listado_peliculaS", "movies"
    terms = terms or [text]
    j = j.replace("'buscar3'", "'%s'" % action).replace('"content": \'files\'', '"content": \'%s\'' % content)
    cond = re.search(r"iREGEXP\s*\(\s*'%s'\s*,\s*titulo\s*\)", j)
    if cond:
        where = " OR ".join("iREGEXP ('%s', titulo)" % _sql_text(t) for t in terms)
        j = j[:cond.start()] + ("(%s)" % where if len(terms) > 1 else where) + j[cond.end():]
    else:
        j = j.replace("'%s'", "'" + _sql_text(terms[0]) + "'", 1)
    j = re.sub(r"ORDER\s+by\s+titulo\s+COLLATE\s+latin1", lambda m: relevance_order(terms), j, count=1, flags=re.I)
    return encode_route(j)


class NoAnswer(Exception):
    """Files.GetDirectory devolvió un error en vez de un listado (aunque fuera vacío): Palantir no contestó"""


def fetch(route, text, terms=None):
    """resultados de una búsqueda; NoAnswer si Palantir no contestó (antes daba [] y salía «Sin resultados»; TV-12)"""
    acc = KeyboardAccepter(text)
    acc.start()
    r = rpc("Files.GetDirectory", {
        "directory": direct_route(route, text, terms) or route, "media": "video",
        "properties": ["title", "art", "plot", "year", "genre", "rating", "duration", "mpaa", "premiered", "file", "playcount", "resume",
                       "uniqueid"],     # id TMDB: con la consulta conjunta, cada resultado vuelve a la fila de su sección
    })
    acc.stop = True
    acc.join(timeout=0.5)
    if r.get("error"):
        raise NoAnswer(str(r["error"]))
    return (r.get("result") or {}).get("files") or []


# ---------- historial ----------
def history():
    items = []
    for i in range(1, HIST_MAX + 1):
        v = xbmc.getInfoLabel("Skin.String(flix_hist%d)" % i)
        if v:
            items.append(v)
    return items


def push_history(text):
    items = [text] + [h for h in history() if h.lower() != text.lower()]
    items = items[:HIST_MAX]
    for i in range(1, HIST_MAX + 1):
        val = items[i - 1] if i <= len(items) else ""
        xbmc.executebuiltin(flix_builtin.set_string("flix_hist%d" % i, val))


# ---------- teclado en pantalla (TV y táctil; en táctil Kodi no puede abrir el teclado de Android) ----------
TOUCH = xbmc.getSkinDir().endswith(".touch")
KEYS = list("1234567890qwertyuiopasdfghjklñzxcvbnm'")   # orden QWERTY; FlixSearch.xml: botones 6000 + índice
SYMS = list("1234567890" "@#&_-+()/:" ";!?,.'\"*%=" "¿¡[]$~€º")  # capa de símbolos (tecla ?123), mismo nº de teclas
assert len(SYMS) == len(KEYS)
KEY_SPACE, KEY_BACK, KEY_CLEAR, KEY_ENTER, KEY_TOGGLE, KEY_VOICE = 6090, 6091, 6092, 6093, 6094, 6095
A_CONTEXT, A_VOICE = (101, 117), 300   # mantener OK = menú contextual en nuestra ventana; tecla de voz del mando
MENU_WAIT = 180   # s: lo más que se espera a que acabe flix_menu (diálogos de Palantir) para poner ✓ y ▶ al día
KEY_FIRST = 6010  # foco al abrir el teclado (la "q")
BOX = 5309      # caja de búsqueda: tocarla vuelve a mostrar el teclado
PREVIEW = 5290  # tira de carátulas visible encima del teclado mientras se escribe (resultados en vivo)
# búsqueda en vivo (solo táctil) tras una pausa al teclear (cada búsqueda = ~8 llamadas a Palantir, de una en una).
# En la TV no hay búsqueda en vivo: con el mando cada letra tarda >1 s y lanzaba "bat", "batm"… -> solo "Buscar".
LIVE_DELAY, LIVE_MIN = 1.2, 3
LIVE_SPACING = 3.0   # s entre dos búsquedas en vivo: tecleando despacio encadenaba 2-3 («bat», «batm»…) (TAC-08)
# táctil: los resultados (teclado oculto) se ven en la ventana del Inicio (flix_home.py search): una lista vertical con
# inercia, como el Inicio y las secciones (aquí era un grouplist: sin inercia, a saltos; Carlos, 20-oct). Las filas le
# llegan por este fichero según responde Palantir (= flix_home.SEARCH_FILE).
SEARCH_FILE = xbmcvfs.translatePath("special://temp/flix_search_rows.json")


# ---------- ventana ----------
class SearchWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.query = kwargs.get("query", "")
        self.shown, self.items = {}, {}             # lo pintado en cada lista: títulos de Palantir y sus ListItem
        self.paint_lock = threading.RLock()
        self.ctx = {"srcs": [], "of": {}}           # TV: listado sin teclado de cada resultado (open_menu)

    def onInit(self):
        # Kodi vuelve a llamar a onInit al volver de una ficha, una serie o un vídeo: los resultados siguen en la
        # ventana, así que solo se vuelve a enlazar la caja (auditoría PY-02: antes se repetía la búsqueda entera)
        if getattr(self, "started", False):
            try:
                ctl = self.getControl(BOX)
                self.edit = ctl if isinstance(ctl, xbmcgui.ControlEdit) else None
            except Exception:  # noqa: BLE001
                self.edit = None
            self.repaint()                          # tras recargar la skin las listas vuelven vacías
            if getattr(self, "results_open", False):  # Atrás en la ventana de resultados: al teclado con lo buscado
                self.results_open = False
                self.show_kbd(True)
                return
            self.show_kbd(getattr(self, "kbd", False))  # Kodi devuelve el foco al control por defecto (tecla oculta)
            return
        self.started = True
        self.setProperty("flix_state", "loading" if self.query else "idle")
        self.abort = False
        self.worker = None
        self.typed = self.query
        self._deb = 0
        self.phys = False                               # escribe con un teclado físico (edit_changed)
        self.sym = False
        self.paint_keys()
        # caja = control edit en la TV (teclado físico); en la táctil es un botón
        try:
            ctl = self.getControl(BOX)
            self.edit = ctl if isinstance(ctl, xbmcgui.ControlEdit) else None
        except Exception:  # noqa: BLE001
            self.edit = None
        self.set_typed(self.typed)
        self.titles = TitleIndex()                      # lista de títulos de Palantir mientras se escribe
        self.titles.start()
        self.show_kbd(not self.query)                   # sin texto: teclado a la vista
        if self.query:
            self.start_search(self.query)
            self.show_results()
        if not TOUCH:                                   # QR para escribir desde el móvil (flix_phonekb.py)
            import flix_phonekb
            self.phone = flix_phonekb.PhoneKeyboard(self.phone_text, "Buscar películas y series", props=self).start()

    def phone_text(self, text):
        """texto escrito (o dictado) en el móvil: busca ya, como el dictado por voz"""
        if getattr(self, "abort", False):
            return
        self.set_typed(text)
        self._deb += 1
        self.show_kbd(False)
        push_history(text)
        self.cancel_search()
        self.start_search(text, record=False)
        self.show_results()

    def fill(self, cid, files, append=False):
        """pinta una lista por id (reset/addItems: seguros tras recargar la skin) y guarda lo pintado. Nada de
        getSelectedItem ni getSelectedPosition: tras una actualización automática el objeto de Python apunta a la
        lista vieja, ya borrada, y Kodi se cae (SIGSEGV, auditoría 22-oct A-01)"""
        new = [to_listitem(f) for f in files]
        with self._lock():
            ctl = self.getControl(cid)
            if append:
                self.shown.setdefault(cid, []).extend(files)
                self.items.setdefault(cid, []).extend(new)
            else:
                ctl.reset()
                self.shown[cid], self.items[cid] = list(files), new
            if new:
                ctl.addItems(new)

    def _lock(self):
        lock = getattr(self, "paint_lock", None)
        if lock is None:
            lock = self.paint_lock = threading.RLock()
        return lock

    def sel_item(self, cid):
        """ListItem seleccionado, con la posición que dice Kodi y los ListItem guardados"""
        try:
            pos = int(xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) or 0) - 1
        except ValueError:
            return None
        items = getattr(self, "items", {}).get(cid) or []
        return items[pos] if 0 <= pos < len(items) else None

    def repaint(self):
        """al volver a la ventana: si una lista con resultados está vacía, la skin se recargó -> se vuelve a pintar
        con ListItem nuevos (A-07: antes quedaba el resumen sin resultados y el foco en una fila vacía)"""
        with self._lock():
            for cid, files in list(getattr(self, "shown", {}).items()):
                if files and xbmc.getInfoLabel("Container(%d).NumItems" % cid) in ("", "0"):
                    log("lista %d vacía al volver (skin recargada): repinto %d" % (cid, len(files)))
                    self.fill(cid, files)

    def start_search(self, text, record=True):
        self.abort = False
        self.gen = getattr(self, "gen", 0) + 1          # cada búsqueda su número: la anterior queda obsoleta
        if TOUCH:                                       # ya, no en el hilo: show_results no debe ver las de antes
            self.results, self.result_paths = {}, {}
            self.write_results(self.gen)
        else:
            self.ctx = {"srcs": [], "of": {}}
        self.worker = threading.Thread(target=self._guarded_search, args=(text, record, self.gen), daemon=True)
        self.worker.start()

    def set_typed(self, text):
        """Texto escrito -> etiqueta de la caja y control edit (sin que cuente como tecleo físico)."""
        self.typed = text
        self.setProperty("flix_typed", text)
        if getattr(self, "edit", None):
            self.edit_seen = text
            self.edit.setText(text)

    def edit_changed(self):
        """onClick de la caja edit: Kodi lo manda por cada cambio de texto (teclado físico o su teclado propio)
        y con Intro sin cambios. Intro = Buscar; un salto de varias letras (teclado de Kodi, pegar) busca ya."""
        text = self.edit.getText()
        prev = getattr(self, "edit_seen", "")
        if text == prev:
            self.type_key(KEY_ENTER)
            return
        if len(text) == len(prev) - 1 and not getattr(self, "phys", False):
            # Atrás del mando en Android: llega como retroceso y el edit ya ha borrado la letra (su clic llega antes
            # que el onAction). Sin escribir con un teclado físico, Atrás no borra (Carlos 30-oct): vuelve la letra y
            # onAction lo trata como Atrás
            self.set_typed(prev)
            self.edit_time = 0
            return
        self.edit_seen = text
        self.edit_time = time.time()
        self.typed = text
        self.setProperty("flix_typed", text)
        self._deb += 1
        if abs(len(text) - len(prev)) == 1:          # una letra: teclado físico
            if len(text) > len(prev):                # solo una letra de más (borrar no lo marca, era el Atrás)
                self.phys = True                     # en esta apertura su retroceso sí borra
                if not xbmc.getCondVisibility("Skin.HasSetting(flix_physkbd)"):
                    xbmc.executebuiltin("Skin.SetBool(flix_physkbd)")   # en adelante el buscador abre con foco en la caja
            if not self.kbd:
                self.show_kbd(True, focus=BOX)
            if TOUCH:
                threading.Timer(LIVE_DELAY, self._live, args=(self._deb,)).start()
        else:
            self.type_key(KEY_ENTER)

    # --- resultados en la ventana del Inicio (táctil) ---
    def write_results(self, gen, done=False):
        rows = [{"label": k, "path": self.result_paths.get(k, ""), "files": v} for k, v in list(self.results.items())]
        try:
            atomic_write(SEARCH_FILE, json.dumps({"gen": gen, "done": done, "rows": rows}))
        except OSError as e:
            log("no escribo %s: %s" % (SEARCH_FILE, e))

    def show_results(self):
        """teclado oculto con una búsqueda: sus resultados en la ventana del Inicio en cuanto haya una fila"""
        if not TOUCH:
            return
        self.want_results = True
        self.open_results()

    def open_results(self):
        if not (getattr(self, "want_results", False) and getattr(self, "results", None)) or self.kbd \
                or getattr(self, "results_open", False):
            return
        self.want_results, self.results_open = False, True
        HOME.setProperty("flix_search_title", "«%s»" % self.query)
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,search)")

    # --- teclado táctil ---
    def show_kbd(self, on, focus=None):
        self.kbd = on
        self.setProperty("flix_kbd", "1" if on else "")
        if on and not TOUCH:
            if focus is None and getattr(self, "edit", None) and xbmc.getCondVisibility("Skin.HasSetting(flix_physkbd)"):
                focus = BOX                         # ya usó teclado físico: a escribir directamente
            self.setFocusId(focus or KEY_FIRST)
        elif not on and not TOUCH:
            self.focus_results()

    def focus_results(self):
        for rid in ROW_IDS:
            if getattr(self, "shown", {}).get(rid):  # no size(): tras recargar es una copia que miente
                self.setFocusId(rid)
                return
        self.setFocusId(BOX)

    def paint_keys(self):
        """Etiquetas de las teclas según la capa (letras / símbolos), como el toggle ?123 de Android."""
        layer = SYMS if self.sym else KEYS
        for i, ch in enumerate(layer):
            self.setProperty("flix_k%d" % i, ch.upper() if ch.isalpha() else ch)
        self.setProperty("flix_ktoggle", "ABC" if self.sym else "?123")

    def voice(self):
        """Dictado: abre el teclado de Kodi y le manda VoiceRecognizer (en ese teclado, mantener OK = voz de
        Android, como antes); lo dictado pasa a la búsqueda."""
        def go():
            xbmc.sleep(500)
            if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                xbmc.executebuiltin("Action(VoiceRecognizer)")
        threading.Thread(target=go, daemon=True).start()
        kb = xbmc.Keyboard(self.typed, "Buscar películas y series")
        HOME.setProperty("flix_voice", "1")         # DialogKeyboard.xml no se autocierra
        try:
            kb.doModal()
        finally:
            HOME.clearProperty("flix_voice")
        if not kb.isConfirmed():
            return
        text = kb.getText().strip()
        if not text:
            return
        self.set_typed(text)
        self._deb += 1
        self.show_kbd(False)
        push_history(text)
        self.cancel_search()
        self.start_search(text, record=False)
        self.show_results()

    def type_key(self, control_id):
        if KEY_ENTER == control_id:                 # Buscar: busca ya y oculta el teclado
            self._deb += 1
            self.show_kbd(False)
            text = self.typed.strip()
            if text:
                push_history(text)                  # recientes: lo buscado con «Buscar» (lo tecleado en vivo, no)
            if text and text != self.query:
                self.cancel_search()
                self.start_search(text, record=False)
            if text:
                self.show_results()
            return
        if KEY_TOGGLE == control_id:
            self.sym = not self.sym
            self.paint_keys()
            return
        if KEY_BACK == control_id:
            self.typed = self.typed[:-1]
        elif KEY_CLEAR == control_id:
            self.typed = ""
        elif KEY_SPACE == control_id:
            if self.typed and not self.typed.endswith(" "):
                self.typed += " "
        else:
            self.typed += (SYMS if self.sym else KEYS)[control_id - 6000]
        self.set_typed(self.typed)
        self._deb += 1
        if TOUCH:   # en vivo solo en la táctil; en la TV se busca al pulsar "Buscar" (pedido de Carlos)
            threading.Timer(LIVE_DELAY, self._live, args=(self._deb,)).start()

    def _live(self, deb):
        if deb != self._deb:
            return                                  # se siguió tecleando
        text = self.typed.strip()
        if not text:
            self.cancel_search()
            self.clear_rows()
            self.query = ""
            self.setProperty("flix_state", "idle")
            return
        if len(text) < LIVE_MIN or text == self.query:
            return
        since = time.time() - getattr(self, "live_at", 0.0)
        if since < LIVE_SPACING:                    # la anterior lleva menos de 3 s: se encola (vuelve a mirar lo tecleado)
            threading.Timer(LIVE_SPACING - since, self._live, args=(deb,)).start()
            return
        self.live_at = time.time()
        self.cancel_search()
        self.start_search(text, record=False)

    def cancel_search(self):
        # la búsqueda en curso queda obsoleta al instante (sus resultados ya no se pintan aunque lleguen tarde);
        # no se espera a que Palantir termine la consulta que tenga entre manos
        self.gen = getattr(self, "gen", 0) + 1
        self.abort = False
        self.wake_event().set()                     # la espera a Palantir de la obsoleta se entera ya

    def wake_event(self):
        """Event que despiertan los hilos de consulta al acabar y la cancelación: la espera de run_query ya no es un
        sleep de 50 ms (revisión 7-nov PY-28)"""
        ev = self.__dict__.get("wake")
        if ev is None:
            ev = self.__dict__["wake"] = threading.Event()
        return ev

    def clear_rows(self):
        for i, rid in enumerate(ROW_IDS, 1):
            self.fill(rid, [])
            self.setProperty("flix_row%d" % i, "")
        self.fill(PREVIEW, [])
        self.setProperty("flix_summary", "")

    def _guarded_search(self, text, record=True, gen=0):
        try:
            self.run_search(text, record, gen)
        except Exception as e:  # noqa: BLE001
            log("búsqueda abortada/fallida: %s" % e)

    def onAction(self, action):
        aid = action.getId()
        if (aid == 61448 and getattr(self, "edit", None) and self.getFocusId() == BOX
                and time.time() - getattr(self, "edit_time", 0) < 0.4):
            return          # retroceso crudo que el edit ya ha aplicado (su clic llega antes): no es "Atrás"
        if (aid == 110 or aid == 92 and getattr(self, "phys", False)) and getattr(self, "edit", None) \
                and self.getFocusId() == BOX and self.typed:
            # Retroceso (110) y, escribiendo con un teclado físico, el retroceso que Kodi da como "Atrás" (92) en la
            # caja con texto: borra una letra, como el teclado de Kodi. Sin teclado físico, el 92 (mando CEC o IR)
            # es Atrás (Carlos 30-oct)
            log("caja: retroceso (accion %d, boton %d)" % (aid, action.getButtonCode()))
            self.set_typed(self.edit.getText()[:-1])
            return
        if aid in A_BACK:  # Atrás (comunes, TV-28: antes sin el 9)
            if not getattr(self, "kbd", False) and self.query:
                self.show_kbd(True)                 # Atrás con resultados: vuelve al teclado con lo buscado (NAV-07)
                return
            self.abort = True
            self.wake_event().set()
            self.close()
            return
        if aid in (7, 135) and getattr(self, "edit", None) and self.getFocusId() == BOX:
            # OK del mando / Intro del teclado físico en la caja (el teclado de Kodi que abre el edit ya lo ha
            # cerrado DialogKeyboard.xml): escribiendo con texto = Buscar; si no, a nuestro teclado
            if self.kbd and self.typed.strip():
                self.type_key(KEY_ENTER)
            else:
                self.show_kbd(True, focus=KEY_FIRST)
            return
        if aid == A_VOICE or (aid in A_CONTEXT and (self.getFocusId() >= 6000 or self.getFocusId() in (BOX, 5300) or 5301 <= self.getFocusId() <= 5305)):
            self.voice()                            # mantener OK en el teclado / caja = hablar
            return
        if aid in A_CONTEXT and not TOUCH and (self.getFocusId() in ROW_IDS or self.getFocusId() == PREVIEW):
            if HOME.getProperty("flix_ctx_auto"):
                super().onAction(action)            # flix_menu abriendo por detrás el menú de Kodi (lista oculta FlixCtx)
            else:
                self.open_menu(self.getFocusId())
            return
        super().onAction(action)

    def remember_src(self, src, files):
        """TV: de qué listado sin teclado salió cada resultado (el de su sección con lo buscado: direct_route), para
        su menú KER0N3 (open_menu). Se guarda el índice del listado, no el listado en cada título: van con los
        resultados a la memoria de búsquedas (results_put) y cada listado son ~1-2 KB"""
        if not src:
            return
        ctx = self.__dict__.setdefault("ctx", {"srcs": [], "of": {}})
        if src not in ctx["srcs"]:
            ctx["srcs"].append(src)
        i = ctx["srcs"].index(src)
        for f in files:
            ctx["of"].setdefault(f.get("file", ""), i)

    def open_menu(self, cid):
        """menú KER0N3 (flix_menu.py: vista, resolución, favoritos…) del resultado con foco, como en las filas del Inicio
        y de las secciones. Los resultados son listas de Python sin menú de Kodi: flix_menu pulsa la opción de Palantir
        desde una lista oculta (FlixCtx) con el listado de donde salió. Antes salía el menú de Kodi, vacío (Carlos,
        31-oct)"""
        item = self.sel_item(cid)
        path = item.getPath() if item else ""
        ctx = getattr(self, "ctx", None) or {"srcs": [], "of": {}}
        i = ctx["of"].get(path)
        if i is None or not path.startswith(PLUGIN_ROOT) or i >= len(ctx["srcs"]):
            log("menú: sin listado para %s" % (item.getLabel() if item else "nada"))
            return
        HOME.setProperty("flix_ctx_src", ctx["srcs"][i])
        t0 = time.time()
        xbmc.executebuiltin('RunScript(special://skin/scripts/flix_menu.py,"%s","%s","%s",sec)'
                            % (path, item.getArt("poster"), item.getLabel().replace('"', "'")))
        threading.Thread(target=self.after_menu, args=(cid, t0, getattr(self, "gen", 0)), daemon=True).start()

    def after_menu(self, cid, t0, gen):
        """cuando flix_menu acaba (flix_menu_done): ✓ y ▶ al día en la fila, sin mover la selección"""
        mon, end = xbmc.Monitor(), t0 + MENU_WAIT
        while not self.stale(gen) and time.time() < end and not mon.abortRequested():
            done = HOME.getProperty("flix_menu_done")
            if done and float(done) > t0:
                break
            mon.waitForAbort(0.5)
        else:
            return
        if self.stale(gen):
            return
        import flix_rows
        try:
            pos = int(xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) or 0) - 1
        except ValueError:
            pos = 0
        focus = self.getFocusId()
        self.fill(cid, flix_rows._progress(self.shown.get(cid) or []))
        if pos > 0:
            self.getControl(cid).selectItem(pos)
        if focus == cid:
            self.setFocusId(cid)                    # Kodi suelta el foco de una lista que se vacía

    def stale(self, gen):
        return self.abort or (gen and gen != getattr(self, "gen", 0))

    def run_search(self, text, record=True, gen=0):
        t0 = time.time()
        log("buscar %s" % text)             # principio y fin (_run_search) de C3 sin depuración (revisión 29-oct DAT-22)
        self.query = text
        HOME.setProperty("flix_query", text)
        self.setProperty("flix_state", "loading")
        self.setProperty("flix_summary", "")
        self.setProperty("flix_error", "")
        for i, rid in enumerate(ROW_IDS, 1):
            self.fill(rid, [])
            self.setProperty("flix_row%d" % i, "")
        self.fill(PREVIEW, [])

        try:
            xbmcaddon.Addon("plugin.video.palantir3").setSetting("Query", text)
        except Exception as e:  # noqa: BLE001  (Palantir desactivado o desinstalado)
            # antes la excepción salía con flix_state=loading puesto: «Buscando…» para siempre (auditoría 22-oct B-09)
            log("Palantir no disponible: %s" % e)
            self.setProperty("flix_summary", "Palantir no está disponible")
            self.setProperty("flix_error", "1")
            self.setProperty("flix_state", "done")
            return
        if record:
            push_history(text)
        stamp = str(int(time.time()))

        summary = []
        row = 0
        # Palantir pone p3_play=true tras una búsqueda y mientras esté puesto reutiliza la anterior sin preguntar
        # (el skin original la limpia antes de buscar).
        HOME.clearProperty("p3_play")
        HOME.setProperty("flix_searching", "true")
        try:
            self._run_search(text, stamp, gen, t0)
        finally:
            if not gen or gen == getattr(self, "gen", 0):   # una búsqueda vieja no apaga la marca de la nueva
                HOME.clearProperty("flix_searching")

    def _run_search(self, text, stamp, gen=0, t0=None):
        t0 = t0 or time.time()
        routes = section_search_routes()
        if not routes:
            log("no encuentro rutas de búsqueda por sección; uso la global")
            routes = [["Resultados", global_search_route()]]
        hit = results_get(text, routes)
        if hit:                             # la misma búsqueda hace menos de 10 min: sin preguntar a Palantir (APA-04)
            self.replay(hit, gen)
            log("fin %s: %d filas en %.1f s (de memoria)" % (text, len(hit["rows"]), time.time() - t0))
            return
        rows_by_label = {}
        seen = set()
        used = []
        lock = threading.Lock()
        qlock = threading.Lock()        # orden de entrega de las filas (deliver coge «lock» por dentro)
        failed, answered = [], []       # consultas sin respuesta de Palantir / con respuesta (TV-12)

        def one(q, label, route, i, terms=None):
            if self.stale(gen):
                return
            HOME.clearProperty("p3_play")
            t0 = time.time()
            try:
                items = fetch("%s&reload=%d%d" % (route, int(time.time() * 1000), i), q, terms)
                answered.append(label)
            except Exception as e:  # noqa: BLE001  (la fila vacía no debe dejar esperando a las siguientes)
                log("sección %s: %s" % (label, e))
                failed.append(label)
                items = []
            if self.stale(gen):
                return
            run_query.put(i, (q, label, route, items, terms, time.time() - t0))

        def deliver(q, label, route, items, terms, dt):
            """resultados de una sección a su fila (sin repetidos de otras secciones)"""
            with lock:
                items = [f for f in items if f.get("file") and f["file"] not in seen]
                log("sección %s %r%s -> %d (%.1fs)" % (label, q, " +%d variantes" % len(terms) if terms else "",
                                                       len(items), dt))
                for f in items:
                    seen.add(f["file"])
                    found.append(clean_title(f.get("title") or f.get("label")))
                if short and not terms:
                    # «up»: Palantir busca letras sueltas dentro de las palabras (SUPerficie, BUPkis…): solo la palabra
                    # entera; lo demás se guarda por si no hay nada mejor
                    keep = [f for f in items if word_match(q, clean_title(f.get("title") or f.get("label")))]
                    spare.extend((label, route, f) for f in items if f not in keep)
                    items = keep
                show(q, label, route, items, terms)

        def group(q, idx, ids, terms=None, per=None):
            """secciones del mismo tipo en una consulta (plan()); cada resultado a la fila de su sección por su id TMDB
            (per: los candidatos de cada sección, ya calculados en plan()). Si alguno no se puede colocar (sin id o
            fuera de los candidatos), ese grupo se repite sección a sección."""
            if self.stale(gen):
                return
            HOME.clearProperty("p3_play")
            t0 = time.time()
            rt = combined_route(routes[idx[0]][1], q, terms, ids, len(ids))
            try:
                items = fetch("%s&reload=%d%d" % (rt, int(time.time() * 1000), idx[0]), q, terms) if rt else None
                if rt:
                    answered.append(idx[0])
            except NoAnswer as e:           # como antes con el error: filas vacías, sin repetir sección a sección
                log("consulta conjunta: %s" % e)
                failed.append(idx[0])
                items = []
            except Exception as e:  # noqa: BLE001
                log("consulta conjunta: %s" % e)
                items = None
            if self.stale(gen):
                return
            if per is None:
                keys = [loose(t) for t in (terms or [q])]
                per = {i: set(blobs.ids(view_of(routes[i][1]), keys)) for i in idx}
            rows, taken = {i: [] for i in idx}, set()
            for f in items or []:
                try:
                    tid = int((f.get("uniqueid") or {}).get("tmdb") or 0)
                except (TypeError, ValueError):
                    tid = 0
                home = next((i for i in idx if tid in per[i]), None)
                if home is not None:
                    rows[home].append(f)
                    taken.add(id(f))
            if items is None or len(taken) < len([f for f in items if f.get("file")]):
                log("consulta conjunta %s sin repartir del todo: sección a sección" % [routes[i][0] for i in idx])
                for i in idx:
                    one(q, routes[i][0], routes[i][1], i, terms)
                return
            dt = time.time() - t0
            log("consulta conjunta %s %r -> %d (%.1fs)" % ([routes[i][0] for i in idx], q, len(items), dt))
            for i in idx:
                run_query.put(i, (q, routes[i][0], routes[i][1], rows[i], terms, dt))

        def show(q, label, route, items, terms=None):
            """añade a su fila (lo de variantes / TMDB, delante); con el cerrojo cogido"""
            if not items:
                return
            if label not in rows_by_label:
                if len(rows_by_label) >= len(ROW_IDS):
                    return
                rows_by_label[label] = []
            # variantes / TMDB solo se buscan si lo de antes no se parecía: lo nuevo va delante
            old = rows_by_label[label] if terms else []
            rows_by_label[label] = items + old if terms else rows_by_label[label] + items
            order = exact_first(rows_by_label, text)
            if order != list(rows_by_label):        # fila con el título exacto: arriba nada más llegar
                focus = self.getFocusId()
                was = list(rows_by_label)
                moved = {k: rows_by_label[k] for k in order}
                rows_by_label.clear()
                rows_by_label.update(moved)
                log("fila %s con %r exacto: arriba" % (order[0], text))
                if not TOUCH:
                    for i, k in enumerate(order):
                        if k == label:
                            continue                # la nueva se pinta abajo
                        self.setProperty("flix_row%d" % (i + 1), "%s (%d)" % (k, len(rows_by_label[k])))
                        self.fill(ROW_IDS[i], rows_by_label[k])
                    if focus in ROW_IDS and ROW_IDS.index(focus) < len(was):   # el foco sigue en su fila
                        self.setFocusId(ROW_IDS[order.index(was[ROW_IDS.index(focus)])])
                    old = rows_by_label[label]      # su control se rehace entero abajo
            idx = list(rows_by_label.keys()).index(label)
            self.setProperty("flix_row%d" % (idx + 1), "%s (%d)" % (label, len(rows_by_label[label])))
            self.fill(PREVIEW, items, append=True)
            if TOUCH:
                if self.stale(gen):
                    return
                self.results = rows_by_label
                # menú de mantener pulsado: la fila necesita una ruta que se pueda listar sin teclado
                self.result_paths.setdefault(label, direct_route(route, q) or "")
                self.write_results(gen)
                self.open_results()
            else:
                self.remember_src(direct_route(route, q, terms) or "", items)
                if old:
                    self.fill(ROW_IDS[idx], rows_by_label[label])
                else:
                    self.fill(ROW_IDS[idx], items, append=True)
                if idx == 0 and len(rows_by_label[label]) == len(items) and not getattr(self, "kbd", False):
                    self.setFocusId(ROW_IDS[0])
            self.setProperty("flix_summary", "  ·  ".join(count_label(len(v), k) for k, v in rows_by_label.items()) + "  ·  buscando más…")

        titles = getattr(self, "titles", None)
        blobs = titles.wait() if titles else None
        if blobs is None:
            log("sin lista de títulos: se pregunta a todas las secciones")

        def pick(terms):
            """secciones a preguntar: solo las que pueden tener alguno de los términos"""
            if blobs is None:
                return list(range(len(routes)))
            idx = sections_with(routes, blobs, terms)
            if blobs:
                expected.update(idx)
            log("secciones con %r: %s de %d" % (terms[:3], [routes[i][0] for i in idx], len(routes)))
            return idx

        def run_query(q, terms=None):
            only = pick(terms or [q])
            if not only:
                return                              # ninguna sección lo tiene: ni se pregunta
            used.append(q)
            asked.append(q)
            # cada sección a su fila en el orden de las secciones, como cuando se preguntaban una a una: lo que llega de
            # una consulta conjunta espera a que estén las secciones de antes (la primera fila no espera nada)
            ready, pos = {}, [0]
            ordered = sorted(only)

            def put(i, args):
                with qlock:
                    ready[i] = args
                    while pos[0] < len(ordered) and ordered[pos[0]] in ready:
                        deliver(*ready.pop(ordered[pos[0]]))
                        pos[0] += 1
            run_query.put = put
            threads = []
            per = {}
            wake = self.wake_event()

            def unit(fn, *a):
                try:
                    fn(*a)
                finally:
                    wake.set()                      # un hueco libre: el bucle de abajo arranca la siguiente
            units = plan(routes, blobs, terms or [q], only, per) if blobs is not None else [("one", i, None) for i in only]
            for kind, i, ids in units:
                if kind == "group":
                    t = threading.Thread(target=unit, args=(group, q, i, ids, terms, per), daemon=True)
                else:
                    t = threading.Thread(target=unit, args=(one, q, routes[i][0], routes[i][1], i, terms), daemon=True)
                threads.append(t)
            # SEARCH_PARALLEL consultas a Palantir a la vez (cada una ~3 s en su servidor)
            pending = list(threads)
            running = []
            while (pending or running) and not self.stale(gen):
                running = [t for t in running if t.is_alive()]
                while pending and len(running) < SEARCH_PARALLEL:
                    t = pending.pop(0)
                    t.start()
                    running.append(t)
                if not running and not pending:
                    break
                wake.wait(0.25)                     # hasta que acabe una consulta o se cancele (antes sleep 50 ms)
                wake.clear()
            for t in running:
                t.join(timeout=30)
            return True

        # 1) lo que escribió el usuario (TMDB ya va buscando en paralelo, sin sumar tiempo); 2) solo si no hay nada
        # parecido: UNA pasada más con las variantes (ú, espacios, números, plural) y los títulos de TMDB juntos (OR)
        found, spare = [], []
        expected, asked = set(), []     # secciones donde la lista de títulos decía que había algo / consultas hechas
        short = is_short(text)
        alt = AltTitles(text, stale=lambda: self.stale(gen))
        alt.start()
        run_query(text)
        if not self.stale(gen) and not looks_found(text, found):
            alt.join(timeout=8)
            alts = alt.result
            direct = bool(direct_route(routes[0][1], text))
            extra = (variants(text) if direct else []) + [a for a in alts if a.lower() != text.lower()]
            log("nada parecido a %r; variantes + TMDB: %s" % (text, extra))
            if direct and extra:
                n = len(seen)
                if run_query(text, terms=extra):
                    del used[-1]
                if len(seen) > n:
                    used.extend(alts)
            else:
                for a in alts:              # ruta de Palantir sin SQL reescribible: como antes, título a título
                    run_query(a)
                    if rows_by_label or self.stale(gen):
                        break
        elif not self.stale(gen) and direct_route(routes[0][1], text):
            # algo parecido ya salió, pero lo escrito es también el nombre original o inglés de otro título que en España
            # se llama distinto («colony»: salen «The Colony» y la serie «Colony»; faltaba «Zona cero»). Una consulta más,
            # solo en las secciones que lo tienen (pick), y con lo de antes ya en pantalla
            alt.join(timeout=8)
            new = [a for a in alt.renamed if not looks_found(a, found)]
            if new and not self.stale(gen):
                log("%r también es %s en España" % (text, new))
                n = len(seen)
                if run_query(text, terms=new):
                    del used[-1]
                if len(seen) > n:
                    used.extend(new)
        if self.stale(gen):
            return
        if not rows_by_label and spare:         # búsqueda corta sin la palabra entera en ningún título: lo que haya
            with lock:
                for label, route, f in spare:
                    show(text, label, route, [f])
        order = exact_first(rows_by_label, text)
        if order != list(rows_by_label):            # «up»: la fila con «Up» arriba del todo
            log("filas con %r exacto primero: %s" % (text, order[:3]))
            with lock:
                moved = {k: rows_by_label[k] for k in order}
                rows_by_label.clear()
                rows_by_label.update(moved)
                if not TOUCH:
                    for i, k in enumerate(order):
                        self.setProperty("flix_row%d" % (i + 1), "%s (%d)" % (k, len(rows_by_label[k])))
                        self.fill(ROW_IDS[i], rows_by_label[k])
                    if not getattr(self, "kbd", False):
                        self.setFocusId(ROW_IDS[0])
        if not rows_by_label and asked and (blobs is None or expected):
            # Palantir no dio nada donde debía haber algo: por si las rutas guardadas caducaron, la próxima las rehace
            # (~27 s). Si la lista de títulos ya decía que no había nada, no se le preguntó y no hay de qué dudar.
            # Contestó de verdad y sin fallos: se olvidan. Fallaron TODAS (error de RPC: tras actualizarse Palantir, o
            # caído): se caducan pero quedan de respaldo. Con un fallo suelto, nada (olvidarlas borra el respaldo sin motivo)
            if answered and not failed:
                forget_routes()
            elif failed and not answered:
                expire_routes()
        summary = [count_label(len(v), k) for k, v in rows_by_label.items()]
        also = [u for u in used if u != text]       # sin primera ronda, «used» puede no llevar lo escrito
        if also:
            summary.append("también: " + ", ".join(also))
        if rows_by_label and not self.stale(gen):   # sin nada no se guarda: quizá Palantir falló
            try:
                results_put(text, routes, rows_by_label,
                            getattr(self, "result_paths", {}) if TOUCH else getattr(self, "ctx", {}), summary)
            except (TypeError, ValueError) as e:
                log("no guardo los resultados: %s" % e)
        if not rows_by_label and HOME.getProperty(ROUTES_PARTIAL):
            log("%s: sin resultados y sin todas las secciones: Palantir ocupado" % text)
            self.setProperty("flix_error", "1")
        elif not rows_by_label and failed and not answered:
            log("%s: Palantir no contestó a ninguna consulta (%d)" % (text, len(failed)))
            self.setProperty("flix_error", "1")     # «Palantir no responde» en vez de «Sin resultados» (TV-12)
        self.setProperty("flix_summary", "  ·  ".join(summary))
        self.setProperty("flix_state", "done")
        if TOUCH:
            self.write_results(gen, done=True)
        elif not getattr(self, "kbd", False):  # escribiendo: no robar el foco al teclado
            self.focus_results()
        log("fin %s: %d filas en %.1f s" % (text, len(rows_by_label), time.time() - t0))

    def replay(self, hit, gen):
        """pinta los resultados guardados de la misma búsqueda (results_get) como si acabara de contestar Palantir"""
        rows = [(label, files) for label, files in hit.get("rows") or [] if files][:len(ROW_IDS)]
        if TOUCH:
            self.results = dict(rows)                   # flix_home (load_search) corrige ✓ y ▶ al pintarlos
            self.result_paths = dict(hit.get("paths") or {})
            self.write_results(gen, done=True)
            self.open_results()
        else:
            try:
                import flix_rows                        # ✓ y ▶ al día: lo guardado puede ser de hace unos minutos
                rows = [(label, flix_rows._progress(files)) for label, files in rows]
            except Exception as e:  # noqa: BLE001
                log("progreso de lo guardado: %s" % e)
            paths = hit.get("paths") or {}
            self.ctx = {"srcs": list(paths.get("srcs") or []), "of": dict(paths.get("of") or {})}
            preview = []
            for i, (label, files) in enumerate(rows):
                self.setProperty("flix_row%d" % (i + 1), "%s (%d)" % (label, len(files)))
                self.fill(ROW_IDS[i], files)
                preview += files
            self.fill(PREVIEW, preview)
        self.setProperty("flix_summary", "  ·  ".join(hit.get("summary") or []))
        self.setProperty("flix_state", "done")
        if not TOUCH and not getattr(self, "kbd", False):
            self.focus_results()

    def onClick(self, control_id):
        if control_id == KEY_VOICE:
            self.voice()
            return
        if 6000 <= control_id < 6000 + len(KEYS) or control_id in (KEY_SPACE, KEY_BACK, KEY_CLEAR, KEY_ENTER, KEY_TOGGLE):
            self.type_key(control_id)
            return
        if control_id == BOX:
            if getattr(self, "edit", None):
                self.edit_changed()
            else:
                self.show_kbd(True)
            return
        if control_id in ROW_IDS or control_id == PREVIEW:
            item = self.sel_item(control_id)
            if not item:
                return
            if self.query:
                push_history(self.query)            # en vivo: al historial solo lo que se ha abierto
            path = item.getPath()
            if item.getProperty("filetype") == "directory":
                xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
            else:
                import flix_play
                tag = item.getVideoInfoTag()
                flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))
        elif control_id in CHIPS:
            text = xbmc.getInfoLabel("Skin.String(flix_hist%d)" % CHIPS[control_id])
            if text:
                self.set_typed(text)
                self.show_kbd(False)
                self.cancel_search()
                self.start_search(text)
                self.show_results()




def main():
    text = sys.argv[1].strip() if len(sys.argv) > 1 else ""
    # banco de pruebas (tools/xvfb/tour.sh): special://temp/flix_debug.txt con el texto a buscar (se borra al usarlo)
    dbg = xbmcvfs.translatePath("special://temp/flix_debug.txt")
    if xbmcvfs.exists(dbg):
        with xbmcvfs.File(dbg) as fh:
            text = fh.read().strip().split("|")[0]
        xbmcvfs.delete(dbg)
        log("debug: query=%r" % text)
    win = SearchWindow("FlixSearch.xml", SKIN_PATH, "Default", "1080i", query=text)
    try:
        win.doModal()
    finally:
        win.abort = True
        if getattr(win, "phone", None) is not None:
            win.phone.stop()
        # cerrado el buscador, sus avisos de Palantir ya no se esconden aunque la consulta en curso siga: antes la
        # marca se quedaba hasta que Palantir contestaba y un aviso salía invisible pero modal (A-11)
        HOME.clearProperty("flix_searching")
    del win


if __name__ == "__main__":
    main()
