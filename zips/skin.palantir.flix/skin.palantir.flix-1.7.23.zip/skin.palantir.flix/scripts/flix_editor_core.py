"""Editor único (Ajustes → «Personalizar menú e Inicio» y «Nota de los títulos»): lógica pura de la lista que se
edita, sin Kodi (tests en tools/tests/test_editor_core.py). Aquí están también los ids y la geometría que comparten
scripts/flix_editor.py y tools/gen_editor.py (FlixEditor.xml).
Elemento = dict: id, label, on, icon, fixed (Inicio: no se mueve ni se oculta), removable, kids (tiene filas debajo),
note (texto pequeño a la derecha), orig (nombre de Palantir: si label es otro, está renombrado) y raw (lo que la fuente necesita para guardarlo).
locked: no se oculta (filas fijas de «Filas al azar»); nomove: no se mueve ni deja pasar a otras por su sitio;
norename: sin «Cambiar nombre»; open_label / tlabels: textos propios del menú corto para «abrir» y el interruptor;
act: acción de la fuente (press) que lanza activar la fila (OK en la TV, tocar el nombre en el táctil), sin menú corto."""

LIST, BTNS, BTN_IDS, SLOTS_LIST, MENU_GROUP, MENU_BG, MENU = 100, 200, (201, 202, 203), 300, 390, 391, 400
SLOT0 = 1000            # táctil: botón b del hueco k = SLOT0 + 10·k + b (1 ▲, 2 ▼, 3 interruptor, 4 papelera, 5 filas, 6 nombre)
SLOTS = 24              # huecos táctiles: 18 filas del Inicio, 14 secciones y el máximo medido en Palantir (+4)
TV_L, TV_TOP, TV_W, TV_H = 140, 260, 1000, 72     # TV: lista 100 (izquierda, arriba, ancho, alto de fila)
# TV-14: cada fila es la fila de opción común (tools/flix_ui.py, OPTION): píldora de 64 en un hueco de 72
MENU_W = 480
MENU_X = TV_L + TV_W + 20                         # menú corto: a la derecha de la lista, a la altura de la fila
GRIP = "flix/icons/grip-vertical.png"             # TV: icono de las filas que se pueden mover y no traen icono
SLOT_FIELDS = ("label", "icon", "note", "on", "mv", "tg", "rm", "kids", "rn")


def item(id, label, on=True, icon="", fixed=False, removable=False, kids=False, note="", raw=None, orig=None,  # noqa: A002
         locked=False, nomove=False, norename=False, open_label="", tlabels=None, act="", switch=False):
    """switch: fila fija de un ajuste Sí/No que enseña su interruptor y OK lo cambia (act)"""
    return {"id": id, "label": label, "on": on, "icon": icon, "fixed": fixed, "removable": removable,
            "kids": kids, "note": note, "raw": raw, "orig": label if orig is None else orig,
            "locked": locked, "nomove": nomove, "norename": norename, "open_label": open_label, "tlabels": tlabels, "act": act,
            "switch": switch}


def note_of(it):
    """nota de la derecha: la de la fuente y, si está renombrada, el nombre de Palantir"""
    renamed = "era «%s»" % it["orig"] if it["label"] != it["orig"] else ""
    return " · ".join(x for x in (it["note"], renamed) if x)


def first_movable(items):
    return next((k for k, it in enumerate(items) if not it["fixed"]), len(items))


def move(items, k, step):
    """sube (step -1) o baja (+1) items[k] un puesto, sin pasar por encima de los fijos; devuelve dónde ha quedado"""
    j = k + step
    if not 0 <= k < len(items) or items[k]["fixed"] or items[k].get("nomove") or \
            not first_movable(items) <= j < len(items) or items[j].get("nomove"):
        return k
    items[k], items[j] = items[j], items[k]
    return j


def toggle(items, k):
    if not 0 <= k < len(items) or items[k]["fixed"] or items[k].get("locked"):
        return False
    items[k]["on"] = not items[k]["on"]
    return True


def active_count(items):
    return len([it for it in items if it["on"] and not it["fixed"]])


def find(items, item_id):
    return next((k for k, it in enumerate(items) if it["id"] == item_id), 0)


def separator_index(items, limit):
    """táctil, nivel menú: la raya «las siguientes no caben en el móvil» va delante de este índice (justo después de
    la limit-ésima sección activa) si hay más activas detrás; None si caben todas"""
    act = [k for k, it in enumerate(items) if it["on"] and not it["fixed"]]
    return act[limit - 1] + 1 if len(act) > limit else None


def options(it, toggle_labels=("Ocultar", "Mostrar"), remove_label="Quitar", rename=False):
    """menú corto de la TV (OK en una fila): [(acción, texto)]"""
    out = [("open", it.get("open_label") or "Editar filas")] if it["kids"] else []
    if it["fixed"]:
        return out
    if not it.get("nomove"):
        out.append(("move", "Mover"))
    if rename and not it.get("norename"):
        out.append(("rename", "Cambiar nombre"))
    if not it.get("locked"):
        labels = it.get("tlabels") or toggle_labels
        out.append(("toggle", labels[0] if it["on"] else labels[1]))
    if it["removable"]:
        out.append(("remove", remove_label))
    return out


def slot_props(items, slots, sep=None, rename=False):
    """táctil: {propiedad de ventana: valor} de los huecos fijos e<k>_* (vacío = hueco oculto) y la raya"""
    out = {"sep": "" if sep is None else str(sep)}
    for k in range(slots):
        it = items[k] if k < len(items) else None
        vals = dict.fromkeys(SLOT_FIELDS, "")
        if it:
            vals.update(label=it["label"], icon=it["icon"], note=note_of(it), on="1" if it["on"] else "",
                        mv="" if it["fixed"] or it.get("nomove") else "1",
                        tg="" if it["fixed"] or it.get("locked") else "1",
                        rm="1" if it["removable"] else "", kids="1" if it["kids"] else "",
                        rn="1" if it.get("act") or (rename and not it["fixed"] and not it.get("norename")) else "")
        out.update({"e%d_%s" % (k, f): v for f, v in vals.items()})
    return out
