"""Progreso de películas igual en todas las filas.

Palantir guarda el progreso real en addon_data/plugin.video.palantir3/watched.db (lo sube a Trakt y lo baja al
sincronizar), pero cada fila del Inicio sale de su caché (cache.db, hasta 3 días) con el porcentaje del momento en
que se generó, y Kodi no vuelve a pedir una fila mientras su ruta no cambie. Resultado: la misma película con 35 %
en Top 10, 21 % en Tendencias y sin barra en otra fila.

Este script (solo lee watched.db; no toca Trakt ni el scrobbling de Palantir):
  1. corrige percentPlayed/playCount/totalTime/lastPlayed de cada película en las listas de cache.db
     (pickle de Palantir, reescrito byte a byte igual salvo esos campos); "Seguir viendo" se borra de la caché si
     ha cambiado o hay algo visto después, para que Palantir la regenere con su orden y sus reglas;
  2. corrige el "resume" de la caché de las pantallas de sección (rows_cache2.json del skin);
  3. mira lo que enseña cada fila del Inicio (Container(N).ListItemAbsolute(i).PercentPlayed) y recarga SOLO las
     filas que no cuadran, cambiando Window(home).Property(flix_rl_<variable>) que va pegada al reload= de su ruta
     (cada carga de Palantir consulta la API de GitHub, 60/h por IP: no se recarga nada sin necesidad).
Se lanza al abrir el Inicio, al cerrar el vídeo y al cerrar el menú contextual (limpiar progreso, marcar como
vista); repite la pasada unos segundos después porque Palantir escribe watched.db con algo de retraso.
Uso: RunScript(special://skin/scripts/flix_progress.py,home|video|menu)
"""
import json
import os
import pickle
import re
import sqlite3
import sys
import time
import types

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/")
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
ROWS_CACHE = flix_rows.CACHE_FILE
# las últimas pasadas recogen las listas que Palantir regenera al recargar una fila (llegan sin estado)
PASSES = {"home": [0, 4, 12, 25], "video": [2, 6, 15, 30], "menu": [1, 3, 8, 15, 25, 40]}
TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')
CONTENT_RE = re.compile(r'"content": \'(\w+)')


def log(msg):
    xbmc.log("[flix_progress] %s" % msg, xbmc.LOGINFO)
    HOME.setProperty("flix_progress_log", msg[:500])     # legible por JSON-RPC (en Fire OS no se puede leer kodi.log)


# ---------- verdad: watched.db de Palantir ----------
def truth():
    """{tmdb(str): (playcount, progress %, runtime s, lastPlayed)}; None si no se puede leer. {} = base sin
    películas (quien solo ve series): NO es «sin watched.db» (auditoría 22-oct B-06)"""
    try:
        return flix_common.watched_movies(WATCHED_DB)
    except Exception as e:  # noqa: BLE001  (p. ej. watched.db vacío sin tablas)
        log("watched.db: %s" % e)
        return None


ABSENT = object()   # campo que NO debe estar
_UNSET = object()   # fechas de seguimiento aún sin leer (solo si hay esa lista en la caché)

# Series: Palantir no da su estado en las listas (Top 10 de series sin ✓ ni ▶, Carlos 20-oct) pero SÍ pasa al
# póster el playCount de la caché. Vista = playCount 1 (✓); a medias = SHOW_STARTED (▶ en Includes_Flix.xml y
# flix_home.py; el ✓ excluye ese valor). Kodi no tiene otro campo de series que Palantir respete (percentPlayed no).
SHOW_STARTED = 99


def truth_shows():
    """{tmdb(str): playCount que toca a la serie (1 vista, SHOW_STARTED a medias)}; las demás no están"""
    path = flix_common.watched_db(WATCHED_DB)
    if not os.path.exists(path):
        return None
    db = sqlite3.connect("file:%s?mode=ro" % path, uri=True, timeout=5)
    try:
        eps = {r[0]: (r[1] or 0, r[2] or 0) for r in db.execute(
            "SELECT tmdb_id, SUM(playcount > 0), SUM(progress > 0) FROM episodes_watched GROUP BY tmdb_id")}
        out = {}
        for tmdb, total, complete, hidden in db.execute(
                "SELECT tmdb_id, num_total_episodios, completa, ocultar FROM shows_watched"):
            seen, partial = eps.get(tmdb, (0, 0))
            if complete or (total and seen >= total):
                out[str(tmdb)] = 1
            elif not hidden and (seen or partial):
                out[str(tmdb)] = SHOW_STARTED
        return out
    finally:
        db.close()


def show_pc(S, tmdb):
    return (S or {}).get(str(tmdb), 0)


def fields(row):
    """campos de un P3Item de película tal como los escribe Palantir al generar la lista. Sin fila en watched.db
    (sin ver) Palantir NO pone esos campos: si los encuentra a None revienta al reproducir (float(None), línea 492;
    Spider-Man desde el Top 10, 19-oct) -> se quitan"""
    if row is None:
        return {"percentPlayed": ABSENT, "playCount": ABSENT, "totalTime": ABSENT, "lastPlayed": ABSENT}
    playcount, progress, runtime, last = row
    return {"percentPlayed": progress, "playCount": playcount, "totalTime": runtime, "lastPlayed": last}


def shown_pct(row):
    """porcentaje que debería enseñar la barra (Kodi trunca a entero)"""
    return int(row[1] or 0) if row else 0


# ---------- 1. cache.db de Palantir ----------
class _Unpickler(pickle.Unpickler):
    """las clases de Palantir (libs.*) no se pueden importar fuera de su proceso: se sustituyen por clases vacías
    con el mismo módulo y nombre, registradas en sys.modules para que pickle.dumps las vuelva a escribir igual"""

    def find_class(self, module, name):
        if module.split(".")[0] == "libs":
            mod = sys.modules.get(module)
            if mod is None:
                parts = module.split(".")
                for i in range(1, len(parts) + 1):
                    sys.modules.setdefault(".".join(parts[:i]), types.ModuleType(".".join(parts[:i])))
                mod = sys.modules[module]
            cls = getattr(mod, name, None)
            if cls is None:
                cls = type(name, (), {})
                cls.__module__, cls.__qualname__ = module, name
                setattr(mod, name, cls)
            return cls
        return super().find_class(module, name)


def _loads(data):
    import io
    return _Unpickler(io.BytesIO(data)).load()


def fix_more(cid, items):
    """En las listas de las filas del Inicio (Widget…) el «más…» de Palantir apunta a la página 0: la misma lista
    otra vez, con un solo título nuevo (Carlos, 21-oct: Series en seguimiento repetidas). Se pasa a la página 1, la
    siguiente de verdad (comprobado en la Shield: 0 repetidas). True si cambió algo"""
    if not str(cid).startswith("Widget"):
        return False
    changed = False
    for it in items:
        v = getattr(it, "__dict__", None)
        if isinstance(v, dict) and v.get("specialSort") == "bottom" and v.get("page") == 0 and "limitItemList" in v:
            v["page"] = 1
            changed = True
    return changed


def fix_palantir_cache(W, S=None):
    """devuelve nº de listas corregidas/borradas"""
    if not os.path.exists(CACHE_DB):
        return 0
    if S is None:
        S = truth_shows_cached()
    db = sqlite3.connect(CACHE_DB, timeout=5)
    changed, dates = 0, _UNSET
    try:
        rows = db.execute("SELECT id, data FROM simplecache WHERE type='pickle'").fetchall()
        for cid, data in rows:
            try:
                items = _loads(data)
                if pickle.dumps(items, protocol=4) != data:
                    log("%s: no se reescribe igual, no se toca" % cid)
                    continue
            except Exception as e:  # noqa: BLE001
                log("no leo %s: %s" % (cid, e))
                continue
            if not isinstance(items, list):
                continue
            dirty, unfinished, newest, more = False, False, "", fix_more(cid, items)
            for it in items:
                v = getattr(it, "__dict__", None)
                if isinstance(v, dict) and v.get("content") == "tvshows" and v.get("tmdb") and S is not None:
                    pc = show_pc(S, v["tmdb"])
                    if pc and v.get("playCount") != pc:
                        v["playCount"] = pc
                        dirty = True
                    elif not pc and "playCount" in v:
                        del v["playCount"]
                        dirty = True
                    continue
                if not isinstance(v, dict) or v.get("content") != "movies" or not v.get("tmdb"):
                    continue
                unfinished = unfinished or v.get("especial") == "no_finalizadas"
                newest = max(newest, v.get("lastPlayed") or "")
                want = fields(W.get(str(v["tmdb"])))
                for k, val in want.items():
                    if val is ABSENT:
                        if k in v:
                            del v[k]
                            dirty = True
                    elif v.get(k) != val:
                        v[k] = val
                        dirty = True
            if any(_follow_item_tmdb(it) for it in items[:1]):
                if dates is _UNSET:
                    dates = follow_dates()
                if dates is not None and sort_follow(items, _follow_item_tmdb, dates):
                    dirty = True
            if unfinished:
                # "Seguir viendo": Palantir decide qué entra y en qué orden -> que la regenere
                played_after = any((r[3] or "") > newest and (r[1] or 0) > 0 for r in W.values())
                if dirty or played_after:
                    db.execute("DELETE FROM simplecache WHERE id=? AND data=?", (cid, data))
                    changed += 1
                    log("%s borrada (seguir viendo cambió)" % cid)
                    continue
                dirty = more                    # solo el «más…»: se reescribe sin borrarla
            if dirty or more:
                db.execute("UPDATE simplecache SET data=? WHERE id=? AND data=?",
                           (pickle.dumps(items, protocol=4), cid, data))
                changed += 1
                log("%s corregida" % cid)
        db.commit()
    finally:
        db.close()
    return changed


# ---------- orden de «Series en seguimiento» ----------
# Palantir la ordena por el último capítulo de watched.db, pero lo que baja de Trakt lo apunta con la hora de la
# SINCRONIZACIÓN (con milésimas: «…07:06:16.863Z») y no con la de verdad (siempre «.000Z»). En el móvil (23-oct) 8
# series selladas a las 09:06 pasaron delante de ¿Es una Tarta?, vista la noche antes; y algunas (Manhunt T1E1,
# Gilmore T4E4) se vuelven a sellar en cada sincronización (Shield 21-oct, móvil 23-oct). Solo se cambia el ORDEN
# de la lista: watched.db (y Trakt) no se tocan.
STAMPS_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/p3_sellos.json" % xbmc.getSkinDir())
SEED = "semilla"
_FOLLOW = [0.0, None]


def is_sync_stamp(last):
    """¿hora puesta por Palantir al sincronizar (milésimas distintas de 0)?"""
    m = re.search(r"\.(\d+)Z$", last or "")
    return bool(m) and int(m.group(1)) != 0


def show_dates(rows, stamps):
    """({tmdb: fecha del último capítulo}, ¿stamps cambió?) de las filas (tmdb, temporada, capítulo, lastPlayed).
    Un capítulo que llega sellado por 1.ª vez (visto en otro aparato) vale con la hora de su llegada, que se guarda
    en stamps: si Palantir lo vuelve a sellar, se sigue usando esa. Los sellos que ya había al estrenar esto (SEED)
    no cuentan: son los que Palantir repite en cada sincronización"""
    dates, changed = {}, False
    for tmdb, season, episode, last in rows:
        if not last:
            continue
        if is_sync_stamp(last):
            key = "%s:%s:%s" % (tmdb, season, episode)
            first = stamps.get(key)
            if first is None:
                stamps[key] = first = last
                changed = True
            if first == SEED:
                continue
            last = first
        if last > dates.get(str(tmdb), ""):
            dates[str(tmdb)] = last
    return dates, changed


def follow_dates(max_age=5):
    """fechas para ordenar «Series en seguimiento» (leídas como mucho cada max_age s); None si no se puede"""
    if _FOLLOW[1] is not None and time.time() - _FOLLOW[0] <= max_age:
        return _FOLLOW[1]
    try:
        path = flix_common.watched_db(WATCHED_DB)
        if not os.path.exists(path):
            return None
        db = sqlite3.connect("file:%s?mode=ro" % path, uri=True, timeout=5)
        try:
            rows = db.execute("SELECT tmdb_id, season, episode, lastPlayed FROM episodes_watched").fetchall()
        finally:
            db.close()
        import flix_cache
        with flix_cache.file_lock(STAMPS_FILE):
            try:
                with open(STAMPS_FILE, encoding="utf-8") as fh:
                    stamps, seed = json.load(fh), False
                if not isinstance(stamps, dict):
                    raise ValueError("no es un diccionario")
            except (OSError, ValueError):
                # 1.ª vez (o fichero roto): lo sellado hasta ahora no dice cuándo se vio
                stamps, seed = {"%s:%s:%s" % r[:3]: SEED for r in rows if is_sync_stamp(r[3])}, True
            dates, changed = show_dates(rows, stamps)
            if seed or changed:
                flix_cache.atomic_write(STAMPS_FILE, json.dumps(stamps))
    except Exception as e:  # noqa: BLE001
        log("orden de Series en seguimiento: %s" % e)
        return None
    _FOLLOW[:] = [time.time(), dates]
    return dates


def sort_follow(entries, tmdb_of, dates):
    """ordena EN SU SITIO las series de la lista por fecha (la más reciente primero); sin fecha, detrás y en el orden
    de Palantir; lo demás («más…») no se mueve. True si cambió algo"""
    idx = [i for i, e in enumerate(entries) if tmdb_of(e)]
    shows = [entries[i] for i in idx]
    ordered = sorted(shows, key=lambda e: dates.get(tmdb_of(e), ""), reverse=True)   # estable: empates igual
    if all(a is b for a, b in zip(ordered, shows)):
        return False
    for i, e in zip(idx, ordered):
        entries[i] = e
    return True


def ordered_follow(files):
    """«Series en seguimiento» de JSON-RPC (Inicio, secciones) en orden de verdad y sin las series terminadas que ya
    has visto enteras (drop_finished). Devuelve una COPIA si cambia algo (la lista puede ser la guardada en caché,
    compartida con otros hilos); si no, la misma lista"""
    if not files or not flix_rows.follow_tmdb(files[0]):
        return files
    kept = drop_finished(files)
    dates = follow_dates()
    if dates is None:
        return kept
    out = list(kept)
    return out if sort_follow(out, flix_rows.follow_tmdb, dates) or kept is not files else files


# ---------- series terminadas (TMDB) ----------
# «El castillo» vista entera y terminada seguía en «Series en seguimiento» (Palantir guarda esa lista hasta 3 días) y
# con ▶ (Carlos, 24-oct). Fuera de la fila: vista entera (truth_shows = 1) Y terminada o cancelada en TMDB. Las que
# siguen en emisión y vas al día se quedan con su ▶ (queda algo por salir). Estado de TMDB guardado 7 días.
TV_STATUS_TTL, TV_STATUS_ERR = 7 * 86400, 3600
_STATUS = {"data": None, "busy": False}


def tv_status_path():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/tvstatus.json" % xbmc.getSkinDir())


def tv_status(tmdb, now=None):
    """'Ended' / 'Canceled' / 'Returning Series'…; None si no se sabe (o caducó)"""
    if _STATUS["data"] is None:
        try:
            with open(tv_status_path(), encoding="utf-8") as fh:
                _STATUS["data"] = json.load(fh)
        except (OSError, ValueError):
            _STATUS["data"] = {}
    hit = _STATUS["data"].get(str(tmdb))
    now = time.time() if now is None else now
    if not hit or now - hit[0] > (TV_STATUS_TTL if hit[1] else TV_STATUS_ERR):
        return None
    return hit[1] or None


def fetch_status(ids, opener=None):
    """estado de TMDB de esas series, en un hilo; al acabar se avisa al Inicio para que repinte (flix_progress_wsig)"""
    if _STATUS["busy"] or not ids:
        return
    _STATUS["busy"] = True

    def run():
        import urllib.request
        got = False
        try:
            for tmdb in ids:
                url = "https://api.themoviedb.org/3/tv/%s?api_key=%s" % (tmdb, flix_common.TMDB_KEY)
                try:
                    with (opener or urllib.request.urlopen)(url, timeout=8) as r:
                        st = json.loads(r.read().decode("utf-8", "replace")).get("status") or ""
                except Exception as e:  # noqa: BLE001
                    log("estado de la serie %s en TMDB: %s" % (tmdb, e))
                    st = ""
                _STATUS["data"][str(tmdb)] = [time.time(), st]
                got = got or bool(st)
            try:
                flix_common.atomic_write(tv_status_path(), json.dumps(_STATUS["data"]))
            except OSError as e:
                log("no guardo el estado de las series: %s" % e)
            if got:
                HOME.setProperty("flix_progress_wsig", "%s|tv%d" % (HOME.getProperty("flix_progress_wsig"),
                                                                  int(time.time())))
        finally:
            _STATUS["busy"] = False
    import threading
    threading.Thread(target=run, daemon=True).start()


def drop_finished(files, S=None):
    """«Series en seguimiento» sin las vistas enteras que TMDB da por terminadas o canceladas. Las que aún no se
    saben se piden por detrás (la fila se repinta al llegar). La misma lista si no quita nada"""
    S = truth_shows_cached() if S is None else S
    if not S:
        return files
    out, unknown = [], []
    for f in files:
        t = flix_rows.follow_tmdb(f)
        if t and S.get(str(t)) == 1:
            st = tv_status(t)
            if st is None:
                unknown.append(str(t))
            elif st in ("Ended", "Canceled"):
                continue
        out.append(f)
    if unknown:
        fetch_status(unknown)
    if len(out) != len(files):
        log("Series en seguimiento: fuera %d terminadas y vistas" % (len(files) - len(out)))
        return out
    return files


def _follow_item_tmdb(it):
    v = getattr(it, "__dict__", None)
    return str(v.get("tmdb")) if isinstance(v, dict) and v.get("action") == "play_mis_serieS" and v.get("tmdb") \
        else None


# ---------- 2. listas JSON-RPC (pantallas de sección, Inicio táctil) ----------
_TRUTH = [0.0, None, None]


def truth_cached(max_age=5):
    """watched.db leída como mucho una vez cada max_age s (una pantalla pide varias filas seguidas) Y otra vez en
    cuanto cambia el fichero: una pasada que llegaba antes de que Palantir guardara dejaba aquí lo viejo y el Inicio
    repintaba con ello al avisarle la pasada siguiente (Spider-Man desmarcado seguía con ✓; Carlos, 24-oct)"""
    sig = watched_sig()
    if _TRUTH[1] is None or time.time() - _TRUTH[0] > max_age or _TRUTH[2] != sig:
        try:
            _TRUTH[:] = [time.time(), truth(), sig]
        except Exception as e:  # noqa: BLE001
            log("watched.db: %s" % e)
            return None
    return _TRUTH[1]


_SHOWS = [0.0, None, None]


def truth_shows_cached(max_age=5):
    sig = watched_sig()
    if _SHOWS[1] is None or time.time() - _SHOWS[0] > max_age or _SHOWS[2] != sig:
        try:
            _SHOWS[:] = [time.time(), truth_shows(), sig]
        except Exception as e:  # noqa: BLE001
            log("watched.db series: %s" % e)
            return None
    return _SHOWS[1]


def fix_files(files, W=None):
    """pone en cada película de una lista de Files.GetDirectory el resume/playcount reales; devuelve cuántas cambió"""
    W = truth_cached() if W is None else W
    if W is None or not files:
        return 0
    changed = 0
    for f in files:
        if not isinstance(f, dict) or not str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/"):
            continue
        try:
            route = flix_rows.decode_route(f["file"])
        except Exception:  # noqa: BLE001
            continue
        m, c = TMDB_RE.search(route), CONTENT_RE.search(route)
        # las series son CARPETAS: antes se saltaban con el filtro de abajo y su ▶/✓ se quedaba como viniera
        # (Carlos, 20-oct: Carrie dejada de seguir con ▶ en el Top 10; La isla de las tentaciones a medias sin ▶)
        if m and c and c.group(1) == "tvshows":
            S = truth_shows_cached()
            if S is not None and int(f.get("playcount") or 0) != show_pc(S, m.group(1)):
                f["playcount"] = show_pc(S, m.group(1))
                changed += 1
            continue
        if f.get("filetype", "file") != "file" or not m or (c and c.group(1) != "movies"):
            continue
        row = W.get(m.group(1))
        total = float(row[2] or 0) if row else 0.0
        pos = round(total * float(row[1] or 0) / 100, 3) if row else 0.0
        want_pc = int(row[0] or 0) if row else 0
        old = f.get("resume") or {}
        if abs(float(old.get("position") or 0) - pos) > 1 or int(f.get("playcount") or 0) != want_pc:
            f["resume"], f["playcount"] = {"position": pos, "total": total}, want_pc
            changed += 1
    return changed


def is_resume_row(path):
    """¿es la fila «Seguir viendo» de Palantir (películas a medias)?"""
    try:
        return "'no_finalizadas'" in flix_rows.decode_route(path or "")
    except Exception:  # noqa: BLE001
        return False


def still_started(files):
    """«Seguir viendo» sin lo que ya no está a medias (progreso quitado o vista), con fix_files ya aplicado.
    Palantir no rehace la fila hasta que caduca: en la táctil se quedaban sin barra (Carlos, 20-oct)"""
    out = []
    for f in files:
        movie = isinstance(f, dict) and str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/") \
            and f.get("filetype", "file") == "file"
        if movie and (int(f.get("playcount") or 0) > 0 or float((f.get("resume") or {}).get("position") or 0) <= 0):
            continue
        out.append(f)
    return out


def fix_rows_cache(W):
    import flix_cache
    with flix_cache.file_lock(ROWS_CACHE):          # leer-corregir-escribir sin pisar a flix_rows (B-05)
        try:
            with open(ROWS_CACHE, encoding="utf-8") as fh:
                cache = json.load(fh)
        except Exception:  # noqa: BLE001
            return 0
        changed = 0
        for _key, entry in cache.items():
            if isinstance(entry, list) and len(entry) == 2 and isinstance(entry[1], list):
                changed += fix_files(entry[1], W)
        if changed:
            flix_cache.atomic_write(ROWS_CACHE, json.dumps(cache, ensure_ascii=False))   # temporal único (PY-NUEVO-01)
            log("rows_cache: %d películas corregidas" % changed)
    return changed


# ---------- 3. filas del Inicio en pantalla ----------
def home_rows():
    """{list_id: nombre de la variable de su ruta} leído de Home.xml (el orden lo cambia flix_home_order.py).
    Desde la 1.5.43 el Inicio TV es la ventana Python flix_inicio.py (sus filas salen de rows_cache2.json, que
    fix_rows_cache ya corrige, y se repintan solas): Home.xml no tiene filas y este paso no hace nada"""
    try:
        with xbmcvfs.File("special://skin/xml/Home.xml") as fh:
            text = fh.read()
    except Exception:  # noqa: BLE001
        return {}
    out = {}
    for block in re.findall(r'<include content="FlixRow">(.*?)</include>', text, re.S):
        lid = re.search(r'name="list_id" value="(\d+)"', block)
        # src = variable de la ruta real (de serie: FlixPath…; añadida: FlixRowPath<id>); la de path es la de carga
        # diferida (FlixRowPath<id>, vacía hasta que la fila está cerca). Home.xml antiguo: solo path
        var = re.search(r'name="src" value="(\w+)"', block) or re.search(r'name="path" value="\$VAR\[(\w+)\]"', block)
        if lid and var:
            out[lid.group(1)] = var.group(1)
    return out


def refresh_rows(W):
    if xbmcgui.getCurrentWindowId() != 10000:
        return 0
    S = truth_shows_cached()
    bumped = 0
    for lid, var in home_rows().items():
        n = int(xbmc.getInfoLabel("Container(%s).NumItems" % lid) or 0)
        wrong = []
        for i in range(n):
            path = xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).FileNameAndPath" % (lid, i))
            if not path.startswith("plugin://plugin.video.palantir3/"):
                continue
            try:
                route = flix_rows.decode_route(path)
            except Exception:  # noqa: BLE001
                continue
            m, c = TMDB_RE.search(route), CONTENT_RE.search(route)
            if m and c and c.group(1) == "tvshows" and S is not None:
                want_pc = show_pc(S, m.group(1))
                if int(xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).PlayCount" % (lid, i)) or 0) != want_pc:
                    wrong.append("s%s:%d" % (m.group(1), want_pc))
                continue
            if not m or not c or c.group(1) != "movies":
                continue
            row = W.get(m.group(1))
            want = shown_pct(row)
            got = int(xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).PercentPlayed" % (lid, i)) or 0)
            # vista (✓ del póster): antes solo se comparaba el porcentaje y «Marcar como vista» de una película sin
            # empezar (0 % antes y después) no recargaba la fila: la ✓ no salía hasta mucho después
            seen = bool(row and int(row[0] or 0) > 0)
            got_seen = int(xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).PlayCount" % (lid, i)) or 0) > 0
            if abs(want - got) > 1 or seen != got_seen:
                wrong.append("%s:%d%s" % (m.group(1), want, "v" if seen else ""))
        if not wrong:
            continue
        sig = ",".join(wrong)
        # cada carga gasta API de GitHub: por la misma discrepancia, como mucho 3 recargas y 5 s entre ellas
        # (una recarga puede llegar antes de que Palantir haya guardado el cambio y no servir)
        prev = HOME.getProperty("flix_rl_sig_" + var).split("|")
        tries = int(prev[1]) if len(prev) == 3 and prev[0] == sig else 0
        last = float(prev[2]) if len(prev) == 3 and prev[0] == sig else 0.0
        if tries >= 3 or time.time() - last < 5:
            continue
        HOME.setProperty("flix_rl_sig_" + var, "%s|%d|%f" % (sig, tries + 1, time.time()))
        HOME.setProperty("flix_rl_" + var, str(int(time.time() * 10)))
        bumped += 1
        log("recargo fila %s (%s, intento %d): %s" % (lid, var, tries + 1, sig))
    return bumped


def watched_sig():
    """huella de watched.db y cache.db (fecha y tamaño, también del -wal de SQLite): si no cambian, las cachés ya
    están bien. cache.db cuenta porque Palantir regenera sus listas (al sincronizar con Trakt, al caducar) sin el
    estado: el Top 10 de series volvía sin ✓/▶ aunque watched.db no hubiera cambiado (20-oct)"""
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal", CACHE_DB, CACHE_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def one_pass():
    W = truth()
    if W is None:
        log("sin watched.db en %s" % WATCHED_DB)
        return
    # el trabajo pesado (cache.db de Palantir ~0,5 s y rows_cache ~0,7 s por pasada en el S24) solo si watched.db
    # cambió desde la última vez; las filas en pantalla se revisan siempre (pueden traer el % viejo) (REND-05/PY-06)
    sig = watched_sig()
    a = b = 0
    if sig != HOME.getProperty("flix_progress_wsig"):
        a = fix_palantir_cache(W)
        b = fix_rows_cache(W)
        HOME.setProperty("flix_progress_wsig", watched_sig())     # ya con lo que acabamos de escribir
    c = refresh_rows(W)
    if a or b or c:
        log("pasada: cache.db %d, secciones %d, filas recargadas %d" % (a, b, c))


def started_shows():
    """series seguidas a medias (▶) según watched.db"""
    try:
        return {k for k, v in (truth_shows() or {}).items() if v == SHOW_STARTED}
    except Exception as e:  # noqa: BLE001
        log("series a medias: %s" % e)
        return set()


def episode_just_watched(now=None, window=180):
    """¿Palantir ha apuntado un capítulo en los últimos 3 min? (lastPlayed en UTC, «2026-10-20T21:56:17.000Z»)"""
    import calendar
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            last = db.execute("SELECT MAX(lastPlayed) FROM episodes_watched").fetchone()[0]
        finally:
            db.close()
        t = calendar.timegm(time.strptime(last[:19], "%Y-%m-%dT%H:%M:%S"))
    except Exception:  # noqa: BLE001
        return False
    return 0 <= (now or time.time()) - t <= window


def follow_check(before):
    """si alguna serie ha dejado de estar a medias (último capítulo visto: Palantir la marca completa) se renueva
    «Series en seguimiento»: Palantir la guarda en caché hasta 3 días y, rehecha, ya no la trae (probado en la Shield
    20-oct con Crystal Lake). Antes solo pasaba al reiniciar Kodi. Devuelve las series a medias de ahora."""
    now = started_shows()
    done = before - now
    if done:
        log("series que ya no están a medias: %s -> renuevo Series en seguimiento" % sorted(done))
        import flix_p3sync
        flix_p3sync.refresh_follow()
    return now


def wait_or_again(monitor, secs, step=0.25):
    """espera secs entre pasadas: 'abort' si Kodi se cierra, 'again' si otra llamada pidió pasada (flix_progress_again)
    y '' si se cumplió el tiempo. Antes la petición esperaba a que acabara todo el horario en marcha (hasta 40 s): al
    marcar, el menú de Kodi que se abre por detrás lanza una pasada ANTES de que Palantir guarde, y la de después de
    guardar (flix_menu.wait_applied) quedaba en cola; la ✓ tardaba en quitarse (Carlos, 24-oct)"""
    end = time.time() + secs
    while True:
        if HOME.getProperty("flix_progress_again"):
            return "again"
        left = end - time.time()
        if left <= 0:
            return ""
        if monitor.waitForAbort(min(step, left)):
            return "abort"


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "home"
    busy = HOME.getProperty("flix_progress_busy")
    if busy and time.time() - float(busy or 0) < 60:
        HOME.setProperty("flix_progress_again", mode)
        return
    HOME.setProperty("flix_progress_busy", str(time.time()))
    monitor = xbmc.Monitor()
    log("inicio (%s)" % mode)
    started = started_shows() if mode == "video" else set()
    # tras ver un capítulo, «Series en seguimiento» se renueva al final: Palantir la ordena por lo último visto pero
    # la guarda en caché (Carlos, 20-oct: El Castillo, recién vista, ni salía)
    renew = mode == "video"
    try:
        while True:
            last = 0
            for t in PASSES.get(mode, PASSES["home"]):
                # waitForAbort(0) no vuelve en algunas versiones: solo se espera si hay algo que esperar
                if t > last:
                    woke = wait_or_again(monitor, t - last)
                    if woke == "abort":
                        return
                    if woke == "again":
                        break           # otra petición (p. ej. «Marcar como no vista» ya guardado): pasada YA
                last = t
                HOME.setProperty("flix_progress_busy", str(time.time()))
                try:
                    one_pass()
                    if mode == "video":
                        started = follow_check(started)
                except Exception as e:  # noqa: BLE001
                    log("error: %s" % e)
            if renew and episode_just_watched():
                renew = False
                log("capítulo visto: renuevo Series en seguimiento (orden por lo último visto)")
                import flix_p3sync
                flix_p3sync.refresh_follow()
            again = HOME.getProperty("flix_progress_again")
            HOME.clearProperty("flix_progress_again")
            if not again:
                break
            # tras un vídeo se sigue con su horario (follow_check / Series en seguimiento) aunque llegue otra petición
            mode = mode if mode == "video" else again
            HOME.setProperty("flix_progress_busy", str(time.time()))
            try:
                one_pass()                  # al momento: el horario de la nueva petición empieza después
            except Exception as e:  # noqa: BLE001
                log("error: %s" % e)
    finally:
        HOME.clearProperty("flix_progress_busy")


if __name__ == "__main__":
    main()
