# -*- coding: utf-8 -*-
"""Imagen apaisada de cada título de «Seguir viendo» del Inicio TV (Carlos, 11-nov: tarjetas como en las plataformas).

La fila 5101 se pinta con tarjetas de 384x216 en vez de carátulas. Palantir manda carátula, fondo y logo, pero el fondo
es la misma imagen que la cabecera enseña a pantalla completa. TMDB tiene además imágenes apaisadas que ya llevan el
título puesto por el diseñador (backdrops con idioma): son las que usan las plataformas en sus tarjetas, y con ellas
no hace falta montar el logo encima. Se piden UNA vez por título (primero en español, si no en inglés) y se guardan en
wide.json; sin ninguna se apunta vacío y se vuelve a mirar a la semana (a los estrenos les llegan más tarde).

Nunca en el camino del foco ni al pintar: el Inicio llama a decorate() con lo que haya en caché y a want(), que las pide
en segundo plano, de una en una con pausa (mismo patrón que flix_age), y avisa con Window(home).Property(flix_wide_rev)
para que el Inicio las ponga en las tarjetas ya pintadas (apply). Mientras no llega, la tarjeta enseña el fondo de
Palantir con el logo. Todo fallo se traga: la fila funciona igual, con el fondo."""
import json
import threading
import time

import xbmc
import xbmcgui

import flix_age
import flix_common

HOME = xbmcgui.Window(10000)
REV = "flix_wide_rev"
ROW = 5101                      # «Seguir viendo» (flix_home_conf.WIDE_ROW)
TMDB = "https://api.themoviedb.org/3/%s/%s/images?include_image_language=es,en&api_key=%s"      # lleva la clave: no va al log
# 500 px de ancho para una tarjeta de 384: la textura ocupa ~0,5 MB, como una carátula (w342: 0,7 MB). Con w780 eran
# 1,3 MB y con el fondo de Palantir (w1280), 3,5 MB por tarjeta (Carlos, 11-nov: «¿no hace más pesada la skin?»)
SIZE = "w500"
IMG = "https://image.tmdb.org/t/p/" + SIZE
TIMEOUT = 6
PAUSE = 0.35                    # s entre dos peticiones
MAX_PER_RUN = 40
SAVE_EVERY = 5                  # la fila es corta: que se vea llegar
RETRY = 7 * 86400               # sin imagen con título: se vuelve a mirar a la semana
LANGS = ("es", "en")

_mem = {"data": None, "sig": None}
_queue = []
_busy = threading.Lock()
_running = [False]


def log(msg):
    xbmc.log("[flix_wide] %s" % msg, xbmc.LOGINFO)


def cache_file():
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/wide.json" % xbmc.getSkinDir())


def data():
    """{clave: [ruta de TMDB o '', hora]} de wide.json (se relee solo si cambió el fichero)"""
    path = cache_file()
    sig = flix_age._sig(path)
    if _mem["data"] is None or sig != _mem["sig"]:
        import flix_cache
        _mem["data"] = {k: v for k, v in flix_cache.load_dict(path).items() if isinstance(v, list) and len(v) == 2}
        _mem["sig"] = sig
    return _mem["data"]


def pick(js):
    """la apaisada con título de la respuesta de TMDB: la primera en español y, si no hay, en inglés; '' si ninguna"""
    backs = [b for b in (js or {}).get("backdrops") or [] if isinstance(b, dict) and str(b.get("file_path") or "").startswith("/")]
    for lang in LANGS:
        for b in backs:
            if b.get("iso_639_1") == lang:
                return b["file_path"]
    return ""


def url_of(path, d=None):
    """dirección de la imagen apaisada de esa ruta de Palantir; '' si no está en caché o el título no tiene"""
    k = flix_age.key(path)
    if not k:
        return ""
    v = (d if d is not None else data()).get(k)
    return IMG + v[0] if v and isinstance(v[0], str) and v[0].startswith("/") else ""


def left_text(f):
    """«Quedan 1 h 31 min» / «Quedan 42 min» de lo que falta por ver (resume de Palantir, en segundos); '' si no consta.
    En la tarjeta de un capítulo a medias (flix_progress.episode_cards), delante su «T1 E4»"""
    ep = (f or {}).get("flix_ep") or ""
    rest = "" if (f or {}).get("flix_untimed") else _left(f)
    return "  ·  ".join(x for x in (ep, rest) if x)


def _left(f):
    r = (f or {}).get("resume") or {}
    try:
        pos, total = float(r.get("position") or 0), float(r.get("total") or 0)
    except (TypeError, ValueError):
        return ""
    mins = int(round((total - pos) / 60.0))
    if total <= 0 or pos <= 0 or mins < 1:
        return ""
    h, m = divmod(mins, 60)
    if not h:
        return "Quedan %d min" % m
    return "Quedan %d h" % h if not m else "Quedan %d h %d min" % (h, m)


def small_fanart(art):
    """el fondo de Palantir (TMDB a w1280 u original) a 500 px, para la tarjeta sin imagen con título; '' si no es de TMDB"""
    import re
    import urllib.parse
    a = art or ""
    if a.startswith("image://"):
        a = urllib.parse.unquote(a[len("image://"):].rstrip("/"))
    m = re.match(r"(https?://image\.tmdb\.org/t/p/)(?:w\d+|original)(/[^/?#]+)$", a)
    return m.group(1) + SIZE + m.group(2) if m else ""


def apply(items):
    """la imagen apaisada en tarjetas ya pintadas (sin repintar la fila); cualquier fallo se traga. Con título de TMDB si
    lo hay en caché; si no (aún no ha llegado o el título no tiene), el fondo de Palantir en pequeño y FlixWidePlain,
    con el que la tarjeta monta encima la sombra y el logo"""
    try:
        d = data()
        for li in items or []:
            u = url_of(li.getPath(), d)
            if u:
                if li.getProperty("FlixWide") != u:
                    li.setArt({"landscape": u})
                    li.setProperty("FlixWide", u)
                    li.setProperty("FlixWidePlain", "")
            elif not li.getProperty("FlixWide") and not li.getProperty("FlixWidePlain"):
                small = small_fanart(li.getArt("fanart"))
                if small:
                    li.setArt({"landscape": small})
                    li.setProperty("FlixWidePlain", "1")
    except Exception as e:  # noqa: BLE001
        log("pintar: %s" % type(e).__name__)


def decorate(items, files):
    """al pintar la fila: lo que falta por ver de cada título y la imagen que ya esté en caché"""
    try:
        for li, f in zip(items or [], files or []):
            li.setProperty("FlixLeft", left_text(f))
    except Exception as e:  # noqa: BLE001
        log("resto: %s" % type(e).__name__)
    apply(items)


def missing(files, now=None):
    now = time.time() if now is None else now
    d = data()
    out = []
    for f in files or []:
        k = flix_age.key((f or {}).get("file", ""))
        if not k or k in out:
            continue
        v = d.get(k)
        if v is None or (not v[0] and now - float(v[1] or 0) > RETRY):
            out.append(k)
    return out


def fetch(k, opener=None):
    """la ruta de TMDB de la apaisada con título para la clave; '' si no hay"""
    import urllib.request
    kind, tmdb = ("movie", k[1:]) if k[0] == "m" else ("tv", k[1:])
    with (opener or urllib.request.urlopen)(TMDB % (kind, tmdb, flix_common.TMDB_KEY), timeout=TIMEOUT) as r:
        return pick(json.loads(r.read().decode("utf-8")))


def _save(found):
    import flix_cache

    def change(disk):
        disk = {k: v for k, v in disk.items() if isinstance(v, list) and len(v) == 2}
        disk.update(found)
        return disk
    flix_cache.update_json(cache_file(), change)
    _mem["data"] = None                     # se relee con lo de otros intérpretes


def _run(opener=None, sleep=None):
    found, done = {}, 0
    try:
        while done < MAX_PER_RUN and not flix_common.quitting():
            with _busy:
                if not _queue:
                    break
                k = _queue.pop(0)
            try:
                v = fetch(k, opener)
            except Exception as e:  # noqa: BLE001  (sin red, TMDB caído: se deja para otra vez)
                log("TMDB no responde (%s): lo dejo para luego" % type(e).__name__)
                break
            found[k] = [v, time.time()]
            done += 1
            if len(found) >= SAVE_EVERY:
                _save(found)
                found = {}
                HOME.setProperty(REV, str(time.time()))
            (sleep or flix_common.quit_sleep)(PAUSE)
    finally:
        if found:
            _save(found)
            HOME.setProperty(REV, str(time.time()))
        if done:
            log("%d imágenes apaisadas nuevas de TMDB" % done)
        with _busy:
            _queue.clear()
            _running[0] = False


def want(files):
    """pide en segundo plano las que falten de estos títulos (un hilo por intérprete)"""
    try:
        ks = missing(files)
    except Exception:  # noqa: BLE001
        return
    if not ks:
        return
    with _busy:
        for k in ks:
            if k not in _queue:
                _queue.append(k)
        if _running[0]:
            return
        _running[0] = True
    threading.Thread(target=_run, daemon=True, name="flix_wide").start()
