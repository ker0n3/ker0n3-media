"""Reproducir una película de Palantir preguntando si reanudar (como hace Kodi en sus listas).

Desde las filas del skin la película se abría con PlayMedia(ruta): Kodi crea un elemento nuevo sin la posición
de reanudación que Palantir pone en la carátula y empezaba siempre desde el principio sin preguntar.

Uso desde XML: RunScript(special://skin/scripts/flix_play.py,<ruta>,<porcentaje visto>,<duración en s>)
Uso desde Python: flix_play.play(ruta, posicion_s, total_s)
Siempre con xbmc.Player().play(ruta, ListItem, windowed=False) (play_full): reanudar = ListItem con StartOffset
(Kodi conserva el desplazamiento al resolver la ruta del plugin); desde el inicio, sin él (Player().play no pregunta
«Reanudar desde…» con el marcador propio de Kodi, como hacía PlayMedia sin noresume).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402
from flix_common import A_BACK, COLOR_RE, INFO_COVER, WATCHED_DB_REL, decode_route, fresh, watched_movie  # noqa: E402,F401

# Clic en carátula → aviso/ficha cuanto antes: cada RunScript es un intérprete nuevo y en la Shield los imports se
# llevaban ~390 ms de ~490 (22-oct). Aquí nada de flix_progress/flix_rows (pickle, json, urllib.parse…) y las notas
# no cargan urllib hasta pedir una a internet (test_click_imports.py)
WATCHED_DB = xbmcvfs.translatePath(WATCHED_DB_REL)
HOME = xbmcgui.Window(10000)
COVER = "flix_trailer_cover"    # Window(home): fanart que tapa la ventana de debajo durante el tráiler (FlixTrailerCover)
# Dos reproducciones a la vez cierran Kodi («Logic error due to two concurrent busydialogs… The application will
# exit»; Shield 26-oct: OK en Black Clover y otra vez antes de que saliera su aviso, ya en Naruto, test_doble_apertura)
LAUNCH = "flix_launch"          # Window(home): hora del clic en un título, hasta que su script decide (aviso o ficha)
LAUNCH_SECS = 30                # marca más vieja = script muerto sin quitarla: no cuenta
# la marca cuyo aviso o ficha está a la vista: los toques van a esa ventana, la marca no hace falta. Si algo la cierra
# desde fuera, doModal no vuelve (solo termina con close() de Python) y launch_end no llega: la Inicio ignoraba todos los
# clics 30 s (móvil, 4-nov, ficha de Verity)
SHOWN = "flix_launch_shown"
LOAD_SECS = 120                 # = flix_playload.MAX_SECS: la capa de carga nunca dura más
LOAD_START = 2.0                # s tras flix_playload.begin en que la rueda de Palantir aún puede no haber salido
# capa de carga al pulsar el pop-up (mismos nombres que flix_playload.PROP / FANART / PENDING, sin importarlo: arrastra
# sqlite3 y json justo al pulsar; test_resume_layer.py comprueba que coinciden)
PL_PROP, PL_FANART, PENDING = "flix_playload", "flix_playload_fanart", "pending"
LOADING = ("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog) | "
           "Window.IsActive(progressdialog) | Player.HasMedia")



class ResumeDialog(xbmcgui.WindowXMLDialog):
    """FlixResume.xml (tools/gen_resume_dialog.py): 10 = Seguir viendo, 11 = Desde el principio, 14 = Ver ficha;
    Atrás = nada"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.t0 = kwargs.get("t0")         # hora del clic en la película (sheet): «aviso … en N ms» al abrirse
        self.choice = -1

    def onInit(self):
        launch_shown()
        for k, v in self.props.items():
            self.setProperty(k, v)
        try:
            self.getControl(30).setPercent(float(self.props.get("fr_pct") or 0))
        except (RuntimeError, ValueError):
            pass
        if self.t0:
            log_open("aviso", self.props.get("fr_title"), self.t0)
            self.t0 = None

    def onClick(self, cid):
        if cid in (10, 11, 14):           # 14 y no 12: Kodi escribe «N objetos» en el id 12 de las ventanas Python
            # la capa de carga ya, con el fanart del pop-up: hasta el begin() de start() (imports, route_info) el
            # Inicio asomaba y luego negro con rueda (Shield, 15 fps). Sin hilo: quien no llegue a begin() la quita.
            # Si ya hay una marca (otra carga en marcha) no se pisa: quitaría su capa
            if cid != 14 and not HOME.getProperty(PL_PROP):
                HOME.setProperty(PL_FANART, self.props.get("fr_fanart") or "")
                HOME.setProperty(PL_PROP, PENDING)
            self.choice = {10: 0, 11: 1, 14: 2}[cid]
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:        # Atrás = nada (choice -1), con los códigos de las demás ventanas (TV-28)
            self.close()


def ends_at(remaining, now=None, region=None):
    """«Termina a las 23:48»: la hora a la que acabaría si se pone ahora lo que queda (s), con el formato de hora de
    Kodi (24 h, o 12 h con AM/PM en un Kodi en inglés); '' si no se sabe cuánto queda (Carlos, 11-nov)"""
    import time
    try:
        remaining = float(remaining or 0)
    except (TypeError, ValueError):
        return ""
    if remaining <= 0:
        return ""
    if region is None:
        try:
            region = xbmc.getRegion("time")
        except Exception:  # noqa: BLE001
            region = ""
    f = (region or "%H:%M").replace(":%S", "")
    txt = time.strftime(f, time.localtime((time.time() if now is None else now) + remaining)).strip()
    if "%I" in f or "%l" in f:
        txt = txt.lstrip("0")
    return "Termina a las %s" % txt


def fmt(secs):
    secs = int(secs)
    return "%d:%02d:%02d" % (secs // 3600, secs % 3600 // 60, secs % 60)


def log_open(what, title, t0):
    """«ficha Dune en 180 ms»: del clic (play) a la ventana a la vista, para medir sin depuración (revisión 29-oct
    DAT-22, C2). No cuenta el arranque del intérprete ni los imports: eso solo sale con depuración. Una vez por clic:
    onInit vuelve a llegar al volver de otra ventana"""
    xbmc.log("[flix_play] %s %s en %d ms" % (what, title, (time.time() - t0) * 1000), xbmc.LOGINFO)


def choose(title, sub, btn10, btn11="Desde el principio", more="", pct=0, fanart="", t0=None):
    """pop-up FlixResume: 0 = seguir viendo, 1 = desde el principio, 2 = ver ficha (solo con more), -1 = Atrás.
    t0: hora del clic (solo la película, sheet) para apuntar lo que tardó en salir"""
    props = {"fr_title": COLOR_RE.sub("", title or "").strip(), "fr_sub": sub, "fr_btn10": btn10, "fr_btn11": btn11,
             "fr_more": more, "fr_pct": str(int(pct)), "fr_fanart": fanart or ""}
    w = ResumeDialog("FlixResume.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props,
                     t0=t0)
    try:
        w.doModal()
    finally:
        launch_hidden()
    choice = w.choice
    del w
    # Inicio táctil: el gesto Atrás de Android que cierra el pop-up le llega después como pulsación larga (dos, con y
    # sin coordenadas) y abría el menú de otra carátula (móvil, 21-oct): flix_home.py las ignora un rato
    xbmcgui.Window(10000).setProperty("flix_dlg_closed", "%f" % time.time())
    return choice


def ask(position, total, title="", fanart=""):
    sub = "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else "")
    return choose(title, sub, "Seguir viendo", "Desde el principio",      # el tiempo ya va en sub
                  pct=100 * position / total if total else 0, fanart=fanart)


def release_pending():
    """quita la capa del pop-up si no se llegó a begin() (no hace nada si ya hay marca de verdad)"""
    if HOME.getProperty(PL_PROP) == PENDING:
        import flix_playload
        flix_playload.clear_pending()


def loading_other(now=None):
    """otro título cargando su vídeo: capa de flix_playload puesta y recién pulsado o con algo cargando"""
    stamp = HOME.getProperty("flix_playload")
    now = now or time.time()
    if not fresh(stamp, now, LOAD_SECS):
        return False
    return fresh(stamp, now, LOAD_START) or xbmc.getCondVisibility(LOADING)


def opening_other(now=None):
    """ya se abre otro título: su clic aún no ha sacado aviso ni ficha (LAUNCH) o carga su vídeo"""
    now = now or time.time()
    mark = HOME.getProperty(LAUNCH)
    return (fresh(mark, now, LAUNCH_SECS) and mark != HOME.getProperty(SHOWN)) or loading_other(now)


def launch_begin():
    if HOME.getProperty(SHOWN):
        xbmc.log("[flix_play] clic con otra ventana sin volver (¿cerrada desde fuera?): sigo", xbmc.LOGINFO)
        HOME.clearProperty(SHOWN)
    mark = "%.3f" % time.time()
    HOME.setProperty(LAUNCH, mark)
    return mark


def launch_end(mark):
    if HOME.getProperty(LAUNCH) == mark:
        HOME.clearProperty(LAUNCH)
        HOME.clearProperty(SHOWN)


def launch_shown():
    """aviso o ficha a la vista (onInit)"""
    HOME.setProperty(SHOWN, HOME.getProperty(LAUNCH))


def launch_hidden():
    """su doModal volvió: hasta el vídeo (imports, begin) la marca cuenta otra vez"""
    HOME.clearProperty(SHOWN)


def refuse_if_loading():
    """True (y aviso) si otro título está cargando: no se lanza un 2.º vídeo"""
    if not loading_other():
        return False
    xbmc.log("[flix_play] otro título cargando: no lanzo otro vídeo", xbmc.LOGINFO)
    release_pending()
    xbmcgui.Dialog().notification("KER0N3 MEDIA", "Espera: ya se está abriendo otro título", xbmcgui.NOTIFICATION_INFO,
                                  2500)
    return True


def trailer_over():
    """«Ver» / «Seguir viendo»: ya no hay tráiler. Sin esto, tras el tráiler automático FLAG (flix_trailer) seguía puesta
    2 s más (flix_trailer.done programa quitarla) y VideoFullScreen se saltaba flix_autoplay follow al cargar; GEN: un
    tráiler cancelado que llegue tarde ya no se para (flix_trailer)"""
    HOME.clearProperty("flix_trailer_gen")
    xbmc.executebuiltin("CancelAlarm(flixtrailerend,true)")
    HOME.clearProperty("flix_trailer")
    # capítulo a medias desde la ficha de serie («Continuar»): el tráiler automático de la ficha seguía sonando con la
    # pantalla de carga (Carlos, 30-oct); lo para el hilo de la ficha
    import flix_autotrailer
    flix_autotrailer.ask_stop()


def resume_series(play, fanart):
    """«Seguir viendo» de una serie: Palantir pone el capítulo a medias o el siguiente (play_mis_serieS)"""
    if refuse_if_loading():
        return
    try:
        trailer_over()
        import flix_playload
        flix_playload.begin(fanart, play)          # una sola rueda hasta el vídeo
    finally:
        release_pending()                          # si algo falló antes del begin(); después no hace nada
    play_full(play)


def play_full(path, offset=0):
    """reproduce a pantalla completa. Un tráiler de la ficha pedido en su recuadro (PlayMedia(...,1)) que no llega a
    empezar (YouTube colgado: Kodi lo mata a los 5 s) deja puesta en Kodi la marca «el próximo vídeo, en ventana»
    (CMediaSettings::SetMediaStartWindowed: solo se quita al empezar un vídeo) y PlayMedia no la toca: la película
    sonaba detrás de la ficha y luego de la búsqueda (Shield, 2-nov, American Fiction). Player().play la pone siempre
    (Player::playStream, windowed=False)"""
    li = xbmcgui.ListItem(path=path)
    if offset > 0:
        li.setProperty("StartOffset", str(int(offset)))
    xbmc.Player().play(path, li, False)


def start(path, offset=0):
    """reproduce la ruta de Palantir; offset > 0 = reanudar ahí (StartOffset se conserva al resolver el plugin)"""
    if refuse_if_loading():
        return
    try:
        trailer_over()      # sin tráiler: ni GEN (uno tardío ya no se para) ni FLAG (VideoFullScreen sí sigue el autoplay)
        import flix_playload
        info = route_info(path)
        flix_playload.begin(_img(info.get("fanart")) or HOME.getProperty("flix_open_fanart"), path)
    finally:
        release_pending()   # capa del pop-up (pending) si algo falló antes del begin(); después no hace nada
    HOME.setProperty("flix_play_offset", str(int(offset)) if offset > 0 else "")   # reintentos: flix_autoplay salta ahí
    if offset > 0:
        xbmc.log("[flix_play] reanudar en %s: %s" % (fmt(offset), path[:80]), xbmc.LOGINFO)
    else:
        # la ficha ya decidió (progreso de Palantir/Trakt): con PlayMedia sin noresume Kodi preguntaba «Reanudar
        # desde…» con su PROPIO marcador local (otro progreso, distinto en cada aparato: «Resume from 00:18:52», móvil
        # 19-oct); Player().play no pregunta
        xbmc.log("[flix_play] ver %s" % (info.get("title") or path[:80]), xbmc.LOGINFO)   # inicio de C6 (DAT-22)
    play_full(path, offset)


def play(path, position=0, total=0, title="", fanart="", ficha=False):
    """ficha: directo a la ficha, sin el aviso «Te quedaste en…» (vuelta de «Títulos de X» del panel ( i ), flix_info)"""
    t0 = time.time()                    # el clic: la ficha o el aviso apuntan lo que tardaron (log_open)
    if path.startswith("special://skin/"):
        return              # carátula de relleno de una fila que aún carga (flix_home_conf.IDLE_PATH): abría una ficha vacía
    if opening_other():
        xbmc.log("[flix_play] ya se abre otro título: ignoro el clic en %s" % (title or path[:60]), xbmc.LOGINFO)
        return
    mark = launch_begin()
    try:
        _play(path, position, total, title, fanart, t0, ficha)
    finally:
        launch_end(mark)


def _play(path, position, total, title, fanart, t0=None, ficha=False):
    position, total = float(position or 0), float(total or 0)
    if not xbmc.getCondVisibility("Skin.HasSetting(flix_nosheet)"):
        # TV y táctil: pulsar una película abre su ficha (info + Ver / Seguir viendo / Desde el principio)
        if ficha:
            return sheet(path, position, total, title, fanart, t0, ask_first=False)
        return sheet(path, position, total, title, fanart, t0)
    if position > 30 and (not total or position < total - 60):
        choice = ask(position, total, title, fanart)
        if choice < 0:
            return
        if choice == 0:
            start(path, position)
            return
    start(path)


# ---------- ficha de película (TV: xml/FlixMovie.xml, táctil: touch/xml/FlixMovie.xml) ----------
TMDB_IMG = "https://image.tmdb.org/t/p/original"


def _img(v):
    v = v or ""
    return TMDB_IMG + v if v.startswith("/") else v


def route_info(path):
    """el elemento entero de Palantir va dentro de su ruta (JSON con comillas de Python)"""
    try:
        import ast
        return ast.literal_eval(decode_route(path))
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_play] ruta de Palantir ilegible (%s): %s" % (e, path[:80]), xbmc.LOGWARNING)
        return {}


class MovieSheet(xbmcgui.WindowXMLDialog):
    """FlixMovie.xml: 10 = Ver / Seguir viendo, 11 = Desde el principio, 14 = Tráiler, 90 = volver.
    Tráiler (flix_trailer): la ficha sigue abierta con «Cargando…» mientras el addon YouTube lo resuelve y se cierra
    cuando ya hay vídeo (choice 2); sheet() la reabre al acabar. NO usar el id 12: en las ventanas Python Kodi lo
    reserva para «N objetos» (CONTROL_LABELFILES) y al volver de un vídeo pisaba la etiqueta (20-oct)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.trailer = kwargs.get("trailer")
        self.focus = kwargs.get("focus", 10)
        self.t0 = kwargs.get("t0")         # hora del clic: «ficha … en N ms» al abrirse (no al volver del tráiler)
        self.auto = kwargs.get("auto")     # el automático que sigue sonando al volver de la pantalla completa
        self.choice = -1
        self.loading = False
        self.cancel = False

    def onInit(self):
        launch_shown()
        for k, v in self.props.items():
            self.setProperty(k, v)
        if self.trailer is not None and self.trailer.url:     # si llega después, lo pone TrailerLookup
            self.setProperty("fm_trailer", self.trailer.url)
        try:
            self.getControl(30).setPercent(float(self.props.get("fm_pct") or 0))
        except (RuntimeError, ValueError):
            pass
        self.setFocusId(self.focus)
        if HOME.getProperty(COVER):         # vuelta del tráiler: la ficha ya tapa (tras su fundido); fuera la cubierta
            flix_common.later(0.5, HOME.clearProperty, COVER)    # daemon: no retiene el intérprete (PY-21)
        if HOME.getProperty(INFO_COVER):    # y la de la vuelta desde «Títulos de X» (flix_info)
            flix_common.later(0.5, HOME.clearProperty, INFO_COVER)
        if self.t0:
            log_open("ficha", self.props.get("fm_title"), self.t0)
            self.t0 = None
        if self.auto is not None:           # vuelta de la pantalla completa: el mismo tráiler, en su recuadro
            self.auto.attach(self)
        elif self.focus != 14:              # no al volver del tráiler (botón «Tráiler» de siempre)
            import flix_autotrailer
            self.auto = flix_autotrailer.AutoTrailer(
                self, lambda: self.trailer.url if self.trailer is not None else "")
            self.auto.start()

    def stop_auto(self):
        if self.auto is not None:
            self.auto.stop()

    def onClick(self, cid):
        if self.loading:
            return
        if cid in (10, 11):
            self.choice = cid - 10
            self.stop_auto()
            self.close()
        elif cid == 14 and self.auto is not None and self.auto.playing():
            self.choice = 3                 # sheet() lo pasa a pantalla completa y reabre la ficha con él
            self.close()
        elif cid == 14:
            self.stop_auto()                # aún cargando: el automático se para antes del tráiler de siempre
            url = self.trailer.url if self.trailer is not None else ""
            if url:
                self.loading = True
                self.setProperty("fm_trailer_btn", "Cargando…")
                threading.Thread(target=self.play_trailer, args=(url,), daemon=True).start()
        elif cid == 90:
            self.stop_auto()
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:            # los 9 códigos comunes (TV-28; antes 10 y 92)
            self.cancel = self.loading      # Atrás mientras carga el tráiler: se cancela (si empieza, se para)
            self.stop_auto()
            self.close()
        elif self.auto is not None:         # cualquier otra tecla antes del tráiler automático: ya no arranca
            self.auto.key_in_sheet(action.getId())

    def play_trailer(self, url):
        import flix_trailer
        if flix_trailer.start(url, cancelled=lambda: self.cancel):
            HOME.setProperty(COVER, self.props.get("fm_fanart") or "flix/white.png")
            self.choice = 2
            self.close()
            return
        self.loading = False
        self.setProperty("fm_trailer_btn", "Tráiler")


def sheet(path, position, total, title, fanart, t0=None, ask_first=True):
    import sys as _s
    import os as _o
    _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
    info = route_info(path)
    label = info.get("label") or title or ""
    clean_label = COLOR_RE.sub("", label)
    parts = re.findall(r"\[([^\]]*)\]", clean_label)
    name = info.get("title") or re.split(r"\s+\(\d{4}\)|\s+\[", clean_label)[0].strip()
    watched = 0
    # progreso real (watched.db de Palantir), no el que trae la carátula: solo la fila de esta película, no toda
    # movies_watched (revisión 7-nov PY-12)
    try:
        row = watched_movie(WATCHED_DB, info.get("tmdb") or "")
        if row:
            watched = int(row[0] or 0)
            total = float(row[2] or 0) or total or float(info.get("duration") or 0)
            position = total * float(row[1] or 0) / 100
        elif row is not None:           # Palantir tiene otras películas y esta no: sin empezar
            position = 0.0
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_play] progreso: %s" % e, xbmc.LOGWARNING)
    total = total or float(info.get("duration") or 0)
    started = position > 30 and (not total or position < total - 60)
    if started and ask_first:
        # empezada: pop-up en vez de la ficha (la ficha queda como 3.ª opción)
        choice = choose(name, "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else ""),
                        "Seguir viendo", more="Ver ficha",                 # el tiempo ya va en sub
                        pct=100 * position / total if total else 0, fanart=fanart or _img(info.get("fanart")), t0=t0)
        t0 = None                       # «Ver ficha» desde el aviso: ya se apuntó el clic
        if choice == 0:
            return start(path, position)
        if choice == 1:
            return start(path)
        if choice != 2:
            return
    quality = parts[-1] if len(parts) >= 2 else ""
    up = quality.upper()
    q = "4K · DV" if "4K" in up and "DV" in up else next(
        (v for k, v in (("4K", "4K"), ("DV", "DV"), ("HDR", "HDR"), ("1080", "1080p"), ("720", "720p")) if k in up), "")
    year = (info.get("fecha") or "")[:4]
    mins = int(float(info.get("duration") or total or 0) // 60)
    rating = str(info.get("rating") or "").split("/")[0]

    def meta_with(rt):              # rt: «Metacritic 82» (flix_ratings) o '' -> la ★ de TMDB de siempre
        return "  ·  ".join(x for x in (year, "%d min" % mins if mins else "", q,
                                         rt or ("★ %s" % rating if rating and rating not in ("0", "0.0") else ""),
                                         parts[0].strip() if len(parts) >= 2 else "") if x and x.strip())
    # la misma línea por partes para la ficha del móvil, con los iconos de imagen y el círculo de edad en vez de la
    # calidad en texto (como la cabecera de la TV, 7-nov): fm_meta_pre, fm_q, fm_hdr, fm_age y fm_meta_post. La ficha
    # de la TV sigue con fm_meta
    import flix_items
    hdr = flix_items.hdr_from_label(label)
    try:
        import flix_age
        age = flix_age.age_of(path)
    except Exception:  # noqa: BLE001
        age = ""
    pre = "  ·  ".join(x for x in (year, "%d min" % mins if mins else "") if x and x.strip())

    def post_with(rt):
        post = "  ·  ".join(x for x in (rt or ("★ %s" % rating if rating and rating not in ("0", "0.0") else ""),
                                        parts[0].strip() if len(parts) >= 2 else "") if x and x.strip())
        return ("  ·  " + post if pre or q or hdr or age else post) if post else ""
    # la nota de MDBList (ratings3.json entero) no se lee en el hilo del clic: la ficha abre con la ★ de TMDB y el
    # hilo late la cambia cuando llega (revisión 7-nov PY-12)
    meta = meta_with("")
    genre = info.get("genre") or []
    ends = ends_at((total - position) if started else (total or mins * 60))
    props = {
        "fm_title": name,
        "fm_logo": _img(info.get("clearlogo")),
        "fm_fanart": fanart or _img(info.get("fanart")),
        "fm_meta": meta,
        "fm_meta_pre": pre,
        "fm_q": q,
        "fm_hdr": hdr,
        "fm_age": age,
        "fm_meta_post": post_with(""),
        "fm_genre": " / ".join(genre) if isinstance(genre, list) else str(genre),
        # a qué hora acabaría si se pone ahora: lo que queda si está empezada, entera si no (al abrir la ficha)
        "fm_ends": ("  ·  " if genre else "") + ends if ends else "",
        "fm_plot": COLOR_RE.sub("", info.get("plot") or ""),
        "fm_state": "started" if started else "watched" if watched else "new",
        "fm_pos": fmt(position) if started else "",
        "fm_total": fmt(total) if total else "",
        "fm_pct": str(int(100 * position / total)) if started and total else "0",
        "fm_btn": ("Seguir viendo  ·  %s" % fmt(position)) if started else "Ver de nuevo" if watched else "Ver",
        "fm_trailer_btn": "Tráiler",
        "fm_tmdb": str(info.get("tmdb") or ""),         # botón ( i ): panel de información (flix_info)
        "fm_path": path,                                # y para volver a esta ficha desde «Títulos de X»
    }
    trailer, focus, auto = TrailerLookup(info), 10, None
    viva = None                         # el automático de la ficha que pueda seguir sonando (red de seguridad)
    ask_late = True
    try:
        while True:
            w = MovieSheet("FlixMovie.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props,
                           trailer=trailer, focus=focus, t0=t0, auto=auto)
            t0 = None                       # reabierta tras el tráiler: esa no es la del clic
            if ask_late:            # la nota, de caché o pedida (una vez: no al reabrir tras el tráiler)
                ask_late = False

                def late(w=w):
                    if not age:
                        try:                    # edad de TMDB que falte: para la próxima vez (flix_age, en segundo plano)
                            import flix_age
                            flix_age.want([{"file": path}])
                        except Exception:  # noqa: BLE001
                            pass
                    try:
                        import flix_ratings
                        r = flix_ratings.label_for(path, wait=flix_ratings.TIMEOUT)
                    except Exception as e:  # noqa: BLE001
                        xbmc.log("[flix_play] nota: %s" % e, xbmc.LOGWARNING)
                        return
                    if r:
                        props["fm_meta"] = meta_with(r)
                        w.setProperty("fm_meta", props["fm_meta"])
                        props["fm_meta_post"] = post_with(r)
                        w.setProperty("fm_meta_post", props["fm_meta_post"])
                threading.Thread(target=late, daemon=True).start()
            trailer.win = w
            try:
                w.doModal()
            finally:
                launch_hidden()
                viva = w.auto                   # también si doModal falla: lo para el finally de abajo
            choice = w.choice
            auto = viva
            trailer.win = None
            del w
            if choice == 3:                         # «Tráiler» con el automático sonando: pantalla completa
                if not (auto.to_fullscreen() and auto.wait_fullscreen()):
                    auto = None                     # acabó a pantalla completa: la ficha con el fanart
                props["fm_trailer_btn"], focus = "Tráiler", 14
                continue                            # Atrás: la ficha otra vez, con el tráiler en su recuadro si sigue
            auto = None
            if choice != 2:
                break
            import flix_trailer
            try:
                flix_trailer.watch()            # al acabar (o Atrás) se vuelve a la ficha, en «Tráiler»
            except Exception:  # noqa: BLE001
                HOME.clearProperty(COVER)
                raise
            props["fm_trailer_btn"], focus = "Tráiler", 14
    finally:
        # red de seguridad (como flix_series_sheet.open_sheet): ningún camino deja el automático sonando con FLAG, la
        # marca y el silencio puestos: ni una ficha cerrada sin onClick/onAction ni un fallo en la pantalla completa
        # (to_fullscreen -> set_mute -> rpc). Solo sigue vivo a propósito entre vueltas del bucle con choice == 3
        if viva is not None and viva.state != "done":
            viva.stop()
    HOME.clearProperty(COVER)               # por si la ficha no llegó a reabrirse
    if choice == 0:
        start(path, position if started else 0)
    elif choice == 1:
        start(path)


class TrailerLookup:
    """URL del tráiler de la ficha (flix_trailer: TMDB y si no Palantir), buscada en un hilo al abrirla: el botón
    aparece en cuanto llega. Sin el addon YouTube ni se busca (sin botón, como antes)."""

    def __init__(self, info):
        self.url, self.win = "", None
        if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
            return
        tmdb, palantir = str(info.get("tmdb") or ""), info.get("trailer") or ""

        def run():         # flix_trailer (urllib) se importa aquí: la ficha no espera a esos imports
            try:
                import flix_trailer
                self.url = flix_trailer.resolve("movie", tmdb, palantir)
            except Exception as e:  # noqa: BLE001
                xbmc.log("[flix_play] tráiler: %s" % e, xbmc.LOGWARNING)
                self.url = "plugin://plugin.video.youtube/play/?video_id=%s" % palantir if palantir else ""
            w = self.win
            if w is not None and self.url:
                w.setProperty("fm_trailer", self.url)
        threading.Thread(target=run, daemon=True).start()


TOUCH_SECS = 5      # s: el dedo apoyado en un capítulo cuenta para el aviso de reanudar que salga enseguida


def touch_item(mark, now):
    """(lista, posición desde 1, ruta) del capítulo que tocó el dedo hace poco (flix_touch_item, flix_series_sheet), o None"""
    parts = (mark or "").split("|", 3)
    try:
        return tuple(parts[1:]) if len(parts) == 4 and 0 <= now - float(parts[0]) <= TOUCH_SECS else None
    except ValueError:
        return None


def resume_focused(resume_label):
    """la pregunta «Reanudar desde… / Reproducir desde el principio» de Kodi (capítulo empezado de la pantalla de serie,
    elemento de una rejilla) sale con el estilo genérico y junto al dedo: DialogContextMenu.xml la cierra y aquí se
    hace la nuestra, centrada, con el elemento enfocado. resume_label: su 1.er botón («Reanudar desde 00:12:34»)"""
    end = time.time() + 2
    while time.time() < end and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
        xbmc.sleep(50)
    cid = xbmc.getInfoLabel("System.CurrentControlId")
    c = "Container(%s).ListItem." % cid if cid.isdigit() else "ListItem."
    path = xbmc.getInfoLabel(c + "FileNameAndPath")
    if not path:                # móvil: sin lista enfocada tras volver del vídeo la pulsación se perdía (4-nov)
        touched = touch_item(HOME.getProperty("flix_touch_item"), time.time())
        if touched:
            # el seleccionado de esa lista, si se lee: es el del tiempo del aviso; la geometría puede errar en la fila cortada
            c = "Container(%s).ListItem." % touched[0]
            path = xbmc.getInfoLabel(c + "FileNameAndPath")
            if not path:
                c = "Container(%s).ListItemAbsolute(%d)." % (touched[0], int(touched[1]) - 1)
                path = touched[2]
    m = re.search(r"(?:(\d+):)?(\d+):(\d\d)\s*$", resume_label or "")
    position = (int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + int(m.group(3))) if m else 0
    if not path or not position:
        xbmc.log("[flix_play] reanudar: sin elemento o sin tiempo (%r, %r)" % (path[:60], resume_label), xbmc.LOGINFO)
        return
    dur = xbmc.getInfoLabel(c + "Duration(secs)")
    total = float(dur) if dur.isdigit() else 0.0
    title = xbmc.getInfoLabel(c + "Label")
    fanart = xbmc.getInfoLabel(c + "Art(fanart)") or xbmcgui.Window(10000).getProperty("flix_open_fanart")
    choice = choose(title, "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else ""),
                    "Seguir viendo", pct=100 * position / total if total else 0, fanart=fanart)
    if choice == 0:
        start(path, position)
    elif choice == 1:
        start(path)


def resume_of(f):
    """(posición, total) de un elemento JSON-RPC (propiedad resume)"""
    r = f.get("resume") or {}
    return r.get("position") or 0, r.get("total") or 0


if __name__ == "__main__" and sys.argv[1:2] == ["resume"]:
    resume_focused(sys.argv[2] if len(sys.argv) > 2 else "")
elif __name__ == "__main__" and sys.argv[2:3] == ["ficha"]:
    play(sys.argv[1], ficha=True)       # vuelta a la ficha desde «Títulos de X» (flix_info.back_to)
elif __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    title = sys.argv[4] if len(sys.argv) > 4 else ""
    fanart = sys.argv[5] if len(sys.argv) > 5 else ""
    try:
        pct = float(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] else 0.0
        dur = float(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3] else 0.0
    except ValueError:
        pct, dur = 0.0, 0.0
    # desde el XML solo hay porcentaje entero: se redondea hacia atrás (reanuda como mucho ~1 % antes)
    pos = max(0.0, (pct - 1) * dur / 100.0) if pct > 0 and dur > 0 else 0.0
    play(path, pos, dur, title, fanart)
