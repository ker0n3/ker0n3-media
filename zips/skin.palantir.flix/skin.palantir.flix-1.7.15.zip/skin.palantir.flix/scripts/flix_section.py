"""Sección de Palantir desplegada en filas (versión TV, ventana FlixSection.xml).

Uso: RunScript(special://skin/scripts/flix_section.py,<clave de la sección>)   (flix_sections: sections.json)
Las filas son los submenús de la sección en Palantir, con el orden y los interruptores elegidos en Ajustes →
Secciones del menú → Editar filas (flix_sections_conf.apply_rows).
Se carga SOLO al entrar: las filas se piden a Palantir una a una (Palantir atiende de una en una, ~4 s cada
una) y van apareciendo; con caché de 30 min (flix_rows.fetch) volver a entrar es instantáneo.
  fila de listado  -> carátulas (película = reproducir, serie = temporadas vía flix_series.py)
  fila de submenú  -> tarjetas (sagas, calidad, letras…): al abrir una, su rejilla de carátulas
  último "Más…" de un listado -> tarjeta "Ver más" que abre la página siguiente como sección de una fila suelta
                               (open_rows, como «Ver similares»): en la cuadrícula de Kodi el clic iba al selector de
                               Palantir o a la carpeta de la serie, no a la ficha propia (Carlos, 7-nov)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import threading
import time

import xbmc
import xbmcgui

import flix_cache  # noqa: E402
import flix_common  # noqa: E402
import flix_menu_preview  # noqa: E402
import flix_newep  # noqa: E402
import flix_reload  # noqa: E402
import flix_rows  # noqa: E402
import flix_sections_conf  # noqa: E402
from flix_items import to_listitem  # noqa: E402  (sin el buscador entero: revisión 29-oct ARR-19)

HOME = xbmcgui.Window(10000)
FIRST, NROWS = 5401, 16
RETRY = 5490            # botón de reserva (FlixSection.xml): foco mientras no hay filas; OK = reintentar
ROW_LIMIT = 40
from flix_common import A_BACK  # noqa: E402,F401  (comunes: TV-28; flix_inicio lo importa de aquí)
A_OK = (7, 100)                 # Select y clic: OK en el menú lateral (9000) de la sección
A_RIGHT = (2,)                  # derecha: sobre «Inicio» del menú, como OK (vuelve al Inicio)
MENU = 9000                     # menú lateral (FlixHomeChrome): 1 = «Inicio», 2… = hueco flix_sec<N> del Inicio
A_CONTEXT = (117,)              # mantener OK / tecla menú: menú KER0N3 de la carátula, como en el Inicio (28-oct)
MENU_WAIT = 180                 # s: lo más que se espera a que acabe flix_menu (diálogos de Palantir) para repintar
LOADING, MISSING = flix_rows.LOADING, flix_rows.MISSING     # tarjeta de una fila que aún no ha llegado / que no dio nada
TICK = 0.5                      # s entre vueltas de la vigilancia (vista previa del menú), como el Inicio


def log(msg):
    xbmc.log("[flix_section] %s" % msg, xbmc.LOGINFO)


def small_screen():
    """pantalla de 1080 o menos (Fire TV): las carátulas de las filas se dibujan a 168x252 y Palantir las da a 342x513.
    En la Shield (4K) y el móvil se quedan como estaban"""
    global _SMALL
    if _SMALL is None:
        try:
            _SMALL = 0 < int(xbmc.getInfoLabel("System.ScreenWidth") or 0) <= 1920
        except ValueError:
            _SMALL = False
    return _SMALL


_SMALL = None


def small_art(art):
    """póster y miniatura de TMDB a w185 (~ -65 % de memoria de textura por carátula; auditoría 22-oct C-02). Solo en
    las filas: la ficha y el selector siguen con las suyas"""
    out = dict(art)
    for k in ("poster", "thumb"):
        v = out.get(k) or ""
        if "image.tmdb.org" in v:
            out[k] = v.replace("%2fw342%2f", "%2fw185%2f").replace("/w342/", "/w185/")
    return out


def make_item(f, row):
    if small_screen() and f.get("art"):
        f = dict(f, art=small_art(f["art"]))
    li = to_listitem(f)
    if flix_rows.is_more(f):
        li.setLabel("Ver más")
        li.setProperty("card", "text")
        li.setProperty("open", "grid")
        li.setProperty("more", "1")         # página siguiente: la sección la abre como fila suelta (onClick)
    elif row["kind"] == "coll":
        li.setProperty("card", "text" if flix_rows.is_generic(f) else "band")
        li.setProperty("open", "grid")
    elif f.get("flix_ep"):
        li.setProperty("open", "resume")    # capítulo a medias en «Seguir viendo» (flix_progress.episode_cards): sin aviso
        li.setProperty("FlixEp", f["flix_ep"])      # «T1 E4»: el menú de la tarjeta es el del capítulo (flix_menu.card_episode)
    elif f.get("filetype") == "directory":
        li.setProperty("open", "series")
    else:
        li.setProperty("open", "play")
    return li


def placeholder(label):
    """tarjeta de texto de una fila sin títulos todavía: no abre nada (onClick mira «open»)"""
    li = xbmcgui.ListItem(label)
    li.setProperty("card", "text")
    li.setProperty("open", "")
    return li


class SectionWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.var = kwargs.get("var")
        self.title = kwargs.get("title")
        self.rconf = kwargs.get("rconf") or {}     # filas elegidas (orden / apagadas)
        # filas sueltas en vez de las del menú de Palantir (open_rows: «Ver similares»); Atrás la cierra
        self.fixed = kwargs.get("rows")
        self.back_cover = kwargs.get("back_cover") or ""    # «Títulos de X»: fondo de la ficha a la que vuelve Atrás
        self.t0 = kwargs.get("t0")       # hora de la pulsación (main): la 1.ª carga apunta «lista en X s» desde ahí
        self.key = kwargs.get("key") or ""      # clave de esta sección (flix_sections): la cabecera de entrada la compara
        self.next = ""                   # clave de la sección que el usuario eligió en el menú lateral ("" = no hay)
        # fs_key ANTES de doModal: las animaciones WindowOpen y la cabecera de entrada (FlixSection.xml) la leen al abrirse
        # la ventana y onInit llegaría tarde
        self.setProperty("fs_key", self.key)
        # y su nombre: la marca «estás aquí» del menú lateral cerrado (FlixHomeChrome, param current) lo compara con el
        # de cada elemento del menú; así ya está al abrirse (onInit lo repite, como siempre)
        self.setProperty("fs_title", self.title or "")
        # sin menú lateral: filas sueltas abiertas desde donde no se veía (búsqueda, ficha, cuadrícula: open_rows)
        self.setProperty("fs_nomenu", "1" if kwargs.get("nomenu") else "")
        self.stop = False
        self.started = False
        self.rows = {}           # id de lista -> fila
        self.slot_of = {}        # ruta de la fila -> id de lista
        self.shown = {}          # id de lista -> títulos pintados
        # vista previa en el menú lateral, como en el Inicio (Carlos, 31-oct): la crea la primera onInit
        self.preview = None
        self.wid = ""            # id de esta ventana (primera onInit): active()
        self.in_flight = False   # el hilo de carga pidiendo a Palantir: la vista previa no pide a la vez
        self.wake = threading.Event()       # la vista previa acabó de pedir: la carga, si esperaba, sigue
        self.refocus = None      # foco pedido a una fila recién rellenada: tick() lo repite si Kodi no lo dio (XML-02)

    def onInit(self):
        self.setProperty("fs_title", self.title)
        self.setProperty("fs_key", getattr(self, "key", ""))
        self.mark_menu()
        if not self.started:
            self.started = True
            # solo en la primera, como fi_window en el Inicio: las siguientes pueden llegar con otra ventana ya delante
            self.wid = str(xbmcgui.getCurrentWindowId())
            # aquí y no en __init__: al crearse quita la vista previa del Inicio (flix_pv_on), que aún se ve hasta que
            # esta ventana está delante. home_item: «Inicio» del menú enseña la vista previa del Inicio (Carlos, 31-oct)
            self.preview = flix_menu_preview.Preview(self, self.wake.set, lambda: self.in_flight, own=self.key,
                                                     home_item=True)
            threading.Thread(target=self.load, daemon=True).start()
            threading.Thread(target=self.watch, daemon=True).start()
        else:
            self.repaint()

    def mark_menu(self):
        """marca en el menú lateral la sección de esta ventana (posición = hueco + 1; «Inicio» es la 1). Sin su hueco en
        el Inicio (acceso por clave que no está en el menú) o sin la lista (tests) no hace nada. Se repite en cada
        onInit: tras recargar la skin el menú se monta de nuevo y vuelve a «Inicio»"""
        key = getattr(self, "key", "")
        if not key:
            return
        for n in range(1, flix_sections_conf.MAX_SECTIONS + 1):
            if HOME.getProperty("flix_sec%d_key" % n) == key:
                try:
                    self.getControl(MENU).selectItem(n)         # 0-based: el hueco n está en la posición n + 1
                except (RuntimeError, AttributeError):
                    pass
                return

    def menu_choice(self):
        """(clave, tipo) de la sección que tiene el foco en el menú lateral; ('', '') si es «Inicio» o no hay"""
        import flix_menu_preview
        n = flix_menu_preview.slot_of(xbmc.getInfoLabel("Container(%d).CurrentItem" % MENU))
        if not n:
            return "", ""
        return HOME.getProperty("flix_sec%d_key" % n), HOME.getProperty("flix_sec%d_kind" % n)

    def fallback(self):
        """adónde va el foco cuando no hay fila con títulos: a la 1.ª fila si ya tiene hueco («Cargando…» / «No
        disponible» son tarjetas enfocables; con fs_row1 puesta la reserva 5490 está oculta y Kodi no la enfoca:
        «5490 can't focus», revisión 7-nov XML-02) o a la reserva mientras no hay ninguna"""
        return FIRST if self.getProperty("fs_row1") else RETRY

    def focus_soon(self, cid):
        """pide el foco y lo apunta para que tick() lo repita si Kodi no lo dio: tras reset()+addItems() la fila sigue
        oculta (NumItems era 0) hasta el fotograma siguiente y el foco pedido en el mismo se pierde («5412 can't
        focus»; luego la 1.ª tecla lo devolvía a la 1.ª fila). XML-02"""
        self.setFocusId(cid)
        self.refocus = cid

    def focus_rows(self):
        """OK en el menú sobre la sección actual: el foco a su primera fila con títulos (o, si aún no hay, adonde diga
        fallback: ahí también lo deja restore_focus)"""
        for lid in sorted(self.rows):
            if self.shown.get(lid):
                self.setFocusId(lid)
                return
        self.focus_soon(self.fallback())

    def restore_focus(self):
        """foco perdido (p. ej. abajo desde la lupa con el grupo de filas aún sin filas que enfocar): a la primera fila,
        o a la reserva mientras no hay. Con la sección cerrándose no se toca nada"""
        if self.stop:
            return
        try:
            if self.focus_id() is None:
                self.setFocusId(self.fallback())
        except RuntimeError:                        # ventana ya destruida
            pass

    def repaint(self):
        """tras recargar la skin (actualización automática con la sección abierta) Kodi vuelve a montar la ventana
        desde el XML con las listas vacías y llama otra vez a onInit: se repinta lo que había y se devuelve el foco.
        Antes quedaba en negro, sin foco, y solo respondía Atrás (auditoría 22-oct A-06). Solo con "0": al volver de
        un vídeo onInit puede llegar con la ventana del vídeo aún delante y entonces da "" """
        for lid, row in sorted(self.rows.items()):
            if xbmc.getInfoLabel("Container(%d).NumItems" % lid) != "0":
                continue
            files = self.shown.get(lid)
            if files:
                items = [make_item(f, row) for f in files]
            else:
                items = [placeholder(MISSING if getattr(self, "loaded", False) else LOADING)]
            log("fila %s vacía al volver (skin recargada): repinto" % row["label"])
            self.refill(lid, items)
        if self.focus_id() is None:
            self.focus_soon(self.fallback())

    def load(self, refocus=True):
        try:
            self._load(refocus)
        except RuntimeError:
            if not self.stop:
                raise
            # sección cerrada mientras cargaba: Kodi ya destruyó la ventana (antes: traceback en el log, PY-10)

    def _load(self, refocus=True):
        """1) lo guardado al momento, aunque esté caducado; 2) Palantir solo para lo caducado o sin caché, por detrás,
        en orden, sin mover la selección (auditoría REND-02: antes ~40 s con la caché caducada).
        refocus=False: repintado tras el menú KER0N3 (el foco se queda en la carátula)"""
        t0 = getattr(self, "t0", None) or time.time()      # recargas (reintentar, tras el menú): desde que empiezan
        self.t0 = None
        self.setProperty("fs_empty", "")
        self.setProperty("fs_error", "")
        self.setProperty("fs_status", "cargando…")
        # Favoritos / Listas Trakt con el menú guardado caducado: se pinta ya con él y el de Palantir se pide después
        # de las filas (abajo); antes se esperaba ~11 s en «Cargando Favoritos…» con las filas en la caché (APA-01)
        recheck = flix_rows.live_stale(self.var)
        # ¿Palantir no contesta o no hay nada? (TV-12: antes las dos cosas salían como «Sin contenido»)
        failed, answered = False, False
        flix_common.dir_failed(reset=True)
        if not self.hold_palantir():        # sin lo guardado, el menú se pide a Palantir
            return
        try:
            if getattr(self, "fixed", None):
                rows = list(self.fixed)
            else:
                rows = flix_sections_conf.apply_rows(flix_rows.section_rows(self.var, stale_ok=True, live_later=True),
                                                     self.rconf)
        except Exception as e:  # noqa: BLE001  (antes el hilo moría y la sección se quedaba en «Cargando…»)
            log("menú de %s: %s" % (self.title, e))
            rows, failed = [], True
        finally:
            self.in_flight = False
        failed = flix_common.dir_failed(reset=True) or failed
        # todas las filas cogen su hueco ya, en su orden y con «Cargando…»: se puede bajar sin esperar a Palantir
        # (antes cada fila cogía hueco al llegar: no había adónde bajar y salían en orden de llegada)
        for row in rows[:NROWS]:
            if self.stop:
                return
            self.place(row)
        if rows and not self.stop and refocus:
            self.focus_soon(FIRST)
        pending = []
        for row in rows:
            if self.stop:
                return
            files, fresh = flix_rows.peek(row["path"])
            if files:
                self.paint(row, files, "caché" if fresh else "caché antigua")
            if not fresh:
                pending.append(row)
        # menú caducado: primero las filas del guardado y después el menú (~10 s de Palantir en la Shield); antes, al
        # revés, y sin filas guardadas la 1.ª salía a los 14 s (Carlos, 30-oct). Lo que cambie se recoloca al final
        failed, answered = self.fetch_rows(pending, failed, answered)
        if recheck and not self.stop:
            failed, answered = self.fetch_rows(self.recheck_menu(rows, []), failed, answered)
        flix_rows.flush()
        self.setProperty("fs_status", "")
        self.loaded = True
        if self.stop:
            return
        for lid, files in self.shown.items():
            if files is None:                       # Palantir no dio nada para esta fila
                self.refill(lid, [placeholder(MISSING)])
        if not any(self.shown.values()):
            # botón 5490 (FlixState): «Palantir no responde» si nada contestó, si no «Sin contenido»; OK = reintentar.
            # Con filas colocadas (todas «No disponible») la reserva está oculta: a la 1.ª fila (fallback)
            self.setProperty("fs_error", "1" if failed and not answered else "")
            self.setProperty("fs_empty", "1")
            self.focus_soon(self.fallback())
            log("sección %s sin filas%s" % (self.title, " (Palantir no responde)" if failed and not answered else ""))
        log("%s: lista en %.1f s" % (self.title, time.time() - t0))     # fin de C5 sin depuración (DAT-22)

    def fetch_rows(self, pending, failed, answered):
        """pide a Palantir las filas de pending, en orden, y las pinta; devuelve (failed, answered) al día"""
        for k, row in enumerate(pending):
            if self.stop or not self.hold_palantir():
                break
            try:
                files, _ = flix_rows.fetch(row["path"], force=True, save=False)
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row["label"], e))
                failed = True
                continue
            finally:
                self.in_flight = False
            if flix_common.dir_failed(reset=True):
                failed = True
            else:
                answered = True
            if files and not self.stop:
                self.paint(row, files, "Palantir")
            if k % 4 == 3:
                flix_rows.flush(keep=True)      # vienen más: sin releer el fichero si nadie lo ha tocado (DAT-02)
        return failed, answered

    def hold_palantir(self):
        """antes de pedir a Palantir desde el hilo de carga: si la vista previa del menú está pidiendo, se espera sin
        pedir (Palantir atiende de una en una) y se marca in_flight para que ella no pida a la vez, como
        flix_inicio.worker. Quien pide quita la marca al acabar (finally). False: la sección se cerró esperando"""
        pv = getattr(self, "preview", None)
        while not getattr(self, "stop", False):
            if pv is None or not pv.busy():
                self.in_flight = True       # se avisa antes de mirar otra vez (la vista previa, igual): nunca los dos
                if pv is None or not pv.busy():
                    return True
                self.in_flight = False      # se adelantó la vista previa: a esperar
            self.wake.wait(1)
            self.wake.clear()
        return False

    # ---------- vigilancia: vista previa del menú lateral (como flix_inicio.InicioWindow.watch / tick) ----------
    def watch(self):
        # al cerrarse Kodi se para en menos de 1 s (System.OnQuit, flix_common.quit_monitor: a los RunScript sin addon
        # Kodi no les avisa por abortRequested; antes esperaba 5 s y lo mataba con traceback, revisión 7-nov PY-01)
        mon = flix_common.quit_monitor()
        last = None                         # un fallo que se repite, una sola línea (como el Inicio)
        while not self.stop and not flix_common.wait_quit(mon, TICK):
            try:
                self.tick()
                last = None
            except Exception as e:  # noqa: BLE001
                msg = "vigilancia: %s" % e
                if msg != last and not self.stop:
                    log(msg)
                last = msg
        if flix_common.quitting(mon) and not self.stop:
            self.on_quit()

    def on_quit(self):
        """Kodi se cierra: la carga deja de esperar (wake) y la ventana se cierra para que doModal vuelva y el script
        acabe solo, sin que Kodi tenga que matarlo"""
        self.stop = True
        self.wake.set()
        try:
            self.close()
        except RuntimeError:                        # ventana ya destruida
            pass

    def tick(self):
        """sin el ajuste (o en modo ligero), fuera lo pintado; tapada (ficha, aviso, vídeo, otra ventana), que no pida
        más (Palantir, libre); delante, su vuelta"""
        if self.stop:
            return
        try:                                        # llegaron edades de TMDB: a las carátulas ya pintadas, sin repintar
            import flix_age
            rev = HOME.getProperty(flix_age.REV)
            if rev != getattr(self, "age_rev", ""):
                self.age_rev = rev
                for items in list(self.items_of().values()):
                    flix_age.apply(items)
        except Exception:  # noqa: BLE001
            pass
        pending, self.refocus = getattr(self, "refocus", None), None
        if pending is not None and self.focus_id() is None:
            self.setFocusId(pending)            # una sola vez más: ya pasó el fotograma en que la fila estaba oculta
        if flix_reload.reloading(HOME):
            # «Recargar skin»: la ventana se cierra antes de que Kodi la destruya con el skin viejo (flix_reload)
            self.stop = True
            self.close()
            return
        if not flix_menu_preview.enabled():
            self.preview.leave(hide=True)
        elif self.covered():
            self.preview.leave()
        else:
            self.preview.tick(time.time())

    def active(self):
        """¿la sección está delante? Solo entonces la vista previa toca sus listas (5191/5192) y pide; cerrándose, no"""
        wid = getattr(self, "wid", "")
        return bool(wid) and not self.stop and str(xbmcgui.getCurrentWindowId()) == wid

    def covered(self):
        # HasActiveModalDialog: HasModalDialog no cuenta las fichas y avisos de Python (como el Inicio)
        return not self.active() or xbmc.getCondVisibility("System.HasActiveModalDialog | Player.HasMedia")

    def recheck_menu(self, rows, pending):
        """pide a Palantir el menú de la sección (estaba guardado y caducado: las cuentas y qué categorías tienen algo
        cambian) y, si cambió, recoloca las filas (relayout). Devuelve las filas que quedan por pedir"""
        if not self.hold_palantir():
            return pending
        try:
            new = flix_sections_conf.apply_rows(flix_rows.section_rows(self.var, force=True), self.rconf)
        except Exception as e:  # noqa: BLE001
            log("menú de %s: %s" % (self.title, e))
            return pending
        finally:
            self.in_flight = False
        if self.stop or not new:
            return pending              # Palantir no dio nada: se queda lo guardado
        if [(r["label"], r["path"]) for r in new[:NROWS]] == [(r["label"], r["path"]) for r in rows[:NROWS]]:
            return pending
        log("menú de %s cambiado: %s -> %s" % (self.title, [r["label"] for r in rows], [r["label"] for r in new]))
        changed = self.relayout(new)
        keep = {r["path"] for r in new}
        pending = [r for r in pending if r["path"] in keep and r not in changed]
        for row in changed:             # filas nuevas (o con otra ruta): lo guardado al momento, Palantir después
            files, fresh = flix_rows.peek(row["path"])
            if files:
                self.paint(row, files, "caché" if fresh else "caché antigua")
            if not fresh:
                pending.append(row)
        order = {r["path"]: k for k, r in enumerate(new)}
        return sorted(pending, key=lambda r: order.get(r["path"], 0))

    def relayout(self, rows):
        """recoloca las filas con el menú nuevo, en su orden. Las que siguen (misma etiqueta) conservan lo pintado y
        el foco (Kodi no puede mover una lista: si cambia de hueco se vuelve a pintar en el suyo); las nuevas salen con
        «Cargando…»; los huecos que sobran se vacían (fila oculta). Devuelve las filas nuevas o con otra ruta"""
        focus = self.focus_id()
        old_rows, old_items = dict(self.rows), dict(self.items_of())
        old = {r["label"]: (lid, r) for lid, r in old_rows.items()}
        shown = {r["label"]: self.shown.get(lid) for lid, r in old_rows.items()}
        flabel = old_rows[focus]["label"] if focus in old_rows else None
        fpos = self.sel_pos(focus) if flabel is not None else 0
        self.rows, self.slot_of, self.shown = {}, {}, {}
        self.items_of().clear()
        changed = []
        for k, row in enumerate(rows[:NROWS]):
            lid = FIRST + k
            prev = old.get(row["label"])
            self.rows[lid], self.slot_of[row["path"]] = row, lid
            self.setProperty("fs_row%d" % (k + 1), row.get("title") or row["label"])
            if prev is None or prev[1]["path"] != row["path"]:
                changed.append(row)
            files = shown.get(row["label"]) if prev is not None else None
            self.shown[lid] = files
            if prev is not None and prev[0] == lid and prev[1]["path"] == row["path"]:
                self.items_of()[lid] = old_items.get(lid, [])       # misma fila en su sitio: no se toca
                continue
            items = [make_item(f, row) for f in files] if files else [placeholder(LOADING)]
            self.refill(lid, items, fpos if row["label"] == flabel else 0)
        for k in range(len(rows[:NROWS]), len(old_rows)):
            lid = FIRST + k                 # hueco que sobra: vacío (la fila se oculta); el foco se pone abajo
            self.setProperty("fs_row%d" % (k + 1), "")
            self.getControl(lid).reset()
        if focus is not None and focus in old_rows:
            to = next((lid for lid, r in self.rows.items() if r["label"] == flabel), None)
            self.setFocusId(to or (FIRST if self.rows else RETRY))
        return changed

    def place(self, row):
        """hueco de una fila antes de que lleguen sus títulos (al reintentar, vuelve a «Cargando…»)"""
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            lid = FIRST + len(self.slot_of)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = None
            self.setProperty("fs_row%d" % (lid - FIRST + 1), row.get("title") or row["label"])
        elif self.shown.get(lid) is not None:
            return
        self.refill(lid, [placeholder(LOADING)])

    def focus_id(self):
        try:
            return self.getFocusId() or None
        except RuntimeError:                        # ningún control de la ventana tiene el foco
            return None

    def refill(self, lid, items, pos=0):
        """vacía y rellena una fila. Kodi suelta el foco de una lista vacía: si la fila lo tenía (o nadie lo tiene y
        es la 1.ª) se le devuelve. Sin esto la 1.ª entrada a una sección se quedaba sin responder al mando hasta salir
        y volver (Carlos, 22-oct; desde la 1.5.38: la 1.ª fila coge el foco con «Cargando…» y luego se rellena)"""
        focus = self.focus_id()
        lst = self.getControl(lid)
        lst.reset()
        lst.addItems(items)
        self.items_of()[lid] = list(items)
        if pos > 0:
            lst.selectItem(min(pos, len(items) - 1))
        if focus == lid or (lid == FIRST and focus in (None, RETRY)):
            self.focus_soon(lid)

    def paint(self, row, files, origin):
        """show() desde el hilo de carga: una fila que falle al pintarse se apunta en el log y se sigue con las demás
        (antes la excepción mataba el hilo en silencio y la sección se quedaba en «Cargando…», revisión 7-nov PY-10).
        RuntimeError sigue subiendo: es Kodi destruyendo la ventana (load lo trata)"""
        try:
            self.show(row, files, origin)
        except RuntimeError:
            raise
        except Exception as e:  # noqa: BLE001
            log("fila %s: no se pudo pintar (%s: %s)" % (row.get("label"), type(e).__name__, e))

    def show(self, row, files, origin):
        """pinta una fila: su hueco ya está (place); solo si cambió, conservando la selección"""
        if files and flix_rows.follow_tmdb(files[0]):
            import flix_progress
            files = flix_progress.ordered_follow(files)     # Series en seguimiento: por lo visto de verdad
        if row.get("skip"):
            # «Ver más» de Series en seguimiento del Inicio (open_more con skip): la misma lista sin las que ya enseña
            # la fila ni su «más…» (el del widget de Palantir lleva a la lista entera desde el principio)
            skip = set(row["skip"])
            files = [f for f in files if flix_rows.follow_tmdb(f) not in skip and not flix_rows.is_more(f)]
        files = flix_rows.head(files, ROW_LIMIT)
        try:                                        # edad de TMDB en segundo plano, solo las que falten (flix_age)
            import flix_age
            flix_age.want(files)
        except Exception:  # noqa: BLE001
            pass
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            lid = FIRST + len(self.slot_of)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = files
            self.setProperty("fs_row%d" % (lid - FIRST + 1), row.get("title") or row["label"])
            items = [make_item(f, row) for f in files]
            flix_newep.paint(items, files, lambda: self.items_of().get(lid))     # Series en seguimiento
            self.getControl(lid).addItems(items)
            self.items_of()[lid] = items
            if lid == FIRST:
                self.focus_soon(lid)
        else:
            if flix_cache.same_items(self.shown.get(lid), files):
                flix_newep.update(self.items_of().get(lid))
                flix_newep.recheck(self.items_of().get(lid), lambda: self.items_of().get(lid))   # caducó algo: refresco
                return
            self.shown[lid] = files
            items = [make_item(f, row) for f in files]
            flix_newep.paint(items, files, lambda: self.items_of().get(lid))
            self.refill(lid, items, self.sel_pos(lid))
        log("fila %s [%s]: %d (%s)" % (row["label"], row["kind"], len(files), origin))

    def items_of(self):
        if not hasattr(self, "items"):
            self.items = {}             # id de lista -> ListItems pintados (los nuestros)
        return self.items

    def sel_pos(self, lid):
        """posición seleccionada preguntando a Kodi: ControlList.getSelectedPosition/getSelectedItem usan la lista
        de antes de recargar la skin (actualización automática con la sección abierta) y Kodi se caía (SIGSEGV)"""
        try:
            return max(0, int(xbmc.getInfoLabel("Container(%d).CurrentItem" % lid) or 0) - 1)
        except ValueError:
            return 0

    def onAction(self, action):
        if action.getId() in A_BACK and getattr(self, "fixed", None):
            self.stop = True                    # «Ver similares»: no es una sección del menú lateral, Atrás vuelve
            cover = getattr(self, "back_cover", "")
            if cover:
                # «Títulos de X»: el fondo de la ficha tapa ya, antes de cerrar; puesto después (back_with_cover), en el
                # fundido de cierre asomaba el Inicio con su menú lateral (Shield, Carlos 1-nov)
                HOME.setProperty(flix_common.INFO_COVER, cover)
            self.close()
            return
        if action.getId() in A_BACK:
            # Atrás como en el Inicio (Carlos, 31-oct): lo hace cada control (<onback>: filas y reserva -> menú ->
            # lupa -> menú de apagar) y nunca cierra la sección; a Kodi no pasa (el onAction de serie de WindowXML la
            # cerraría). Cuando llega aquí el XML ya movió el foco: si está en el menú es que venía de las filas o de la
            # reserva, y el cursor va a esta sección (pudo bajarse a las filas desde la lupa con el menú en «Inicio»)
            if self.focus_id() == MENU:
                self.mark_menu()
            else:
                self.restore_focus()            # foco perdido: como con cualquier otra tecla
            return
        if (action.getId() in A_OK + A_RIGHT and self.focus_id() == MENU and not self.stop
                and xbmc.getInfoLabel("Container(%d).CurrentItem" % MENU) == "1"):
            # «Inicio» con OK, clic o derecha (en el XML, noop): se cierra la sección y el Inicio vuelve a sus filas
            # (flix_inicio.InicioWindow.onInit), no al menú abierto en esta sección con su vista previa (Carlos, 31-oct)
            HOME.setProperty("flix_go_home", "1")
            self.stop = True
            self.close()
            return
        if action.getId() in A_CONTEXT and self.focus_id() in self.rows:
            if HOME.getProperty("flix_ctx_auto"):
                super().onAction(action)        # flix_menu abriendo por detrás el menú de Kodi (lista oculta FlixCtx)
                return
            self.open_menu(self.focus_id())
            return
        if action.getId() in A_OK and self.focus_id() == MENU and not self.stop:
            key, kind = self.menu_choice()
            if key and kind == "rows":
                if key == getattr(self, "key", ""):
                    self.focus_rows()                   # la misma sección: a sus filas
                else:                                   # otra: esta ventana se cierra y main abre la nueva (sin apilar)
                    self.next = key
                    HOME.setProperty(SWAP, "1")         # el Inicio, tapado mientras asoma entre las dos
                    self.stop = True
                    self.close()
                return
            # las de lista (flix_sections.py,open): lo hace el XML
        self.restore_focus()                        # foco perdido: la tecla no iría a ningún sitio
        super().onAction(action)
        self.restore_focus()                        # y si esta tecla lo perdió (abajo a un grupo sin filas): ya

    def open_menu(self, lid):
        """menú KER0N3 (flix_menu.py) de la carátula con foco. Las filas son listas de Python sin menú de Kodi: como en
        el Inicio, flix_menu pulsa la opción de Palantir desde una lista oculta (FlixCtx) con el listado de la fila"""
        items = self.items_of().get(lid) or []
        pos = self.sel_pos(lid)
        item = items[pos] if pos < len(items) else None
        path = item.getPath() if item else ""
        if not item or item.getProperty("open") in ("", "grid") or not path.startswith("plugin://plugin.video.palantir3/"):
            return                      # «Cargando…», «Ver más», colecciones: sin menú
        HOME.setProperty("flix_ctx_src", flix_rows.directory(self.rows[lid]["path"], offline=True))     # sin red (DAT-16)
        t0 = time.time()
        xbmc.executebuiltin('RunScript(special://skin/scripts/flix_menu.py,"%s","%s","%s",sec)'
                            % (path, item.getArt("poster"), item.getLabel().replace('"', "'")))
        threading.Thread(target=self.after_menu, args=(t0,), daemon=True).start()

    def after_menu(self, t0):
        """cuando flix_menu acaba (flix_menu_done) se repinta lo que cambió (✓…) sin mover el foco. Un favorito
        quitado lo saca la sección de sus filas: Palantir tarda unos segundos en dar sus listados sin él (Shield,
        28-oct: 1 s después aún salía) y volver a pedírselas lo devolvía a la fila"""
        mon, end = flix_common.quit_monitor(), t0 + MENU_WAIT
        while not self.stop and time.time() < end and not flix_common.quitting(mon):
            done = HOME.getProperty("flix_menu_done")
            if done and float(done) > t0:
                break
            if flix_common.wait_quit(mon, 0.5):
                return
        else:
            return
        if self.stop:
            return
        change = HOME.getProperty("flix_fav_change").split("|")
        if len(change) == 3 and change[1] == "del" and float(change[0] or 0) > t0:
            self.drop_title(change[2])
            return
        self.load(refocus=False)

    def drop_title(self, key):
        """saca el título key («content:tmdb») de las filas de FAVORITOS pintadas, sin pedir nada (en Películas o en
        un Top 10 la película sigue estando aunque deje de ser favorita)"""
        for lid, files in list(self.shown.items()):
            if not flix_rows.is_fav_path(self.rows[lid]["path"]):
                continue
            keep = [f for f in files or [] if flix_rows.title_key(f) != key]
            if files and len(keep) != len(files):
                self.shown[lid] = keep
                self.refill(lid, [make_item(f, self.rows[lid]) for f in keep] or [placeholder(MISSING)],
                            self.sel_pos(lid))
                log("fila %s: quitado %s (favorito)" % (self.rows[lid]["label"], key))

    def onClick(self, control_id):
        if control_id == RETRY and self.getProperty("fs_empty") == "1":
            threading.Thread(target=self.load, daemon=True).start()
            return
        if control_id not in self.rows:
            return
        items, pos = self.items_of().get(control_id) or [], self.sel_pos(control_id)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open"):     # «Cargando…» / «No disponible»
            return
        path, how = item.getPath(), item.getProperty("open")
        HOME.setProperty("flix_title", item.getProperty("P3Titulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid" and item.getProperty("more"):
            # «Ver más»: la página siguiente como sección de una fila suelta, con los clics de cualquier fila (ficha
            # con tráiler y «Seguir viendo»); en la cuadrícula de Kodi (ventana Vídeos) una película iba al selector de
            # Palantir y una serie a su carpeta, y Kodi no deja cambiar el clic de sus listas (Carlos, 7-nov)
            row = self.rows.get(control_id) or {}
            open_more(self.title, row.get("label", ""), path, menu=not self.getProperty("fs_nomenu"))
        elif how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.title, item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def open_section(key, t0):
    """abre la sección key y espera a que se cierre; devuelve la clave de la que el usuario eligió en su menú lateral
    ("" = ninguna: se acabó). t0: la pulsación de esta apertura"""
    import flix_sections
    import xbmcvfs
    s = flix_sections.section(key) or flix_sections.section("peliculas")
    log("%s: abierta" % flix_sections_conf.shown(s))     # principio de C5 sin depuración (revisión 29-oct DAT-22)
    HOME.setProperty("flix_section", flix_sections_conf.shown(s))
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                        var=s["src"], title=flix_sections_conf.shown(s), rconf=s.get("rows") or {}, t0=t0,
                        key=s["key"])
    return run_window(win)


# Window(home): «1» desde que una sección se cierra para abrir otra elegida en su menú lateral hasta que main vuelve
# al Inicio. Entre las dos ventanas Kodi enseña el Inicio un instante, con su menú y su vista previa de cuando se salió
# de él: «salta unos segundos la última que has visto» (Carlos, 8-nov). FlixInicio.xml lo tapa de negro
SWAP = "flix_sec_swap"
SIMILAR = "flix_similar"        # Window(home): {"title", "rows"} que deja flix_menu.open_similar para open_rows
MORE_LABEL = "Más títulos"      # cabecera de la fila con la página siguiente de un listado («Ver más»)


def more_rows(title, label, path, menu, skip=None):
    """lo que deja «Ver más» en SIMILAR: la página siguiente (path) como sección de una fila suelta titulada
    «Sección · Fila»; desde una página ya abierta así (fila MORE_LABEL) se conserva el título. menu: menú lateral,
    solo si se veía donde se pulsó (fs_nomenu). skip: tmdb de Series en seguimiento que ya enseñaba la fila (show)"""
    if label and label != MORE_LABEL:
        title = "%s · %s" % (title, label)
    row = {"label": MORE_LABEL, "path": path, "kind": "list"}
    if skip:
        row["skip"] = list(skip)
    return {"title": title, "rows": [row], "menu": bool(menu)}


def open_more(title, label, path, menu=True, skip=None):
    """abre la página siguiente de un listado (tarjeta «Ver más») como open_rows, en otro intérprete (como
    flix_menu.open_similar: esta ventana sigue debajo y Atrás vuelve a ella)"""
    HOME.setProperty(SIMILAR, json.dumps(more_rows(title, label, path, menu, skip)))
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_section.py,similar)")


def open_rows(t0):
    """sección hecha de filas sueltas que dejó flix_menu en Window(home) (SIMILAR): «Ver similares» (Carlos, 31-oct).
    En la cuadrícula de Kodi (ventana Vídeos) una película se reproducía sin ficha y una serie entraba en la carpeta de
    Palantir: aquí los clics son los de cualquier sección. Atrás la cierra. Devuelve como open_section"""
    import xbmcvfs
    try:
        data = json.loads(HOME.getProperty(SIMILAR) or "{}")
    except ValueError:
        data = {}
    HOME.clearProperty(SIMILAR)
    rows = [r for r in data.get("rows") or [] if isinstance(r, dict) and r.get("path")]
    if not rows:
        return ""
    title = data.get("title") or ""
    log("%s: abierta" % title)
    HOME.setProperty("flix_section", title)
    # el menú lateral, solo si se abrió desde donde se veía: el Inicio o una sección con él (data["menu"], de quien la
    # pide; Carlos, 31-oct: «si estoy en búsqueda o en una ficha … si abro algo no debería mostrarlo»)
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                        var="", title=title, rconf={}, t0=t0, key="", rows=rows, nomenu=not data.get("menu", True),
                        back_cover=(data.get("cover") or "") if data.get("back") else "")
    return run_window(win)


def run_window(win):
    """abre la ventana de una sección y espera a que se cierre; devuelve la clave de la que el usuario eligió en su
    menú lateral ("" = ninguna)"""
    win.doModal()
    win.stop = True
    preview = getattr(win, "preview", None)
    if preview is not None:
        preview.leave()                     # lo que estuviera pidiendo para antes de la fila siguiente (Palantir, libre)
    nxt = getattr(win, "next", "")
    del win
    # la cabecera de entrada es de esta ventana: la siguiente, elegida en su menú, solo lleva la suya si ya la pintaba la
    # vista previa de esta o main la pone (de lo guardado); si no, ni se desliza ni enseña una cabecera vieja
    if not nxt or flix_menu_preview.HOME.getProperty("flix_pv_key") != nxt:
        flix_menu_preview.drop("flix_pv_key")
    return nxt


def main():
    try:
        run(sys.argv[1] if len(sys.argv) > 1 else "peliculas")
    finally:
        HOME.clearProperty(SWAP)            # de vuelta al Inicio (o error): que no se quede tapado


def run(key):
    if key == "similar":                # «Ver similares» (flix_menu.open_similar) y «Títulos de X» (flix_info)
        try:
            data = json.loads(HOME.getProperty(SIMILAR) or "{}")
        except ValueError:
            data = {}
        import flix_info
        if data.get("cover"):
            flix_info.uncover_soon()    # el fondo de la ficha tapaba el Inicio hasta verse esta
        key = open_rows(time.time())
        if not key and data.get("back") and not flix_reload.reloading(HOME):
            # Atrás: a la ficha de la que se vino (no si se fue a otra sección ni si se está recargando el skin)
            flix_info.back_with_cover(data["back"], data.get("cover") or "")
    while key:          # cada vuelta, su pulsación: el menú lateral de la sección cambia de sección en este mismo proceso
        key = open_section(key, time.time())
        if key:
            # la siguiente abre con su cabecera de entrada (lo guardado, sin Palantir) y se desliza desde los 230 px del
            # menú abierto de esta: sin ella se veían ~0,5 s de negro y «Cargando…» (Carlos, 31-oct)
            flix_menu_preview.entry_header(key)
    # de vuelta al Inicio, nada de la vista previa queda puesto: la repinta el Inicio (lo apartado con leave lo repinta
    # al volver el foco a la misma sección; con «Inicio» o fuera del menú, nada). Antes se reponía lo de antes de entrar
    # y flix_pv_on podía quedarse sin dueño si el Inicio ya había quitado lo suyo: con el foco en «Inicio», la última
    # sección parpadeaba antes de ir a las filas (Carlos, 31-oct). Solo si nadie las ha tocado desde lo último que
    # escribió esta sección: si el Inicio ya repintó su vista previa, es suya (revisión)
    if flix_menu_preview.still_mine():
        flix_menu_preview.clear()


if __name__ == "__main__":
    main()
