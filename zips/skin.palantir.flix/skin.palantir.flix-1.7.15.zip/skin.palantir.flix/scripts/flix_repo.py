"""Actualizaciones automáticas: al arrancar, deja el aparato enganchado al repositorio Ker0n3 Media.

1. Si falta el addon repository.ker0n3media, lo instala desde la copia que trae el skin
   (resources/repository.ker0n3media) y lo activa.
2. Kodi NO actualiza solo lo que se instaló desde un zip (origen vacío), con ningún ajuste: si el skin no tiene
   origen, se le pone el del repositorio en Addons33.db (efecto al siguiente arranque). Y se le quita la fijación
   que Kodi pone a lo instalado desde un zip (update_rules), que también lo deja sin actualizaciones.
3. Kodi solo revisa los repositorios una vez cada 24 h (no en cada arranque): si la última revisión del repositorio
   Ker0n3 Media tiene más de CHECK_HOURS, se pide a Kodi que los revise ya (UpdateAddonRepos) para que una versión
   nueva llegue en el siguiente arranque (la Shield no se actualizaba tras abrir Kodi 4 veces, 18-oct-2026).
Se ejecuta desde Startup.xml; no hace nada si ya está todo bien.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import datetime
import glob
import re
import shutil
import sqlite3

import xbmc
import xbmcvfs

REPO = "repository.ker0n3media"
CHECK_HOURS = 2
PIN_ZIP = 3         # AddonUpdateRule::PIN_ZIP_INSTALL (xbmc/addons/AddonUpdateRules.h)
SKIN_ID = xbmc.getSkinDir()


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[flix_repo] %s" % msg, level)


# JSON-RPC común (revisión 29-oct DAT-20): la misma petición y ValueError si la respuesta no es JSON, como antes
from flix_common import rpc  # noqa: E402


def addon_version(xml):
    m = re.search(r'<addon[^>]*\bversion="([^"]+)"', xml)
    return m.group(1) if m else ""


def newer(a, b):
    """¿la versión a es mayor que b? (1.0.10 > 1.0.9)"""
    def parts(v):
        return [int(x) for x in re.findall(r"\d+", v)]
    return parts(a) > parts(b)


def _version_in(folder):
    try:
        with open(os.path.join(folder, "addon.xml"), encoding="utf-8") as fh:
            return addon_version(fh.read())
    except OSError:
        return ""


SKINS = ("skin.palantir.flix", "skin.palantir.flix.touch")


def clean_packages(folder, installed):
    """borra de addons/packages los zips de nuestras skins más viejos que la instalada: Kodi los ofrece en la ficha
    del addon («Versiones») y bajar a uno es volver a fallos ya arreglados. installed = {id: versión}. Devuelve
    los nombres borrados."""
    gone = []
    try:
        names = os.listdir(folder)
    except OSError:
        return gone
    for name in names:
        m = re.match(r"^(skin\.palantir\.flix(?:\.touch)?)-([0-9.]+)\.zip$", name)
        if m and m.group(1) in installed and newer(installed[m.group(1)], m.group(2)):
            try:
                os.remove(os.path.join(folder, name))
                gone.append(name)
            except OSError:
                pass
    return gone


def installed_skins():
    out = {}
    for sid in SKINS:
        v = xbmc.getInfoLabel("System.AddonVersion(%s)" % sid)
        if v:
            out[sid] = v
    return out


def copy_tree(src, dst):
    """copia solo el contenido (copyfile): en Android chmod/utime del almacenamiento compartido dan Permission denied
    y copytree (también con copyfile: copystat de las carpetas) abortaba antes de UpdateLocalAddons"""
    for base, dirs, files in os.walk(src):
        out = os.path.join(dst, os.path.relpath(base, src))
        os.makedirs(out, exist_ok=True)
        for name in files:
            shutil.copyfile(os.path.join(base, name), os.path.join(out, name))


def ensure_repo():
    dst = xbmcvfs.translatePath("special://home/addons/%s" % REPO)
    src = xbmcvfs.translatePath("special://skin/resources/%s" % REPO)
    if os.path.isdir(dst) and os.path.isdir(src):
        have, bundled = _version_in(dst), _version_in(src)
        if have and bundled and newer(bundled, have):
            # repo nuevo dentro de la skin (p. ej. 1.0.5: directo a GitHub sin el Worker bloqueado): se sustituye aquí,
            # sin depender de poder leer el repo viejo
            shutil.rmtree(dst)
            copy_tree(src, dst)
            xbmc.executebuiltin("UpdateLocalAddons")
            log("repositorio %s -> %s (copia de la skin)" % (have, bundled))
            return enable_repo(tries=6)
    if os.path.isdir(dst):
        det = rpc("Addons.GetAddonDetails", {"addonid": REPO, "properties": ["enabled"]})
        if (det.get("result") or {}).get("addon", {}).get("enabled") is False:
            return enable_repo(tries=3)          # copiado en un arranque anterior pero sin llegar a activarse
        return False
    if not os.path.isdir(src):
        return False
    copy_tree(src, dst)
    xbmc.executebuiltin("UpdateLocalAddons")
    return enable_repo()


def enable_repo(tries=20, wait_ms=500):
    """Kodi tarda en registrar el addon copiado: reintenta la activación y dice si de verdad quedó activo (PY-15)"""
    for _ in range(tries):
        if wait_ms:
            xbmc.sleep(wait_ms)
        if rpc("Addons.SetAddonEnabled", {"addonid": REPO, "enabled": True}).get("result") == "OK":
            log("repositorio instalado y activado")
            return True
    log("repositorio copiado pero no se pudo activar (se reintentará en el próximo arranque)", xbmc.LOGWARNING)
    return False


def ensure_origin():
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath("special://database/"), "Addons*.db")))
    if not dbs:
        return
    con = sqlite3.connect(dbs[-1], timeout=5)
    try:
        cur = con.execute("SELECT origin FROM installed WHERE addonID=?", (SKIN_ID,)).fetchone()
        if cur is not None and not cur[0]:
            con.execute("UPDATE installed SET origin=? WHERE addonID=?", (REPO, SKIN_ID))
            con.commit()
            log("%s enganchado al repositorio (antes: instalado desde zip)" % SKIN_ID)
        # con el origen puesto tampoco se actualizaba: Kodi FIJA lo instalado desde un zip (update_rules, regla
        # PIN_ZIP = 3; en la ficha, «Auto actualizar» apagado) y no lo toca más (móvil de Carlos, 10-nov: táctil en 1.3.7
        # con la 1.3.11 publicada). Solo esa regla y solo de esta skin: la 1 (apagado a mano) y la 2 (versión elegida)
        # son decisiones del usuario. Kodi lee las reglas al arrancar: efecto al siguiente arranque
        try:
            gone = con.execute("DELETE FROM update_rules WHERE addonID=? AND updateRule=?", (SKIN_ID, PIN_ZIP)).rowcount
        except sqlite3.OperationalError:        # base sin esa tabla
            gone = 0
        if gone:
            con.commit()
            log("%s: quitada la fijación por instalarse desde zip (vuelve a actualizarse sola)" % SKIN_ID)
    finally:
        con.close()


def addons_db():
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath("special://database/"), "Addons*.db")))
    return dbs[-1] if dbs else None


def maybe_check():
    db = addons_db()
    if not db:
        return
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=5)     # solo lee (revisión 29-oct DAT-12)
    try:
        row = con.execute("SELECT lastcheck FROM repo WHERE addonID=?", (REPO,)).fetchone()
    finally:
        con.close()
    if row and row[0]:
        try:
            last = datetime.datetime.strptime(row[0][:19], "%Y-%m-%d %H:%M:%S")
            if datetime.datetime.now() - last < datetime.timedelta(hours=CHECK_HOURS):
                return
        except ValueError:
            pass
    xbmc.executebuiltin("UpdateAddonRepos")
    log("revisión de repositorios pedida (última: %s)" % (row[0] if row else "nunca"))


def main():
    import first_run
    if not first_run.once("repositorio"):
        return              # ya lo lanzó first_run (o el Startup táctil): una vez por sesión
    try:
        ensure_repo()
        ensure_origin()
        gone = clean_packages(xbmcvfs.translatePath("special://home/addons/packages"), installed_skins())
        if gone:
            log("paquetes viejos borrados: %s" % ", ".join(sorted(gone)))
        maybe_check()
    except Exception as e:  # noqa: BLE001
        log("error: %s" % e, xbmc.LOGWARNING)


if __name__ == "__main__":
    main()
