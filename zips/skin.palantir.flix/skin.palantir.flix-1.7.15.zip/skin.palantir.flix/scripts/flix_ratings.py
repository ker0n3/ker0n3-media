"""Nota de cada título (Metacritic, IMDb, Rotten Tomatoes o Letterboxd) en lugar de la ★ de TMDB, vía MDBList con la
clave PROPIA de cada aparato. Carlos (21-oct): lista ordenable con interruptor por fuente (Ajustes → Nota de los
títulos); por título se enseña la 1.ª fuente encendida que tenga nota. TMDB (la ★ que da Palantir) la tienen todos y no
se puede apagar: las fuentes que queden debajo no se llegan a usar.

Carlos (20-oct): «el que no tenga API puesta sigue viendo lo de ahora». Sin clave (Skin.String flix_mdblist_key) o
con TMDB la 1.ª encendida (Skin.String flix_rating_order) este script ni arranca el bucle: las etiquetas usan la ★ que
da Palantir (variables FlixRating* de Includes_Flix.xml caen a ListItem.Rating).

Con clave y alguna fuente antes de TMDB, un bucle mira lo enfocado (lo lanza first_run.py si hay clave, y el editor de
notas al poner una; late en Window(home) flix_ratings y ensure_running() no lo dobla; sin clave NOKEY_EXIT s, sale):
  ranura li  ListItem.FolderPath                        (filas del Inicio TV, secciones, listados, táctil)
  ranura c5  Container(5000).ListItem.FolderPath        (cabecera del Inicio táctil antiguo / listas)
  ranura fz  Window(home).Property(fhz_path)            (cabecera congelada del Inicio TV al subir al menú)
y deja en Window(home) flix_rt_<ranura> = «Metacritic 82» / «IMDb 8.4» y flix_rt_<ranura>_path = la ruta a la que corresponde
(el XML solo la usa si coincide con la del elemento: nunca enseña la nota de otro título). Sin nota de esas fuentes
para el título -> vacío -> la ★ de TMDB, como siempre. Además precarga en segundo plano los primeros títulos de cada
fila (prefetch): así casi nunca se ve el cambio de la ★ a la nota.

Siguientes de la fila: con el foco asentado DWELL s, se piden también las notas de los NEIGHBOURS títulos que siguen (mismas
reglas que todo: caché, TTL, «sin nota», cuota), de una en una, detrás del título enfocado y de la precarga, con tope de
NEIGHBOUR_DAY_MAX al día (se cuenta en ratings3.json, clave "nb") para no gastar las 1000 consultas gratis.

Sin cambio visible de la ★ a la nota (Carlos): mientras el bucle está en marcha pone Window(home) flix_rt_on y el XML ya no
enseña la ★ de una ruta que el script no ha resuelto. Cada ranura recibe su ruta resuelta (flix_rt_<ranura>_path) con la nota
(en caché: en la 1.ª vuelta), o con la nota vacía -> la ★ cuando no hay nota, cuando la cuota está parada (429 / LOW), no es un
título, o pasan NOTE_WAIT s desde el foco sin respuesta. Mientras tanto, en blanco. flix_rt_on se borra al arrancar, al
cambiar los ajustes a «sin clave / TMDB la primera» y al salir del bucle (finally): sin el script, la ★ de siempre.

API: GET https://api.mdblist.com/tmdb/{movie|show}/{tmdb}?apikey=… (1000 consultas/día con clave gratuita). Se pide
solo lo que se queda enfocado DWELL s, en un hilo; caché por aparato (ratings3.json) 7 días, «sin nota» 1 día; con
429 o pocas consultas restantes se deja de pedir hasta el reinicio del contador. La caché guarda TODAS las fuentes de
cada título: cambiar el orden no vuelve a pedir nada. La clave no sale nunca en el log.

Guardado por aparato en los ajustes del skin:
  Skin.String(flix_mdblist_key)      clave («-» = sin clave)
  Skin.String(flix_rating_order)     "metacritic|imdb|tmdb|-tomatoes|-letterboxd" (orden; "-" = apagada; sin comas:
                                     Skin.SetString corta el valor en la primera coma)
  Skin.String(flix_rating_summary)   resumen para la pantalla de Ajustes ("Metacritic → IMDb → TMDB")
  Skin.String(flix_rating_src)       el de antes (tmdb / mdb / letterboxd / metacritic): solo para migrar
Uso: RunScript(special://skin/scripts/flix_ratings.py)            bucle (first_run)
     RunScript(special://skin/scripts/flix_ratings.py,settings)   editor único (flix_editor.py,ratings)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import ast
import json
import re
import threading
import time

from flix_common import decode_route, quit_monitor, quit_sleep, quitting, wait_quit  # noqa: E402

API = "https://api.mdblist.com/tmdb/%s/%s?apikey=%s"
TMDB = "tmdb"                           # la ★ de Palantir (ListItem.Rating): no viene de MDBList
# fuente de MDBList ("source" de su lista "ratings") -> (nombre, formato). Letterboxd 0-5; Rotten Tomatoes y Metacritic 0-100
SOURCES = {"metacritic": ("Metacritic", "%d"), "imdb": ("IMDb", "%.1f"), "tomatoes": ("Rotten Tomatoes", "%d%%"),
           "letterboxd": ("Letterboxd", "%.1f")}
KEYS = ("metacritic", "imdb", TMDB, "tomatoes", "letterboxd")
LABEL = {k: (SOURCES[k][0] if k in SOURCES else "TMDB") for k in KEYS}
DEFAULT = [("metacritic", True), ("imdb", True), (TMDB, True), ("tomatoes", False), ("letterboxd", False)]
TMDB_ONLY = [(k, k == TMDB) for k, _ in DEFAULT]
KEY_RE = r"[A-Za-z0-9]{8,64}"
KIND = {"movies": "movie", "movie": "movie", "tvshows": "show", "tvshow": "show", "seasons": "show",
        "episodes": "show"}
TTL = 7 * 86400         # nota guardada
NEG_TTL = 86400         # «MDBList no tiene nota»: se vuelve a mirar al día siguiente
ERR_TTL = 600           # error de red: no insistir en 10 min
MAX_ENTRIES = 4000
LOW = 25                # consultas restantes por debajo de las cuales se para hasta el reinicio del contador
DWELL = 0.6             # s enfocado antes de pedir (no gastar consultas al pasar de largo)
NOTE_WAIT = 1.0         # s desde el foco: si la nota no ha llegado, se enseña la ★ (antes: ni una ni otra)
STEP = 0.25             # vuelta del bucle en reposo (revisión 7-nov PY-06: antes 0,1 toda la sesión)
STEP_FOCUS = 0.1        # los FOCUS_FAST s que siguen a un cambio de foco: un título en caché sale en blanco como mucho STEP_FOCUS s
FOCUS_FAST = 2.0
STEP_VIDEO = 0.5        # con un vídeo en marcha: el bucle compite con el decodificador (Shield / Fire TV)
NOKEY_EXIT = 3.0        # s sin clave antes de salir (no al momento: Skin.SetString es asíncrono y la recién puesta tarda en leerse)
ALIVE = "flix_ratings"  # Window(home): hora del último latido del bucle (first_run / save_settings lo lanzan si no late)
ALIVE_EVERY = 5
ALIVE_MAX = 30
CFG_EVERY = 0.5         # s entre lecturas de los ajustes (clave y orden): no hace falta mirarlos en cada vuelta
TIMEOUT = 8
NEIGHBOURS = 3          # títulos que siguen al enfocado de cada fila, para pedir su nota por adelantado
NEIGHBOUR_DAY_MAX = 400  # consultas al día para ellos (MDBList gratis: 1000; el resto, para lo que se mira y la precarga)
NEIGHBOUR_SAVE = 10     # notas de siguientes sin guardar que fuerzan guardar ratings3.json
NEIGHBOUR_SAVE_AGE = 20  # s: y lo más que se queda una sin guardar (el SD no se escribe por cada una)
NEIGHBOUR_WAIT_MAX = 20  # s esperando al enfocado o a la precarga: pasado esto, se sueltan los siguientes
NEIGHBOUR_RECHECK = 0.2
ON = "flix_rt_on"       # Window(home): el bucle está en marcha con nota -> el XML no enseña la ★ de una ruta sin resolver


def mask(key):
    return "••••" + key[-4:] if key else "Sin poner"


def parse_order(text):
    """'metacritic|-imdb|tmdb|…' -> [(fuente, encendida)] con todas (las que falten, al final y apagadas); TMDB
    siempre encendida (es la última red: la tienen todos los títulos)"""
    out, seen = [], set()
    for part in (text or "").replace(",", "|").split("|"):
        part = part.strip().lower()
        k = part.lstrip("-")
        if k in LABEL and k not in seen:
            out.append((k, k == TMDB or not part.startswith("-")))
            seen.add(k)
    if TMDB not in seen:
        return list(DEFAULT)
    return out + [(k, False) for k in KEYS if k not in seen]


def dump_order(order):
    return "|".join(("" if on else "-") + k for k, on in order)


def legacy_order(src, key):
    """orden equivalente al ajuste de antes (Skin.String flix_rating_src): «tmdb» con clave puesta = solo TMDB; el
    resto (mdb, letterboxd, metacritic, o sin clave: se veía TMDB porque no había clave) = el orden de serie"""
    src = (src or "").strip().lower()
    return list(TMDB_ONLY) if key and src in ("", TMDB) else list(DEFAULT)


def chain(order):
    """fuentes de MDBList que se miran, en orden: las encendidas antes de TMDB. () = la ★ de TMDB de siempre"""
    out = []
    for k, on in order:
        if k == TMDB:
            break
        if on:
            out.append(k)
    return tuple(out)


def summary(order, key):
    """«Metacritic → IMDb → TMDB» (lo que se mira de verdad) o «TMDB (sin clave de MDBList)»"""
    if not key:
        return "TMDB (sin clave de MDBList)"
    return " → ".join([LABEL[k] for k in chain(order)] + ["TMDB"])


def target(path):
    """('movie'|'show', tmdb) de una ruta de Palantir; None si no es un título"""
    if not path or "palantir3" not in path or "?" not in path:
        return None
    try:
        info = ast.literal_eval(decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(info, dict):
        return None
    tmdb = str(info.get("tmdb") or "")
    kind = KIND.get(info.get("content") or "")
    if not kind or not tmdb.isdigit() or tmdb == "0":
        return None
    return kind, tmdb


def parse(data):
    """{'metacritic': 44.0, 'imdb': 6.1, 'tomatoes': 36.0, 'letterboxd': 2.9} con TODAS las fuentes que tienen valor
    (la caché las guarda todas: cambiar el orden no pide nada)"""
    out = {}
    for r in (data or {}).get("ratings") or []:
        src = r.get("source")
        if src in SOURCES and isinstance(r.get("value"), (int, float)) and r["value"] > 0:
            out[src] = float(r["value"])
    return out


def slot_state(t, cached, since, now, quota_ok):
    """qué enseña una ranura para el título t (target() de su ruta) enfocado desde since:
      "note"  está en caché (con nota o sin ella): se publica ya, sin esperar
      "wait"  pendiente y aún dentro de NOTE_WAIT: ni ★ ni nota (el XML lo pinta en blanco)
      "star"  no es un título, la cuota está parada (429 / LOW) o pasó NOTE_WAIT: la ★ de TMDB"""
    if t is None:
        return "star"
    if cached:
        return "note"
    if not quota_ok or now - since >= NOTE_WAIT:
        return "star"
    return "wait"


def neighbour_picks(paths, skip):
    """títulos a pedir de las rutas de los siguientes (en orden de fila): solo los NEIGHBOURS primeros, sin lo que no es un
    título, sin repetidos y sin lo que skip(t) diga (en caché, ya en vuelo, el enfocado)"""
    out = []
    for p in list(paths)[:NEIGHBOURS]:
        t = target(p)
        if t and t not in out and not skip(t):
            out.append(t)
    return out


def neighbour_left(used):
    """consultas de siguientes que quedan hoy"""
    return max(0, NEIGHBOUR_DAY_MAX - used)


def neighbour_turn(quota_ok, left, busy):
    """«go» pide el siguiente, «wait» espera (el enfocado y la precarga van primero: hay una petición en marcha), «stop»
    deja la cola (429 / LOW, o tope del día)"""
    if not quota_ok or left <= 0:
        return "stop"
    return "wait" if busy else "go"


def neighbour_save_due(unsaved, since, now):
    """¿toca guardar ratings3.json por las notas de siguientes sin guardar? (unsaved desde since)"""
    return unsaved >= NEIGHBOUR_SAVE or (unsaved > 0 and now - since >= NEIGHBOUR_SAVE_AGE)


def fmt(srcs, vals):
    """«Metacritic 44» o, sin ella, la siguiente de srcs (chain()) que tenga nota; '' si ninguna (-> la ★ de TMDB)"""
    for k in srcs or ():
        if k in SOURCES and (vals or {}).get(k) is not None:
            name, f = SOURCES[k]
            return "%s %s" % (name, f % vals[k])
    return ""


def parts(srcs, vals):
    """(fuente, valor) de la nota que enseña fmt: ('metacritic', '44') / ('imdb', '6.1'); ('', '') si ninguna. Para
    pintar el icono de la fuente en vez de su nombre (cabecera del Inicio TV; Carlos, 11-nov)"""
    for k in srcs or ():
        if k in SOURCES and (vals or {}).get(k) is not None:
            return k, SOURCES[k][1] % vals[k]
    return "", ""


class RateLimited(Exception):
    def __init__(self, until):
        Exception.__init__(self, "límite de MDBList")
        self.until = until


def fetch(kind, tmdb, key, opener=None, now=time.time):
    """notas de MDBList ({} si no tiene ninguna de las nuestras). RateLimited si hay que parar."""
    # aquí y no arriba: la ficha importa este módulo al abrirse y urllib.request costaba ~135 ms en la Shield
    import urllib.error
    import urllib.request
    opener = opener or urllib.request.urlopen
    req = urllib.request.Request(API % (kind, tmdb, key), headers={"User-Agent": "Ker0n3Media-skin"})
    try:
        with opener(req, timeout=TIMEOUT) as r:
            body, headers = r.read(), r.headers
    except urllib.error.HTTPError as e:
        if e.code == 429:
            raise RateLimited(_reset(e.headers, now)) from None
        if e.code == 404:
            return {}
        raise
    vals = parse(json.loads(body.decode("utf-8", "replace") or "{}"))
    try:
        remaining = int((headers or {}).get("x-ratelimit-remaining", "") or -1)
    except ValueError:
        remaining = -1
    if 0 <= remaining < LOW:
        raise _Partial(vals, _reset(headers, now))
    return vals


class _Partial(RateLimited):
    """quedan pocas consultas: se usa esta nota pero se para después"""
    def __init__(self, vals, until):
        RateLimited.__init__(self, until)
        self.vals = vals


def _reset(headers, now):
    try:
        until = float((headers or {}).get("x-ratelimit-reset", "") or 0)
    except ValueError:
        until = 0
    t = now()
    return until if t < until < t + 2 * 86400 else t + 6 * 3600


def _file_sig(path):
    try:
        st = os.stat(path)
    except OSError:
        return None
    return st.st_ino, st.st_mtime_ns, st.st_size


def day_of(ts):
    return time.strftime("%Y-%m-%d", time.gmtime(ts))


def _nb(x):
    """['2026-11-04', 12]: consultas de siguientes de ese día; lo que no tenga esa forma, ['', 0]"""
    if (isinstance(x, (list, tuple)) and len(x) == 2 and isinstance(x[0], str) and isinstance(x[1], int)
            and not isinstance(x[1], bool) and x[1] >= 0):
        return [x[0], x[1]]
    return ["", 0]


def _stamp(e):
    try:
        return float(e[0])
    except (TypeError, ValueError, IndexError, KeyError):
        return 0.0


class Cache:
    """ratings3.json: {"v": {"movie:123": [ts, {"metacritic": 44, "imdb": 6.1} | null]}, "until": ts_parar,
    "nb": [día UTC, consultas de siguientes de ese día]}.
    La escriben el bucle de notas (vivo toda la sesión) y label_for (la ficha, el Inicio táctil), cada uno en su
    intérprete: save() mezcla con lo que haya en el fichero (gana la nota más nueva y el mayor «until») y sync() trae
    lo que guardó otro (revisión 29-oct ARR-05: antes el bucle borraba en cada guardado las notas de la ficha)"""

    def __init__(self, path, now=time.time):
        self.path, self.now, self.dirty = path, now, False
        self.sig = _file_sig(path)              # ANTES de leer: si cambia mientras, sync() lo vuelve a leer
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        if not isinstance(d, dict):
            d = {}
        self.v = d.get("v") if isinstance(d.get("v"), dict) else {}
        self.until = float(d.get("until") or 0)
        self.nb = _nb(d.get("nb"))

    def _merge_in(self, d):
        """lo del fichero d que sea más nuevo que lo de aquí"""
        v = d.get("v") if isinstance(d.get("v"), dict) else {}
        for k, e in v.items():
            if isinstance(e, list) and _stamp(e) > _stamp(self.v.get(k)):
                self.v[k] = e
        try:
            self.until = max(self.until, float(d.get("until") or 0))
        except (TypeError, ValueError):
            pass
        nb = _nb(d.get("nb"))
        if nb > self.nb:                    # día más nuevo, o el mismo con más consultas
            self.nb = nb

    def sync(self):
        """lo que otro script haya guardado desde la última lectura (solo si el fichero cambió)"""
        sig = _file_sig(self.path)
        if sig is None or sig == self.sig:
            return
        import flix_cache       # aquí y no arriba: el clic en una carátula importa este módulo (test_click_imports)
        self.sig = sig
        self._merge_in(flix_cache.load_dict(self.path))
        self._trim()

    def get(self, kind, tmdb):
        """(True, vals|None) si está fresca; (False, None) si hay que pedirla"""
        e = self.v.get("%s:%s" % (kind, tmdb))
        if not isinstance(e, list) or len(e) < 2:
            return False, None
        ts, vals = e[0], e[1]
        ttl = TTL if vals else (ERR_TTL if len(e) > 2 else NEG_TTL)
        if self.now() - ts > ttl:
            return False, None
        return True, (vals or None)

    def put(self, kind, tmdb, vals, error=False):
        e = [self.now(), vals if vals else ({} if not error else None)]
        if error:
            e.append("err")
        self.v["%s:%s" % (kind, tmdb)] = e
        self._trim()
        self.dirty = True

    def _trim(self):
        if len(self.v) > MAX_ENTRIES:              # fuera las más viejas
            for k in sorted(self.v, key=lambda k: _stamp(self.v[k]))[:len(self.v) - MAX_ENTRIES]:
                del self.v[k]

    def nb_used(self):
        """consultas de siguientes de hoy (día UTC, como el contador de MDBList)"""
        return self.nb[1] if self.nb[0] == day_of(self.now()) else 0

    def nb_add(self):
        today = day_of(self.now())
        self.nb = [today, self.nb_used() + 1]
        self.dirty = True

    def blocked(self):
        return self.now() < self.until

    def block(self, until):
        self.until, self.dirty = until, True

    def save(self):
        """con cerrojo y mezclando con el fichero (flix_cache.update_json): lo que guardó otro script se queda"""
        if not self.dirty:
            return
        import flix_cache       # aquí y no arriba: el clic en una carátula importa este módulo (test_click_imports)

        def merge(disk):
            self._merge_in(disk)
            self._trim()
            return {"v": self.v, "until": self.until, "nb": self.nb}
        flix_cache.update_json(self.path, merge, separators=(",", ":"))
        self.sig = _file_sig(self.path)
        self.dirty = False


# ---------- dentro de Kodi ----------
def _kodi():
    import xbmc
    import xbmcgui
    import xbmcvfs
    return xbmc, xbmcgui, xbmcvfs


def read_key():
    key = _kodi()[0].getInfoLabel("Skin.String(flix_mdblist_key)").strip()
    return key if key not in ("", "-") else ""


def read_order(key=None):
    """orden guardado; si aún no hay (aparato de antes), el equivalente al ajuste viejo flix_rating_src"""
    xbmc = _kodi()[0]
    text = xbmc.getInfoLabel("Skin.String(flix_rating_order)").strip()
    if text:
        return parse_order(text)
    return legacy_order(xbmc.getInfoLabel("Skin.String(flix_rating_src)"), read_key() if key is None else key)


def settings_now():
    """(clave, fuentes de MDBList a mirar en orden); sin clave -> ('', ()) = la ★ de TMDB de siempre"""
    key = read_key()
    return key, (chain(read_order(key)) if key else ())


def save_settings(key, order):
    xbmc = _kodi()[0]
    xbmc.executebuiltin("Skin.SetString(flix_mdblist_key,%s)" % (key or "-"))
    xbmc.executebuiltin("Skin.SetString(flix_rating_order,%s)" % dump_order(order))
    xbmc.executebuiltin("Skin.SetString(flix_rating_summary,%s)" % summary(order, key))
    ensure_running(key)         # clave puesta en el editor: el bucle, si no está ya (sin clave sale él solo; PY-09)


def alive(now=None):
    """¿el bucle late? (ALIVE con hora reciente; la marca «1» de first_run de antes no cuenta)"""
    home = _kodi()[1].Window(10000)
    try:
        t = float(home.getProperty(ALIVE) or 0)
    except ValueError:
        return False
    return 0 <= (time.time() if now is None else now) - t < ALIVE_MAX


def ensure_running(key=None):
    """lanza el bucle si hay clave y no late (first_run al arrancar, save_settings al poner la clave). True si lo lanzó.
    Sin clave no se lanza nada: antes vivía toda la sesión mirando los ajustes cada 3 s (revisión 7-nov PY-09)"""
    xbmc, xbmcgui, _ = _kodi()
    key = read_key() if key is None else key
    if not key or alive():
        return False
    xbmcgui.Window(10000).setProperty(ALIVE, "%.0f" % time.time())     # ya, no cuando arranque: dos seguidos no doblan
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_ratings.py)")
    return True


def migrate():
    """al arrancar (first_run): orden del ajuste viejo -> flix_rating_order, una vez; y resumen siempre al día. Así
    los ajustes existen y se pueden poner a distancia (Settings.SetSkinSettingValue solo cambia los que existen)"""
    xbmc = _kodi()[0]
    key, order = read_key(), read_order()
    if (not xbmc.getInfoLabel("Skin.String(flix_rating_order)")
            or xbmc.getInfoLabel("Skin.String(flix_rating_summary)") != summary(order, key)):
        save_settings(key, order)


def cache_path():
    xbmc, _, xbmcvfs = _kodi()
    # ratings3: las de antes (ratings.json, ratings2.json) no guardaban Rotten Tomatoes ni Letterboxd
    return xbmcvfs.translatePath("special://profile/addon_data/%s/ratings3.json" % xbmc.getSkinDir())


def log(msg):
    xbmc = _kodi()[0]
    xbmc.log("[flix_ratings] %s" % msg, xbmc.LOGINFO)


SLOTS = (("li", "ListItem.FolderPath"), ("c5", "Container(5000).ListItem.FolderPath"),
         ("fz", "Window(home).Property(fhz_path)"))


# etiqueta de los siguientes de cada ranura (%d = 1, 2, 3 en la forma de Kodi); la cabecera congelada (fz) no tiene fila
NEAR = {"li": "ListItem(%d).FolderPath", "c5": "Container(5000).ListItem(%d).FolderPath"}


class Watcher:
    def __init__(self):
        xbmc, xbmcgui, _ = _kodi()
        self.xbmc, self.home = xbmc, xbmcgui.Window(10000)
        self.cache = Cache(cache_path())
        self.lock = threading.Lock()
        self.busy = set()
        self.seen = {}                  # ranura -> (ruta, desde cuándo (monotónico), target de la ruta)
        self.shown = {}                 # ranura -> (ruta, texto) lo último publicado: en reposo la vuelta no lee propiedades
        self.save_after = 0.0           # no reintentar guardar antes de esta hora (disco lleno: no a 10 Hz)
        self.key, self.srcs = "", ()
        self.mon = None                 # el de run(): se entera del cierre de Kodi (quit_monitor)
        self.near = {}                  # ranura -> siguientes por pedir (los de la fila del foco de ahora)
        self.near_path = {}             # ranura -> ruta enfocada de la que ya se encolaron los siguientes
        self.near_run = False           # hay un hilo drain_near (solo uno a la vez)
        self.pre_active = False         # la precarga está en marcha: los siguientes esperan
        self.nb_unsaved, self.nb_first = 0, 0.0     # siguientes sin guardar y desde cuándo
        self.focus_at = None            # monotónico del último cambio de foco: FOCUS_FAST s a STEP_FOCUS

    def clear(self):
        """todo fuera, también ON: sin él el XML vuelve a la ★ de siempre"""
        self.home.clearProperty(ON)
        self.shown.clear()
        for s, _ in SLOTS:
            self.home.clearProperty("flix_rt_%s" % s)
            self.home.clearProperty("flix_rt_%s_path" % s)
            self.home.clearProperty("flix_rt_%s_src" % s)
            self.home.clearProperty("flix_rt_%s_val" % s)

    def show(self, slot, path, vals):
        text = fmt(self.srcs, vals)
        src, val = parts(self.srcs, vals)
        self.home.setProperty("flix_rt_%s_src" % slot, src)     # antes que el texto: el XML elige icono o texto con los tres
        self.home.setProperty("flix_rt_%s_val" % slot, val)
        self.home.setProperty("flix_rt_%s" % slot, text)
        self.home.setProperty("flix_rt_%s_path" % slot, path)
        self.shown[slot] = (path, text)

    def worker(self, kind, tmdb, save=True):
        """pide la nota a MDBList y la guarda. save=False: la precarga guarda ella cada PREFETCH_SAVE títulos. True si
        hizo la petición (los siguientes de la fila la cuentan para su tope del día)"""
        import urllib.error
        sent = False
        try:
            if quitting(self.mon):
                return False            # Kodi se cierra: nada nuevo a MDBList (APA-03)
            with self.lock:
                self.cache.sync()       # la ficha (otro intérprete) puede haberla guardado ya: no gastar consulta
                if self.cache.get(kind, tmdb)[0]:
                    return False
            sent = True
            vals = fetch(kind, tmdb, self.key)
            with self.lock:
                self.cache.put(kind, tmdb, vals)
        except _Partial as e:
            with self.lock:
                self.cache.put(kind, tmdb, e.vals)
                self.cache.block(e.until)
            log("quedan pocas consultas de MDBList: paro hasta %s" % time.strftime("%H:%M", time.localtime(e.until)))
        except RateLimited as e:
            with self.lock:
                self.cache.block(e.until)
            log("límite de MDBList: paro hasta %s" % time.strftime("%H:%M", time.localtime(e.until)))
        except urllib.error.HTTPError as e:
            with self.lock:
                self.cache.put(kind, tmdb, None, error=True)
            log("MDBList %s/%s: HTTP %s%s" % (kind, tmdb, e.code, " (¿clave %s mal?)" % mask(self.key)
                                               if e.code in (401, 403) else ""))
        except Exception as e:  # noqa: BLE001
            with self.lock:
                self.cache.put(kind, tmdb, None, error=True)
            log("MDBList %s/%s: %s" % (kind, tmdb, str(e).replace(self.key, mask(self.key)) if self.key else e))
        finally:
            with self.lock:
                self.busy.discard((kind, tmdb))
                if save:
                    self.save()
        return sent

    def save(self):
        """con self.lock cogido; nunca lanza (como antes, un fallo al guardar no para el bucle)"""
        try:
            self.cache.save()
            self.nb_unsaved = 0
        except Exception as e:  # noqa: BLE001
            log("no guardo las notas: %s" % e)
            # disco lleno: flush_due corre 10 veces por segundo y reintentaba (y leía el JSON) en cada una. Se reinicia
            # el reloj de las tandas y no se vuelve a intentar hasta dentro de NEIGHBOUR_SAVE_AGE s (lo pendiente sigue sucio)
            self.nb_first = self.save_after = time.time()
            self.save_after += NEIGHBOUR_SAVE_AGE

    def drop_near(self, slot):
        """el foco se movió: los siguientes de antes ya no están cerca"""
        with self.lock:
            self.near.pop(slot, None)
            self.near_path.pop(slot, None)

    def tick(self):
        now = time.monotonic()      # no la hora de pared: un cambio de hora no debe alargar ni acortar el foco (since)
        settled = []
        # con un menú encima del Inicio (sin ser la ranura c5 / fz), ListItem.* es el del menú: la ranura li no se toca y
        # conserva lo último publicado (el XML sigue viendo la misma nota y la misma ruta, y flix_rt_on no cambia)
        modal = bool(self.xbmc.getCondVisibility("System.HasActiveModalDialog"))
        for slot, label in SLOTS:
            if modal and slot == "li":
                continue
            path = self.xbmc.getInfoLabel(label)
            prev = self.seen.get(slot)
            if not prev or prev[0] != path:
                # la ruta se decodifica al cambiar, no en cada vuelta (10 por segundo, también en reposo)
                self.seen[slot] = (path, now, target(path))
                prev = self.seen[slot]
                self.drop_near(slot)
                self.focus_at = now
            t = prev[2]
            with self.lock:
                hit, vals = self.cache.get(*t) if t else (False, None)
                blocked = self.cache.blocked()
                busy = bool(t) and t in self.busy
            # el XML enseña la nota si la ruta coincide, la ★ solo si la ruta está resuelta (aquí) y en blanco mientras
            # tanto: así no hay ★ que luego se cambie por la nota (ni siquiera en la 1.ª pintura tras el foco)
            st = slot_state(t, hit, prev[1], now, not blocked)
            if st != "wait":
                v = vals if st == "note" else None
                if self.shown.get(slot, ("", "")) != (path, fmt(self.srcs, v)):     # lo último publicado (sin nada = vacío)
                    self.show(slot, path, v)
            if t and not hit and not busy and not blocked and now - prev[1] >= DWELL:
                with self.lock:
                    self.busy.add(t)
                threading.Thread(target=self.worker, args=t, daemon=True).start()
            if slot in NEAR and path and now - prev[1] >= DWELL and self.near_path.get(slot) != path:
                settled.append((slot, path, t))
        for slot, path, t in settled:       # después de lanzar lo enfocado de TODAS las ranuras: va primero
            self.enqueue_near(slot, path, t)

    def enqueue_near(self, slot, path, t):
        """foco asentado en path (ranura slot, título t): encola los títulos de los NEIGHBOURS siguientes que no estén ya"""
        self.near_path[slot] = path
        paths = [self.xbmc.getInfoLabel(NEAR[slot] % i) for i in range(1, NEIGHBOURS + 1)]
        if not any(paths):
            return
        with self.lock:
            if self.cache.blocked() or neighbour_left(self.cache.nb_used()) <= 0:
                return
            picks = neighbour_picks(paths, lambda x: x == t or self.cache.get(*x)[0] or x in self.busy)
        if not picks or self.xbmc.getCondVisibility("Skin.HasSetting(flix_lite)"):
            return                  # modo modesto: solo la nota del título que se mira
        with self.lock:
            self.near[slot] = picks
            start, self.near_run = not self.near_run, True
        if start:
            threading.Thread(target=self.drain_near, args=(), daemon=True).start()

    def next_near(self):
        """con self.lock cogido: el siguiente por pedir (los ya en caché o en vuelo se descartan); None si no queda"""
        for slot in list(self.near):
            q = self.near[slot]
            while q:
                t = q.pop(0)
                if not self.cache.get(*t)[0] and t not in self.busy:
                    return t
            del self.near[slot]
        return None

    def flush_due(self):
        """guarda las notas de siguientes si ya son muchas o llevan NEIGHBOUR_SAVE_AGE s sin guardar"""
        with self.lock:
            now = time.time()
            if self.cache.dirty and now >= self.save_after and neighbour_save_due(self.nb_unsaved, self.nb_first, now):
                self.save()

    def drain_near(self):
        """hilo de los siguientes de la fila: de uno en uno (nunca dos a la vez), después del enfocado y de la precarga, con
        pausa entre peticiones y el tope del día; un hilo solo (near_run). La cola la vacía el foco al moverse (drop_near)"""
        n, waited, clean = 0, 0.0, False
        try:
            while not quitting(self.mon):
                job = None
                with self.lock:
                    if not any(self.near.values()):
                        self.near_run, clean = False, True     # decidido con el cerrojo: encolar después abre otro hilo
                        break
                    verdict = neighbour_turn(not self.cache.blocked(), neighbour_left(self.cache.nb_used()),
                                             bool(self.busy) or self.pre_active)
                    if verdict == "stop" or (verdict == "wait" and waited >= NEIGHBOUR_WAIT_MAX):
                        self.near.clear()                       # 429 / LOW / tope del día: el resto se deja
                        self.near_run, clean = False, True
                        break
                    if verdict == "go":
                        job = self.next_near()
                        if job:
                            self.busy.add(job)
                if job is None:
                    if verdict == "wait":
                        waited += NEIGHBOUR_RECHECK
                        if quit_sleep(NEIGHBOUR_RECHECK):
                            break
                    continue
                waited = 0.0
                if self.worker(job[0], job[1], save=False):
                    n += 1
                    with self.lock:
                        self.cache.nb_add()
                        if not self.nb_unsaved:
                            self.nb_first = time.time()
                        self.nb_unsaved += 1
                    self.flush_due()
                if quit_sleep(NEIGHBOUR_PAUSE):
                    break
        finally:
            with self.lock:
                if not clean:
                    self.near_run = False
                if quitting(self.mon):
                    self.save()                                 # Kodi se cierra: lo pedido no se pierde
        if n:
            log("siguientes de la fila: %d notas pedidas" % n)

    def prefetch(self):
        self.pre_active = True              # los siguientes de la fila esperan a que acabe
        try:
            self._prefetch()
        finally:
            self.pre_active = False

    def _prefetch(self):
        """notas de los primeros PREFETCH_ROW títulos de cada fila, de una en una y con tope por pasada"""
        if self.xbmc.getCondVisibility("Skin.HasSetting(flix_lite)"):
            return                  # modo modesto: solo la nota del título que se mira, sin precarga
        n = 0
        for kind, tmdb in prefetch_targets(self.xbmc):
            if quitting(self.mon):
                break                   # Kodi se cierra: la precarga para entre título y título (APA-03)
            with self.lock:
                hit, _ = self.cache.get(kind, tmdb)
                skip = hit or (kind, tmdb) in self.busy or self.cache.blocked()
                if not skip:
                    self.busy.add((kind, tmdb))
            if skip:
                continue
            if n >= PREFETCH_MAX:
                with self.lock:
                    self.busy.discard((kind, tmdb))
                break
            self.worker(kind, tmdb, save=False)
            n += 1
            if n % PREFETCH_SAVE == 0:
                with self.lock:
                    self.save()         # cada 20 y al final: antes, tras cada título (hasta 150 por pasada; ARR-22)
            if quit_sleep(PREFETCH_PAUSE):
                break
        with self.lock:
            self.save()
        if n:
            log("precarga: %d notas pedidas" % n)

    def step(self, video, now):
        """vuelta siguiente: 0,5 s con vídeo; 0,1 s los FOCUS_FAST s tras mover el foco; 0,25 s en reposo (PY-06)"""
        if video:
            return STEP_VIDEO
        if self.focus_at is not None and now - self.focus_at < FOCUS_FAST:
            return STEP_FOCUS
        return STEP

    def run(self):
        # Kodi no avisa del cierre por abortRequested a los RunScript sin addon: quit_monitor se entera por System.OnQuit
        # y el bucle, la precarga y las peticiones nuevas se paran (antes Kodi esperaba 5 s y lo mataba; APA-03). Una
        # petición a MDBList ya en marcha acaba como siempre (TIMEOUT); con Kodi abierto no cambia nada
        mon = self.mon = quit_monitor()
        active = None
        next_pre = time.time() + PREFETCH_DELAY
        next_cfg = next_alive = 0
        nokey_since = None
        video = False
        try:
            self.clear()                                     # de otra vez: ON o notas viejas taparían la ★
            while not quitting(mon):
                if time.time() >= next_cfg:
                    next_cfg = time.time() + CFG_EVERY
                    self.key, self.srcs = settings_now()
                    video = bool(self.xbmc.getCondVisibility("Player.HasVideo | Window.IsActive(fullscreenvideo)"))
                if time.time() >= next_alive:
                    next_alive = time.time() + ALIVE_EVERY
                    self.home.setProperty(ALIVE, "%.0f" % time.time())       # latido: ensure_running no lanza otro
                if self.key:
                    nokey_since = None
                elif nokey_since is None:
                    nokey_since = time.time()
                elif time.time() - nokey_since >= NOKEY_EXIT:
                    log("sin clave de MDBList: salgo (el editor relanza el bucle al poner una)")
                    break
                on = bool(self.key) and bool(self.srcs)
                if (self.srcs, on) != active:                # al cambiar el orden o la clave: fuera las notas puestas
                    log("nota de %s (clave %s)" % (" → ".join([LABEL[k] for k in self.srcs] + ["TMDB"]), mask(self.key))
                        if on else "sin clave de MDBList o TMDB la primera: la ★ de siempre")
                    active = (self.srcs, on)
                    self.clear()
                    if on:
                        self.home.setProperty(ON, "1")       # a partir de aquí el XML espera a que el bucle resuelva
                if on:
                    self.tick()
                    self.flush_due()
                    if time.time() >= next_pre:
                        next_pre = time.time() + PREFETCH_EVERY
                        threading.Thread(target=self.prefetch, daemon=True).start()
                if wait_quit(mon, self.step(video, time.monotonic()) if on else (3 if self.key else 1)):
                    break
        finally:
            self.clear()                                     # el bucle acaba (cierre, error): la ★ vuelve siempre
            self.home.clearProperty(ALIVE)                   # sin latido: ensure_running puede volver a lanzarlo
            with self.lock:
                self.near.clear()
                self.save()                                  # y lo pedido sin guardar (siguientes de la fila) no se pierde


PREFETCH_DELAY = 90     # s tras arrancar: que carguen el Inicio, p3sync (20 s), el especial y el repositorio (45 s) (PY-08)
PREFETCH_EVERY = 1800   # y cada media hora (filas renovadas)
PREFETCH_ROW = 10       # títulos por fila
PREFETCH_MAX = 150      # consultas como mucho por pasada (MDBList gratis: 1000/día)
PREFETCH_PAUSE = 0.3
NEIGHBOUR_PAUSE = PREFETCH_PAUSE    # entre dos peticiones de siguientes
PREFETCH_SAVE = 20      # la precarga guarda ratings3.json cada tantos títulos y al acabar
HOME_ROWS = list(range(5101, 5119)) + list(range(5130, 5148))   # filas del Inicio TV (flix_home_conf)


def prefetch_targets(xbmc, rows_file=None):
    """títulos de las filas: Inicio TV (contenedores de Kodi, si está a la vista) y filas guardadas por la táctil y
    las secciones (rows_cache2.json). Sin índice aparte: escribirlo en cada guardado costaba más (7-nov, PY-08)"""
    out, seen = [], set()

    def add(path):
        t = target(path)
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    if xbmc.getCondVisibility("Window.IsVisible(home)"):
        for rid in HOME_ROWS:
            for i in range(PREFETCH_ROW):
                p = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FolderPath" % (rid, i))
                if not p:
                    break
                add(p)
    try:
        if rows_file is None:
            import xbmcvfs
            rows_file = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache2.json" % xbmc.getSkinDir())
        with open(rows_file, encoding="utf-8") as f:
            rows = json.load(f)
        for entry in rows.values():
            files = entry[1] if isinstance(entry, list) and len(entry) == 2 and isinstance(entry[1], list) else []
            for f in files[:PREFETCH_ROW]:
                if isinstance(f, dict):
                    add(f.get("file", ""))
    except (OSError, ValueError):
        pass
    return out


def wanted(path):
    """True si esta ruta debería llevar nota de MDBList (clave puesta, alguna fuente antes de TMDB y es un título)"""
    key, srcs = settings_now()
    return bool(key) and bool(srcs) and target(path) is not None


def label_for(path, wait=0.0):
    """para scripts (ficha, Inicio táctil): «Metacritic 82» / «IMDb 8.4» si está activa y hay nota (de caché o, con wait > 0,
    pidiéndola como mucho wait s); '' si no -> el que llama pone la ★ de TMDB"""
    key, srcs = settings_now()
    t = target(path)
    if not key or not srcs or not t:
        return ""
    c = Cache(cache_path())
    hit, vals = c.get(*t)
    if hit:
        return fmt(srcs, vals)
    if wait <= 0 or c.blocked():
        return ""
    try:
        vals = fetch(*t, key)
        c.put(*t, vals)
    except _Partial as e:
        c.put(*t, e.vals)
        c.block(e.until)
        vals = e.vals
    except RateLimited as e:
        c.block(e.until)
        vals = None
    except Exception:  # noqa: BLE001
        c.put(*t, None, error=True)
        vals = None
    c.save()
    return fmt(srcs, vals)


# ---------- editor único (flix_editor.py): avisos de cada fuente y clave ----------


def row_note(order, k, key):
    """aviso a la derecha de cada fuente: TMDB es la predefinida; las de debajo de TMDB no se usan; sin clave no hay
    MDBList"""
    if k == TMDB:
        return "Predefinida"
    if [x for x, _ in order].index(k) > [x for x, _ in order].index(TMDB):
        return "Debajo de TMDB: no se usa"
    if not key:
        return "Necesita clave de MDBList"
    return ""


def ask_key(xbmcgui, key):
    """teclado para la clave; '' la borra. None = cancelado o no válida"""
    new = xbmcgui.Dialog().input("Clave de MDBList (mdblist.com → Preferences → API). Vacía = quitarla",
                                 key).strip()
    if new and not re.fullmatch(KEY_RE, new):
        xbmcgui.Dialog().notification("Nota de los títulos", "Esa clave no parece válida", time=3000)
        return None
    return new


def main(argv):
    if len(argv) > 1 and argv[1] == "settings":
        import flix_editor
        flix_editor.run("ratings")          # acceso viejo (Ajustes de antes)
        return
    Watcher().run()


if __name__ == "__main__":
    main(sys.argv)
