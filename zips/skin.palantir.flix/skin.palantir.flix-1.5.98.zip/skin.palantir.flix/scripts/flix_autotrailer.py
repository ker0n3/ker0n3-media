"""Tráiler automático en la ficha (TV; diseño docs/superpowers/specs/2026-10-30-trailer-automatico-ficha-design.md).

Con Ajustes → «Tráiler automático en la ficha» en «Con sonido» o «Sin sonido» (Skin.String(flix_autotrailer) =
sonido / mudo; vacío = No, de serie), al abrir la ficha de una película (flix_play.MovieSheet) o de una serie
(flix_series_sheet.SeriesSheet) el tráiler se pide a los 2 s en el recuadro de la ficha (PlayMedia(...,1)) y entra con
un fundido cuando hay imagen (onAVStarted). Se para al salir, al ver algo o con cualquier otra reproducción, y solo si
lo que suena es lo suyo. Reaprovecha flix_trailer (búsqueda, caché, _try, mark_bad, audio_guard, FLAG).

Kodi en Android pinta el vídeo (MediaCodec Surface) solo desde el recuadro de la ventana ACTIVA, no desde los diálogos
(GUIWindowManager::RenderEx): la ficha de película es un diálogo y las ventanas de debajo llevan FlixTrailerHost, un
recuadro fuera de pantalla visible con flix_tr_auto (Shield, 30-oct).

Lógica pura arriba (tests en tools/tests/test_autotrailer.py); lo que toca Kodi, abajo."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import threading  # noqa: E402
import time  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

SETTING = "flix_autotrailer"
MODES = ("", "sonido", "mudo")
LABELS = ("No", "Con sonido", "Sin sonido")
DELAY = 2.0             # s con la ficha abierta antes de pedirlo (entrar y salir rápido no gasta nada)
URL_WAIT = 12           # s más esperando a que la búsqueda (TMDB / Palantir) dé la URL
TRY_WAIT = 15           # s por vídeo esperando imagen (el addon YouTube tarda ~4 s en la Shield)
ACTIVE = "flix_tr_auto"         # Window(home): automático en marcha (FlixTrailerHost de las ventanas de debajo)
LOADING = "flix_tr_loading"     # Window(home): preparándose (DialogBusy sin rueda)
ON_HOME = "flix_tr_on"          # Window(home): hay imagen (botón «Tráiler» de la serie: a pantalla completa)
GEN = "flix_trailer_gen"        # Window(home): marca del último flix_trailer.begin() (como flix_trailer.GEN)
ON = "tr_on"                    # propiedad de la ficha: hay imagen (fundido del recuadro)
MUTED = "flix_tr_muted"         # Skin.String: silencio puesto por el automático (recover lo quita al arrancar)
HOME = xbmcgui.Window(10000)


def log(msg):
    xbmc.log("[flix_autotrailer] %s" % msg, xbmc.LOGINFO)


def mode_of(value):
    return value if value in MODES else ""


def should_start(mode, has_media, open_secs, closed):
    """pedir el tráiler: ajuste encendido, nada sonando (un solo reproductor), 2 s con la ficha abierta"""
    return bool(mode) and not has_media and not closed and open_secs >= DELAY


def need_mute(mode, muted):
    """silenciar solo en «Sin sonido» y si Kodi no lo estaba ya (ese silencio no es nuestro: no se quita)"""
    return mode == "mudo" and not muted


def at_end(pos, total, margin=1.0):
    """el HLS de YouTube no avisa del final: Kodi lo trata como emisión en directo, el tiempo sigue pasada la
    duración y se queda la última imagen congelada (Shield, 30-oct: «está congelado el tráiler», 3:10 de 2:34)"""
    return total > 0 and pos >= total - margin


def is_ours(own_file, playing_file):
    return bool(own_file) and own_file == playing_file


# ---------- Kodi ----------
def mode():
    return mode_of(xbmc.getInfoLabel("Skin.String(%s)" % SETTING))


def muted():
    import flix_common
    try:
        return bool((flix_common.rpc("Application.GetProperties", {"properties": ["muted"]}).get("result") or {})
                    .get("muted"))
    except ValueError:
        return False


def set_mute(on):
    """silencio de todo Kodi. Application.SetMute por JSON-RPC desde la skin no hace nada (devuelve «no silenciado»;
    Shield 30-oct): se usa el Mute de Kodi, que alterna, solo si hace falta (muted()). La marca persistente sigue al
    silencio"""
    if on:
        # la marca ANTES del silencio: si Kodi se cierra entre las dos cosas, recover() aún puede devolver el sonido.
        # wait=True: que ya esté puesta cuando cleanup() la lea
        xbmc.executebuiltin("Skin.SetString(%s,1)" % MUTED, True)
        if not muted():
            xbmc.executebuiltin("Mute", True)
    else:
        if muted():
            xbmc.executebuiltin("Mute", True)
        xbmc.executebuiltin("Skin.Reset(%s)" % MUTED)


def _marker():
    """la marca persistente del silencio del automático (full() la quita al pasar a pantalla completa)"""
    return xbmc.getInfoLabel("Skin.String(%s)" % MUTED)


def recover():
    """al arrancar Kodi (first_run): si se cerró con el silencio del automático puesto, se quita"""
    if _marker():
        set_mute(False)
        xbmc.executebuiltin("Skin.Reset(%s)" % MUTED)
        log("silencio del tráiler automático quitado al arrancar")


def _playing_file():
    """lo que suena TAL COMO se pidió: Player.Filenameandpath da la URL del PlayMedia (el plugin de YouTube), no la
    resuelta que da getPlayingFile (Shield, 30-oct). Se usa siempre esta, para guardar y para comparar"""
    return xbmc.getInfoLabel("Player.Filenameandpath")


def _stop_player():
    xbmc.Player().stop()


def _position():
    """(segundos, duración) de lo que suena; (0, 0) si nada"""
    try:
        player = xbmc.Player()
        return player.getTime(), player.getTotalTime()
    except RuntimeError:
        return 0.0, 0.0


def _done():
    import flix_trailer
    flix_trailer.done()


def _stop_late():
    """el PlayMedia ya pedido llegará después: se para al aparecer (flix_trailer.stop_late; un envoltorio para los tests)"""
    import flix_trailer
    flix_trailer.stop_late()


class _Player(xbmc.Player):
    """avisos del reproductor para el automático (onAVStarted = hay imagen de verdad)"""

    def __init__(self, auto):
        super().__init__()
        self.auto = auto

    def onAVStarted(self):
        self.auto.on_av()

    def onPlayBackStarted(self):
        self.auto.on_started()

    def onPlayBackEnded(self):
        self.auto.on_end()

    def onPlayBackStopped(self):
        self.auto.on_end()

    def onPlayBackError(self):
        self.auto.on_end()


class AutoTrailer:
    """el tráiler automático de UNA ficha. state: idle → loading → playing → done.
    win: la ventana de la ficha (propiedad tr_on); get_urls(): las URL de flix_trailer.resolve («a|b»), o '' si aún
    no se sabe"""

    def __init__(self, win, get_urls):
        self.win, self.get_urls = win, get_urls
        self.state, self.file, self.muted_by_us, self.closed = "idle", "", False, False
        self.requested = ""         # URL del PlayMedia lanzado cuya imagen (onAVStarted) aún no ha llegado; '' = ninguno
        self.gen = ""               # GEN de flix_trailer tras nuestro begin(): otro begin() (el botón «Tráiler») lo cambia
        self.stopped_at = 0.0       # cuándo se cerró la ficha (el aviso tardío solo se atiende LATE_WAIT s)
        self.begun = False          # flix_trailer.begin() puesto y done() aún no: cleanup() lo cierra
        self.player = None
        self.lock = threading.Lock()

    # --- arrancar ---
    def start(self):
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        if not mode():                      # «No» (de serie; en la táctil siempre): ni se espera ni se busca la URL
            return
        mon, t0 = xbmc.Monitor(), time.time()
        while not self.closed:
            urls = self.get_urls()
            if urls and time.time() - t0 >= DELAY:
                break
            if time.time() - t0 > DELAY + URL_WAIT or mon.waitForAbort(0.2):
                return
        if not should_start(mode(), xbmc.getCondVisibility("Player.HasMedia"), time.time() - t0, self.closed):
            return
        import flix_trailer
        if not flix_trailer.available():        # sin el addon YouTube no hay tráiler (ni botón)
            return
        self.play(urls, mon)

    def play(self, urls, mon):
        """pide el tráiler. Pase lo que pase (también una excepción) acaba en cleanup(), salvo que ya suene"""
        settled = False
        try:
            settled = self._play(urls, mon)
        except Exception as e:  # noqa: BLE001
            log("error al arrancar el tráiler: %s" % e)
        finally:
            if not settled:
                self.cleanup()
        if settled:
            self.pump(mon)

    def pump(self, mon):
        """Kodi entrega los avisos de xbmc.Player (onAVStarted…) en el hilo que creó el Player y solo mientras ese hilo
        espera en Kodi (waitForAbort): este hilo se queda vivo mientras el tráiler sea nuestro, o pedido y con la ficha
        recién cerrada (LATE_WAIT). Sin esto el tráiler sonaba y el recuadro no se encendía nunca (Shield, 30-oct).
        Sin monitor (tests) no espera"""
        import flix_trailer
        if mon is None:
            return
        while not mon.waitForAbort(0.1):
            with self.lock:
                alive = self.state in ("loading", "playing") or bool(
                    self.requested and self.closed and time.time() - self.stopped_at <= flix_trailer.LATE_WAIT)
            if not alive:
                return
            if self.state == "playing" and at_end(*_position()):
                self.finish()

    def _play(self, urls, mon):
        """True si no queda nada que limpiar (ficha ya cerrada, o el tráiler está en marcha)"""
        import flix_trailer
        with self.lock:
            if self.closed:
                return True
            self.state = "loading"
            # begin() aquí dentro: si stop() ya limpió, no se llama, y si no, cleanup() lo cierra con done()
            flix_trailer.begin()
            self.begun = True
            self.gen = HOME.getProperty(flix_trailer.GEN)
        HOME.setProperty(ACTIVE, "1")
        HOME.setProperty(LOADING, "1")
        self.player = _Player(self)
        if need_mute(mode(), muted()):
            set_mute(True)
            self.muted_by_us = True
        res = ""
        for url in [u for u in urls.split(flix_trailer.SEP) if u]:
            if self.closed:                     # se salió de la ficha: no se pide otro
                break
            log("pido %s" % url)
            self.requested = url
            res = flix_trailer._try(url, mon, lambda: self.closed, windowed=True, quiet=True, wait=TRY_WAIT)
            if res == "ok":
                HOME.clearProperty(LOADING)
                flix_trailer.audio_guard()
                return True
            if res == "failed":
                flix_trailer.mark_bad(url)      # el addon avisó: la próxima vez ni se intenta
            else:
                # "cancel": la rueda va escondida (modal), así que «sin vídeo y sin aviso del addon» es el Atrás del
                # usuario sobre una rueda que no ve; otra URL abriría otra rueda invisible (hasta 5). Igual que
                # flix_trailer.start(): no se insiste ni se marca como mala. También con tiempo agotado, "late" o Kodi
                # cerrándose
                break
        if res == "timeout" and HOME.getProperty(flix_trailer.GEN) == self.gen:
            # si llega después, se para al aparecer; no si el usuario pidió con «Tráiler» el suyo entre medias (stop_late
            # coge el GEN de ahora y pararía ESE)
            flix_trailer.stop_late()
        # con "late" la ficha ya se cerró y stop() armó el aviso con el GEN de ESTE tráiler: armarlo otra vez ahora
        # cogería el GEN del que el usuario pidió con «Tráiler» entre medias y lo pararía
        log("sin tráiler (%s)" % (res or "sin URL"))
        return False

    # --- avisos del reproductor ---
    def on_av(self):
        with self.lock:
            if self.state == "loading" and not self.closed:
                if _playing_file() != self.requested:
                    # lo que ha empezado no es el tráiler pedido (un capítulo o «Seguir viendo» pulsado en los huecos
                    # de la preparación): no se adopta; se limpia lo nuestro (marcas, silencio) sin parar nada
                    self.on_other_playback()
                    return
                self.requested = ""
                self.file = _playing_file()
                self.state = "playing"
                HOME.clearProperty(LOADING)
                HOME.setProperty(ON_HOME, "1")
                self.win.setProperty(ON, "1")
                log("en el recuadro: %s" % self.file[:80])
            elif self.requested and self.closed:
                # la ficha se cerró con el tráiler ya pedido: si llega ahora (hasta LATE_WAIT s), se para, pero solo
                # si es el que pedimos: cualquier otra reproducción (un capítulo, la película) no es cosa nuestra
                import flix_trailer
                if time.time() - self.stopped_at <= flix_trailer.LATE_WAIT:
                    # y solo si nadie ha empezado otro tráiler después (el del botón, con la misma URL): cambia GEN
                    if _playing_file() == self.requested and HOME.getProperty(flix_trailer.GEN) == self.gen:
                        self.requested = ""
                        _stop_player()
                        log("tráiler llegado tras cerrar la ficha: parado")
                else:
                    self.requested = ""

    def on_started(self):
        with self.lock:
            if self.state == "playing" and not is_ours(self.file, _playing_file()):
                self.on_other_playback()

    def on_other_playback(self):
        """otra reproducción ha sustituido al tráiler (Palantir, un capítulo): solo se limpia lo nuestro"""
        log("otra reproducción: el tráiler ya no suena")
        self.cleanup()

    def on_end(self):
        with self.lock:                     # como on_av/on_started: no a medias con un stop() de la ficha
            if self.state == "playing":
                log("tráiler acabado")
                self.cleanup()

    def finish(self):
        """el tráiler llegó a su duración (at_end): se para y vuelve el fanart, como si Kodi hubiera avisado del final"""
        with self.lock:
            if self.state == "playing" and is_ours(self.file, _playing_file()):
                log("tráiler acabado")
                _stop_player()
                self.cleanup()

    # --- parar ---
    def playing(self):
        return self.state == "playing"

    def stop(self):
        """salir de la ficha, «Ver», el menú: se para al instante si lo que suena es lo suyo"""
        self.stopped_at = time.time()
        self.closed = True
        with self.lock:
            if self.state == "playing" and is_ours(self.file, _playing_file()):
                _stop_player()
            elif self.state == "loading" and self.requested:
                _stop_late()        # el PlayMedia ya está pedido: si aparece, se para (también lo mira on_av)
            if self.state in ("loading", "playing"):
                # con un PlayMedia aún por llegar, requested se conserva: on_av lo para si aparece
                self.cleanup(keep_requested=self.state == "loading" and bool(self.requested))
            self.state = "done"

    def cleanup(self, keep_requested=False):
        if not keep_requested:
            self.requested = ""
        self.win.clearProperty(ON)
        for p in (ACTIVE, LOADING, ON_HOME):
            HOME.clearProperty(p)
        if self.muted_by_us:
            if _marker():       # si full() ya lo quitó, el silencio que haya ahora es del usuario: no se toca
                set_mute(False)
            self.muted_by_us = False
        if self.begun:
            self.begun = False
            if HOME.getProperty(GEN) == self.gen:   # si el usuario pidió otro con «Tráiler», FLAG es de ese: no se quita
                _done()
        self.state = "done"

    # --- pantalla completa (botón «Tráiler») ---
    def attach(self, win):
        """la ficha de película se reabre tras la pantalla completa: el recuadro vuelve a enseñar el tráiler"""
        self.win = win
        if self.playing():
            win.setProperty(ON, "1")

    def to_fullscreen(self):
        """el que suena, a pantalla completa por el mismo segundo; con sonido (lo ha pedido el usuario)"""
        if not self.playing():
            return False
        if self.muted_by_us:
            set_mute(False)
            self.muted_by_us = False
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
        return True

    def wait_fullscreen(self, mon=None, timeout=600):
        """ficha de película: espera a que se deje la pantalla completa (Atrás) o acabe; True si sigue sonando. Si en 5 s
        no llega a verse la pantalla completa (ActivateWindow no cuajó) vuelve ya con playing(): el tráiler sigue en su
        recuadro"""
        mon = mon or xbmc.Monitor()
        t0, seen = time.time(), False
        while time.time() - t0 < timeout and self.playing():
            full = xbmc.getCondVisibility("Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd)")
            if seen and not full:
                return self.playing()
            seen = seen or full
            if not seen and time.time() - t0 > 5:       # ActivateWindow no cuajó: no se espera 10 minutos
                return self.playing()
            if mon.waitForAbort(0.1):
                return False
        return self.playing()


def choose():
    """Ajustes → «Tráiler automático en la ficha»: No / Con sonido / Sin sonido"""
    import flix_picker
    cur = MODES.index(mode())
    i = flix_picker.pick("Tráiler automático en la ficha", list(LABELS),
                         "Al abrir la ficha de una película o de una serie, a los pocos segundos el tráiler empieza "
                         "solo, arriba a la derecha. «Tráiler» lo pasa a pantalla completa; al salir de la ficha o "
                         "pulsar «Ver» se para. «Sin sonido» silencia Kodi mientras suena.",
                         current=cur)
    if i >= 0:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (SETTING, MODES[i]) if MODES[i] else "Skin.Reset(%s)" % SETTING)


def full():
    """botón «Tráiler» de la serie con el automático en marcha (Includes_Flix, 5251: flix_tr_auto). Corre en otro
    proceso: quita el silencio del automático y su marca persistente. El AutoTrailer de la ficha sigue creyendo que lo
    silenció él, pero en cleanup() solo lo quita si la marca sigue puesta: así no desmuta un silencio que el usuario
    ponga durante la pantalla completa.
    Si aún no hay imagen (flix_tr_on sin poner: entre el PlayMedia y onAVStarted no hay rueda ni nada que pasar a
    pantalla completa) se sigue el camino de siempre del botón: flix_trailer.play_series con la URL de la serie (mismo
    proceso, sin pasar la URL por RunScript). El AutoTrailer de la ficha lo ve sin dañar nada: su begin() ya no es el
    GEN actual, así que ni arma stop_late ni cierra FLAG (run/cleanup); si llega la imagen del mismo tráiler la adopta y
    la limpia cuando el vigilante de play_series la para"""
    if _marker():
        set_mute(False)
    if not HOME.getProperty(ON_HOME):
        url = HOME.getProperty("flix_series_trailer")
        if url:
            import flix_trailer
            flix_trailer.play_series(url)
        return
    xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    {"ajuste": choose, "full": full}.get(arg, lambda: None)()
