"""Sección de Palantir desplegada en filas (versión TV, ventana FlixSection.xml).

Uso: RunScript(special://skin/scripts/flix_section.py,<variable p3…>,<título>)
Se carga SOLO al entrar: las filas se piden a Palantir una a una (Palantir atiende de una en una, ~4 s cada
una) y van apareciendo; con caché de 30 min (flix_rows.fetch) volver a entrar es instantáneo.
  fila de listado  -> carátulas (película = reproducir, serie = temporadas vía flix_series.py)
  fila de submenú  -> tarjetas (sagas, calidad, letras…): al abrir una, su rejilla de carátulas
  último "Más…" de un listado -> tarjeta "Ver más" que abre la página siguiente en rejilla
"""
import os
import sys
import threading

import xbmc
import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_cache  # noqa: E402
import flix_rows  # noqa: E402
from flix_search import to_listitem  # noqa: E402

HOME = xbmcgui.Window(10000)
FIRST, NROWS = 5401, 16
RETRY = 5490            # botón de reserva (FlixSection.xml): foco mientras no hay filas; OK = reintentar
ROW_LIMIT = 40
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)


def log(msg):
    xbmc.log("[flix_section] %s" % msg, xbmc.LOGINFO)


def make_item(f, row):
    li = to_listitem(f)
    if flix_rows.is_more(f):
        li.setLabel("Ver más")
        li.setProperty("card", "text")
        li.setProperty("open", "grid")
    elif row["kind"] == "coll":
        li.setProperty("card", "text" if flix_rows.is_generic(f) else "band")
        li.setProperty("open", "grid")
    elif f.get("filetype") == "directory":
        li.setProperty("open", "series")
    else:
        li.setProperty("open", "play")
    return li


class SectionWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.var = kwargs.get("var")
        self.title = kwargs.get("title")
        self.stop = False
        self.started = False
        self.rows = {}           # id de lista -> fila
        self.slot_of = {}        # ruta de la fila -> id de lista
        self.shown = {}          # id de lista -> títulos pintados

    def onInit(self):
        self.setProperty("fs_title", self.title)
        if not self.started:
            self.started = True
            threading.Thread(target=self.load, daemon=True).start()

    def load(self):
        """1) lo guardado al momento, aunque esté caducado; 2) Palantir solo para lo caducado o sin caché, por detrás,
        en orden, sin mover la selección (auditoría REND-02: antes ~40 s con la caché caducada)"""
        self.setProperty("fs_empty", "")
        self.setProperty("fs_status", "cargando…")
        rows = flix_rows.section_rows(self.var, stale_ok=True)
        pending = []
        for row in rows:
            if self.stop:
                return
            files, fresh = flix_rows.peek(row["path"])
            if files:
                self.show(row, files, "caché" if fresh else "caché antigua")
            if not fresh:
                pending.append(row)
        for k, row in enumerate(pending):
            if self.stop:
                break
            try:
                files, _ = flix_rows.fetch(row["path"], force=True, save=False)
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row["label"], e))
                continue
            if files and not self.stop:
                self.show(row, files, "Palantir")
            if k % 4 == 3:
                flix_rows.flush()
        flix_rows.flush()
        self.setProperty("fs_status", "")
        if not self.slot_of and not self.stop:
            self.setProperty("fs_empty", "1")       # botón 5490: "Sin contenido · OK para reintentar"
            log("sección %s sin filas" % self.title)

    def show(self, row, files, origin):
        """pinta una fila: nueva -> siguiente hueco; ya pintada -> solo si cambió, conservando la selección"""
        files = files[:ROW_LIMIT] + [f for f in files[ROW_LIMIT:] if flix_rows.is_more(f)][:1]
        lid = self.slot_of.get(row["path"])
        if lid is None:
            if len(self.slot_of) >= NROWS:
                return
            lid = FIRST + len(self.slot_of)
            self.slot_of[row["path"]] = lid
            self.rows[lid] = row
            self.shown[lid] = files
            self.setProperty("fs_row%d" % (lid - FIRST + 1), row["label"])
            self.getControl(lid).addItems([make_item(f, row) for f in files])
            if lid == FIRST:
                self.setFocusId(lid)
        else:
            if flix_cache.same_items(self.shown.get(lid), files):
                return
            self.shown[lid] = files
            lst = self.getControl(lid)
            pos = lst.getSelectedPosition()
            lst.reset()
            lst.addItems([make_item(f, row) for f in files])
            if pos > 0:
                lst.selectItem(min(pos, len(files) - 1))
        log("fila %s [%s]: %d (%s)" % (row["label"], row["kind"], len(files), origin))

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.stop = True
            self.close()
            return
        super().onAction(action)

    def onClick(self, control_id):
        if control_id == RETRY and self.getProperty("fs_empty") == "1":
            threading.Thread(target=self.load, daemon=True).start()
            return
        if control_id not in self.rows:
            return
        item = self.getControl(control_id).getSelectedItem()
        if not item:
            return
        path, how = item.getPath(), item.getProperty("open")
        HOME.setProperty("flix_title", item.getProperty("P3Titulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.title, item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def main():
    var = sys.argv[1] if len(sys.argv) > 1 else "p3Peliculas"
    title = sys.argv[2] if len(sys.argv) > 2 else "Películas"
    import xbmcvfs
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", var=var, title=title)
    win.doModal()
    win.stop = True
    del win


if __name__ == "__main__":
    main()
