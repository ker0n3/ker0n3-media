"""Diagnóstico en kodi.log (y en Android también en /sdcard/Download/flix_diag.log, legible por ADB aunque Fire OS
no deje leer kodi.log). Uso:
  RunScript(special://skin/scripts/flix_log.py,upnext)   onload de Custom_1111_Overlay: cuánto faltaba al final
  RunScript(special://skin/scripts/flix_log.py,confirm)  onload de DialogConfirm: qué aviso sale y si flix_resolving
                                                         lo estaba ocultando («Cargando AllDebrid» en capítulos)"""
import sys
import time

INFO = {
    "upnext": ("Player.Title", "Player.Time", "Player.Duration", "Player.TimeRemaining",
               "VideoPlayer.TVShowTitle", "VideoPlayer.Season", "VideoPlayer.Episode"),
    "confirm": ("Control.GetLabel(1)", "Control.GetLabel(9)", "System.CurrentWindow", "Player.HasVideo",
                "Window.IsActive(progressdialog)", "Window.IsActive(okdialog)", "Window.IsActive(selectdialog)",
                "Window(home).Property(flix_resolving)", "Window(home).Property(flix_autoplay_busy)",
                "Window(home).Property(flix_autoplay_state)", "Window(home).Property(flix_searching)"),
}
DIAG_MAX = 200_000


def diag_line(what, info, now=None):
    stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now if now is not None else time.time()))
    return "%s %s %s\n" % (stamp, what, " ".join("%s=%r" % (k, info[k]) for k in sorted(info)))


def diag_path(platform):
    return "/sdcard/Download/flix_diag.log" if platform == "android" else None


def main():
    import os
    import xbmc
    what = sys.argv[1] if len(sys.argv) > 1 else "?"
    if what == "confirm" and xbmc.getInfoLabel("Window(home).Property(flix_searching)") == "true":
        return                                  # «sin resultados» de cada sección durante la búsqueda: ruido
    if what == "confirm":
        xbmc.sleep(150)                         # Palantir rellena el texto justo después de abrir
    cond = lambda k: k.startswith(("Window.IsActive", "Player.Has"))   # booleanas: getInfoLabel las da vacías
    info = {k: ("sí" if xbmc.getCondVisibility(k) else "no") if cond(k) else xbmc.getInfoLabel(k)
            for k in INFO.get(what, ())}
    xbmc.log("[flix_log] %s %s" % (what, info), xbmc.LOGINFO)
    path = diag_path("android" if xbmc.getCondVisibility("System.Platform.Android") else "")
    if path:
        try:
            if os.path.exists(path) and os.path.getsize(path) > DIAG_MAX:
                os.replace(path, path + ".old")
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(diag_line(what, info))
        except OSError:
            pass


if __name__ == "__main__":
    main()
