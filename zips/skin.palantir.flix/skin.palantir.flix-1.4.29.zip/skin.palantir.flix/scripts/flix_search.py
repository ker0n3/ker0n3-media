# -*- coding: utf-8 -*-
"""Búsqueda unificada Palantir Flix (ventana Python WindowXML).

Uso desde el skin:
  RunScript(special://skin/scripts/flix_search.py)            -> pide texto con el teclado
  RunScript(special://skin/scripts/flix_search.py, <texto>)   -> busca directamente

Cómo funciona:
- Se usa la búsqueda global de Palantir (item "Buscar por título" del menú raíz, descubierto en
  tiempo de ejecución). Devuelve carpetas por categoría ("Películas (8)", "Series (2)", ...).
- Palantir abre su propio teclado al recibir esa ruta: un hilo (KeyboardAccepter) escribe el texto
  y acepta en cuanto aparece. Las carpetas de categoría se listan sin teclado.
- Palantir pone Window(home).Property(p3_play)=true tras buscar y mientras esté puesto reutiliza
  la búsqueda anterior sin preguntar: se limpia antes de cada búsqueda (igual que el skin original).
- Las consultas van por JSON-RPC (Files.GetDirectory) porque en cargas de widget Kodi no muestra
  el teclado del plugin. Codec de rutas Palantir: tools/p3route.py.
"""
import base64
import json
import math
import os
import re
import sys
import threading
import time
import unicodedata
from difflib import SequenceMatcher
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_builtin  # noqa: E402
from flix_common import COLOR_RE, PLUGIN_ROOT, atomic_write, clean, decode_route, encode_route  # noqa: E402,F401

HOME = xbmcgui.Window(10000)
HIST_MAX = 5
SKIN_PATH = xbmcvfs.translatePath("special://skin/")
ROW_IDS = [5201, 5202, 5203, 5204, 5205, 5206, 5207, 5208]
CHIPS = {5301: 1, 5302: 2, 5303: 3, 5304: 4, 5305: 5}
BTN_NEW = 5309
# Clave pública del scraper oficial de Kodi (metadata.themoviedb.org.python). Uso: traducir lo que
# escribe el usuario (inglés / erratas) al título en castellano que usa Palantir.
TMDB_KEY = "f090bb54758cabf231fb605d3e3e0468"
SEARCH_PARALLEL = 1  # Palantir serializa: con 3 hilos cada consulta pasa de 3 a 7-12 s y el total no baja (medido 16-oct)
MAX_ALT_TITLES = 2


def log(msg):
    xbmc.log("[flix_search] %s" % msg, xbmc.LOGINFO)


def rpc(method, params):
    raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
    return json.loads(raw)



# ---------- rutas Palantir ----------




def list_dir(route, props=("file",), retries=2):
    """listado de Palantir; si viene vacío o con error (p. ej. Palantir ocupado sincronizando Trakt al
    arrancar) lo reintenta. Deja el error en el log (antes se perdía y la búsqueda daba 0 sin explicación)."""
    for attempt in range(retries + 1):
        r = rpc("Files.GetDirectory", {"directory": route, "media": "video", "properties": list(props)})
        files = (r.get("result") or {}).get("files") or []
        if files:
            return files
        log("listado vacío (intento %d) %s: %s" % (attempt + 1, route[:70], r.get("error") or "sin elementos"))
        if attempt < retries:
            xbmc.sleep(1500)
    return []


def skin_var(name):
    """valor por defecto de una variable de Includes_Palantir3.xml (rutas fijas de las secciones)"""
    try:
        with xbmcvfs.File("special://skin/xml/Includes_Palantir3.xml") as fh:
            text = fh.read()
    except Exception:  # noqa: BLE001
        return ""
    m = re.search(r'<variable name="%s">(.*?)</variable>' % re.escape(name), text, re.S)
    vals = re.findall(r"<value[^>]*>(.*?)</value>", m.group(1), re.S) if m else []
    return vals[-1].strip().replace("&amp;", "&") if vals else ""


def global_search_route():
    """Item 'Buscar por título' del menú raíz de Palantir (búsqueda global; devuelve carpetas por categoría)."""
    cached = HOME.getProperty("flix_root_search")
    if cached:
        return cached
    for f in list_dir(PLUGIN_ROOT):
        lab = _plain(clean(f.get("label")))
        if (lab.startswith("buscar") or lab.startswith("search")) and ("titulo" in lab or "title" in lab):
            HOME.setProperty("flix_root_search", f["file"])
            return f["file"]
    return ""


SECTIONS = ["películas", "series", "dibujos", "anime", "documentales"]


def _plain(text):
    return "".join(c for c in unicodedata.normalize("NFD", text.lower()) if unicodedata.category(c) != "Mn")


def is_title_search(label):
    """'Por título', 'Buscar por título', 'For title', 'Search by title', '[B]Por título[/B]'…"""
    t = _plain(label)
    # Palantir sigue el idioma de Kodi: en inglés es "For title" / "Search by title" (móvil 16-oct)
    return ("titulo" in t or "title" in t) and not t.rstrip().endswith(":")


ROUTES_FILE = "special://profile/addon_data/%s/search_routes.json" % xbmc.getSkinDir()
ROUTES_TTL = 7 * 86400   # las rutas "Por título" de Palantir apenas cambian; averiguarlas cuesta ~27 s (5 menús)


def _routes_disk(save=None):
    path = xbmcvfs.translatePath(ROUTES_FILE)
    lang = xbmc.getLanguage(xbmc.ISO_639_1)
    if save is not None:
        try:
            atomic_write(path, json.dumps({"ts": time.time(), "lang": lang, "routes": save}))
        except OSError as e:
            log("no guardo rutas: %s" % e)
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("routes") and d.get("lang") == lang and time.time() - d.get("ts", 0) < ROUTES_TTL:
            return d["routes"]
    except (OSError, ValueError):
        pass
    return None


def forget_routes():
    """si una búsqueda no da nada en ninguna sección, las rutas guardadas pueden haber caducado"""
    HOME.clearProperty("flix_section_routes")
    try:
        os.remove(xbmcvfs.translatePath(ROUTES_FILE))
    except OSError:
        pass


def section_search_routes():
    """[(etiqueta, ruta 'Por título'), ...] de cada sección de Palantir, en orden de prioridad.
    Cacheado en home (sesión) y en disco 7 días (la Shield reinicia Kodi a menudo: sin disco, cada primera
    búsqueda costaba ~27 s de menús antes de empezar)."""
    cached = HOME.getProperty("flix_section_routes")
    if cached:
        try:
            return json.loads(cached)
        except ValueError:
            pass
    disk = _routes_disk()
    if disk:
        HOME.setProperty("flix_section_routes", json.dumps(disk))
        log("rutas de búsqueda desde disco: %s" % [o[0] for o in disk])
        return disk
    out = []
    # rutas de sección: primero las fijas de la skin (no dependen del menú raíz de Palantir, que en el
    # móvil llegó vacío al arrancar); si faltan, las del menú raíz
    secs = {}
    for name, var in zip(SECTIONS, ("p3Peliculas", "p3Series", "p3Dibujos", "p3Anime", "p3Documentales")):
        path = skin_var(var)
        if path.startswith("plugin://"):
            secs[name] = {"label": name.capitalize(), "file": path}
    if len(secs) < len(SECTIONS):
        for f in list_dir(PLUGIN_ROOT):
            if f.get("filetype") == "directory":
                secs.setdefault(clean(f.get("label")).lower(), f)
    for name in SECTIONS:
        sec = secs.get(name)
        if not sec:
            continue
        header = clean(sec.get("label"))
        items = list_dir(sec["file"])
        log("menú %s: %s" % (name, [clean(i.get("label")) for i in items][:25]))
        for it in items:
            lab = clean(it.get("label"))
            if lab.endswith(":") and "buscar" not in lab.lower() and "search" not in lab.lower():
                header = lab.rstrip(":").strip()
                continue
            if is_title_search(lab):
                out.append([header, it["file"]])
    log("rutas de búsqueda por sección: %s" % [o[0] for o in out])
    if out:
        HOME.setProperty("flix_section_routes", json.dumps(out))
        _routes_disk(save=out)
    return out


def fetch_plain(route):
    r = rpc("Files.GetDirectory", {
        "directory": route, "media": "video",
        "properties": ["title", "art", "plot", "year", "genre", "rating", "duration", "mpaa", "premiered", "file", "playcount", "resume"],
    })
    return (r.get("result") or {}).get("files") or []








# ---------- TMDB: títulos alternativos ----------
def norm(t):
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def tmdb_search(query):
    """[(título es, título original), ...] de TMDB (películas y series)."""
    url = "https://api.themoviedb.org/3/search/multi?" + urllib.parse.urlencode(
        {"api_key": TMDB_KEY, "language": "es-ES", "query": query, "include_adult": "false"})
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            data = json.load(r)
    except Exception as e:  # noqa: BLE001
        log("tmdb: %s" % e)
        return []
    out = []
    for it in data.get("results", []):
        if it.get("media_type") not in ("movie", "tv"):
            continue
        title = it.get("title") or it.get("name") or ""
        orig = it.get("original_title") or it.get("original_name") or ""
        if title:
            out.append((title, orig))
    return out


ALT_SIMILAR = 0.75


def alt_titles(text):
    """Títulos en castellano (TMDB) para lo que escribió el usuario en otro idioma: solo se aceptan
    resultados cuyo título ORIGINAL contiene el texto (evita falsos amigos: "dune" ≈ "Anatomie d'une chute").
    Tolera erratas recortando el texto si TMDB no devuelve nada."""
    q = text
    results = tmdb_search(q)
    while not results and len(q) > 4:
        q = q[:-1]
        results = tmdb_search(q)
    n0, nq = norm(text), norm(q)
    out = []
    for t, orig in results:
        nt, no = norm(t), norm(orig)
        if not nt or nt == n0 or nt in n0 or n0 in nt:
            continue
        # vale si el título original contiene lo escrito, o si lo escrito se PARECE al título entero (erratas,
        # títulos latinos: "interestelar" -> Interstellar 0,92; "dune" vs "anatomie d une chute" 0,33)
        close = max(SequenceMatcher(None, n0, no).ratio(), SequenceMatcher(None, n0, nt).ratio()) >= ALT_SIMILAR
        if not close and not (nq and re.search(r"\b%s\b" % re.escape(nq), no)):
            continue
        if nt not in [norm(x) for x in out]:
            out.append(t)
        if len(out) >= MAX_ALT_TITLES:
            break
    return out


# ---------- teclado de Palantir ----------
class KeyboardAccepter(threading.Thread):
    """Mientras dura la consulta: escribe el texto en el teclado de Palantir y cierra su diálogo
    "No se han encontrado resultados" (okdialog) si aparece."""

    def __init__(self, text, timeout=180.0):
        super().__init__(daemon=True)
        self.text = text
        self.timeout = timeout
        self.stop = False
        self.typed = False

    def run(self):
        mon = xbmc.Monitor()
        t0 = time.time()
        while not self.stop and time.time() - t0 < self.timeout and not mon.abortRequested():
            if not self.typed and xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                xbmc.sleep(300)
                if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                    rpc("Input.SendText", {"text": self.text, "done": True})
                    self.typed = True
            elif xbmc.getCondVisibility("Window.IsActive(okdialog)"):
                xbmc.executebuiltin("Dialog.Close(okdialog,true)")
                log("cerrado diálogo de Palantir")
            xbmc.sleep(100)


def direct_route(route, text):
    """Ruta 'buscar3' (Palantir pide el texto con su teclado) -> misma SQL ya rellenada con acción de
    listado normal (listado_peliculaS / listado_serieS): sin teclado y ~2 s. None si no es convertible."""
    try:
        j = decode_route(route)
    except Exception:
        return None
    if "'buscar3'" not in j or "'%s'" not in j:
        return None
    sql = re.search(r'"sql": "(.*?)"[,}]', j, re.S)
    if not sql or "FROM" not in sql.group(1).upper():
        return None
    tbl = re.search(r'FROM\s+(\S+)', sql.group(1), re.I).group(1).lower()
    if "serie" in tbl:
        action, content = "listado_serieS", "tvshows"
    else:
        action, content = "listado_peliculaS", "movies"
    q = re.sub(r"[\\'\"()\[\]{}*+?|^$]", ".", text).strip()  # comillas y metacaracteres -> cualquier carácter (es un regex)
    j = j.replace("'buscar3'", "'%s'" % action).replace('"content": \'files\'', '"content": \'%s\'' % content).replace("'%s'", "'" + q + "'", 1)
    return encode_route(j)


def fetch(route, text):
    acc = KeyboardAccepter(text)
    acc.start()
    r = rpc("Files.GetDirectory", {
        "directory": direct_route(route, text) or route, "media": "video",
        "properties": ["title", "art", "plot", "year", "genre", "rating", "duration", "mpaa", "premiered", "file", "playcount", "resume"],
    })
    acc.stop = True
    acc.join(timeout=0.5)
    return (r.get("result") or {}).get("files") or []


# ---------- items ----------
def brackets(label):
    return re.findall(r"\[([^\]]*)\]", clean(label))


def clean_title(label):
    return re.split(r"\s+\(\d{4}\)|\s+\[", clean(label))[0].strip()


def quality_from_label(label):
    m = brackets(label)
    up = (m[-1] if m else "").upper()
    if "4K" in up and "DV" in up:
        return "4K · DV"
    for key, val in (("4K", "4K"), ("DV", "DV"), ("HDR", "HDR"), ("1080", "1080p"), ("720", "720p")):
        if key in up:
            return val
    return ""


def langs_from_label(label):
    m = brackets(label)
    return m[0] if len(m) >= 2 else ""


def to_listitem(f):
    label = f.get("label", "")
    li = xbmcgui.ListItem(label)
    li.setPath(f.get("file", ""))
    li.setArt(f.get("art") or {})
    li.setProperty("IsPlayable", "false")
    li.setProperty("P3Titulo", clean_title(label))
    li.setProperty("P3Calidad", quality_from_label(label))
    li.setProperty("P3IdiomaStr", langs_from_label(label))
    li.setProperty("filetype", f.get("filetype", "file"))
    tag = li.getVideoInfoTag()
    tag.setTitle(clean_title(label))
    tag.setPlot(f.get("plot") or "")
    if f.get("year"):
        tag.setYear(int(f["year"]))
    if f.get("rating"):
        tag.setRating(float(f["rating"]))
    if f.get("genre"):
        tag.setGenres(list(f["genre"]))
    if f.get("duration"):
        tag.setDuration(int(f["duration"]))
    if f.get("mpaa"):
        tag.setMpaa(f["mpaa"])
    if f.get("premiered"):
        tag.setPremiered(f["premiered"])
    tag.setMediaType("tvshow" if f.get("filetype") == "directory" else "movie")
    r = f.get("resume") or {}
    if r.get("position"):
        tag.setResumePoint(float(r["position"]), float(r.get("total") or 0))
    return li


# ---------- historial ----------
def history():
    items = []
    for i in range(1, HIST_MAX + 1):
        v = xbmc.getInfoLabel("Skin.String(flix_hist%d)" % i)
        if v:
            items.append(v)
    return items


def push_history(text):
    items = [text] + [h for h in history() if h.lower() != text.lower()]
    items = items[:HIST_MAX]
    for i in range(1, HIST_MAX + 1):
        val = items[i - 1] if i <= len(items) else ""
        xbmc.executebuiltin(flix_builtin.set_string("flix_hist%d" % i, val))


# ---------- teclado en pantalla (TV y táctil; en táctil Kodi no puede abrir el teclado de Android) ----------
TOUCH = xbmc.getSkinDir().endswith(".touch")
KEYS = list("1234567890qwertyuiopasdfghjklñzxcvbnm'")   # orden QWERTY; FlixSearch.xml: botones 6000 + índice
SYMS = list("1234567890" "@#&_-+()/:" ";!?,.'\"*%=" "¿¡[]$~€º")  # capa de símbolos (tecla ?123), mismo nº de teclas
assert len(SYMS) == len(KEYS)
KEY_SPACE, KEY_BACK, KEY_CLEAR, KEY_ENTER, KEY_TOGGLE, KEY_VOICE = 6090, 6091, 6092, 6093, 6094, 6095
A_CONTEXT, A_VOICE = (101, 117), 300   # mantener OK = menú contextual en nuestra ventana; tecla de voz del mando
KEY_FIRST = 6010  # foco al abrir el teclado (la "q")
BOX = 5309      # caja de búsqueda: tocarla vuelve a mostrar el teclado
PREVIEW = 5290  # tira de carátulas visible encima del teclado mientras se escribe (resultados en vivo)
# búsqueda en vivo (solo táctil) tras una pausa al teclear (cada búsqueda = ~8 llamadas a Palantir, de una en una).
# En la TV no hay búsqueda en vivo: con el mando cada letra tarda >1 s y lanzaba "bat", "batm"… -> solo "Buscar".
LIVE_DELAY, LIVE_MIN = 1.2, 3


# ---------- ventana ----------
class SearchWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.query = kwargs.get("query", "")

    def onInit(self):
        # Kodi vuelve a llamar a onInit al volver de una ficha, una serie o un vídeo: los resultados siguen en la
        # ventana, así que solo se vuelve a enlazar la caja (auditoría PY-02: antes se repetía la búsqueda entera)
        if getattr(self, "started", False):
            try:
                ctl = self.getControl(BOX)
                self.edit = ctl if isinstance(ctl, xbmcgui.ControlEdit) else None
            except Exception:  # noqa: BLE001
                self.edit = None
            self.show_kbd(getattr(self, "kbd", False))  # Kodi devuelve el foco al control por defecto (tecla oculta)
            return
        self.started = True
        self.setProperty("flix_state", "loading" if self.query else "idle")
        self.abort = False
        self.worker = None
        self.typed = self.query
        self._deb = 0
        self.sym = False
        self.paint_keys()
        # caja = control edit en la TV (teclado físico); en la táctil es un botón
        try:
            ctl = self.getControl(BOX)
            self.edit = ctl if isinstance(ctl, xbmcgui.ControlEdit) else None
        except Exception:  # noqa: BLE001
            self.edit = None
        self.set_typed(self.typed)
        self.show_kbd(not self.query)                   # sin texto: teclado a la vista
        if self.query:
            self.start_search(self.query)

    def start_search(self, text, record=True):
        self.abort = False
        self.gen = getattr(self, "gen", 0) + 1          # cada búsqueda su número: la anterior queda obsoleta
        self.worker = threading.Thread(target=self._guarded_search, args=(text, record, self.gen), daemon=True)
        self.worker.start()

    def set_typed(self, text):
        """Texto escrito -> etiqueta de la caja y control edit (sin que cuente como tecleo físico)."""
        self.typed = text
        self.setProperty("flix_typed", text)
        if getattr(self, "edit", None):
            self.edit_seen = text
            self.edit.setText(text)

    def edit_changed(self):
        """onClick de la caja edit: Kodi lo manda por cada cambio de texto (teclado físico o su teclado propio)
        y con Intro sin cambios. Intro = Buscar; un salto de varias letras (teclado de Kodi, pegar) busca ya."""
        text = self.edit.getText()
        prev = getattr(self, "edit_seen", "")
        if text == prev:
            self.type_key(KEY_ENTER)
            return
        self.edit_seen = text
        self.edit_time = time.time()
        self.typed = text
        self.setProperty("flix_typed", text)
        self._deb += 1
        if abs(len(text) - len(prev)) == 1:          # una letra: teclado físico
            if not xbmc.getCondVisibility("Skin.HasSetting(flix_physkbd)"):
                xbmc.executebuiltin("Skin.SetBool(flix_physkbd)")   # en adelante el buscador abre con foco en la caja
            if not self.kbd:
                self.show_kbd(True, focus=BOX)
            if TOUCH:
                threading.Timer(LIVE_DELAY, self._live, args=(self._deb,)).start()
        else:
            self.type_key(KEY_ENTER)

    # --- teclado táctil ---
    def show_kbd(self, on, focus=None):
        self.kbd = on
        self.setProperty("flix_kbd", "1" if on else "")
        if on and not TOUCH:
            if focus is None and getattr(self, "edit", None) and xbmc.getCondVisibility("Skin.HasSetting(flix_physkbd)"):
                focus = BOX                         # ya usó teclado físico: a escribir directamente
            self.setFocusId(focus or KEY_FIRST)
        elif not on and not TOUCH:
            self.focus_results()

    def focus_results(self):
        for rid in ROW_IDS:
            if self.getControl(rid).size():
                self.setFocusId(rid)
                return
        self.setFocusId(BOX)

    def paint_keys(self):
        """Etiquetas de las teclas según la capa (letras / símbolos), como el toggle ?123 de Android."""
        layer = SYMS if self.sym else KEYS
        for i, ch in enumerate(layer):
            self.setProperty("flix_k%d" % i, ch.upper() if ch.isalpha() else ch)
        self.setProperty("flix_ktoggle", "ABC" if self.sym else "?123")

    def voice(self):
        """Dictado: abre el teclado de Kodi y le manda VoiceRecognizer (en ese teclado, mantener OK = voz de
        Android, como antes); lo dictado pasa a la búsqueda."""
        def go():
            xbmc.sleep(500)
            if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                xbmc.executebuiltin("Action(VoiceRecognizer)")
        threading.Thread(target=go, daemon=True).start()
        kb = xbmc.Keyboard(self.typed, "Buscar películas y series")
        HOME.setProperty("flix_voice", "1")         # DialogKeyboard.xml no se autocierra
        try:
            kb.doModal()
        finally:
            HOME.clearProperty("flix_voice")
        if not kb.isConfirmed():
            return
        text = kb.getText().strip()
        if not text:
            return
        self.set_typed(text)
        self._deb += 1
        self.show_kbd(False)
        self.cancel_search()
        self.start_search(text, record=False)

    def type_key(self, control_id):
        if KEY_ENTER == control_id:                 # Buscar: busca ya y oculta el teclado
            self._deb += 1
            self.show_kbd(False)
            text = self.typed.strip()
            if text and text != self.query:
                self.cancel_search()
                self.start_search(text, record=False)
            return
        if KEY_TOGGLE == control_id:
            self.sym = not self.sym
            self.paint_keys()
            return
        if KEY_BACK == control_id:
            self.typed = self.typed[:-1]
        elif KEY_CLEAR == control_id:
            self.typed = ""
        elif KEY_SPACE == control_id:
            if self.typed and not self.typed.endswith(" "):
                self.typed += " "
        else:
            self.typed += (SYMS if self.sym else KEYS)[control_id - 6000]
        self.set_typed(self.typed)
        self._deb += 1
        if TOUCH:   # en vivo solo en la táctil; en la TV se busca al pulsar "Buscar" (pedido de Carlos)
            threading.Timer(LIVE_DELAY, self._live, args=(self._deb,)).start()

    def _live(self, deb):
        if deb != self._deb:
            return                                  # se siguió tecleando
        text = self.typed.strip()
        if not text:
            self.cancel_search()
            self.clear_rows()
            self.query = ""
            self.setProperty("flix_state", "idle")
            return
        if len(text) < LIVE_MIN or text == self.query:
            return
        self.cancel_search()
        self.start_search(text, record=False)

    def cancel_search(self):
        # la búsqueda en curso queda obsoleta al instante (sus resultados ya no se pintan aunque lleguen tarde);
        # no se espera a que Palantir termine la consulta que tenga entre manos
        self.gen = getattr(self, "gen", 0) + 1
        self.abort = False

    def clear_rows(self):
        for i, rid in enumerate(ROW_IDS, 1):
            self.getControl(rid).reset()
            self.setProperty("flix_row%d" % i, "")
        self.getControl(PREVIEW).reset()
        self.setProperty("flix_summary", "")

    def _guarded_search(self, text, record=True, gen=0):
        try:
            self.run_search(text, record, gen)
        except Exception as e:  # noqa: BLE001
            log("búsqueda abortada/fallida: %s" % e)

    def onAction(self, action):
        aid = action.getId()
        if (aid == 61448 and getattr(self, "edit", None) and self.getFocusId() == BOX
                and time.time() - getattr(self, "edit_time", 0) < 0.4):
            return          # retroceso crudo que el edit ya ha aplicado (su clic llega antes): no es "Atrás"
        if aid in (92, 110) and getattr(self, "edit", None) and self.getFocusId() == BOX and self.typed:
            # Retroceso del teclado físico (Kodi lo da como "Atrás") y Atrás del mando de la Shield (Android lo manda
            # como retroceso) en la caja con texto: borra una letra, como el teclado de Kodi
            log("caja: retroceso (accion %d, boton %d)" % (aid, action.getButtonCode()))
            self.set_typed(self.edit.getText()[:-1])
            return
        if aid in (10, 92, 216, 247, 257, 275, 61467, 61448):  # back / previous menu / nav back
            if not getattr(self, "kbd", False) and self.query:
                self.show_kbd(True)                 # Atrás con resultados: vuelve al teclado con lo buscado (NAV-07)
                return
            self.abort = True
            self.close()
            return
        if aid in (7, 135) and getattr(self, "edit", None) and self.getFocusId() == BOX:
            # OK del mando / Intro del teclado físico en la caja (el teclado de Kodi que abre el edit ya lo ha
            # cerrado DialogKeyboard.xml): escribiendo con texto = Buscar; si no, a nuestro teclado
            if self.kbd and self.typed.strip():
                self.type_key(KEY_ENTER)
            else:
                self.show_kbd(True, focus=KEY_FIRST)
            return
        if aid == A_VOICE or (aid in A_CONTEXT and (self.getFocusId() >= 6000 or self.getFocusId() in (BOX, 5300) or 5301 <= self.getFocusId() <= 5305)):
            self.voice()                            # mantener OK en el teclado / caja = hablar
            return
        super().onAction(action)

    def stale(self, gen):
        return self.abort or (gen and gen != getattr(self, "gen", 0))

    def run_search(self, text, record=True, gen=0):
        self.query = text
        HOME.setProperty("flix_query", text)
        self.setProperty("flix_state", "loading")
        self.setProperty("flix_summary", "")
        for i, rid in enumerate(ROW_IDS, 1):
            self.getControl(rid).reset()
            self.setProperty("flix_row%d" % i, "")
        self.getControl(PREVIEW).reset()

        xbmcaddon.Addon("plugin.video.palantir3").setSetting("Query", text)
        if record:
            push_history(text)
        stamp = str(int(time.time()))

        summary = []
        row = 0
        # Palantir pone p3_play=true tras una búsqueda y mientras esté puesto reutiliza la anterior sin preguntar
        # (el skin original la limpia antes de buscar).
        HOME.clearProperty("p3_play")
        HOME.setProperty("flix_searching", "true")
        try:
            self._run_search(text, stamp, gen)
        finally:
            if not gen or gen == getattr(self, "gen", 0):   # una búsqueda vieja no apaga la marca de la nueva
                HOME.clearProperty("flix_searching")

    def _run_search(self, text, stamp, gen=0):
        routes = section_search_routes()
        if not routes:
            log("no encuentro rutas de búsqueda por sección; uso la global")
            routes = [["Resultados", global_search_route()]]
        rows_by_label = {}
        seen = set()
        used = []
        lock = threading.Lock()

        def one(q, label, route, i):
            if self.stale(gen):
                return
            HOME.clearProperty("p3_play")
            t0 = time.time()
            items = fetch("%s&reload=%d%d" % (route, int(time.time() * 1000), i), q)
            if self.stale(gen):
                return
            with lock:
                items = [f for f in items if f.get("file") and f["file"] not in seen]
                log("sección %s %r -> %d (%.1fs)" % (label, q, len(items), time.time() - t0))
                for f in items:
                    seen.add(f["file"])
                if not items:
                    return
                if label not in rows_by_label:
                    if len(rows_by_label) >= len(ROW_IDS):
                        return
                    rows_by_label[label] = []
                rows_by_label[label].extend(items)
                idx = list(rows_by_label.keys()).index(label)
                self.setProperty("flix_row%d" % (idx + 1), "%s (%d)" % (label, len(rows_by_label[label])))
                self.getControl(ROW_IDS[idx]).addItems([to_listitem(f) for f in items])
                self.getControl(PREVIEW).addItems([to_listitem(f) for f in items])
                if idx == 0 and len(rows_by_label[label]) == len(items) and not getattr(self, "kbd", False):
                    self.setFocusId(ROW_IDS[0])
                self.setProperty("flix_summary", "  ·  ".join("%d %s" % (len(v), k.lower()) for k, v in rows_by_label.items()) + "  ·  buscando más…")

        def run_query(q):
            used.append(q)
            threads = []
            for i, (label, route) in enumerate(routes):
                t = threading.Thread(target=one, args=(q, label, route, i), daemon=True)
                threads.append(t)
            # SEARCH_PARALLEL consultas a Palantir a la vez (cada una ~3 s en su servidor)
            pending = list(threads)
            running = []
            while (pending or running) and not self.stale(gen):
                running = [t for t in running if t.is_alive()]
                while pending and len(running) < SEARCH_PARALLEL:
                    t = pending.pop(0)
                    t.start()
                    running.append(t)
                time.sleep(0.05)
            for t in running:
                t.join(timeout=30)

        # 1) lo que escribió el usuario; 2) solo si no hay nada, título en castellano vía TMDB
        run_query(text)
        if not rows_by_label and not self.stale(gen):
            alts = alt_titles(text)
            log("sin resultados para %r; alternativas TMDB: %s" % (text, alts))
            for alt in alts:
                run_query(alt)
                if rows_by_label or self.stale(gen):
                    break
        if self.stale(gen):
            return
        if not rows_by_label:
            forget_routes()     # nada en ninguna sección: por si las rutas guardadas caducaron, la próxima las rehace
        summary = ["%d %s" % (len(v), k.lower()) for k, v in rows_by_label.items()]
        if len(used) > 1:
            summary.append("también: " + ", ".join(u for u in used if u != text))
        self.setProperty("flix_summary", "  ·  ".join(summary))
        self.setProperty("flix_state", "done")
        if not getattr(self, "kbd", False):  # escribiendo: no robar el foco al teclado
            self.focus_results()

    def onClick(self, control_id):
        if control_id == KEY_VOICE:
            self.voice()
            return
        if 6000 <= control_id < 6000 + len(KEYS) or control_id in (KEY_SPACE, KEY_BACK, KEY_CLEAR, KEY_ENTER, KEY_TOGGLE):
            self.type_key(control_id)
            return
        if control_id == BOX:
            if getattr(self, "edit", None):
                self.edit_changed()
            else:
                self.show_kbd(True)
            return
        if control_id in ROW_IDS or control_id == PREVIEW:
            item = self.getControl(control_id).getSelectedItem()
            if not item:
                return
            if self.query:
                push_history(self.query)            # en vivo: al historial solo lo que se ha abierto
            path = item.getPath()
            if item.getProperty("filetype") == "directory":
                xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
            else:
                import flix_play
                tag = item.getVideoInfoTag()
                flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))
        elif control_id in CHIPS:
            text = xbmc.getInfoLabel("Skin.String(flix_hist%d)" % CHIPS[control_id])
            if text:
                self.set_typed(text)
                self.show_kbd(False)
                self.cancel_search()
                self.start_search(text)


def bench(q):
    """Mide latencias: búsqueda global, búsqueda por sección (Películas / Series) y listado de carpeta."""
    HOME.clearProperty("p3_play")
    t0 = time.time(); groups = fetch(global_search_route() + "&reload=%d" % int(time.time()), q); t1 = time.time()
    log("BENCH global %r: %.1fs, %d grupos" % (q, t1 - t0, len(groups)))
    if groups:
        t2 = time.time(); items = fetch_plain(groups[0]["file"]); log("BENCH carpeta %s: %.1fs, %d items" % (clean(groups[0]["label"]), time.time() - t2, len(items)))
    for sec in list_dir(PLUGIN_ROOT):
        name = clean(sec.get("label")).lower()
        if name not in ("películas", "series"):
            continue
        for it in list_dir(sec["file"]):
            if clean(it.get("label")).lower() == "por título":
                HOME.clearProperty("p3_play")
                t3 = time.time(); items = fetch(it["file"] + "&reload=%d" % int(time.time()), q)
                log("BENCH sección %s %r: %.1fs, %d items" % (name, q, time.time() - t3, len(items)))
                break


def ask_text():
    kb = xbmc.Keyboard("", "Buscar en Palantir")
    kb.doModal()
    if not kb.isConfirmed():
        return ""
    return kb.getText().strip()


def main():
    text = sys.argv[1].strip() if len(sys.argv) > 1 else ""
    # gancho de depuración: special://temp/flix_debug.txt con el texto (se borra al usarlo)
    dbg = xbmcvfs.translatePath("special://temp/flix_debug.txt")
    if xbmcvfs.exists(dbg):
        with xbmcvfs.File(dbg) as fh:
            text = fh.read().strip().split("|")[0]
        xbmcvfs.delete(dbg)
        log("debug: query=%r" % text)
        if text.startswith("!bench"):
            bench(text.split(" ", 1)[1] if " " in text else "batman")
            return
        if text == "!clearhist":
            for i in range(1, HIST_MAX + 1):
                xbmc.executebuiltin("Skin.SetString(flix_hist%d,)" % i)
            return
    win = SearchWindow("FlixSearch.xml", SKIN_PATH, "Default", "1080i", query=text)
    win.doModal()
    del win


if __name__ == "__main__":
    main()
