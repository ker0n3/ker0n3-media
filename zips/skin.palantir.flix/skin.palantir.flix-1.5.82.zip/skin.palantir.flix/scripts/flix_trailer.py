"""Botón «Tráiler» de la ficha de película (flix_play.sheet) y de la pantalla de serie (flix_series.py + MyVideoNav).

El tráiler se ve en el reproductor de Kodi como cualquier vídeo (addon YouTube: plugin://plugin.video.youtube/play/
?video_id=…) y al acabar, o con Atrás, se vuelve a donde se estaba: la ficha se reabre (flix_play) y la pantalla de
la serie es una ventana de Kodi que sigue debajo. Sin el addon YouTube no hay botón y todo queda como antes.

De dónde sale: PRIMERO TMDB (/3/{movie|tv}/{id}/videos: español, inglés y sin idioma; YouTube, Trailer y si no
Teaser, oficial y el más reciente) y al final el de Palantir (campo «trailer» de su elemento, id de YouTube).
Palantir lo busca por título y falla (20-oct: el de «Animales» 2026 era «Animales fantásticos: Los secretos de
Dumbledore»).

Mientras dura, Window(home).Property(flix_trailer)=1: VideoFullScreen y el Inicio no lanzan flix_progress ni el aviso
de siguiente capítulo (no es de Palantir). Rehecho el 23-oct sobre 1.5.53 (la versión del 20-oct quedó aparcada:
tapaba las ventanas de debajo con una cubierta y al volver el Inicio se quedaba congelado unos segundos).

Caché por aparato (trailers2.json en addon_data de la skin; trailers.json = la de antes del orden sin VOSE): 7 días, «TMDB no tiene» 1 día, error de red 10 min.
Uso: RunScript(special://skin/scripts/flix_trailer.py,play,<url>)   (botón de la serie, MyVideoNav)
     flix_trailer.resolve(kind, tmdb, palantir) / start(urls) / watch()   (desde Python)
<url> son varias separadas por «|» (resolve): si una no se puede ver (tráileres bloqueados en España), la siguiente."""
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import TMDB_KEY, atomic_write  # noqa: E402

YT = "plugin://plugin.video.youtube/play/?video_id=%s"
API = "https://api.themoviedb.org/3/%s/%s/videos?"
TTL = 7 * 86400
NEG_TTL = 86400
ERR_TTL = 600
MAX_ENTRIES = 2000
TIMEOUT = 6
MAX_KEYS = 4
SEP = "|"
BAD = "bad:"            # clave en la caché de un vídeo que el addon YouTube no pudo dar
FLAG = "flix_trailer"   # Window(home): hay un tráiler en marcha
GEN = "flix_trailer_gen"    # Window(home): marca del último start()
COVER = "flix_trailer_cover"    # Window(home): fondo que tapa la ventana de debajo al volver (FlixTrailerCover)
START_WAIT = 45         # s esperando a que el addon YouTube empiece (sin contar sus preguntas: asistente 1.ª vez)
GONE_WAIT = 1.5         # s sin rueda, vídeo ni pregunta tras haber visto la rueda = no hubo vídeo
ASKING = ("Window.IsActive(yesnodialog) | Window.IsActive(okdialog) | Window.IsActive(selectdialog) | "
          "Window.IsActive(virtualkeyboard) | Window.IsActive(numericinput) | Window.IsActive(progressdialog)")
LATE_WAIT = 20          # s vigilando un tráiler que llegue después de rendirse
AUDIO_LATE = 1.5        # s de imagen sin sonido = el audio se atascó al empezar (audio_guard)
AUDIO_TRIES = 2         # vueltas al principio como mucho
AUDIO_GIVEUP = 15       # s esperando a que la imagen avance (pausa, carga) antes de dejarlo
POLL = 0.1


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_trailer] %s" % msg, xbmc.LOGINFO)
    except ImportError:
        pass


def url_of(v):
    """id de YouTube (lo que guarda Palantir) o URL ya hecha -> URL reproducible; '' si no hay"""
    v = (v or "").strip()
    if not v:
        return ""
    if v.startswith(("plugin://", "http://", "https://")):
        return v
    return YT % v


# TMDB marca «es» los tráileres en versión original subtitulada («Nuevo Tráiler Oficial [VOSE]»): se oían en inglés
# (Los asesinos de la luna, Carlos 24-oct) porque eran los más recientes. Van detrás de los doblados
VOSE_RE = re.compile(r"\bv\.?\s?o\.?\s?s\.?(\s?e\.?)?(?![a-z])|subtitulad", re.I)


def lang_rank(v):
    """0 español doblado, 1 español VOSE, 2 inglés, 3 el resto"""
    lang = v.get("iso_639_1")
    if lang == "es":
        return 1 if VOSE_RE.search(v.get("name") or "") else 0
    return 2 if lang == "en" else 3


def pick(results):
    """claves de YouTube por orden de preferencia: español (doblado y luego VOSE), inglés y resto; Trailer antes que
    Teaser; oficial y el más reciente. Como mucho MAX_KEYS (hay tráileres bloqueados en España: si falla uno se prueba
    el siguiente)"""
    vids = [v for v in results or [] if v.get("site") == "YouTube" and v.get("type") in ("Trailer", "Teaser")
            and v.get("key")]
    vids.sort(key=lambda v: v.get("published_at") or "", reverse=True)
    vids.sort(key=lambda v: (lang_rank(v), v.get("type") != "Trailer", not v.get("official")))
    out = []
    for v in vids:
        if v["key"] not in out:
            out.append(v["key"])
    return out[:MAX_KEYS]


def fetch(kind, tmdb, opener=urllib.request.urlopen):
    """claves de YouTube de los tráileres de TMDB (una consulta: español, inglés y sin idioma); [] si no tiene.
    Excepción = red."""
    q = {"api_key": TMDB_KEY, "language": "es-ES", "include_video_language": "es,en,null"}
    req = urllib.request.Request(API % (kind, tmdb) + urllib.parse.urlencode(q),
                                 headers={"User-Agent": "Ker0n3Media-skin"})
    try:
        with opener(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return []
        raise
    return pick(data.get("results"))


def cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/trailers2.json" % xbmc.getSkinDir())


def _load(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(path, d):
    if len(d) > MAX_ENTRIES:            # fuera lo más viejo
        for k in sorted(d, key=lambda k: d[k][0])[:len(d) - MAX_ENTRIES]:
            del d[k]
    try:
        atomic_write(path, json.dumps(d))
    except OSError as e:
        log("no guardo la caché: %s" % e)


def tmdb_keys(kind, tmdb, path=None, opener=urllib.request.urlopen, now=time.time):
    """claves de YouTube de TMDB con caché; [] si TMDB no tiene (o no se pudo preguntar)"""
    if not str(tmdb or "").isdigit() or str(tmdb) == "0":
        return []
    path = path or cache_path()
    d, k, t = _load(path), "%s:%s" % (kind, tmdb), now()
    hit = d.get(k)
    if isinstance(hit, list) and len(hit) == 2:
        ts, val = hit
        if isinstance(val, str):        # caché de la versión del 20-oct (una sola clave)
            val = [val] if val else []
        ttl = ERR_TTL if val is None else TTL if val else NEG_TTL
        if t - ts < ttl:
            return val or []
    try:
        val = fetch(kind, tmdb, opener)
    except Exception as e:  # noqa: BLE001
        log("TMDB no responde (%s %s): %s" % (kind, tmdb, e))
        val = None
    d[k] = [t, val]
    _save(path, d)
    return val or []


def resolve(kind, tmdb, palantir="", path=None, opener=urllib.request.urlopen, now=time.time):
    """URLs del tráiler por orden (TMDB y al final el de Palantir) unidas con «|» (cabe en una propiedad y en el
    RunScript del botón de la serie); '' si no hay ninguno. kind = 'movie' | 'tv'"""
    urls = [url_of(k) for k in tmdb_keys(kind, tmdb, path, opener, now)]
    pal = url_of(palantir)
    if pal and pal not in urls:
        urls.append(pal)
    bad = _load(path or cache_path())
    return SEP.join(u for u in urls if not _is_bad(bad.get(BAD + u), now()))


def _is_bad(hit, t):
    return isinstance(hit, list) and len(hit) == 2 and t - hit[0] < TTL


def mark_bad(url, path=None, now=time.time):
    """ese vídeo no se puede ver aquí (bloqueado en España…): resolve() lo deja fuera TTL; sin ninguno no hay botón"""
    path = path or cache_path()
    d = _load(path)
    d[BAD + url] = [now(), None]
    _save(path, d)


def available():
    import xbmc
    return xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)")


def no_dash():
    """el addon YouTube sin MPEG-DASH (kodion.mpd.videos) da HLS directo de YouTube en vez de DASH por su proxy
    127.0.0.1:50152. Con DASH YouTube rechazaba trozos (403), el proxy se colgaba y al parar Kodi se congelaba 20-60 s
    (en el móvil casi siempre con el gesto Atrás de Android, que mueve la ventana de Kodi). Con HLS: 1080p, sin fallos
    y salida en 0,1 s (móvil y Fire TV, 23-oct). TV y táctil (Carlos)."""
    try:
        import xbmcaddon
        yt = xbmcaddon.Addon("plugin.video.youtube")
        if yt.getSettingBool("kodion.mpd.videos"):
            yt.setSettingBool("kodion.mpd.videos", False)
            log("addon YouTube: MPEG-DASH desactivado (HLS directo)")
    except Exception as e:  # noqa: BLE001
        log("no pude ajustar el addon YouTube: %s" % e)


def start(urls, cancelled=lambda: False):
    """lanza el tráiler (urls: resolve()) y espera a que haya vídeo (el addon YouTube tarda unos s en resolverlo).
    Si uno falla (bloqueado en España: el addon lo avisa y no da vídeo) se prueba el siguiente. True si empezó;
    False si no, o si cancelled() (Atrás en la ficha mientras cargaba: si el vídeo llega después, se para)."""
    import xbmc
    import xbmcgui
    no_dash()
    home = xbmcgui.Window(10000)
    # el tráiler anterior dejó programado quitar FLAG a los 2 s (done): con dos seguidos lo quitaba en mitad de este y
    # saltaban el aviso de capítulo y las pasadas de progreso (móvil, 23-oct)
    xbmc.executebuiltin("CancelAlarm(flixtrailerend,true)")
    home.setProperty(FLAG, "1")
    home.setProperty(GEN, "%f" % time.time())     # este intento (stop_late de uno anterior no lo toca)
    mon, res = xbmc.Monitor(), ""
    for url in [u for u in urls.split(SEP) if u]:
        log("tráiler: %s" % url)
        res = _try(url, mon, cancelled)
        if res == "ok":
            audio_guard()
            return True
        if res != "failed":
            break
        mark_bad(url)
    else:
        xbmcgui.Dialog().notification("Tráiler", "No hay ningún tráiler que se pueda ver",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
    if res in ("timeout", "late"):      # el addon puede seguir resolviéndolo (Atrás sobre su rueda sí lo retira)
        stop_late()
    done()
    return False


def _try(url, mon, cancelled):
    """'ok' (hay vídeo), 'failed' (el addon no dio vídeo: probar otro), 'cancel', 'late' (Atrás en la ficha antes
    de la rueda: puede llegar luego), 'timeout' o 'abort'.
    Sin vídeo tras la rueda puede ser un fallo del addon (avisa con su notificación: «not available in your
    country»…) o Atrás sobre la rueda (la cancela; la ficha no se entera): sin aviso = cancelado, no se prueba otro
    ni se marca como malo"""
    import xbmc
    import xbmcgui
    xbmc.executebuiltin('PlayMedia("%s",noresume)' % url)     # siempre desde el principio (retomar = un salto)
    original_audio()                    # pista original antes de que se vea la imagen (pick_audio)
    t0, busy_seen, idle_since, toast = time.time(), False, None, False
    while not xbmc.getCondVisibility("Player.HasVideo"):
        if mon.waitForAbort(POLL):
            return "abort"
        if cancelled():
            return "late"               # Atrás en la ficha: el PlayMedia sigue en marcha
        busy = xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)")
        asking = xbmc.getCondVisibility(ASKING)
        if asking:
            t0 = time.time()            # el addon pregunta algo: no corre el tiempo
        busy_seen = busy_seen or busy
        toast = toast or (busy_seen and xbmc.getCondVisibility("Window.IsActive(notification)"))
        idle_since = None if busy or asking or xbmc.getCondVisibility("Player.HasMedia") else idle_since or time.time()
        if busy_seen and idle_since and time.time() - idle_since > GONE_WAIT:
            log("no dio vídeo (%s)" % ("aviso del addon" if toast else "cancelado"))
            return "failed" if toast else "cancel"
        if time.time() - t0 > START_WAIT:
            log("no empezó (tiempo agotado)")
            xbmcgui.Dialog().notification("Tráiler", "No se ha podido reproducir el tráiler",
                                          xbmcgui.NOTIFICATION_INFO, 4000)
            return "timeout"
    if cancelled():
        xbmc.Player().stop()
        return "cancel"
    return "ok"


def pick_audio(streams):
    """índice de la pista original si YouTube añadió doblajes automáticos («American English - dubbed-auto», delante de
    «es-US - original»): Kodi coge la primera y el tráiler en español de Oppenheimer se oía en inglés, con Kodi en
    inglés o en español (el addon YouTube pide los vídeos con hl=en_US; Carlos, 24-oct). None = no tocar (sin doblajes
    automáticos, o sin pista original)"""
    if not any("dubbed" in (a.get("name") or "").lower() for a in streams or []):
        return None

    def original(a):
        name = (a.get("name") or "").lower()
        return a.get("isoriginal") or (" original" in " " + name and "dubbed" not in name)
    return next((a.get("index") for a in streams if original(a)), None)


def rpc(method, params):
    import xbmc
    r = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return r.get("result")


def to_start():
    rpc("Player.Seek", {"playerid": 1, "value": {"time": {"hours": 0, "minutes": 0, "seconds": 0, "milliseconds": 0}}})


def original_audio(wait=START_WAIT):
    """pasa a la pista original (pick_audio) en cuanto el reproductor da la lista de pistas, en un hilo. Kodi la da
    unos segundos ANTES de la imagen: cambiada entonces suena desde el principio (Fire TV, Carlos 24-oct). Cambiada
    con el vídeo ya en marcha, en Fire TV se queda MUDA hasta un salto: si llega tarde se vuelve al principio"""
    import threading
    import xbmc

    def run():
        mon, end = xbmc.Monitor(), time.time() + wait
        while time.time() < end:
            try:
                r = rpc("Player.GetProperties", {"playerid": 1, "properties": ["audiostreams", "currentaudiostream",
                                                                                "time"]}) or {}
                if r.get("audiostreams"):
                    idx = pick_audio(r["audiostreams"])
                    if idx is None or (r.get("currentaudiostream") or {}).get("index") == idx:
                        return
                    rpc("Player.SetAudioStream", {"playerid": 1, "stream": idx})
                    late = xbmc.getCondVisibility("Player.HasVideo") and seconds(r.get("time")) >= 1
                    if late:
                        xbmc.sleep(300)
                        to_start()
                    log("audio original (pista %s%s): YouTube trae doblajes automáticos"
                        % (idx, ", tarde: al principio" if late else ""))
                    return
            except Exception as e:  # noqa: BLE001
                log("no pude elegir el audio: %s" % e)
                return
            if mon.waitForAbort(0.1):
                return
    threading.Thread(target=run, daemon=True).start()


def audio_stuck(pos, rate, paused):
    """Kodi pone la frecuencia del audio (Player.Process(audiosamplerate)) cuando el sonido llega a la salida: «0»
    hasta entonces (y otra vez al cerrar el vídeo). Con AUDIO_LATE s de imagen avanzando y aún «0», no hay sonido"""
    return pos >= AUDIO_LATE and rate in ("", "0") and not paused


def audio_guard(tries=AUDIO_TRIES):
    """a veces el tráiler empieza MUDO: inputstream.adaptive no da audio del HLS de YouTube (en el log «stream
    stalled» y ningún «Creating audio stream») y no llega hasta un salto (Shield, Carlos 25-oct; Fire TV 24-oct). Si
    a los AUDIO_LATE s de imagen no suena, se vuelve al principio: el salto arranca el audio. En un hilo"""
    import threading
    import xbmcgui
    home = xbmcgui.Window(10000)
    threading.Thread(target=_audio_guard, args=(home, home.getProperty(GEN), tries), daemon=True).start()


def _audio_guard(home, gen, tries):
    import xbmc
    mon, player = xbmc.Monitor(), xbmc.Player()
    for n in range(tries + 1):
        armed, t0 = False, time.time()      # armed: posición ya por debajo de AUDIO_LATE (el salto anterior hecho)
        while True:
            if mon.waitForAbort(0.2) or home.getProperty(GEN) != gen or not home.getProperty(FLAG):
                return
            if not xbmc.getCondVisibility("Player.HasVideo"):
                return
            rate = xbmc.getInfoLabel("Player.Process(audiosamplerate)")
            if rate not in ("", "0"):
                if n:
                    log("audio arrancado al volver al principio")
                return
            try:
                pos = player.getTime()
            except RuntimeError:
                return
            armed = armed or pos < AUDIO_LATE
            if armed and audio_stuck(pos, rate, xbmc.getCondVisibility("Player.Paused | Player.Caching")):
                break
            if time.time() - t0 > AUDIO_GIVEUP:
                return
        if n == tries:
            log("tráiler sin sonido: sigue mudo tras %d vueltas al principio" % tries)
            return
        log("tráiler sin sonido a los %.1f s: al principio (%d)" % (pos, n + 1))
        to_start()


def seconds(t):
    t = t or {}
    return t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)


def stop_late(wait=LATE_WAIT):
    """el PlayMedia ya lanzado no se puede retirar: si el vídeo llega después de rendirse (o de cancelar), se para
    al aparecer (si no, sonaría detrás de la ficha)"""
    import threading
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    gen = home.getProperty(GEN)

    def run():
        mon, t0 = xbmc.Monitor(), time.time()
        # se retira si se pide otro tráiler o Palantir resuelve algo (Ver la peli justo después): no es el tráiler
        while time.time() - t0 < wait and home.getProperty(GEN) == gen and not home.getProperty("flix_resolving"):
            if xbmc.getCondVisibility("Player.HasVideo"):
                xbmc.Player().stop()
                log("tráiler llegado tarde: parado")
                return
            if mon.waitForAbort(POLL * 3):
                return
    threading.Thread(target=run, daemon=True).start()


def watch():
    """espera a que acabe el tráiler o se salga de él (Atrás). Vuelve en cuanto se deja la pantalla completa, sin
    esperar a que el reproductor acabe de parar (se para aquí mismo, sin el segundo de flix_stop): así la ficha se
    reabre enseguida y apenas asoma la ventana de debajo. Solo tras haber visto el vídeo a pantalla completa: al
    empezar hay vídeo un instante antes de que se abra esa ventana. Pausa la de Kodi; saltos no hay (Kodi trata el
    HLS de YouTube como emisión en directo)."""
    import xbmc
    mon = xbmc.Monitor()
    seen_full = False
    while xbmc.getCondVisibility("Player.HasMedia"):
        full = xbmc.getCondVisibility("Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd)")
        if seen_full and not full:
            xbmc.Player().stop()
            break
        seen_full = seen_full or full
        if mon.waitForAbort(POLL):
            break
    done()


def done():
    """fin del tráiler: flix_trailer se quita 2 s más tarde (el onunload de VideoFullScreen la mira y puede llegar
    después de que el reproductor haya parado)"""
    import xbmc
    xbmc.executebuiltin("AlarmClock(flixtrailerend,ClearProperty(%s,home),00:02,silent)" % FLAG)


SERIES_RELOAD = 15      # s esperando a que la pantalla de la serie se recargue al volver del tráiler


def play_series(urls):
    """botón de la serie (MyVideoNav 5251). Al volver del vídeo Kodi recarga la carpeta (unos s en negro con
    «Cargando…» y sin nada enfocado): mientras, la tapa el fondo de la serie (FlixTrailerCover) y al acabar el foco
    vuelve a «Tráiler»"""
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    if not start(urls):
        return
    home.setProperty(COVER, home.getProperty("flix_open_fanart") or "flix/white.png")
    try:
        watch()
        folder, mon, t0 = home.getProperty("flix_series_folder"), xbmc.Monitor(), time.time()
        while time.time() - t0 < SERIES_RELOAD and not mon.waitForAbort(POLL):
            if xbmc.getInfoLabel("Container.FolderPath") == folder and xbmc.getCondVisibility("Control.IsVisible(5251)"):
                xbmc.executebuiltin("SetFocus(5251)")
                break
    finally:
        home.clearProperty(COVER)


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "play" and sys.argv[2]:
        play_series(sys.argv[2])
