"""Progreso de películas igual en todas las filas.

Palantir guarda el progreso real en addon_data/plugin.video.palantir3/watched.db (lo sube a Trakt y lo baja al
sincronizar), pero cada fila del Inicio sale de su caché (cache.db, hasta 3 días) con el porcentaje del momento en
que se generó, y Kodi no vuelve a pedir una fila mientras su ruta no cambie. Resultado: la misma película con 35 %
en Top 10, 21 % en Tendencias y sin barra en otra fila.

Este script (solo lee watched.db; no toca Trakt ni el scrobbling de Palantir):
  1. corrige percentPlayed/playCount/totalTime/lastPlayed de cada película en las listas de cache.db
     (pickle de Palantir, reescrito byte a byte igual salvo esos campos); "Seguir viendo" se borra de la caché si
     ha cambiado o hay algo visto después, para que Palantir la regenere con su orden y sus reglas;
  2. corrige el "resume" de la caché de las pantallas de sección (rows_cache2.json del skin).
El Inicio TV (flix_inicio.py) pinta sus filas desde rows_cache2.json y las repinta cuando cambia
Window(home).Property(flix_progress_wsig); el táctil corrige las suyas (flix_home.sync_progress). El antiguo paso 3
(recargar las filas de Kodi de Home.xml que no cuadraban) no hacía nada desde la 1.5.43, sin filas en Home.xml, y se
quitó (revisión 29-oct ARR-11).
Se lanza al abrir el Inicio, al cerrar el vídeo y al cerrar el menú contextual (limpiar progreso, marcar como
vista); repite la pasada unos segundos después porque Palantir escribe watched.db con algo de retraso.
Uso: RunScript(special://skin/scripts/flix_progress.py,home|video|menu)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import pickle
import re
import sqlite3
import time
import types

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath(flix_common.P3DATA_REL)
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
ROWS_CACHE = flix_rows.CACHE_FILE
# las últimas pasadas recogen las listas que Palantir regenera al recargar una fila (llegan sin estado). La 4.ª de
# «home» a 35 s: a 25 s coincidía con la sincronización de vistos de Palantir (flix_p3sync lista su raíz a +20 s y
# Palantir escribe watched.db a +29 s: «Error al sincronizar vistos: NoneType… fetchall», Shield 5-nov; revisión
# 7-nov PY-04)
PASSES = {"home": [0, 4, 12, 35], "video": [2, 6, 15, 30], "menu": [1, 3, 8, 15, 25, 40]}
TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')
CONTENT_RE = re.compile(r'"content": \'(\w+)')


_LAST_LOG = [""]


def log(msg):
    xbmc.log("[flix_progress] %s" % msg, xbmc.LOGINFO)
    _LAST_LOG[0] = msg[:500]


def flush_log():
    """la última línea de la pasada en Window(home).Property(flix_progress_log), legible por JSON-RPC (en Fire OS no
    se puede leer kodi.log). Antes se escribía la propiedad en CADA línea (revisión 7-nov PY-31)"""
    if _LAST_LOG[0]:
        HOME.setProperty("flix_progress_log", _LAST_LOG[0])


# ---------- verdad: watched.db de Palantir ----------
def truth():
    """{tmdb(str): (playcount, progress %, runtime s, lastPlayed)}; None si no se puede leer. {} = base sin
    películas (quien solo ve series): NO es «sin watched.db» (auditoría 22-oct B-06)"""
    try:
        return flix_common.watched_movies(WATCHED_DB)
    except Exception as e:  # noqa: BLE001  (p. ej. watched.db vacío sin tablas)
        log("watched.db: %s" % e)
        return None


ABSENT = object()   # campo que NO debe estar
_UNSET = object()   # fechas de seguimiento aún sin leer (solo si hay esa lista en la caché)

# Series: vista = playCount 1 (✓), a medias = SHOW_STARTED (▶). La regla está en flix_common (show_rule): el clic en
# una serie la usa sin cargar este módulo (revisión 29-oct DAT-06) y así no hay dos copias.
SHOW_STARTED = flix_common.SHOW_STARTED
show_rule = flix_common.show_rule


def truth_shows():
    """{tmdb(str): playCount que toca a la serie (1 vista, SHOW_STARTED a medias)}; las demás no están"""
    path = flix_common.watched_db(WATCHED_DB)
    if not os.path.exists(path):
        return None
    db = flix_common.watched_connect(path, snapshot=False, timeout=5)
    try:
        eps = {r[0]: (r[1] or 0, r[2] or 0) for r in db.execute(
            "SELECT tmdb_id, SUM(playcount > 0), SUM(progress > 0) FROM episodes_watched GROUP BY tmdb_id")}
        out = {}
        for tmdb, total, complete, hidden in db.execute(
                "SELECT tmdb_id, num_total_episodios, completa, ocultar FROM shows_watched"):
            pc = show_rule(total, complete, hidden, *eps.get(tmdb, (0, 0)))
            if pc:
                out[str(tmdb)] = pc
        return out
    finally:
        db.close()


def show_pc(S, tmdb):
    return (S or {}).get(str(tmdb), 0)


def fields(row):
    """campos de un P3Item de película tal como los escribe Palantir al generar la lista. Sin fila en watched.db
    (sin ver) Palantir NO pone esos campos: si los encuentra a None revienta al reproducir (float(None), línea 492;
    Spider-Man desde el Top 10, 19-oct) -> se quitan"""
    if row is None:
        return {"percentPlayed": ABSENT, "playCount": ABSENT, "totalTime": ABSENT, "lastPlayed": ABSENT}
    playcount, progress, runtime, last = row
    return {"percentPlayed": progress, "playCount": playcount, "totalTime": runtime, "lastPlayed": last}


# ---------- 1. cache.db de Palantir ----------
class _Unpickler(pickle.Unpickler):
    """las clases de Palantir (libs.*) no se pueden importar fuera de su proceso: se sustituyen por clases vacías
    con el mismo módulo y nombre, registradas en sys.modules para que pickle.dumps las vuelva a escribir igual"""

    def find_class(self, module, name):
        if module.split(".")[0] == "libs":
            mod = sys.modules.get(module)
            if mod is None:
                parts = module.split(".")
                for i in range(1, len(parts) + 1):
                    sys.modules.setdefault(".".join(parts[:i]), types.ModuleType(".".join(parts[:i])))
                mod = sys.modules[module]
            cls = getattr(mod, name, None)
            if cls is None:
                cls = type(name, (), {})
                cls.__module__, cls.__qualname__ = module, name
                setattr(mod, name, cls)
            return cls
        return super().find_class(module, name)


def _loads(data):
    import io
    return _Unpickler(io.BytesIO(data)).load()


def fix_more(cid, items):
    """En las listas de las filas del Inicio (Widget…) el «más…» de Palantir apunta a la página 0: la misma lista
    otra vez, con un solo título nuevo (Carlos, 21-oct: Series en seguimiento repetidas). Se pasa a la página 1, la
    siguiente de verdad (comprobado en la Shield: 0 repetidas). True si cambió algo"""
    if not str(cid).startswith("Widget"):
        return False
    changed = False
    for it in items:
        v = getattr(it, "__dict__", None)
        if isinstance(v, dict) and v.get("specialSort") == "bottom" and v.get("page") == 0 and "limitItemList" in v:
            v["page"] = 1
            changed = True
    return changed


CACHE_IDX = "flix_progress_cidx"   # Window(home): {id: "expires:bytes"} de los pickles de cache.db tras la última pasada


def cache_index():
    """el índice de la pasada anterior; None si no hay (1.ª de la sesión) o está roto"""
    try:
        idx = json.loads(HOME.getProperty(CACHE_IDX) or "")
    except ValueError:
        return None
    return idx if isinstance(idx, dict) else None


def fix_palantir_cache(W, S=None, only_changed=False):
    """devuelve nº de listas corregidas/borradas. only_changed: watched.db no ha cambiado desde la pasada anterior
    (solo cache.db): se leen únicamente los pickles que Palantir ha rehecho desde entonces (expires o tamaño
    distintos de los apuntados en CACHE_IDX); los demás ya quedaron bien y saldrían igual. Antes cada pasada con la
    huella cambiada leía y volvía a serializar TODOS (22 pickles, ~700 KB en la Shield), 2-4 veces tras cada vídeo
    (revisión 7-nov PY-11)"""
    if not os.path.exists(CACHE_DB):
        return 0
    if S is None:
        S = truth_shows_cached()
    db = sqlite3.connect(CACHE_DB, timeout=5)
    # los cambios se reúnen y se aplican al final en una transacción corta: el 1.er UPDATE/DELETE coge el bloqueo
    # de escritura de cache.db y antes se quedaba cogido mientras se procesaban los pickles que faltaban (16,7 ms
    # en proot; Palantir esperaba para escribir) (revisión 29-oct DAT-17). Las mismas cláusulas WHERE id=? AND
    # data=?: si Palantir la ha rehecho entre medias, no se pisa (8a22e7f)
    changed, dates, writes = 0, _UNSET, []
    try:
        heads = db.execute("SELECT id, expires, length(data) FROM simplecache WHERE type='pickle'").fetchall()
        index = {cid: "%s:%d" % (exp, n or 0) for cid, exp, n in heads}
        old = cache_index() if only_changed else None
        todo = list(index) if old is None else [cid for cid in index if index[cid] != old.get(cid)]
        if not todo:
            rows = []
        elif len(todo) == len(index) or len(todo) > 500:
            rows = db.execute("SELECT id, data FROM simplecache WHERE type='pickle'").fetchall()
        else:                               # de una vez, como siempre: leer-todo y después corregir
            rows = db.execute("SELECT id, data FROM simplecache WHERE type='pickle' AND id IN (%s)"
                              % ",".join("?" * len(todo)), todo).fetchall()
        for cid, data in rows:
            try:
                items = _loads(data)
                if pickle.dumps(items, protocol=4) != data:
                    log("%s: no se reescribe igual, no se toca" % cid)
                    continue
            except Exception as e:  # noqa: BLE001
                log("no leo %s: %s" % (cid, e))
                continue
            if not isinstance(items, list):
                continue
            dirty, unfinished, newest, more = False, False, "", fix_more(cid, items)
            for it in items:
                v = getattr(it, "__dict__", None)
                if isinstance(v, dict) and v.get("content") == "tvshows" and v.get("tmdb") and S is not None:
                    pc = show_pc(S, v["tmdb"])
                    if pc and v.get("playCount") != pc:
                        v["playCount"] = pc
                        dirty = True
                    elif not pc and "playCount" in v:
                        del v["playCount"]
                        dirty = True
                    continue
                if not isinstance(v, dict) or v.get("content") != "movies" or not v.get("tmdb"):
                    continue
                unfinished = unfinished or v.get("especial") == "no_finalizadas"
                newest = max(newest, v.get("lastPlayed") or "")
                want = fields(W.get(str(v["tmdb"])))
                for k, val in want.items():
                    if val is ABSENT:
                        if k in v:
                            del v[k]
                            dirty = True
                    elif v.get(k) != val:
                        v[k] = val
                        dirty = True
            if any(_follow_item_tmdb(it) for it in items[:1]):
                if dates is _UNSET:
                    dates = follow_dates()
                if dates is not None and sort_follow(items, _follow_item_tmdb, dates):
                    dirty = True
            if unfinished:
                # "Seguir viendo": Palantir decide qué entra y en qué orden -> que la regenere
                played_after = any((r[3] or "") > newest and (r[1] or 0) > 0 for r in W.values())
                if dirty or played_after:
                    writes.append(("DELETE FROM simplecache WHERE id=? AND data=?", (cid, data),
                                   "%s borrada (seguir viendo cambió)" % cid, cid, None))
                    _RESUME_DROPPED[0] = True
                    continue
                dirty = more                    # solo el «más…»: se reescribe sin borrarla
            if dirty or more:
                new = pickle.dumps(items, protocol=4)
                writes.append(("UPDATE simplecache SET data=? WHERE id=? AND data=?", (new, cid, data),
                               "%s corregida" % cid, cid, len(new)))
        for sql, args, msg, cid, size in writes:
            if db.execute(sql, args).rowcount != 1:
                index.pop(cid, None)            # Palantir la rehizo entre medias: la próxima pasada la vuelve a mirar
                continue
            changed += 1
            log(msg)
            if size is None:
                index.pop(cid, None)
            else:                               # lo que acabamos de escribir ya está bien (mismo expires)
                index[cid] = "%s:%d" % (index.get(cid, "").split(":")[0], size)
        db.commit()
        HOME.setProperty(CACHE_IDX, json.dumps(index))
    finally:
        db.close()
    return changed


# ---------- orden de «Series en seguimiento» ----------
# Palantir la ordena por el último capítulo de watched.db, pero lo que baja de Trakt lo apunta con la hora de la
# SINCRONIZACIÓN (con milésimas: «…07:06:16.863Z») y no con la de verdad (siempre «.000Z»). En el móvil (23-oct) 8
# series selladas a las 09:06 pasaron delante de ¿Es una Tarta?, vista la noche antes; y algunas (Manhunt T1E1,
# Gilmore T4E4) se vuelven a sellar en cada sincronización (Shield 21-oct, móvil 23-oct). Solo se cambia el ORDEN
# de la lista: watched.db (y Trakt) no se tocan.
STAMPS_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/p3_sellos.json" % xbmc.getSkinDir())
SEED = "semilla"
_FOLLOW = [0.0, None]


def is_sync_stamp(last):
    """¿hora puesta por Palantir al sincronizar (milésimas distintas de 0)?"""
    m = re.search(r"\.(\d+)Z$", last or "")
    return bool(m) and int(m.group(1)) != 0


def show_dates(rows, stamps):
    """({tmdb: fecha del último capítulo}, ¿stamps cambió?) de las filas (tmdb, temporada, capítulo, lastPlayed).
    Un capítulo que llega sellado por 1.ª vez (visto en otro aparato) vale con la hora de su llegada, que se guarda
    en stamps: si Palantir lo vuelve a sellar, se sigue usando esa. Los sellos que ya había al estrenar esto (SEED)
    no cuentan: son los que Palantir repite en cada sincronización"""
    dates, changed = {}, False
    for tmdb, season, episode, last in rows:
        if not last:
            continue
        if is_sync_stamp(last):
            key = "%s:%s:%s" % (tmdb, season, episode)
            first = stamps.get(key)
            if first is None:
                stamps[key] = first = last
                changed = True
            if first == SEED:
                continue
            last = first
        if last > dates.get(str(tmdb), ""):
            dates[str(tmdb)] = last
    return dates, changed


def follow_dates(max_age=5):
    """fechas para ordenar «Series en seguimiento» (leídas como mucho cada max_age s); None si no se puede"""
    if _FOLLOW[1] is not None and time.time() - _FOLLOW[0] <= max_age:
        return _FOLLOW[1]
    try:
        rows = flix_common.watched_query(WATCHED_DB, "SELECT tmdb_id, season, episode, lastPlayed FROM episodes_watched")
        if rows is None:
            return None
        import flix_cache
        with flix_cache.file_lock(STAMPS_FILE):
            try:
                with open(STAMPS_FILE, encoding="utf-8") as fh:
                    stamps, seed = json.load(fh), False
                if not isinstance(stamps, dict):
                    raise ValueError("no es un diccionario")
            except (OSError, ValueError):
                # 1.ª vez (o fichero roto): lo sellado hasta ahora no dice cuándo se vio
                stamps, seed = {"%s:%s:%s" % r[:3]: SEED for r in rows if is_sync_stamp(r[3])}, True
            dates, changed = show_dates(rows, stamps)
            if seed or changed:
                flix_cache.atomic_write(STAMPS_FILE, json.dumps(stamps))
    except Exception as e:  # noqa: BLE001
        log("orden de Series en seguimiento: %s" % e)
        return None
    _FOLLOW[:] = [time.time(), dates]
    return dates


def sort_follow(entries, tmdb_of, dates):
    """ordena EN SU SITIO las series de la lista por fecha (la más reciente primero); sin fecha, detrás y en el orden
    de Palantir; lo demás («más…») no se mueve. True si cambió algo"""
    idx = [i for i, e in enumerate(entries) if tmdb_of(e)]
    shows = [entries[i] for i in idx]
    ordered = sorted(shows, key=lambda e: dates.get(tmdb_of(e), ""), reverse=True)   # estable: empates igual
    if all(a is b for a, b in zip(ordered, shows)):
        return False
    for i, e in zip(idx, ordered):
        entries[i] = e
    return True


def ordered_follow(files):
    """«Series en seguimiento» de JSON-RPC (Inicio, secciones) en orden de verdad y sin las series terminadas que ya
    has visto enteras (drop_finished). Devuelve una COPIA si cambia algo (la lista puede ser la guardada en caché,
    compartida con otros hilos); si no, la misma lista"""
    if not files or not flix_rows.follow_tmdb(files[0]):
        return files
    kept = drop_finished(files)
    dates = follow_dates()
    if dates is None:
        return kept
    out = list(kept)
    return out if sort_follow(out, flix_rows.follow_tmdb, dates) or kept is not files else files


# ---------- series terminadas (TMDB) ----------
# «El castillo» vista entera y terminada seguía en «Series en seguimiento» (Palantir guarda esa lista hasta 3 días) y
# con ▶ (Carlos, 24-oct). Fuera de la fila: vista entera (truth_shows = 1) Y terminada o cancelada en TMDB. Las que
# siguen en emisión y vas al día se quedan con su ▶ (queda algo por salir). Estado de TMDB guardado 7 días.
TV_STATUS_TTL, TV_STATUS_ERR = 7 * 86400, 3600
_STATUS = {"data": None, "busy": False}


def tv_status_path():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/tvstatus.json" % xbmc.getSkinDir())


def tv_status(tmdb, now=None):
    """'Ended' / 'Canceled' / 'Returning Series'…; None si no se sabe (o caducó)"""
    if _STATUS["data"] is None:
        try:
            with open(tv_status_path(), encoding="utf-8") as fh:
                _STATUS["data"] = json.load(fh)
        except (OSError, ValueError):
            _STATUS["data"] = {}
    hit = _STATUS["data"].get(str(tmdb))
    now = time.time() if now is None else now
    if not hit or now - hit[0] > (TV_STATUS_TTL if hit[1] else TV_STATUS_ERR):
        return None
    return hit[1] or None


def fetch_status(ids, opener=None):
    """estado de TMDB de esas series, en un hilo; al acabar se avisa al Inicio para que repinte (flix_progress_wsig)"""
    if _STATUS["busy"] or not ids:
        return
    _STATUS["busy"] = True

    def run():
        import urllib.request
        import flix_cache
        got = False
        try:
            for tmdb in ids:
                if flix_common.quitting():
                    break           # Kodi se cierra: se guarda lo que haya (APA-03)
                url = "https://api.themoviedb.org/3/tv/%s?api_key=%s" % (tmdb, flix_common.TMDB_KEY)
                try:
                    with (opener or urllib.request.urlopen)(url, timeout=8) as r:
                        st = json.loads(r.read().decode("utf-8", "replace")).get("status") or ""
                except Exception as e:  # noqa: BLE001
                    log("estado de la serie %s en TMDB: %s" % (tmdb, e))
                    st = ""
                _STATUS["data"][str(tmdb)] = [time.time(), st]
                got = got or bool(st)
            # con cerrojo y mezclando con el fichero: lo que guardó otro proceso se queda (revisión 29-oct DAT-14)
            mine = {str(t): _STATUS["data"][str(t)] for t in ids if str(t) in _STATUS["data"]}
            try:
                disk = flix_cache.update_json(tv_status_path(),
                                              lambda d: flix_cache.merge_newer(d, mine, list(mine)))
                for k, v in disk.items():
                    if flix_cache.stamp(v) > flix_cache.stamp(_STATUS["data"].get(k)):
                        _STATUS["data"][k] = v
            except OSError as e:
                log("no guardo el estado de las series: %s" % e)
            if got:
                HOME.setProperty("flix_progress_wsig", "%s|tv%d" % (HOME.getProperty("flix_progress_wsig"),
                                                                  int(time.time())))
        finally:
            _STATUS["busy"] = False
    import threading
    threading.Thread(target=run, daemon=True).start()


_DROPPED = [None]     # series quitadas la última vez que se apuntó en el log


def drop_finished(files, S=None):
    """«Series en seguimiento» sin las vistas enteras que TMDB da por terminadas o canceladas. Las que aún no se
    saben se piden por detrás (la fila se repinta al llegar). La misma lista si no quita nada"""
    S = truth_shows_cached() if S is None else S
    if not S:
        return files
    out, unknown, gone = [], [], []
    for f in files:
        t = flix_rows.follow_tmdb(f)
        if t and S.get(str(t)) == 1:
            st = tv_status(t)
            if st is None:
                unknown.append(str(t))
            elif st in ("Ended", "Canceled"):
                gone.append(str(t))
                continue
        out.append(f)
    if unknown:
        fetch_status(unknown)
    if len(out) != len(files):
        gone = frozenset(gone)
        if gone != _DROPPED[0]:
            # una línea cuando cambian las que se quitan, no en cada repintado de la fila (11 de las 32 líneas de
            # flix_progress de una sesión real; revisión 29-oct ARR-12)
            _DROPPED[0] = gone
            log("Series en seguimiento: fuera %d terminadas y vistas" % (len(files) - len(out)))
        return out
    return files


def _follow_item_tmdb(it):
    v = getattr(it, "__dict__", None)
    return str(v.get("tmdb")) if isinstance(v, dict) and v.get("action") == "play_mis_serieS" and v.get("tmdb") \
        else None


# ---------- 2. listas JSON-RPC (pantallas de sección, Inicio táctil) ----------
_TRUTH = [0.0, None, None]


def truth_cached(max_age=5):
    """watched.db leída como mucho una vez cada max_age s (una pantalla pide varias filas seguidas) Y otra vez en
    cuanto cambia el fichero: una pasada que llegaba antes de que Palantir guardara dejaba aquí lo viejo y el Inicio
    repintaba con ello al avisarle la pasada siguiente (Spider-Man desmarcado seguía con ✓; Carlos, 24-oct)"""
    sig = watched_sig()
    if _TRUTH[1] is None or time.time() - _TRUTH[0] > max_age or _TRUTH[2] != sig:
        try:
            _TRUTH[:] = [time.time(), truth(), sig]
        except Exception as e:  # noqa: BLE001
            log("watched.db: %s" % e)
            return None
    return _TRUTH[1]


_SHOWS = [0.0, None, None]


def truth_shows_cached(max_age=5):
    sig = watched_sig()
    if _SHOWS[1] is None or time.time() - _SHOWS[0] > max_age or _SHOWS[2] != sig:
        try:
            _SHOWS[:] = [time.time(), truth_shows(), sig]
        except Exception as e:  # noqa: BLE001
            log("watched.db series: %s" % e)
            return None
    return _SHOWS[1]


_MISS = object()     # estado de las series aún sin pedir en esta llamada de fix_files


def fix_files(files, W=None):
    """pone en cada película de una lista de Files.GetDirectory el resume/playcount reales; devuelve cuántas cambió"""
    W = truth_cached() if W is None else W
    if W is None or not files:
        return 0
    changed, S = 0, _MISS
    for f in files:
        if not isinstance(f, dict) or not str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/"):
            continue
        try:
            route = flix_rows.decode_route(f["file"])
        except Exception:  # noqa: BLE001
            continue
        m, c = TMDB_RE.search(route), CONTENT_RE.search(route)
        # las series son CARPETAS: antes se saltaban con el filtro de abajo y su ▶/✓ se quedaba como viniera
        # (Carlos, 20-oct: Carrie dejada de seguir con ▶ en el Top 10; La isla de las tentaciones a medias sin ▶)
        if m and c and c.group(1) == "tvshows":
            if S is _MISS:
                # una vez por llamada, al llegar a la 1.ª serie: antes eran 4 os.stat (la huella) por CADA serie, 833
                # en una corrección completa de rows_cache2.json (revisión 29-oct ARR-01/DAT-01). La huella se sigue
                # mirando en cada llamada (ea449b3)
                S = truth_shows_cached()
            if S is not None and int(f.get("playcount") or 0) != show_pc(S, m.group(1)):
                f["playcount"] = show_pc(S, m.group(1))
                changed += 1
            continue
        if f.get("filetype", "file") != "file" or not m or (c and c.group(1) != "movies"):
            continue
        row = W.get(m.group(1))
        total = float(row[2] or 0) if row else 0.0
        pos = round(total * float(row[1] or 0) / 100, 3) if row else 0.0
        want_pc = int(row[0] or 0) if row else 0
        old = f.get("resume") or {}
        if abs(float(old.get("position") or 0) - pos) > 1 or int(f.get("playcount") or 0) != want_pc:
            f["resume"], f["playcount"] = {"position": pos, "total": total}, want_pc
            changed += 1
    return changed


def is_resume_row(path):
    """¿es la fila «Seguir viendo» de Palantir (películas a medias)?"""
    try:
        return "'no_finalizadas'" in flix_rows.decode_route(path or "")
    except Exception:  # noqa: BLE001
        return False


def still_started(files):
    """«Seguir viendo» sin lo que ya no está a medias (progreso quitado o vista), con fix_files ya aplicado.
    Palantir no rehace la fila hasta que caduca: en la táctil se quedaban sin barra (Carlos, 20-oct)"""
    out = []
    for f in files:
        movie = isinstance(f, dict) and str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/") \
            and f.get("filetype", "file") == "file"
        if movie and (int(f.get("playcount") or 0) > 0 or float((f.get("resume") or {}).get("position") or 0) <= 0):
            continue
        out.append(f)
    return out


EP_KEY = "flix_ep"      # tarjeta de capítulo a medias en «Seguir viendo»: «T1 E4»


EP_DAYS = 30            # y solo si se tocó en los últimos 30 días


def half_episodes(db_path=None, now=None, days=EP_DAYS):
    """{tmdb(str): (temporada, capítulo, progreso %, duración s, lastPlayed)} de las series cuyo último capítulo tocado
    se quedó a medias: la misma regla que el aviso «Seguir viendo · TxEy» (flix_series.next_episode). Solo lo de los
    últimos `days` días: en la base de Carlos (11-nov) había 26 series así, casi todas pilotos dejados hace meses, y
    Palantir tampoco enseña en «Seguir viendo» las películas a medias viejas (5 de 48: las del último mes). {} si no
    hay ninguna o no se puede leer"""
    cut = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime((time.time() if now is None else now) - days * 86400))
    try:
        rows = flix_common.watched_query(db_path or WATCHED_DB,
                                         "SELECT tmdb_id, season, episode, progress, runtime, lastPlayed FROM episodes_watched "
                                         "ORDER BY lastPlayed DESC, season DESC, episode DESC")
    except Exception as e:  # noqa: BLE001
        log("watched.db capítulos: %s" % e)
        return {}
    by = {}
    for tmdb, season, episode, progress, runtime, last in rows or []:
        by.setdefault(str(tmdb), []).append((season, episode, progress, last, runtime))
    out = {}
    for k, own in by.items():
        # la última tocada; o, si es un visto que llegó de Trakt con fecha posterior, el siguiente que está a medias
        (season, episode, progress, last, runtime), _ = flix_common.current_episode(own)
        if progress and float(progress) > 0 and (last or "") >= cut:
            out[k] = (int(season), int(episode), float(progress), float(runtime or 0), last or "")
    return out


def _movie_last(f, movies):
    """lastPlayed de una película de la fila ('' si no consta); None si no es una película"""
    if not isinstance(f, dict) or f.get("filetype", "file") != "file":
        return None
    try:
        m = TMDB_RE.search(flix_rows.decode_route(f.get("file") or ""))
    except Exception:  # noqa: BLE001
        return None
    row = (movies or {}).get(m.group(1)) if m else None
    return (row[3] or "") if row else ""


def episode_cards(files, follow_files, eps=None, movies=None):
    """«Seguir viendo» con una tarjeta por serie que tiene un capítulo a medias (Carlos, 11-nov), intercaladas con las
    películas por lo último que se vio. La tarjeta es la propia serie de «Series en seguimiento» (su ruta pone el
    capítulo que toca) con el progreso de ese capítulo; la fila de series no se toca. Sin la lista de seguimiento
    guardada, lo que había"""
    files = [f for f in files or [] if not (isinstance(f, dict) and f.get(EP_KEY))]
    if not follow_files:
        return files
    eps = half_episodes() if eps is None else eps
    if not eps:
        return files
    cards = []
    for f in follow_files:
        ep = eps.get(str(flix_rows.follow_tmdb(f) or ""))
        if not ep:
            continue
        season, episode, pct, runtime, last = ep
        total = runtime if runtime > 0 else 100.0
        card = dict(f, resume={"position": round(total * pct / 100.0, 3), "total": total}, playcount=0)
        card[EP_KEY] = "T%d E%d" % (season, episode)
        card["flix_untimed"] = runtime <= 0             # sin duración: la barra sí, «Quedan…» no
        card["flix_last"] = last
        cards.append(card)
    if not cards:
        return files
    cards.sort(key=lambda c: c["flix_last"], reverse=True)
    if movies is None:
        movies = truth_cached() or {}
    out = []
    for f in files:
        if isinstance(f, dict) and flix_rows.is_more(f):
            out += cards                                 # el «Más…» de Palantir, siempre al final
            cards = []
        else:
            last = _movie_last(f, movies)
            while cards and last is not None and cards[0]["flix_last"] > last:
                out.append(cards.pop(0))
        out.append(f)
    return out + cards


_ROWS_WROTE = [""]   # huella de rows_cache2.json justo después de escribirlo fix_rows_cache con el cerrojo cogido


def fix_rows_cache(W):
    import flix_cache
    with flix_cache.file_lock(ROWS_CACHE) as lock:  # leer-corregir-escribir sin pisar a flix_rows (B-05)
        try:
            with open(ROWS_CACHE, encoding="utf-8") as fh:
                cache = json.load(fh)
        except Exception:  # noqa: BLE001
            return 0
        changed = 0
        for _key, entry in cache.items():
            if isinstance(entry, list) and len(entry) == 2 and isinstance(entry[1], list):
                changed += fix_files(entry[1], W)
        if changed:
            flix_cache.atomic_write(ROWS_CACHE, json.dumps(cache, ensure_ascii=False))   # temporal único (PY-NUEVO-01)
            if getattr(lock, "fh", None):
                # con el cerrojo nadie ha podido escribir entre medias: lo que hay es lo que acabamos de corregir
                # (sin él, file_lock sigue al cabo de 5 s y la pasada siguiente lo vuelve a mirar) (DAT-04)
                _ROWS_WROTE[0] = file_sig(ROWS_CACHE)
            log("rows_cache: %d películas corregidas" % changed)
    return changed


def watched_sig():
    """huella de watched.db y cache.db (fecha y tamaño, también del -wal de SQLite): si no cambian, las cachés ya
    están bien. cache.db cuenta porque Palantir regenera sus listas (al sincronizar con Trakt, al caducar) sin el
    estado: el Top 10 de series volvía sin ✓/▶ aunque watched.db no hubiera cambiado (20-oct)"""
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal", CACHE_DB, CACHE_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def file_sig(path):
    """inodo, fecha (ns) y tamaño de un fichero ('-' si no está). atomic_write pone uno nuevo en cada escritura: se
    nota aunque la fecha y el tamaño coincidan"""
    try:
        st = os.stat(path)
        return "%d:%d:%d" % (st.st_ino, st.st_mtime_ns, st.st_size)
    except OSError:
        return "-"


def rows_sig(sig):
    """huella de lo que usa fix_rows_cache (revisión 29-oct DAT-04): watched.db y su -wal (los dos primeros trozos de
    sig, tomada ANTES de leer), la foto .flixbak si es la que se lee (flix_common.watched_db: al acabar p3sync se
    vuelve a watched.db sin que cambie su fecha) y rows_cache2.json. cache.db no cuenta: no cambia el resultado"""
    src = flix_common.watched_db(WATCHED_DB)
    return "|".join(sig.split("|")[:2] + [file_sig(src) if src != WATCHED_DB else "", file_sig(ROWS_CACHE)])


_RESUME_DROPPED = [False]      # fix_palantir_cache borró «Seguir viendo» de cache.db en esta pasada


def reload_resume_row():
    """«Seguir viendo» del Inicio (TV: su marca de recarga, como flix_p3sync; táctil: fh_refetch_row 5101), otra vez pedida. Al parar un vídeo el
    Inicio la recarga al momento, pero Palantir escribe el progreso ~3 s después (antes lo manda a Trakt): la fila se
    quedaba sin la película recién vista hasta reiniciar, con su carátula en rojo de «empezada» en las demás filas
    (Shield, 2-nov, Spider-Man). La lista de Palantir ya se ha borrado: la rehace con lo nuevo. La marca es la misma
    que pone flix_p3sync (mark_row): si la fila ya se recargó con este mismo estado de watched.db, no se repite
    (revisión 7-nov PY-02)"""
    import flix_p3sync
    if flix_p3sync.mark_row("p3PathPeliculasNoFinalizadas", "5101", flix_p3sync.resume_sig()):
        log("Seguir viendo cambió: recargo la fila")


def one_pass():
    # la huella ANTES de leer watched.db: si Palantir guarda mientras corregimos (marcar justo después de abrir su
    # menú), la siguiente pasada lo ve. Antes se apuntaba la de después y ese cambio no se corregía nunca: el Top 10
    # seguía «sin ver» y Palantir solo ofrecía «Marcar como visto» (Spider-Man, Shield, 25-oct). Si la pasada escribe
    # cache.db, la siguiente repite una vez sin cambiar nada y se queda quieta
    sig = watched_sig()
    # el trabajo (cache.db de Palantir ~0,5 s y rows_cache ~0,7 s por pasada en el S24) solo si watched.db o cache.db
    # cambiaron desde la última vez (REND-05/PY-06). Sin cambios ni se lee watched.db: era lo único que quedaba de las
    # filas de Kodi que se revisaban siempre (revisión 29-oct DAT-05)
    prev = HOME.getProperty("flix_progress_wsig")
    if sig == prev:
        return
    rsig = rows_sig(sig)                # también ANTES de leer
    W = truth()
    if W is None:
        log("sin watched.db en %s" % WATCHED_DB)
        return
    _RESUME_DROPPED[0] = False
    # watched.db igual que en la pasada anterior (los dos primeros trozos de la huella): solo cache.db ha cambiado y
    # basta con mirar los pickles rehechos (PY-11)
    a = fix_palantir_cache(W, only_changed=bool(prev) and prev.split("|")[:2] == sig.split("|")[:2])
    if _RESUME_DROPPED[0]:
        reload_resume_row()
    b = 0
    # rows_cache2.json solo depende de watched.db: si desde su última corrección no han cambiado ni watched.db ni el
    # fichero (solo cache.db: Palantir rehace una lista, la pasada anterior la escribió, llega el estado de TMDB…),
    # saldría lo mismo y no se repite (revisión 29-oct DAT-04; 74-110 ms por pasada en proot). Solo se mira cuando la
    # huella de siempre ha cambiado: nunca corrige más tarde que antes
    if rsig != HOME.getProperty("flix_progress_rsig"):
        _ROWS_WROTE[0] = ""
        b = fix_rows_cache(W)
        if b and _ROWS_WROTE[0]:
            rsig = rsig.rsplit("|", 1)[0] + "|" + _ROWS_WROTE[0]     # lo que acaba de escribir ya está bien
        HOME.setProperty("flix_progress_rsig", rsig)
    HOME.setProperty("flix_progress_wsig", sig)
    if a or b:
        # la misma línea de siempre (la buscan las medidas de la revisión); ya no se recarga ninguna fila de Kodi
        log("pasada: cache.db %d, secciones %d, filas recargadas 0" % (a, b))


def started_shows():
    """series seguidas a medias (▶) según watched.db"""
    try:
        return {k for k, v in (truth_shows() or {}).items() if v == SHOW_STARTED}
    except Exception as e:  # noqa: BLE001
        log("series a medias: %s" % e)
        return set()


def episode_just_watched(now=None, window=180):
    """¿Palantir ha apuntado un capítulo en los últimos 3 min? (lastPlayed en UTC, «2026-10-20T21:56:17.000Z»)"""
    import calendar
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            last = db.execute("SELECT MAX(lastPlayed) FROM episodes_watched").fetchone()[0]
        finally:
            db.close()
        t = calendar.timegm(time.strptime(last[:19], "%Y-%m-%dT%H:%M:%S"))
    except Exception:  # noqa: BLE001
        return False
    return 0 <= (now or time.time()) - t <= window


def follow_check(before):
    """si alguna serie ha dejado de estar a medias (último capítulo visto: Palantir la marca completa) se renueva
    «Series en seguimiento»: Palantir la guarda en caché hasta 3 días y, rehecha, ya no la trae (probado en la Shield
    20-oct con Crystal Lake). Antes solo pasaba al reiniciar Kodi. Devuelve las series a medias de ahora."""
    now = started_shows()
    done = before - now
    if done:
        log("series que ya no están a medias: %s -> renuevo Series en seguimiento" % sorted(done))
        import flix_p3sync
        flix_p3sync.refresh_follow()
    return now


def wait_or_again(monitor, secs, step=0.25):
    """espera secs entre pasadas: 'abort' si Kodi se cierra, 'again' si otra llamada pidió pasada (flix_progress_again)
    y '' si se cumplió el tiempo. Antes la petición esperaba a que acabara todo el horario en marcha (hasta 40 s): al
    marcar, el menú de Kodi que se abre por detrás lanza una pasada ANTES de que Palantir guarde, y la de después de
    guardar (flix_menu.wait_applied) quedaba en cola; la ✓ tardaba en quitarse (Carlos, 24-oct)"""
    end = time.time() + secs
    while True:
        if flix_common.quitting():
            return "abort"          # System.OnQuit (Kodi no avisa por abortRequested a los RunScript sin addon; APA-03)
        if HOME.getProperty("flix_progress_again"):
            return "again"
        left = end - time.time()
        if left <= 0:
            return ""
        if monitor.waitForAbort(min(step, left)):
            return "abort"


def wait_p3sync(monitor):
    """flix_p3sync está rehaciendo las pausas y Palantir bajando de Trakt (flix_p3sync_busy, ~20-60 s al arrancar):
    aquí no se escribe nada hasta que acabe. 'abort' si Kodi se cierra, '' al quedar libre. La marca de ocupado se
    renueva mientras: otra llamada no arranca un segundo intérprete (pide pasada con flix_progress_again)"""
    while flix_common.p3sync_busy():
        if flix_common.quitting() or monitor.waitForAbort(1):
            return "abort"
        HOME.setProperty("flix_progress_busy", str(time.time()))
    return ""


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "home"
    busy = HOME.getProperty("flix_progress_busy")
    if busy and time.time() - float(busy or 0) < 60:
        HOME.setProperty("flix_progress_again", mode)
        return
    HOME.setProperty("flix_progress_busy", str(time.time()))
    # se entera del cierre de Kodi (System.OnQuit) mientras espera entre pasadas: antes seguía su horario (hasta 40 s)
    # y Kodi lo mataba a los 5 s (revisión 29-oct APA-03)
    monitor = flix_common.quit_monitor()
    log("inicio (%s)" % mode)
    started = started_shows() if mode == "video" else set()
    # tras ver un capítulo, «Series en seguimiento» se renueva al final: Palantir la ordena por lo último visto pero
    # la guarda en caché (Carlos, 20-oct: El Castillo, recién vista, ni salía)
    renew = mode == "video"

    def do_pass():
        nonlocal started
        HOME.setProperty("flix_progress_busy", str(time.time()))
        try:
            one_pass()
            if mode == "video":
                started = follow_check(started)
        except Exception as e:  # noqa: BLE001
            log("error: %s" % e)
        flush_log()

    try:
        while True:
            last, deferred = 0, False
            for t in PASSES.get(mode, PASSES["home"]):
                # waitForAbort(0) no vuelve en algunas versiones: solo se espera si hay algo que esperar
                if t > last:
                    woke = wait_or_again(monitor, t - last)
                    if woke == "abort":
                        return
                    if woke == "again":
                        break           # otra petición (p. ej. «Marcar como no vista» ya guardado): pasada YA
                last = t
                if flix_common.p3sync_busy():
                    # la sincronización de arranque escribe watched.db y Palantir baja de Trakt: una pasada ahora
                    # pisaba su escritura («Error al sincronizar vistos», Shield 5-nov; PY-04). Se hace al acabar
                    if not deferred:
                        log("flix_p3sync en marcha: aplazo la pasada")
                    deferred = True
                    continue
                do_pass()
            if deferred:
                if wait_p3sync(monitor) == "abort":
                    return
                do_pass()
            if renew and episode_just_watched():
                renew = False
                log("capítulo visto: renuevo Series en seguimiento (orden por lo último visto)")
                import flix_p3sync
                flix_p3sync.refresh_follow()
            again = HOME.getProperty("flix_progress_again")
            HOME.clearProperty("flix_progress_again")
            if not again:
                break
            # tras un vídeo se sigue con su horario (follow_check / Series en seguimiento) aunque llegue otra petición
            mode = mode if mode == "video" else again
            HOME.setProperty("flix_progress_busy", str(time.time()))
            try:
                one_pass()                  # al momento: el horario de la nueva petición empieza después
            except Exception as e:  # noqa: BLE001
                log("error: %s" % e)
    finally:
        flush_log()
        HOME.clearProperty("flix_progress_busy")


if __name__ == "__main__":
    main()
