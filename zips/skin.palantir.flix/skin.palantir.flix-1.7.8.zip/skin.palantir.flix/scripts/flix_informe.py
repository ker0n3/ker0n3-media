"""«Enviar informe» (Carlos, 31-oct: a su hermana la Sony a veces no le reproduce y no es de trastear): sube el registro
de Kodi a paste.kodi.tv (el sitio del complemento oficial «Kodi Logfile Uploader») y enseña un código corto para
pasarlo por Telegram. Van las dos sesiones, la de ahora y la anterior (kodi.old.log): el fallo sigue ahí aunque se
haya cerrado Kodi o borrado la caché, siempre que se envíe al volver a entrar. Claves, contraseñas y tokens no salen del aparato: se borra su valor y la
línea se queda (suele ser la del fallo); sin marca ni aviso (Carlos, 8-nov).
Lo lanza Ajustes → OTROS → «Enviar informe de fallo» (TV: tools/gen_settings.py; táctil: touch/xml/Custom_1196)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import time

import xbmc
import xbmcgui
import xbmcvfs

PASTE = "https://paste.kodi.tv/"
LOGS = (("kodi.old.log", "SESIÓN ANTERIOR"), ("kodi.log", "ESTA SESIÓN"))
MAX_LOG = 400 * 1024        # bytes de cada registro como mucho: el principio (arranque) y el final (lo último)
HEAD = 60 * 1024
TIMEOUT = 30
TELEGRAM = "t.me/skinker0n3media"
# lo que no debe salir: usuario y contraseña en una URL, valores de claves y tokens, Authorization. Se borra el valor
# sin dejar nada en su sitio (Carlos, 8-nov: ni «tapado» ni <oculto>)
SECRETS = [
    (re.compile(r"(://)[^/\s:@]+:[^/\s@]+@"), r"\1"),
    (re.compile(r"(?i)((?:api_?key|apikey|access_?token|refresh_?token|token|password|passwd|pass|secret|client_secret"
                r"|key|pin|user(?:name)?)[\"']?\s*[=:]\s*[\"']?)[^&\"'\s,;}\]<]+"), r"\1"),
    (re.compile(r"(?i)(<(pass(?:word)?|user(?:name)?|token)>)[^<]*(</\2>)"), r"\1\3"),
    (re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+"), r"\1"),
]


def log(msg):
    xbmc.log("[flix_informe] %s" % msg, xbmc.LOGINFO)


def redact(text, known=()):
    """el registro sin secretos: los valores conocidos (clave de MDBList, de TMDB…) y los patrones de SECRETS"""
    for k in known:
        if k and len(k) >= 6:
            text = text.replace(k, "")
    for rx, rep in SECRETS:
        text = rx.sub(rep, text)
    return text


def trim(text, limit=MAX_LOG, head=HEAD):
    """registro largo: el principio (aparato, versión, arranque) y el final (lo último que pasó)"""
    if len(text) <= limit:
        return text
    cut = len(text) - (limit - head)
    return "%s\n\n[… %d caracteres quitados …]\n\n%s" % (text[:head], cut - head, text[cut:])


def report(logs, header, known=()):
    """texto del informe: cabecera y cada registro (nombre, título, texto), sin secretos"""
    parts = [header]
    for name, title, text in logs:
        parts.append("\n\n===== %s (%s) =====\n%s" % (title, name, trim(text) if text else "(no está)"))
    return redact("".join(parts), known)


def code_of(answer):
    """código del informe en la respuesta de paste.kodi.tv ({"key": "…"}); '' si no lo trae"""
    try:
        key = json.loads(answer).get("key", "")
    except (ValueError, AttributeError):
        return ""
    return key if isinstance(key, str) and re.fullmatch(r"[A-Za-z0-9]{4,40}", key) else ""


def upload(text, opener=None):
    """sube el texto; el código o '' si falla"""
    import urllib.request
    req = urllib.request.Request(PASTE + "documents", data=text.encode("utf-8"), method="POST",
                                 headers={"Content-Type": "text/plain; charset=utf-8", "User-Agent": "KER0N3 MEDIA"})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=TIMEOUT) as r:
            return code_of(r.read().decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001  (sin red, paste.kodi.tv caído…)
        log("no se pudo subir: %s" % e)
        return ""


# ---------- Kodi ----------
def read_logs():
    folder = xbmcvfs.translatePath("special://logpath")
    out = []
    for name, title in LOGS:
        try:
            with open(os.path.join(folder, name), encoding="utf-8", errors="replace") as fh:
                out.append((name, title, fh.read()))
        except OSError:
            out.append((name, title, ""))
    return out


def header():
    info = {k: xbmc.getInfoLabel(k) for k in ("System.BuildVersion", "System.FriendlyName")}
    skin = xbmc.getSkinDir()
    return "Informe KER0N3 MEDIA · %s · skin %s %s · Kodi %s · %s" % (
        time.strftime("%Y-%m-%d %H:%M"), skin, xbmc.getInfoLabel("System.AddonVersion(%s)" % skin),
        info["System.BuildVersion"], info["System.FriendlyName"])


def known_secrets():
    """valores que se tapan tal cual: la clave de MDBList del usuario y la de TMDB de la skin"""
    from flix_common import TMDB_KEY
    return [xbmc.getInfoLabel("Skin.String(flix_mdblist_key)"), TMDB_KEY]


ASK_TITLE = "Informar de un fallo"
ASK_TEXT = "¿Enviar el registro de Kodi para que te ayuden? Se sube a paste.kodi.tv y te doy un código."
TOUCH_OPTS = ["Enviar (te doy un código)", "Guardar en Descargas"]


def confirm(dialog, touch, picker=None):
    """antes de subir nada (auditoría UX 8-nov, H1: un toque sin querer publicaba el registro): 'send', 'save' o ''.
    TV: Sí/No con el foco en «Cancelar». Táctil: lista con «Enviar» y «Guardar en Descargas» (antes otra tarjeta,
    «Copiar registro a Descargas»); Atrás = cancelar"""
    if touch:
        i = picker(ASK_TITLE, TOUCH_OPTS, ASK_TEXT)
        return ("send", "save")[i] if i in (0, 1) else ""
    try:
        ok = dialog.yesno(ASK_TITLE, ASK_TEXT, nolabel="Cancelar", yeslabel="Enviar",
                          defaultbutton=xbmcgui.DLG_YESNO_NO_BTN)
    except (TypeError, AttributeError):        # Kodi sin defaultbutton
        ok = dialog.yesno(ASK_TITLE, ASK_TEXT, nolabel="Cancelar", yeslabel="Enviar")
    return "send" if ok else ""


def main():
    touch = xbmc.getSkinDir().endswith(".touch")
    import flix_picker
    what = confirm(xbmcgui.Dialog(), touch, flix_picker.pick)
    if what == "save":
        import flix_export_log          # solo en la táctil (touch/scripts)
        flix_export_log.main()
        return
    if what != "send":
        return
    dlg = xbmcgui.DialogProgress()
    dlg.create("Enviar informe", "Enviando el registro de Kodi…")
    try:
        code = upload(report(read_logs(), header(), known_secrets()))
    finally:
        dlg.close()
    if not code:
        xbmcgui.Dialog().ok("Enviar informe", "No se ha podido enviar. Comprueba que hay internet y vuelve a probar.")
        return
    log("enviado: %s%s" % (PASTE, code))
    xbmcgui.Dialog().ok("Informe enviado", "Pasa este código por Telegram (%s) o a quien te ayude:[CR][CR]"
                        "[B]%s[/B]" % (TELEGRAM, code))


if __name__ == "__main__":
    main()
