# -*- coding: utf-8 -*-
"""Pantalla negra al abrir Kodi en Android hasta «Borrar caché» (móvil de Carlos casi a diario, 2-nov; otros usuarios
6-nov). Kodi saca sus archivos (Python, sonidos, idiomas…) del APK a <caché de la app>/apk y solo los vuelve a sacar si
esa carpeta NO existe o es más vieja que el APK (Splash.java). Cuando a Android le falta sitio vacía cachés de apps
(installd, CacheTracker): borra ARCHIVO A ARCHIVO, los más viejos primero, y deja las carpetas. Kodi ve apk/ en su
sitio, no re-extrae y arranca sin Python: «Fatal Python error: init_fs_encoding» y negro, sin llegar a la skin.

Remedio: marcar apk/ como «grupo» de caché (atributo user.cache_group, lo mismo que hace
StorageManager.setCacheBehaviorGroup de Android 8+). Android la borra entonces ENTERA, carpeta incluida, y Kodi la
vuelve a sacar sola al arrancar (unos segundos de «Extrayendo»). Se pone en cada arranque sano (barato, idempotente);
fuera de Android, o con xbmc.home fuera de la caché, no hace nada."""
import os

XATTR = "user.cache_group"


def target(xbmc_path):
    """<caché>/apk a partir de special://xbmc (…/cache/apk/assets); None si Kodi no vive en su caché"""
    p = (xbmc_path or "").replace("\\", "/").rstrip("/")
    i = p.find("/cache/apk")
    if i < 0:
        return None
    rest = p[i + len("/cache/apk"):]
    if rest and not rest.startswith("/"):
        return None                     # «/cache/apkfoo»: no es la carpeta de Kodi
    return p[:i + len("/cache/apk")]


def mark(path, osmod=os):
    """'ya' / 'puesto' / motivo de por qué no se pudo"""
    if not hasattr(osmod, "setxattr"):
        return "sin xattr"
    if not osmod.path.isdir(path):
        return "no existe"
    try:
        osmod.getxattr(path, XATTR)
        return "ya"
    except OSError:
        pass
    try:
        osmod.setxattr(path, XATTR, b"1")
        return "puesto"
    except OSError as e:
        return "error %s" % e


def main():
    import xbmc
    import xbmcvfs
    if not xbmc.getCondVisibility("System.Platform.Android"):
        return
    path = target(xbmcvfs.translatePath("special://xbmc"))
    if not path:
        return
    res = mark(path)
    if res != "ya":
        xbmc.log("[flix_cacheguard] %s: %s" % (path, res), xbmc.LOGINFO)
