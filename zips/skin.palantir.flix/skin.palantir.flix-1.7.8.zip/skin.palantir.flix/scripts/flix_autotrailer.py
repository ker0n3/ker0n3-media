"""Tráiler automático en la ficha (TV; diseño docs/superpowers/specs/2026-10-30-trailer-automatico-ficha-design.md).

Con Ajustes → «Tráiler automático en la ficha» en «Con sonido» o «Sin sonido» (Skin.String(flix_autotrailer) =
sonido / mudo; vacío = No, de serie), al abrir la ficha de una película (flix_play.MovieSheet) o de una serie
(flix_series_sheet.SeriesSheet) el tráiler se pide a los 2 s: su dirección se pregunta a YouTube en un hilo
(flix_trailer.direct, sin la rueda modal de Kodi) y se reproduce en el recuadro de la ficha (flix_trailer.play_direct),
con un fundido cuando hay imagen (onAVStarted). Se para al salir, al ver algo o con cualquier otra reproducción, y solo si
lo que suena es lo suyo. Reaprovecha flix_trailer (búsqueda, caché, _try, mark_bad, audio_guard, FLAG).

Kodi en Android pinta el vídeo (MediaCodec Surface) solo desde el recuadro de la ventana ACTIVA, no desde los diálogos
(GUIWindowManager::RenderEx): la ficha de película es un diálogo y las ventanas de debajo llevan FlixTrailerHost, un
recuadro fuera de pantalla visible con flix_tr_auto (Shield, 30-oct).

Lógica pura arriba (tests en tools/tests/test_autotrailer.py); lo que toca Kodi, abajo."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import threading  # noqa: E402
import time  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

SETTING = "flix_autotrailer"
MODES = ("", "sonido", "mudo")
LABELS = ("No", "Con sonido", "Sin sonido")
DELAY = 2.0             # s con la ficha abierta antes de pedirlo (entrar y salir rápido no gasta nada)
URL_WAIT = 12           # s más esperando a que la búsqueda (TMDB / Palantir) dé la URL
TRY_WAIT = 15           # s por vídeo esperando imagen (el addon YouTube tarda ~4 s en la Shield)
LOADING_MAX = 15        # s con vídeo y sin imagen (onAVStarted) que la rueda de Kodi sigue escondida, como mucho
ACTIVE = "flix_tr_auto"         # Window(home): automático en marcha (FlixTrailerHost de las ventanas de debajo)
LOADING = "flix_tr_loading"     # Window(home): preparándose (DialogBusy sin rueda)
ON_HOME = "flix_tr_on"          # Window(home): hay imagen (botón «Tráiler» de la serie: a pantalla completa)
STOP = "flix_tr_stop"           # Window(home): otro script pide pararlo (ask_stop); lo para el hilo de la ficha
GEN = "flix_trailer_gen"        # Window(home): marca del último flix_trailer.begin() (como flix_trailer.GEN)
ON = "tr_on"                    # propiedad de la ficha: hay imagen (fundido del recuadro)
MUTED = "flix_tr_muted"         # Skin.String: silencio puesto por el automático (recover lo quita al arrancar)
CLICK = "flix_tr_click"         # Window(home): tecla mientras carga (DialogBusy.xml, 9100): se le pasa a la ficha
CLICK_WAIT = 10.0               # s como mucho a que se vaya la rueda cancelada (Kodi espera a que YouTube acabe: ~5 s)
KEYS = {"select": "Select", "left": "Left", "right": "Right", "up": "Up", "down": "Down"}
NOISE = (0, 107)                # acciones que no son una tecla (ratón que se mueve)
PANEL = "flix_info_open"        # Window(home): panel ( i ) de la ficha abierto (flix_info.OPEN): no se arranca debajo
# Window(home): la ficha se reabre al volver de «Títulos de X» (flix_info.back_with_cover, la hora): ya se estuvo en ella
# y su tráiler, pedido otra vez, dejaba los botones parados ~5 s si llegaba una tecla con YouTube resolviéndolo (Kodi
# espera a que el addon acabe; Shield, Carlos 1-nov). Una sola ficha la gasta; una vieja no cuenta
SKIP = "flix_tr_skip"
SKIP_FRESH = 10.0
HOME = xbmcgui.Window(10000)


def log(msg):
    xbmc.log("[flix_autotrailer] %s" % msg, xbmc.LOGINFO)


def skip_fresh(value, now):
    try:
        return 0 <= now - float(value) < SKIP_FRESH
    except (TypeError, ValueError):
        return False


def mode_of(value):
    return value if value in MODES else ""


def should_start(mode, has_media, open_secs, closed):
    """pedir el tráiler: ajuste encendido, nada sonando (un solo reproductor), 2 s con la ficha abierta"""
    return bool(mode) and not has_media and not closed and open_secs >= DELAY


def need_mute(mode, muted):
    """silenciar solo en «Sin sonido» y si Kodi no lo estaba ya (ese silencio no es nuestro: no se quita)"""
    return mode == "mudo" and not muted


def at_end(pos, total, margin=1.0):
    """el HLS de YouTube no avisa del final: Kodi lo trata como emisión en directo, el tiempo sigue pasada la
    duración y se queda la última imagen congelada (Shield, 30-oct: «está congelado el tráiler», 3:10 de 2:34)"""
    return total > 0 and pos >= total - margin


def is_ours(own_file, playing_file):
    return bool(own_file) and own_file == playing_file


# ---------- Kodi ----------
def mode():
    return mode_of(xbmc.getInfoLabel("Skin.String(%s)" % SETTING))


def muted():
    import flix_common
    try:
        return bool((flix_common.rpc("Application.GetProperties", {"properties": ["muted"]}).get("result") or {})
                    .get("muted"))
    except ValueError:
        return False


def set_mute(on):
    """silencio de todo Kodi. Application.SetMute por JSON-RPC desde la skin no hace nada (devuelve «no silenciado»;
    Shield 30-oct): se usa el Mute de Kodi, que alterna, solo si hace falta (muted()). La marca persistente sigue al
    silencio"""
    if on:
        # la marca ANTES del silencio: si Kodi se cierra entre las dos cosas, recover() aún puede devolver el sonido.
        # wait=True: que ya esté puesta cuando cleanup() la lea
        xbmc.executebuiltin("Skin.SetString(%s,1)" % MUTED, True)
        if not muted():
            xbmc.executebuiltin("Mute", True)
    else:
        if muted():
            xbmc.executebuiltin("Mute", True)
        xbmc.executebuiltin("Skin.Reset(%s)" % MUTED)


def _marker():
    """la marca persistente del silencio del automático (full() la quita al pasar a pantalla completa)"""
    return xbmc.getInfoLabel("Skin.String(%s)" % MUTED)


def recover():
    """al arrancar Kodi (first_run): si se cerró con el silencio del automático puesto, se quita"""
    if _marker():
        set_mute(False)
        xbmc.executebuiltin("Skin.Reset(%s)" % MUTED)
        log("silencio del tráiler automático quitado al arrancar")


def ask_stop(wait=2.0):
    """otro script (flix_play: un capítulo a medias desde la ficha de serie, con su «Continuar») no ve el AutoTrailer de
    la ficha: deja el aviso, el hilo de la ficha lo para (gone) y se espera a que lo haya hecho (ACTIVE fuera, ~0,1 s;
    como mucho wait s): así el Stop del tráiler le llega a Kodi antes que el play del capítulo, como con «Ver» en la
    ficha de película. Solo con el automático en marcha: un aviso viejo pararía el siguiente (aun así, _play lo quita)"""
    if not HOME.getProperty(ACTIVE):
        return
    HOME.setProperty(STOP, "1")
    deadline, mon = time.time() + wait, xbmc.Monitor()      # uno, no uno cada 50 ms (revisión 7-nov PY-19)
    while HOME.getProperty(ACTIVE) and time.time() < deadline:
        if mon.waitForAbort(0.05):
            break


def _playing_file():
    """lo que suena TAL COMO se pidió: Player.Filenameandpath da la URL del PlayMedia (el plugin de YouTube), no la
    resuelta que da getPlayingFile (Shield, 30-oct). Se usa siempre esta, para guardar y para comparar"""
    return xbmc.getInfoLabel("Player.Filenameandpath")


def _stop_player():
    xbmc.Player().stop()


def _position():
    """(segundos, duración) de lo que suena; (0, 0) si nada"""
    try:
        player = xbmc.Player()
        return player.getTime(), player.getTotalTime()
    except RuntimeError:
        return 0.0, 0.0


def _done():
    import flix_trailer
    flix_trailer.done()


def _stop_late():
    """el PlayMedia ya pedido llegará después: se para al aparecer (flix_trailer.stop_late; un envoltorio para los tests)"""
    import flix_trailer
    flix_trailer.stop_late()


class _Player(xbmc.Player):
    """avisos del reproductor para el automático (onAVStarted = hay imagen de verdad)"""

    def __init__(self, auto):
        super().__init__()
        self.auto = auto

    def onAVStarted(self):
        self.auto.on_av()

    def onPlayBackStarted(self):
        self.auto.on_started()

    def onPlayBackEnded(self):
        self.auto.on_end()

    def onPlayBackStopped(self):
        self.auto.on_end()

    def onPlayBackError(self):
        self.auto.on_end()


class AutoTrailer:
    """el tráiler automático de UNA ficha. state: idle → loading → playing → done.
    win: la ventana de la ficha (propiedad tr_on); get_urls(): las URL de flix_trailer.resolve («a|b»), o '' si aún
    no se sabe"""

    def __init__(self, win, get_urls):
        self.win, self.get_urls = win, get_urls
        self.state, self.file, self.muted_by_us, self.closed = "idle", "", False, False
        self.requested = ""         # URL del PlayMedia lanzado cuya imagen (onAVStarted) aún no ha llegado; '' = ninguno
        self.gen = ""               # GEN de flix_trailer tras nuestro begin(): otro begin() (el botón «Tráiler») lo cambia
        self.stopped_at = 0.0       # cuándo se cerró la ficha (el aviso tardío solo se atiende LATE_WAIT s)
        self.begun = False          # flix_trailer.begin() puesto y done() aún no: cleanup() lo cierra
        self.ok_at = 0.0            # cuándo dio vídeo el PlayMedia (Player.HasVideo; la imagen llega con on_av)
        self.player = None
        self.lock = threading.Lock()

    # --- arrancar ---
    def start(self):
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        if not mode():                      # «No» (de serie; en la táctil siempre): ni se espera ni se busca la URL
            return
        skip = HOME.getProperty(SKIP)
        if skip:
            HOME.clearProperty(SKIP)
            if skip_fresh(skip, time.time()):
                log("vuelta de «Títulos de X»: sin tráiler automático")
                return
        mon, t0 = xbmc.Monitor(), time.time()
        while not self.closed:
            if HOME.getProperty(PANEL):         # el panel ( i ) tapa la ficha: el tráiler sonaría sin verse
                log("panel de información abierto: no arranca")
                return
            urls = self.get_urls()
            if urls and time.time() - t0 >= DELAY:
                break
            if time.time() - t0 > DELAY + URL_WAIT or mon.waitForAbort(0.2):
                return
        if not should_start(mode(), xbmc.getCondVisibility("Player.HasMedia"), time.time() - t0, self.closed):
            return
        import flix_trailer
        if not flix_trailer.available():        # sin el addon YouTube no hay tráiler (ni botón)
            return
        self.play(urls, mon)

    def play(self, urls, mon):
        """pide el tráiler. Pase lo que pase (también una excepción) acaba en cleanup(), salvo que ya suene"""
        settled = False
        try:
            settled = self._play(urls, mon)
        except Exception as e:  # noqa: BLE001
            log("error al arrancar el tráiler: %s" % e)
        finally:
            if not settled:
                self.cleanup()
        if settled:
            self.pump(mon)

    def pump(self, mon):
        """Kodi entrega los avisos de xbmc.Player (onAVStarted…) en el hilo que creó el Player y solo mientras ese hilo
        espera en Kodi (waitForAbort): este hilo se queda vivo mientras el tráiler sea nuestro, o pedido y con la ficha
        recién cerrada (LATE_WAIT). Sin esto el tráiler sonaba y el recuadro no se encendía nunca (Shield, 30-oct).
        Sin monitor (tests) no espera"""
        import flix_trailer
        if mon is None:
            return
        while not mon.waitForAbort(0.1):
            self.gone()
            with self.lock:
                alive = self.state in ("loading", "playing") or bool(
                    self.requested and self.closed and time.time() - self.stopped_at <= flix_trailer.LATE_WAIT)
            if not alive:
                return
            if self.state == "playing" and at_end(*_position()):
                self.finish()
            elif self.state == "loading" and self.ok_at and time.time() - self.ok_at > LOADING_MAX:
                HOME.clearProperty(LOADING)     # la imagen no llega: que las ruedas de la ficha se vuelvan a ver

    def _play(self, urls, mon):
        """True si no queda nada que limpiar (ficha ya cerrada, o el tráiler está en marcha)"""
        import flix_trailer
        with self.lock:
            if self.closed:
                return True
            self.state = "loading"
            HOME.clearProperty(STOP)            # un aviso de otra ficha no para este
            # begin() aquí dentro: si stop() ya limpió, no se llama, y si no, cleanup() lo cierra con done()
            flix_trailer.begin()
            self.begun = True
            self.gen = HOME.getProperty(flix_trailer.GEN)
        HOME.setProperty(ACTIVE, "1")
        HOME.setProperty(LOADING, "1")
        self.player = _Player(self)
        if need_mute(mode(), muted()):
            set_mute(True)
            self.muted_by_us = True
        res = ""
        for url in [u for u in urls.split(flix_trailer.SEP) if u]:
            if self.gone():                     # se salió de la ficha (o se pidió parar): no se pide otro
                break
            log("pido %s" % url)
            # la dirección del vídeo, preguntada a YouTube en un hilo (flix_trailer.direct): sin la rueda modal de Kodi
            # que dejaba la ficha sin mando mientras el addon lo resolvía (Carlos, 2-nov: «pulso ver deberia ignorar
            # completamente el trailer»). Una tecla antes de tenerla y no se reproduce nada
            res, path, props = flix_trailer.direct(url, mon, self.gone)
            if res == "ok":
                self.requested = path           # lo que dará Player.Filenameandpath (on_av lo compara)
                res = flix_trailer.play_direct(path, props, mon, self.gone, wait=TRY_WAIT)
            if res == "ok":
                # LOADING sigue hasta la imagen (on_av): con Player.HasVideo Kodi aún abre el vídeo con su rueda, y
                # quitarlo aquí la enseñaba justo antes del tráiler (Carlos, 30-oct)
                self.ok_at = time.time()
                flix_trailer.audio_guard()
                return True
            if res == "failed":
                flix_trailer.mark_bad(url)      # el addon avisó: la próxima vez ni se intenta
            else:
                # tecla o ficha cerrada ("cancel"/"late"), sin youtube_resolver, fallo de red, no arrancó, tiempo agotado
                # o Kodi cerrándose: no se insiste ni se marca como mala
                break
        if res == "timeout" and self.requested and HOME.getProperty(flix_trailer.GEN) == self.gen:
            # si llega después, se para al aparecer; no si el usuario pidió con «Tráiler» el suyo entre medias (stop_late
            # coge el GEN de ahora y pararía ESE)
            flix_trailer.stop_late()
        # con "late" la ficha ya se cerró y stop() armó el aviso con el GEN de ESTE tráiler: armarlo otra vez ahora
        # cogería el GEN del que el usuario pidió con «Tráiler» entre medias y lo pararía
        log("sin tráiler (%s)" % (res or "sin URL"))
        return False

    # --- avisos del reproductor ---
    def on_av(self):
        with self.lock:
            if self.state == "loading" and not self.closed:
                if _playing_file() != self.requested:
                    # lo que ha empezado no es el tráiler pedido (un capítulo o «Seguir viendo» pulsado en los huecos
                    # de la preparación): no se adopta; se limpia lo nuestro (marcas, silencio) sin parar nada
                    self.on_other_playback()
                    return
                self.requested = ""
                self.file = _playing_file()
                self.state = "playing"
                HOME.clearProperty(LOADING)
                HOME.setProperty(ON_HOME, "1")
                self.win.setProperty(ON, "1")
                log("en el recuadro: %s" % self.file[:80])
            elif self.requested and self.closed:
                # la ficha se cerró con el tráiler ya pedido: si llega ahora (hasta LATE_WAIT s), se para, pero solo
                # si es el que pedimos: cualquier otra reproducción (un capítulo, la película) no es cosa nuestra
                import flix_trailer
                if time.time() - self.stopped_at <= flix_trailer.LATE_WAIT:
                    # y solo si nadie ha empezado otro tráiler después (el del botón, con la misma URL): cambia GEN
                    if _playing_file() == self.requested and HOME.getProperty(flix_trailer.GEN) == self.gen:
                        self.requested = ""
                        _stop_player()
                        log("tráiler llegado tras cerrar la ficha: parado")
                else:
                    self.requested = ""

    def on_started(self):
        with self.lock:
            if self.state == "playing" and not is_ours(self.file, _playing_file()):
                self.on_other_playback()

    def on_other_playback(self):
        """otra reproducción ha sustituido al tráiler (Palantir, un capítulo): solo se limpia lo nuestro"""
        log("otra reproducción: el tráiler ya no suena")
        self.cleanup()

    def on_end(self):
        with self.lock:                     # como on_av/on_started: no a medias con un stop() de la ficha
            if self.state == "playing":
                log("tráiler acabado")
                self.cleanup()

    def finish(self):
        """el tráiler llegó a su duración (at_end): se para y vuelve el fanart, como si Kodi hubiera avisado del final"""
        with self.lock:
            if self.state == "playing" and is_ours(self.file, _playing_file()):
                log("tráiler acabado")
                _stop_player()
                self.cleanup()

    # --- parar ---
    def gone(self):
        """¿ficha cerrada o tráiler parado? Atiende antes el aviso de otro script (ask_stop) como salir de la ficha y el
        OK pulsado mientras carga (CLICK)"""
        key = HOME.getProperty(CLICK)
        if key:
            HOME.clearProperty(CLICK)
            self.pressed(key)
        if HOME.getProperty(STOP):
            log("parado a petición (otra reproducción desde la ficha)")
            self.stop()
        return self.closed

    def pressed(self, key):
        """tecla mientras cargaba (Carlos, 31-oct: «si pulso antes, que corte la carga del tráiler y ya está»): la rueda
        escondida de Kodi se quedaba con ella. DialogBusy ya la cancela (Atrás) y aquí se para el tráiler; cuando la
        rueda se va (Kodi espera a que YouTube acabe), la misma tecla a la ficha: el OK, al botón con el foco (con su
        onClick de Python o su onclick del XML: SendClick solo llega al de Python), y las flechas, a moverse"""
        action = KEYS.get(key, "Select")
        log("tecla mientras carga (%s): fuera el tráiler y se la paso a la ficha" % action)
        self.stop()

        def send():
            end, mon = time.time() + CLICK_WAIT, xbmc.Monitor()
            while xbmc.getCondVisibility("Window.IsActive(busydialog)") and time.time() < end:
                if mon.waitForAbort(0.05):
                    return
            if not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                xbmc.executebuiltin("Action(%s)" % action)
        threading.Thread(target=send, daemon=True).start()

    def key_in_sheet(self, aid):
        """tecla en la ficha antes de pedir el tráiler: ya no arranca y la tecla hace lo suyo al momento"""
        if aid in NOISE or self.state != "idle" or self.closed:
            return
        self.closed = True
        log("tecla en la ficha antes del tráiler: no arranca")

    def playing(self):
        return self.state == "playing"

    def stop(self):
        """salir de la ficha, «Ver», el menú: se para al instante si lo que suena es lo suyo"""
        self.stopped_at = time.time()
        self.closed = True
        with self.lock:
            if self.state == "playing" and is_ours(self.file, _playing_file()):
                _stop_player()
            elif self.state == "loading" and self.requested:
                _stop_late()        # el PlayMedia ya está pedido: si aparece, se para (también lo mira on_av)
            if self.state in ("loading", "playing"):
                # con un PlayMedia aún por llegar, requested se conserva: on_av lo para si aparece
                self.cleanup(keep_requested=self.state == "loading" and bool(self.requested))
            self.state = "done"

    def cleanup(self, keep_requested=False):
        if not keep_requested:
            self.requested = ""
        self.win.clearProperty(ON)
        for p in (ACTIVE, LOADING, ON_HOME, STOP):
            HOME.clearProperty(p)
        if self.muted_by_us:
            if _marker():       # si full() ya lo quitó, el silencio que haya ahora es del usuario: no se toca
                set_mute(False)
            self.muted_by_us = False
        if self.begun:
            self.begun = False
            if HOME.getProperty(GEN) == self.gen:   # si el usuario pidió otro con «Tráiler», FLAG es de ese: no se quita
                _done()
        self.state = "done"

    # --- pantalla completa (botón «Tráiler») ---
    def attach(self, win):
        """la ficha de película se reabre tras la pantalla completa: el recuadro vuelve a enseñar el tráiler"""
        self.win = win
        if self.playing():
            win.setProperty(ON, "1")

    def to_fullscreen(self):
        """el que suena, a pantalla completa por el mismo segundo; con sonido (lo ha pedido el usuario)"""
        if not self.playing():
            return False
        if self.muted_by_us:
            set_mute(False)
            self.muted_by_us = False
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
        return True

    def wait_fullscreen(self, mon=None, timeout=600):
        """ficha de película: espera a que se deje la pantalla completa (Atrás) o acabe; True si sigue sonando. Si en 5 s
        no llega a verse la pantalla completa (ActivateWindow no cuajó) vuelve ya con playing(): el tráiler sigue en su
        recuadro"""
        mon = mon or xbmc.Monitor()
        t0, seen = time.time(), False
        while time.time() - t0 < timeout and self.playing():
            full = xbmc.getCondVisibility("Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd)")
            if seen and not full:
                return self.playing()
            seen = seen or full
            if not seen and time.time() - t0 > 5:       # ActivateWindow no cuajó: no se espera 10 minutos
                return self.playing()
            if mon.waitForAbort(0.1):
                return False
        return self.playing()


def choose():
    """Ajustes → «Tráiler automático en la ficha»: No / Con sonido / Sin sonido"""
    import flix_picker
    cur = MODES.index(mode())
    i = flix_picker.pick("Tráiler automático en la ficha", list(LABELS),
                         "Al abrir la ficha de una película o de una serie, a los pocos segundos el tráiler empieza "
                         "solo, arriba a la derecha. «Tráiler» lo pasa a pantalla completa; al salir de la ficha o "
                         "pulsar «Ver» se para. «Sin sonido» silencia Kodi mientras suena.",
                         current=cur)
    if i >= 0:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (SETTING, MODES[i]) if MODES[i] else "Skin.Reset(%s)" % SETTING)


def sound():
    """Ajustes (TV) → «Tráiler en la ficha» › : sus opciones (Carlos, 8-nov: el menú no cambia según lo encendido; la
    flecha del interruptor lleva aquí). Solo el sonido; con el automático apagado la flecha no se ve"""
    import flix_picker
    opts = ("mudo", "sonido")
    cur = 1 if mode() == "sonido" else 0
    i = flix_picker.pick("Sonido del tráiler", ["En silencio", "Con sonido"],
                         "En silencio: el tráiler automático empieza sin sonido y no molesta mientras lees la ficha. "
                         "Con sonido: suena desde el principio.", current=cur)
    if i >= 0:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (SETTING, opts[i]))


def full():
    """botón «Tráiler» de la serie con el automático en marcha (Includes_Flix, 5251: flix_tr_auto). Corre en otro
    proceso: quita el silencio del automático y su marca persistente. El AutoTrailer de la ficha sigue creyendo que lo
    silenció él, pero en cleanup() solo lo quita si la marca sigue puesta: así no desmuta un silencio que el usuario
    ponga durante la pantalla completa.
    Si aún no hay imagen (flix_tr_on sin poner: entre el PlayMedia y onAVStarted no hay rueda ni nada que pasar a
    pantalla completa) se sigue el camino de siempre del botón: flix_trailer.play_series con la URL de la serie (mismo
    proceso, sin pasar la URL por RunScript). El AutoTrailer de la ficha lo ve sin dañar nada: su begin() ya no es el
    GEN actual, así que ni arma stop_late ni cierra FLAG (run/cleanup); si llega la imagen del mismo tráiler la adopta y
    la limpia cuando el vigilante de play_series la para"""
    if _marker():
        set_mute(False)
    if not HOME.getProperty(ON_HOME):
        url = HOME.getProperty("flix_series_trailer")
        if url:
            import flix_trailer
            flix_trailer.play_series(url)
        return
    xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    {"ajuste": choose, "sonido": sound, "full": full}.get(arg, lambda: None)()
