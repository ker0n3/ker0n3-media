"""Caché de imágenes de Kodi (userdata/Thumbnails + Textures13.db) sin lo que no se ve desde hace DAYS días (Carlos,
3-nov: «alguna mejora en la skin que mejore la estabilidad de kodi»). Kodi nunca la limpia: en la Shield, 19.329
imágenes y 1,2 GB desde nov-2024 (el 67 % sin usar en más de 180 días) con el almacenamiento al 87 %; si se llena,
Kodi no puede guardar sus bases de datos. Se borran con la función de Kodi (Textures.RemoveTexture: fichero y fila a la
vez); si una vuelve a hacer falta, Kodi la descarga otra vez. 30 días y no 60: en la Shield solo 430 imágenes más y las
filas de uso semanal o quincenal no se tocan.
Ya no hay limpieza semanal automática (Carlos, 4-nov): solo la hace el botón Ajustes → «Limpiar Kodi» (flix_limpiar.py),
que usa estas funciones. Un textures.json de la versión anterior se deja donde está (no molesta). Solo funciones: no
se lanza con RunScript."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import time

import xbmc
import xbmcgui

DAYS = 30
BATCH = 100         # imágenes seguidas antes de soltar el disco un momento (PAUSE s)
PAUSE = 0.5
HOME = xbmcgui.Window(10000)


def cutoff(now, days=DAYS):
    """fecha límite como la guarda Kodi (CURRENT_TIMESTAMP de SQLite: UTC, «AAAA-MM-DD HH:MM:SS»)"""
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(now - days * 86400))


def old_ids(textures, limit):
    """ids de las imágenes cuyos tamaños guardados llevan todos sin usarse desde antes de limit; sin fecha, no"""
    out = []
    for t in textures or []:
        sizes = t.get("sizes") or []
        used = [s.get("lastused") or "" for s in sizes]
        if used and all(u and u < limit for u in used) and isinstance(t.get("textureid"), int):
            out.append(t["textureid"])
    return out


def busy():
    """vídeo, enlace resolviéndose o tráiler cargando: el disco para ellos"""
    return bool(xbmc.getCondVisibility("Player.HasMedia") or HOME.getProperty("flix_resolving")
                or HOME.getProperty("flix_trailer"))


def wait_free(mon, flix_common, until):
    """espera a que busy() deje de serlo; False si Kodi se cierra o se pasa until"""
    while busy():
        if time.time() > until or flix_common.wait_quit(mon, 5):
            return False
    return True


def list_old(flix_common, limit):
    r = flix_common.rpc("Textures.GetTextures", {
        "properties": ["sizes"],
        "filter": {"field": "lastused", "operator": "lessthan", "value": limit}})
    return old_ids((r.get("result") or {}).get("textures"), limit)


def remove(ids, mon, flix_common, until):
    """borra con Textures.RemoveTexture; entre lotes espera (hasta until, hora) a que no haya vídeo, enlace ni tráiler;
    para si Kodi se cierra o se pasa until. Devuelve (borradas, terminado)"""
    done = 0
    for i, tid in enumerate(ids):
        if i and i % BATCH == 0 and (flix_common.wait_quit(mon, PAUSE) or not wait_free(mon, flix_common, until)):
            return done, False
        if flix_common.quitting(mon):
            return done, False
        r = flix_common.rpc("Textures.RemoveTexture", {"textureid": tid})
        if r.get("result") == "OK":
            done += 1
    return done, True
