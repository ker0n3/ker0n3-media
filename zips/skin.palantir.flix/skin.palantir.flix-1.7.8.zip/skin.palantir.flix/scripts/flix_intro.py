"""«Saltar intro» / «Saltar resumen» durante un capítulo, solo con datos de TheIntroDB e IntroDB (Carlos, 3-nov: sin modo
manual ni salto automático). Sin datos no sale nada. Lo usa follow_playback (flix_autoplay.py) con un Watcher por capítulo.
Los créditos (TheIntroDB «credits», IntroDB «outro») no son botón: solo dicen a follow_playback cuándo sacar el aviso
de «Siguiente capítulo» (credits_start / Watcher.credits_at). Si IntroDB marca «post_credits» (escena tras los
créditos) no se adelanta nada: tampoco es botón.

Los tiempos se piden en un hilo (nunca en el bucle de reproducción, que va cada 0,5 s) y se guardan en
addon_data/<skin>/intro_times.json: 30 días si hubo datos, 7 si no. Todo fallo se traga: esto nunca puede afectar a
la reproducción. La clave de TMDB no se escribe jamás en el log."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import threading
import time
import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402

THEINTRODB = "https://api.theintrodb.org/v2/media?tmdb_id=%d&season=%d&episode=%d"
TMDB_IDS = "https://api.themoviedb.org/3/tv/%d/external_ids?api_key=%s"      # lleva la clave: no va al log
INTRODB = "https://api.introdb.app/segments?imdb_id=%s&season=%d&episode=%d"
TIMEOUT = 4
MIN_LEN, MAX_LEN = 10, 600       # un tramo de menos de 10 s o de más de 10 min no es un intro
TAIL = 3                         # a menos de 3 s del final del tramo ya no compensa enseñar el botón
TTL_DATA, TTL_NONE = 30 * 86400, 7 * 86400
TTL_FAIL = 600                   # fallo de red: se reintenta pasados 10 min, no en cada tick
FAILED = object()                # el opener no pudo preguntar (distinto de None = 404, sin datos)
MAX_CACHE = 500
CACHE_V = 4                      # versión de la caché: la 3 (sin mirar IntroDB con TheIntroDB completo) no tiene post_credits
CREDITS_WINDOW = 600             # créditos que empiezan a más de 10 min del final: dato malo, no se usan
CREDITS_FRAC = 0.75              # y que empiezan antes del 75 % del capítulo (One Piece 1x05: «créditos» de 0 a 154 s)
CREDITS_END_GAP = 30             # y que acaban a más de 30 s del final (una escena suelta, no los créditos del final)
KINDS = ("intro", "recap", "credits", "post_credits")
CREDIT_KINDS = ("credits", "post_credits")
LABELS = {"intro": "Saltar intro", "recap": "Saltar resumen"}


def log(msg):
    xbmc.log("[flix_intro] %s" % msg, xbmc.LOGINFO)


def cache_file():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/intro_times.json" % xbmc.getSkinDir())


# --- tramos (puro) ---

def _seg(kind, d):
    """{start_ms, end_ms} (o start_sec / end_sec) -> tramo; start nulo = desde el principio; None si no sirve.
    Los créditos (y post_credits) sí valen sin final (end None) pero no sin inicio"""
    if not isinstance(d, dict):
        return None
    try:
        end = d.get("end_ms")
        end = end / 1000.0 if end is not None else d.get("end_sec")
        start = d.get("start_ms")
        start = start / 1000.0 if start is not None else d.get("start_sec")
        if kind in CREDIT_KINDS:
            if start is None:
                return None
            return {"kind": kind, "start": round(float(start), 3), "end": round(float(end), 3) if end is not None else None}
        if end is None:
            return None
        return {"kind": kind, "start": round(float(start or 0), 3), "end": round(float(end), 3)}
    except (TypeError, ValueError):
        return None


def parse_theintrodb(data):
    """{"intro": [{start_ms, end_ms}], "recap": [...], "credits": [{start_ms, end_ms|null}]} -> tramos intro / recap / credits"""
    out = []
    if isinstance(data, dict):
        for kind in ("recap", "intro", "credits"):
            items = data.get(kind)
            for d in (items if isinstance(items, list) else [items]):
                s = _seg(kind, d)
                if s:
                    out.append(s)
    return sorted(out, key=lambda s: s["start"])


def parse_introdb(data):
    """{"intro": {start_ms, end_ms, ...}, "recap": {...}|null, "outro": {...}|null, "post_credits": {...}|null} ->
    tramos intro / recap / credits (el outro) / post_credits"""
    out = []
    if isinstance(data, dict):
        for kind, name in (("recap", "recap"), ("intro", "intro"), ("credits", "outro"), ("post_credits", "post_credits")):
            s = _seg(kind, data.get(name))
            if s:
                out.append(s)
    return sorted(out, key=lambda s: s["start"])


def valid(segs, total):
    """quita los tramos raros; total 0 o desconocido (getTotalTime() da 0 al empezar): no se comprueba el final"""
    out = []
    for s in segs:
        if s["kind"] in CREDIT_KINDS:   # sin límites de duración y el final puede faltar; solo no puede empezar tras el final
            if s["start"] < 0 or (s["end"] is not None and s["end"] <= s["start"]):
                continue
            if total and total > 0 and s["start"] >= total:
                continue
            out.append(s)
            continue
        if not MIN_LEN <= s["end"] - s["start"] <= MAX_LEN:
            continue
        if total and total > 0 and s["end"] > total:
            continue
        out.append(s)
    return out


def segment_at(segs, t, done):
    """tramo que toca enseñar en el segundo t (None si no hay, está ya saltado/descartado o casi acabado)"""
    for s in segs:
        if s["kind"] in CREDIT_KINDS or (s["kind"], s["start"]) in done:     # los créditos no son botón
            continue
        if s["start"] <= t < s["end"] - TAIL:
            return s
    return None


def credits_start(segs, total):
    """segundo en que empiezan los créditos (el primer tramo «credits»), o None. Solo si de verdad son los del final:
    empiezan a partir del 75 % del capítulo y a menos de CREDITS_WINDOW del final, acaban (si se sabe) a menos de
    CREDITS_END_GAP del final y no hay escena tras los créditos (post_credits). Si no, None: es el lado seguro
    (el aviso sale a los segundos de Ajustes). Solo mira el primero. Puro"""
    if not total or total <= 0:
        return None
    if any(isinstance(s, dict) and s.get("kind") == "post_credits" for s in segs):
        return None
    for s in segs:
        if isinstance(s, dict) and s.get("kind") == "credits":
            start, end = s.get("start"), s.get("end")
            if not isinstance(start, (int, float)) or start < CREDITS_FRAC * total or start >= total or total - start > CREDITS_WINDOW:
                return None
            if end is not None and (not isinstance(end, (int, float)) or total - end > CREDITS_END_GAP):
                return None
            return float(start)
    return None


# --- red y caché ---

def real_opener(url, timeout):
    """JSON de la URL; None si es 404 (sin datos); FAILED si falla la red, otro HTTP o el JSON. Log sin la query (lleva la clave)"""
    import urllib.error
    import urllib.parse
    import urllib.request
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "skin.palantir.flix", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        log("%s: %s" % (urllib.parse.urlsplit(url).netloc, type(e).__name__))
        return FAILED
    except Exception as e:  # noqa: BLE001
        log("%s: %s" % (urllib.parse.urlsplit(url).netloc, type(e).__name__))
        return FAILED


def _load():
    try:
        with open(cache_file(), encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(data):
    if len(data) > MAX_CACHE:
        keep = sorted(data, key=lambda k: data[k].get("t", 0) if isinstance(data[k], dict) else 0)[-MAX_CACHE:]
        data = {k: data[k] for k in keep}
    try:
        flix_common.atomic_write(cache_file(), json.dumps(data))
    except OSError as e:
        log("no se pudo guardar la caché: %s" % e)


def _good_segs(segs):
    """¿tramos bien formados? Una caché rota no debe apagar el botón durante 30 días"""
    def ok(x):
        if not isinstance(x, dict) or x.get("kind") not in KINDS:
            return False
        if not isinstance(x.get("start"), (int, float)):
            return False
        end = x.get("end")
        return isinstance(end, (int, float)) or (end is None and x["kind"] in CREDIT_KINDS)   # sin final, solo los créditos
    return isinstance(segs, list) and all(ok(x) for x in segs)


class Segs(list):
    """los tramos de un capítulo; failed = alguna petición falló (el dato puede estar incompleto: sin salto anticipado)"""
    failed = False


def _credits_usable(segs):
    """¿hay unos créditos que podrían valer (empiezan tras el segundo 0)? Los de 0 s (One Piece) nunca cuentan: sin
    la duración no se puede más, y credits_start los descarta; ahí no hace falta mirar post_credits"""
    return any(s["kind"] == "credits" and s["start"] > 0 for s in segs)


def lookup(tmdb, season, episode, opener=None, now=time.time):
    """tramos del capítulo: caché; si no, TheIntroDB y, si le falta el intro/resumen o los créditos, IntroDB (con el IMDb
    de TMDB) solo para lo que falte: lo que ya dio un servicio no lo pisa el otro. Con unos créditos válidos de
    TheIntroDB se pregunta igual a IntroDB, por post_credits (es la escena tras ellos: no se adelanta el siguiente).
    Devuelve Segs: .failed si algo falló (entonces no se adelanta nada por los créditos)"""
    opener = opener or real_opener
    key = "%s:%s:%s" % (tmdb, season, episode)
    cache = _load()
    ent = cache.get(key)
    if isinstance(ent, dict) and ent.get("v") == CACHE_V and _good_segs(ent.get("segs")):
        try:
            ttl = TTL_FAIL if ent.get("fail") else (TTL_DATA if ent["segs"] else TTL_NONE)
            if 0 <= now() - float(ent["t"]) < ttl:
                out = Segs(ent["segs"])
                out.failed = bool(ent.get("fail"))
                return out
        except (KeyError, TypeError, ValueError):  # entrada rota: como si no estuviera
            pass
    failed = False
    raw = opener(THEINTRODB % (tmdb, season, episode), TIMEOUT)
    failed |= raw is FAILED
    segs = valid(parse_theintrodb(None if raw is FAILED else raw), 0)
    kinds = {s["kind"] for s in segs}
    need_skip = not kinds & {"intro", "recap"}
    need_credits = "credits" not in kinds
    if need_skip or need_credits or _credits_usable(segs):
        ids = opener(TMDB_IDS % (tmdb, flix_common.TMDB_KEY), TIMEOUT)
        failed |= ids is FAILED
        imdb = ids.get("imdb_id") if isinstance(ids, dict) else None
        if imdb:
            raw = opener(INTRODB % (imdb, season, episode), TIMEOUT)
            failed |= raw is FAILED
            for s in valid(parse_introdb(None if raw is FAILED else raw), 0):
                # post_credits siempre: es un aviso de seguridad (no adelantar el siguiente capítulo), no un dato más
                if (s["kind"] == "credits" and need_credits) or (s["kind"] in ("intro", "recap") and need_skip) \
                        or s["kind"] == "post_credits":
                    segs.append(s)
            segs.sort(key=lambda s: s["start"])
    # un fallo (aunque llegara algo) no es «sin datos»: lo que falta se vuelve a pedir en 10 min, no en 30 días
    cache[key] = {"t": now(), "segs": segs, "v": CACHE_V, **({"fail": 1} if failed else {})}
    _save(cache)
    out = Segs(segs)
    out.failed = failed
    return out


# --- botón ---

class SkipDialog(xbmcgui.WindowXMLDialog):
    """Botón «Saltar intro»: se queda el foco, así que lo demás se reenvía al reproductor.
    Flechas: izquierda/derecha = salto corto, arriba/abajo = salto largo (como en pantalla completa); sin esto el
    botón atraparía las flechas. Se mandan a fullscreenvideo, no a «la ventana activa» (sería este mismo diálogo)."""
    # pausa, parar y adelantar no se tocan: el diálogo no las atiende y Kodi las pasa solo al reproductor
    MOVES = {1: "StepBack", 2: "StepForward", 3: "BigStepForward", 4: "BigStepBack"}   # el botón se queda las flechas
    FORWARD = {11: "Info", 24: "OSD"}

    def onInit(self):
        # etiqueta por propiedad (como UpNext): setLabel sobre el control se rompe al recargar la skin con la ventana abierta
        self.setProperty("skip_label", self.label)
        self.setFocusId(100)

    def onClick(self, cid):
        if cid == 100:
            self.on_skip()

    def onAction(self, action):
        aid = action.getId()
        if aid in flix_common.A_BACK:
            self.on_dismiss()
        elif aid in self.MOVES:
            xbmc.executebuiltin("Action(%s)" % self.MOVES[aid])     # sin ventana: el salto lo atiende Kodi, no la ventana
        elif aid in self.FORWARD:
            xbmc.executebuiltin("Action(%s,fullscreenvideo)" % self.FORWARD[aid])


class Watcher:
    """Un capítulo: busca los tiempos en un hilo y, en cada vuelta del bucle (tick), abre o cierra el botón"""

    def __init__(self, player, tmdb, season, episode):
        self.player = player
        self.segs = []
        self.failed = False         # algún servicio falló: los créditos no valen para saltar (puede faltar post_credits)
        self.done = set()           # (kind, start) de los tramos ya saltados o descartados
        self.dialog = None
        self.seg = None
        self.off = False
        self.away = 0               # ticks seguidos sin pantalla completa con el botón abierto
        self.thread = threading.Thread(target=self._look, args=(tmdb, season, episode), daemon=True)
        self.thread.start()

    def _look(self, tmdb, season, episode):
        try:
            segs = lookup(tmdb, season, episode)
            self.failed = bool(getattr(segs, "failed", False))      # antes que los tramos: credits_at no los ve sin la marca
            self.segs = segs
            log("%s:%s:%s -> %d tramos" % (tmdb, season, episode, len(self.segs)))
        except Exception as e:  # noqa: BLE001
            log("sin tiempos: %s" % e)

    def credits_at(self, total):
        """segundo en que empiezan los créditos, o None (sin datos, sin respuesta aún del hilo, fuera de ventana o fallo,
        también si alguna petición falló). Solo lee lo que ya hay: no espera ni pide nada"""
        try:
            if self.failed:
                return None
            return credits_start(valid(self.segs, total), total)
        except Exception:  # noqa: BLE001
            return None

    def tick(self, cur, total, hold=False):
        """hold = otro aviso (el de «Siguiente capítulo») ocupa la pantalla: el botón no sale"""
        if self.off:
            return
        try:
            seg = None if hold else segment_at(valid(self.segs, total), cur, self.done)
            if seg is None:
                self._close()
                return
            if self.dialog is not None:
                if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                    self.away = 0
                else:
                    self.away += 1          # 2 seguidos (un solo tick puede ser el OSD): se cierra sin descartar
                    if self.away >= 2:
                        self._close()
                        return
                if self.seg is seg or self.seg == seg:
                    return
                self._close()
            if not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                return
            dlg = SkipDialog("Custom_1112_FlixSkip.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
            dlg.label = LABELS.get(seg["kind"], LABELS["intro"])
            dlg.on_skip = lambda s=seg, d=dlg: self._skip(s, d)
            dlg.on_dismiss = lambda s=seg, d=dlg: self._dismiss(s, d)
            self.dialog, self.seg = dlg, seg
            dlg.show()
        except Exception as e:  # noqa: BLE001
            log("botón apagado: %s" % e)
            self.off = True
            self.close()

    def _skip(self, seg, dlg):
        self.done.add((seg["kind"], seg["start"]))
        try:
            self.player.seekTime(seg["end"])
        except Exception as e:  # noqa: BLE001
            log("no se pudo saltar: %s" % e)
        self._dismiss(seg, dlg)

    def _dismiss(self, seg, dlg):
        self.done.add((seg["kind"], seg["start"]))
        if self.dialog is dlg:
            self._close()

    def _close(self):
        dlg, self.dialog, self.seg = self.dialog, None, None
        self.away = 0
        if dlg is not None:
            try:
                dlg.close()
            except RuntimeError:        # ventana ya cerrada (o skin recargada)
                pass

    def close(self):
        try:
            self._close()
        except Exception as e:  # noqa: BLE001
            log("al cerrar: %s" % e)
