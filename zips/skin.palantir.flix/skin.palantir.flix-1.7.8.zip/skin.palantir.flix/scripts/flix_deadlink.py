"""Enlace caído sin selector: Palantir con UNA sola versión (o con su reproducción automática) no abre el selector y
reproduce directo; flix_autoplay no entra, así que no hay otro enlace al que saltar ni aviso propio. Si ese servidor
de AllDebrid no contesta, Kodi espera 20 s por intento (y Palantir reintenta el mismo enlace): hasta 2 min de carga y
al final nada claro (móvil 11x27 y Shield 11x26, La isla de las tentaciones, 5-nov, servidor v2w3x4.debrid.it).

Kodi no deja cortar antes (parar a mitad congela la pantalla hasta que vence el intento), así que aquí solo se avisa:
  * el intento acaba sin llegar a verse vídeo -> «El enlace no responde (AllDebrid). Prueba más tarde.»
  * «Elegir resolución» y Palantir reproduce sin selector -> «Solo hay una versión» (si Palantir no tiene su
    reproducción automática puesta: entonces no es que haya una sola).
Si el vídeo arranca, o se abre el selector (flix_autoplay se encarga), o el usuario pulsa Atrás: nada.
Lo lanza flix_playload.begin() en un hilo, solo con pulsación del usuario y ruta de Palantir.
"""
import time

LIMIT = 150         # s como mucho vigilando desde la pulsación (2 intentos de Palantir: ~2 min en el móvil)
CANCEL_IDLE = 2     # s: el intento acaba justo tras tocar el mando/pantalla = Atrás del usuario, no un fallo
PICK_ONCE_SECS = 90     # como flix_autoplay.PICK_ONCE_SECS
DEAD_TITLE = "Enlace caído"
DEAD_MSG = "El enlace no responde (AllDebrid). Prueba más tarde."
ONE_TITLE = "Elegir resolución"
ONE_MSG = "Solo hay una versión: se pone directamente."


class Tracker:
    """lógica pura: step(estado, ahora) -> lista de acciones ("una", "caido") y self.done cuando ya no hay que mirar.
    estado: sel (selector de Palantir abierto o autoplay en marcha), media (Player.HasMedia, no tráiler),
    video (vídeo de verdad: Player.HasVideo, no tráiler), idle (s sin tocar el mando), pick (se pidió «Elegir
    resolución» hace poco y Palantir no tiene su reproducción automática)"""

    def __init__(self, t0):
        self.t0, self.done, self.media_seen = t0, False, False

    def step(self, st, now):
        if self.done:
            return []
        if st["sel"]:
            self.done = True        # selector: flix_autoplay prueba otros y avisa
            return []
        out = []
        if (st["media"] or st["video"]) and not self.media_seen:
            self.media_seen = True  # Palantir ya resolvió y Kodi abre el enlace, sin selector (un fichero rápido
            if st["pick"]:          # ya trae vídeo en la misma vuelta)
                out.append("una")
        if st["video"]:
            self.done = True        # va bien
            return out
        if self.media_seen and not st["media"]:
            self.done = True        # el intento acabó sin vídeo
            if st["idle"] >= CANCEL_IDLE:
                out.append("caido")
            return out
        if now - self.t0 > LIMIT:
            self.done = True
        return out


def pick_pending(stamp, now):
    try:
        return 0 <= now - float(stamp) < PICK_ONCE_SECS
    except ValueError:
        return False


def palantir_autoplay():
    """¿Palantir tiene puesta su «Reproducción automática (solo 1080p)»? Entonces no abre el selector aunque haya más"""
    try:
        import xbmcaddon
        return xbmcaddon.Addon("plugin.video.palantir3").getSetting("autoplay_1080") == "true"
    except Exception:  # noqa: BLE001  (sin Palantir o sin ajuste: como si no)
        return False


def state(home):
    import xbmc
    cond = xbmc.getCondVisibility
    trailer = "plugin.video.youtube" in xbmc.getInfoLabel("Player.Filenameandpath") or \
        bool(home.getProperty("flix_trailer") or home.getProperty("flix_tr_on"))
    return {"sel": cond("Window.IsActive(selectdialog)") or bool(home.getProperty("flix_autoplay_state")),
            "media": cond("Player.HasMedia") and not trailer,
            "video": cond("Player.HasVideo") and not trailer,
            "idle": xbmc.getGlobalIdleTime(), "pick": False}


def notify(home, title, msg, ms):
    import xbmcgui
    home.setProperty("flix_own_notice", str(time.time()))   # flix_autoplay.close_errors no lo cierra (OWN_NOTICE)
    xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, ms)


AFTER = 90         # s tras el aviso cerrando el diálogo genérico de Kodi (el reintento de Palantir tarda ~1 min)
MARK = "flix_deadlink"     # Window(home): marca del último vigilante; otra pulsación lo releva (un solo aviso)


def kodi_failed_dialog():
    """¿está el diálogo genérico de Kodi «Fallo en la reproducción / Uno o más elementos…» (okdialog, cadena 16027)?
    Solo ese: por su texto exacto en el idioma de Kodi"""
    import xbmc
    if not xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        return False
    want = xbmc.getLocalizedString(16027).strip()
    for _ in range(10):     # recién abierto aún no tiene texto
        text = xbmc.getInfoLabel("Control.GetLabel(9)").strip()
        if text:
            return bool(want) and text == want
        xbmc.sleep(50)
    return False


def watch(home, step=0.25):
    import xbmc
    import flix_common
    mon, t0 = flix_common.quit_monitor(), time.time()
    mine = "%.3f" % t0
    home.setProperty(MARK, mine)
    tr = Tracker(t0)
    pick = pick_pending(home.getProperty("flix_pick_once"), t0) and not palantir_autoplay()
    after = None        # desde el aviso de enlace caído: se cierra el diálogo genérico de Kodi (también el del reintento
    #                     de Palantir con el mismo enlace) hasta AFTER s o hasta que algo se vea
    while not flix_common.quitting(mon) and home.getProperty(MARK) == mine:
        if after is None:
            if tr.done:
                break
            st = state(home)
            st["pick"] = pick
            for act in tr.step(st, time.time()):
                if act == "una":
                    home.clearProperty("flix_pick_once")    # gastada: no vale para el próximo selector
                    xbmc.log("[flix_deadlink] «Elegir resolución» sin selector: una sola versión", xbmc.LOGINFO)
                    notify(home, ONE_TITLE, ONE_MSG, 4000)
                elif act == "caido":
                    xbmc.log("[flix_deadlink] el enlace no llegó a reproducirse (sin selector, %.0f s): aviso"
                             % (time.time() - t0), xbmc.LOGINFO)
                    notify(home, DEAD_TITLE, DEAD_MSG, 6000)
                    after = time.time()
        else:
            if time.time() - after > AFTER or state(home)["video"]:
                break
            if kodi_failed_dialog():
                xbmc.log("[flix_deadlink] cierro el «Fallo en la reproducción» de Kodi (ya avisado)", xbmc.LOGINFO)
                xbmc.executebuiltin("Dialog.Close(okdialog,true)")
        if flix_common.wait_quit(mon, step):
            break
