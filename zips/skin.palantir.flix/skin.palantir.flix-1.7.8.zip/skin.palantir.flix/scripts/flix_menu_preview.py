"""Vista previa de las secciones en el menú lateral del Inicio TV (Carlos, 30-oct): con el foco parado en Películas,
Series… se ven arriba la cabecera del primer título de la sección y debajo sus 2 primeras filas, sin entrar.
Lo guardado (menú y 2 filas, aunque caducados) sale al instante; si falta algo, a los DWELL s parado, y lo caducado se
pide a Palantir entonces, una fila cada vez (atiende de una en una). Pasar de largo no pide nada.
La llama flix_inicio.InicioWindow.tick (cada 0,5 s) y, en el menú lateral de una sección, flix_section.SectionWindow.tick
(Carlos, 31-oct: allí la sección actual no tiene vista previa: se ve ella; «Inicio» enseña la del Inicio, con lo
guardado de sus 2 primeras filas, que publica flix_inicio, y sin pedir nunca nada a Palantir). Ajuste: Skin.Bool
flix_menu_preview (apagado de serie), primera fila de Ajustes → Personalizar menú e Inicio. En modo ligero (flix_lite)
nunca. Solo TV.
Diseño: docs/superpowers/specs/2026-10-30-vista-previa-menu-design.md"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import threading  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

HOME = xbmcgui.Window(10000)
DWELL = 1.5                     # s parado en una sección antes de pedir a Palantir
SETTLE = 0.4                    # s parado en una sección SIN guardar antes de pintar su «Cargando…» (antes esperaba
                                # DWELL y entretanto se veía el Inicio: Carlos, 7-nov). Pasando de largo no parpadea
NROWS = 2                       # filas que caben bajo la cabecera, como en el Inicio
ROW_ITEMS = 15                  # títulos por fila en la vista previa: caben ~9 (menos que pintar al bajar rápido)
LISTS = (5191, 5192)            # listas de la vista previa (FlixMenuPreview, Includes_Flix.xml)
MENU = 9000                     # menú lateral (FlixHomeChrome, Includes_FlixHome.xml)
SETTING = "flix_menu_preview"   # Skin.Bool
ON = "flix_pv_on"               # Window(home): vista previa lista (el XML la enseña con el foco en el menú)
ROW = "flix_pv_row%d"           # Window(home): nombre de la fila 1, 2
# Window(home): lo que pinta la cabecera de la vista previa, que la ventana de sección (FlixSection.xml) enseña al abrirse
# mientras carga, para que entrar en ella no salte (flix_pv_key = clave de la sección pintada: la ventana la compara con
# su fs_key). Vacías, salvo key y section, hasta que hay un título
HEADER = ("flix_pv_key", "flix_pv_section", "flix_pv_fanart", "flix_pv_logo", "flix_pv_title", "flix_pv_info",
          "flix_pv_plot")
PROPS = (ON,) + tuple(ROW % (i + 1) for i in range(len(LISTS))) + HEADER     # todas las de Window(home)
NONE, HIDE, PAINT, FETCH = "", "hide", "paint", "fetch"
# «Inicio» en el menú de una sección (Preview con home_item): su vista previa es la del Inicio. Ninguna sección se llama
# así (las de serie tienen su nombre y las añadidas van con «p3:», flix_sections_conf.new_section)
HOME_KEY = "inicio"
# Window(home): las 2 primeras filas con títulos del Inicio, nombre que se ve y ruta de su caché (la de flix_rows.peek).
# Las escribe flix_inicio.InicioWindow (publish_home); no son de PROPS: la sección no las quita al volver al Inicio
HOME_LABEL, HOME_PATH = "fi_pv%d_label", "fi_pv%d_path"
# filas del Inicio publicadas: una de reserva por si «Seguir viendo» se queda vacía dentro de la sección (el Inicio,
# tapado, no repinta y la fila se salta: Carlos, 31-oct)
HOME_ROWS = NROWS + 1
EMPTY = ([], [], False, False)  # look_up sin sección


def log(msg):
    xbmc.log("[flix_menu_preview] %s" % msg, xbmc.LOGINFO)


# lo último que este proceso escribió en cada una de PROPS. El Inicio y la sección son procesos distintos y comparten
# las propiedades: flix_section.main, al volver al Inicio, las quita (clear) solo si nadie las ha repintado después
# (still_mine; si no, quitaba lo nuevo del Inicio y este ya no lo repintaba: revisión)
WROTE = {}


def put(k, v):
    WROTE[k] = v
    HOME.setProperty(k, v)


def drop(k):
    WROTE[k] = ""
    HOME.clearProperty(k)


def still_mine():
    """¿las propiedades que escribió este proceso siguen como las dejó? False si no escribió ninguna"""
    return bool(WROTE) and all(HOME.getProperty(k) == v for k, v in WROTE.items())


def clear():
    """quita todas las propiedades de la vista previa (PROPS): flix_section.main al volver al Inicio, que repinta la
    suya"""
    for k in PROPS:
        drop(k)


def decide(enabled, key, shown, since, now, cached, fresh, fetching, tried):
    """qué hacer en esta vuelta de la vigilancia.
    key: sección de filas enfocada en el menú ('' = ninguna: «Inicio», una de lista o el menú sin foco); shown: la que
    está pintada; since: desde cuándo está enfocada key; cached: menú y filas guardados (aunque caducados); fresh: y sin
    caducar; fetching: hay una petición en marcha (de esta u otra sección); tried: ya se pidió en esta parada"""
    if not enabled or not key:
        return HIDE if shown else NONE
    dwell = now - since >= DWELL
    if key != shown:
        # sin guardar: «Cargando…» con el nombre de la sección en cuanto se para (SETTLE), sin esperar a pedirla (DWELL).
        # Mientras se pasa de largo se deja la anterior, no se quita: quitarla enseñaba el Inicio (Carlos, 7-nov)
        return PAINT if cached or now - since >= SETTLE else NONE
    if not fresh and dwell and not fetching and not tried:
        return FETCH
    return NONE


def publish_home(rows):
    """el Inicio publica sus primeras filas con títulos, [(nombre que se ve, ruta de su caché)] en su orden (las que
    pasen de HOME_ROWS no cuentan); solo se escribe lo que cambia (lo llama cada vez que pinta una fila)"""
    for i in range(HOME_ROWS):
        label, path = rows[i] if i < len(rows) else ("", "")
        for k, v in ((HOME_LABEL % (i + 1), label), (HOME_PATH % (i + 1), path)):
            if HOME.getProperty(k) != v:
                HOME.setProperty(k, v)


def home_rows():
    """las filas que publicó el Inicio, como las de una sección (todas las del Inicio son de listado: kind list)"""
    out = []
    for i in range(HOME_ROWS):
        path = HOME.getProperty(HOME_PATH % (i + 1))
        if path:
            out.append({"label": HOME.getProperty(HOME_LABEL % (i + 1)), "path": path, "kind": "list"})
    return out


def home_files(path, files):
    """lo guardado de una fila del Inicio como lo enseña él (flix_inicio.InicioWindow.show): «Seguir viendo» sin lo ya
    visto o sin progreso y «Series en seguimiento» en el orden de lo visto de verdad"""
    if not files:
        return files
    import flix_common
    import flix_progress
    import flix_rows
    if flix_progress.is_resume_row(path) and not flix_common.p3sync_busy():
        files = flix_progress.still_started(files)
    if files and flix_rows.follow_tmdb(files[0]):
        files = flix_progress.ordered_follow(files)
    return files


def slot_of(pos):
    """Container(9000).CurrentItem (1 = «Inicio», 2… = huecos flix_sec1…) → número de hueco; 0 si no es una sección.
    Los huecos vacíos van al final (flix_sections.menu_props), así que las posiciones no se saltan ninguno"""
    import flix_sections_conf
    try:
        n = int(pos) - 1
    except ValueError:
        return 0
    return n if 1 <= n <= flix_sections_conf.MAX_SECTIONS else 0


# ---------- Kodi ----------
def enabled():
    """ajuste encendido y sin modo ligero (Fire TV: la vista previa es memoria de más)"""
    return xbmc.getCondVisibility("Skin.HasSetting(%s)" % SETTING) and not xbmc.getCondVisibility(
        "Skin.HasSetting(flix_lite)")


def focused_key():
    """clave de la sección de filas enfocada en el menú lateral; '' con el foco fuera, en «Inicio» o en una de lista"""
    if not xbmc.getCondVisibility("Control.HasFocus(%d)" % MENU):
        return ""
    n = slot_of(xbmc.getInfoLabel("Container(%d).CurrentItem" % MENU))
    if not n or HOME.getProperty("flix_sec%d_kind" % n) != "rows":
        return ""
    return HOME.getProperty("flix_sec%d_key" % n)


def home_focused():
    """¿el foco en «Inicio» (posición 1) del menú lateral?"""
    return bool(xbmc.getCondVisibility("Control.HasFocus(%d)" % MENU)) and xbmc.getInfoLabel(
        "Container(%d).CurrentItem" % MENU) == "1"


def rows_of(key):
    """(filas que se ven, ¿menú guardado?) de la sección, solo con lo guardado: [] si el menú no está en la caché"""
    import flix_rows
    import flix_sections
    import flix_sections_conf
    s = flix_sections.section(key)
    if not s:
        return [], False
    menu, _ = flix_rows.peek(flix_rows.menu_path(s["src"]), keep_headers=True)
    if not menu:
        return [], False
    rows = flix_sections_conf.apply_rows(flix_rows.section_rows(s["src"], stale_ok=True, live_later=True),
                                         s.get("rows") or {})
    return rows[:NROWS], True


def look_up(key):
    """(filas, títulos guardados de cada una, cached, fresh) de la sección: cached = menú y filas guardados (aunque
    caducados); fresh = y sin caducar. HOME_KEY: las filas que publicó el Inicio; lo suyo cuenta siempre como fresco
    (aquí nunca se pide a Palantir: lo pide el Inicio). Las que se quedan sin nada que enseñar (lo de «Seguir viendo»
    ya terminado) se saltan, como en el Inicio"""
    import flix_rows
    if key == HOME_KEY:
        rows = home_rows()
        raw = [flix_rows.peek(r["path"])[0] for r in rows]
        keep = [(r, home_files(r["path"], f)) for r, f in zip(rows, raw)]
        keep = [(r, f) for r, f in keep if f][:NROWS]
        cached = len(keep) > 0 and all(raw)
        return [r for r, _ in keep], [f for _, f in keep], cached, cached
    rows, has_menu = rows_of(key)
    peeks = [flix_rows.peek(r["path"]) for r in rows]
    cached = has_menu and len(rows) > 0 and all(f for f, _ in peeks)
    return rows, [f for f, _ in peeks], cached, cached and all(fr for _, fr in peeks)


def section_name(key):
    """nombre que se ve de la sección key en el menú ('' si ya no existe)"""
    if key == HOME_KEY:
        return "Inicio"                     # el del menú (FlixHomeChrome)
    import flix_sections
    import flix_sections_conf
    s = flix_sections.section(key)
    return flix_sections_conf.shown(s) if s else ""


def header(f):
    """(fanart, logo, título, datos, sinopsis) del título f (dict de Palantir) para la cabecera: lo mismo que lee el
    XML del primer título de la lista 5191 (título limpio como P3Titulo; datos «año · min · géneros»); todo "" sin título"""
    if not f:
        return "", "", "", "", ""
    from flix_items import clean_title
    art = f.get("art") or {}
    parts = []
    if f.get("year"):
        parts.append(str(f["year"]))
    if f.get("duration"):
        try:
            parts.append("%d min" % (int(f["duration"]) // 60))     # segundos (to_listitem: tag.setDuration)
        except (TypeError, ValueError):
            pass
    genre = f.get("genre") or []
    genre = " / ".join(genre) if isinstance(genre, (list, tuple)) else str(genre)
    if genre:
        parts.append(genre)
    return (art.get("fanart") or "", art.get("clearlogo") or "", clean_title(f.get("label", "")),
            "  ·  ".join(parts), f.get("plot") or "")


def entry_header(key):
    """cabecera de entrada de la sección key solo con lo guardado (sin Palantir): la pone flix_section.main al pasar de
    una sección a otra desde su menú, para que la nueva abra como si viniera de la vista previa. Las mismas propiedades
    que Preview.paint_header (el primer título de la primera fila). Sin un primer título guardado no toca nada: False"""
    try:
        _, files, _, _ = look_up(key)
        first = files[0][0] if files and files[0] else None
        if not first:
            return False
        Preview.paint_header(key, first)
        return True
    except Exception as e:  # noqa: BLE001  (sin cabecera, la sección abre igual)
        log("%s: cabecera de entrada: %s" % (key, e))
        return False


class Preview:
    """la vista previa del menú lateral: la ventana que la aloja (InicioWindow, SectionWindow) la llama en cada vuelta de
    su vigilancia (tick). Solo toca las listas con la ventana delante (win.active(), como el Inicio: al recargarse la
    skin Kodi las destruye). palantir_busy(): la ventana está pidiendo a Palantir (atiende de una en una): mientras, no
    se pide. own: la clave de la sección que la aloja ("" en el Inicio): con el foco en ella no hay vista previa (se ve
    la sección, como «Inicio» en el Inicio). home_item: «Inicio» del menú enseña la vista previa del Inicio (solo la
    sección; en el Inicio, «Inicio» es él mismo)"""

    def __init__(self, win, on_idle, palantir_busy=lambda: False, own="", home_item=False):
        self.win, self.on_idle, self.palantir_busy, self.own = win, on_idle, palantir_busy, own
        self.home_item = home_item
        self.key = ""               # sección enfocada
        self.since = 0.0            # desde cuándo
        self.shown = ""             # sección pintada
        self.dirty = False          # lo pintado puede estar viejo: el Inicio estuvo tapado (leave) sin tocar las listas
        self.tried = False          # ya se pidió a Palantir en esta parada
        self.fetching = False
        self.sync = False           # tests: pedir en el mismo hilo
        self.look = EMPTY           # lo guardado de la sección enfocada: (filas, títulos, cached, fresh)
        # key, look y lo pintado los cambian dos hilos (la vigilancia y el que pide): siempre con el cerrojo
        self.lock = threading.Lock()
        # leave() deja las propiedades puestas (sin parpadeo al volver), pero un Inicio nuevo (fi_reload, recarga de la
        # skin, relevo de fi_token) empieza sin nada pintado: sin esto flix_pv_on quedaría puesta y el XML enseñaría la
        # vista previa vacía y escondería FlixHero con el foco en el menú. La sección (own) quita igual la del Inicio (con
        # el foco en su propia clave el XML la enseñaría vacía), pero no la cabecera: es la de entrada, la lee su XML
        self.hide(header=not own)

    def busy(self):
        """¿pidiendo a Palantir? El Inicio no pide a la vez (atiende de una en una)"""
        return self.fetching

    def tick(self, now):
        try:
            self._tick(now)
        except Exception as e:  # noqa: BLE001  (la vista previa nunca deja el Inicio a medias)
            log("error: %s" % e)
            self.hide()

    def leave(self, hide=False):
        """el Inicio, tapado (ficha, vídeo, otra ventana) o con el ajuste apagado: lo que se esté pidiendo para antes
        de la fila siguiente (Palantir, libre). No toca las listas; hide: quita también la pintada (propiedades).
        Lo pintado queda por si se vuelve a la misma sección (sin parpadeo), pero se repinta entonces (dirty): mientras
        tanto pudo guardarse lo que faltaba (al entrar en ella) o recargarse la skin (listas vacías)"""
        with self.lock:
            self.key, self.dirty = "", True
        if hide and self.shown:
            self.hide()

    def _tick(self, now):
        # el ajuste ya lo mira el Inicio antes de llamar (InicioWindow.tick)
        active = self.win.active()
        key = focused_key() if active else ""
        if not key and self.home_item and active and home_focused():
            key = HOME_KEY                  # «Inicio» en el menú de una sección: la vista previa del Inicio
        if key == self.own:                 # la sección que la aloja: se ve ella (own "" en el Inicio: nada cambia)
            key = ""
        if key != self.key:
            # la caché se lee al cambiar de sección (y al acabar de pedir), no en cada vuelta: peek corrige el progreso
            # con watched.db (Carlos, 30-oct: «¿ralentizará la skin?»)
            look = look_up(key) if key else EMPTY
            with self.lock:
                self.key, self.since, self.tried, self.look = key, now, False, look
        rows, files, cached, fresh = self.look
        if key == HOME_KEY and not cached:
            key = ""                        # sin lo guardado del Inicio, sin vista previa (como antes): no se pide nada
        fetching = self.fetching or self.palantir_busy()
        act = decide(True, key, self.shown, self.since, now, cached, fresh, fetching, self.tried)
        if self.dirty and key and key == self.shown:
            act = PAINT                     # de vuelta a la misma sección: con lo guardado ahora, sin quitarla antes
        if act == HIDE:
            self.hide()
        elif act == PAINT:
            self.paint(key, rows, files)
            if not fresh and now - self.since >= DWELL and not fetching and not self.tried:
                self.fetch(key)
        elif act == FETCH:
            self.fetch(key)

    # ---------- pintar ----------
    def paint(self, key, rows, files):
        """las filas con lo guardado (o «Cargando…») y sus nombres; la cabecera la lee el XML de la lista 5191.
        Sin filas aún (menú de la sección sin guardar): «Cargando…» en la primera"""
        import flix_section
        name = section_name(key)            # lee sections.json: fuera del cerrojo
        with self.lock:
            if self.key != key:             # el foco ya se fue a otra
                return
            self.dirty = False
            for i, lid in enumerate(LISTS):
                row = rows[i] if i < len(rows) else None
                got = files[i] if i < len(files) else None
                # el nombre que le puso el usuario (Editar filas: title), como la sección
                put(ROW % (i + 1), (row.get("title") or row["label"]) if row else "")
                if got:
                    items = [flix_section.make_item(f, row) for f in got[:ROW_ITEMS]]
                elif row or (not rows and i == 0):
                    items = [flix_section.placeholder(flix_section.LOADING)]
                else:
                    items = []
                self.fill(lid, items)
            self.shown = key
            put(ON, "1")
            self.paint_header(key, files[0][0] if files and files[0] else None, name)
        if self.__dict__.get("logged") != key:      # una línea por sección enfocada, no por repintado (PY-15)
            self.logged = key
            log("%s: vista previa" % key)

    @staticmethod
    def paint_header(key, first, name=None):
        """las propiedades de la cabecera (HEADER) con el primer título de la primera fila; sin él, solo la clave y el
        nombre de la sección (el XML de la sección enseña el fondo vacío y su nombre mientras llegan los títulos).
        name: el nombre ya buscado (paint lo busca antes de coger el cerrojo: lee sections.json); None = buscarlo"""
        if name is None:
            name = section_name(key)
        values = (key, name) + header(first)
        for k, v in zip(HEADER, values):
            put(k, v)

    def fill(self, lid, items):
        if not self.win.active():
            return
        lst = self.win.getControl(lid)
        lst.reset()
        if items:
            lst.addItems(items)

    def hide(self, header=True):
        """quita la vista previa (propiedades); header=False deja la cabecera (HEADER)"""
        with self.lock:
            drop(ON)
            for i in range(len(LISTS)):
                drop(ROW % (i + 1))
            if header:
                for k in HEADER:
                    drop(k)
            self.shown = ""

    # ---------- pedir ----------
    def fetch(self, key):
        """pide a Palantir lo que falte o esté caducado de la sección, una fila cada vez; para si el foco se va"""
        if key == HOME_KEY:                 # lo del Inicio, solo lo guardado: lo pide él
            return
        self.fetching = True                # se avisa antes de mirar (el worker del Inicio, igual): nunca los dos
        if self.palantir_busy():
            self.fetching = False
            return
        self.tried = True
        try:
            if self.sync:
                self._fetch(key)
            else:
                threading.Thread(target=self._fetch, args=(key,), daemon=True).start()
        except Exception as e:  # noqa: BLE001  (sin hilo: el Inicio no se queda esperando)
            log("%s: %s" % (key, e))
            self.fetching = False
            self.on_idle()

    def _fetch(self, key):
        import flix_rows
        import flix_section
        import flix_sections
        import flix_sections_conf
        try:
            rows, has_menu = rows_of(key)
            if not has_menu:                    # menú sin guardar: se pide (una llamada a Palantir)
                s = flix_sections.section(key)
                rows = flix_sections_conf.apply_rows(flix_rows.section_rows(s["src"], stale_ok=True),
                                                     s.get("rows") or {})[:NROWS]
                self.paint(key, rows, [flix_rows.peek(r["path"])[0] for r in rows])
            for i, row in enumerate(rows):
                # el foco se fue o el Inicio está tapado: lo que estaba llegando ya se guardó, no se pide más
                if self.key != key or not self.win.active():
                    break
                if flix_rows.is_fresh(row["path"]):
                    continue
                got, _ = flix_rows.fetch(row["path"], force=True, save=False)
                if got:
                    with self.lock:
                        if self.key == key and self.shown == key:
                            self.fill(LISTS[i], [flix_section.make_item(f, row) for f in got[:ROW_ITEMS]])
                            if i == 0:          # su primer título es el de la cabecera (también la de la sección)
                                self.paint_header(key, got[0])
            flix_rows.flush(keep=True)
            look = look_up(key)                 # lo nuevo, para la próxima vuelta (lento: fuera del cerrojo)
            with self.lock:
                if self.key == key:             # y solo si el foco sigue ahí: si no, pisaría lo de la otra sección
                    self.look = look
        except Exception as e:  # noqa: BLE001
            log("%s: %s" % (key, e))
        finally:
            self.fetching = False
            self.on_idle()


# ---------- ajuste (Ajustes → Personalizar menú e Inicio, primera fila; flix_editor_sources.MenuSource) ----------
def label(on=None):
    """texto de la fila del ajuste; on: el valor ya conocido (si no, se lee de la skin)"""
    if on is None:
        on = xbmc.getCondVisibility("Skin.HasSetting(%s)" % SETTING)
    return "Vista previa al pasar por el menú: %s" % ("Sí" if on else "No")


def toggle():
    """enciende o apaga el ajuste y devuelve el valor nuevo; el builtin va por la cola de Kodi: se espera (acotado) a que
    se vea, como flix_lite"""
    on = not xbmc.getCondVisibility("Skin.HasSetting(%s)" % SETTING)
    xbmc.executebuiltin("Skin.%s(%s)" % ("SetBool" if on else "Reset", SETTING))
    for _ in range(40):
        if bool(xbmc.getCondVisibility("Skin.HasSetting(%s)" % SETTING)) == on:
            break
        xbmc.sleep(50)
    return on
