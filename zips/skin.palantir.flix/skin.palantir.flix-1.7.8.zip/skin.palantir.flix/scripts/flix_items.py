"""Carátula de Palantir -> ListItem de Kodi (filas de las secciones, del Inicio y del buscador).

Aquí y no en flix_search (revisión 29-oct ARR-19, lote 21): flix_section, y con él el Inicio TV, importaban el
buscador entero (urllib, difflib, unicodedata, hilos… ~17 ms propios en proot) solo por to_listitem. flix_search la
vuelve a exportar (from flix_items import …), así que flix_search.to_listitem sigue siendo la misma función."""
import os
import re
import sys

import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import clean  # noqa: E402


def brackets(label):
    return re.findall(r"\[([^\]]*)\]", clean(label))


def clean_title(label):
    return re.split(r"\s+\(\d{4}\)|\s+\[", clean(label))[0].strip()


def quality_from_label(label):
    m = brackets(label)
    up = (m[-1] if m else "").upper()
    if "4K" in up and "DV" in up:
        return "4K · DV"
    for key, val in (("4K", "4K"), ("DV", "DV"), ("HDR", "HDR"), ("1080", "1080p"), ("720", "720p")):
        if key in up:
            return val
    return ""


def langs_from_label(label):
    m = brackets(label)
    return m[0] if len(m) >= 2 else ""


def hdr_from_label(label):
    """el mejor HDR entre las versiones de la etiqueta de Palantir («[DV HDR10, 4K HDR10+, 1080p]»): 'hdr10plus',
    'hdr10', 'hdr' o ''. Para el icono de la cabecera (FlixMetaRow): en las condiciones de Kodi el «+» es «y» y no se
    puede buscar «HDR10+» desde el XML (Carlos, 7-nov)"""
    up = (label or "").upper()
    if "HDR10+" in up or "HDR10PLUS" in up:
        return "hdr10plus"
    if "HDR10" in up:
        return "hdr10"
    if "HDR" in up:
        return "hdr"
    return ""


_WIDTHS = []


def _widths():
    if not _WIDTHS:
        import json
        import os
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "flix_plot_widths.json"),
                      encoding="utf-8") as fh:
                _WIDTHS.append(json.load(fh))
        except (OSError, ValueError):
            _WIDTHS.append({})
    return _WIDTHS[0]


def plot_short(plot, width, lines, slack=0.97):
    """la sinopsis en `lines` líneas de `width` px (NotoSans 25, tools/make_plot_widths.py) y, si no cabe, cortada al
    final de una palabra con «…»: el textbox de Kodi la cortaba a media frase sin puntos suspensivos (Carlos, 7-nov).
    slack deja un margen por si Kodi parte las líneas un poco antes"""
    text = " ".join((plot or "").split())
    if not text:
        return ""
    w = _widths()
    avg = w.get("n", 13.0)
    size = lambda s: sum(w.get(c, avg) for c in s)
    room, space = width * slack, w.get(" ", 6.5)
    out, cur, cur_w = [], [], 0.0
    words = text.split(" ")
    for i, word in enumerate(words):
        ww = size(word)
        if cur and cur_w + space + ww > room:
            out.append(cur)
            cur, cur_w = [], 0.0
            if len(out) == lines:
                break
        cur.append(word)
        cur_w = cur_w + (space if cur_w else 0) + ww
    else:
        out.append(cur)
        return text if len(out) <= lines else ""
    # no cabe: la última línea con «…» quitando palabras hasta que entre
    last = out[lines - 1]
    ell = size("…")
    while last and size(" ".join(last)) + ell > room:
        last = last[:-1]
    out[lines - 1] = last
    lead = " ".join(" ".join(l) for l in out[:lines - 1])
    tail = " ".join(last).rstrip(",;:.-–— ")
    return ((lead + " ") if lead else "") + tail + "…"


def to_listitem(f):
    label = f.get("label", "")
    li = xbmcgui.ListItem(label)
    li.setPath(f.get("file", ""))
    li.setArt(f.get("art") or {})
    li.setProperty("IsPlayable", "false")
    li.setProperty("P3Titulo", clean_title(label))
    li.setProperty("P3Calidad", quality_from_label(label))
    li.setProperty("P3IdiomaStr", langs_from_label(label))
    li.setProperty("FlixHDR", hdr_from_label(label))
    try:                                        # edad guardada de TMDB (flix_age); sin dato, nada
        import flix_age
        li.setProperty("FlixAge", flix_age.age_of(f.get("file", "")))
    except Exception:  # noqa: BLE001
        pass
    li.setProperty("filetype", f.get("filetype", "file"))
    tag = li.getVideoInfoTag()
    tag.setTitle(clean_title(label))
    tag.setPlot(f.get("plot") or "")
    li.setProperty("FlixPlot2", plot_short(f.get("plot"), 820, 2))      # cabecera del Inicio (2 líneas)
    li.setProperty("FlixPlot4", plot_short(f.get("plot"), 900, 4))      # cabecera de la sección (4 líneas)
    if f.get("year"):
        tag.setYear(int(f["year"]))
    if f.get("rating"):
        tag.setRating(float(f["rating"]))
    if f.get("genre"):
        tag.setGenres(list(f["genre"]))
    if f.get("duration"):
        tag.setDuration(int(f["duration"]))
    if f.get("mpaa"):
        tag.setMpaa(f["mpaa"])
    if f.get("premiered"):
        tag.setPremiered(f["premiered"])
    tag.setMediaType("tvshow" if f.get("filetype") == "directory" else "movie")
    r = f.get("resume") or {}
    if r.get("position"):
        tag.setResumePoint(float(r["position"]), float(r.get("total") or 0))
    if f.get("playcount"):
        tag.setPlaycount(int(f["playcount"]))   # ✓ de vista en el póster (secciones y buscador; faltaba)
    return li
