"""Escribir desde el móvil: QR en el teclado de Kodi (DialogKeyboard: clave de MDBList, nombres, contraseñas…) y en
el del buscador. Meter una clave de 25 letras con el mando era una locura (Carlos, 24-oct).

Mientras el teclado está abierto, la tele sirve en la red de casa una página pequeña (http://<ip>:<puerto>/<código>)
y enseña su QR. El móvil la abre, se escribe, pega o dicta, y el texto llega a la tele:
  - teclado de Kodi: Input.SendText con done (como la app Kore) -> el teclado lo acepta y se cierra;
  - buscador: on_text de flix_search (busca, como el dictado por voz).
Coste (Fire TV modestas): nada sin teclado abierto; con él, un hilo que espera conexiones (poll 0,5 s). El QR se hace
una vez por sesión de Kodi: el código y el puerto se guardan en Window(home) y la imagen en special://temp.
Solo red de casa y con el código aleatorio de la sesión (sin él, 404). Sin internet ni Worker.
Uso: RunScript(special://skin/scripts/flix_phonekb.py,keyboard)   (DialogKeyboard.xml, solo TV)
     flix_phonekb.PhoneKeyboard(on_text, title).start() / .stop()   (flix_search.py)"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import hashlib
import html
import json
import re
import secrets
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor"))

HOME = xbmcgui.Window(10000)
PORTS = range(47801, 47811)
MAX_TEXT = 2000
QR_PROP = "flix_pkb_qr"          # Window(home): imagen del QR del teclado de Kodi (DialogKeyboard.xml)
URL_PROP = "flix_pkb_url"
RUNNING = "flix_pkb_kb"          # Window(home): hay un teclado de Kodi con QR en marcha (uno a la vez)


def log(msg):
    xbmc.log("[flix_phonekb] %s" % msg, xbmc.LOGINFO)


def token():
    """código aleatorio de la sesión de Kodi (misma dirección -> mismo QR, se hace una vez)"""
    t = HOME.getProperty("flix_pkb_token")
    if not t:
        t = secrets.token_urlsafe(6).replace("-", "a").replace("_", "b")
        HOME.setProperty("flix_pkb_token", t)
    return t


IPV4 = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def lan_ip(wait=3.0):
    """IP de la tele en casa: la de la salida por defecto (socket UDP «conectado», no envía nada) y si no la de Kodi,
    que al principio responde «Busy» mientras la consulta (el QR salía con «Busy:47801»)"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))         # TEST-NET: solo elige la interfaz, no sale ningún paquete
            ip = s.getsockname()[0]
        finally:
            s.close()
        if IPV4.match(ip) and not ip.startswith(("127.", "0.")):
            return ip
    except OSError:
        pass
    end = time.time() + wait
    while True:
        ip = xbmc.getInfoLabel("Network.IPAddress")
        if IPV4.match(ip or "") and not ip.startswith(("127.", "0.")):
            return ip
        if time.time() >= end:
            return ""
        xbmc.sleep(200)


def page(title, password):
    """página del móvil: un cuadro, «Enviar» y el resultado; se puede volver a enviar (buscador)"""
    kind = "password" if password else "text"
    return """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>KER0N3 MEDIA</title>
<style>
:root{color-scheme:dark}
body{margin:0;background:#141418;color:#f2f2f2;font:17px system-ui,sans-serif;padding:24px 16px}
h1{font-size:15px;font-weight:600;color:#9a9a9a;margin:0 0 6px;letter-spacing:.08em}
h2{font-size:22px;margin:0 0 20px}
input{width:100%;box-sizing:border-box;font-size:20px;padding:14px;border-radius:12px;border:0;background:#26262e;color:#fff}
button{margin-top:14px;width:100%;font-size:19px;padding:14px;border-radius:12px;border:0;background:#fff;color:#000;font-weight:700}
p{color:#9a9a9a;min-height:1.4em}
</style></head><body>
<h1>KER0N3 MEDIA</h1><h2>{TITLE}</h2>
<form id="f"><input id="t" type="{KIND}" autofocus autocomplete="off" autocapitalize="off" spellcheck="false">
<button>Enviar a la tele</button></form><p id="r"></p>
<script>
document.getElementById('f').onsubmit=function(e){e.preventDefault();var t=document.getElementById('t'),r=document.getElementById('r');
if(!t.value){return}r.textContent='Enviando…';
fetch(location.pathname,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'t='+encodeURIComponent(t.value)})
.then(function(x){r.textContent=x.ok?'Enviado ✓':'La tele ya no espera texto (vuelve a escanear el QR)';if(x.ok){t.value=''}})
.catch(function(){r.textContent='No llega a la tele: ¿misma WiFi?'})}
</script></body></html>""".replace("{TITLE}", html.escape(title or "Escribe aquí")).replace("{KIND}", kind)


def make_handler(owner):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):          # sin ruido en kodi.log
            pass

        def _send(self, code, body, ctype="text/html; charset=utf-8"):
            data = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path.split("?")[0] != "/" + owner.token:
                return self._send(404, "")
            self._send(200, page(owner.title, owner.password))

        def do_POST(self):
            if self.path.split("?")[0] != "/" + owner.token or not owner.alive:
                return self._send(404, "")
            n = min(int(self.headers.get("Content-Length") or 0), MAX_TEXT * 4)
            text = urllib.parse.parse_qs(self.rfile.read(n).decode("utf-8", "replace")).get("t", [""])[0]
            text = text.replace("\r", " ").replace("\n", " ").strip()[:MAX_TEXT]
            if not text:
                return self._send(400, "")
            self._send(200, "ok", "text/plain; charset=utf-8")
            log("texto recibido del móvil (%d caracteres)" % len(text))
            threading.Thread(target=owner.on_text, args=(text,), daemon=True).start()
    return Handler


def qr_path(url):
    import flix_common
    return flix_common.temp_image("flix_pkb_%s.png" % hashlib.sha1(url.encode("utf-8")).hexdigest()[:12])


def make_qr(url):
    """PNG del QR (segno, Python puro); se reutiliza si ya existe (misma dirección en toda la sesión)"""
    path = qr_path(url)
    if not os.path.exists(path):
        t0 = time.time()
        import segno
        segno.make(url, error="l").save(path, scale=10, border=2, dark="#000000", light="#ffffff")
        log("QR hecho en %.2f s" % (time.time() - t0))
    return path


class PhoneKeyboard:
    """servidor + QR mientras dura un teclado. on_text(texto) se llama en otro hilo. props: ventana donde se ponen
    qr/url (Window(home) para el teclado de Kodi; la del buscador para el suyo)"""

    def __init__(self, on_text, title="", password=False, props=None, qr_prop=QR_PROP, url_prop=URL_PROP):
        self.on_text, self.title, self.password = on_text, title, password
        self.props, self.qr_prop, self.url_prop = props or HOME, qr_prop, url_prop
        self.token, self.server, self.alive = token(), None, False

    def bind(self):
        last = HOME.getProperty("flix_pkb_port")
        order = ([int(last)] if last.isdigit() else []) + [p for p in PORTS if str(p) != last]
        for port in order:
            try:
                import flix_common
                srv = flix_common.http_server(("0.0.0.0", port), make_handler(self))
                HOME.setProperty("flix_pkb_port", str(port))
                return srv
            except OSError:
                continue
        return None

    def start(self):
        self.alive = True
        threading.Thread(target=self._run, daemon=True).start()
        return self

    def _run(self):
        ip = lan_ip()
        if not ip:
            log("sin IP de red: sin QR")
            return
        self.server = self.bind()
        if self.server is None:
            log("ningún puerto libre en %d-%d: sin QR" % (PORTS[0], PORTS[-1]))
            return
        url = "http://%s:%d/%s" % (ip, self.server.server_address[1], self.token)
        try:
            img = make_qr(url)
        except Exception as e:  # noqa: BLE001
            log("no pude hacer el QR: %s" % e)
            self._close()
            return
        if not self.alive:                  # el teclado se cerró mientras tanto
            self._close()
            return
        try:
            size = "%d B" % os.path.getsize(img)
        except OSError as e:
            size = "sin fichero (%s)" % e
        # el QR sale en blanco en los aparatos («Direct texture file loading failed»): qué fichero se le da a Kodi
        # y cuánto pesa, para la próxima vez (revisión 29-oct APA-02; sin arreglo a ciegas)
        log("QR a la vista: %s, %s" % (img, size))
        self.props.setProperty(self.qr_prop, img)
        self.props.setProperty(self.url_prop, url.split("//", 1)[1].split("/", 1)[0])
        log("esperando texto del móvil en el puerto %d" % self.server.server_address[1])
        try:
            self.server.serve_forever(poll_interval=0.5)
        except Exception as e:  # noqa: BLE001
            log("servidor: %s" % e)

    def _close(self):
        srv, self.server = self.server, None
        if srv is not None:
            try:
                srv.server_close()
            except Exception:  # noqa: BLE001
                pass

    def stop(self):
        self.alive = False
        self.props.clearProperty(self.qr_prop)
        self.props.clearProperty(self.url_prop)
        srv = self.server
        if srv is not None:
            threading.Thread(target=lambda: (srv.shutdown(), self._close()), daemon=True).start()


def send_to_keyboard(text):
    """como Kore: el texto al teclado de Kodi abierto y aceptado"""
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Input.SendText",
                                    "params": {"text": text, "done": True}}))


def keyboard():
    """DialogKeyboard.xml onload: QR mientras el teclado siga abierto (el buscador cierra el suyo al momento)"""
    mon = xbmc.Monitor()
    if mon.waitForAbort(0.4) or not xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
        return
    since = HOME.getProperty(RUNNING)
    if since and time.time() - float(since) < 600:
        return                              # ya hay uno (teclado sobre teclado)
    HOME.setProperty(RUNNING, str(time.time()))
    title = xbmc.getInfoLabel("Control.GetLabel(311)")
    password = xbmc.getCondVisibility("Control.IsVisible(310)")
    pk = PhoneKeyboard(send_to_keyboard, title, password).start()
    try:
        while xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)") and not mon.waitForAbort(0.3):
            HOME.setProperty(RUNNING, str(time.time()))
    finally:
        pk.stop()
        HOME.clearProperty(RUNNING)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "keyboard":
        keyboard()
