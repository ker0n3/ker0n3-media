# -*- coding: utf-8 -*-
"""Edad recomendada (calificación española de TMDB) para la cabecera del Inicio (Carlos, 7-nov).

Palantir no la manda en las carátulas (ListItem.Mpaa vacío; solo VideoPlayer.mpaa al reproducir). Se pide a TMDB
UNA vez por título y se guarda para siempre en ages.json (la calificación no cambia); sin dato español se apunta
vacío y se vuelve a mirar a los 30 días. Nunca en el camino del foco: el Inicio llama a want() al pintar sus filas y
un hilo de este intérprete las pide en segundo plano, de una en una con pausa, y avisa con
Window(home).Property(flix_age_rev) para que el Inicio ponga FlixAge en las carátulas ya pintadas (apply).
Valores: TP, 7, 10, 12, 13, 16, 18 (el icono es media/flix/badges/age_<valor>.png)."""
import ast
import json
import os
import re
import threading
import time

import xbmc
import xbmcgui

import flix_common

HOME = xbmcgui.Window(10000)
REV = "flix_age_rev"
KIND = {"movies": "m", "movie": "m", "tvshows": "t", "tvshow": "t", "seasons": "t", "episodes": "t"}
TMDB = "https://api.themoviedb.org/3/%s/%s/%s?api_key=%s"
TIMEOUT = 6
PAUSE = 0.35            # s entre dos peticiones
MAX_PER_RUN = 120       # como mucho por tanda (lo demás, en la siguiente)
SAVE_EVERY = 15
RETRY = 30 * 86400      # sin calificación española: se vuelve a mirar al mes
VALID = ("TP", "7", "10", "12", "13", "16", "18")

_mem = {"data": None, "sig": None}
_queue = []
_busy = threading.Lock()
_running = [False]


def log(msg):
    xbmc.log("[flix_age] %s" % msg, xbmc.LOGINFO)


def cache_file():
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/ages.json" % xbmc.getSkinDir())


def _sig(path):
    try:
        st = os.stat(path)
        return st.st_mtime_ns, st.st_size
    except OSError:
        return None


def data():
    """{clave: [valor, hora]} de ages.json (se relee solo si cambió el fichero)"""
    path = cache_file()
    sig = _sig(path)
    if _mem["data"] is None or sig != _mem["sig"]:
        import flix_cache
        _mem["data"] = {k: v for k, v in flix_cache.load_dict(path).items() if isinstance(v, list) and len(v) == 2}
        _mem["sig"] = sig
    return _mem["data"]


def key(path):
    """'m603' / 't1399' de una ruta de Palantir; '' si no es un título"""
    if not path or "palantir3" not in path or "?" not in path:
        return ""
    try:
        info = ast.literal_eval(flix_common.decode_route(path))
    except Exception:  # noqa: BLE001
        return ""
    if not isinstance(info, dict):
        return ""
    tmdb = str(info.get("tmdb") or "")
    kind = KIND.get(info.get("content") or "")
    return kind + tmdb if kind and tmdb.isdigit() and tmdb != "0" else ""


def normalize(cert):
    """calificación de TMDB a TP / 7 / 10 / 12 / 13 / 16 / 18; '' si no se entiende"""
    c = (cert or "").strip().upper().replace("+", "")
    if c in ("TP", "A", "APTA", "ATP", "T", "TODOS", "ALL", "0", "APTA PARA TODOS LOS PÚBLICOS"):
        return "TP"
    if c in ("X", "ADULTOS"):
        return "18"
    m = re.search(r"\d+", c)
    if not m:
        return ""
    n = int(m.group(0))
    for v in (18, 16, 13, 12, 10, 7):
        if n >= v:
            return str(v)
    return "TP"


def age_of(path, d=None):
    k = key(path)
    if not k:
        return ""
    v = (d if d is not None else data()).get(k)
    return v[0] if v and v[0] in VALID else ""


def apply(items):
    """FlixAge en carátulas ya pintadas (sin repintar), como flix_newep.update; cualquier fallo se traga"""
    try:
        d = data()
        for li in items or []:
            v = age_of(li.getPath(), d)
            if li.getProperty("FlixAge") != v:
                li.setProperty("FlixAge", v)
    except Exception as e:  # noqa: BLE001
        log("pintar: %s" % type(e).__name__)


def missing(files, now=None):
    now = time.time() if now is None else now
    d = data()
    out = []
    for f in files or []:
        k = key((f or {}).get("file", ""))
        if not k:
            continue
        v = d.get(k)
        if v is None or (not v[0] and now - float(v[1] or 0) > RETRY):
            out.append(k)
    return out


def fetch(k, opener=None):
    """la calificación española de TMDB para la clave; '' si no hay"""
    import urllib.request
    kind, tmdb = ("movie", k[1:]) if k[0] == "m" else ("tv", k[1:])
    what = "release_dates" if kind == "movie" else "content_ratings"
    with (opener or urllib.request.urlopen)(TMDB % (kind, tmdb, what, flix_common.TMDB_KEY), timeout=TIMEOUT) as r:
        js = json.loads(r.read().decode("utf-8"))
    for res in js.get("results") or []:
        if res.get("iso_3166_1") != "ES":
            continue
        if kind == "tv":
            return normalize(res.get("rating"))
        for rd in res.get("release_dates") or []:
            v = normalize(rd.get("certification"))
            if v:
                return v
    return ""


def _save(found):
    import flix_cache

    def change(disk):
        disk = {k: v for k, v in disk.items() if isinstance(v, list) and len(v) == 2}
        disk.update(found)
        return disk
    flix_cache.update_json(cache_file(), change)
    _mem["data"] = None                     # se relee con lo de otros intérpretes


def _run(opener=None, sleep=None):
    found, done = {}, 0
    try:
        while done < MAX_PER_RUN and not flix_common.quitting():
            with _busy:
                if not _queue:
                    break
                k = _queue.pop(0)
            try:
                v = fetch(k, opener)
            except Exception as e:  # noqa: BLE001  (sin red, TMDB caído: se deja para otra vez)
                log("TMDB no responde (%s): lo dejo para luego" % type(e).__name__)
                break
            found[k] = [v, time.time()]
            done += 1
            if len(found) >= SAVE_EVERY:
                _save(found)
                found = {}
                HOME.setProperty(REV, str(time.time()))
            (sleep or flix_common.quit_sleep)(PAUSE)
    finally:
        if found:
            _save(found)
            HOME.setProperty(REV, str(time.time()))
        if done:
            log("%d edades nuevas de TMDB" % done)
        with _busy:
            _queue.clear()
            _running[0] = False


def want(files):
    """pide en segundo plano las que falten de estas carátulas (un hilo por intérprete)"""
    try:
        ks = missing(files)
    except Exception:  # noqa: BLE001
        return
    if not ks:
        return
    with _busy:
        for k in ks:
            if k not in _queue:
                _queue.append(k)
        if _running[0]:
            return
        _running[0] = True
    threading.Thread(target=_run, daemon=True, name="flix_age").start()
