"""Selector de versiones de Palantir (DialogSelect, lista id 3): reproducción automática y reintentos invisibles.

Lo lanza el <onload> de DialogSelect.xml (también con el autoplay apagado) salvo en los selectores de los Ajustes de
Kodi y del OSD del vídeo, que nunca son de Palantir (revisión 7-nov XML-09). El selector de Palantir sale OCULTO
(rueda) y solo se enseña si este script pone Window(home).Property(flix_select_show) (modo manual o fallo). Si el
selector resulta ser otro de Kodi (idiomas, subtítulos…), decide() lo dice y no se toca su foco (PY-26).

Calidades, orden y remux: Ajustes → Orden de calidades (flix_quality.py). Con la reproducción automática
apagada se enseña el selector. Dentro de cada calidad, primero las versiones con Esp.

Palantir reabre el selector en tres casos y aquí se distinguen:
  * el enlace FALLA (AllDebrid "link not available"...): Palantir saca un aviso (okdialog / notificación).
    Mientras se resuelve un enlace, Window(home).Property(flix_resolving)=true oculta esos avisos y este script los
    cierra; al reabrirse el selector se prueba el SIGUIENTE enlace (primero los aptos del modo, luego el resto,
    remux al final) sin enseñar nada.
  * la reproducción llegó a arrancar y se paró: se cierra el selector (no se vuelven a enseñar las fuentes).
  * el usuario pulsó Atrás mientras cargaba (reabre sin aviso de error): también se cierra el selector.
Estado en Window(home).Property(flix_autoplay_state) = "titulo|estado|idx,idx|hora" con estado trying / failed /
played. Fallaron todos y el usuario vuelve a darle (flix_playload.begin después del fallo): se prueban de nuevo.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import threading
import time
import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402
from flix_common import A_BACK, COLOR_RE, TMDB_KEY, clean, decode_route  # noqa: E402,F401
import flix_quality  # noqa: E402
import flix_playload  # noqa: E402

HOME = xbmcgui.Window(10000)
ERROR_WINDOWS = ("okdialog", "notification")
OWN_NOTICE = "flix_own_notice"     # Window(home): hora del último aviso propio (notify): close_errors no lo cierra
OWN_NOTICE_SECS = 6
HANDOFF = [False]       # el selector se reabrió y otra instancia sigue: esta no toca flix_resolving
UPNEXT_SECS = 75        # el aviso "Siguiente capítulo" sale a 75 s del final (créditos) (solo capítulos de más de 3 min)
UPNEXT_CHOICES = (30, 45, 60, 75, 90, 120)
# el salto por los créditos espera si el vídeo está en pausa o se ve el OSD o un diálogo sobre el vídeo (ajustes,
# selección, menú contextual, sí/no, subtítulos, marcadores): se saltaría por encima de lo que el usuario está tocando.
# Ventanas concretas y NO System.HasActiveModalDialog: el aviso propio (UpNext) es un diálogo abierto con show() y, si
# Kodi lo contara como modal, el salto no llegaría nunca
JUMP_WAIT = ("Player.Paused | Window.IsVisible(videoosd) | Window.IsVisible(osdsubtitlesettings) | "
             "Window.IsVisible(osdvideosettings) | Window.IsVisible(osdaudiosettings) | Window.IsVisible(selectdialog) | "
             "Window.IsVisible(contextmenu) | Window.IsVisible(yesnodialog) | Window.IsVisible(subtitlesearch) | "
             "Window.IsVisible(videobookmarks)")
SEEK_FWD = 5            # s: un avance mayor entre dos vueltas del bucle (0,5 s) es un salto del usuario, no el vídeo andando
PICK_ONCE_SECS = 90     # «Elegir resolución» en la ficha (flix_play): vale para el selector que se abra en ese rato


def pick_once(now=None):
    """¿se pidió «Elegir resolución» hace poco? Se gasta al mirarla: solo esa reproducción va por el selector"""
    stamp = HOME.getProperty("flix_pick_once")
    if not stamp:
        return False
    HOME.clearProperty("flix_pick_once")
    try:
        return 0 <= (time.time() if now is None else now) - float(stamp) < PICK_ONCE_SECS
    except ValueError:
        return False  # Ajustes → «Aviso de siguiente capítulo» (Skin.String(flix_upnext_secs))


def upnext_secs():
    """segundos antes del final a los que sale el aviso: el elegido en Ajustes (Carlos, 22-oct) o UPNEXT_SECS"""
    try:
        s = int(xbmc.getInfoLabel("Skin.String(flix_upnext_secs)") or UPNEXT_SECS)
    except ValueError:
        return UPNEXT_SECS
    return s if s in UPNEXT_CHOICES else UPNEXT_SECS
PIN_SECS = 60           # tras cerrar el aviso de vincular AllDebrid (Atrás/caducado) no se prueba otro enlace
AFTER_STOP_SECS = 25    # Palantir abre el selector del siguiente capítulo ~8 s después de acabar/parar
NEXT_MAX = 90           # s como mucho esperando el siguiente capítulo mientras Palantir siga cargándolo
REOPEN_FAST = 8         # s tras parar: el selector que se abre es Palantir reabriendo el mismo título
REOPEN_MAX = 25         # s: más tarde aún, si nadie tocó el mando (Shield: llega a ~8-9 s)
REOPEN = "flix_select_reopen"   # Window(home): el 1.er selector sin marca se cierra en cuanto abre (DialogSelect.xml), sin esperar
#                                 a este script: oculto, una pulsación elegía un enlace y arrancaba lo parado (móvil, 4-nov)
REOPEN_SECS = 4     # s armado: Palantir reabre a 0,5-3,2 s (medido, 4-nov). Más tarde lo cierra el script, con la lista sin responder.
#                     Corto: en onload aún no se sabe si el selector es de Palantir, y cerraría cualquier otro (prueba, 4-nov)
SERVED = "flix_press_served"    # Window(home): «hora|título» de la última pulsación atendida
QUIET = "flix_select_quiet"     # Window(home): el selector que se abra ahora es Palantir reabriéndolo: sin rueda
EPISODE_RE = re.compile(r"(\d+)x(\d+)")
FOLLOW_STALE = 15       # s: la marca flix_following se renueva cada ~5 s mientras alguien sigue la reproducción
CANCEL_IDLE = 2         # s: un «error» justo tras tocar el mando es Atrás del usuario (Palantir: «Acción cancelada»)


def user_cancel(idle):
    """¿el aviso que acaba de salir mientras se resolvía lo provocó el usuario (Atrás)? Palantir cancela, saca
    «Acción cancelada» y reabre el selector; se tomaba por un enlace fallido y se probaba SOLO el siguiente, desde el
    principio y tapado por la pantalla de carga (Carlos, 25-oct, Del revés: el reintento borró su progreso)"""
    return idle <= CANCEL_IDLE


TEXT_TRIES = 8          # intentos de leer el texto del diálogo, cada 50 ms
FAILED_WAIT = 100       # vueltas de 0,1 s tras un diálogo de error, por si Palantir reabre el selector
CANCEL_TEXTS = ("acción cancelada", "accion cancelada", "action cancelled", "action canceled")


def classify_error(text, idle):
    """¿Atrás o enlace fallido? Un diálogo de error de Palantir dice cuál es; un fallo justo tras pulsar «Ver» no es
    Atrás (Carlos, 3-nov). Las notificaciones pueden ser de cualquiera: esas, por la última tecla, como antes"""
    low = (text or "").strip().lower()
    if low:
        return "cancelled" if any(c in low for c in CANCEL_TEXTS) else "failed"
    return "cancelled" if user_cancel(idle) else "failed"


def safe_error_text(text):
    """para el log: sin enlaces ni códigos largos, y nada si puede llevar un PIN"""
    if not text or re.search(r"\bpin\b", text, re.I):
        return ""
    return re.sub(r"\b[A-Za-z0-9_-]{16,}\b", "<…>", re.sub(r"https?://\S+", "<url>", text))[:80]


def silent_failure(status, selector_open, playing):
    """enlace fallido y nadie lo cuenta: ni se reproduce nada ni se reabrió el selector (decide() ya avisa en ese caso)"""
    return status == "failed" and not selector_open and not playing


def seek_on_retry(tried, offset):
    """¿saltar a la posición al arrancar? Solo en un reintento (la 1.ª lleva el StartOffset en el play) y si hay
    algo que saltar: el reintento pasa por el selector de Palantir y empezaba desde 0:00 (Carlos, 25-oct)"""
    return len(tried) > 1 and offset >= 30


def seek_resume(player, tried):
    offset = flix_playload.resume_offset(HOME.getProperty("flix_play_offset"))
    if not seek_on_retry(tried, offset):
        return
    for _ in range(50):                 # hasta que el reproductor sepa la duración (~1-3 s)
        try:
            if player.getTotalTime() > 0:
                break
        except RuntimeError:
            pass
        nap(100)
    try:
        if player.getTime() < offset - 5:
            player.seekTime(offset)
            log("reintento: salto a %d s" % offset)
    except RuntimeError as e:
        log("reintento: no salto (%s)" % e)


def cancel_reopen(stamp, now):
    """¿el selector que se abre viene de esa cancelación (Palantir lo reabre en < 1 s)? Más tarde es una apertura nueva"""
    try:
        return 0 <= now - float(stamp) <= REOPEN_FAST
    except (TypeError, ValueError):
        return False


_MON = []


def nap(ms):
    """espera ms; si Kodi se está cerrando termina el script (xbmc.sleep seguía esperando: auditoría PY-14). El
    cierre llega por System.OnQuit (flix_common.quit_monitor: a los RunScript sin addon no les llega abortRequested;
    con vídeo o selector los bucles seguían 12-25 s y Kodi los mataba, revisión 7-nov PY-03)"""
    if not _MON:
        _MON.append(flix_common.quit_monitor())
    if flix_common.wait_quit(_MON[0], ms / 1000.0):      # en trozos: una espera larga acaba al anunciarse el cierre
        raise SystemExit


def follower_active(mark, now):
    """¿hay ya un script siguiendo la reproducción? (marca = hora de la última renovación)"""
    try:
        return now - float(mark) < FOLLOW_STALE
    except (TypeError, ValueError):
        return False


def player_header(show, season, episode, title):
    """cabecera estilo selector ('Serie: 1x03 Título') a partir del reproductor, para el modo follow"""
    if show and season and episode:
        return "%s: %sx%02d %s" % (show, season, int(episode), title) if episode.isdigit() else "%s: %sx%s %s" % (show, season, episode, title)
    return title


def next_after(seasons, s, e, today):
    """capítulo que sigue a sXe con lo ya emitido. seasons: {temporada: [(capítulo, 'AAAA-MM-DD' o ''), ...]} (sin
    especiales). (temporada, capítulo) o None si sXe es el último emitido"""
    aired = lambda d: bool(d) and d <= today        # noqa: E731
    for ep, d in sorted(seasons.get(s, [])):
        if ep > e and aired(d):
            return s, ep
    for sn in sorted(k for k in seasons if k > s):
        eps = sorted((ep, d) for ep, d in seasons[sn] if aired(d))
        if eps:
            return sn, eps[0][0]
    return None


def tmdb_get(path):
    import json
    import urllib.parse
    import urllib.request
    url = "https://api.themoviedb.org/3/%s?%s" % (path, urllib.parse.urlencode({"api_key": TMDB_KEY}))
    with urllib.request.urlopen(url, timeout=6) as r:
        return json.load(r)


def next_label(tmdb, s, e):
    """«T1 · E9» / «T2 · E1» si hay siguiente ya emitido; '' si era el último; None si no se sabe (sin red)"""
    try:
        show = tmdb_get("tv/%s" % tmdb)
        seasons = {}
        for sn in show.get("seasons") or []:
            n = sn.get("season_number") or 0
            if n < s:
                continue
            if n == s:
                seasons[n] = [(x.get("episode_number") or 0, x.get("air_date") or "")
                              for x in tmdb_get("tv/%s/season/%d" % (tmdb, n)).get("episodes") or []]
            else:                       # siguientes temporadas: basta con que su 1.er capítulo esté emitido
                seasons[n] = [(1, sn.get("air_date") or "")] if (sn.get("episode_count") or 0) > 0 else []
        nxt = next_after(seasons, s, e, time.strftime("%Y-%m-%d"))
    except Exception as e2:  # noqa: BLE001
        log("siguiente capítulo en TMDB: %s" % e2)
        return None
    return "T%d · E%d" % nxt if nxt else ""


def playing_show_tmdb():
    """tmdb de la serie abierta con flix_series.py (la ruta de «Continuar» lleva el JSON de Palantir)"""
    m = re.search(r'"tmdb": \'?(\d+)', decode_route(HOME.getProperty("flix_series_play"))) \
        if HOME.getProperty("flix_series_play") else None
    return m.group(1) if m else None


def upnext_due(rem, cur, total, secs, credits):
    """¿toca abrir el aviso de «Siguiente capítulo»? A secs del final (como siempre) o, si hay datos de créditos
    (segundo en que empiezan, o None), en cuanto empiezan. Solo capítulos de más de 3 min; secs 0 o nulo = apagado"""
    if not (total > 180 and secs and secs > 0):
        return False
    if 0 < rem <= secs:
        return True
    return credits is not None and cur >= credits and rem > 0


def upnext_remaining(rem, opened_at, now, secs, early):
    """segundos que enseña la cuenta atrás. Normal: lo que falta para el final. early (el aviso salió con los créditos
    a más de secs del final): los secs de Ajustes contados desde que salió (opened_at y now, en segundos de vídeo)"""
    if not early:
        return rem
    return max(0.0, min(float(secs), secs - (now - opened_at)))


class UpNext(xbmcgui.WindowXMLDialog):
    """Aviso propio "Siguiente capítulo" (Custom_1111_Overlay.xml, mismos ids que el de Palantir).
    Siguiente = saltar al final (Palantir abre el siguiente al acabar). Cancelar / Atrás = al acabar o parar,
    quedarse en el menú. Si no se toca, al acabar el capítulo sigue el siguiente.
    A lo Netflix (Carlos, 8-nov; tools/gen_upnext.py): sin tarjeta, [ Cancelar ] [ Siguiente capítulo · T2 · E5 ]
    abajo a la derecha como «Saltar intro», y la cuenta atrás es un relleno dentro de Siguiente (un_pct). Si salía
    antes de los créditos, la tarjeta grande tapaba la imagen hasta el final"""

    def onInit(self):
        title = xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or HOME.getProperty("flix_series_title") or xbmc.getInfoLabel("Player.Title")
        m = EPISODE_RE.search(xbmc.getInfoLabel("Player.Title"))
        self.getControl(200001).setLabel(title)
        nxt = getattr(self, "next_label", None)     # de TMDB (follow_playback); si no se sabe, el siguiente número
        nxt = nxt or ("T%d · E%d" % (int(m.group(1)), int(m.group(2)) + 1) if m else "")
        self.getControl(200003).setLabel(nxt)
        art = xbmc.getInfoLabel("Player.Art(fanart)") or HOME.getProperty("flix_fanart") or xbmc.getInfoLabel("Player.Art(thumb)")
        # imagen y barra por propiedades (Custom_1111_Overlay.xml): setImage / setPercent usan el control y, tras
        # recargar la skin con el aviso abierto, apuntaban al borrado y cerraban Kodi (auditoría 22-oct A-02).
        # setLabel / setText van por mensaje: seguros
        self.setProperty("un_art", art)
        self.setProperty("un_next", nxt)
        self.tick(self.secs())

    def tick(self, remaining):
        self.setProperty("un_pct", "%d" % max(0, min(100, round(100.0 * remaining / self.secs()))))
        try:
            self.getControl(200002).setText("Empieza en %d s" % max(0, int(remaining)))
        except RuntimeError:
            pass

    def secs(self):
        return getattr(self, "upnext_secs", UPNEXT_SECS)

    def go_next(self):
        """lo que hace el botón «Siguiente» (y la cuenta atrás de los créditos al llegar a 0)"""
        HOME.setProperty("flix_upnext_choice", "next")
        self.close()
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_next.py)")

    def onClick(self, cid):
        if cid == 200006:
            self.go_next()
        elif cid == 200005:
            HOME.setProperty("flix_upnext_choice", "stay")
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:            # = «Cancelar»
            HOME.setProperty("flix_upnext_choice", "stay")
            self.close()


def series_of(header):
    """'Palantir · South Park: 28x02 La mujer…' -> 'palantir · south park' ('' si no es un capítulo)"""
    m = EPISODE_RE.search(header or "")
    return header[:m.start()].rstrip(" :-·").strip().lower() if m else ""


def is_episode():
    return bool(xbmc.getInfoLabel("VideoPlayer.Episode")) or EPISODE_RE.search(xbmc.getInfoLabel("Player.Title")) is not None


def make_skip_watcher(player):
    """Watcher de «Saltar intro» si Kodi da el tmdb, la temporada y el capítulo (números); nunca falla hacia fuera"""
    try:
        ids = [xbmc.getInfoLabel(k) for k in ("VideoPlayer.UniqueID(tmdb)", "VideoPlayer.Season", "VideoPlayer.Episode")]
        if not all(i.isdigit() for i in ids):
            return None
        import flix_intro
        return flix_intro.Watcher(player, *[int(i) for i in ids])
    except Exception as e:  # noqa: BLE001
        log("saltar intro: %s" % e)
        return None


def credits_of(watcher, total):
    """segundo en que empiezan los créditos según el Watcher de «Saltar intro» (None: sin datos, sin watcher o fallo)"""
    try:
        return watcher.credits_at(total) if watcher is not None else None
    except Exception:  # noqa: BLE001
        return None


def follow_playback(header):
    """Durante la reproducción: aviso "Siguiente capítulo" a upnext_secs() del final (o al empezar los créditos, si
    hay datos y faltan más de esos segundos: la cuenta atrás dura los de Ajustes y luego pasa al siguiente) y, al parar,
    decide si el selector del siguiente capítulo que abrirá Palantir se deja (go) o se cierra (stay)."""
    player, mon = xbmc.Player(), flix_common.quit_monitor()      # se para al cerrarse Kodi (System.OnQuit, PY-03)
    flix_playload.clear_press()     # ya hay vídeo: una pulsación sin usar no da por buena una apertura de Palantir al parar
    HOME.clearProperty("flix_upnext_choice")
    episode, popup, last_rem = is_episode(), None, 9999.0
    # el fanart se lee ahora, con el vídeo sonando: al parar ya no hay Player.Art
    fanart = xbmc.getInfoLabel("Player.Art(fanart)") or HOME.getProperty("flix_fanart")
    secs = upnext_secs()
    renewed = 0.0
    # qué capítulo sigue (TMDB, en segundo plano): si era el último, sin aviso de «Siguiente capítulo» (anunciaba un
    # E9 que no existe; Carlos, 20-oct). Sin red: como antes (el número siguiente)
    upnext = {"label": None}
    m = EPISODE_RE.search(xbmc.getInfoLabel("Player.Title"))
    title = (HOME.getProperty("flix_series_title") or "").strip().lower()
    same = bool(title) and (title in (header or "").lower()
                            or title == (xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or "").strip().lower())
    tmdb = playing_show_tmdb() if episode and m and same else None     # solo si es la serie abierta
    if tmdb:
        def look():
            upnext["label"] = next_label(tmdb, int(m.group(1)), int(m.group(2)))
            log("después de %sx%s: %r" % (m.group(1), m.group(2), upnext["label"]))
        threading.Thread(target=look, daemon=True).start()
    # «Saltar intro»: el hilo busca los tiempos; si al arrancar Kodi aún no da los ids se reintenta unos segundos
    watcher, watch_tries = None, 0
    early, opened_cur, jumped = False, 0.0, False      # aviso abierto por los créditos con más de secs por delante
    prev_cur = None                                     # el tiempo de la vuelta anterior (para ver los saltos adelante)
    while player.isPlaying() and not flix_common.quitting(mon):
        if episode and watcher is None and watch_tries < 20:
            watch_tries += 1
            watcher = make_skip_watcher(player)
        if time.time() - renewed > 5:
            renewed = time.time()
            HOME.setProperty("flix_following", str(renewed))
        try:
            total, cur = player.getTotalTime(), player.getTime()
            last_rem = total - cur
        except RuntimeError:
            break
        seeked = prev_cur is not None and cur - prev_cur > SEEK_FWD
        prev_cur = cur
        credits = credits_of(watcher, total) if episode else None
        # por los créditos (faltan más de secs) hay que SABER que hay siguiente: con la respuesta de TMDB «hay». Sin ella
        # (sin red, o sin tmdb de la serie) no se adelanta: un último capítulo saltaría 10 min antes del final
        if episode and popup is None and upnext_due(last_rem, cur, total, secs, credits) \
                and not HOME.getProperty("flix_upnext_choice") and upnext["label"] != "" \
                and (last_rem <= secs or upnext["label"]):
            early, opened_cur, jumped = last_rem > secs, cur, False
            popup = UpNext("Custom_1111_Overlay.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
            popup.next_label = upnext["label"]
            popup.upnext_secs = secs
            # aviso propio: ya se apunta aquí abajo; Custom_1111_Overlay.xml solo lanza flix_log.py (un intérprete
            # más) cuando la ventana la abre Palantir (revisión 29-oct ARR-12)
            HOME.setProperty("flix_upnext_own", "1")
            popup.show()
            log("aviso siguiente capítulo (%s, faltan %.0f s%s; créditos %s, dura %.0f s)" % (
                header, last_rem, ", por los créditos" if early else "",
                "a %.0f s del final" % (total - credits) if credits is not None else "sin dato válido", total))
        elif popup is not None:
            try:
                if early and credits is not None and cur < credits:     # retrocedió a antes de los créditos: se quita
                    popup.close()                                       # (sin salto; vuelve a salir al llegar a ellos)
                    popup, early = None, False
                else:
                    if early and seeked and not jumped:     # salto adelante (no el del propio «Siguiente»):
                        opened_cur = cur                    # la cuenta atrás vuelve a empezar
                    left = upnext_remaining(last_rem, opened_cur, cur, secs, early)
                    popup.tick(left)
                    # a 0: lo que haría «Siguiente», una vez y solo si nadie ha elegido (Cancelar deja seguir hasta el final);
                    # con el OSD o un diálogo abierto espera (jumped sigue False: salta en cuanto se cierren)
                    if early and left <= 0 and not jumped and not HOME.getProperty("flix_upnext_choice") \
                            and not xbmc.getCondVisibility(JUMP_WAIT):
                        jumped = True
                        popup.go_next()
            except Exception as e:  # noqa: BLE001
                log("aviso con créditos: %s" % e)
                jumped = True
        if watcher is not None:         # sin red ni diálogos bloqueantes; con el aviso del siguiente, el botón no sale
            watcher.tick(cur, total, hold=popup is not None)
        if mon.waitForAbort(0.1 if last_rem < 6 else 0.5) or flix_common.quitting():    # al final, más fino
            break
    HOME.clearProperty("flix_following")
    if watcher is not None:
        try:
            watcher.close()
        except Exception:  # noqa: BLE001
            pass
    if popup is not None:
        try:
            popup.close()
        except RuntimeError:
            pass
    HOME.clearProperty("flix_upnext_own")
    # Palantir reabre el selector justo al parar: solo esa reapertura inmediata se cierra (ver decide)
    HOME.clearProperty(SERVED)
    HOME.setProperty("flix_autoplay_stop", "%.1f" % time.time())
    # y esa reapertura, sin la rueda del selector oculto (DialogSelect.xml): asomaba ~0,5 s al salir de cada vídeo
    # hasta que decide lo cerraba (Shield, Carlos 1-nov). Solo REOPEN_FAST s; una apertura nueva la quita (decide)
    HOME.setProperty(QUIET, "1")
    xbmc.executebuiltin("AlarmClock(flixselquiet,ClearProperty(%s,home),00:%02d,silent)" % (QUIET, REOPEN_FAST))
    choice = HOME.getProperty("flix_upnext_choice")
    natural = last_rem < 6                          # acabó solo (o "Siguiente" saltó al final)
    go = episode and (choice == "next" or (natural and choice != "stay"))
    if not go and (episode or read_state(header)[0] == "played"):    # de Palantir: no tras YouTube ni la biblioteca
        HOME.setProperty(REOPEN, "1")
        xbmc.executebuiltin("AlarmClock(flixselreopen,ClearProperty(%s,home),00:%02d,silent)" % (REOPEN, REOPEN_SECS))
    if episode:     # solo los capítulos: Palantir abre el siguiente de la MISMA serie
        HOME.setProperty("flix_after_stop", "%d|%s|%s" % (time.time(), "go" if go else "stay", header))
    else:
        HOME.clearProperty("flix_after_stop")
    log("fin de %r: faltaban %.0f s, elección %r -> %s" % (header, last_rem, choice, "siguiente capítulo" if go else "quedarse en el menú"))
    stamp = None
    # la capa de carga (fanart + rueda) ya, sin dejar a la vista la ficha hasta que empiece el siguiente; si era el
    # último capítulo (label "") no hay nada que cargar y la capa solo taparía el aviso de «No hay más capítulos»
    if go and upnext["label"] != "":
        stamp = flix_playload.begin(fanart, pressed=False, idle_max=flix_playload.NEXT_IDLE,
                                    grace=flix_playload.NEXT_GRACE)
    handle_countdown(go, header, stamp)


def link_in_progress():
    """¿un enlace resolviéndose? Lo lleva otra instancia, que quita flix_resolving; no hay que tocarlo"""
    return "|trying|" in HOME.getProperty("flix_autoplay_state")


def is_countdown():
    """¿el progressdialog activo es la cuenta atrás de Palantir («Starting Serie (2x3) in 5 seconds»)? Lo demás es una carga"""
    return bool(re.search(r"\b(?:in|en)\s+\d+\s*(?:seconds?|secs?|segundos?|segs?)\b", clean(xbmc.getInfoLabel("Control.GetLabel(9)")).lower()))


def handle_countdown(go, header="", stamp=None):
    """Al acabar un capítulo Palantir enseña su cuenta atrás ("Starting Serie (2x3) in 5 seconds", progressdialog).
    Nunca se pinta (flix_resolving oculta el progreso en DialogConfirm). Si hay que seguir, se deja correr; si no,
    se cancela (Atrás sobre el diálogo) y no llega a abrirse el siguiente.
    Si había que seguir y Palantir no abre el selector del siguiente (no hay más capítulos: solo saca un aviso, que
    aquí se oculta), sale el aviso propio "No hay más capítulos" en vez de quedarse cargando.
    stamp = la marca de la capa que empezó follow_playback (None si no empezó ninguna): solo esa se quita. Sin siguiente
    (go False) no se empieza ninguna capa y aquí no se toca: podría ser la de otra pulsación (parar y pulsar otro título)."""
    HOME.setProperty("flix_resolving", "true")
    mon = flix_common.quit_monitor()        # se para al cerrarse Kodi (System.OnQuit, PY-03)
    t0, seen_progress, progress_end, nomore = time.time(), False, 0.0, False
    saw_selector = False
    try:
        while time.time() - t0 < 25 or (go and time.time() - t0 < NEXT_MAX and xbmc.getCondVisibility(
                "Window.IsActive(progressdialog) | Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)")):
            # Palantir aún cargando el siguiente (Fire TV: 23 s hasta abrirlo; a los 25 s salía «No hay más
            # capítulos» y justo después empezaba el capítulo, Carlos 24-oct): se espera mientras siga cargando
            if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                if go:
                    HANDOFF[0] = True
                    return                              # el selector del siguiente ya está: su instancia manda
                # sin pedir el siguiente: puede ser el que cierra el XML o el del usuario. Se sigue vigilando: nadie más
                # cancela la cuenta atrás, y arrancaría el siguiente
                saw_selector = True
            if go and (xbmc.Player().isPlayingVideo() or (time.time() - t0 > 2 and xbmc.getCondVisibility("Player.HasMedia"))):
                return                                  # sin selector: Palantir ya abre (o reproduce) el siguiente
            if not go and saw_selector and xbmc.getCondVisibility("Player.HasMedia"):
                return
            prog = xbmc.getCondVisibility("Window.IsActive(progressdialog)")
            # con una pulsación de por medio, un progressdialog puede ser SU carga: solo se cancela la cuenta atrás
            if not go and prog and (is_countdown() or not (flix_playload.peek_press() or HOME.getProperty(SERVED) or link_in_progress())):
                log("cuenta atrás: %r" % safe_error_text(clean(xbmc.getInfoLabel("Control.GetLabel(9)"))))
                # «Cancelar» (10) de la cuenta atrás de Palantir, a esa ventana: con Action(Back), si la rueda de Kodi
                # estaba encima (recarga de la carpeta tras el vídeo) se cancelaba ELLA, la carpeta fallaba y Kodi
                # saltaba a la raíz de Vídeos; esperar a que se fuera dejaba acabar la cuenta y empezaba el siguiente
                # capítulo solo (banco, 25-oct)
                xbmc.executebuiltin("SendClick(progressdialog,10)")
                log("cuenta atrás de Palantir cancelada (me quedo en el menú)")
                mon.waitForAbort(0.8)
                return
            if go:
                if prog:
                    seen_progress, progress_end = True, 0.0
                elif seen_progress and not progress_end:
                    progress_end = time.time()
                if close_errors():
                    nomore = True                       # aviso de Palantir (sin más capítulos / sin enlaces)
                    break
                if progress_end and time.time() - progress_end > 8:
                    nomore = True                       # acabó su cuenta atrás y no abrió nada
                    break
                if not seen_progress and time.time() - t0 > 12:
                    nomore = True                       # ni siquiera empezó cuenta atrás
                    break
            elif time.time() - t0 > 12:
                return
            if mon.waitForAbort(0.2) or flix_common.quitting():
                return
        nomore = nomore or go
    finally:
        if not HANDOFF[0] and not link_in_progress() and not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
            HOME.clearProperty("flix_resolving")
    if go and nomore and not HANDOFF[0]:
        # PROP con otra marca (no vacía): el usuario pulsó otro título; su capa sigue y el aviso no va encima
        other = flix_playload.HOME.getProperty(flix_playload.PROP)
        if stamp and other and other != stamp:
            log("%s: otro título pulsado -> sin aviso" % header)
            return
        log("%s: no llega el siguiente capítulo -> aviso" % header)
        if stamp:
            flix_playload.end(stamp)                    # la capa taparía el aviso (solo la nuestra)
        show_message(HOME.getProperty("flix_series_title") or series_of(header).title(),
                     "No hay más capítulos disponibles por ahora", HOME.getProperty("flix_fanart"))


class MessageDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        threading.Timer(8, self.close).start()          # se cierra solo

    def onAction(self, action):
        if action.getId() in A_BACK:                    # Atrás como en las demás ventanas (TV-28)
            self.close()


def show_message(title, text, fanart=""):
    w = MessageDialog("FlixMessage.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                      props={"fm_title": title or "", "fm_text": text, "fm_fanart": fanart or ""})
    w.doModal()
    del w


def log(msg):
    xbmc.log("[flix_autoplay] %s" % msg, xbmc.LOGINFO)



def quality(label):
    m = re.search(r"\((.+?)\)\s*\[", label)
    return (m.group(1) if m else "").strip()


def read_state(header):
    state = HOME.getProperty("flix_autoplay_state")
    if not state.startswith(header + "|"):
        return None, []
    parts = state[len(header) + 1:].split("|")
    status = parts[0]
    tried = [int(x) for x in (parts[1] if len(parts) > 1 else "").split(",") if x.isdigit()]
    return status, tried


def write_state(header, status, tried):
    HOME.setProperty("flix_autoplay_state", "%s|%s|%s|%s" % (header, status, ",".join(str(i) for i in tried),
                                                             time.time()))


def state_time(header):
    """hora (texto) en que se escribió el estado de header; '' si es de otro título"""
    state = HOME.getProperty("flix_autoplay_state")
    if not state.startswith(header + "|"):
        return ""
    parts = state[len(header) + 1:].split("|")
    return parts[2] if len(parts) > 2 else ""


def pressed_again(pressed, failed_at):
    """la última pulsación (flix_playload.begin) es posterior al último fallo: el usuario vuelve a darle; si no, es
    Palantir reabriendo el selector tras un enlace muerto dentro de la misma pulsación"""
    try:
        return float(pressed) > float(failed_at)
    except ValueError:
        return False


def close_selector():
    """Cierra el selector sin que se llegue a ver (sigue oculto: no hay flix_select_show)."""
    xbmc.executebuiltin("Dialog.Close(selectdialog,true)")


def close_selector_done():
    """cierra el selector cuando ya no hay nada que resolver y quita flix_resolving DESPUÉS de que se cierre: su
    onunload (DialogSelect.xml) la vuelve a poner y se quedaba puesta 120 s sin nada en marcha. Mientras, la rueda
    «Cargando capítulos» de la ficha de serie no salía (capítulo parado a los pocos segundos, Fire TV 24-oct)"""
    close_selector()
    for _ in range(30):
        if not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
            break
        nap(50)
    nap(100)
    HOME.clearProperty("flix_resolving")


def notify(title, msg, ms):
    """aviso propio. close_errors (de esta instancia o de la del enlace anterior, que sigue 1 s ocultando los avisos de
    Palantir) lo cerraba: «Ningún enlace disponible» duraba 0,3 s y no llegaba a verse (banco, 25-oct)"""
    HOME.setProperty(OWN_NOTICE, str(time.time()))
    xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, ms)


def own_notice(stamp, now):
    try:
        return now - float(stamp) < OWN_NOTICE_SECS
    except ValueError:
        return False


LAST_ERROR = ""         # texto del último aviso cerrado por close_errors (classify_error decide con él)


def error_text():
    """texto de un diálogo de error modal (okdialog, etiqueta 9); las notificaciones no se leen: "" """
    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        for _ in range(TEXT_TRIES):  # recién abierto aún no tiene texto (Mac: se cerraba a los 10 ms y parecía Atrás)
            text = clean(xbmc.getInfoLabel("Control.GetLabel(9)"))
            if text:
                return text
            nap(50)
    return ""


def close_errors():
    global LAST_ERROR
    LAST_ERROR = ""
    seen = False
    for w in ERROR_WINDOWS:
        if w == "notification" and own_notice(HOME.getProperty(OWN_NOTICE), time.time()):
            continue
        if xbmc.getCondVisibility("Window.IsActive(%s)" % w):
            if not seen:
                LAST_ERROR = error_text()       # se lee antes de cerrar
                shown = safe_error_text(LAST_ERROR)
                if shown and HOME.getProperty("flix_debrid_pin") != "true":
                    log("aviso cerrado: %r" % shown)
            xbmc.executebuiltin("Dialog.Close(%s,true)" % w)
            seen = True
    return seen


def watch(header, tried):
    """Tras elegir un enlace: espera a que reproduzca, falle (aviso de error) o se reabra el selector."""
    HOME.setProperty("flix_resolving", "true")
    failed = False
    reason = ""
    left = None  # vueltas que quedan tras un diálogo de error: si Palantir no reabre, no se espera 90 s
    try:
        player = xbmc.Player()
        for _ in range(30):  # el selector tarda en cerrarse (animación): no confundirlo con una reapertura
            if not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                break
            nap(50)
        for _ in range(900):  # hasta 90 s resolviendo el enlace
            while HOME.getProperty("flix_debrid_pin") == "true":  # vinculando AllDebrid (hasta 10 min): no cuenta
                nap(200)
            if close_errors():
                if (LAST_ERROR or not failed) and classify_error(LAST_ERROR, xbmc.getGlobalIdleTime()) == "cancelled":
                    failed = False  # lo que hubiera fallado antes ya no importa: sin aviso de fallo
                    write_state(header, "cancelled", tried)
                    HOME.setProperty("flix_autoplay_cancel", str(time.time()))
                    log("enlace %d: Atrás del usuario -> cancelado, sin reintentos" % tried[-1])
                    flix_playload.cancel()
                    return
                write_state(header, "failed", tried)
                failed = True
                if LAST_ERROR and left is None:
                    left = FAILED_WAIT
                    reason = safe_error_text(LAST_ERROR)  # close_errors() lo borra en la siguiente pasada
                    HOME.setProperty("flix_fail_reason", reason)   # para el aviso de decide(), en otra instancia
                log("enlace %d falló (aviso ocultado)" % tried[-1])
            if player.isPlayingVideo():
                write_state(header, "played", tried)
                log("reproduciendo enlace %d" % tried[-1])
                HOME.clearProperty("flix_resolving")
                seek_resume(player, tried)
                failed = False  # un aviso suelto previo no vale: el enlace funcionó
                follow_playback(header)
                return
            if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                close_errors()
                HANDOFF[0] = True
                return  # reapertura: la nueva instancia del script decide
            if left is not None:
                left -= 1
                if left <= 0:
                    break
            nap(100)
        else:
            HOME.clearProperty("flix_autoplay_state")  # nada en 90 s: estado caducado
    finally:
        # los avisos que Kodi/Palantir saquen justo después del fallo también se ocultan un momento
        reopened = False
        n = 0
        while n < (20 if failed else 10):  # con fallo, 2 s por si el selector tarda en reabrirse
            if close_errors():
                status, t = read_state(header)
                if status == "trying":
                    write_state(header, "failed", t)
                    failed = True
            if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                reopened = True  # una reapertura en cualquier momento de la ventana cuenta
            nap(100)
            n += 1
        selector_open = HANDOFF[0] or reopened or xbmc.getCondVisibility("Window.IsActive(selectdialog)")
        if not selector_open:
            HOME.clearProperty("flix_resolving")     # con relevo / selector abierto, la propiedad es de la otra instancia
            if left is not None and left <= 0:       # corte tras el diálogo: sin reapertura, estado caducado; si reabre
                HOME.clearProperty("flix_autoplay_state")   # se conserva, o decide() repetiría el enlace que ha fallado
                HOME.clearProperty("flix_following")        # si el enlace arranca aún, lo sigue follow()
        if pin_cancelled(HOME.getProperty("flix_pin_closed"), time.time()):
            failed = False  # el usuario cerró el aviso del PIN: decide() ya lo gestiona (no se borra aquí)
        if silent_failure("failed" if failed else "", selector_open, xbmc.Player().isPlayingVideo()):
            notify("No se ha podido reproducir", reason or "El enlace ha fallado", 8000)


def play(header, items, idx, tried):
    tried.append(idx)
    if len(tried) == 1:
        HOME.clearProperty("flix_fail_reason")     # intento nuevo: fuera el motivo de la vez anterior
    write_state(header, "trying", tried)
    HOME.setProperty("flix_resolving", "true")      # antes de elegir: el progreso de AllDebrid no llega a verse
    HOME.setProperty("flix_following", str(time.time()))   # este script seguirá la reproducción
    log("%s -> %d %r (intento %d)" % (header, idx, items[idx], len(tried)))
    HOME.setProperty("flix_select_armed", "1")      # la lista oculta no responde: ni un dedo ni una tecla eligen por error
    for _ in range(10):
        if xbmc.getCondVisibility("Control.IsEnabled(3)"):
            break
        nap(30)
    xbmc.executebuiltin("SetFocus(3,%d,absolute)" % idx)
    nap(120)
    xbmc.executebuiltin("Action(Select)")
    watch(header, tried)


def show_selector():
    HOME.setProperty("flix_select_show", "true")
    for _ in range(10):                             # oculta no se podía enfocar (<enable>); a 15 fps tarda
        if xbmc.getCondVisibility("Control.IsEnabled(3)"):
            break
        nap(30)
    if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):     # si ya se cerró, iría a la ventana de debajo
        xbmc.executebuiltin("SetFocus(3)")


def manual(header, items):
    """Autoplay apagado: se enseña el selector y se vigila qué enlace elige el usuario para reintentar si falla."""
    HOME.clearProperty("flix_fail_reason")     # intento nuevo: fuera el motivo de la vez anterior
    show_selector()
    last = 0
    while xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
        cur = xbmc.getInfoLabel("Container(3).CurrentItem")
        if cur.isdigit() and int(cur) > 0:
            last = int(cur) - 1
        nap(80)
    # Atrás en el selector = Palantir no carga nada: si en 3 s no hay carga ni reproducción, no se vigila
    for _ in range(30):
        if xbmc.getCondVisibility("Window.IsActive(progressdialog) | Window.IsActive(busydialog) | "
                                  "Window.IsActive(busydialognocancel) | Player.HasMedia | Window.IsActive(okdialog)"):
            break
        nap(100)
    else:
        return
    tried = [last]
    write_state(header, "trying", tried)
    log("%s: elegido a mano %d %r" % (header, last, items[last]))
    watch(header, tried)


def press_matches(mark, header):
    """¿este selector es el de lo pulsado? Si la marca no dice qué capítulo es, vale para cualquiera"""
    if not mark:
        return False
    parts = mark.split("|")
    ident = parts[2] if len(parts) > 2 else ""
    have = EPISODE_RE.search(header or "")
    if ident == "-":
        return not have
    want = EPISODE_RE.search(ident)
    return not want or not have or (int(want.group(1)), int(want.group(2))) == (int(have.group(1)), int(have.group(2)))


def seconds_since(stamp, now):
    try:
        return now - float(stamp)
    except (TypeError, ValueError):
        return float("inf")


def idle_for_guess():
    """contador para adivinar si el usuario tocó algo, solo donde una pulsación no deja marca (ventana Vídeos de Kodi):
    en el resto toda la deja, y el contador también cuenta las teclas de moverse (arrancaba el capítulo sin pedirlo)"""
    if HOME.getProperty("flix_sheet") or not xbmc.getCondVisibility("Window.IsVisible(videos)"):
        return float("inf")
    return xbmc.getGlobalIdleTime()


def same_or_next(stopped, header):
    """¿«header» es lo parado o su siguiente? Lo único que Palantir abre por su cuenta (temporada nueva: su 1.er capítulo)"""
    a, b = EPISODE_RE.search(stopped or ""), EPISODE_RE.search(header or "")
    if not a or not b or series_of(stopped) != series_of(header):
        return False
    s, e, s2, e2 = int(a.group(1)), int(a.group(2)), int(b.group(1)), int(b.group(2))
    return (s2, e2) in ((s, e), (s, e + 1)) or (s2 == s + 1 and e2 <= 1)


def served_other(served, header, now, idle):
    """¿selector de otro título justo después de atender una pulsación? Es Palantir: el usuario ya tiene el suyo"""
    stamp, _, title = (served or "").partition("|")
    age = seconds_since(stamp, now)
    return title != header and 0 <= age < REOPEN_MAX and idle + 1 >= age


def palantir_reopen(since_stop, idle):
    """¿El selector que se abre tras parar lo reabre Palantir solo? Hasta REOPEN_FAST s, sí; hasta REOPEN_MAX, si
    nadie ha tocado el mando desde que se paró. En la Shield llegaba a los ~8 s y se tomaba por una apertura nueva:
    volvía a reproducir el mismo capítulo, y así cada vez que se salía (Carlos, 23-oct, Slow Horses 1x03)"""
    return since_stop <= REOPEN_FAST or (since_stop <= REOPEN_MAX and idle + 1 >= since_stop)


def palantir_next(stopped, header, since_stop, idle):
    """¿El selector que se abre tras parar el capítulo «stopped» es Palantir abriendo el SIGUIENTE por su cuenta?
    Un capítulo de la misma serie, poco después y sin tocar el mando desde que se paró. Lo que pide el usuario lleva marca
    de pulsación y no llega aquí (también «Seguir viendo» del mismo capítulo: Fire TV, El Castillo, Carlos 24-oct)"""
    if since_stop >= AFTER_STOP_SECS or idle + 1 < since_stop:
        return False
    a, b = EPISODE_RE.search(stopped or ""), EPISODE_RE.search(header or "")
    if a and b and (int(b.group(1)), int(b.group(2))) < (int(a.group(1)), int(a.group(2))):
        return False                    # uno anterior: Palantir solo abre el mismo o el siguiente
    return bool(series_of(header)) and series_of(header) == series_of(stopped)


def pin_cancelled(mark, now):
    """¿Se cerró hace poco el aviso de vincular AllDebrid? (marca flix_pin_closed de flix_debrid.py)"""
    return mark.isdigit() and 0 <= now - int(mark) < PIN_SECS


def decide():
    items = []
    for _ in range(40):  # el diálogo rellena la lista justo después de onload
        n = xbmc.getInfoLabel("Container(3).NumItems")
        if n.isdigit() and int(n) > 0:
            items = [xbmc.getInfoLabel("Container(3).ListItem(%d).Label" % i) for i in range(int(n))]
            break
        nap(50)
    if not items:
        return None                 # sin lista: main() enseña el selector por si acaso, como siempre
    if not items[0].startswith("Ver en"):
        return False                # selector de Kodi (idiomas, subtítulos…): ni foco ni flix_select_show (PY-26)
    conf = flix_quality.load()
    header = clean(xbmc.getInfoLabel("Control.GetLabel(1)"))
    if pin_cancelled(HOME.getProperty("flix_pin_closed"), time.time()):
        # el usuario cerró el aviso de vincular AllDebrid: otro enlace = otro PIN (bucle sin salida). Se para aquí.
        HOME.clearProperty("flix_pin_closed")
        HOME.clearProperty("flix_autoplay_state")
        flix_playload.clear_press()
        log("%s: aviso de vincular AllDebrid cerrado -> no reintento" % header)
        close_selector()
        for _ in range(30):  # el onunload del selector vuelve a poner flix_resolving: se quita para ver el aviso
            if not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                break
            nap(50)
        HOME.clearProperty("flix_resolving")
        notify("AllDebrid sin vincular", "Vuelve a darle y escribe el código en alldebrid.com/pin", 6000)
        return True
    status, tried = read_state(header)
    # la pulsación manda: si el usuario ha pulsado, este selector es suyo, sin plazos ni contador (en el móvil un toque no
    # lo pone a cero: se abría y se cerraba solo hasta la 2.ª pulsación, Carlos 4-nov). Sin marca, plan B para ventanas
    # que no la ponen. Tras parar, Palantir reabre el título parado (a 0,5-3,2 s). Mientras esa reapertura no haya pasado
    # (REOPEN armado), lo que abra es suyo. Después, solo lo parado o su siguiente sin ser lo pulsado: se cierra sin gastar la
    # marca ni quitar la capa. Otro número distinto es lo pulsado con otra numeración (own_numbering, tipo Bleach)
    armed = bool(HOME.getProperty(REOPEN))
    HOME.clearProperty(REOPEN)              # ya está aquí: que lo que venga no se cierre solo
    mark = flix_playload.peek_press()
    mine = press_matches(mark, header)
    since_stop = seconds_since(HOME.getProperty("flix_autoplay_stop"), time.time())
    stopped = HOME.getProperty("flix_after_stop").split("|")[-1]
    no_id = bool(mark) and not (mark.split("|") + ["", "", ""])[2]
    if mark and since_stop < REOPEN_MAX and ((armed and (status == "played" or not mine or no_id)) or
                                             (not mine and same_or_next(stopped, header))):
        log("%s: lo abre Palantir, pulsado otro (%s) -> cierro y espero el suyo" % (header, mark))
        if mine:
            HOME.clearProperty("flix_autoplay_state")
        close_selector_done()
        return True
    flix_playload.clear_press()
    pressed = bool(mark) and (mine or since_stop < REOPEN_MAX)
    if pressed and status in ("played", "trying", "cancelled"):
        status = None
    if close_errors() and status == "trying":
        status = classify_error(LAST_ERROR, xbmc.getGlobalIdleTime())
        if status == "cancelled":
            HOME.setProperty("flix_autoplay_cancel", str(time.time()))
    if status == "cancelled":
        HOME.clearProperty("flix_autoplay_state")
        if cancel_reopen(HOME.getProperty("flix_autoplay_cancel"), time.time()):
            HOME.clearProperty("flix_autoplay_cancel")
            log("%s: reabierto tras cancelar -> cierro el selector" % header)
            close_selector_done()
            if not flix_playload.peek_press():
                flix_playload.cancel()
            return True
        status = None           # vuelve a darle más tarde: apertura nueva

    if status == "played":
        try:
            stopped = float(HOME.getProperty("flix_autoplay_stop") or 0)
        except ValueError:
            stopped = 0.0
        if not palantir_reopen(time.time() - stopped, idle_for_guess()):
            status = None  # se vuelve a abrir el mismo título más tarde: es una apertura nueva
    if status in ("played", "trying"):
        # played = paró la reproducción; trying sin aviso de error = Atrás mientras cargaba
        HOME.clearProperty("flix_autoplay_state")
        log("%s: reabierto tras %s -> cierro el selector" % (header, "reproducir" if status == "played" else "cancelar"))
        close_selector_done()
        if not flix_playload.peek_press():
            flix_playload.cancel()          # Atrás mientras cargaba: de vuelta el progreso que Palantir borró al empezar
        return True

    if status == "failed":
        first = tried[0] if tried and not conf.auto else None
        for idx in flix_quality.fallback_order(items, conf, first):
            if idx not in tried:
                play(header, items, idx, tried)
                return True
        if pressed or pressed_again(HOME.getProperty(flix_playload.PRESSED), state_time(header)):
            # fallaron todos en una pulsación anterior (un rato del hoster: Naruto 26-oct, test_autoplay_otra_pulsacion)
            log("%s: fallaron todos antes (probados %s); pulsado otra vez -> pruebo de nuevo" % (header, tried))
            status = None
        else:
            HOME.clearProperty("flix_autoplay_state")
            log("%s: ningún enlace funciona (probados %s)" % (header, tried))
            close_selector_done()
            if not flix_playload.peek_press():
                flix_playload.cancel()      # fuera la pantalla de carga ya (tapaba el aviso) y de vuelta el progreso
            notify(header or "KER0N3 MEDIA", HOME.getProperty("flix_fail_reason") or "Ningún enlace disponible ahora mismo", 4000)
            HOME.clearProperty("flix_fail_reason")
            return True

    # primera apertura para este título. Si llega justo después de parar un capítulo, es Palantir abriendo el
    # SIGUIENTE por su cuenta: solo se deja si se pidió (Siguiente / aviso sin cancelar al acabar)
    after = HOME.getProperty("flix_after_stop").split("|")
    HOME.clearProperty("flix_after_stop")
    if len(after) >= 3 and after[0].isdigit() and not pressed and \
            palantir_next(after[2], header, time.time() - int(after[0]), idle_for_guess()):
        if after[1] == "stay":
            log("%s: Palantir abre el siguiente tras salir de %r -> me quedo en el menú" % (header, after[2]))
            close_selector()
            return True
        log("%s: siguiente capítulo pedido" % header)
    if pressed:
        HOME.setProperty(SERVED, "%.1f|%s" % (time.time(), header))
    elif HOME.getProperty(SERVED) and served_other(HOME.getProperty(SERVED), header, time.time(), idle_for_guess()):
        log("%s: lo abre Palantir tras atender una pulsación -> cierro" % header)
        close_selector()
        return True
    HOME.clearProperty("flix_autoplay_state")
    HOME.clearProperty("flix_autoplay_stop")
    HOME.clearProperty(QUIET)               # apertura nueva: su rueda, como siempre
    if conf.auto and pick_once():
        log("%s: «Elegir resolución» -> selector esta vez" % header)
    elif conf.auto:
        order = flix_quality.preferred(items, conf)
        if order:
            play(header, items, order[0], [])
            return True
        log("%s: sin versiones aptas para %s, selector manual" % (header, flix_quality.dump(conf.order)))
    manual(header, items)
    return True


def follow():
    """RunScript(flix_autoplay.py,follow) desde el onload de VideoFullScreen: sigue la reproducción (aviso de
    siguiente capítulo y qué hacer al acabar) cuando NO ha pasado por el selector (Palantir con reproducción
    automática, p. ej. Fire TV Eren). Si el autoplay ya la sigue (marca reciente), no hace nada."""
    if follower_active(HOME.getProperty("flix_following"), time.time()):
        return
    HOME.setProperty("flix_following", str(time.time()))
    player = xbmc.Player()
    for _ in range(20):
        if player.isPlayingVideo():
            break
        nap(100)
    else:
        HOME.clearProperty("flix_following")
        return
    header = player_header(xbmc.getInfoLabel("VideoPlayer.TVShowTitle"), xbmc.getInfoLabel("VideoPlayer.Season"),
                           xbmc.getInfoLabel("VideoPlayer.Episode"), clean(xbmc.getInfoLabel("Player.Title")))
    log("sigo la reproducción sin selector: %s" % header)
    follow_playback(header)


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "follow":
        follow()
        return
    handled = None
    try:
        handled = decide()
    finally:
        if handled is None:     # lista vacía o error: que se vea el selector si sigue abierto (False = ajeno, se deja)
            show_selector()
        if not HANDOFF[0] and not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
            HOME.clearProperty("flix_resolving")  # puesta por el onunload del selector (cancelar / cerrado sin cargar)


if __name__ == "__main__":     # RunScript lo ejecuta como __main__; importado (tests) no hace nada
    main()
