"""«Recargar skin» del menú de salir (gen_power_menu; Carlos, 31-oct) y el instalador (tools/flix_install.py).

ReloadSkin() a pelo con el Inicio abierto tiraba Kodi (Shield, 1-nov: tres veces seguidas): el Inicio y las secciones son
ventanas de Python en doModal; al recargar, Kodi las destruye con el skin viejo y luego su Python las cierra otra vez
(SIGSEGV en CGUIWindow::~CGUIWindow desde CGUIWindowManager::CloseWindowSync). Aquí primero se cierran ellas, se espera a
que no quede ninguna delante y entonces se recarga; el Inicio lo vuelve a abrir Home.xml al cargar, como al arrancar
(y con él, el sorteo de filas al azar que estaba preparado).
Si alguna no se va a tiempo, no se recarga (mejor sin recargar que Kodi cerrado).

Las ventanas se enteran por Window(home).Property(flix_reload) (la hora de la petición, ver reloading()): el Inicio TV y
el táctil por su token (fi_token/fh_token, que se quedan sin dueño y ellos se retiran) y las secciones por reloading().
Al cerrarse el Inicio Kodi vuelve a Home y su onload lanza otro Inicio antes de recargar (Shield, 1-nov: 0,6 s antes):
con flix_reload_hold puesta hasta que acaba ReloadSkin ese no abre nada (holding()); después, si no hay Inicio, lo abre
ensure_home().

Uso: RunScript(special://skin/scripts/flix_reload.py)
"""
import time

PROP = "flix_reload"
HOLD = "flix_reload_hold"   # mientras: el Inicio no se abre (lo abre el onload de Home tras recargar, o ensure_home)
FRESH = 15                  # s que vale la marca: lo que tarda en irse todo y recargar, de sobra
WAIT = 6                    # s como mucho esperando a que se cierren las ventanas de Python
PY_WINDOWS = range(13000, 13100)        # ids que Kodi da a las ventanas y diálogos de Python (WINDOW_PYTHON_*)


def fresh(value, now):
    """¿la marca (la hora en texto) es de una recarga en marcha? Sin borrarla: una vieja deja de contar sola"""
    try:
        return 0 <= now - float(value) < FRESH
    except (TypeError, ValueError):
        return False


def reloading(home=None):
    """¿se está recargando el skin? Las ventanas de Python se cierran sin más (ni reabrir la ficha de la que se vino)"""
    if home is None:
        import xbmcgui
        home = xbmcgui.Window(10000)
    return fresh(home.getProperty(PROP), time.time())


def holding(home=None):
    """¿hay una recarga a punto? Un Inicio lanzado ahora (onload de Home al cerrarse el de antes) no abre ventana"""
    if home is None:
        import xbmcgui
        home = xbmcgui.Window(10000)
    return fresh(home.getProperty(HOLD), time.time())


def ensure_home(home, secs=5):
    """tras recargar (o al no poder): si en unos segundos no hay Inicio, se abre (el del onload pudo ver aún la marca)"""
    import xbmc
    touch = xbmc.getSkinDir().endswith(".touch")
    key = "fh_running" if touch else "fi_running"
    mon = xbmc.Monitor()
    end = time.time() + secs
    while time.time() < end:
        if home.getProperty(key) == "1" or mon.waitForAbort(0.25):
            return
    xbmc.log("[flix_reload] sin Inicio tras recargar: lo abro", xbmc.LOGINFO)
    xbmc.executebuiltin("RunScript(special://skin/scripts/%s)" % ("flix_home.py" if touch else "flix_inicio.py"))


def python_window_open():
    import xbmcgui
    return (xbmcgui.getCurrentWindowId() in PY_WINDOWS or xbmcgui.getCurrentWindowDialogId() in PY_WINDOWS)


def main():
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    now = "%f" % time.time()
    home.setProperty(HOLD, now)             # antes que nada: el Inicio que lance Home al quedarse delante, que espere
    home.setProperty(PROP, now)
    # el Inicio (TV y táctil) ve que su token ya no es el suyo y se cierra él (tick / hero_timer)
    home.setProperty("fi_token", "reload")
    home.setProperty("fh_token", "reload")
    xbmc.executebuiltin("Dialog.Close(all,true)")           # el menú de salir, encima de todo
    mon = xbmc.Monitor()
    end = time.time() + WAIT
    while python_window_open():
        if time.time() > end or mon.waitForAbort(0.2):
            xbmc.log("[flix_reload] sigue abierta una ventana de Python (%s/%s): no recargo"
                     % (xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId()), xbmc.LOGWARNING)
            home.clearProperty(PROP)
            home.clearProperty(HOLD)
            xbmcgui.Dialog().notification("Flix", "No se pudo recargar el skin. Prueba otra vez en un momento",
                                          xbmcgui.NOTIFICATION_WARNING, 4000)
            ensure_home(home)               # el Inicio ya se había ido
            return
    # sin dueño: el Inicio que abra Home.xml no debe creer que ya hay uno (already_open)
    for k in ("fi_running", "fi_window", "fi_token", "fh_running", "fh_window", "fh_token"):
        home.clearProperty(k)
    # filas al azar: como al arrancar, el sorteo preparado pasa a usarse al abrir el Inicio (flix_random_rows.promote_saved,
    # una vez por sesión con esta marca; Carlos, 1-nov: «recargar la skin sacará las nuevas filas aleatorias»)
    home.clearProperty("flix_rnd_done")
    if mon.waitForAbort(0.5):          # que el Python de cada ventana acabe de soltarla (del win)
        return
    xbmc.log("[flix_reload] ventanas de Python cerradas: recargo el skin", xbmc.LOGINFO)
    xbmc.executebuiltin("ReloadSkin()", True)       # True: vuelve cuando Kodi ya la ha hecho
    home.clearProperty(HOLD)
    ensure_home(home)


if __name__ == "__main__":
    main()
