"""Complementos que hacen falta para los tráileres: YouTube e InputStream Adaptive (Carlos, 24-oct).

Kodi para Android no trae InputStream Adaptive de serie: sin él el addon de YouTube abre el tráiler con ffmpeg y en la
Shield tardaba 17-24 s en empezar (móvil, con él, al momento). En la Shield además estaba ROTO desde el 13-ago
(carpeta con todos los ficheros a 0 bytes: instalación cortada): Kodi lo daba por instalado y no lo usaba.

Al arrancar la skin (Startup.xml, TV y táctil), si falta o está roto alguno: una pregunta («Instalar» marcado) y
InstallAddon de cada uno. «Ahora no» = no vuelve a preguntar (Skin.SetBool(flix_deps_no)).
Uso: RunScript(special://skin/scripts/flix_deps.py)"""
import os
import time

DEPS = (("plugin.video.youtube", "YouTube"), ("inputstream.adaptive", "InputStream Adaptive"))
NO = "flix_deps_no"
WAIT = 25           # tras arrancar: que pase la intro y salga el Inicio antes de preguntar


def state(addons_dir, addon_id):
    """ok | broken (addon.xml vacío o ilegible) | missing"""
    xml = os.path.join(addons_dir, addon_id, "addon.xml")
    if not os.path.exists(xml):
        return "missing"
    try:
        return "ok" if os.path.getsize(xml) > 0 else "broken"
    except OSError:
        return "broken"


def pending(addons_dir):
    """[(id, nombre, estado)] de los que hay que instalar, en orden (YouTube primero)"""
    return [(i, n, s) for i, n in DEPS for s in [state(addons_dir, i)] if s != "ok"]


def question(todo):
    names = [n for _, n, _ in todo]
    what = names[0] if len(names) == 1 else " e ".join([", ".join(names[:-1]), names[-1]])
    return "Para que los tráileres carguen rápido hace%s falta %s. ¿Instalar%s ahora?" % (
        "n" if len(names) > 1 else "", what, "los" if len(names) > 1 else "lo")


def empty_dir(path):
    """vacía la carpeta de un complemento roto SIN borrarla: Kodi la aparta antes de instalar y, si no existe,
    la instalación falla («Failed to move old addon files», Shield 24-oct)"""
    import shutil       # aquí y no arriba: solo con un complemento roto (revisión 29-oct ARR-23)
    for name in os.listdir(path):
        p = os.path.join(path, name)
        if os.path.isdir(p) and not os.path.islink(p):
            shutil.rmtree(p, ignore_errors=True)
        else:
            try:
                os.remove(p)
            except OSError:
                pass


def at_home(xbmc, xbmcgui):
    """en el Inicio (TV: ventana de flix_inicio, fi_window; táctil: la de flix_home, fh_window), sin vídeo ni diálogos"""
    home = xbmcgui.Window(10000)
    wid = str(xbmcgui.getCurrentWindowId())
    if wid not in (home.getProperty("fi_window"), home.getProperty("fh_window")):
        return False
    return not xbmc.getCondVisibility("Player.HasMedia | System.HasActiveModalDialog | System.HasModalDialog")


def main():
    import sys
    import xbmc
    import xbmcgui
    import xbmcvfs
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import first_run
    if not first_run.once("complementos"):
        return              # ya lo lanzó first_run (o el Startup táctil): una vez por sesión
    import flix_common
    mon = flix_common.quit_monitor()   # al cerrarse Kodi se para en menos de 1 s (System.OnQuit; APA-03)
    if xbmc.getCondVisibility("Skin.HasSetting(%s)" % NO):
        return
    addons = xbmcvfs.translatePath("special://home/addons/")

    def missing():
        # «missing» en la carpeta del usuario pero Kodi lo tiene: viene con Kodi (Linux, Windows, LibreELEC: carpeta
        # del sistema). Roto en la del usuario sí se reinstala aunque Kodi diga que lo tiene (Shield 24-oct)
        return [d for d in pending(addons)
                if d[2] == "broken" or not xbmc.getCondVisibility("System.HasAddon(%s)" % d[0])]
    # lo normal es que no falte nada: se mira ANTES de esperar y el intérprete no se queda 25 s vivo para nada
    # (revisión 29-oct ARR-06). Si falta algo, como siempre: se espera y se vuelve a mirar
    if not missing():
        return
    if flix_common.wait_quit(mon, WAIT):
        return
    todo = missing()
    if not todo:
        return
    # solo en el Inicio y sin nada encima: sobre la ficha de serie el aviso se quedaba sin botón con foco (su vigilante
    # mueve el foco) y el mando no hacía nada (banco, 24-oct). Si no se llega al Inicio en 10 min, otro día
    end = time.time() + 600
    while not at_home(xbmc, xbmcgui):
        if time.time() > end or flix_common.wait_quit(mon, 5):
            return
    xbmc.log("[flix_deps] faltan: %s" % ", ".join("%s (%s)" % (i, s) for i, _, s in todo), xbmc.LOGINFO)
    ok = xbmcgui.Dialog().yesno("Tráileres", question(todo), nolabel="Ahora no", yeslabel="Instalar",
                                defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
    if not ok:
        xbmc.executebuiltin("Skin.SetBool(%s)" % NO)
        return
    for addon_id, _name, st in todo:
        if st == "broken":
            empty_dir(os.path.join(addons, addon_id))
        xbmc.executebuiltin("InstallAddon(%s,true)" % addon_id, True)      # true: sin volver a preguntar


if __name__ == "__main__":
    main()
