"""Lo saltado («+00:30») y adónde, en la barra mientras sigue en pantalla (VideoFullScreen.xml lo lanza al abrirse).

Kodi pone Player.SeekOffset a 0 en cuanto el reproductor hace el salto (VideoPlayer: SeekFinished(0) al procesar el
salto), así que con solo esa etiqueta el «+00:30» duraba los 0,75 s del seekdelay; y entre pedir el salto y hacerlo,
Player.SeekTime vuelve al tiempo de antes (Carlos, Shield 9-nov). Aquí se apunta lo que avisa Kodi en cada salto
(onPlayBackSeek: destino y lo saltado) en Window(home): flix_seekoff («+00:30») y flix_seekto («11:55»). FlixSeekRow
enseña flix_seekoff mientras Player.HasPerformedSeek(3), los mismos 3 s que la barra.

Sin bucle de consultas: espera el aviso de Kodi; cada segundo mira si el vídeo sigue (si no, se va) y borra lo apuntado
pasados KEEP s, para que un salto viejo no reaparezca. Una sola copia (flix_seek_on): la ventana del vídeo se vuelve a
cargar cada vez que se vuelve a él."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import time  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

OFF = "flix_seekoff"
TO = "flix_seekto"
LOCK = "flix_seek_on"
KEEP = 4


def fmt(ms):
    """milisegundos de Kodi -> «+00:30», «-10:00», «+1:05:00» (como Player.SeekOffset); '' si no hay salto"""
    ms = int(ms)
    if not ms:
        return ""
    return ("-" if ms < 0 else "+") + fmt_time(abs(ms))


def fmt_time(ms):
    """milisegundos -> «11:55» o «1:05:00» (como la barra: sin ceros sobrantes en las horas)"""
    s = max(0, int(ms)) // 1000
    h, rest = divmod(s, 3600)
    m, sec = divmod(rest, 60)
    return "%d:%02d:%02d" % (h, m, sec) if h else "%02d:%02d" % (m, sec)


class _Player(xbmc.Player):
    def __init__(self, home):
        super().__init__()
        self.home = home
        self.at = 0.0

    def onPlayBackSeek(self, time_ms, seekOffset):
        label = fmt(seekOffset)
        if label:
            self.home.setProperty(OFF, label)
            self.home.setProperty(TO, fmt_time(time_ms))
            self.at = time.monotonic()

    def expire(self, now=None):
        """borra lo apuntado pasados KEEP s del último salto"""
        if self.at and (now if now is not None else time.monotonic()) - self.at > KEEP:
            self.home.clearProperty(OFF)
            self.home.clearProperty(TO)
            self.at = 0.0


def main():
    home = xbmcgui.Window(10000)
    if home.getProperty(LOCK):
        return
    home.setProperty(LOCK, "1")
    try:
        player = _Player(home)
        mon = xbmc.Monitor()
        while not mon.waitForAbort(1):
            if not xbmc.getCondVisibility("Player.HasMedia"):
                break
            player.expire()
    finally:
        home.clearProperty(OFF)
        home.clearProperty(TO)
        home.clearProperty(LOCK)


if __name__ == "__main__":
    main()
