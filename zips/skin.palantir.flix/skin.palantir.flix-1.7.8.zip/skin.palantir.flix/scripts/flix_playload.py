"""Pantalla de carga única al reproducir (Custom_1198_FlixPlayLoad.xml: fondo de la película/serie + una sola rueda).

Entre pulsar y ver la imagen se turnan la rueda de Kodi, la de flix_series, el selector oculto de Palantir
(flix_autoplay) y el progreso de AllDebrid (flix_debrid); cada uno pinta su propia rueda y en los relevos (0,2-0,5 s)
no había ninguna: se veía el Inicio con la carátula enfocada y otra rueda después (Carlos, 25-oct, Shield).
begin() enciende la capa (Window(home).Property(flix_playload)) y un hilo la quita: al salir el vídeo, si hay que
enseñar algo (selector en modo manual, aviso o pregunta de Palantir), si nada carga durante IDLE_MAX (Atrás, fallo sin
aviso) o como mucho a los MAX_SECS. El hilo no es daemon: el RunScript que la enciende espera a que termine.
"""
import json
import os
import re
import sqlite3
import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import WATCHED_DB_REL, decode_route  # noqa: E402

HOME = xbmcgui.Window(10000)
PROP, FANART, SNAP = "flix_playload", "flix_playload_fanart", "flix_playload_snap"
PENDING = "pending"     # PROP puesta por el pop-up «Te quedaste en…» al pulsar, antes del begin() real (sin hilo): no es una marca
PRESSED = "flix_play_pressed"   # hora del último begin() (no se borra): flix_autoplay distingue otra pulsación
USER_PRESS = "flix_user_press"  # el usuario ha pulsado y su selector aún no se ha abierto (begin() o el <onclick> de las
#                                 listas de capítulos). Lo consume flix_autoplay.decide(); se borra al parar y al cancelar.
#                                 Valor: «lista|posición|capítulo» («7970|6|2x6»); de un botón, sin lista («||2x6»,
#                                 «||-» película, «||» no se sabe)
USER_PRESS_PATH = "flix_user_press_path"    # ruta del capítulo pulsado en la lista
# Palantir BORRA la fila a medias de watched.db en cuanto empieza su acción de reproducir y la reescribe al parar:
# Atrás mientras cargaba dejaba la película fuera de «Seguir viendo» hasta el próximo arranque (Trakt la conserva y
# Palantir la vuelve a bajar entonces; Carlos, 25-oct, Del revés). begin() la guarda y cancel() la devuelve.
WATCHED_DB = xbmcvfs.translatePath(WATCHED_DB_REL)
TABLES = {"movies": ("movies_watched", ("tmdb_id",)), "tvshows": ("episodes_watched", ("tmdb_id", "season", "episode"))}
STEP = 0.1
IDLE_MAX = 2.0      # s sin rueda de nadie ni vídeo: se acabó (los relevos duran 0,2-0,5 s)
# al pasar al siguiente capítulo los huecos de Palantir son más largos que al pulsar play (Fire TV tardó 23 s en total
# en abrirlo, aunque las ruedas cubren casi todo): flix_autoplay.follow_playback espera más antes de dar la capa por parada
NEXT_IDLE = 10.0
# y la ventana del vídeo que acaba de parar aún puede estar activa al encender la capa: no cuenta como «ya se ve»
NEXT_GRACE = 2.0
MAX_SECS = 120
FULL_WAIT = 1.5     # s con vídeo (no tráiler) sin pantalla completa: se pone (windowed_since)
# lo que suena es el tráiler de la ficha (en su recuadro, a propósito sin pantalla completa)
TRAILER = ("!String.IsEmpty(Window(home).Property(flix_trailer)) | !String.IsEmpty(Window(home).Property(flix_tr_on)) | "
           "String.Contains(Player.Filenameandpath,plugin.video.youtube)")
LOADING = ("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog) | "
           "Window.IsActive(progressdialog)")
# avisos de fallo mientras se resuelve un enlace: flix_autoplay los cierra y prueba otro (no se enseñan)
QUESTION = ("[Window.IsActive(okdialog) | Window.IsActive(yesnodialog)] + "
            "!String.IsEqual(Window(home).Property(flix_resolving),true)")


def decide(st, now, t0, idle, idle_max=IDLE_MAX, grace=0.0):
    """(por qué quitar la capa o None, desde cuándo no carga nada). video = ya se ve; mostrar = selector manual o
    aviso/pregunta de Palantir; parado = nada carga desde hace idle_max (Atrás antes del selector, fallo sin aviso)
    o demasiado tiempo: el progreso que Palantir borró al empezar se devuelve (cancel). grace: los primeros s desde t0
    la pantalla completa no quita la capa (siguiente capítulo: fullscreenvideo sigue activa un momento al parar)"""
    if st["fullscreen"] and now - t0 >= grace:
        return "video", idle
    if st["manual"] or st["question"]:
        return "mostrar", idle
    if now - t0 > MAX_SECS:
        # con la película ya sonando no es un «parado»: cancel() devolvería un progreso que Palantir reescribe al parar
        return ("video" if st.get("video") and not st.get("trailer") else "parado"), idle
    if st["loading"] or st["media"]:
        return None, None
    idle = now if idle is None else idle
    return ("parado" if now - idle > idle_max else None), idle


def windowed_since(st, now, since):
    """desde cuándo hay vídeo (no el tráiler) sin pantalla completa; None si no. Red de seguridad de
    flix_play.play_full: un vídeo que Kodi empieza en ventana sonaba detrás de la ficha sin que nadie lo viera
    (Shield, 2-nov): pasados FULL_WAIT s, watch() lo pone a pantalla completa"""
    if st["fullscreen"] or not st.get("video") or st.get("trailer"):
        return None
    return now if since is None else since


def state():
    cond = xbmc.getCondVisibility
    return {"fullscreen": cond("Window.IsActive(fullscreenvideo)"),
            "manual": HOME.getProperty("flix_select_show") == "true",
            "question": cond(QUESTION), "loading": cond(LOADING), "media": cond("Player.HasMedia"),
            "video": cond("Player.HasVideo"), "trailer": cond(TRAILER)}


def route_ids(path):
    """tmdb y tipo (movies / tvshows) de una ruta de Palantir; {} si no se lee"""
    try:
        j = decode_route(path)
    except Exception:  # noqa: BLE001
        return {}
    tm = re.search(r'"tmdb": \'?(\d+)', j)
    kind = "tvshows" if ("'play_mis_serieS'" in j or "'listado_temporadaS'" in j or "\"tvshowtitle\"" in j) else "movies"
    return {"tmdb": tm.group(1), "content": kind} if tm else {}


def snapshot(path):
    """filas a medias (playcount 0, progreso > 0) del título en watched.db: {tabla: [fila como dict]}"""
    ids = route_ids(path)
    if not ids or ids["content"] not in TABLES:
        return {}
    table = TABLES[ids["content"]][0]
    if not os.path.exists(WATCHED_DB):
        return {}
    try:
        # solo lectura: en escritura SQLite crea una base vacía si aún no existe (revisión 29-oct DAT-12, como B-03).
        # restore() sí escribe: solo devuelve filas que la foto leyó, así que la base ya existía
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            db.row_factory = sqlite3.Row
            rows = db.execute("SELECT * FROM %s WHERE tmdb_id = ? AND playcount = 0 AND progress > 0" % table,
                              (int(ids["tmdb"]),)).fetchall()
        finally:
            db.close()
    except sqlite3.Error as e:
        xbmc.log("[flix_playload] no leo %s: %s" % (table, e), xbmc.LOGINFO)
        return {}
    return {table: [dict(r) for r in rows]} if rows else {}


def restore(snap, now=None):
    """devuelve las filas guardadas que ya no estén (Palantir las borró al empezar y no las reescribió: cancelado);
    con fecha de ahora, que el espejo de pausas de flix_p3sync conserva. Devuelve cuántas"""
    if not snap:
        return 0
    now = now or time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())
    keys = {t: k for t, k in TABLES.values()}
    n = 0
    try:
        db = sqlite3.connect(WATCHED_DB, timeout=5)
        try:
            for table, rows in snap.items():
                for row in rows:
                    where = " AND ".join("%s = ?" % k for k in keys[table])
                    if db.execute("SELECT 1 FROM %s WHERE %s" % (table, where), [row[k] for k in keys[table]]).fetchone():
                        continue
                    row = dict(row, lastPlayed=now)
                    cols = list(row)
                    db.execute("INSERT INTO %s (%s) VALUES (%s)" % (table, ", ".join(cols), ", ".join("?" * len(cols))),
                               [row[c] for c in cols])
                    n += 1
            db.commit()
        finally:
            db.close()
    except sqlite3.Error as e:
        xbmc.log("[flix_playload] no devuelvo el progreso: %s" % e, xbmc.LOGINFO)
    if n:
        xbmc.log("[flix_playload] progreso devuelto tras cancelar: %d fila(s)" % n, xbmc.LOGINFO)
    return n


def resume_offset(explicit):
    """segundos a los que retomar un REINTENTO (otro enlace tras fallar el primero: Palantir lo abre él y el
    StartOffset de la 1.ª reproducción se pierde): solo lo que pidió flix_play (flix_play_offset). Nada del progreso
    guardado: con «Desde el principio» un reintento volvería a saltar al minuto de antes"""
    try:
        return int(float(explicit)) if explicit and float(explicit) > 0 else 0
    except ValueError:
        return 0


def cancel(keep_press=False):
    """Atrás mientras cargaba (flix_autoplay): fuera la capa y de vuelta el progreso que Palantir borró al empezar.
    keep_press: la capa se da por parada, pero el selector de lo pulsado aún puede llegar (hasta ~10 s tras parar)"""
    snap = HOME.getProperty(SNAP)
    if not keep_press:
        clear_press()
    end()
    if snap:
        try:
            restore(json.loads(snap))
        except ValueError:
            pass


def clear_pending():
    """quita la capa puesta por el pop-up (PENDING) si el flujo no llega a begin(): sin hilo que la quite se quedaría;
    una marca de verdad (otra carga en marcha) no se toca"""
    if HOME.getProperty(PROP) == PENDING:
        HOME.clearProperty(PROP)
        HOME.clearProperty(FANART)


def end(stamp=None):
    if stamp is None or HOME.getProperty(PROP) == stamp:
        HOME.clearProperty(PROP)
        HOME.clearProperty(FANART)
        HOME.clearProperty(SNAP)


def watch(stamp, idle_max=IDLE_MAX, grace=0.0):
    # hilo que no es daemon (el RunScript espera a que acabe, hasta MAX_SECS): al cerrarse Kodi se para en menos de
    # 1 s (System.OnQuit, flix_common.quit_monitor: sin addon Kodi no avisa por abortRequested; APA-03)
    import flix_common
    mon, t0, idle, why = flix_common.quit_monitor(), time.time(), None, None
    win, forced = None, False
    try:
        while not flix_common.quitting(mon) and HOME.getProperty(PROP) == stamp:
            st, now = state(), time.time()
            why, idle = decide(st, now, t0, idle, idle_max, grace)
            if why:
                break
            win = windowed_since(st, now, win)
            if win is not None and not forced and now - win >= FULL_WAIT:
                forced = True
                xbmc.log("[flix_playload] vídeo en ventana tras %.1f s: a pantalla completa" % (now - win), xbmc.LOGINFO)
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            if flix_common.wait_quit(mon, STEP):
                break
    finally:
        if why == "parado" and HOME.getProperty(PROP) == stamp:
            cancel(keep_press=True)     # Atrás en la 1.ª rueda (sin selector) no pasa por flix_autoplay
        else:
            end(stamp)


def peek_press():
    return HOME.getProperty(USER_PRESS)


def take_press():
    """¿pulsó el usuario? Una pulsación vale para un solo selector"""
    pressed = bool(HOME.getProperty(USER_PRESS))
    clear_press()
    return pressed


def press_id(path):
    """qué se ha pulsado, según la ruta de Palantir: «2x6», «-» si es una película, «» si no se sabe"""
    if not path:
        return ""
    try:
        j = decode_route(path)
    except Exception:  # noqa: BLE001
        return ""
    s = re.search(r"""['"]season['"]: ?['"]?(\d+)""", j)
    e = re.search(r"""['"]episode['"]: ?['"]?(\d+)""", j)
    if s and e:
        return "%sx%s" % (s.group(1), e.group(1))
    return "" if "tvshowtitle" in j or "'play_mis_serieS'" in j or "'listado_temporadaS'" in j else "-"


def clear_press():
    HOME.clearProperty(USER_PRESS)
    HOME.clearProperty(USER_PRESS_PATH)


def begin(fanart="", path="", pressed=True, idle_max=IDLE_MAX, grace=0.0, mark=True):
    """enciende la capa hasta que salga el vídeo (o algo que enseñar); otra begin() la renueva. Con la ruta de Palantir
    guarda el progreso a medias del título (cancel() lo devuelve). pressed=False (siguiente capítulo, sin pulsación del
    usuario): no marca PRESSED, que flix_autoplay lee para detectar una pulsación de verdad. mark=False: capa de un
    bucle, no pone USER_PRESS (decide() ya pudo consumirla). Devuelve la marca (end(marca)
quita solo esta capa)"""
    stamp = "%.3f" % time.time()
    HOME.setProperty(FANART, fanart or "")
    snap = snapshot(path) if path else {}
    HOME.setProperty(SNAP, json.dumps(snap) if snap else "")
    if pressed:
        HOME.setProperty(PRESSED, stamp)
        if mark:
            HOME.setProperty(USER_PRESS, "||" + press_id(path))
    HOME.setProperty(PROP, stamp)
    threading.Thread(target=watch, args=(stamp, idle_max, grace)).start()
    if pressed and (path or "").startswith("plugin://plugin.video.palantir3/"):
        # sin selector (una sola versión) un enlace caído no lo vigila flix_autoplay: aviso (flix_deadlink)
        import flix_deadlink
        threading.Thread(target=flix_deadlink.watch, args=(HOME,)).start()
    return stamp
