# -*- coding: utf-8 -*-
"""Ficha de serie en ventana propia (FlixSeries.xml): temporadas a la izquierda y capítulos de la elegida a la derecha.

Por qué una ventana de Python (código de Kodi 21): en la ventana Vídeos, mantener pulsado un capítulo que no era el
seleccionado solo lo seleccionaba. En Android cada toque manda antes GESTURE_NOTIFY a la lista y esta no sigue al dedo;
la pulsación larga (RightClick) solo abre el menú si el elemento ya estaba seleccionado (CGUIBaseContainer::
OnMouseEvent). Aquí onAction recibe la pulsación (101) con las coordenadas del dedo y se abre el menú KER0N3 del
elemento que hay debajo, a la primera (Carlos, 25-oct).

Listas de FlixSeries.xml:
  7976       carpeta de la serie (Window(home).Property(flix_eps_c6)). Con temporadas va apartada: de ella se leen y a
             ella manda flix_menu la acción de Palantir de una temporada. Con capítulos (serie de una temporada) se ve.
  7952       columna de temporadas: en la de TV sus elementos los añade esta ventana (fill_seasons, addItems); en la
             táctil son huecos fijos flix_s<i>_* (FlixSeasonSlots, flix_series.season_props). Las flix_s<i>_* se ponen
             siempre: las leen flix_menu.season_of y flix_series.season_index
  7970-7975  capítulos de las últimas temporadas vistas (flix_series.EpsSlots)
             (todas, además, con los capítulos que Palantir aún no tiene al final: step_pending, FlixPendingItems)
Fase 1: solo la táctil (flix_series.use_sheet). Spec: docs/superpowers/specs/2026-10-25-ficha-serie-ventana-propia-design.md
"""
import os
import re
import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_screen  # noqa: E402
import flix_series  # noqa: E402

HOME = xbmcgui.Window(10000)
SERIES_SLOT = 6                                        # la 7976 es el «hueco» 6 de las listas de capítulos
SERIES_LIST = flix_series.EPS_FIRST_ID + SERIES_SLOT   # 7976
SEASONS_LIST = flix_series.SEASONS_LIST                # 7952
EPS_FIRST_ID = flix_series.EPS_FIRST_ID                # 7970
# geometría de touch/xml/FlixSeries.xml y de FTEpsList (Includes_FlixTouch.xml): test_series_sheet_xml.py las compara
COL_LEFT, COL_W, COL_TOP, COL_ITEM_H = 46, 580, 210, 144     # temporadas de 48 dp (TCT-01; antes 140)
EPS_LEFT, EPS_RIGHT, EPS_TOP, EPS_ITEM_H = 650, 30, 210, 262
ONE_LEFT, ONE_RIGHT, ONE_TOP, ONE_ITEM_H = 46, 46, 290, 262
A_LONG, A_CTX = 101, 117       # pulsación larga (con coordenadas) / menú contextual (sin ellas)
A_SELECT = 7                   # OK del mando (ACTION_SELECT_ITEM)
LATE_CLICK = 1.0               # s tras parar: un clic aquí es el que lanzó el vídeo, que llega tarde (Kodi corre su clic antes)
PRESS_MAX = 30                 # s: una pulsación sin selector ni vídeo en este tiempo se da por perdida
A_CLICK = 100                  # toque (con coordenadas del dedo): ACTION_MOUSE_LEFT_CLICK
A_MOVE = 107                   # dedo apoyado (con sus coordenadas): ACTION_MOUSE_MOVE (note_press)
TAP_AGE = 5.0                  # s que un toque en un capítulo vale para la carga que arranca
ORIGIN_AGE = 60.0              # s sin carga ni vídeo tras los que se olvida el capítulo de una carga (next_origin)
A_BACK = flix_common.A_BACK      # códigos de Atrás comunes (TV-28)
CTX_WAIT = 0.35                # s que un 117 sin coordenadas espera al 101 de la misma pulsación (como flix_home)
FOCUS_WAIT = 1.5               # s que open_menu espera a que la lista tenga el foco en el elemento pedido
LONG_REPEAT = 1.5              # s: un 117 justo después de una pulsación ya atendida es su eco
MENU_START = 5.0               # s que se le dan a flix_menu.py para arrancar (flix_menu_run = «s<hora>»)
LOAD_SECS = 30                 # s esperando a que Palantir dé la serie (dos intentos)
MODE_PEEK = 3                  # elementos de la carpeta que se miran para saber qué dio Palantir
CONTENT_RE = re.compile(r'"content": \'(\w+)')   # como flix_progress.CONTENT_RE
PLAY_STEP = 1.0                # s por vuelta del bucle con un vídeo en marcha: solo hay que notar la parada (PY-05)
SEASONS_EVERY = 3.0            # s entre firmas de las temporadas en reposo (window_seasons: 40 × 9 getInfoLabel)
SEASONS_FAST = 1.0             # … los FAST_SECS siguientes a un vídeo o al menú: la carpeta recargada llega en 1-3 s
FAST_SECS = 10


def log(msg):
    xbmc.log("[flix_series_sheet] %s" % msg, xbmc.LOGINFO)


def ival(v, default=-1):
    return int(v) if str(v or "").isdigit() else default


def index_at(rel_y, item_h, cur, pos, n):
    """índice (0..n-1) del elemento a rel_y píxeles del borde de arriba de una lista vertical, o None.
    cur = Container(id).CurrentItem (1..n) y pos = Container(id).Position (fila en pantalla, desde 0): la parte a la
    vista empieza en cur-1-pos"""
    if rel_y < 0 or n < 1 or cur < 1 or pos < 0:
        return None
    i = cur - 1 - pos + int(rel_y // item_h)
    return i if 0 <= i < n else None


def list_at(sx, sy, skin_w, mode):
    """(lista, y desde su borde de arriba, alto de elemento) bajo el punto sx, sy (skin), o None. «eps» = la lista de
    capítulos a la vista (cuál, lo dice flix_eps_slot)"""
    if mode == "one":
        if ONE_LEFT <= sx <= skin_w - ONE_RIGHT and sy >= ONE_TOP:
            return SERIES_LIST, sy - ONE_TOP, ONE_ITEM_H
        return None
    if mode != "seasons":
        return None
    if COL_LEFT <= sx < COL_LEFT + COL_W and sy >= COL_TOP:
        return SEASONS_LIST, sy - COL_TOP, COL_ITEM_H
    if EPS_LEFT <= sx <= skin_w - EPS_RIGHT and sy >= EPS_TOP:
        return "eps", sy - EPS_TOP, EPS_ITEM_H
    return None


def route_content(path):
    """«content» de la ruta de Palantir de un elemento ('seasons' en una temporada, 'episodes' en un capítulo; como
    flix_menu.kind_of), o '' si no es una ruta de Palantir o no se lee"""
    try:
        m = CONTENT_RE.search(flix_common.decode_route(path)) if path else None
    except Exception:  # noqa: BLE001
        return ""
    return m.group(1) if m else ""


def mode_of(n, items):
    """qué dio Palantir en la carpeta de la serie: '' (aún nada), 'one' (capítulos: serie de una temporada) o
    'seasons'. items = [(DBType, content de la ruta, Episode), ...] de los primeros elementos (MODE_PEEK).
    Manda el tipo del elemento: que las temporadas vengan sin número de capítulo solo lo garantiza el Palantir
    falso del banco; addons reales lo rellenan también en ellas y una serie de varias temporadas se abría como de
    una (revisión final, 25-oct). Sin tipo en ninguno, la regla de antes: con número de capítulo en el 1.º,
    capítulos"""
    if n < 1:
        return ""
    if any(d == "season" or c == "seasons" for d, c, _ in items):
        return "seasons"
    if any(d == "episode" or c == "episodes" for d, c, _ in items):
        return "one"
    return "one" if items and str(items[0][2]).isdigit() else "seasons"


def menu_busy(run, now):
    """¿hay un menú KER0N3 en marcha? run = Window(home).Property(flix_menu_run): «1» = flix_menu.py corriendo,
    «s<hora>» = esta ventana lo acaba de lanzar y aún no ha arrancado (si no arranca, a los MENU_START s se olvida)"""
    if run == "1":
        return True
    try:
        return run.startswith("s") and now - float(run[1:]) < MENU_START
    except ValueError:
        return False


def ctx_skip(coords, last_long, now, busy):
    """¿no atender esta acción de menú? Con un menú en marcha (flix_menu manda sus Action(ContextMenu) por detrás) o un
    117 sin coordenadas justo después de una pulsación ya atendida: Kodi lo manda además del 101 cuando el elemento ya
    estaba seleccionado (PyWindowXML: RightClick en una lista)"""
    if busy:
        return True
    return not coords and bool(last_long) and now - last_long < LONG_REPEAT


def tap_source(tap, now):
    """(lista, posición, ruta) del capítulo tocado si el toque es reciente, o None. Banco 25-oct: al volver del vídeo
    Kodi deja la ficha sin foco; al tocar un capítulo la lista lo tiene una fracción de segundo antes de que salga el
    selector de enlaces de Palantir, y el sondeo (0,15 s) nunca lo ve: el capítulo se sabe por el toque, no por el foco"""
    return (tap[0], tap[1], tap[2]) if tap and now - tap[3] <= TAP_AGE else None



def latest_source(tap, press, now):
    """el más reciente de los dos que sigan valiendo (tap_source): el toque (100) o el dedo apoyado (107). Si una carga
    se cancela, el 100 de su toque llega al final (Kodi lo entrega tras la carga) y queda vigente unos segundos: si en ese
    rato se toca otro capítulo, manda el dedo apoyado, que es más nuevo (con «toque primero» ganaba el de antes)"""
    cands = [x for x in (tap, press) if tap_source(x, now)]
    return tap_source(max(cands, key=lambda x: x[3]), now) if cands else None

def next_origin(current, new, now, last_busy):
    """capítulo (lista, posición) desde el que se lanzó lo que se está cargando, al EMPEZAR una carga. new = el de
    esta carga (toque, dedo apoyado o foco) o None. Banco 25-oct: con varios enlaces que fallan, Palantir/
    flix_autoplay reintenta con más de 3 s entre diálogos; cada relevo se tomaba por una carga nueva, ya sin toque (se
    gastó en la primera), y dejaba el origen en None: tras el vídeo el foco no volvía al capítulo. Sin uno nuevo se
    conserva el anterior, salvo que lleve más de ORIGIN_AGE s sin carga ni vídeo (last_busy): una carga cancelada no
    se atribuye a un vídeo que empiece mucho después"""
    if new is not None:
        return new
    return current if now - last_busy <= ORIGIN_AGE else None


def signature(items):
    """lo que cambia en las temporadas al marcar o ver algo (flix_series.window_seasons)"""
    return [(x["pct"], x["path"], x["total"], x.get("seen")) for x in items]


def press_origin(mark):
    """(lista, posición) de la marca de pulsación («7970|6|2x6», el <onclick> de la lista), o None si vino de un botón"""
    parts = (mark or "").split("|")
    if len(parts) < 2 or not parts[0].isdigit() or not parts[1].isdigit() or int(parts[1]) < 1:
        return None
    return parts[0], parts[1]


def focus_back_due(since_stop, acted):
    """¿devolver el foco al capítulo tras parar? Kodi lo manda a las temporadas al recargar las listas. Solo si el usuario
    no ha hecho nada en la ficha desde que paró (onAction: sin el contador de inactividad, que no ve los toques)"""
    return not acted and since_stop < flix_series.BACK_PLAY_SECS


def pending_item(row):
    """ListItem de un capítulo que Palantir no tiene (flix_series.pending_rows): etiqueta, miniatura, sinopsis y la
    frase en flix_pending. Sin Episode en el InfoTag: episodes_of/remember_eps lo tomarían por uno de Palantir"""
    li = xbmcgui.ListItem(label=row["label"])
    li.setProperty(flix_series.PENDING, row["pending"])
    if row.get("thumb"):
        li.setArt({"thumb": row["thumb"]})
    if row.get("plot"):
        try:
            li.getVideoInfoTag().setPlot(row["plot"])
        except (AttributeError, RuntimeError):
            pass
    return li


class SeriesSheet(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.folder = kwargs.get("folder", "")
        self.res = None                  # flix_screen.skin_res() (onInit)
        self.mode = ""                   # '' cargando, 'seasons' o 'one' (mode_of)
        self.last_long = 0.0             # última pulsación larga atendida
        self.ctx_wait = 0.0              # 117 sin coordenadas esperando a su 101
        self.started = self.stop = self.closing = False
        self.win_id = 0                  # id de esta ventana (Python: 13000+)
        self.slots = flix_series.EpsSlots()
        self.tap = None                  # (lista, posición, ruta, hora) del último capítulo tocado (onAction)
        self.press = None                # lo mismo del capítulo bajo el dedo al apoyarlo (note_press)
        self.sig, self.sig_at, self.noted, self.check = [], 0.0, set(), None
        self.auto = None                 # tráiler automático (flix_autotrailer.AutoTrailer), se crea en onInit
        # capítulos que Palantir no tiene (flix_series.pending_rows): TMDB por temporada («tmdb/temporada» ->
        # capítulos, None = sin datos), consultas en marcha y para qué (lista, clave, totales válidos) están puestos
        self.pend, self.pend_busy, self.pend_shown = {}, set(), None

    # ---------- ciclo de vida ----------
    def onInit(self):
        # vuelta desde «Títulos de X» (flix_info): el fondo que tapaba el Inicio se quita cuando ya se ve la ficha
        if HOME.getProperty(flix_common.INFO_COVER):
            flix_common.later(0.5, HOME.clearProperty, flix_common.INFO_COVER)   # daemon: no retiene el intérprete (PY-21)
        # también al volver de un vídeo: no se vuelve a cargar nada
        if self.res is None:
            self.res = flix_screen.skin_res()
        wid = xbmcgui.getCurrentWindowId()
        if wid >= 13000:
            self.win_id = wid
        HOME.setProperty("flix_sheet", "1")
        if not self.started:
            self.started = True
            import flix_autotrailer         # tráiler automático: la URL la busca flix_series.find_trailer
            self.auto = flix_autotrailer.AutoTrailer(self, lambda: HOME.getProperty("flix_series_trailer"))
            self.auto.start()               # antes del hilo: si run() falla, leave() ya lo encuentra
            threading.Thread(target=self.run, daemon=True).start()

    def stop_auto(self):
        # getattr: hay pruebas que crean la ventana sin __init__
        auto = getattr(self, "auto", None)
        if auto is not None:
            auto.stop()

    def is_active(self):
        return not self.win_id or xbmc.getCondVisibility("Window.IsActive(%d)" % self.win_id)

    def leave(self):
        if self.closing:
            return
        self.closing, self.stop = True, True
        self.stop_auto()
        self.close()

    # ---------- columna de temporadas ----------
    def seasons_control(self):
        """la lista 7952 cuando la pinta esta ventana (FlixSeries.xml de TV, lista sin <content>); None en la táctil
        (huecos fijos FlixSeasonSlots). Se decide por la skin, no por una propiedad del <onload>: SetProperty sin
        ventana va a la que tiene el foco, y en la Shield al abrir la serie es la rueda (DialogBusy) → la columna se
        quedaba vacía, sin temporadas ni capítulos (Carlos, 7-nov, 1.7.5)"""
        try:
            if xbmc.getSkinDir().endswith(".touch"):
                return None
            return self.getControl(SEASONS_LIST)
        except (AttributeError, RuntimeError):     # pruebas que crean la ventana sin __init__; lista sin control
            return None

    def fill_seasons(self, items):
        """temporadas a la columna: flix_s<i>_* en Window(home) siempre (flix_menu.season_of, season_index) y, en la
        de TV, sus elementos: con las mismas temporadas se cambian etiqueta y propiedades en su sitio (el foco y el
        desplazamiento no se mueven: ✓ nuevo tras el menú o un vídeo); con otro número se rehace conservando la
        posición. Antes eran 40 huecos fijos × 7 propiedades evaluadas por fotograma (revisión 7-nov XML-06)"""
        flix_series.fill_seasons(items)
        ctl = self.seasons_control()
        if ctl is None:
            return
        rows = [flix_series.season_row(it) for it in items[:flix_series.MAX_SEASONS]]
        if rows and len(rows) == ctl.size():
            for i, row in enumerate(rows):
                li = ctl.getListItem(i)
                li.setLabel(row["title"])
                for k in flix_series.SEASON_FIELDS[1:]:
                    li.setProperty(k, row[k])
            return
        pos = -1
        if ctl.size():
            pos = ctl.getSelectedPosition()
            ctl.reset()
        lis = []
        for row in rows:
            li = xbmcgui.ListItem(label=row["title"])
            for k in flix_series.SEASON_FIELDS[1:]:
                li.setProperty(k, row[k])
            lis.append(li)
        ctl.addItems(lis)
        if 0 <= pos < len(lis):
            ctl.selectItem(pos)

    # ---------- bucle de la ficha (hilo): lo de flix_series.watch_seasons sin la ventana Vídeos ----------
    def run(self):
        mon = xbmc.Monitor()
        try:
            if self.load(mon):
                self.start_mode()
                self.loop(mon)
        except Exception:  # noqa: BLE001
            import traceback
            # si el hilo muere con la ficha abierta se queda muda (sin cambio de temporada ni ✓): se registra como
            # error y se sale de ella para que Carlos vuelva a donde estaba
            xbmc.log("[flix_series_sheet] bucle: %s" % traceback.format_exc(), xbmc.LOGERROR)
            self.leave()
        log("fin de la ficha")

    def load(self, mon):
        """espera a que Palantir dé la carpeta de la serie en la lista 7976 (reintenta una vez) y fija el modo"""
        for attempt in (1, 2):
            end = time.time() + LOAD_SECS
            while time.time() < end:
                if self.stop or mon.waitForAbort(0.15):
                    return False
                n = ival(xbmc.getInfoLabel("Container(%d).NumItems" % SERIES_LIST), 0)
                items = [self.peek(i) for i in range(min(n, MODE_PEEK))]
                mode = mode_of(n, items)
                if mode:
                    self.mode = mode
                    self.setProperty("mode", mode)
                    log("serie cargada: %s (%d elementos; 1.º: dbtype=%s content=%s)" % (mode, n, items[0][0],
                                                                                     items[0][1]))
                    return True
            log("Palantir no dio la serie (intento %d)" % attempt)
            if attempt == 1:
                self.reload_series()                    # solo entre intentos: tras el último sería una petición inútil
        xbmcgui.Dialog().notification(HOME.getProperty("flix_series_title") or "Serie",
                                      flix_common.NO_ANSWER_RETRY,
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        self.leave()
        return False

    def peek(self, i):
        """(DBType, content de la ruta, Episode) del elemento i de la carpeta de la serie (mode_of)"""
        g = lambda k: xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).%s" % (SERIES_LIST, i, k))  # noqa: E731
        return g("DBType").lower(), route_content(g("FileNameAndPath")), g("Episode")

    def start_mode(self):
        if self.mode == "one":
            # la propia 7976 es la lista de capítulos (hueco 6): flix_menu y refresh_eps_in_place la encuentran así
            flix_series.apply({"flix_eps_slot": str(SERIES_SLOT), "flix_eps_id": str(SERIES_LIST),
                               "flix_eps_loading": "", "flix_eps_failed": ""})
            self.setProperty("loaded", "1")
            xbmc.executebuiltin("SetFocus(%d)" % SERIES_LIST)
            return
        items = flix_series.window_seasons(SERIES_LIST)
        self.fill_seasons(items)
        # rutas de las temporadas al índice: «Seguir viendo» con la temporada acabada (Slow Horses, 26-oct) lista
        # solo la siguiente en vez de pedir también las temporadas a Palantir (~2 s cada consulta en la Shield)
        tmdb = next((t for t in (flix_series.route_meta(x["path"]).get("tmdb") for x in items) if t), "")
        flix_series.remember_seasons(tmdb, items)
        nxt, done = flix_series.roll_next(HOME.getProperty("flix_series_next"), HOME.getProperty("flix_series_pct"),
                                          items)
        if nxt != HOME.getProperty("flix_series_next"):
            HOME.setProperty("flix_series_next", nxt)   # botón «Seguir viendo · TxEy» y temporada que se abre
        if done:
            HOME.setProperty("flix_series_done", "1")   # vista entera: «Ver de nuevo»
        self.sig, self.sig_at = signature(items), time.time()
        self.setProperty("loaded", "1")
        if not items:
            return
        nxt = HOME.getProperty("flix_series_next")
        if nxt and not HOME.getProperty("flix_series_pct"):
            # cuando llegue la lista de su temporada se mira si Palantir tiene ese capítulo (fix_next)
            self.check = flix_series.season_key(items[flix_series.season_index(items, nxt)]["path"])
        idx = flix_series.season_index(items, nxt or HOME.getProperty("flix_series_upto"))
        end = time.time() + 2                           # los huecos se ven un fotograma después de rellenarlos
        while time.time() < end and xbmc.getInfoLabel("Container(%d).NumItems" % SEASONS_LIST) != str(len(items)):
            xbmc.sleep(50)
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (SEASONS_LIST, idx))
        flix_series.apply(self.slots.step(items[idx]["path"], time.time(), flix_series.eps_count, first=True))
        log("%d temporadas; capítulos de la %d.ª" % (len(items), idx + 1))

    def eps_ids(self):
        return {str(SERIES_LIST)} if self.mode == "one" else flix_series.EPS_IDS

    def reload_series(self):
        """la carpeta de la serie otra vez a Palantir (misma ruta + &reload=): ✓ y «En progreso» de las temporadas"""
        base = re.sub(r"&reload=\d+$", "", HOME.getProperty("flix_eps_c%d" % SERIES_SLOT))
        if base:
            HOME.setProperty("flix_eps_c%d" % SERIES_SLOT, "%s&reload=%d" % (base, int(time.time() * 1000)))

    def after_stop(self, play_from):
        """tras parar un vídeo. NO se pide nada a Palantir: al volver a la ficha Kodi recarga él solo las listas de
        contenido a la vista (la de capítulos y la carpeta 7976: CDirectoryProvider se invalida con el aviso OnStop del
        reproductor). Pedirlas también aquí las duplicaba: 4 peticiones, 2 a la vez, y Palantir lleva mal las
        simultáneas (banco 25-oct). Solo se invalidan las temporadas ocultas (no se procesan mientras lo están; se
        piden al mostrarse). Devuelve (lista, posición, hora) para devolver el foco al capítulo, o None"""
        log("vídeo parado: lanzado desde %s" % (play_from,))
        # la hora de la parada se toma lo primero: un toque posterior debe contar como «tocado» en keep_focus
        t = time.time()
        self.acted, self.stop_at = False, t
        self.fast_until = t + FAST_SECS                 # la carpeta 7976 recargada: firma de temporadas cada segundo
        if self.mode == "seasons" and self.slots.active is not None:
            self.slots.stale_except(self.slots.active)
        if play_from and str(play_from[0]).isdigit() and str(play_from[1]).isdigit():
            return int(play_from[0]), int(play_from[1]) - 1, t
        return None

    def fix_focus(self):
        """en temporadas, el foco no puede quedarse en la lista oculta 7976 (fuera de pantalla): tras una acción de
        temporada flix_menu la enfoca con flix_ctx_auto puesto y su <onfocus> no redirige (banco 25-oct:
        System.CurrentControlId = 7976 tras el menú). Con flix_ctx_auto (menú en marcha) no se toca"""
        if HOME.getProperty("flix_ctx_auto"):
            return
        if self.mode == "seasons" and xbmc.getCondVisibility("Control.HasFocus(%d)" % SERIES_LIST):
            xbmc.executebuiltin("SetFocus(%d)" % SEASONS_LIST)
        elif self.mode in ("seasons", "one") and not xbmc.getInfoLabel("System.CurrentControlId"):
            # tras volver del vídeo Kodi deja la ficha sin control enfocado (banco 25-oct): a la lista principal
            xbmc.executebuiltin("SetFocus(%d)" % (SEASONS_LIST if self.mode == "seasons" else SERIES_LIST))

    def after_menu(self, mon, hint):
        """flix_menu marcó algo (flix_eps_refresh = «lista,posición»): capítulos a la vista al día en su sitio, luego las
        temporadas; el foco vuelve al capítulo si el menú era de un capítulo (si era de una temporada, flix_menu ya lo
        dejó en la columna)"""
        back = flix_series.refresh_eps_in_place(mon, hint)
        if self.mode == "seasons":
            self.reload_series()
            self.fast_until = time.time() + FAST_SECS
        if back and hint.partition(",")[0] == str(back[0]):
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % back)
        HOME.clearProperty("flix_series_hold")         # flix_menu la pone para la ventana Vídeos: aquí no hace falta

    def keep_focus(self, back_play, back_try, now):
        """tras el vídeo, el foco vuelve al capítulo que se estaba viendo mientras nadie toque nada"""
        bcid, bpos, t_stop = back_play
        if not focus_back_due(now - t_stop, getattr(self, "acted", False)):
            return None, back_try
        if xbmc.getCondVisibility("Control.HasFocus(%d)" % bcid) and \
                xbmc.getInfoLabel("Container(%d).CurrentItem" % bcid) == str(bpos + 1):
            return None, back_try                       # ya está
        if now - back_try > 0.5:
            log("tras el vídeo, foco de vuelta al capítulo (lista %d, posición %d)" % (bcid, bpos))
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (bcid, bpos))
            return back_play, now
        return back_play, back_try

    def step_seasons(self, now):
        # ✓ y «En progreso» al día cuando llega la carpeta recargada: cada segundo tras un vídeo o el menú, si no cada 3
        every = SEASONS_FAST if now < getattr(self, "fast_until", 0.0) else SEASONS_EVERY
        if now - self.sig_at > every:
            self.sig_at = now
            items = flix_series.window_seasons(SERIES_LIST)
            if items and signature(items) != self.sig:
                self.sig = signature(items)
                self.fill_seasons(items)
                nxt, done = flix_series.roll_next(HOME.getProperty("flix_series_next"),
                                                  HOME.getProperty("flix_series_pct"), items)
                if nxt != HOME.getProperty("flix_series_next") or done:
                    HOME.setProperty("flix_series_next", nxt)
                    if done:
                        HOME.setProperty("flix_series_done", "1")
        cur = xbmc.getInfoLabel("Container(%d).ListItem.Property(path)" % SEASONS_LIST)
        if cur != HOME.getProperty("flix_season_cur"):
            HOME.setProperty("flix_season_cur", cur)    # temporada resaltada en la columna (FTSeasonRow)
        flix_series.apply(self.slots.step(cur, now, flix_series.eps_count))
        k = self.slots.active
        if k is not None and k in self.slots.ready and (k, self.slots.paths[k]) not in self.noted:
            self.noted.add((k, self.slots.paths[k]))    # «Seguir viendo» de esta temporada ya no pregunta a Palantir
            flix_series.remember_eps(self.slots.paths[k], [e[0] for e in flix_series.episodes_of(EPS_FIRST_ID + k)])
        if self.check and k is not None and k in self.slots.ready and self.slots.paths[k] == self.check:
            self.check = None
            flix_series.apply_fix(flix_series.fix_next(HOME.getProperty("flix_series_next"),
                                                       HOME.getProperty("flix_series_pct"),
                                                       flix_series.episodes_of(EPS_FIRST_ID + k)))

    def loop(self, mon):
        import flix_autotrailer
        import flix_playload
        mark_used = False                               # la pulsación actual ya contó como carga nueva
        mark_at = 0.0                                   # desde cuándo está puesta
        played, play_from, loading_from = False, None, None
        last_focus, last_path, last_pos = "", "", ""
        last_media = last_loading = 0.0
        back_play, back_try = None, 0.0
        while not self.stop and not mon.abortRequested():
            now = time.time()
            mark = HOME.getProperty(flix_playload.USER_PRESS)
            mark_used = mark_used and bool(mark)
            mark_at = (mark_at or now) if mark else 0.0
            if mark and now - mark_at > PRESS_MAX and not xbmc.getCondVisibility("Player.HasMedia"):
                HOME.clearProperty(flix_playload.USER_PRESS)
                HOME.clearProperty(flix_playload.USER_PRESS_PATH)
                mark = ""
            # hay una pulsación en camino o el aviso de reanudar: el foco no se mueve
            if back_play and (mark or HOME.getProperty(flix_playload.PROP) == flix_playload.PENDING or
                              xbmc.getCondVisibility("Window.IsActive(contextmenu)")):
                back_play = None
            if xbmc.getCondVisibility("Player.HasMedia") and not HOME.getProperty(flix_autotrailer.ACTIVE):
                if not played:                          # empieza: de qué capítulo de la lista (para volver a él)
                    play_from, loading_from = loading_from, None
                    log("vídeo en marcha desde %s" % (play_from,))
                played, last_media = True, now          # tras parar: la cuenta atrás de Palantir no es un clic
            elif played and self.is_active():           # de vuelta en la ficha (no antes: sus listas no se leen)
                played = False
                back_play = self.after_stop(play_from)
                play_from = None
            if xbmc.getCondVisibility(flix_series.LOADING):
                # el tráiler automático se prepara (flix_tr_loading): su busydialog no es la carga de un capítulo
                if not HOME.getProperty(flix_autotrailer.LOADING):
                    # el capítulo tocado manda sobre el foco: el del toque (100) si ya llegó; si no, el del dedo apoyado
                    # (107). Con un capítulo sin empezar el 100 llega cuando la carga ya ha terminado (note_press)
                    src = latest_source(getattr(self, "tap", None), getattr(self, "press", None), now)
                    origin = press_origin(mark)             # la pulsación dice cuál es: manda sobre foco y dedo
                    # empieza una carga: consta la pulsación, o un relevo largo (next_origin) si no la hay
                    fresh = bool(mark) and not mark_used
                    if fresh or now - last_loading > 3:
                        new = origin or ((src[0], src[1]) if src else
                                         (last_focus, last_pos) if last_focus in self.eps_ids() and last_pos.isdigit() else None)
                        # una pulsación manda, también sin lista (un botón): no hereda el origen de lo anterior
                        loading_from = new if fresh else next_origin(loading_from, new, now, max(last_loading, last_media))
                        self.tap = self.press = None        # un toque arranca una sola carga
                        mark_used = bool(mark)
                    last_loading = now
                    busy = HOME.getProperty("flix_playload") or HOME.getProperty("flix_working") or \
                        HOME.getProperty("flix_ctx_auto")
                    if flix_series.episode_click(True, origin[0] if origin else src[0] if src else last_focus, bool(busy),
                                                 now - last_media, self.eps_ids(), pressed=bool(mark)):
                        # un capítulo pulsado: Palantir va a reproducir. Solo aquí: la rueda de cargar la lista de
                        # capítulos al abrir la ficha paraba el tráiler recién pedido (Shield, 30-oct)
                        self.stop_auto()
                        flix_playload.begin(HOME.getProperty("flix_open_fanart"),
                                             HOME.getProperty(flix_playload.USER_PRESS_PATH) or (src[2] if src else last_path),
                                             mark=False)
                        log("capítulo pulsado en la lista (%s): pantalla de carga" % mark)
            elif self.is_active() and not xbmc.getCondVisibility(flix_series.COVERED):
                last_focus = xbmc.getInfoLabel("System.CurrentControlId")
                if last_focus in self.eps_ids():
                    last_path = xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % last_focus)
                    last_pos = xbmc.getInfoLabel("Container(%s).CurrentItem" % last_focus)
                hint = HOME.getProperty("flix_eps_refresh")
                if hint:                                # flix_menu marcó algo: ✓ al día, en su sitio
                    HOME.clearProperty("flix_eps_refresh")
                    self.after_menu(mon, hint)
                if back_play:
                    back_play, back_try = self.keep_focus(back_play, back_try, now)
                if not back_play:                       # con back_play, keep_focus es quien manda en el foco
                    self.fix_focus()
                if self.mode == "seasons":
                    self.step_seasons(now)
                self.step_pending()
            # con un vídeo (no el tráiler de la ficha) solo hay que notar la parada: 1 s por vuelta (PY-05)
            if mon.waitForAbort(PLAY_STEP if played else flix_series.WATCH_STEP):
                break

    # ---------- capítulos que Palantir aún no tiene (Carlos, 7-nov) ----------
    def pending_list(self):
        """(lista, ruta de su temporada, ¿ya cargada?) de la lista de capítulos a la vista, o None. En «one» es la
        carpeta 7976; con temporadas, el hueco activo (cargado o cargándose: la consulta a TMDB sale ya, en paralelo
        con Palantir; los pendientes solo se ponen cuando Palantir ha dado los suyos)"""
        if self.mode == "one":
            return SERIES_LIST, HOME.getProperty("flix_eps_c%d" % SERIES_SLOT), True
        k = self.slots.active
        if self.mode != "seasons" or k is None or self.slots.paths[k] is None:
            return None
        return EPS_FIRST_ID + k, HOME.getProperty("flix_eps_c%d" % k), k in self.slots.ready

    def clear_pending(self):
        """sin pendientes a la vista (temporada cambiando o sin datos): sus elementos fijos se ocultan"""
        if self.pend_shown is None:
            return
        self.pend_shown = None
        flix_series.clear_pending_props()

    def step_pending(self):
        """los capítulos que TMDB cuenta y Palantir no da, debajo de los de Palantir en la misma lista (elementos fijos
        FlixPendingItems que se rellenan con flix_pend<i>_*), atenuados y sin reproducir. Primero los de Palantir como
        siempre; TMDB llega en un hilo (fetch_pending, en cuanto se pide la temporada) y se ponen en la vuelta
        siguiente. Se rehacen si cambia la temporada o lo que tiene Palantir (tras un vídeo o un &reload=). Sin red ni
        datos no sale nada"""
        if "pend" not in self.__dict__:                 # pruebas que crean la ventana sin __init__
            self.pend, self.pend_busy, self.pend_shown = {}, set(), None
        meta = self.__dict__.setdefault("pend_meta", {})   # ruta -> (tmdb, temporada): decodificar la ruta una vez, no cada 0,15 s
        src = self.pending_list()
        if not src:
            self.clear_pending()
            return
        cid, path, ready = src
        path = re.sub(r"&reload=\d+$", "", path or "")
        if not path or path == flix_series.EMPTY_EPS or not ready:
            self.clear_pending()
            return
        if path not in meta:
            first = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(0).Season" % cid) if cid == SERIES_LIST else ""
            meta[path] = flix_series.pending_source(path, first)
        tmdb, season = meta[path]
        if not tmdb:
            self.clear_pending()
            return
        key = "%s/%s" % (tmdb, season)
        if key not in self.pend:
            if key not in self.pend_busy:
                self.pend_busy.add(key)
                threading.Thread(target=self.fetch_pending, args=(tmdb, season, key), daemon=True).start()
            return
        # NumItems cuenta también los pendientes que ya se ven (un fotograma después de ponerlos): mientras sea el de
        # Palantir solo o con ellos, nada que hacer (sin leer la lista entera cada 0,15 s)
        n = ival(xbmc.getInfoLabel("Container(%d).NumItems" % cid), 0)
        shown = self.pend_shown
        if n < 1 or (shown and shown[0] == cid and shown[1] == key and n in shown[2]):
            return
        have = [e[0] for e in flix_series.episodes_of(cid)]
        if not have:
            return                                      # aún sin los de Palantir
        rows = flix_series.pending_rows(self.pend[key] or [], have, season, thumb=HOME.getProperty("flix_open_fanart"))
        # los de Palantir = los que hay menos los pendientes que aún se vean (último elemento con flix_pending)
        tail = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Property(%s)" % (cid, n - 1, flix_series.PENDING))
        real = n - (shown[3] if tail and shown and shown[0] == cid else 0)
        flix_series.apply(flix_series.pending_props(rows, cid, real))
        shown_n = min(len(rows), flix_series.PEND_SLOTS)
        self.pend_shown = (cid, key, {real, real + shown_n}, shown_n)
        if rows:
            log("%d capítulos que Palantir no tiene debajo de la lista %d (%s, %d suyos)" % (shown_n, cid, key, real))

    def fetch_pending(self, tmdb, season, key):
        eps = None
        try:
            import flix_newep
            eps = flix_newep.season_episodes(tmdb, season)
        except Exception as e:  # noqa: BLE001
            log("TMDB %s: %s" % (key, type(e).__name__))
        if not self.stop:
            self.pend[key] = eps
        self.pend_busy.discard(key)

    def pending_at(self, cid, idx):
        """la frase del capítulo pendiente en esa posición, o '' si es un capítulo de Palantir"""
        return xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Property(%s)" % (cid, idx, flix_series.PENDING))

    # ---------- toques ----------
    def onClick(self, control_id):
        pass   # botones: su onclick del XML; listas: el clic de Kodi (Palantir reproduce; un pendiente, su aviso)

    def busy(self, now):
        return bool(HOME.getProperty("flix_ctx_auto")) or menu_busy(HOME.getProperty("flix_menu_run"), now)

    def menu_lock(self):
        """cerrojo de «decidir y abrir» el menú. onAction (101) y el Timer de ctx_fallback deciden en hilos
        distintos: sin él los dos podían mirar a la vez, ver el menú sin marcar y abrir dos (revisión final,
        25-oct). Se crea al pedirlo (los tests crean la ventana sin __init__); setdefault es atómico: dos hilos a la
        vez reciben el mismo"""
        lock = self.__dict__.get("_menu_lock")
        return lock if lock is not None else self.__dict__.setdefault("_menu_lock", threading.Lock())

    def onAction(self, action):
        aid = action.getId()
        late = aid in (A_CLICK, A_SELECT) and time.time() - getattr(self, "stop_at", 0.0) < LATE_CLICK
        self.acted = getattr(self, "acted", False) or not late   # hizo algo: el foco ya no se le mueve (keep_focus)
        if aid in A_BACK:
            import flix_playload
            flix_playload.clear_press()      # si no, el selector que llegue arrancaría el vídeo con la ficha cerrada
            self.leave()
            return
        auto = getattr(self, "auto", None)
        if auto is not None:                 # cualquier otra tecla antes del tráiler automático: ya no arranca
            auto.key_in_sheet(aid)
        if aid in (A_CLICK, A_MOVE):
            x, y = action.getAmount1(), action.getAmount2()
            if x > 1 or y > 1:
                (self.note_tap if aid == A_CLICK else self.note_press)(x, y)
            return
        if aid not in (A_LONG, A_CTX):
            return
        x, y = action.getAmount1(), action.getAmount2()
        coords = x > 1 or y > 1
        now = time.time()
        # mirar (menú en marcha, last_long) y marcar de una vez: ctx_fallback decide en otro hilo
        with self.menu_lock():
            if ctx_skip(coords, self.last_long, now, self.busy(now)):
                return
            if not coords:
                # sin dedo: o es el eco que manda Kodi ANTES del 101 (temporada ya seleccionada) o una tecla de menú
                self.ctx_wait = now
                threading.Timer(CTX_WAIT, self.ctx_fallback, args=(now,)).start()
                return
            target = self.target_at(x, y)
            if target is None:
                log("pulsación larga sin temporada ni capítulo debajo (%.0f, %.0f)" % (x, y))
                return
            self.last_long = now
            self.menu_async(*target)

    def note_tap(self, x, y):
        """toque (100): apunta el capítulo tocado; un toque en la columna de temporadas o fuera no se apunta. La
        geometría solo dice QUÉ lista se tocó: Kodi reproduce el elemento que SELECCIONÓ, y en la fila de abajo, a
        medio ver, limita el cursor y no es el que hay bajo el dedo (revisión final, 25-oct). Cuando llega esta
        llamada Kodi ya movió la selección: el capítulo es Container(id).CurrentItem; sin él, el de la geometría"""
        tap = self.episode_at(x, y, prefer_selected=True)
        if tap is not None:
            self.tap = tap

    def note_press(self, x, y):
        """dedo apoyado (107: Kodi lo manda al apoyar el dedo, focusControl de Android; en el banco X11, con cada
        movimiento del ratón). Banco 25-oct: con un capítulo SIN EMPEZAR el clic de Kodi arranca la carga de Palantir
        dentro de su propia acción 100 (diálogo de espera y selector de enlaces, modales) y onAction(100) llega
        cuando la carga ya ha terminado: al empezar no se sabía el capítulo («vídeo en marcha desde None»: ni pantalla
        de carga ni foco de vuelta tras el vídeo). El 107 llega al momento, antes de la carga. Se apunta siempre,
        aunque sea None: manda el último dedo apoyado, y uno en un botón o en la columna borra el anterior. Va por la
        geometría (Kodi aún no ha movido la selección); en la fila cortada de abajo puede no ser el que reproduce
        Kodi, pero solo se usa si el toque no ha llegado"""
        self.press = self.episode_at(x, y)
        if self.press is None:
            HOME.clearProperty("flix_touch_item")
        else:                                # flix_play.resume_focused: con el aviso delante la lista no se lee
            HOME.setProperty("flix_touch_item", "%s|%s|%s|%s" % (self.press[3], self.press[0], self.press[1], self.press[2]))

    def episode_at(self, x, y, prefer_selected=False):
        """(lista, posición, ruta, hora) del capítulo bajo el dedo, o None si no es una lista de capítulos de la
        ficha. La ruta se lee ya: con el diálogo de la carga encima Container(797x) da '' (Kodi la busca en el
        diálogo). prefer_selected (toque): la posición es la seleccionada (Container(id).CurrentItem) si se lee"""
        target = self.target_at(x, y)
        if target is None or str(target[0]) not in self.eps_ids():
            return None
        cid, idx = target
        if prefer_selected:
            cur = ival(xbmc.getInfoLabel("Container(%d).CurrentItem" % cid))
            if cur > 0:
                idx = cur - 1
        path = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, idx))
        return str(cid), str(idx + 1), path, time.time()

    def ctx_fallback(self, stamp):
        """117 sin coordenadas y no llegó el 101 (tecla de menú de un teclado o mando): el elemento enfocado"""
        with self.menu_lock():          # un 101 que llegue a la vez decide después (o antes), nunca a la vez
            if self.stop or self.ctx_wait != stamp or self.last_long >= stamp or self.busy(time.time()):
                return
            target = self.focused_target()
            if target is not None:
                self.last_long = time.time()
                self.menu_async(*target)

    def target_at(self, x, y):
        """(lista, índice) bajo el dedo (coordenadas de pantalla), o None"""
        if self.res is None:             # onAction antes de onInit, o skin_res falló
            return None
        sx, sy = flix_screen.to_skin(x, y, self.res)
        hit = list_at(sx, sy, self.res[0], self.mode)
        if hit is None:
            return None
        cid, rel, h = hit
        if cid == "eps":
            slot = HOME.getProperty("flix_eps_slot")
            if not slot.isdigit() or int(slot) >= flix_series.EPS_SLOTS:
                return None
            cid = EPS_FIRST_ID + int(slot)
        g = lambda k: ival(xbmc.getInfoLabel("Container(%d).%s" % (cid, k)))  # noqa: E731
        idx = index_at(rel, h, g("CurrentItem"), g("Position"), g("NumItems"))
        return None if idx is None else (cid, idx)

    def focused_target(self):
        """(lista, índice) del elemento enfocado si es una temporada o un capítulo de la ficha"""
        cid = xbmc.getInfoLabel("System.CurrentControlId")
        ids = {str(SERIES_LIST)} if self.mode == "one" else \
            {str(SEASONS_LIST)} | {str(EPS_FIRST_ID + k) for k in range(flix_series.EPS_SLOTS)}
        cur = ival(xbmc.getInfoLabel("Container(%s).CurrentItem" % cid))
        return (int(cid), cur - 1) if cid in ids and cur > 0 else None

    def menu_async(self, cid, idx):
        # un capítulo que Palantir no tiene: sin menú (no hay nada que marcar ni reproducir), el mismo aviso que el clic
        phrase = self.pending_at(cid, idx)
        if phrase:
            xbmcgui.Dialog().notification(xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, idx)),
                                          phrase, xbmcgui.NOTIFICATION_INFO, 4000)
            return
        # la marca va ANTES de arrancar el hilo: si fuera dentro, un 101 que llegase justo después de decidir el
        # fallback vería el menú aún sin marcar y abriría un segundo
        self.stop_auto()
        HOME.setProperty("flix_menu_run", "s%f" % time.time())
        threading.Thread(target=self.open_menu, args=(cid, idx), daemon=True).start()

    def open_menu(self, cid, idx):
        """menú KER0N3 del elemento idx de la lista cid. flix_menu.py lo lee de la lista enfocada (focused_episode): se
        enfoca antes. Si Kodi abrió su menú por su cuenta (el elemento ya estaba seleccionado), DialogContextMenu.xml lo
        cierra sin lanzar flix_menu.py con esta ficha abierta (flix_sheet): solo lo lanza esta ventana"""
        if self.stop:                    # ficha cerrada (Atrás) mientras tanto: ni foco ni menú
            HOME.clearProperty("flix_menu_run")
            return
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, idx))
        end = time.time() + FOCUS_WAIT
        while time.time() < end and not (xbmc.getCondVisibility("Control.HasFocus(%d)" % cid) and
                                         xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) == str(idx + 1)):
            xbmc.sleep(30)
        if self.stop:
            HOME.clearProperty("flix_menu_run")
            return
        if not (xbmc.getCondVisibility("Control.HasFocus(%d)" % cid) and
                xbmc.getInfoLabel("Container(%d).CurrentItem" % cid) == str(idx + 1)):
            # flix_menu.py lee el elemento enfocado: sin el pedido abriría el menú de otro capítulo
            log("no llegó al elemento %d de la lista %d: sin menú" % (idx, cid))
            HOME.clearProperty("flix_menu_run")
            return
        log("menú de la lista %d, elemento %d" % (cid, idx))
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_menu.py)")


def open_sheet(folder):
    """abre la ficha de la serie (carpeta listado_temporadaS de Palantir) y espera a que se cierre. flix_series.main()
    ya puso las propiedades de la serie (flix_series_*, flix_open_*)"""
    w = None
    # un flix_eps_refresh que se quedase puesto (de otra ficha o de la ventana Vídeos) haría correr after_menu nada
    # más abrir: más peticiones a Palantir a la vez que la primera carga de la serie
    HOME.clearProperty("flix_eps_refresh")
    try:
        HOME.setProperty("flix_eps_c%d" % SERIES_SLOT, folder)
        w = SeriesSheet("FlixSeries.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", folder=folder)
        w.doModal()
    finally:
        if w is not None:
            w.stop = True
            w.stop_auto()                       # red de seguridad: ningún camino de cierre deja el tráiler sonando
        for k in ("flix_sheet", "flix_eps_c%d" % SERIES_SLOT, "flix_season_cur", "flix_series_hold", "flix_menu_run",
                  "flix_eps_refresh"):
            HOME.clearProperty(k)
        flix_series.clear_pending_props()
        del w
