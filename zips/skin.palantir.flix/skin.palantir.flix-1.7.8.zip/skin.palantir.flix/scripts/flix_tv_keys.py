"""Teclas del reproductor de la TV (auditoría del reproductor 8-nov, paso 5): ↑ y ↓ con el vídeo a pantalla completa
ABREN LOS CONTROLES (y con los controles abiertos siguen moviendo el foco: sección VideoOSD). Por defecto Kodi salta por los capítulos internos del archivo (Shield, Verity: ↓ retrocedió 7
minutos de golpe y ↑ no hizo nada; para la familia, imprevisible). ← → (saltar 10 s) y OK (abrir controles) siguen
como en Kodi.

Lo instala first_run al arrancar: special://profile/keymaps/flix_tv.xml, solo si falta o cambia de versión
(Skin.String(flix_tv_keymap)), y recarga las teclas. No en la táctil (sus gestos: flix_touch_setup.py)."""
import xbmc
import xbmcvfs

KEYMAP_VERSION = "2"
KEYMAP = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Generado por la skin Ker0n3 Media (scripts/flix_tv_keys.py). Se reescribe al cambiar de versión. -->
<keymap>
  <FullscreenVideo>
    <keyboard>
      <up>OSD</up>
      <down>OSD</down>
    </keyboard>
    <remote>
      <up>OSD</up>
      <down>OSD</down>
    </remote>
  </FullscreenVideo>
  <!-- con los controles abiertos, ↑ ↓ mueven el foco como siempre: sin esto Kodi usa las de FullscreenVideo (su
       ventana de reserva) y ↑ cerraba los controles en vez de subir a la barra (Shield, 9-nov) -->
  <VideoOSD>
    <keyboard>
      <up>Up</up>
      <down>Down</down>
    </keyboard>
    <remote>
      <up>Up</up>
      <down>Down</down>
    </remote>
  </VideoOSD>
</keymap>
"""
PATH = "special://profile/keymaps/flix_tv.xml"


def install():
    """True si lo ha escrito ahora (False: ya estaba al día o es la táctil)"""
    if xbmc.getSkinDir().endswith(".touch"):
        return False
    if xbmc.getInfoLabel("Skin.String(flix_tv_keymap)") == KEYMAP_VERSION and xbmcvfs.exists(PATH):
        return False
    folder = "special://profile/keymaps/"
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    with xbmcvfs.File(PATH, "w") as fh:
        if fh.write(KEYMAP) is False:
            raise IOError("no se pudo escribir %s" % PATH)
    xbmc.executebuiltin("Action(reloadkeymaps)")
    xbmc.executebuiltin("Skin.SetString(flix_tv_keymap,%s)" % KEYMAP_VERSION)
    xbmc.log("[flix_tv_keys] teclas del reproductor v%s instaladas" % KEYMAP_VERSION, xbmc.LOGINFO)
    return True
