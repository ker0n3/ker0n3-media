"""Pasar los ajustes de la skin a otro aparato del mismo tipo (TV ↔ TV, móvil ↔ móvil): por la red de casa con un
código (flix_ajustes_red) o con un fichero. Diseño: docs/superpowers/specs/2026-10-30-pasar-ajustes-design.md.

Paquete (JSON): una lista cerrada de ajustes de la skin, el Inicio (home_order.json) y el menú (sections.json) en uso,
y la clave de MDBList solo por la red. Al aplicar se sustituye todo y lo de antes queda en ajustes_anteriores.json
(«Recuperar los ajustes anteriores»).
Uso: RunScript(special://skin/scripts/flix_ajustes.py)"""
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import xbmc  # noqa: E402
import xbmcvfs  # noqa: E402

import flix_ajustes_red as red  # noqa: E402

TIPO, FORMATO = "ker0n3-ajustes", 1
# lista cerrada: lo que no está aquí no viaja nunca (modo ligero, historial, marca del aparato, avisos, cachés…)
# (los resúmenes de Ajustes, flix_quality_summary y flix_rating_summary, no viajan: se calculan al aplicar)
TEXTOS = ("flix_accent", "flix_autoplay", "flix_quality_order", "flix_upnext_secs", "flix_rating_order",
          "flix_rating_src", "flix_autotrailer")
INTERRUPTORES = ("flix_remux", "flix_autoplay_set", "flix_nosheet", "flix_menu_preview")
MDBLIST = "flix_mdblist_key"
QUALITY_SUMMARY, RATING_SUMMARY = "flix_quality_summary", "flix_rating_summary"
BACKUP = "ajustes_anteriores.json"
# lo que se puede pasar a Skin.SetString sin romper el builtin: la coma es otro parámetro; paréntesis y comillas
SAFE = re.compile(r'[^,()"\[\]\r\n]{1,300}')


class AjustesError(Exception):
    """aviso para el usuario (sin punto final)"""


def log(msg):
    xbmc.log("[flix_ajustes] %s" % msg, xbmc.LOGINFO)


def touch():
    return xbmc.getSkinDir().endswith(".touch")


def data_dir():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/" % xbmc.getSkinDir())


def backup_path():
    return os.path.join(data_dir(), BACKUP)


def has_backup():
    return os.path.exists(backup_path())


def device_name():
    return xbmc.getInfoLabel("System.FriendlyName") or "otro aparato"


def home_conf():
    """el Inicio en uso: el guardado; sin guardar, el de una instalación nueva (Aleatoria) o el de fábrica, como
    flix_random_rows.promote_saved y flix_home_conf.normalize"""
    import flix_home_conf as hc
    import flix_home_order as fho
    import flix_random_rows as rr
    conf = fho.load_conf()
    if conf is not None:
        return conf
    if rr.fresh_install(fho.DATA):
        return hc.normalize({"random": {"on": True}, "deleted": list(hc.DEFAULT_DELETED)})
    return hc.normalize(None)


def collect(con_mdblist=False):
    """paquete con los ajustes de este aparato; con_mdblist: solo para el envío por la red"""
    import flix_sections
    skin = xbmc.getSkinDir()
    textos = {}
    for k in TEXTOS:
        v = xbmc.getInfoLabel("Skin.String(%s)" % k)
        if v:
            textos[k] = v
    pkg = {
        "tipo": TIPO, "formato": FORMATO, "skin": skin,
        "version_skin": xbmc.getInfoLabel("System.AddonVersion(%s)" % skin),
        "aparato": device_name(), "fecha": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "textos": textos,
        "interruptores": [k for k in INTERRUPTORES if xbmc.getCondVisibility("Skin.HasSetting(%s)" % k)],
        "inicio": home_conf(),
        "secciones": flix_sections.load_conf(),
    }
    key = xbmc.getInfoLabel("Skin.String(%s)" % MDBLIST)
    if con_mdblist and key and key != "-":
        pkg["mdblist"] = key
    return pkg


def check(pkg):
    """None si el paquete vale para este aparato; si no, el aviso que hay que enseñar"""
    if not isinstance(pkg, dict) or pkg.get("tipo") != TIPO:
        return "Esto no son ajustes de KER0N3 MEDIA"
    try:
        formato = int(pkg.get("formato"))
    except (TypeError, ValueError):
        return "Esto no son ajustes de KER0N3 MEDIA"
    if formato > FORMATO:
        return "Actualiza la skin de este aparato para poder cargar estos ajustes"
    skin = str(pkg.get("skin"))
    if skin != xbmc.getSkinDir():
        if skin.endswith(".touch") and not touch():
            return "Estos ajustes son de la skin del móvil y este aparato usa la de TV"
        if touch() and not skin.endswith(".touch"):
            return "Estos ajustes son de la skin de TV y este aparato usa la del móvil"
        return "Estos ajustes son de otra skin"
    if not (isinstance(pkg.get("textos"), dict) and isinstance(pkg.get("interruptores"), list)
            and isinstance(pkg.get("inicio"), dict) and isinstance(pkg.get("secciones"), dict)):
        return "Los ajustes están incompletos"
    return None


def _set_text(name, value):
    if value and SAFE.fullmatch(value):
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (name, value))
        return
    if value:
        log("%s con caracteres que no valen: se queda el de fábrica" % name)
    xbmc.executebuiltin("Skin.Reset(%s)" % name)


def _summaries(textos, key):
    """(resumen de calidad, resumen de notas) de lo que se acaba de aplicar, con las mismas funciones que los
    editores (flix_quality.summary, flix_ratings.summary); key: la clave de MDBList que quedará puesta ('' = ninguna).
    Sin comas: Skin.SetString corta el valor en la primera"""
    import flix_quality
    import flix_ratings
    vale = {k: v for k, v in textos.items() if isinstance(v, str) and SAFE.fullmatch(v)}    # lo que de verdad se pone
    q_text, q_mode = vale.get("flix_quality_order", ""), vale.get("flix_autoplay", "")
    q_order = flix_quality.parse(q_text) if q_text else flix_quality.legacy_order(q_mode)
    r_text = vale.get("flix_rating_order", "")
    r_order = (flix_ratings.parse_order(r_text) if r_text
               else flix_ratings.legacy_order(vale.get("flix_rating_src", ""), key))
    return (flix_quality.summary(q_order).replace(",", " "), flix_ratings.summary(r_order, key).replace(",", " "))


def _write(pkg):
    """sustituye lo de la lista por lo del paquete (lo que no viene, al de fábrica); la clave de MDBList solo si viene
    (el fichero no la lleva); los resúmenes de Ajustes se recalculan con lo aplicado"""
    import flix_home_order as fho
    import flix_ratings
    import flix_sections
    import flix_sections_conf
    key = pkg.get("mdblist")
    if isinstance(key, str) and (key == "-" or re.fullmatch(flix_ratings.KEY_RE, key)):
        efectiva = "" if key == "-" else key
    else:
        key = None
        # leída ANTES de escribir: los builtins son asíncronos y no se vería la nueva
        efectiva = xbmc.getInfoLabel("Skin.String(%s)" % MDBLIST).strip()
        efectiva = "" if efectiva == "-" else efectiva
    textos = {k: pkg["textos"].get(k) for k in TEXTOS}
    q_summary, r_summary = _summaries(textos, efectiva)
    for k in TEXTOS:
        v = textos[k]
        _set_text(k, v if isinstance(v, str) else "")
    for k in INTERRUPTORES:
        xbmc.executebuiltin("%s(%s)" % ("Skin.SetBool" if k in pkg["interruptores"] else "Skin.Reset", k))
    if key is not None:
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (MDBLIST, key))
    # directos (no por _set_text): «TMDB (sin clave de MDBList)» lleva paréntesis, como en flix_ratings.save_settings
    xbmc.executebuiltin("Skin.SetString(%s,%s)" % (QUALITY_SUMMARY, q_summary))
    xbmc.executebuiltin("Skin.SetString(%s,%s)" % (RATING_SUMMARY, r_summary))
    fho.save_conf(pkg["inicio"])
    flix_sections.save_conf(flix_sections_conf.normalize(pkg["secciones"]))


def _snapshot():
    """lo de este aparato tal cual está para poder volver a ello: como collect(con_mdblist=True) pero anotando siempre
    el estado de la clave de MDBList («-» si no hay), para que deshacer también quite la que llegó por la red"""
    snap = collect(con_mdblist=True)
    snap.setdefault("mdblist", "-")
    return snap


def _swap(pkg, prev, fallo):
    """escribe pkg; si algo falla vuelve a prev y avisa con `fallo`; si tampoco se puede volver, avisa de que se ha
    quedado a medias"""
    try:
        _write(pkg)
        return
    except Exception as e:  # noqa: BLE001
        log("fallo al escribir los ajustes (%s): vuelvo a lo de antes" % e)
    try:
        _write(prev)
    except Exception as e:  # noqa: BLE001
        log("tampoco se pudo volver a lo de antes (%s)" % e)
        raise AjustesError("Algunos ajustes se han quedado a medias: prueba otra vez en un momento")
    raise AjustesError(fallo)


def apply(pkg):
    """aplica un paquete ya comprobado (check); antes guarda lo de este aparato para poder deshacerlo"""
    from flix_common import atomic_write
    prev = _snapshot()
    try:
        atomic_write(backup_path(), dump(prev))
    except OSError as e:
        log("no se pudo guardar la copia de lo de antes (%s)" % e)
        raise AjustesError("No se pudo guardar la copia de los ajustes de este aparato: no se ha cambiado nada")
    _swap(pkg, prev, "No se pudieron cambiar los ajustes: se queda todo como estaba")
    log("ajustes de %s aplicados" % pkg.get("aparato", "?"))


def restore():
    """vuelve a lo de antes del último cambio (ajustes_anteriores.json); no escribe otra copia: se puede repetir"""
    try:
        with open(backup_path(), encoding="utf-8") as fh:
            texto = fh.read()
    except OSError:
        raise AjustesError("No hay ajustes anteriores que recuperar")
    except UnicodeDecodeError:
        raise AjustesError("Esto no son ajustes de KER0N3 MEDIA")
    pkg = parse(texto)
    msg = check(pkg)
    if msg:
        raise AjustesError(msg)
    _swap(pkg, _snapshot(), "No se pudieron recuperar los ajustes anteriores: se queda todo como estaba")
    log("ajustes anteriores recuperados")


def dump(pkg):
    return json.dumps(pkg, ensure_ascii=False, indent=1)


def parse(text):
    try:
        return json.loads(text)
    except ValueError:
        raise AjustesError("Esto no son ajustes de KER0N3 MEDIA")


def file_name(now=None):
    """ker0n3-ajustes-tv-30-10-2026-1542.json (-movil- en la táctil); con la hora, para no repetirse en el día"""
    return "ker0n3-ajustes-%s-%s.json" % ("movil" if touch() else "tv",
                                          time.strftime("%d-%m-%Y-%H%M", time.localtime(now)))


def free_path(folder, now=None):
    """ruta nueva en la carpeta: Android no deja a Kodi sobrescribir ni borrar en Descargas un fichero de una sesión
    anterior (como flix_export_log), así que si el nombre existe se añade -2, -3…"""
    base = folder.rstrip("/\\") + "/"
    name = file_name(now)
    path, n = base + name, 1
    while xbmcvfs.exists(path):
        n += 1
        path = base + name[:-len(".json")] + "-%d.json" % n
    return path


def refresh_quietly():
    """refresh() tras aplicar: si falla, ya está cambiado todo, así que se anota y se sigue con el aviso de éxito"""
    try:
        refresh()
    except Exception as e:  # noqa: BLE001
        log("fallo al refrescar tras aplicar (%r): los ajustes ya están cambiados" % e)


def refresh():
    """lo mismo que el editor al guardar: menú, Inicio y otro sorteo de Aleatoria. Sin ReloadSkin: el Inicio de la TV
    es una ventana Python y se reabre solo (fi_reload); el color cambia solo (Skin.String)"""
    import flix_home_order
    import flix_random_rows as rr
    import flix_sections
    flix_sections.apply()
    flix_home_order.apply_saved()
    path = rr.state_path()
    st = rr.load_state(path)
    st.update(next=[], ready=False)
    rr.save_state(path, st)
    rr.request_prepare()


# ---------- menú (Ajustes → OTROS → «Pasar ajustes a otro aparato») ----------
TITLE = "Pasar ajustes a otro aparato"
HELP = ("Lleva tus ajustes a otro aparato del mismo tipo: el color, la reproducción, las notas, el Inicio y el menú. "
        "Directo por la wifi de casa con un código de 4 cifras, o con un fichero que sirve también de copia. El modo "
        "ligero y el historial se quedan en cada aparato")
OPCIONES = (("enviar", "Enviar a otro aparato"), ("recibir", "Recibir de otro aparato"),
            ("guardar", "Guardar en un fichero"), ("cargar", "Cargar de un fichero"),
            ("recuperar", "Recuperar los ajustes anteriores"))


def options():
    """las opciones del menú; «Recuperar» solo si hay copia de antes"""
    return [o for o in OPCIONES if o[0] != "recuperar" or has_backup()]


def _dialog():
    import xbmcgui
    return xbmcgui.Dialog()


def _ok(text):
    _dialog().ok(TITLE, text)


def _confirm_and_apply(pkg):
    """comprueba, pregunta y aplica; True si se aplicó"""
    msg = check(pkg)
    if msg:
        raise AjustesError(msg)
    if not _dialog().yesno(TITLE, "¿Cambiar los ajustes de este aparato por los de %s?" % (pkg.get("aparato") or
                                                                                          "otro aparato"),
                           nolabel="No", yeslabel="Sí"):
        return False
    apply(pkg)
    refresh_quietly()
    _ok("Ajustes cambiados. Puedes deshacerlo en Recuperar los ajustes anteriores")
    return True


def send():
    import xbmcgui
    import flix_phonekb
    ip = flix_phonekb.lan_ip()
    if not ip:
        raise AjustesError("Este aparato no está conectado a la red")
    s = red.Sender(collect(con_mdblist=True), name=device_name()).start()
    dlg = None
    try:
        d = xbmcgui.DialogProgress()
        d.create(TITLE, "Código [B]%s[/B]  ·  %s  ·  %s[CR]En el otro aparato: Ajustes → %s → Recibir de otro aparato"
                 % (s.code, device_name(), ip, TITLE))
        dlg = d                                 # solo se cierra si llegó a crearse
        mon = xbmc.Monitor()
        while not (dlg.iscanceled() or s.served.is_set() or s.expired() or not s.active()
                   or mon.abortRequested()):
            dlg.update(int(100 * s.remaining() / red.LIFETIME))
            mon.waitForAbort(0.5)
    finally:
        if dlg is not None:
            dlg.close()
        s.stop()
    if s.served.is_set():
        log("ajustes enviados a %s" % (s.served_to or "?"))
        _ok("Ajustes enviados a %s" % (s.served_to or "otro aparato"))
    elif s.expired():
        _ok("Nadie ha recogido los ajustes: vuelve a darle a Enviar cuando el otro aparato esté listo")
    elif s.fails >= red.MAX_FAILS:
        _ok("Demasiados códigos incorrectos: vuelve a darle a Enviar")


def receive():
    import flix_phonekb
    import flix_picker
    code = _dialog().numeric(0, "Código que sale en el otro aparato")
    if not code:
        return
    if not re.fullmatch(r"\d{4}", code):
        raise AjustesError("El código son 4 cifras: míralo en el otro aparato")
    ip = flix_phonekb.lan_ip()
    flix_picker.busy(True)
    try:
        # la búsqueda no lleva el código (revisión de la tarea 2): contestan todos los que están enviando
        found = red.discover(red.broadcast_targets(ip))[:20]
    finally:
        flix_picker.busy(False)
    pkg = None
    if found:
        k = 0
        if len(found) > 1:                      # varios enviando: se elige por el nombre antes de mandar el código
            k = flix_picker.pick("¿De qué aparato?", [name or host for host, _port, name in found])
            if k < 0:
                return
        host, port, _name = found[k]
        flix_picker.busy(True)
        try:
            pkg = red.fetch(host, port, code, me=device_name())
        finally:
            flix_picker.busy(False)
    if pkg is None:
        prefix = ip.rsplit(".", 1)[0] + "." if ip else ""
        host = _dialog().input("No lo encuentro: escribe la dirección que sale en el otro aparato", defaultt=prefix)
        if not host:
            return
        flix_picker.busy(True)
        try:
            pkg = red.fetch_any_port(host.strip(), code, me=device_name())
        finally:
            flix_picker.busy(False)
    _confirm_and_apply(pkg)


SAVE_HERE, SAVE_OTHER = "Guardar en Descargas", "Elegir otra carpeta…"


def _pick(labels):
    import flix_picker
    return flix_picker.pick(TITLE, labels)


def download_dir():
    for d in ("/storage/emulated/0/Download/", "/sdcard/Download/"):
        if os.path.isdir(d):
            return d
    return xbmcvfs.translatePath("special://home/")


def _cancelled(path, default=None):
    """Dialog.browse devuelve lo que se le dio por defecto (no "") al cancelar; una carpeta tampoco es un fichero"""
    return not path or path == default or path.endswith(("/", "\\"))


def save_file():
    i = _pick([SAVE_HERE, SAVE_OTHER])
    if i < 0:
        return
    if i == 0:
        folder = download_dir()
    else:
        # sin defaultt: así vacío = cancelado (con él, cancelar devuelve el de por defecto y no se distingue)
        folder = _dialog().browse(3, "¿Dónde guardo los ajustes?", "files")
        if not folder:
            return
    path = free_path(folder)
    pkg = collect(con_mdblist=False)
    pkg.pop("mdblist", None)                    # la clave nunca va en un fichero
    f = xbmcvfs.File(path, "w")
    try:
        ok = f.write(dump(pkg).encode("utf-8"))
    finally:
        f.close()
    if not ok:
        raise AjustesError("No se pudo guardar en esa carpeta: prueba con otra")
    log("ajustes guardados en %s" % path)
    _ok("Ajustes guardados en %s" % path)


def load_file():
    default = download_dir()
    path = _dialog().browse(1, "Elige el fichero de ajustes", "files", ".json", defaultt=default)
    if _cancelled(path, default):
        return
    f = xbmcvfs.File(path)
    try:
        text = f.read()
    finally:
        f.close()
    if not text:
        raise AjustesError("No se pudo leer ese fichero")
    _confirm_and_apply(parse(text))


def recover():
    if not _dialog().yesno(TITLE, "¿Volver a los ajustes que tenía este aparato antes del último cambio?",
                           nolabel="No", yeslabel="Sí"):
        return
    restore()
    refresh_quietly()
    _ok("Ajustes anteriores recuperados")


def menu():
    import flix_picker
    opts = options()
    i = flix_picker.pick(TITLE, [label for _key, label in opts], HELP)
    if i < 0:
        return
    try:
        {"enviar": send, "recibir": receive, "guardar": save_file, "cargar": load_file,
         "recuperar": recover}[opts[i][0]]()
    except (AjustesError, red.RedError) as e:
        log("aviso: %s" % e)
        _ok(str(e))
    except Exception as e:  # noqa: BLE001  (lo imprevisto, como aviso y no como error de Kodi)
        log("fallo: %r" % e)
        _ok("Algo ha fallado. Prueba otra vez en un momento")


if __name__ == "__main__":
    menu()
