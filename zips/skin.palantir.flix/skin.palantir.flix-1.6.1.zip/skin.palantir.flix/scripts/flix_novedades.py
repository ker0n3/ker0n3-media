"""Aviso de novedades al actualizar la skin (31-oct): una vez por versión y aparato, con el Inicio a la vista, sin
vídeo ni diálogos encima. Solo en la TV (en la táctil no sale: build_touch copia este script, pero main() se para).
Como el aviso de Telegram (flix_telegram.py): registro en addon_data, guardado ANTES de enseñarlo, y nunca los dos a
la vez (cerrojo flix_common.popup_take). Ventana FlixNovedades.xml (tools/gen_novedades_dialog.py), que lleva escritos
los textos de la versión más nueva de NEWS: una entrada nueva se añade al publicar esa versión, y luego se regenera la
ventana. Lo lanza first_run.py (una vez por sesión, antes que el de Telegram)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import time

import xbmc
import xbmcgui
import xbmcvfs

# versión → (título, [(apartado, texto), …]). gen_novedades_dialog.py lo lee de aquí (sin importar el script)
NEWS = {
    # 1.6: lo de la 1.5.100 (quien la vio, lo vuelve a ver; Carlos, 31-oct) y lo nuevo
    "1.6.0": ("Novedades de la 1.6", [
        ("Tráiler automático en la ficha",
         "Al abrir una película o una serie, su tráiler empieza solo arriba a la derecha y puedes seguir leyendo la "
         "ficha. Actívalo en Ajustes → Reproducción → «Tráiler automático en la ficha»."),
        ("Vista previa en el menú lateral",
         "Al pararte en Películas, Series… del menú lateral ves sus primeras filas sin entrar, y dentro de las "
         "secciones tienes el mismo menú que en el Inicio. Actívala en Ajustes → Personalizar menú e Inicio (primera "
         "fila)."),
        ("Búsqueda y filas al azar",
         "En la búsqueda, mantén pulsado el botón central sobre un resultado para marcarlo como visto, elegir "
         "resolución y más, como en las filas. Y las filas al azar del Inicio cambian cada vez, aunque abras Kodi "
         "solo un momento."),
    ]),
    "1.5.100": ("Novedades de la 1.5.100", [
        ("Tráiler automático en la ficha",
         "Al abrir una película o una serie, su tráiler empieza solo arriba a la derecha y puedes seguir leyendo la "
         "ficha. Actívalo en Ajustes → Reproducción → «Tráiler automático en la ficha»."),
        ("Vista previa en el menú lateral",
         "Al pararte en Películas, Series… del menú lateral ves sus primeras filas sin entrar, y dentro de las "
         "secciones tienes el mismo menú que en el Inicio. Actívala en Ajustes → Personalizar menú e Inicio (primera "
         "fila)."),
    ]),
}
START_DELAY = 4         # s tras arrancar: uno antes que el de Telegram (5), para que salga primero
WAIT_IDLE = 600         # s como mucho esperando el Inicio libre (y sin el de Telegram); si no, en el próximo arranque
STATE = "special://profile/addon_data/%s/novedades.json"
OK = 10                 # botón «Aceptar»
HOME = xbmcgui.Window(10000)


def log(msg):
    xbmc.log("[flix_novedades] %s" % msg, xbmc.LOGINFO)


def version():
    """versión de la skin que corre"""
    return xbmc.getInfoLabel("System.AddonVersion(%s)" % xbmc.getSkinDir())


def vkey(v):
    return tuple(int(p) if p.isdigit() else 0 for p in v.split("."))


def newest():
    """la versión cuyas novedades lleva escritas FlixNovedades.xml"""
    return max(NEWS, key=vkey)


def state_path():
    return xbmcvfs.translatePath(STATE % xbmc.getSkinDir())


def load(path):
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def seen(state):
    s = state.get("seen") if state else None
    return [v for v in s if isinstance(v, str)] if isinstance(s, list) else []


def save(path, state, ver):
    from flix_common import atomic_write
    done = seen(state)
    if ver not in done:
        done.append(ver)
    try:
        atomic_write(path, json.dumps({"seen": done}))
    except OSError as e:
        log("no guardo %s: %s" % (path, e))


def due(state, ver):
    """¿toca? Si la versión que corre tiene novedades (la de la ventana) y no se han visto aquí. Sin registro
    (instalación nueva, fichero roto): sí"""
    return bool(ver) and ver in NEWS and ver == newest() and ver not in seen(state)


def idle():
    """Inicio de la TV (FlixInicio.xml) a la vista y nada encima: ni vídeo ni diálogos"""
    return bool(xbmc.getCondVisibility("Window.IsVisible(FlixInicio.xml)")) and not xbmc.getCondVisibility(
        "Player.HasMedia | System.HasActiveModalDialog")


class NovedadesDialog(xbmcgui.WindowXMLDialog):
    def onClick(self, cid):
        self.close()

    def onAction(self, action):
        import flix_common
        if action.getId() in flix_common.A_BACK:       # Atrás como en las demás ventanas (TV-28)
            self.close()


def main():
    if xbmc.getSkinDir().endswith(".touch"):          # solo en la TV
        return
    ver = version()
    path = state_path()
    state = load(path)
    if not due(state, ver):
        return
    import flix_common
    # al cerrarse Kodi se para en menos de 1 s (System.OnQuit, flix_common.quit_monitor; APA-03)
    mon = flix_common.quit_monitor()
    if flix_common.wait_quit(mon, START_DELAY):
        return
    end = time.time() + WAIT_IDLE
    while not (idle() and flix_common.popup_take(HOME, "novedades")):
        if time.time() > end or flix_common.wait_quit(mon, 2):
            log("no lo enseño: el Inicio no ha estado libre")
            return
    try:
        save(path, state, ver)      # antes de enseñarlo: si Kodi se cierra con él abierto no vuelve a salir
        w = NovedadesDialog("FlixNovedades.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
        log("novedades de la %s" % ver)
        w.doModal()
        del w
    finally:
        flix_common.popup_free(HOME, "novedades")


if __name__ == "__main__":
    main()
