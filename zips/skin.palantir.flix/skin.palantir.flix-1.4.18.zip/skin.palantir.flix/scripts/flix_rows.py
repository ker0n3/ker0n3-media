"""Secciones de Palantir desplegadas en filas (compartido TV / táctil).

section_rows(var) lee el menú de una sección (rutas fijas p3Peliculas… de Includes_Palantir3.xml) y lo
convierte en filas:
  kind "list" = listado de títulos (action listado_peliculaS / listado_serieS) -> fila de carátulas
  kind "coll" = submenú (sagas, especiales, calidad, géneros, alfabético…) -> fila de tarjetas; al abrir
               una tarjeta se ve su rejilla de carátulas (vista 51)
Las cabeceras ("Películas de Dibujos:") agrupan; "Buscar por título" se omite (ya está el buscador).
fetch() cachea en disco 30 min: cada llamada a Palantir consulta además la API de GitHub (60/h por IP).
"""
import base64
import json
import math
import os
import re
import time
import urllib.parse

import xbmc
import xbmcvfs

CACHE_TTL = 1800
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache.json" % xbmc.getSkinDir())
COLOR_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE)[^\]]*\]")
GENERIC_ART = "plugin.video.palantir3/resources/media"   # icono genérico de Palantir (calidad, letras, "Más…")
SECTION_VARS = {"Películas": "p3Peliculas", "Series": "p3Series", "Anime": "p3Anime",
                "Dibujos": "p3Dibujos", "Documentales": "p3Documentales"}
PROPS = ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file", "plot", "duration"]


def log(msg):
    xbmc.log("[flix_rows] %s" % msg, xbmc.LOGINFO)


def clean(s):
    return COLOR_RE.sub("", s or "").strip()


def decode_route(path):
    """JSON (como texto) de una ruta de Palantir: base64 invertido y rotado ceil(len/4)."""
    blob = path.split("?", 1)[-1].split("&", 1)[0]
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    return base64.b64decode(b64).decode("utf-8", "replace")


def action_of(path):
    try:
        m = re.search(r'"action": \'?([^\',}]+)', decode_route(path))
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


def skin_var(name):
    try:
        with xbmcvfs.File("special://skin/xml/Includes_Palantir3.xml") as fh:
            text = fh.read()
    except Exception:  # noqa: BLE001
        return ""
    m = re.search(r'<variable name="%s">(.*?)</variable>' % re.escape(name), text, re.S)
    vals = re.findall(r"<value[^>]*>(.*?)</value>", m.group(1), re.S) if m else []
    return vals[-1].strip().replace("&amp;", "&") if vals else ""


_cache = None


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cache_save():
    try:
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump(_cache, fh)
    except OSError as e:
        log("no guardo caché: %s" % e)


def fetch(path, force=False, keep_headers=False):
    """(items, de_caché). Clave sin &reload=. Un fallo de Palantir (0 items) no machaca una caché buena."""
    key = re.sub(r"&reload=[^&]*", "", path) + ("#h" if keep_headers else "")
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and time.time() - hit[0] < CACHE_TTL:
        return _progress(hit[1]), True
    raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": path, "media": "video", "properties": PROPS}}))
    files = ((json.loads(raw).get("result") or {}).get("files")) or []
    files = [f for f in files if f.get("label") and (keep_headers or not clean(f["label"]).endswith(":"))]
    if files or not hit:
        cache[key] = [time.time(), files]
        _cache_save()
    return _progress(files or (hit[1] if hit else [])), False


def _progress(files):
    """progreso real de Palantir (watched.db) en vez del que trae la caché (flix_progress.py)"""
    try:
        import flix_progress
        flix_progress.fix_files(files)
    except Exception as e:  # noqa: BLE001
        log("progreso: %s" % e)
    return files


def is_generic(f):
    a = f.get("art") or {}
    art = urllib.parse.unquote(a.get("poster") or a.get("thumb") or "")   # llega como image://special%3a%2f%2f…
    return not art or GENERIC_ART in art


def is_more(f):
    """último elemento "Más…/More…" de un listado (página siguiente)"""
    return f.get("filetype") == "directory" and re.match(r"^(m[aá]s|more|siguiente|next)\b", clean(f.get("label")).lower()) is not None


def is_search(label):
    l = label.lower().replace("í", "i")
    return "titulo" in l or "title" in l or l.startswith("buscar") or l.startswith("search")


def section_rows(var):
    """[{label, path, kind}] de la sección (en el orden del menú de Palantir)."""
    path = skin_var(var)
    if not path.startswith("plugin://"):
        return []
    menu, _ = fetch(path, keep_headers=True)
    out, group = [], ""
    groups = set()
    for f in menu:
        lab = clean(f.get("label"))
        if not lab:
            continue
        if lab.endswith(":"):
            group = "Series" if "serie" in lab.lower() else "Películas"
            groups.add(group)
            continue
        if is_search(lab) or f.get("filetype") != "directory":
            continue
        act = action_of(f.get("file", ""))
        kind = "list" if act in ("listado_peliculaS", "listado_serieS") else "coll"
        out.append({"label": lab, "path": f["file"], "kind": kind, "group": group})
    # etiquetas repetidas (p. ej. "Por orden alfabético" en pelis y en series) llevan el grupo detrás
    names = [r["label"] for r in out]
    for r in out:
        if names.count(r["label"]) > 1 and r["group"]:
            r["label"] = "%s · %s" % (r["label"], r["group"])
    log("sección %s: %d filas (%s)" % (var, len(out), ", ".join("%s[%s]" % (r["label"], r["kind"]) for r in out)))
    return out
