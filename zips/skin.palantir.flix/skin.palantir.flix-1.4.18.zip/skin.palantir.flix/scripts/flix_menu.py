"""Menú KER0N3 MEDIA de un elemento de Palantir (mantener OK / botón ☰): película, capítulo, temporada o serie.

Solo lo que sirve y llega a Trakt: vista / no vista, quitar progreso (película y capítulo), temporada vista / no vista,
serie vista / no vista y dejar de seguir. Esas acciones son de Palantir y solo existen dentro de su submenú
("Menú Palantir 3..." -> context.py, que recibe el elemento como sys.listitem y no expone ninguna ruta reutilizable).
Por eso este script, tras elegir, abre por detrás el menú contextual de Kodi (invisible: Window(home).Property
(flix_ctx_auto) pone DialogContextMenu.xml transparente y sin interceptar), entra en "Menú Palantir 3..." y pulsa la
opción de Palantir. Las de primer nivel con el mismo nombre son de Kodi y NO llegan a Palantir ni a Trakt: solo se
pulsa dentro del submenú (se reconoce por "Información sobre Palantir 3" / "Information about Palantir 3").
Textos en el idioma del aparato: los de Kodi con xbmc.getLocalizedString y los de Palantir con su propio addon
(Fire TV tiene Kodi en inglés).
Verificado 17-oct-2026 (Shield + resincronizar con Trakt; Fire TV): restablecer y marcar/desmarcar vista llegan a Trakt.
Uso: RunScript(special://skin/scripts/flix_menu.py[,<ruta>,<carátula>])  (lo lanza DialogContextMenu.xml)
"""
import ast
import os
import sqlite3
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_play  # noqa: E402
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
SUBMENU_MARK = "Palantir 3"   # botón de primer nivel que abre el submenú de Palantir ("Menú Palantir 3...")
SUBMENU_SIGN = ("información sobre palantir", "information about palantir")   # solo dentro del submenú
WATCHED_DB = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db")


def _kodi(i):
    try:
        return xbmc.getLocalizedString(i).strip().lower()
    except Exception:  # noqa: BLE001
        return ""


def _pal(i):
    try:
        return xbmcaddon.Addon("plugin.video.palantir3").getLocalizedString(i).strip().lower()
    except Exception:  # noqa: BLE001
        return ""


# id -> (texto en el menú KER0N3, icono, textos de la opción de Palantir (exactos, sin mayúsculas), aviso al terminar)
ACTIONS = {
    10: ("Marcar como vista", "check", {_kodi(16103), "marcar como visto", "mark as watched"}, "Marcada como vista"),
    11: ("Marcar como no vista", "x", {_kodi(16104), "marcar como no visto", "mark as unwatched"},
         "Marcada como no vista"),
    12: ("Quitar progreso", "rewind", {_kodi(38209), "restablecer posición de reanudación", "reset resume position"},
         "Progreso quitado"),
    20: ("Marcar serie como vista", "check", {_pal(30080), "marcar serie como vista", "mark show as watched"},
         "Serie marcada como vista"),
    21: ("Marcar serie como no vista", "x", {_pal(30079), "marcar serie como no vista", "mark show as unwatched"},
         "Serie marcada como no vista"),
    22: ("Dejar de seguir la serie", "delete", {_pal(30091), "no seguir esta serie...", "do not follow this show..."},
         None),
    30: ("Marcar temporada como vista", "check", {_pal(30082), "marcar temporada como vista",
                                                    "mark season as watched"}, "Temporada marcada como vista"),
    31: ("Marcar temporada como no vista", "x", {_pal(30081), "marcar temporada como no vista",
                                                   "mark season as unwatched"}, "Temporada marcada como no vista"),
}


def log(msg):
    xbmc.log("[flix_menu] %s" % msg, xbmc.LOGINFO)
    HOME.setProperty("flix_menu_log", msg[:500])     # legible por JSON-RPC (en Fire OS no se puede leer kodi.log)


class Menu(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.opts = kwargs.get("opts", [])
        self.choice = None

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        lst = self.getControl(9100)
        lst.reset()
        for act in self.opts:
            li = xbmcgui.ListItem(ACTIONS[act][0])
            li.setProperty("icon", ACTIONS[act][1])
            li.setProperty("act", str(act))
            lst.addItem(li)
        self.setFocusId(9100)

    def onClick(self, cid):
        if cid == 9100:
            item = self.getControl(9100).getSelectedItem()
            if item:
                self.choice = int(item.getProperty("act"))
                self.close()


def ctx_buttons():
    """{id: etiqueta} del menú contextual abierto"""
    out = {}
    for i in range(1000, 1040):
        lab = xbmc.getInfoLabel("Control.GetLabel(%d)" % i)
        if lab:
            out[i] = lab
    return out


def wait_for(pred, timeout):
    mon = xbmc.Monitor()
    end = time.time() + timeout
    while time.time() < end and not mon.abortRequested():
        if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            r = pred(ctx_buttons())
            if r:
                return r
        xbmc.sleep(150)
    return None


def press(cid):
    xbmc.executebuiltin("SetFocus(%d)" % cid)
    xbmc.sleep(120)
    xbmc.executebuiltin("Action(Select)")


def run_palantir(words):
    """abre el menú de Kodi, entra en el de Palantir y pulsa la opción cuyo texto contiene todas las palabras"""
    HOME.setProperty("flix_ctx_auto", "1")
    try:
        xbmc.executebuiltin("Action(ContextMenu)")
        sub = wait_for(lambda b: next((i for i, l in b.items() if SUBMENU_MARK in l), None), 6)
        if not sub:
            log("no aparece 'Menú Palantir 3'")
            return False
        press(sub)

        def target(b):
            if not any(sig in l.lower() for l in b.values() for sig in SUBMENU_SIGN):
                return None              # aún es el menú de Kodi (mismas etiquetas, pero no llegan a Trakt)
            return next((i for i, l in b.items() if l.strip().lower() in words), -1)

        cid = wait_for(target, 12)
        if not cid or cid < 0:
            log("Palantir no ofrece %s; opciones: %s" % (sorted(w for w in words if w), list(ctx_buttons().values())))
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        press(cid)
        log("pulsado en Palantir: %s" % xbmc.getInfoLabel("Control.GetLabel(%d)" % cid))
        return True
    finally:
        xbmc.sleep(400)
        HOME.clearProperty("flix_ctx_auto")


# ---------- estado real (watched.db de Palantir) ----------
def db_query(sql, args=()):
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            return db.execute(sql, args).fetchall()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def state_of(kind, info):
    """(firma comparable, props del menú, opciones)"""
    tmdb = str(info.get("tmdb") or "")
    if kind in ("movie", "episode"):
        if kind == "movie":
            rows = db_query("SELECT playcount, progress, runtime FROM movies_watched WHERE tmdb_id=?", (tmdb,))
        else:
            rows = db_query("SELECT playcount, progress, runtime FROM episodes_watched WHERE tmdb_id=? AND season=? "
                            "AND episode=?", (tmdb, info.get("season"), info.get("episode")))
        row = rows[0] if rows else None
        watched = int(row[0] or 0) if row else 0
        total = float(row[2] or 0) if row else 0.0
        total = total or float(info.get("duration") or 0)
        position = total * float(row[1] or 0) / 100 if row else 0.0
        started = position > 30 and (not total or position < total - 60)
        if started:
            sub = "Empezada  ·  %s de %s" % (flix_play.fmt(position), flix_play.fmt(total)) if total else "Empezada"
        else:
            sub = "Vista" if watched else "Sin empezar"
        if kind == "episode":
            sub = "T%s · E%s  ·  %s" % (info.get("season"), info.get("episode"), sub)
        opts = [11] if watched and not started else [10]
        if started:
            opts.append(12)
        state = "started" if started else "watched" if watched else "new"
        props = {"fm_state": state, "fm_sub": sub,
                 "fm_pct": str(int(100 * position / total)) if started and total else "0"}
        return (watched, round(position)), props, opts
    if kind == "season":
        rows = db_query("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND season=? AND playcount>0",
                        (tmdb, info.get("season")))
        seen = rows[0][0] if rows else 0
        total = int(info.get("totalEpisodes") or 0)
        done = bool(total) and seen >= total
        props = {"fm_state": "watched" if done else "new",
                 "fm_sub": "Temporada %s  ·  %d de %d capítulos vistos" % (info.get("season"), seen, total)}
        return (seen,), props, [31] if done else [30]
    # serie
    rows = db_query("SELECT completa, num_total_episodios FROM shows_watched WHERE tmdb_id=?", (tmdb,))
    seen_rows = db_query("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND playcount>0", (tmdb,))
    seen = seen_rows[0][0] if seen_rows else 0
    done = bool(rows and rows[0][0])
    total = int(rows[0][1] or 0) if rows else 0
    sub = "%d de %d capítulos vistos" % (seen, total) if total else ("%d capítulos vistos" % seen if seen else "Sin empezar")
    props = {"fm_state": "watched" if done else "new", "fm_sub": sub}
    return (done, seen), props, ([21] if done else [20]) + [22]


def kind_of(info):
    return {"movies": "movie", "episodes": "episode", "seasons": "season", "tvshows": "show"}.get(info.get("content"))


def wait_applied(kind, info, before, timeout=30):
    """Palantir guarda el cambio unos segundos después (arranca su submenú y habla con Trakt; en Fire TV más):
    se espera a verlo en watched.db y entonces se ponen al día las filas / la lista (sin reiniciar Kodi)"""
    mon, start = xbmc.Monitor(), time.time()
    while time.time() - start < timeout and not mon.abortRequested():
        if state_of(kind, info)[0] != before:
            log("aplicado en %.1f s" % (time.time() - start))
            break
        xbmc.sleep(500)
    else:
        log("no veo el cambio en watched.db tras %d s" % timeout)
    if xbmcgui.getCurrentWindowId() == 10000:
        import flix_progress
        for wait in (0, 6):                # Seguir viendo la regenera Palantir; reintento de recarga a los 6 s
            xbmc.sleep(wait * 1000)
            try:
                flix_progress.one_pass()
            except Exception as e:  # noqa: BLE001
                log("filas: %s" % e)
    else:
        xbmc.executebuiltin("Container.Refresh")     # temporadas / capítulos: Palantir vuelve a dar la lista


def native_menus():
    """menú contextual de siempre UNA vez (series, o lo que no es una película de Palantir). Si en él se entra en
    "Menú Palantir 3..." el permiso dura también para ese submenú; al cerrarse, el siguiente vuelve a ser el KER0N3.
    (Antes duraba hasta 5 s con todo cerrado: reabrir enseguida volvía a dar el de Kodi una y otra vez.)"""
    HOME.setProperty("flix_ctx_skip", "1")
    mon = xbmc.Monitor()

    def wait_open(timeout):
        end = time.time() + timeout
        while time.time() < end and not mon.abortRequested():
            if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
                return True
            xbmc.sleep(100)
        return False

    def wait_closed():
        """espera a que se cierre; devuelve la última opción con foco"""
        last = ""
        while not mon.abortRequested() and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            cid = xbmc.getInfoLabel("System.CurrentControlId")
            if cid:
                last = xbmc.getInfoLabel("Control.GetLabel(%s)" % cid) or last
            xbmc.sleep(100)
        return last

    try:
        xbmc.executebuiltin("Action(ContextMenu)")
        if not wait_open(4):
            return
        last = wait_closed()
        if SUBMENU_MARK in last and wait_open(10):     # entró en el submenú de Palantir
            wait_closed()
    finally:
        HOME.clearProperty("flix_ctx_skip")


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    art = sys.argv[2] if len(sys.argv) > 2 else ""
    label = sys.argv[3] if len(sys.argv) > 3 else ""
    if not path:
        # Inicio: el menú contextual no ve la carátula con foco -> la de la fila que lo tiene (flix_row)
        row = HOME.getProperty("flix_row")
        if row:
            c = "Container(%s).ListItem." % row
            path = xbmc.getInfoLabel(c + "FileNameAndPath")
            art = xbmc.getInfoLabel(c + "Art(poster)") or xbmc.getInfoLabel(c + "Art(tvshow.poster)")
            label = xbmc.getInfoLabel(c + "Label")
    info = {}
    if path.startswith("plugin://plugin.video.palantir3/"):
        try:
            info = ast.literal_eval(flix_rows.decode_route(path))
        except Exception:  # noqa: BLE001
            info = {}
    kind = kind_of(info) if isinstance(info, dict) else None
    if not kind:
        native_menus()      # menús de Palantir, carpetas...: el de siempre
        return
    before, props, opts = state_of(kind, info)
    if kind == "episode":
        name = flix_play.COLOR_RE.sub("", label).strip()
        if name:
            props["fm_sub"] = "%s  ·  %s" % (name, props["fm_sub"].split("  ·  ", 1)[-1])
    if kind == "episode":
        title = info.get("tvshowtitle") or ""
    elif kind == "season":
        title = info.get("tvshowtitle") or ""
    else:
        title = info.get("title") or info.get("tvshowtitle") or flix_play.COLOR_RE.sub("", info.get("label") or "")
    # capítulos: la ruta no trae carátula -> la de la serie (la pone flix_series.py al abrirla)
    poster = flix_play._img(info.get("poster")) or art or HOME.getProperty("flix_poster")
    props.update({"fm_title": title.strip(), "fm_poster": poster,
                  "fm_fanart": flix_play._img(info.get("fanart"))})
    w = Menu("FlixMenu.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props, opts=opts)
    w.doModal()
    choice = w.choice
    del w
    if choice not in ACTIONS:
        return
    xbmc.sleep(250)                          # que el foco vuelva a la carátula antes de abrir menús
    ok = run_palantir(ACTIONS[choice][2])
    done = ACTIONS[choice][3]
    if ok and done:
        wait_applied(kind, info, before)
    if done or not ok:
        xbmcgui.Dialog().notification("KER0N3 MEDIA", done if ok else "Aún no está lista: espera unos segundos y repite",
                                      xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)


if __name__ == "__main__":
    main()
