"""Orden y visibilidad de las filas del Inicio (versión TV y táctil).

RunScript(special://skin/scripts/flix_home_order.py,edit)   -> editor (ventana FlixHomeOrder.xml)
RunScript(special://skin/scripts/flix_home_order.py,check)  -> al arrancar: reaplica el orden si una
                                                               actualización del skin trajo Home.xml de serie
Preferencias en special://profile/addon_data/<skin>/home_order.json: {"order": [ids], "hidden": [ids]}
(ids = list_id de cada fila: 5105 Top 10 películas, 5106 Top 10 series…; los mismos en la táctil).

TV: las filas son fijas en xml/Home.xml (entre FLIX_ROWS_BEGIN y FLIX_ROWS_END); este script reescribe ese
trozo en el orden elegido (con su navegación arriba/abajo) y recarga el skin. La copia de serie del trozo se
guarda en addon_data (home_rows_default.xml) para poder volver a mostrar filas ocultas o restablecer.
Táctil: flix_home.py lee el mismo json y ordena sus filas al cargar.
"""
import json
import os
import re
import sys

import xbmc
import xbmcgui
import xbmcvfs

HOME = xbmcgui.Window(10000)
SKIN_ID = xbmc.getSkinDir()
TOUCH = SKIN_ID.endswith(".touch")
SKIN = xbmcvfs.translatePath("special://skin/")
DATA = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
CONF = os.path.join(DATA, "home_order.json")
DEFAULT_ROWS = os.path.join(DATA, "home_rows_default.xml")
HOME_XML = os.path.join(SKIN, "xml", "Home.xml")
BEGIN, END = "<!-- FLIX_ROWS_BEGIN", "<!-- FLIX_ROWS_END -->"
SIG_RE = re.compile(r"<!-- FLIX_ORDER_SIG ([^ ]*) -->\n?")
BLOCK_RE = re.compile(r'[ \t]*<include content="FlixRow">.*?</include>\n', re.S)


def log(msg):
    xbmc.log("[flix_home_order] %s" % msg, xbmc.LOGINFO)


def load_conf():
    try:
        with open(CONF, encoding="utf-8") as fh:
            c = json.load(fh)
        return {"order": [int(i) for i in c.get("order", [])], "hidden": [int(i) for i in c.get("hidden", [])]}
    except (OSError, ValueError):
        return None


def save_conf(conf):
    os.makedirs(DATA, exist_ok=True)
    with open(CONF, "w", encoding="utf-8") as fh:
        json.dump(conf, fh)


def signature(conf):
    return "o" + "-".join(map(str, conf["order"])) + "_h" + "-".join(map(str, sorted(conf["hidden"])))


def ordered(rows, conf):
    """rows = [(id, label, …)] de serie -> en el orden guardado; las filas nuevas (no en conf) al final."""
    if not conf:
        return list(rows)
    pos = {i: k for k, i in enumerate(conf["order"])}
    return sorted(rows, key=lambda r: pos.get(r[0], 1000 + rows.index(r)))


# ---------- TV: Home.xml ----------
def _region(text):
    a = text.index("-->", text.index(BEGIN)) + 4    # tras el comentario de la marca (ocupa 2 líneas)
    b = text.index(END)
    b = text.rindex("\n", 0, b) + 1
    return a, b


def tv_default_blocks():
    """[(id, label, bloque)] en el orden de serie."""
    with open(HOME_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    region = text[a:b]
    if not SIG_RE.search(region) or not os.path.exists(DEFAULT_ROWS):
        # Home.xml de serie (instalación o actualización): su trozo de filas es el nuevo "de serie"
        os.makedirs(DATA, exist_ok=True)
        with open(DEFAULT_ROWS, "w", encoding="utf-8") as fh:
            fh.write(SIG_RE.sub("", region))
    with open(DEFAULT_ROWS, encoding="utf-8") as fh:
        region = fh.read()
    out = []
    for blk in BLOCK_RE.findall(region):
        i = int(re.search(r'name="list_id" value="(\d+)"', blk).group(1))
        lab = re.search(r'name="label" value="([^"]*)"', blk).group(1)
        out.append((i, lab, blk))
    return out


def tv_apply(conf):
    rows = [r for r in ordered(tv_default_blocks(), conf) if r[0] not in conf["hidden"]]
    if not rows:
        return False
    ids = [r[0] for r in rows]
    blocks = []
    for k, (i, _, blk) in enumerate(rows):
        up = ids[k - 1] if k else i
        down = ids[k + 1] if k + 1 < len(ids) else i
        blk = re.sub(r'name="up" value="[^"]*"', 'name="up" value="%d"' % up, blk)
        blk = re.sub(r'name="down" value="[^"]*"', 'name="down" value="%d"' % down, blk)
        blocks.append(blk)
    with open(HOME_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    new = text[:a] + "\t\t\t\t<!-- FLIX_ORDER_SIG %s -->\n" % signature(conf) + "".join(blocks) + text[b:]
    with open(HOME_XML, "w", encoding="utf-8") as fh:
        fh.write(new)
    log("Home.xml reescrito: %s" % ids)
    return True


def tv_current_sig():
    with open(HOME_XML, encoding="utf-8") as fh:
        m = SIG_RE.search(fh.read())
    return m.group(1) if m else None


# ---------- táctil ----------
def touch_default_rows():
    with open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8") as fh:
        return [(r["id"], r["label"], r) for r in json.load(fh)]


def default_rows():
    return touch_default_rows() if TOUCH else tv_default_blocks()


# ---------- arranque ----------
def check():
    conf = load_conf()
    if TOUCH or not conf:
        return
    try:
        if tv_current_sig() != signature(conf) and tv_apply(conf):
            xbmc.executebuiltin("ReloadSkin()")
    except Exception as e:  # noqa: BLE001
        log("check: %s" % e)


# ---------- editor ----------
LIST, B_UP, B_DOWN, B_TOGGLE, B_SAVE, B_RESET, B_CANCEL = 100, 201, 202, 203, 204, 205, 206
A_UP, A_DOWN, A_SELECT, A_CONTEXT = 3, 4, 7, (101, 117)


class OrderWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        conf = load_conf() or {"order": [], "hidden": []}
        self.rows = [[i, lab, i not in conf["hidden"]] for i, lab, _ in ordered(default_rows(), conf)]
        self.picked = False
        self.pick_pos = -1
        self.saved = False

    def onInit(self):
        self.lst = self.getControl(LIST)
        self.refill(0)
        self.setFocusId(LIST)

    def refill(self, sel):
        self.lst.reset()
        for i, lab, vis in self.rows:
            li = xbmcgui.ListItem(lab)
            li.setProperty("hidden", "" if vis else "1")
            self.lst.addItem(li)
        self.lst.selectItem(max(0, min(sel, len(self.rows) - 1)))
        self.mark()

    def mark(self):
        self.setProperty("picked", "1" if self.picked else "")

    def sel(self):
        return self.lst.getSelectedPosition()

    def move(self, step):
        k = self.sel()
        j = k + step
        if 0 <= k < len(self.rows) and 0 <= j < len(self.rows):
            self.rows[k], self.rows[j] = self.rows[j], self.rows[k]
            self.refill(j)

    def toggle(self):
        k = self.sel()
        if 0 <= k < len(self.rows):
            self.rows[k][2] = not self.rows[k][2]
            if not any(r[2] for r in self.rows):
                self.rows[k][2] = True          # al menos una fila visible
            self.refill(k)

    def onAction(self, action):
        aid = action.getId()
        if self.getFocusId() == LIST and self.picked and aid in (A_UP, A_DOWN):
            # Kodi ya ha movido la selección de la lista: la fila cogida va a la nueva posición
            new, old = self.sel(), self.pick_pos
            if 0 <= old < len(self.rows) and new != old:
                self.rows.insert(new, self.rows.pop(old))
                self.pick_pos = new
                self.refill(new)
            return
        if self.getFocusId() == LIST and aid in A_CONTEXT:
            self.toggle()                                # mantener OK: mostrar / ocultar
            return
        if aid in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            if self.picked:
                self.picked = False
                self.mark()
                return
            self.close()
            return
        super().onAction(action)

    def onClick(self, cid):
        if cid == LIST:
            if TOUCH:
                return                                   # táctil: tocar = seleccionar; botones al lado
            self.picked = not self.picked                # OK: coger / soltar la fila
            self.pick_pos = self.sel()
            self.mark()
        elif cid == B_UP:
            self.move(-1)
        elif cid == B_DOWN:
            self.move(1)
        elif cid == B_TOGGLE:
            self.toggle()
        elif cid == B_RESET:
            self.rows = [[i, lab, True] for i, lab, _ in default_rows()]
            self.refill(0)
        elif cid == B_SAVE:
            conf = {"order": [r[0] for r in self.rows], "hidden": [r[0] for r in self.rows if not r[2]]}
            save_conf(conf)
            self.saved = True
            self.close()
        elif cid == B_CANCEL:
            self.close()


def edit():
    win = OrderWindow("FlixHomeOrder.xml", SKIN, "Default", "1080i")
    win.doModal()
    saved = win.saved
    del win
    if not saved:
        return
    if TOUCH:
        HOME.setProperty("fh_reorder", "1")             # flix_home.py lo aplica al momento (lo mira cada segundo)
        xbmcgui.Dialog().notification("Inicio", "Orden aplicado", xbmcgui.NOTIFICATION_INFO, 2500)
        return
    conf = load_conf()
    if conf and tv_apply(conf):
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ReloadSkin()")


if __name__ == "__main__":
    (check if len(sys.argv) > 1 and sys.argv[1] == "check" else edit)()
