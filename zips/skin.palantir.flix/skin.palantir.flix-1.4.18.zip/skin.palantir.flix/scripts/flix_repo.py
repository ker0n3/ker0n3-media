"""Actualizaciones automáticas: al arrancar, deja el aparato enganchado al repositorio Ker0n3 Media.

1. Si falta el addon repository.ker0n3media, lo instala desde la copia que trae el skin
   (resources/repository.ker0n3media) y lo activa.
2. Kodi NO actualiza solo lo que se instaló desde un zip (origen vacío), con ningún ajuste: si el skin no tiene
   origen, se le pone el del repositorio en Addons33.db (efecto al siguiente arranque).
Se ejecuta desde Startup.xml; no hace nada si ya está todo bien.
"""
import glob
import json
import os
import shutil
import sqlite3

import xbmc
import xbmcvfs

REPO = "repository.ker0n3media"
SKIN_ID = xbmc.getSkinDir()


def log(msg):
    xbmc.log("[flix_repo] %s" % msg, xbmc.LOGINFO)


def rpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def ensure_repo():
    dst = xbmcvfs.translatePath("special://home/addons/%s" % REPO)
    src = xbmcvfs.translatePath("special://skin/resources/%s" % REPO)
    if os.path.isdir(dst) or not os.path.isdir(src):
        return False
    shutil.copytree(src, dst)
    xbmc.executebuiltin("UpdateLocalAddons")
    for _ in range(20):
        xbmc.sleep(500)
        r = rpc("Addons.SetAddonEnabled", {"addonid": REPO, "enabled": True})
        if r.get("result") == "OK":
            break
    log("repositorio instalado y activado")
    return True


def ensure_origin():
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath("special://database/"), "Addons*.db")))
    if not dbs:
        return
    con = sqlite3.connect(dbs[-1], timeout=5)
    try:
        cur = con.execute("SELECT origin FROM installed WHERE addonID=?", (SKIN_ID,)).fetchone()
        if cur is not None and not cur[0]:
            con.execute("UPDATE installed SET origin=? WHERE addonID=?", (REPO, SKIN_ID))
            con.commit()
            log("%s enganchado al repositorio (antes: instalado desde zip)" % SKIN_ID)
    finally:
        con.close()


try:
    ensure_repo()
    ensure_origin()
except Exception as e:  # noqa: BLE001
    log("error: %s" % e)
