"""Sección de Palantir desplegada en filas (versión TV, ventana FlixSection.xml).

Uso: RunScript(special://skin/scripts/flix_section.py,<variable p3…>,<título>)
Se carga SOLO al entrar: las filas se piden a Palantir una a una (Palantir atiende de una en una, ~4 s cada
una) y van apareciendo; con caché de 30 min (flix_rows.fetch) volver a entrar es instantáneo.
  fila de listado  -> carátulas (película = reproducir, serie = temporadas vía flix_series.py)
  fila de submenú  -> tarjetas (sagas, calidad, letras…): al abrir una, su rejilla de carátulas
  último "Más…" de un listado -> tarjeta "Ver más" que abre la página siguiente en rejilla
"""
import os
import sys
import threading

import xbmc
import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_rows  # noqa: E402
from flix_search import to_listitem  # noqa: E402

HOME = xbmcgui.Window(10000)
FIRST, NROWS = 5401, 16
ROW_LIMIT = 40
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)


def log(msg):
    xbmc.log("[flix_section] %s" % msg, xbmc.LOGINFO)


def make_item(f, row):
    li = to_listitem(f)
    if flix_rows.is_more(f):
        li.setLabel("Ver más")
        li.setProperty("card", "text")
        li.setProperty("open", "grid")
    elif row["kind"] == "coll":
        li.setProperty("card", "text" if flix_rows.is_generic(f) else "band")
        li.setProperty("open", "grid")
    elif f.get("filetype") == "directory":
        li.setProperty("open", "series")
    else:
        li.setProperty("open", "play")
    return li


class SectionWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.var = kwargs.get("var")
        self.title = kwargs.get("title")
        self.stop = False
        self.started = False
        self.rows = {}           # id de lista -> fila

    def onInit(self):
        self.setProperty("fs_title", self.title)
        if not self.started:
            self.started = True
            threading.Thread(target=self.load, daemon=True).start()

    def load(self):
        self.setProperty("fs_status", "cargando…")
        rows = flix_rows.section_rows(self.var)
        slot = 0
        for row in rows:
            if self.stop or slot >= NROWS:
                break
            try:
                files, cached = flix_rows.fetch(row["path"])
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row["label"], e))
                continue
            files = files[:ROW_LIMIT] + [f for f in files[ROW_LIMIT:] if flix_rows.is_more(f)][:1]
            log("fila %s [%s]: %d%s" % (row["label"], row["kind"], len(files), " (caché)" if cached else ""))
            if not files or self.stop:
                continue
            slot += 1
            lid = FIRST + slot - 1
            self.rows[lid] = row
            self.setProperty("fs_row%d" % slot, row["label"])
            self.getControl(lid).addItems([make_item(f, row) for f in files])
            if slot == 1:
                self.setFocusId(lid)
        self.setProperty("fs_status", "")

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.stop = True
            self.close()
            return
        super().onAction(action)

    def onClick(self, control_id):
        if control_id not in self.rows:
            return
        item = self.getControl(control_id).getSelectedItem()
        if not item:
            return
        path, how = item.getPath(), item.getProperty("open")
        HOME.setProperty("flix_title", item.getProperty("P3Titulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.title, item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def main():
    var = sys.argv[1] if len(sys.argv) > 1 else "p3Peliculas"
    title = sys.argv[2] if len(sys.argv) > 2 else "Películas"
    import xbmcvfs
    win = SectionWindow("FlixSection.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", var=var, title=title)
    win.doModal()
    win.stop = True
    del win


if __name__ == "__main__":
    main()
