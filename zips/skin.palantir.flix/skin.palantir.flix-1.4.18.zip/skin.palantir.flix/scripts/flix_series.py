# -*- coding: utf-8 -*-
"""Abrir una serie de Palantir en su pantalla de temporadas (en vez de "reproducir siguiente capítulo").

RunScript(special://skin/scripts/flix_series.py, <ruta plugin:// del item>)

La ruta de un item de serie lleva action 'play_mis_serieS' (Palantir: reproduce el siguiente capítulo).
Con action 'listado_temporadaS' y el mismo JSON, Palantir devuelve las temporadas en ~2 s.
Se guarda la ruta original en Window(home).Property(flix_series_play) para el botón "Continuar".
"""
import base64
import math
import re
import sqlite3
import sys
import time
import xbmc
import xbmcgui
import xbmcvfs

HOME = xbmcgui.Window(10000)
PLUGIN_ROOT = "plugin://plugin.video.palantir3/"


def decode_route(url):
    blob = url.split("?", 1)[-1].split("&", 1)[0]
    k = math.ceil(len(blob) / 4)
    rb = blob[k:] + blob[:k]
    b64 = rb[::-1]
    b64 += "=" * (-len(b64) % 4)
    return base64.b64decode(b64).decode("utf-8", "replace")


def encode_route(text):
    b64 = base64.b64encode(text.encode()).decode().rstrip("=")
    rb = b64[::-1]
    n = len(rb)
    k = math.ceil(n / 4)
    return PLUGIN_ROOT + "?" + rb[n - k:] + rb[:n - k]


def next_episode(tmdb_id):
    """('T1 E41', pct) según watched.db de Palantir: episodio a medias (progress>0) o último visto + 1. None si no empezada."""
    if not tmdb_id:
        return None
    db = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db")
    try:
        con = sqlite3.connect(db, timeout=3)
        rows = con.execute("SELECT season, episode, playcount, progress, lastPlayed FROM episodes_watched WHERE tmdb_id=? ORDER BY lastPlayed DESC", (tmdb_id,)).fetchall()
        con.close()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] watched.db: %s" % e, xbmc.LOGINFO)
        return None
    if not rows:
        return None
    s, e, playcount, progress, _ = rows[0]
    if progress and progress > 0 and not playcount:
        return ("T%d E%d" % (s, e), int(progress))
    return ("T%d E%d" % (s, e + 1), 0)


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    if not path.startswith(PLUGIN_ROOT):
        xbmc.log("[flix_series] ruta inválida: %r" % path, xbmc.LOGINFO)
        return
    try:
        j = decode_route(path)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] no decodifico: %s" % e, xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    if "'play_mis_serieS'" in j:
        play, seasons = path, encode_route(j.replace("'play_mis_serieS'", "'listado_temporadaS'"))
    elif "'listado_temporadaS'" in j:
        play, seasons = encode_route(j.replace("'listado_temporadaS'", "'play_mis_serieS'")), path
    else:
        xbmc.log("[flix_series] ruta sin acción de serie conocida; abro tal cual", xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    m = re.search(r'"tvshowtitle": \'([^\']*)\'', j)
    tm = re.search(r'"tmdb": \'?(\d+)', j)
    nxt = next_episode(int(tm.group(1)) if tm else None)
    HOME.setProperty("flix_series_next", nxt[0] if nxt else "")
    HOME.setProperty("flix_series_pct", str(nxt[1]) if nxt and nxt[1] else "")
    HOME.setProperty("flix_series_play", play)
    HOME.setProperty("flix_series_folder", seasons)
    HOME.setProperty("flix_series_title", m.group(1) if m else "")
    title = m.group(1) if m else "?"
    HOME.setProperty("flix_section", title)   # cabecera de la ventana Vídeos (si no, sale la última sección: "Anime")
    xbmc.log("[flix_series] abro temporadas de %s" % title, xbmc.LOGINFO)
    open_checked(seasons, title)


def loaded_ok(path):
    n = xbmc.getInfoLabel("Container.NumItems")
    return xbmc.getInfoLabel("Container.FolderPath") == path and n.isdigit() and int(n) > 0


def wait_loaded(path, timeout=90):
    """True si la ventana Vídeos acaba mostrando 'path'. False si Palantir falla: entonces Kodi deja a la vista la
    ÚLTIMA carpeta que tuvo esa ventana (p. ej. un "Especial Halloween" de antes) -> hay que detectarlo."""
    t0 = time.time()
    idle_since = None
    while time.time() - t0 < timeout:
        busy = xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Container.IsUpdating")
        if loaded_ok(path) and not busy:
            xbmc.sleep(600)                         # al fallar, Kodi pone un instante la ruta pedida y vuelve atrás
            if loaded_ok(path):
                return True
            continue
        if xbmc.getCondVisibility("Window.IsActive(videos)") and not busy and time.time() - t0 > 2:
            idle_since = idle_since or time.time()
            if time.time() - idle_since > 3:        # ventana quieta 3 s con otra carpeta = falló la carga
                return False
        else:
            idle_since = None
        if not xbmc.getCondVisibility("Window.IsActive(videos)") and time.time() - t0 > 5:
            return True                             # el usuario se fue: nada que vigilar
        xbmc.sleep(200)
    return False


def open_checked(seasons, title, tries=2):
    """Abre las temporadas tapando la carpeta vieja (MyVideoNav: flix_opening) y reintenta una vez si Palantir
    falla (p. ej. ocupado sincronizando Trakt)."""
    HOME.setProperty("flix_opening", "1")
    try:
        for attempt in range(1, tries + 1):
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % seasons)
            if wait_loaded(seasons):
                return
            xbmc.log("[flix_series] Palantir no dio las temporadas de %s (intento %d)" % (title, attempt), xbmc.LOGINFO)
            if xbmc.getCondVisibility("Window.IsActive(videos)"):
                xbmc.executebuiltin("Action(Back)")     # fuera la carpeta vieja
                xbmc.sleep(800)
        xbmcgui.Dialog().notification(title, "Palantir no responde ahora mismo. Prueba otra vez en un momento.",
                                      xbmcgui.NOTIFICATION_INFO, 5000)
    finally:
        HOME.clearProperty("flix_opening")


if __name__ == "__main__":
    main()
