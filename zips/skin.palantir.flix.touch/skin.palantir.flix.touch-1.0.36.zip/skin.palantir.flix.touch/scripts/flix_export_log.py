"""Copia el registro de Kodi a Descargas (para diagnosticar sin ADB/Wi-Fi).

En Android, Kodi guarda el log en su carpeta privada (Android/data/…), que otras apps no pueden leer.
Android sí deja a una app crear sus propios ficheros en Download/, así que se copia ahí:
  /storage/emulated/0/Download/kodi-flix-AAAAMMDD-HHMMSS.log      (sesión actual)
  /storage/emulated/0/Download/kodi-flix-AAAAMMDD-HHMMSS.old.log  (sesión anterior)
"""
import os
import shutil
import time

import xbmc
import xbmcgui
import xbmcvfs

DEST_DIRS = ["/storage/emulated/0/Download", "/sdcard/Download"]


def main():
    src = xbmcvfs.translatePath("special://logpath")
    dest = next((d for d in DEST_DIRS if os.path.isdir(d)), None)
    if not dest:
        xbmcgui.Dialog().ok("Ker0n3 Flix", "No encuentro la carpeta Descargas.")
        return
    done = []
    stamp = time.strftime("%Y%m%d-%H%M%S")
    # nombre nuevo cada vez: Android no deja a Kodi sobrescribir/borrar en Download un fichero de una
    # sesión anterior (pasó el 16-oct: el log seguía siendo el viejo)
    for name, out in (("kodi.log", "kodi-flix-%s.log" % stamp), ("kodi.old.log", "kodi-flix-%s.old.log" % stamp)):
        p = os.path.join(src, name)
        if os.path.exists(p):
            try:
                target = os.path.join(dest, out)
                shutil.copyfile(p, target)
                done.append(out)
            except OSError as e:
                xbmc.log("[flix_export_log] %s: %s" % (name, e), xbmc.LOGWARNING)
    if done:
        xbmcgui.Dialog().ok("Ker0n3 Flix", "Registro copiado a Descargas:[CR]%s" % done[0])
    else:
        xbmcgui.Dialog().ok("Ker0n3 Flix", "No se pudo copiar el registro a %s." % dest)


if __name__ == "__main__":
    main()
