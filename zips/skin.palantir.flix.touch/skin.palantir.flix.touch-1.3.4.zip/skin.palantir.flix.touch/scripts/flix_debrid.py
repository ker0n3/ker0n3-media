"""onload de DialogConfirm: si el diálogo es el progreso de AllDebrid/Real-Debrid, pone
Window(home).Property(flix_debrid)=true y el skin lo oculta y enseña la rueda de carga (DialogConfirm, FlixHideP3Debrid).
Hace falta un script: en las condiciones del skin Control.GetLabel(9) del propio diálogo no funciona (siempre falso),
aunque desde Python sí se lee. La propiedad la borra el onunload de DialogConfirm.

EXCEPCIÓN: el aviso de VINCULAR la cuenta («Register at Alldebrid, Enter 'https://alldebrid.com/pin/' … enter the
pin XXXX before 9 minutes…», primera reproducción tras instalar Palantir) se enseña SIEMPRE: pone flix_debrid_pin
y ni la rueda ni el autoplay lo tapan."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re

PIN_RE = re.compile(r"debrid\.com/pin|\bpin\b", re.I)


def is_debrid(heading, text):
    return "debrid" in ("%s %s" % (heading, text)).lower()


def is_pin(heading, text):
    """Aviso de vincular la cuenta (código PIN): hay que verlo para escribir el código en la web."""
    return bool(PIN_RE.search("%s %s" % (heading, text)))


def hidden_progress(pin, debrid, resolving, playload):
    """¿progreso sin pintar? Entonces OK no debe caer en su Cancelar (DialogConfirm, control 19); el PIN siempre se ve"""
    return not pin and bool(debrid or resolving or playload)


def main():
    """Vigila el diálogo MIENTRAS esté abierto: Palantir puede cambiar el texto (conectando… → PIN) y en la primera
    apertura de la sesión el diálogo aún no cuenta como activo al lanzar el onload (por eso sin condición)."""
    import time
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    opened = pin = debrid = moved = False
    start = time.time()
    while time.time() - start < 900:                # el PIN caduca a los 10 min
        if not xbmc.getCondVisibility("Window.IsActive(progressdialog)"):
            if opened or time.time() - start > 1.5:  # cerrado, o no era un progreso (sí/no, aviso…)
                break
            xbmc.sleep(50)
            continue
        opened = True
        heading, text = xbmc.getInfoLabel("Control.GetLabel(1)"), xbmc.getInfoLabel("Control.GetLabel(9)")
        if not pin and is_pin(heading, text):
            pin = True
            home.setProperty("flix_debrid_pin", "true")
            xbmc.log("[flix_debrid] aviso de vincular AllDebrid: se muestra", xbmc.LOGINFO)
            xbmc.executebuiltin("SetFocus(10)")     # visible y con su Cancelar a mano, aunque antes estuviera oculto
        elif not debrid and not pin and is_debrid(heading, text):
            debrid = True
            home.setProperty("flix_debrid", "true")
        if not moved and hidden_progress(pin, debrid, home.getProperty("flix_resolving") == "true",
                                         home.getProperty("flix_playload")):
            moved = True
            xbmc.executebuiltin("SetFocus(19)")
        xbmc.sleep(100)
    if pin:
        # cancelado o caducado: si Palantir reabre el selector, flix_autoplay.py no prueba otro enlace (sería otro PIN)
        home.setProperty("flix_pin_closed", str(int(time.time())))


if __name__ == "__main__":
    main()
