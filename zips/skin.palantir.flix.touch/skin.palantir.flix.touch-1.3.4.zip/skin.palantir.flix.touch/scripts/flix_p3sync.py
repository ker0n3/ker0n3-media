"""Sincronización de Palantir con Trakt al arrancar, sin frenar el Inicio.

Palantir no tiene servicio: lo que se marca en OTRO aparato (vista, progreso, dejar de seguir) solo baja de Trakt
cuando se abre SU MENÚ RAÍZ (plugin://plugin.video.palantir3/), que la skin original enseñaba en el Inicio. Nuestro
Inicio va directo a las filas y nunca lo abre: la Shield llevaba días sin traer nada de Trakt (Carlos, 20-oct:
Obsession vista en la Shield y no en el móvil, serie dejada de seguir que seguía). Probado en la Shield (20-oct):
listar la raíz trae lo marcado en el móvil en ~10 s; `RunScript(plugin.video.palantir3,None,&update=1)` no trae nada.
Y SOLO la 1.ª vez de cada sesión de Kodi (medido 20-oct en Shield y Fire TV: 2.ª raíz, raíz en pantalla, marcar
vista / no vista... nada vuelve a bajar de Trakt hasta reiniciar Kodi; la skin original tampoco lo pide más): por
eso se hace una sola vez, al arrancar (antes repetía cada 30 min y al acabar un vídeo sin traer nada).

Ahora se lista la raíz (sin enseñarla) DELAY s después del arranque y, cuando Palantir termina de escribir watched.db,
se ponen al día las filas: ✓ y progreso de películas (flix_progress.py) y, si cambiaron series seguidas o
capítulos vistos, la lista «Series en seguimiento» de la caché de Palantir se borra y se recarga esa fila.
Antes de listarla se preparan las pausas (prepare_pauses) para que las pelis/capítulos a medias queden iguales que
en Trakt: Palantir por sí solo nunca borra lo quitado del progreso en otro aparato.
Lo llama first_run.py (una vez por sesión)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import sqlite3
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath(flix_common.P3DATA_REL)
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
SEEN_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/p3sync_seen.json" % xbmc.getSkinDir())
ROOT = "plugin://plugin.video.palantir3/"
DELAY = 20          # s tras el arranque: el Inicio ya está pintado
WATCH = 120         # s como mucho esperando a que Palantir escriba (tarda ~10 s)
STEP = 5
PAUSE_TABLES = {"movies": "movies_watched", "episodes": "episodes_watched"}
BACKUP = WATCHED_DB + ".flixbak"   # foto antes de rehacer las pausas: la leen los demás mientras dura la sincronización
PAUSE_KEYS = {"movies_watched": ("tmdb_id",), "episodes_watched": ("tmdb_id", "season", "episode")}
_SAVED = {}                         # filas quitadas por prepare_pauses: se devuelven si Palantir no las rellena


def log(msg):
    xbmc.log("[flix_p3sync] %s" % msg, xbmc.LOGINFO)


def file_sig():
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def shows_sig():
    """series seguidas (no ocultas) + capítulos vistos: si cambian, «Series en seguimiento» está vieja"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            shows = sorted(r[0] for r in db.execute("SELECT tmdb_id FROM shows_watched WHERE NOT ocultar"))
            eps = db.execute("SELECT COUNT(*), MAX(lastPlayed), SUM(progress) FROM episodes_watched").fetchone()
        finally:
            db.close()
        return repr((shows, eps))
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def resume_sig():
    """pelis a medias de watched.db (las de «Seguir viendo»: progress > 0, como Palantir): si cambian, la fila del
    Inicio está vieja"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            rows = db.execute("SELECT tmdb_id, progress FROM movies_watched WHERE progress > 0 ORDER BY tmdb_id").fetchall()
        finally:
            db.close()
        return repr(rows)
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def paused_at():
    """{'movies'|'episodes': fecha del último cambio de pausas en Trakt que ha bajado Palantir}"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            return {t: d for t, d in db.execute(
                "SELECT type, date FROM last_activities_trakt WHERE action = 'paused_at'") if t in PAUSE_TABLES}
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("watched.db pausas: %s" % e)
        return None


def load_seen():
    """firmas de watched.db que vio la última sincronización, también de sesiones anteriores: Palantir puede
    traer de Trakt ANTES de nuestra 1.ª consulta (al pedirle las filas caducadas al arrancar) y entonces la foto
    «antes» ya sale nueva y las filas guardadas se quedaban viejas (Carlos, 20-oct: Carrie dejada de seguir en la
    Shield seguía con ▶ en el móvil)"""
    try:
        with open(SEEN_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_seen():
    # atómico: con open('w') el fichero se vaciaba antes de escribir y, si Kodi cortaba el script (al cerrarse, al
    # recargar la skin), quedaba a medias (revisión 29-oct ARR-13/DAT-15)
    from flix_common import atomic_write
    try:
        atomic_write(SEEN_FILE, json.dumps({"file": file_sig(), "shows": shows_sig(), "resume": resume_sig()}))
    except OSError as e:
        log("no guardo %s: %s" % (SEEN_FILE, e))


def drop_palantir_cache(pattern, what):
    """borra de la caché de Palantir (cache.db) las listas cuyo id contiene `pattern`. Sin cache.db no hay nada que
    borrar: sqlite en escritura lo CREARÍA vacío (auditoría 22-oct B-03)"""
    if not os.path.exists(CACHE_DB):
        return
    try:
        db = sqlite3.connect(CACHE_DB, timeout=5)
        try:
            n = db.execute("DELETE FROM simplecache WHERE id LIKE ?", ("%" + pattern + "%",)).rowcount
            db.commit()
        finally:
            db.close()
        log("caché de %s borrada (%d)" % (what, n))
    except Exception as e:  # noqa: BLE001
        log("no borro la caché de %s: %s" % (what, e))


def refresh_follow():
    drop_palantir_cache("SeriesSeguimiento", "Series en seguimiento")
    HOME.setProperty("flix_rl_p3PathSeriesSeguimiento", str(int(time.time() * 10)))   # fila TV
    refetch_touch("5102")                                                            # Inicio táctil


def refresh_resume():
    """«Seguir viendo» también: en una instalación limpia se pidió antes de que Palantir bajara nada de Trakt, y
    Palantir guarda esa lista (vacía) hasta 3 días: sin borrarla, recargar la fila devolvía lo mismo (B-03)"""
    drop_palantir_cache("PeliculasNoFinalizadas", "Seguir viendo")
    HOME.setProperty("flix_rl_p3PathPeliculasNoFinalizadas", str(int(time.time() * 10)))  # fila TV
    refetch_touch("5101")


def refetch_touch(rid):
    """Inicio táctil (flix_home.py): ids de fila a volver a pedir, separados por comas"""
    cur = [x for x in HOME.getProperty("fh_refetch_row").split(",") if x]
    if rid not in cur:
        HOME.setProperty("fh_refetch_row", ",".join(cur + [rid]))


STUCK = 60          # s: Palantir no suele tardar más de 15 en su raíz; más = se está actualizando (o atascado)
WINDOWS = ("progressdialog", "extendedprogressdialog", "okdialog", "yesnodialog", "busydialog", "contextmenu",
           "selectdialog", "notification", "home", "videos", "fullscreenvideo")


def screen_state():
    """qué hay en pantalla (para el registro): ventanas y diálogos activos, propiedades de la skin que tapan avisos"""
    act = [w for w in WINDOWS if xbmc.getCondVisibility("Window.IsActive(%s)" % w)]
    props = [p for p in ("flix_resolving", "flix_searching", "flix_playload", "flix_debrid", "flix_ctx_auto")
             if HOME.getProperty(p)]
    head = xbmc.getInfoLabel("Control.GetLabel(1)") if "progressdialog" in act else ""
    return "ventana %s, activas %s, modal %s, propiedades %s%s" % (
        xbmcgui.getCurrentWindowId(), act or "-", xbmc.getCondVisibility("System.HasActiveModalDialog"),
        props or "-", (", aviso «%s»" % head) if head else "")


def watch_stuck(done, start):
    """si Palantir tarda más de STUCK s en dar su raíz, cada minuto se apunta qué hay en pantalla: el 28-oct (móvil)
    su actualización de contenido se quedó parada 3 min y siguió al descargar la skin, y no se supo qué esperaba"""
    mon, logged = flix_common.quit_monitor(), 0         # se para al cerrarse Kodi (System.OnQuit, APA-03)
    while not done.is_set() and not flix_common.wait_quit(mon, 5):
        waited = time.time() - start
        if waited >= STUCK and waited - logged >= STUCK:
            logged = waited
            log("Palantir sigue sin terminar su raíz tras %d s: %s" % (waited, screen_state()))


def list_root(mon):
    """lista la raíz de Palantir (lo que le hace bajar de Trakt) y espera a que termine de escribir watched.db;
    True si escribió, False si no, None si Kodi se cierra"""
    start, last = time.time(), file_sig()
    done = threading.Event()
    threading.Thread(target=watch_stuck, args=(done, start), daemon=True).start()
    try:
        # la respuesta no se mira (JSON-RPC común, revisión 29-oct DAT-20)
        flix_common.rpc_send("Files.GetDirectory", {"directory": ROOT, "media": "video"})
    finally:
        done.set()
    changed = False
    while time.time() - start < WATCH:
        if flix_common.wait_quit(mon, STEP):
            return None
        sig = file_sig()
        if sig != last:                 # sigue escribiendo: esperar a que pare
            last, changed = sig, True
            continue
        if changed:
            break                       # escribió y lleva STEP s quieto
    return changed


def backup_db(src, dst):
    """foto coherente de una base SQLite con su API de copia (coge el bloqueo: nunca medio fichero mientras Palantir
    escribe), escrita aparte y puesta de golpe. Antes shutil.copyfile sobre la base viva (auditoría 22-oct B-04)"""
    tmp = dst + ".tmp"
    src_db = sqlite3.connect("file:%s?mode=ro" % src, uri=True, timeout=10)
    try:
        dst_db = sqlite3.connect(tmp)
        try:
            src_db.backup(dst_db)
        finally:
            dst_db.close()
    finally:
        src_db.close()
    os.replace(tmp, dst)


def prepare_pauses():
    """deja que Palantir rehaga las pelis/capítulos a medias IGUAL que en Trakt. Palantir, al bajar de Trakt, añade y
    actualiza pero NUNCA borra: lo que se quita del progreso en otro aparato se quedaba aquí para siempre (Carlos,
    20-oct: 4 pelis quitadas en la Shield seguían en «Seguir viendo» del móvil). Si se le borran las filas a medias y
    la fecha de pausas, en su 1.ª raíz de la sesión vuelve a bajar la lista ENTERA de Trakt (probado en la Shield
    20-oct: 63/63 pelis, mismos porcentajes). Se conservan las filas posteriores a la última fecha de pausas
    (progreso de este aparato que Palantir aún no haya subido, p. ej. sin conexión); las vistas (playcount > 0) no
    se tocan, ni los capítulos de series ocultas («No seguir esta serie»: al quedarse sin capítulos, un disparador de
    Palantir borra la serie con su marca y volvía a salir en Seguimiento en cada arranque, auditoría 22-oct B-02).
    Antes, foto en BACKUP y flix_p3sync_busy: mientras tanto los demás leen la foto (flix_common.watched_db) y la
    ficha no ofrece «Ver» desde el principio de una peli a medias (B-01). Devuelve los tipos preparados."""
    _SAVED.clear()
    pa = paused_at()
    kinds = [k for k in PAUSE_TABLES if (pa or {}).get(k)]
    if not kinds:
        return []                       # sin fecha de pausas: Palantir ya baja la lista entera
    try:
        backup_db(WATCHED_DB, BACKUP)
        HOME.setProperty("flix_p3sync_busy", str(time.time()))     # con la hora: caduca sola (p3sync_busy)
        db = sqlite3.connect(WATCHED_DB, timeout=10)
        try:
            for k in kinds:
                table = PAUSE_TABLES[k]
                where = "playcount = 0 AND progress > 0 AND (lastPlayed IS NULL OR lastPlayed <= ?)"
                if table == "episodes_watched":
                    where += " AND tmdb_id NOT IN (SELECT tmdb_id FROM shows_watched WHERE ocultar)"
                cur = db.execute("SELECT * FROM %s WHERE %s" % (table, where), (pa[k],))
                _SAVED[table] = ([c[0] for c in cur.description], cur.fetchall())
                n = db.execute("DELETE FROM %s WHERE %s" % (table, where), (pa[k],)).rowcount
                db.execute("DELETE FROM last_activities_trakt WHERE type = ? AND action = 'paused_at'", (k,))
                _SAVED.setdefault("paused_at", []).append((k, pa[k]))
                log("pausas %s: %d filas fuera, Palantir las vuelve a bajar de Trakt" % (k, n))
            db.commit()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("no preparo las pausas: %s" % e)
        _SAVED.clear()
        return []
    return kinds


def restore_pauses():
    """devuelve las filas quitadas que Palantir no haya vuelto a escribir (filas, no el fichero: lo que sí bajó en
    esta sesión se queda) y la fecha de pausas, en una transacción"""
    db = sqlite3.connect(WATCHED_DB, timeout=10)
    try:
        n = 0
        for table, keys in PAUSE_KEYS.items():
            if table not in _SAVED:
                continue
            cols, rows = _SAVED[table]
            idx = [cols.index(k) for k in keys]
            for row in rows:
                if db.execute("SELECT 1 FROM %s WHERE %s" % (table, " AND ".join("%s = ?" % k for k in keys)),
                              [row[i] for i in idx]).fetchone():
                    continue
                db.execute("INSERT INTO %s (%s) VALUES (%s)" % (table, ", ".join(cols), ", ".join("?" * len(cols))), row)
                n += 1
        for kind, date in _SAVED.get("paused_at", []):
            if not db.execute("SELECT 1 FROM last_activities_trakt WHERE type = ? AND action = 'paused_at'",
                              (kind,)).fetchone():
                db.execute("INSERT INTO last_activities_trakt (type, action, date) VALUES (?, 'paused_at', ?)",
                           (kind, date))
        db.commit()
        log("pausas devueltas: %d filas" % n)
    finally:
        db.close()


def check_pauses(kinds):
    """tras la raíz: si Palantir no rellenó las pausas (sin conexión, Trakt caído...) se devuelven las quitadas"""
    after = paused_at()
    if after is None:
        log("watched.db sin leer (¿Palantir escribiendo?): no toco las pausas")
        return
    if all(k in after for k in kinds):
        log("pausas iguales que en Trakt (%s)" % ", ".join(kinds))
        return
    log("Palantir no rellenó las pausas (¿sin conexión?): devuelvo las quitadas")
    try:
        restore_pauses()
    except Exception as e:  # noqa: BLE001
        log("no devuelvo las pausas: %s" % e)


def sync_once(mon):
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.palantir3)"):
        return
    # instalación limpia: watched.db no existe hasta que Palantir baja de Trakt en su 1.ª raíz. Antes aquí se salía y
    # las filas personales del Inicio, pedidas vacías, no se volvían a pedir (Carlos, 22-oct)
    # (0 bytes = lo creó vacío otro script antes que Palantir: también es la 1.ª vez, B-03)
    fresh = not os.path.exists(WATCHED_DB) or os.path.getsize(WATCHED_DB) == 0
    seen = load_seen()                  # sin fichero (1.ª vez): se refresca todo una vez
    log("lanzo la sincronización de Palantir")
    # mientras Palantir rebaja las pausas, watched.db está sin ellas: el Inicio táctil no debe quitar nada de
    # «Seguir viendo» (flix_home.sync_progress)
    try:
        os.remove(BACKUP)               # la foto de otra sesión no vale: hasta que haya una nueva, se lee watched.db
    except OSError:
        pass
    HOME.setProperty("flix_p3sync_busy", str(time.time()))
    try:
        kinds = [] if fresh else prepare_pauses()       # con foto en BACKUP: los demás la leen hasta acabar
        start = time.time()
        changed = list_root(mon)
        if changed is None:
            return                      # Kodi se cierra: sin fecha de pausas, Palantir las rebaja al próximo arranque
        if kinds:
            check_pauses(kinds)
    finally:
        HOME.clearProperty("flix_p3sync_busy")
    if fresh and not (os.path.exists(WATCHED_DB) and os.path.getsize(WATCHED_DB)):
        log("Palantir sin datos de Trakt todavía")
        return
    if not changed and file_sig() == seen.get("file"):
        log("sin cambios de Trakt en %d s" % (time.time() - start))
        return
    log("watched.db cambió (%s): pongo al día las filas" % ("en %.0f s" % (time.time() - start) if changed
                                                            else "antes de consultar"))
    if fresh or shows_sig() != seen.get("shows"):
        refresh_follow()
    # el Inicio pinta «Seguir viendo» al arrancar con lo guardado y nadie la volvía a pedir: lo pausado en otro aparato
    # no salía hasta parar un vídeo (Fire TV, 2-nov: American Fiction ya en Palantir y no en la fila). Contra lo visto
    # la vez anterior, como las series: Palantir puede haberlo traído antes de nuestra consulta
    if fresh or resume_sig() != seen.get("resume"):
        refresh_resume()
    HOME.setProperty("fh_progress", "1")          # Inicio táctil: repinta ✓ y barras (flix_home.sync_progress)
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")
    save_seen()


P3SYNC_DONE = "flix_p3sync_done"    # = flix_sections.P3SYNC_DONE: la 1.ª raíz ya está listada (o no se pudo)


def main():
    # al cerrarse Kodi se para en menos de 1 s (Kodi no avisa por abortRequested a los RunScript sin addon: System.OnQuit, flix_common.quit_monitor; APA-03)
    mon = flix_common.quit_monitor()
    if flix_common.wait_quit(mon, DELAY):
        return
    try:
        sync_once(mon)
    finally:
        # aviso a flix_sections follow (secciones «Especial…»), que espera a esto para listar él la raíz (ARR-09)
        HOME.setProperty(P3SYNC_DONE, str(time.time()))


if __name__ == "__main__":
    main()
