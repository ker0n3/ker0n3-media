# -*- coding: utf-8 -*-
"""Abrir una serie de Palantir en su pantalla de temporadas (en vez de "reproducir siguiente capítulo").

RunScript(special://skin/scripts/flix_series.py, <ruta plugin:// del item>)
RunScript(special://skin/scripts/flix_series.py, ver)    -> botón «Ver / Continuar» de la pantalla de temporadas

La ruta de un item de serie lleva action 'play_mis_serieS' (Palantir: reproduce el siguiente capítulo).
Con action 'listado_temporadaS' y el mismo JSON, Palantir devuelve las temporadas en ~2 s.
Se guarda la ruta original en Window(home).Property(flix_series_play) para el botón "Continuar".
Serie a medias (▶): pop-up «Seguir viendo · TxEy / Desde el principio / Ver temporadas» en vez de las temporadas.
Serie sin empezar: «Ver» = T1 E1 (play_mis_serieS no sabe qué poner y no hacía nada; se salta los especiales).
"""
import base64
import json
import math
import re
import sqlite3
import sys
import time
import xbmc
import xbmcgui
import xbmcvfs
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import PLUGIN_ROOT, decode_route, encode_route  # noqa: E402,F401

HOME = xbmcgui.Window(10000)



def next_episode(tmdb_id):
    """('T1 E41', pct) según watched.db de Palantir: episodio a medias (progress>0) o último visto + 1. None si no empezada."""
    if not tmdb_id:
        return None
    from flix_common import watched_db
    db = watched_db(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db"))
    if not os.path.exists(db):
        return None
    try:
        # solo lectura: en escritura sqlite CREA watched.db vacío si aún no existe (instalación limpia) y la
        # sincronización de arranque creía que Palantir ya tenía datos (auditoría 22-oct B-03)
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=3)
        rows = con.execute("SELECT season, episode, playcount, progress, lastPlayed FROM episodes_watched WHERE tmdb_id=? ORDER BY lastPlayed DESC", (tmdb_id,)).fetchall()
        con.close()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] watched.db: %s" % e, xbmc.LOGINFO)
        return None
    if not rows:
        return None
    s, e, playcount, progress, _ = rows[0]
    if progress and progress > 0:       # empezado aunque ya contara como visto (volver a verlo): ese es el a medias
        return ("T%d E%d" % (s, e), int(progress))
    return ("T%d E%d" % (s, e + 1), 0)


def roll_next(nxt, pct, items):
    """(siguiente, terminada). «T1 E7» cuando la temporada 1 tiene 6 -> «T2 E1» (next_episode solo suma 1: no sabe
    cuántos tiene cada temporada; la ventana sí: TotalEpisodes). Si era el último de la última temporada: ('', True)
    = serie vista entera, botón «Ver de nuevo» (T1 E1). Igual si no se sabe o está a medias"""
    m = re.match(r"T(\d+) E(\d+)$", nxt or "")
    if not m or pct:
        return nxt, False
    s, e = int(m.group(1)), int(m.group(2))
    by = {f.get("season"): f for f in items}
    total = str((by.get(s) or {}).get("total") or "")
    if not (total.isdigit() and e > int(total) > 0):
        return nxt, False
    later = sorted(n for n in by if isinstance(n, int) and n > s)
    return ("T%d E1" % later[0], False) if later else ("", True)


def route_field(j, name):
    m = re.search(r'"%s": \'([^\']*)\'' % name, j)
    return m.group(1) if m else ""


def art_url(v, size):
    """'/abc.jpg' (ruta de TMDB que guarda Palantir) -> URL completa; URL completa o vacío -> tal cual"""
    return "https://image.tmdb.org/t/p/%s%s" % (size, v) if v.startswith("/") else v


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    if not path.startswith(PLUGIN_ROOT):
        xbmc.log("[flix_series] ruta inválida: %r" % path, xbmc.LOGINFO)
        return
    try:
        j = decode_route(path)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] no decodifico: %s" % e, xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    if "'play_mis_serieS'" in j:
        play, seasons = path, encode_route(j.replace("'play_mis_serieS'", "'listado_temporadaS'"))
    elif "'listado_temporadaS'" in j:
        play, seasons = encode_route(j.replace("'listado_temporadaS'", "'play_mis_serieS'")), path
    else:
        xbmc.log("[flix_series] ruta sin acción de serie conocida; abro tal cual", xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    # fondo y logo para la pantalla de carga (MyVideoNav: flix_opening) desde la propia ruta: vale para todos los
    # caminos (Inicio TV/táctil, secciones, buscador). Rutas relativas de TMDB -> mismo tamaño que pide Palantir (w1280)
    HOME.setProperty("flix_open_fanart", art_url(route_field(j, "fanart"), "w1280"))
    HOME.setProperty("flix_open_logo", art_url(route_field(j, "clearlogo"), "w500"))
    m = re.search(r'"tvshowtitle": \'([^\']*)\'', j)
    tm = re.search(r'"tmdb": \'?(\d+)', j)
    nxt = next_episode(int(tm.group(1)) if tm else None)
    clear_eps()                               # sin capítulos de la serie anterior mientras carga esta
    fill_seasons([])                          # ni sus temporadas
    set_rating(j, play)
    HOME.setProperty("flix_series_next", nxt[0] if nxt else "")
    HOME.clearProperty("flix_series_done")
    HOME.clearProperty("flix_series_hold")
    HOME.setProperty("flix_series_pct", str(nxt[1]) if nxt and nxt[1] else "")
    HOME.setProperty("flix_series_play", play)
    HOME.setProperty("flix_series_folder", seasons)
    find_trailer(tm.group(1) if tm else "", route_field(j, "trailer"), seasons)
    HOME.setProperty("flix_series_title", m.group(1) if m else "")
    title = m.group(1) if m else "?"
    HOME.setProperty("flix_section", title)   # cabecera de la ventana Vídeos (si no, sale la última sección: "Anime")
    if nxt and started(tm.group(1)):
        import flix_play
        sub = ("%s a medias  ·  %s %%" % (nxt[0], nxt[1])) if nxt[1] else "Siguiente: %s" % nxt[0]
        choice = flix_play.choose(title, sub, "Seguir viendo", more="Ver temporadas", pct=nxt[1],  # TxEy en sub
                                  fanart=HOME.getProperty("flix_open_fanart"))
        xbmc.log("[flix_series] %s a medias: opción %d" % (title, choice), xbmc.LOGINFO)
        if choice == 0:
            xbmc.executebuiltin('PlayMedia("%s")' % play)
            return
        if choice == 1:
            play_first(seasons, title)
            return
        if choice != 2:
            return
    xbmc.log("[flix_series] abro temporadas de %s" % title, xbmc.LOGINFO)
    if open_checked(seasons, title) and xbmc.getCondVisibility("Container.Content(seasons)"):
        watch_seasons(seasons)


def tmdb_star(j):
    """«★ 7.1»: 1.ª nota de la ruta de Palantir («7.1/7.6» = TMDB/IMDb); '' si no hay"""
    m = re.search(r'"rating": \'([0-9.]+)', j)
    return "★ %s" % m.group(1) if m and m.group(1) not in ("0", "0.0") else ""


def set_rating(j, play):
    """nota de la serie en la línea de datos de la ficha (MyVideoNav: flix_series_rating). En la táctil no hay
    cursor que pase por los pósters para verla (Carlos, 21-oct). Con clave de MDBList: Metacritic -> IMDb (si no
    está guardada se pide en segundo plano); si no, la ★ de TMDB"""
    HOME.setProperty("flix_series_rating", tmdb_star(j))
    try:
        import flix_ratings
    except Exception:  # noqa: BLE001
        return
    r = flix_ratings.label_for(play)
    if r:
        HOME.setProperty("flix_series_rating", r)
    elif flix_ratings.wanted(play):
        def late():
            r2 = flix_ratings.label_for(play, wait=flix_ratings.TIMEOUT)
            if r2 and HOME.getProperty("flix_series_play") == play:
                HOME.setProperty("flix_series_rating", r2)
        import threading
        threading.Thread(target=late, daemon=True).start()


def find_trailer(tmdb, palantir, seasons):
    """botón «Tráiler» de la serie (MyVideoNav 5251): URL en flix_series_trailer, buscada en un hilo (flix_trailer:
    TMDB y si no Palantir) mientras se abren las temporadas. Sin el addon YouTube ni se busca: sin botón."""
    HOME.clearProperty("flix_series_trailer")
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
        return

    def run():
        try:
            import flix_trailer
            url = flix_trailer.resolve("tv", tmdb, palantir)
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] tráiler: %s" % e, xbmc.LOGINFO)
            return
        if url and HOME.getProperty("flix_series_folder") == seasons:     # sigue en esta serie
            HOME.setProperty("flix_series_trailer", url)
    import threading
    threading.Thread(target=run).start()        # no daemon: el script espera a que acabe (como mucho ~12 s)


def started(tmdb):
    """serie con ▶ (a medias y seguida; mismo criterio que el póster): vista entera u oculta = no"""
    try:
        import flix_progress
        return (flix_progress.truth_shows() or {}).get(str(tmdb)) == flix_progress.SHOW_STARTED
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] estado de la serie: %s" % e, xbmc.LOGINFO)
        return False


SPECIAL_RE = re.compile(r"especial|special|extra", re.I)


def list_dir(path, props):
    r = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
                                                   "params": {"directory": path, "media": "video", "properties": props}})))
    return (r.get("result") or {}).get("files") or []


def number(f, key, pattern):
    """temporada / capítulo de un elemento: propiedad de Kodi o, si Palantir no la da, el número de la etiqueta"""
    n = f.get(key)
    if isinstance(n, int) and n >= 0:
        return n
    m = re.search(pattern, f.get("title") or f.get("label") or "")
    return int(m.group(1)) if m else None


def pick_season(items):
    """1.ª temporada que no sea especial (temporada 0 / «Especiales»)"""
    ok = [(number(f, "season", r"(\d+)"), i, f) for i, f in enumerate(items)
          if f.get("filetype") != "file" and not SPECIAL_RE.search(f.get("label") or "")]
    ok = [x for x in ok if x[0] != 0]
    ok.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return ok[0][2] if ok else None


def pick_episode(items):
    """capítulo con el número más bajo (Palantir titula «1x01 Nombre»)"""
    eps = [(number(f, "episode", r"\d+x(\d+)"), i, f) for i, f in enumerate(items) if f.get("filetype") != "directory"]
    eps = [x for x in eps if x[0] != 0] or eps
    eps.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return eps[0][2] if eps else None


def play_first(seasons, title):
    """T1 E1 (sin especiales) desde el principio"""
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    ep = None
    try:
        items = list_dir(seasons, ["season", "episode", "title"])
        if any(f.get("filetype") == "file" for f in items):
            # serie de una temporada (Carrie): Palantir da los capítulos directamente. Ojo: «listar» un capítulo
            # lo REPRODUCE (abre el selector) y la lista falla
            ep = pick_episode(items)
        else:
            season = pick_season(items)
            if season:
                ep = pick_episode(list_dir(season["file"], ["season", "episode", "title"]))
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not ep:
        xbmc.log("[flix_series] no encuentro el 1.er capítulo de %s" % title, xbmc.LOGINFO)
        xbmcgui.Dialog().notification(title, "Palantir no responde ahora mismo. Prueba otra vez en un momento.",
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        return
    xbmc.log("[flix_series] %s desde el principio: %s" % (title, ep.get("label")), xbmc.LOGINFO)
    import flix_play
    flix_play.start(ep["file"])


WATCH_STEP = 0.15       # s entre miradas a la temporada enfocada
# carpeta que no existe (0 elementos): un hueco se vacía con ella antes de cargar otra temporada. Con la ruta vacía
# Kodi conservaba los capítulos viejos y Container.IsUpdating no se marca en estas listas
EMPTY_EPS = "special://skin/media/flix/sin-capitulos/"
EPS_FAIL = 20           # s sin capítulos tras pedir una temporada -> «No se pudieron cargar los capítulos»
DEBOUNCE = 0.4          # s quieto en una temporada antes de pedir sus capítulos (Palantir: ~2 s cada vez, sin caché)
EPS_SLOTS = 6           # listas de capítulos (MyVideoNav 7970-7975): las últimas temporadas vistas se quedan cargadas
EPS_FIRST_ID = 7970


def season_key(path):
    """lo que identifica una temporada en su ruta: Palantir mete en ella los contadores de vistos (watchedEpisodes,
    playCount...) y al marcar un capítulo la ruta cambia; con la ruta entera se tomaba por otra temporada y se
    vaciaban y volvían a pedir sus capítulos (Shield, 23-oct). Si no se lee, la ruta tal cual"""
    try:
        j = decode_route(path)
    except Exception:  # noqa: BLE001
        return path
    tm, se = re.search(r'"tmdb": \'?(\d+)', j), re.search(r'"season": (\d+)', j)
    return ("%s/%s" % (tm.group(1), se.group(1))) if tm and se else path


class EpsSlots:
    """Qué lista de capítulos se ve (Carlos, 21-oct: al volver a una temporada, sin esperar a Palantir otra vez).
    Cada hueco k es una lista de MyVideoNav con contenido Window(home).Property(flix_eps_c<k>); solo se ve la activa
    (flix_eps_slot) y las ocultas conservan sus capítulos sin pintar miniaturas. step() devuelve los cambios de
    propiedades; count(k) = elementos que tiene ya la lista k. Temporada nueva: tras DEBOUNCE quieto se coge el hueco
    libre o el usado hace más tiempo, se vacía (EMPTY_EPS, para no ver los de otra temporada) y se le pone la ruta."""

    def __init__(self, n=EPS_SLOTS):
        self.paths, self.used, self.ready = [None] * n, [0.0] * n, set()   # paths: season_key de cada hueco
        self.active, self.seen, self.since, self.job = None, None, 0.0, None

    def find(self, path):
        key = season_key(path)
        return next((k for k, p in enumerate(self.paths) if p == key and k in self.ready), None)

    def pick(self):
        free = [k for k, p in enumerate(self.paths) if p is None]
        return free[0] if free else min(range(len(self.paths)), key=lambda k: self.used[k])

    def _show(self, k, out):
        self.active = k
        out["flix_eps_slot"] = "" if k is None else str(k)
        out["flix_eps_id"] = str(EPS_FIRST_ID + k) if k is not None else str(SEASONS_LIST)
        out["flix_eps_failed"] = ""

    def invalidate(self):
        """tras ver un capítulo (✓ nuevos): todo se vuelve a pedir; la enfocada, en seguida"""
        self.paths, self.ready, self.job, self.seen = [None] * len(self.paths), set(), None, None
        out = {"flix_eps_loading": ""}
        self._show(None, out)
        return out

    def step(self, focus, now, count, first=False):
        out = {}
        if season_key(focus) != self.seen:              # misma temporada con ✓ nuevos: no es otra
            self.seen, self.since = season_key(focus), now
            self.job = None
            out["flix_eps_loading"] = ""
            k = self.find(focus)
            if k is not None:                           # ya cargada: al momento
                self.used[k] = now
                self._show(k, out)
                return out
            if self.active is not None:
                self._show(None, out)                   # rueda hasta que se pida y llegue
        if not focus:
            return out
        if self.job is None and self.active is None and (first or now - self.since >= DEBOUNCE):
            k = self.pick()
            self.ready.discard(k)
            self.paths[k], self.used[k] = season_key(focus), now
            self.job = ["vaciar", k, now]
            out["flix_eps_c%d" % k] = EMPTY_EPS
            out["flix_eps_loading"] = str(k)
            self._show(k, out)
        elif self.job and self.job[0] == "vaciar" and count(self.job[1]) == 0:
            self.job = ["cargar", self.job[1], now]
            out["flix_eps_c%d" % self.job[1]] = focus
        elif self.job and self.job[0] == "cargar" and count(self.job[1]) > 0:
            out["log"] = "capítulos en %.1f s" % (now - self.job[2])
            self.ready.add(self.job[1])
            self.job = None
            out["flix_eps_loading"] = ""
        elif self.job and self.job[0] == "cargar" and now - self.job[2] > EPS_FAIL:
            self.paths[self.job[1]] = None
            self.job = None
            out["flix_eps_failed"] = "1"
        return out


def season_index(items, nxt):
    """posición en la lista de temporadas de la del siguiente capítulo («T2 E5» -> temporada 2); si no se sabe,
    la 1.ª que no es especial"""
    m = re.match(r"T(\d+) ", nxt or "")
    if m:
        for i, f in enumerate(items):
            if number(f, "season", r"(\d+)") == int(m.group(1)):
                return i
    first = pick_season(items)
    return items.index(first) if first is not None else 0


REFOCUS_SECS = 6        # s intentando devolver el foco al capítulo marcado (desde que acaba la recarga de la carpeta)
HOLD_MAX = 20           # s como mucho de retención de la pantalla de serie (flix_menu: flix_series_hold)
# un diálogo encima de la pantalla de serie. Nombrados uno a uno: System.HasModalDialog no ve los de Python (con
# FlixMenu abierto el vigilante seguía y vaciaba la lista de capítulos; Shield, 23-oct)
COVERED = ("System.HasModalDialog | Window.IsActive(contextmenu) | Window.IsActive(selectdialog) | "
           "Window.IsVisible(FlixMenu.xml) | Window.IsVisible(FlixResume.xml) | Window.IsVisible(FlixCtx.xml) | "
           "Window.IsVisible(FlixMovie.xml) | Window.IsVisible(FlixMessage.xml) | Window.IsVisible(FlixQuality.xml)")
SEASONS_LIST = 7952     # columna de temporadas (MyVideoNav vista 52: elementos fijos, su onclick manda)
MAX_SEASONS = 40        # huecos fijos de la columna (Includes_Flix.xml FlixSeasonSlots)
SEASON_FIELDS = ("title", "sub", "watched", "path", "plot", "genre")


def season_props(items):
    """{propiedad de Window(home): valor} para la columna 7952 a partir de las temporadas de la ventana Vídeos.
    Antes la columna pedía las temporadas otra vez a Palantir: no atiende dos llamadas a la vez (~2 s cada una en la
    Shield, 21-oct) y las temporadas tardaban el doble en salir"""
    out = {}
    for i in range(MAX_SEASONS):
        it = items[i] if i < len(items) else {}
        n = it.get("season", -1)
        total = it.get("total", "")
        out.update({
            "flix_s%d_title" % i: ("Temporada %d" % n if n > 0 else it.get("label", "")) if it else "",
            "flix_s%d_sub" % i: "  ·  ".join(x for x in (total and "%s episodios" % total, it.get("year", "")) if x),
            "flix_s%d_watched" % i: "1" if it.get("pct") == "100" else "",
            "flix_s%d_path" % i: it.get("path", ""),
            "flix_s%d_plot" % i: it.get("plot", ""),
            "flix_s%d_genre" % i: it.get("genre", ""),
        })
    return out


def window_seasons():
    """temporadas que muestra la ventana Vídeos (ya cargadas: no se vuelve a llamar a Palantir)"""
    n = xbmc.getInfoLabel("Container.NumItems")
    out = []
    for i in range(min(int(n) if n.isdigit() else 0, MAX_SEASONS)):
        g = lambda k: xbmc.getInfoLabel("Container.ListItemAbsolute(%d).%s" % (i, k))  # noqa: E731
        if g("Label") == "..":
            continue
        s = g("Season")
        out.append({"label": g("Label"), "season": int(s) if s.lstrip("-").isdigit() else -1,
                    "total": g("Property(TotalEpisodes)"), "year": g("Year"),
                    "pct": g("Property(WatchedEpisodePercent)"), "path": g("FileNameAndPath"), "plot": g("Plot"),
                    "genre": g("Genre")})
    return out


def fill_seasons(items):
    for k, v in season_props(items).items():
        HOME.setProperty(k, v)


def visible_seasons():
    """rellena la columna con las temporadas de la ventana y las devuelve (etiqueta, número, ruta)"""
    items = window_seasons()
    fill_seasons(items)
    return items


def eps_count(k):
    n = xbmc.getInfoLabel("Container(%d).NumItems" % (EPS_FIRST_ID + k))
    return int(n) if n.isdigit() else 0


def apply(out):
    for k, v in out.items():
        if k == "log":
            xbmc.log("[flix_series] %s" % v, xbmc.LOGINFO)
        elif v:
            HOME.setProperty(k, v)
        else:
            HOME.clearProperty(k)


def clear_eps():
    """sin capítulos de la serie anterior"""
    for k in range(EPS_SLOTS):
        HOME.clearProperty("flix_eps_c%d" % k)
    for k in ("flix_eps_slot", "flix_eps_loading", "flix_eps_failed", "flix_season_cur"):
        HOME.clearProperty(k)
    HOME.setProperty("flix_eps_id", str(SEASONS_LIST))


def refresh_eps_in_place(mon, hint="", wait=6):
    """tras marcar un capítulo (flix_menu): la lista de capítulos a la vista se vuelve a pedir EN SU SITIO (misma
    ruta + &reload=, como las filas del Inicio): Kodi no la vacía, Palantir la da con los ✓ al día y solo cambia ese
    icono. Antes se vaciaban todas («Cargando capítulos…») y no quedaba nada a la vista (Carlos, 23-oct). El foco se
    queda en el mismo capítulo: devuelve (lista, posición) y el vigilante lo enfoca cuando Kodi acaba de recargar la
    carpeta (si se hace aquí, la recarga lo vuelve a llevar a la columna de temporadas). hint = «lista,posición»
    que leyó flix_menu antes de abrir sus diálogos (aquí, recién cerrados, CurrentItem salía vacío)"""
    k = HOME.getProperty("flix_eps_slot")
    if not k.isdigit():
        return None
    cid = EPS_FIRST_ID + int(k)
    base = re.sub(r"&reload=\d+$", "", HOME.getProperty("flix_eps_c%s" % k))
    if not base or base == EMPTY_EPS:
        return None
    hcid, _, hpos = hint.partition(",")
    pos = hpos if hcid == str(cid) else xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
    pos = int(pos) - 1 if pos.isdigit() and int(pos) > 0 else None
    old = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, pos)) if pos is not None else ""
    xbmc.log("[flix_series] capítulos al día en su sitio (lista %d, posición %s)" % (cid, pos), xbmc.LOGINFO)
    HOME.setProperty("flix_eps_c%s" % k, "%s&reload=%d" % (base, int(time.time() * 1000)))
    end = time.time() + wait
    while pos is not None and time.time() < end and not mon.waitForAbort(0.15):
        now = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, pos))
        if now and now != old:                          # ya llegó la lista nueva
            break
    return (cid, pos) if pos is not None else None


def watch_seasons(folder):
    """Mientras la ventana Vídeos muestre las temporadas de esta serie: capítulos de la temporada enfocada en una de
    las listas EpsSlots. Sigue vivo durante la reproducción de un capítulo; termina al salir de la serie."""
    mon = xbmc.Monitor()
    items = visible_seasons()
    slots, away, sig_at, played = EpsSlots(), None, time.time(), False
    nxt, done = roll_next(HOME.getProperty("flix_series_next"), HOME.getProperty("flix_series_pct"), items)
    if nxt != HOME.getProperty("flix_series_next"):
        HOME.setProperty("flix_series_next", nxt)       # botón «Continuar · TxEy» y temporada que se abre
    if done:
        HOME.setProperty("flix_series_done", "1")       # vista entera: «Ver de nuevo» (ver() -> T1 E1)
    if items:
        idx = season_index(items, HOME.getProperty("flix_series_next"))
        end = time.time() + 2                           # los huecos se ven un fotograma después de rellenarlos
        while time.time() < end and xbmc.getInfoLabel("Container(%d).NumItems" % SEASONS_LIST) != str(len(items)):
            mon.waitForAbort(0.05)
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (SEASONS_LIST, idx))
        # la temporada inicial, sin esperar al debounce: lo primero que se pide a Palantir tras las temporadas
        apply(slots.step(items[idx]["path"], time.time(), eps_count, first=True))
        xbmc.log("[flix_series] %d temporadas a la vista; pido capítulos de la %d.ª" % (len(items), idx + 1),
                 xbmc.LOGINFO)
    sig = [(x["pct"], x["path"]) for x in items]
    refocus = None                                      # (lista, posición, hasta): capítulo marcado en flix_menu
    reloaded = False                                    # Kodi recargó la carpeta con la retención puesta
    while not mon.abortRequested():
        if xbmc.getCondVisibility("Player.HasMedia"):
            played = True
        if xbmc.getCondVisibility("Window.IsActive(videos)"):
            if xbmc.getCondVisibility(COVERED):
                # un diálogo encima (FlixMenu, FlixCtx, menú de Kodi): Container.* y las listas son las SUYAS -> la
                # columna se llenaba con sus elementos («Temporada 1» repetida, «Marcar como vista»), los capítulos se
                # iban y la carpeta «cambiaba» (este vigilante se terminaba). Nada hasta que se cierre (Shield, 23-oct)
                if mon.waitForAbort(WATCH_STEP):
                    break
                continue
            fp = xbmc.getInfoLabel("Container.FolderPath")
            if not fp or xbmc.getCondVisibility("Container.IsUpdating"):
                reloaded = reloaded or bool(HOME.getProperty("flix_series_hold"))
                if mon.waitForAbort(WATCH_STEP):        # Kodi recargando la carpeta (Palantir tras marcar): esperar
                    break
                continue
            if fp != folder:
                break                                   # otra carpeta (Atrás, otra serie)
            away = None
            if xbmc.getCondVisibility("Control.HasFocus(52)") and not HOME.getProperty("flix_ctx_auto"):
                # la lista de temporadas de Kodi está fuera de pantalla: al cerrar un menú el foco vuelve a ella y el
                # mando se movía sin que se viera nada (Fire TV, 23-oct) -> a la columna visible
                xbmc.executebuiltin("SetFocus(%d)" % SEASONS_LIST)
            if played and not xbmc.getCondVisibility("Player.HasMedia"):
                played = False                          # tras ver un capítulo: capítulos guardados con ✓ viejos
                apply(slots.invalidate())
            hint = HOME.getProperty("flix_eps_refresh")
            if hint:                                    # flix_menu marcó un capítulo: ✓ al día, en su sitio
                HOME.clearProperty("flix_eps_refresh")
                back = refresh_eps_in_place(mon, hint)
                refocus = (back + (None,)) if back else None
            hold = HOME.getProperty("flix_series_hold")
            age = time.time() - float(hold or 0)
            if hold and (age > HOLD_MAX or (not HOME.getProperty("flix_eps_refresh") and (reloaded or age > 3) and
                         xbmc.getCondVisibility("Container.Content(seasons) + !Container.IsUpdating"))):
                # suelta cuando Kodi ya recargó la carpeta (Palantir la refresca tras marcar: ~8 s en la Shield);
                # antes se soltaba al segundo, ANTES de que empezara, y todo se ocultaba mientras (Shield, 23-oct)
                HOME.clearProperty("flix_series_hold")  # la carpeta ya está otra vez (MyVideoNav: retención)
                hold, reloaded = "", False
            if refocus and not hold:                    # con la recarga en curso el foco aún se lo lleva Kodi
                rcid, rpos, until = refocus
                if until is None:
                    refocus = (rcid, rpos, time.time() + REFOCUS_SECS)
                elif time.time() > until or xbmc.getCondVisibility("Control.HasFocus(%d)" % rcid):
                    refocus = None
                elif xbmc.getCondVisibility("Control.HasFocus(%d) | Control.HasFocus(52)" % SEASONS_LIST):
                    xbmc.log("[flix_series] foco de vuelta al capítulo (lista %d, posición %d)" % (rcid, rpos),
                             xbmc.LOGINFO)
                    xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (rcid, rpos))
            if time.time() - sig_at > 1:                # Kodi recarga la carpeta tras ver un capítulo: ✓ al día
                sig_at = time.time()
                now = window_seasons()
                if [(x["pct"], x["path"]) for x in now] != sig and now:
                    sig = [(x["pct"], x["path"]) for x in now]
                    fill_seasons(now)
            cur = xbmc.getInfoLabel("Container(%d).ListItem.Property(path)" % SEASONS_LIST)
            if cur != HOME.getProperty("flix_season_cur"):
                # temporada resaltada en la columna (táctil FTSeasonRow): con un diálogo encima Container(7952) ya no
                # es la columna y TODAS salían resaltadas (Carlos, 23-oct); esta propiedad no cambia mientras
                HOME.setProperty("flix_season_cur", cur)
            apply(slots.step(cur, time.time(), eps_count))
        elif not xbmc.getCondVisibility("Player.HasMedia | Window.IsActive(busydialog) | "
                                        "Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog)"):
            away = away or time.time()
            if time.time() - away > 3:                  # ni en la serie ni viendo un capítulo
                break
        if mon.waitForAbort(WATCH_STEP):
            break
    HOME.clearProperty("flix_series_hold")          # fuera de la serie: nada de retener su pantalla
    xbmc.log("[flix_series] fin del vigilante de temporadas", xbmc.LOGINFO)


def ver():
    """botón de la pantalla de temporadas: «Continuar · TxEy» = siguiente de Palantir; «Ver» (sin empezar) = T1 E1"""
    if HOME.getProperty("flix_series_next"):
        xbmc.executebuiltin('PlayMedia("%s")' % HOME.getProperty("flix_series_play"))
    else:
        play_first(HOME.getProperty("flix_series_folder"), HOME.getProperty("flix_series_title"))


def loaded_ok(path):
    n = xbmc.getInfoLabel("Container.NumItems")
    return xbmc.getInfoLabel("Container.FolderPath") == path and n.isdigit() and int(n) > 0


def wait_loaded(path, timeout=90):
    """True si la ventana Vídeos acaba mostrando 'path'. False si Palantir falla: entonces Kodi deja a la vista la
    ÚLTIMA carpeta que tuvo esa ventana (p. ej. un "Especial Halloween" de antes) -> hay que detectarlo."""
    t0 = time.time()
    idle_since = None
    while time.time() - t0 < timeout:
        busy = xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Container.IsUpdating")
        if loaded_ok(path) and not busy:
            xbmc.sleep(600)                         # al fallar, Kodi pone un instante la ruta pedida y vuelve atrás
            if loaded_ok(path):
                return True
            continue
        if xbmc.getCondVisibility("Window.IsActive(videos)") and not busy and time.time() - t0 > 2:
            idle_since = idle_since or time.time()
            if time.time() - idle_since > 3:        # ventana quieta 3 s con otra carpeta = falló la carga
                return False
        else:
            idle_since = None
        if not xbmc.getCondVisibility("Window.IsActive(videos)") and time.time() - t0 > 5:
            return True                             # el usuario se fue: nada que vigilar
        xbmc.sleep(200)
    return False


def open_checked(seasons, title, tries=2):
    """Abre las temporadas tapando la carpeta vieja (MyVideoNav: flix_opening) y reintenta una vez si Palantir
    falla (p. ej. ocupado sincronizando Trakt)."""
    HOME.setProperty("flix_opening", "1")
    try:
        for attempt in range(1, tries + 1):
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % seasons)
            if wait_loaded(seasons):
                return True
            xbmc.log("[flix_series] Palantir no dio las temporadas de %s (intento %d)" % (title, attempt), xbmc.LOGINFO)
            if xbmc.getCondVisibility("Window.IsActive(videos)"):
                xbmc.executebuiltin("Action(Back)")     # fuera la carpeta vieja
                xbmc.sleep(800)
        xbmcgui.Dialog().notification(title, "Palantir no responde ahora mismo. Prueba otra vez en un momento.",
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        return False
    finally:
        HOME.clearProperty("flix_opening")


if __name__ == "__main__":
    if sys.argv[1:2] == ["ver"]:
        ver()
    else:
        main()
