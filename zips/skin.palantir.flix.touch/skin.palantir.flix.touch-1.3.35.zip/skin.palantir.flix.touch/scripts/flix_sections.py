"""Secciones del menú: barra lateral de la TV (Home.xml, lista 9000: Inicio + 14 huecos fijos) y tarjetas de arriba de
la táctil (flix_home.py, las 7 primeras). Qué secciones salen, en qué orden y qué filas lleva cada una lo decide
flix_sections_conf (sections.json, por aparato); apply() lo copia a Window(home).Property(flix_sec<N>_*) y
flix_chip<N>, que es lo que pintan los huecos: el menú cambia al momento, sin recargar el skin.
Uso: RunScript(special://skin/scripts/flix_sections.py)              -> editor único (flix_editor.py,menu)
     RunScript(special://skin/scripts/flix_sections.py,apply)        -> rellena el menú (Home.xml si no lo está)
     RunScript(special://skin/scripts/flix_sections.py,open,<clave>) -> abre una sección de rejilla (Trakt, Favoritos…)
     RunScript(special://skin/scripts/flix_sections.py,follow)       -> al arrancar: secciones «Especial…» al día"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re

import flix_sections_conf  # noqa: E402

CONF_NAME = "sections.json"


def setting(key):
    """ajuste viejo (antes de sections.json) que ocultaba una sección de serie"""
    return "flix_hide_%s" % key


def hidden_now():
    import xbmc
    return {d["key"] for d in flix_sections_conf.DEFAULTS
            if xbmc.getCondVisibility("Skin.HasSetting(%s)" % setting(d["key"]))}


def conf_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/%s" % (xbmc.getSkinDir(), CONF_NAME))


def load_conf():
    import json
    try:
        with open(conf_path(), encoding="utf-8") as fh:
            raw = json.load(fh)
    except OSError:
        return flix_sections_conf.default_conf(hidden_now())     # sin fichero: lo de siempre (y flix_hide_<clave>)
    except ValueError as e:
        import xbmc
        xbmc.log("[flix_sections] %s ilegible (%s): secciones de serie" % (CONF_NAME, e), xbmc.LOGWARNING)
        return flix_sections_conf.default_conf(set())
    return flix_sections_conf.normalize(raw)


def save_conf(conf):
    import json
    from flix_common import atomic_write     # temporal único (antes «.tmp» fijo) (revisión 29-oct ARR-13/DAT-15)
    atomic_write(conf_path(), json.dumps(conf, ensure_ascii=False, indent=1))


def from_palantir(s):
    """¿sección de Palantir? Las de serie (variable p3… de la skin) y las añadidas de su raíz; no las de «Otros
    orígenes» (biblioteca, NAS, otros complementos)"""
    src = s.get("src", "")
    return src.startswith("plugin://plugin.video.palantir3/") or ("://" not in src and not src.startswith("/"))


def own_list(s):
    """con fuentes propias, la ruta propia de una sección de rejilla («Series en seguimiento», «Películas no
    finalizadas»); '' si no la tiene"""
    import flix_rows
    import flix_sections_own
    if s.get("kind") != "list":
        return ""
    src = s.get("src", "")
    return flix_sections_own.list_path(src, flix_rows.route_of(src))


def own_ok(s):
    """con fuentes propias, ¿sale la sección? Las de «Otros orígenes», sí; las de Palantir, si tienen menú propio con
    filas (Trakt, solo en uso) o rejilla propia. Las demás (sin equivalente, también la que seguía al «Especial…» de
    Palantir) no, esté o no Palantir instalado (Carlos, 17-nov); la migración única las borra (migrate_own)"""
    if not from_palantir(s):
        return True
    if s.get("follow"):
        return False
    if s.get("kind") == "list":
        return bool(own_list(s))
    import flix_rows
    return bool(flix_rows.own_menu(s.get("src", "")))


def shown_sections(conf):
    """las secciones que salen en el menú: las activas; con fuentes propias, las que tienen de dónde salir (own_ok:
    bloques 4 y 5). Leer no toca la configuración"""
    import flix_common
    act = flix_sections_conf.active(conf)
    if act and flix_common.fuentes_on():
        act = [s for s in act if own_ok(s)]
    return act


def effective_rows(var, rconf, **kw):
    """filas que salen en la sección: su menú (flix_rows.section_rows: el de Palantir o, con fuentes propias, el propio)
    con lo elegido en «Editar filas» (apply_rows). Con fuentes propias (bloques 4 y 5), las añadidas de Palantir pasan
    a su lista parecida o, sin ella, no salen (flix_rows.custom_path)"""
    import flix_common
    import flix_rows
    rows = flix_sections_conf.apply_rows(flix_rows.section_rows(var, **kw), rconf or {})
    if not flix_common.fuentes_on():
        return rows
    out = []
    for r in rows:
        if r.get("custom") and str(r.get("path", "")).startswith(flix_common.PLUGIN_ROOT):
            p = flix_rows.custom_path(r["path"])
            if not p:
                continue
            r = dict(r, path=p, kind="list")
        out.append(r)
    return out


# ---------- migración única «sin equivalente → fuera» (bloques 4 y 5; Carlos, 17-nov) ----------
MIGRATED = "sin_palantir_migrado.json"      # marca por aparato (addon_data de la skin): {"t", "trakt"}
BACKUP = CONF_NAME + ".antes-sin-palantir"  # copia de sections.json de antes, una sola vez, para reponerla a mano


def prune_rows(rconf, own_labels):
    """(filas de la sección sin lo que no tiene equivalente, etiquetas quitadas). Se queda lo de las filas del menú
    propio (own_labels) y lo de las añadidas que tienen parecida (listas de TMDB, otros orígenes; las de Palantir
    con lista parecida se traducen al pintar: flix_rows.custom_path); fuera lo demás (orden, ocultas, nombres,
    eliminadas y añadidas)"""
    import flix_common
    import flix_rows
    rconf = dict(rconf or {})
    gone = []
    custom = []
    for c in rconf.get("custom") or []:
        if str(c.get("path", "")).startswith(flix_common.PLUGIN_ROOT) and not flix_rows.custom_path(c["path"]):
            gone.append(c["label"])
        else:
            custom.append(c)
    keep = set(own_labels) | {c["label"] for c in custom}
    for field in ("order", "off", "deleted"):
        if field in rconf:
            vals = list(rconf.get(field) or [])
            gone += [l for l in vals if l not in keep and l not in gone]
            rconf[field] = [l for l in vals if l in keep]
            if field == "deleted" and not rconf[field]:
                del rconf[field]
    if "names" in rconf:
        gone += [l for l in rconf["names"] if l not in keep and l not in gone]
        rconf["names"] = {l: n for l, n in rconf["names"].items() if l in keep}
        if not rconf["names"]:
            del rconf["names"]
    if "custom" in rconf:
        if custom:
            rconf["custom"] = custom
        else:
            del rconf["custom"]
    return rconf, gone


def prune_own(conf, trakt=None, rows_only_trakt=False):
    """(conf nuevo, [textos de lo quitado], ¿Trakt hecho?) con fuentes propias: fuera las secciones de Palantir sin
    equivalente (también la que seguía al «Especial…») y, en las que tienen, la configuración de filas sin
    equivalente. Las de otros orígenes y las eliminadas de serie, tal cual. Las filas de Trakt solo con Trakt en uso
    (trakt["on"]): sin él no se sabe qué listas son de la cuenta. rows_only_trakt: solo eso (la marca ya estaba)"""
    import flix_rows
    import flix_sections_own as so
    trakt = trakt if isinstance(trakt, dict) else {}
    out, removed, trakt_done = [], [], bool(trakt.get("on"))
    for s in conf["sections"]:
        if not from_palantir(s) or s.get("deleted"):
            out.append(s)
            continue
        name = flix_sections_conf.shown(s)
        var = so.own_var(s.get("src", ""), flix_rows.route_of(s.get("src", "")))
        keep = not s.get("follow") and (bool(own_list(s)) if s.get("kind") == "list" else bool(var))
        if not keep:
            if not rows_only_trakt:
                removed.append("sección «%s»" % name)
                continue
            out.append(s)
            continue
        if s.get("kind") == "rows" and (var == so.TRAKT and trakt_done or var != so.TRAKT and not rows_only_trakt):
            rows, gone = prune_rows(s.get("rows"), [r["label"] for r in so.rows_for(var, trakt=trakt) or []])
            s = dict(s, rows=rows)
            removed += ["%s: fila «%s»" % (name, l) for l in gone]
        out.append(s)
    return dict(conf, sections=out), removed, trakt_done


def migrate_own(conf_file=None, mark_file=None, trakt=None, log_fn=None):
    """una sola vez por aparato y con fuentes propias (first_run, antes de montar el menú): borra de sections.json lo
    que no tiene equivalente sin Palantir (Carlos, 17-nov: borrar, no ocultar). Antes guarda una copia de
    sections.json (BACKUP, solo la primera vez) y apunta en el registro lo quitado (solo nombres). Lo que tiene
    equivalente no se toca. Si Trakt no estaba en uso, sus filas se miran en un arranque posterior con Trakt en uso.
    Devuelve lo quitado ([] si no tocaba). Nunca lanza"""
    import json
    import os
    import time
    import flix_common
    log_fn = log_fn or log
    try:
        if not flix_common.fuentes_on():
            return []
        conf_file = conf_file or conf_path()
        mark_file = mark_file or os.path.join(os.path.dirname(conf_file), MIGRATED)
        try:
            with open(mark_file, encoding="utf-8") as fh:
                mark = json.load(fh)
        except (OSError, ValueError):
            mark = None
        if isinstance(mark, dict) and mark.get("trakt"):
            return []                       # hecho del todo
        if trakt is None:
            import flix_rows
            trakt = flix_rows.k3_trakt_lists()
        only_trakt = isinstance(mark, dict)
        if only_trakt and not trakt.get("on"):
            return []                       # falta lo de Trakt y sigue sin estar en uso
        removed, done = [], bool(trakt.get("on"))
        if os.path.exists(conf_file):       # sin fichero: las de serie, sin nada configurado que quitar
            with open(conf_file, encoding="utf-8") as fh:
                raw = fh.read()
            conf = flix_sections_conf.normalize(json.loads(raw))
            new, removed, done = prune_own(conf, trakt, rows_only_trakt=only_trakt)
            if removed:
                backup = os.path.join(os.path.dirname(conf_file), BACKUP)
                if not os.path.exists(backup):
                    flix_common.atomic_write(backup, raw)
                flix_common.atomic_write(conf_file, json.dumps(new, ensure_ascii=False, indent=1))
        flix_common.atomic_write(mark_file, json.dumps({"t": int(time.time()), "trakt": done}))
        log_fn("sin Palantir: %s" % ("quitado de la configuración (copia en %s): %s" % (BACKUP, "; ".join(removed))
                                     if removed else "nada que quitar de la configuración"))
        return removed
    except Exception as e:  # noqa: BLE001
        log_fn("sin Palantir: configuración sin migrar (%s)" % type(e).__name__)
        return []


def menu_props(conf, resolve=None):
    """{propiedad: valor} del menú: huecos flix_sec<N>_* (TV) y flix_chip<N> (táctil, los TOUCH_MAX primeros)"""
    act = shown_sections(conf)
    out = {}
    for n in range(1, flix_sections_conf.MAX_SECTIONS + 1):
        s = act[n - 1] if n <= len(act) else {}
        out.update({"flix_sec%d_label" % n: flix_sections_conf.shown(s) if s else "", "flix_sec%d_icon" % n: s.get("icon", ""),
                    "flix_sec%d_kind" % n: s.get("kind", ""), "flix_sec%d_key" % n: s.get("key", "")})
        out["flix_chip%d" % n] = flix_sections_conf.shown(s) if s and n <= flix_sections_conf.TOUCH_MAX else ""
    return out


def apply(conf=None):
    import xbmcgui
    conf = conf or load_conf()
    home = xbmcgui.Window(10000)
    for k, v in menu_props(conf).items():
        home.setProperty(k, v)
    home.setProperty("flix_sec_ok", "1")        # Home.xml: si falta (skin recién instalado) lo pide al cargar
    return shown_sections(conf)


def chips_props():
    """táctil: tarjetas de arriba (flix_chip<N>) = las primeras secciones activas"""
    return apply()[:flix_sections_conf.TOUCH_MAX]


def section(key, conf=None):
    """sección por clave; también por variable p3… (accesos de antes: flix_section.py,p3Dibujos,Dibujos)"""
    secs = (conf or load_conf())["sections"]
    return next((s for s in secs if s["key"] == key), None) or next((s for s in secs if s["src"] == key), None)


def src_path(s):
    """ruta de Palantir de una sección: la guardada (añadidas) o la variable p3… del skin; con los $INFO[...] que
    llevan algunas (&reload=…) ya resueltos"""
    import xbmc
    src = s.get("src", "")
    if "://" not in src and not src.startswith("/"):        # nombre de variable de la skin (las de serie); una ruta
        # de otro origen (library://, sources://, smb://, special://…: «Otros orígenes», 13-nov) va tal cual
        import flix_rows
        src = flix_rows.skin_var(src)
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: xbmc.getInfoLabel(m.group(1)), src)


def open_one_row(title, path):
    """una ruta del addon como sección de una fila (como «Ver más»: ficha, tráiler y menú de siempre), en otro
    intérprete: flix_section.py en la TV, flix_home.py en la táctil"""
    import json
    import xbmc
    import xbmcgui
    xbmcgui.Window(10000).setProperty("flix_similar", json.dumps(
        {"title": title, "rows": [{"label": title, "path": path, "kind": "list"}], "menu": True}))
    script = "flix_home.py" if xbmc.getSkinDir().endswith(".touch") else "flix_section.py"
    xbmc.executebuiltin("RunScript(special://skin/scripts/%s,similar)" % script)


def open_list(key):
    """sección de rejilla (Series en seguimiento, Películas no finalizadas…): su listado en la ventana Vídeos; con
    fuentes propias y ruta propia, como sección de una fila (en la rejilla de Kodi una película se reproducía sin
    ficha; bloques 4 y 5)"""
    import flix_common
    import xbmc
    import xbmcgui
    s = section(key)
    own = own_list(s) if s and flix_common.fuentes_on() else ""
    if own:
        open_one_row(flix_sections_conf.shown(s), own)
        return
    path = src_path(s) if s else ""
    if not path:
        xbmc.log("[flix_sections] sección %s sin ruta" % key, xbmc.LOGWARNING)
        return
    xbmcgui.Window(10000).setProperty("flix_section", flix_sections_conf.shown(s))     # cabecera de la ventana Vídeos
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)


PALANTIR_ROOT = "plugin://plugin.video.palantir3/"
NO_ANSWER = "Palantir no responde ahora mismo"
FOLLOW_DELAY = 20       # s tras arrancar: que el Inicio pida lo suyo antes (Palantir atiende una llamada cada vez)
# Window(home): flix_p3sync ya listó la 1.ª raíz de la sesión (la única que baja de Trakt, 724f84e). follow lista la
# raíz DESPUÉS: si no, con una sección «Especial…» la gastaba follow (empezaba ~1,5 s antes) y p3sync podía devolver
# las pausas quitadas creyendo que Palantir no las había rellenado (revisión 29-oct ARR-09). Como mucho P3SYNC_MAX s
# (p3sync espera 20 s y su raíz, hasta 120): si no arrancó o murió, follow sigue como antes
P3SYNC_DONE = "flix_p3sync_done"
P3SYNC_MAX = 150
P3SYNC_STEP = 1


def log(msg):
    import xbmc
    xbmc.log("[flix_sections] %s" % msg, xbmc.LOGINFO)


_MON = []          # el Monitor del script (follow): se entera del cierre de Kodi (System.OnQuit; APA-03)


def wait(seconds):
    """True si Kodi se cierra mientras espera (también sin addon: flix_common.wait_quit)"""
    import flix_common
    if not _MON:
        _MON.append(flix_common.quit_monitor())
    return flix_common.wait_quit(_MON[0], seconds)


def wait_p3sync():
    """espera a que flix_p3sync haya listado la 1.ª raíz de la sesión (P3SYNC_DONE), como mucho P3SYNC_MAX s. True si
    Kodi se cierra mientras"""
    import xbmcgui
    waited = 0
    while not xbmcgui.Window(10000).getProperty(P3SYNC_DONE):
        if waited >= P3SYNC_MAX:
            log("especial: flix_p3sync no ha acabado en %d s; sigo" % P3SYNC_MAX)
            return False
        if wait(P3SYNC_STEP):
            return True
        waited += P3SYNC_STEP
    return False


def palantir_root():
    """menú principal de Palantir sin rueda de espera (al arrancar, por detrás)"""
    import flix_palantir_browse
    return flix_palantir_browse.listing(PALANTIR_ROOT)


def follow():
    """al arrancar (Startup.xml): las secciones «Especial…» toman el especial que tenga ahora Palantir (nombre y
    ruta) o se esconden si no tiene ninguno; si Palantir no responde, no se toca nada"""
    import flix_common
    if flix_common.fuentes_on():
        return              # sin «Especial…» con fuentes propias (Carlos, 17-nov): nada que pedir a Palantir
    import first_run
    if not first_run.once("especial"):
        return              # ya lo lanzó first_run (o el Startup táctil): una vez por sesión
    if not any(s.get("follow") for s in load_conf()["sections"]):
        return
    if wait(FOLLOW_DELAY):
        return
    if wait_p3sync():
        return
    import flix_home_conf
    folders, _ = flix_home_conf.classify(palantir_root())
    if not folders:
        log("especial: Palantir no responde")
        return
    conf = load_conf()          # pudo cambiar mientras esperaba
    if flix_sections_conf.follow_update(conf, [{"label": f["label"], "path": f["file"]} for f in folders]):
        save_conf(conf)
        apply(conf)
        log("especial al día: %s" % ", ".join("%s%s" % (s["label"], " (sin especial ahora)" if s.get("gone") else "")
                                                for s in conf["sections"] if s.get("follow")))


def kind_of(files):
    """al añadir una sección: "rows" si su menú son submenús (filas), "list" si lista títulos (Películas no
    finalizadas, Series en seguimiento); None si Palantir no ha dado nada"""
    import flix_home_conf
    folders, titles = flix_home_conf.classify(files)
    if not folders and not titles:
        return None
    return "list" if titles > len(folders) else "rows"


def rows_conf(items):
    """[(etiqueta, encendida)] del editor de filas -> {"order", "off"} de sections.json"""
    return {"order": [l for l, _ in items], "off": [l for l, on in items if not on]}


def count_text(n, touch):
    if touch and n > flix_sections_conf.TOUCH_MAX:
        return "%d de %d · en el móvil se ven %d" % (n, flix_sections_conf.MAX_SECTIONS, flix_sections_conf.TOUCH_MAX)
    return "%d de %d secciones" % (n, flix_sections_conf.MAX_SECTIONS)


def palantir_menu(path):
    """listado de un menú de Palantir (sin caché: al añadir se quiere lo de ahora)"""
    import flix_palantir_browse
    import flix_picker
    flix_picker.busy(True)
    try:
        return flix_palantir_browse.listing(path)
    finally:
        flix_picker.busy(False)


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "open":
        open_list(sys.argv[2])
    elif len(sys.argv) > 1 and sys.argv[1] == "follow":
        follow()
    elif len(sys.argv) > 1 and sys.argv[1] == "apply":
        apply()
    else:
        import flix_editor
        flix_editor.run("menu")          # acceso viejo (Ajustes de antes)
