"""Secciones de Palantir desplegadas en filas (compartido TV / táctil).

section_rows(var) lee el menú de una sección (rutas fijas p3Peliculas… de Includes_Palantir3.xml) y lo
convierte en filas:
  kind "list" = listado de títulos (action listado_peliculaS / listado_serieS) -> fila de carátulas
  kind "coll" = submenú (sagas, especiales, calidad, géneros, alfabético…) -> fila de tarjetas; al abrir
               una tarjeta se ve su rejilla de carátulas (vista 51)
Las cabeceras ("Películas de Dibujos:") agrupan; "Buscar por título" se omite (ya está el buscador).
fetch() cachea en disco 30 min: cada llamada a Palantir consulta además la API de GitHub (60/h por IP).
peek() da lo guardado aunque esté caducado (las secciones lo enseñan al momento y refrescan por detrás).
Con save=False fetch() no escribe el fichero: el que llama hace flush() cada pocas filas (antes se reescribían
~2,6 MB tras cada fila). flush() quita lo de más de un día y escribe de forma atómica.
"""
import ast
import json
import os
import re
import time
import urllib.parse
import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# skin_var: una sola copia en flix_common, con el XML leído una vez por proceso (revisión 29-oct DAT-19)
from flix_common import COLOR_RE, clean, decode_route, is_fs, list_dir, skin_var  # noqa: E402,F401
import flix_cache  # noqa: E402

# tarjeta de una fila que aún no ha llegado / que no dio nada: la misma en la Sección de TV (flix_section) y en el
# Inicio y las secciones táctiles (flix_home; revisión 29-oct TCT-08)
LOADING, MISSING = "Cargando…", "No disponible"

CACHE_TTL = 1800            # filas personales (Seguir viendo, Series en seguimiento…): cambian al ver algo
STATIC_TTL = 6 * 3600       # las demás (Top 10, novedades, plataformas, géneros…): como mucho cambian a diario.
# cuánto se guarda una fila aunque esté caducada: se enseña al momento y se refresca por detrás. Era 1 día y con el
# Inicio «Aleatoria» (listas de TMDB) ya nadie refrescaba las filas de las secciones: entrar en Películas o Anime tras
# un día salía todo en «Cargando…» (Carlos, 24-oct). Son siempre las mismas rutas (se reemplazan, no se acumulan).
# Las listas de TMDB pesan mucho (5 de 8 MB en la Fire TV) y se sortean en cada arranque: siguen en 1 día
KEEP = 7 * 86400
KEEP_TMDB = 86400
# Cada fila pedida a Palantir es una consulta a la API de GitHub (60/h por IP, compartida por todos los aparatos de
# casa): antes se pedían las ~18 cada 30 min (auditoría 22-oct C-07, aprobado por Carlos)
TMDB_LIST = "flix://tmdb/"     # filas con listas de TMDB hechas de títulos de Palantir (flix_tmdblists.py)
# filas de tarjetas de las secciones propias (sagas, géneros, años): ruta tarjetas/<grupo> del addon (= flix_sections_own.CARDS)
CARDS = "plugin://plugin.video.ker0n3/tarjetas/"
PERSONAL_RE = re.compile(r"no_finalizadas|Mis_|Seguimiento|watchlist|favorit|historial", re.I)
FAV_RE = re.compile(r"favorit", re.I)       # rutas de Favoritos de Palantir (menú y sus listas)
TRAKT_RE = re.compile(r"listas_trakt|listado_trakt")     # menú «Listas Trakt.tv» de Palantir y cada lista
# «Películas favoritas (9)» / «Watchlist Películas [1]»: la cuenta sale fuera de la etiqueta (la configuración de
# filas va por etiqueta y la cuenta cambia al añadir) y las que están a 0 no son fila («Música (0)»…)
COUNT_RE = re.compile(r"^(.*?)\s*[(\[](\d+)[)\]]$")
# secciones cuyo menú cambia (cuentas, listas nuevas): guardado y caducado se pide otra vez al entrar
LIVE_MENUS = ("p3Favoritos", "p3PathTrakt")
# entradas de menú que no son listados sino acciones (abren el teclado): nunca fila
SKIP_ACTIONS = ("add_lista_trakt",)


def route_of(path):
    """ruta de Palantir decodificada ("" si no es de Palantir o no se entiende)"""
    if not path.startswith("plugin://plugin.video.palantir3/?"):
        return ""
    try:
        return decode_route(path.split("&")[0]) or ""
    except Exception:  # noqa: BLE001
        return ""


def title_key(f):
    """«content:tmdb» de la ruta de Palantir de un título ("" si no se entiende): el mismo título en filas distintas"""
    try:
        info = ast.literal_eval(decode_route(f.get("file", "")))
    except Exception:  # noqa: BLE001
        return ""
    return "%s:%s" % (info.get("content"), info["tmdb"]) if isinstance(info, dict) and info.get("tmdb") else ""


def is_fav_path(path):
    """¿es un listado de Favoritos de Palantir? (menú de Favoritos o una de sus categorías)"""
    return bool(FAV_RE.search(route_of(path)))


def ttl_of(path):
    """caducidad de la caché de una fila según sea personal o no (CACHE_TTL / STATIC_TTL). Las listas y las tarjetas
    de Ker0n3 (bloques 4 y 5) como las de TMDB (el addon avisa si cambian); lo demás de Ker0n3 (favoritos, seguir),
    personal"""
    if path.startswith((TMDB_LIST, CARDS, K3_LIST)):
        return STATIC_TTL
    if path.startswith("plugin://plugin.video.ker0n3/"):
        return CACHE_TTL
    route = route_of(path)
    if not route:
        return CACHE_TTL
    return CACHE_TTL if PERSONAL_RE.search(route) else STATIC_TTL
# «2»: las rutas guardadas antes de la 1.4.52/1.0.71 pueden llevar progreso a None (flix_progress) y Palantir revienta
# al reproducirlas -> caché nueva; la vieja (rows_cache.json) la borra first_run al arrancar
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache2.json" % xbmc.getSkinDir())
GENERIC_ART = "plugin.video.palantir3/resources/media"   # icono genérico de Palantir (calidad, letras, "Más…")
SECTION_VARS = {"Películas": "p3Peliculas", "Series": "p3Series", "Anime": "p3Anime",
                "Dibujos": "p3Dibujos", "Documentales": "p3Documentales"}
PROPS = ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file", "plot", "duration"]


def log(msg):
    xbmc.log("[flix_rows] %s" % msg, xbmc.LOGINFO)




def action_of(path):
    try:
        m = re.search(r'"action": \'?([^\',}]+)', decode_route(path))
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


HOME = xbmcgui.Window(10000)
_cache = None
_dirty = set()      # claves que este proceso ha pedido a Palantir y aún no ha guardado
# Lo que este proceso dejó en el fichero en su último guardado con más guardados detrás (flush(keep=True)), para no
# volver a leerlo entero si nadie lo ha cambiado (revisión 29-oct DAT-02; json.load de 33-126 ms con 8 MB y la Shield
# ya tiene 10 MB). {clave: (marca, texto JSON de la entrada)}: texto y no los objetos, porque _progress corrige en
# sitio las filas que se enseñan y el fichero tiene que salir igual, byte a byte, que releyéndolo.
_saved = None
_saved_sig = None   # huella del fichero justo después de ese guardado: (ruta, inodo, mtime en ns, tamaño)


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _file_sig():
    try:
        st = os.stat(CACHE_FILE)
    except OSError:
        return None
    return (CACHE_FILE, st.st_ino, st.st_mtime_ns, st.st_size)


def _sig_ok(before, after, nbytes):
    """¿la huella de después de escribir sirve para saber, la próxima vez, que nadie ha tocado el fichero? Todos los
    que escriben rows_cache2.json (flix_rows, expire, flix_progress.fix_rows_cache) lo hacen con el cerrojo y de forma
    atómica (fichero nuevo = inodo nuevo). Ante cualquier duda, no: el siguiente guardado lee el fichero como siempre.
      - tenía que haber fichero antes y el inodo tiene que haber cambiado (si no, el sistema no da inodos de verdad);
      - la hora tiene que tener fracción de segundo (por segundos, dos escrituras seguidas no se distinguirían);
      - el tamaño tiene que ser el de lo que acabamos de escribir."""
    return bool(before and after) and after[0] == before[0] and after[1] != before[1] and \
        after[2] % 1000000000 != 0 and after[3] == nbytes


def _dumps(parts):
    """json.dumps de un dict a partir de {clave: (marca, texto JSON de la entrada)}: el mismo texto, byte a byte
    (separadores ', ' y ': ' por defecto; claves y valores con el mismo codificador). Un solo join: ~10 MB se copian
    una vez"""
    out = ["{"]
    for k, (_s, t) in parts.items():
        out += (json.dumps(k), ": ", t, ", ")
    if len(out) > 1:
        out[-1] = "}"
    else:
        out.append("}")
    return "".join(out)


def _forget():
    global _saved, _saved_sig
    _saved = _saved_sig = None


def _cache_save(keep=False):
    """guarda lo pedido por este proceso MEZCLADO con el fichero (gana lo más nuevo), con cerrojo. Antes se volcaba
    la copia entera del proceso: el Inicio, que vive toda la sesión, pisaba lo que guardaban las secciones y
    flix_progress (auditoría 22-oct B-05 / REND-04), y reescribía ~2,6 MB aunque no hubiera nada nuevo (C-04).
    keep=True: vienen más guardados enseguida (cada 4 filas). Se recuerda lo escrito y, si en el siguiente la huella
    del fichero es la misma, no se vuelve a leer ni a volcar entero: se mezcla y se purga sobre lo recordado (DAT-02).
    Sin keep (el último del lote, fetch con save) la copia se suelta: pesa tanto como el fichero"""
    global _saved, _saved_sig
    if not _dirty:
        if not keep:
            _forget()
        return
    try:
        with flix_cache.file_lock(CACHE_FILE) as lock:
            locked = getattr(lock, "fh", None) is not None
            before = _file_sig()
            parts = _saved if locked and _saved is not None and before == _saved_sig else None
            _forget()
            keys = list(_dirty)
            if parts is None:
                # como siempre: el fichero entero
                try:
                    with open(CACHE_FILE, encoding="utf-8") as fh:
                        disk = json.load(fh)
                except (OSError, ValueError):
                    disk = {}
                if not isinstance(disk, dict):
                    disk = {}
                flix_cache.merge_newer(disk, _cache, keys)
                flix_cache.purge(disk, max_age=KEEP, ages=[(TMDB_LIST, KEEP_TMDB)])
                if keep and locked:
                    parts = {k: (v[0], json.dumps(v)) for k, v in disk.items()}   # tras purge: todas con v[0]
                    text = _dumps(parts)
                else:
                    text = json.dumps(disk)
            else:
                # nadie ha escrito desde nuestro último guardado: lo recordado ES el fichero
                disk = parts
                flix_cache.merge_newer(disk, _cache, keys)
                flix_cache.purge(disk, max_age=KEEP, ages=[(TMDB_LIST, KEEP_TMDB)])
                for k in keys:
                    v = disk.get(k)
                    if v is not None and not isinstance(v, tuple):
                        disk[k] = (v[0], json.dumps(v))
                text = _dumps(disk)
            flix_cache.atomic_write(CACHE_FILE, text)
            if keep and locked:
                after = _file_sig()
                if _sig_ok(before, after, len(text) if text.isascii() else len(text.encode("utf-8"))):
                    _saved, _saved_sig = parts, after
        _dirty.difference_update(keys)
        for k, v in disk.items():               # y lo nuevo de los demás, para el siguiente peek
            if flix_cache.stamp(v) > flix_cache.stamp(_cache.get(k)):
                _cache[k] = json.loads(v[1]) if isinstance(v, tuple) else v
    except OSError as e:
        _forget()
        log("no guardo caché: %s" % e)


flush = _cache_save

def expire(rx):
    """da por caducado lo guardado cuya ruta de Palantir cumpla rx: se sigue enseñando al momento y se pide otra vez.
    Sobre el fichero y con cerrojo: merge_newer nunca deja «envejecer» una entrada. Cuántas"""
    def hit(key):
        return bool(rx.search(route_of(key[:-2] if key.endswith("#h") else key)))

    # marca de hace algo más de STATIC_TTL: caducada con cualquier ttl, pero no para la purga (KEEP). Con 0, el siguiente
    # guardado de cualquier script la borraba y Favoritos abría sin nada que enseñar (30 s; Carlos, 30-oct)
    old = time.time() - STATIC_TTL - 1

    def age(v):
        try:
            v[0] = min(float(v[0]), old)
        except (TypeError, ValueError):
            v[0] = old
    n = 0
    try:
        with flix_cache.file_lock(CACHE_FILE):
            try:
                with open(CACHE_FILE, encoding="utf-8") as fh:
                    disk = json.load(fh)
            except (OSError, ValueError):
                disk = {}
            for k, v in disk.items():
                if isinstance(v, list) and v and hit(k):
                    age(v)
                    n += 1
            if n:
                flix_cache.atomic_write(CACHE_FILE, json.dumps(disk))
    except OSError as e:
        log("no caduco caché: %s" % e)
    for k, v in (_cache or {}).items():
        if isinstance(v, list) and v and hit(k):
            age(v)
    log("caducadas %d filas guardadas (%s)" % (n, rx.pattern))
    return n


def peek(path, keep_headers=False):
    """(items guardados o None, ¿frescos?) sin llamar a Palantir"""
    hit = _cache_load().get(cache_key(path, keep_headers))
    if not hit:
        return None, False
    return _progress(hit[1]), hit_fresh(path, hit)


def is_fresh(path, keep_headers=False):
    """¿lo guardado de esa fila está fresco? Lo mismo que peek(path)[1] sin corregir el progreso de los títulos
    (refresh_stale del Inicio solo quiere saber qué filas volver a pedir; revisión 29-oct ARR-01)"""
    hit = _cache_load().get(cache_key(path, keep_headers))
    return hit_fresh(path, hit)


def k3_stale(path, home=None):
    """¿hay fila guardada y es anterior al último aviso del addon para su lista? (reloj del Inicio)"""
    hit = _cache_load().get(cache_key(path))
    return bool(hit) and k3_newer(path, hit[0], home)


def fetch(path, force=False, keep_headers=False, save=True):
    """(items, de_caché). Clave sin &reload=. Un fallo de Palantir (0 items) no machaca una caché buena."""
    key = cache_key(path, keep_headers)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and hit_fresh(path, hit):
        return _progress(hit[1]), True
    files = list_files(directory(path), PROPS, tmdb=path.startswith(TMDB_LIST))
    files = [f for f in files if f.get("label") and (keep_headers or not clean(f["label"]).endswith(":"))]
    files = tag_k3(path, files)
    if files:          # vacío = fallo de Palantir: ni machaca una caché buena ni se guarda (el reintento volvería a dar vacío)
        cache[key] = [time.time(), files]
        _dirty.add(key)
        if save:
            _cache_save()
    return _progress(files or (hit[1] if hit else [])), False


def _own_list(path):
    """ruta de lista propia: la propia ruta si ya lo es; con la prueba sin Trakt activada, la que sustituye a una
    fila de Palantir que depende de Trakt (flix_tmdblists.trakt_equivalent); '' en otro caso"""
    path = str(path or "")
    if path.startswith(TMDB_LIST):
        return path
    import flix_tmdblists
    return flix_tmdblists.trakt_equivalent(path) if flix_tmdblists.simkl_on() else ""


# con fuentes propias (sin Palantir, bloque 1; 15-nov): «Seguir viendo» y «Series en seguimiento» salen de la base de
# Ker0n3 (rutas del addon) en vez de Palantir
K3_PERSONAL = {"resume": "plugin://plugin.video.ker0n3/seguir", "follow": "plugin://plugin.video.ker0n3/siguiendo"}


K3_FAVORITES = {"WidgetPelisFavoritas": "plugin://plugin.video.ker0n3/favoritos/peliculas",
                "WidgetSeriesFavoritas": "plugin://plugin.video.ker0n3/favoritos/series"}


def k3_personal(path):
    """la ruta de Ker0n3 que sustituye a la fila de Palantir «Seguir viendo» (5101) o «Series en seguimiento» (5102)
    con fuentes propias; '' si no es una de esas o están apagadas"""
    import flix_common
    path = str(path or "")
    if not path.startswith(flix_common.PLUGIN_ROOT) or not flix_common.fuentes_on():
        return ""
    import flix_direct
    item, extra = flix_direct.decode(path)
    if item and item.get("nameWidget") in K3_FAVORITES:
        return K3_FAVORITES[item["nameWidget"]]     # fila de favoritos de Palantir: los de la base propia (bloque 3)
    return K3_PERSONAL.get(flix_direct.kind_of(item, extra), "") if item else ""


# con fuentes propias (sin Palantir, bloque 2; 16-nov): las demás filas del Inicio salen de las listas del addon
# (ruta lista/<clave>, claves de flix_tmdblists)
K3_LIST = "plugin://plugin.video.ker0n3/lista/"
_K3_MEMO = {}       # (fuentes, ruta sin &reload=) -> ruta de Ker0n3: decodificar la fila, una vez


def k3_list(path):
    """la lista de Ker0n3 que sustituye a la fila con fuentes propias: una lista de TMDB (flix://tmdb/<clave>) o una
    fila de serie de Palantir con equivalente (flix_tmdblists.k3_equivalent); '' si no la hay o están apagadas"""
    import flix_common
    path = str(path or "")
    if not path.startswith((TMDB_LIST, flix_common.PLUGIN_ROOT)) or not flix_common.fuentes_on():
        return ""
    import flix_tmdblists
    key = flix_tmdblists.k3_equivalent(path)
    return K3_LIST + key if key else ""


def k3_route(path):
    """ruta de Ker0n3 de la fila con fuentes propias (personal o lista); '' si no tiene o están apagadas"""
    import flix_common
    path = str(path or "")
    if not path.startswith((TMDB_LIST, flix_common.PLUGIN_ROOT)):
        return ""
    memo = (flix_common.fuentes_on(), flix_cache.key_of(path))
    if memo not in _K3_MEMO:
        if len(_K3_MEMO) > 500:
            _K3_MEMO.clear()
        _K3_MEMO[memo] = (k3_personal(path) or k3_list(path)) if memo[0] else ""
    return _K3_MEMO[memo]


def k3_list_key(path):
    """clave de la lista de Ker0n3 de la fila ('' si no es una): el servicio del addon avisa por clave
    (Window(home).Property(k3_list_rev_<clave>)) cuando lo que enseña esa lista cambia"""
    path = str(path or "")
    if path.startswith(K3_LIST):
        # la propia ruta del addon (lista/<clave>, …/todo, …/resto/<n>: lo que abre «Ver más»)
        import flix_common
        return re.split(r"[/?&]", path[len(K3_LIST):], maxsplit=1)[0] if flix_common.fuentes_on() else ""
    if path.startswith(CARDS):
        # fila de tarjetas (bloques 4 y 5): el addon avisa por grupo (cards.rev_key)
        import flix_common
        return "tarjetas-" + re.split(r"[/?&]", path[len(CARDS):], maxsplit=1)[0] if flix_common.fuentes_on() else ""
    route = k3_route(path)
    return route[len(K3_LIST):] if route.startswith(K3_LIST) else ""


def k3_rest(key, files, shown):
    """«Ver más» de una fila de lista de Ker0n3 (clave key) = solo el resto (Carlos, 16-nov): la tarjeta lleva a
    lista/<clave>/resto/<n>, con n = los títulos que la fila enseña (shown, lo que dejó head: 8-30 según Ajustes), y
    solo sale si la lista (files, lo que dio la ruta: hasta 30 y su «Más…») tiene más que esos. Sin clave (fila de
    Palantir, del NAS…), shown tal cual"""
    if not key:
        return shown
    titles = [f for f in shown if not is_more(f)]
    more = [f for f in files if is_more(f)]
    if not more and sum(1 for f in files if not is_more(f)) <= len(titles):
        return titles
    card = dict(more[0]) if more else {"label": "Más…", "filetype": "directory"}
    card["file"] = "%s%s/resto/%d" % (K3_LIST, key, len(titles))
    return titles + [card]


# Aviso del addon «lo que enseña esta lista ha cambiado» (lists.signal): la propiedad k3_list_rev_<clave> de
# Window(10000) (décimas de segundo) y, para que sobreviva a un reinicio de Kodi y a que el Inicio no esté abierto,
# el fichero listas_rev.json del addon ({clave: hora}). 16-nov, S24: «En cines ahora» seguía con títulos descartados
# tras reiniciar, porque la fila guardada (6 h) era de ANTES del repaso y el aviso, solo en memoria, se había perdido
K3_REV_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/listas_rev.json")
K3_REV_EVERY = 3        # s: el fichero se relee como mucho cada tanto (lo mira el reloj del Inicio)
_K3_REV = {}


def k3_changed_at(key, home=None):
    """hora del último aviso del addon para esa lista (0 si ninguno): lo más nuevo de la propiedad y del fichero.
    Sin red; el fichero (pequeño) se lee como mucho cada K3_REV_EVERY s"""
    if not key:
        return 0
    try:
        prop = float((home or HOME).getProperty("k3_list_rev_" + key) or 0) / 10
    except (TypeError, ValueError):
        prop = 0
    now = time.monotonic()
    if "at" not in _K3_REV or now - _K3_REV["at"] >= K3_REV_EVERY:
        try:
            with open(K3_REV_FILE, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            data = {}
        _K3_REV["at"], _K3_REV["data"] = now, data if isinstance(data, dict) else {}
    try:
        disk = float(_K3_REV["data"].get(key) or 0)
    except (TypeError, ValueError):
        disk = 0
    return max(prop, disk)


def k3_newer(path, fetched_at, home=None):
    """¿el addon ha avisado de un cambio en la lista de esa fila DESPUÉS de fetched_at (cuándo se guardó la fila)?
    Entonces lo guardado ya no vale como fresco: se pinta y se vuelve a pedir"""
    key = k3_list_key(path)
    if not key:
        return False
    try:
        return float(fetched_at) < k3_changed_at(key, home)
    except (TypeError, ValueError):
        return False


def hit_fresh(path, hit, home=None):
    """¿fresca una entrada [hora, items] de la caché de filas? Dentro de su caducidad y no anterior al último aviso
    del addon para su lista. La usan la TV (peek / is_fresh / fetch) y el Inicio táctil (su caché aparte)"""
    return bool(hit) and flix_cache.is_fresh(hit, ttl=ttl_of(path)) and not k3_newer(path, hit[0], home)


def k3_orphan(path):
    """con fuentes propias, fila de Palantir sin sustituta (sagas, favoritos, lo de Trakt, menús de las secciones…) y
    con Palantir ya desinstalado: no hay a quién pedírsela. Con Palantir instalado se le sigue pidiendo, como hasta
    ahora"""
    import flix_common
    return (str(path or "").startswith(flix_common.PLUGIN_ROOT) and flix_common.fuentes_on()
            and not xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"))


def home_custom(path):
    """fila AÑADIDA al Inicio desde «Explorar Palantir…»: con fuentes propias se cambia por la lista propia que más
    se parece (flix_tmdblists.k3_guess: género, categoría o listado general), como flix://tmdb/<clave>; si no hay
    ninguna, o sin fuentes propias, tal cual. Solo el Inicio: las secciones piden sus filas como siempre (bloque 5)"""
    import flix_common
    path = str(path or "")
    if not path.startswith(flix_common.PLUGIN_ROOT) or not flix_common.fuentes_on():
        return path
    import flix_tmdblists
    key = flix_tmdblists.k3_equivalent(path) or flix_tmdblists.k3_guess(path)
    return TMDB_LIST + key if key else path


def custom_path(path):
    """fila AÑADIDA a una sección desde Palantir (bloques 4 y 5), con fuentes propias: la lista parecida (home_custom,
    como en el Inicio); '' si no la hay (Carlos, 17-nov: lo que no tiene equivalente no sale, y la migración única lo
    borra de la configuración: flix_sections.migrate_own)"""
    p = home_custom(path)
    return p if p.startswith(TMDB_LIST) else ""


K3_TRAKT_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/trakt_listas.json")


def k3_trakt_lists():
    """lo que dejó el servicio del addon sobre Trakt (trakt_lists.py): {"on": ¿en uso?, "lists": [{id, name, n}],
    "watchlist": {"pelis": n, "series": n}}. Sin fichero o ilegible: {"on": False}. Sin red"""
    try:
        with open(K3_TRAKT_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {"on": False}
    except (OSError, ValueError):
        return {"on": False}


def from_palantir(src):
    """¿sección de Palantir? Variable p3… de la skin o ruta de Palantir; no las de «Otros orígenes»"""
    src = str(src or "")
    return src.startswith("plugin://plugin.video.palantir3/") or ("://" not in src and not src.startswith("/"))


def own_menu(var):
    """con fuentes propias, las filas del menú propio de la sección (flix_sections_own): por su variable o, las
    añadidas, por su ruta de Palantir. None sin fuentes propias o si esa sección no tiene (Otros orígenes, o una
    añadida de Palantir que no se reconoce)"""
    import flix_common
    if not flix_common.fuentes_on():
        return None
    import flix_sections_own as so
    var = str(var or "")
    v = so.own_var(var, route_of(var))
    if not v:
        return None
    return so.rows_for(v, trakt=k3_trakt_lists() if v == so.TRAKT else None)


def cache_key(path, keep_headers=False):
    """clave de la caché de una fila: su ruta sin &reload=; con fuentes propias, la de Ker0n3 que la sustituye. Así lo
    guardado de Palantir para esa fila no se enseña como si fuera de Ker0n3 (sus títulos abrirían Palantir), ni al
    revés al apagar el interruptor. La usa también el Inicio táctil (flix_home.fetch / peek)"""
    return flix_cache.key_of(k3_route(path) or path, keep_headers)


def tag_k3(path, files):
    """«Series en seguimiento» de Ker0n3 (ruta siguiendo): cada serie lleva su tmdb en flix_follow, lo que con
    Palantir se lee de su ruta play_mis_serieS (follow_tmdb: etiqueta «NUEVO», «Ver más» sin repetidas)"""
    if files and (k3_personal(path) == K3_PERSONAL["follow"] or flix_cache.key_of(path) == K3_PERSONAL["follow"]):
        import flix_common
        for f in files:
            ref = flix_common.k3_ref(f.get("file")) if isinstance(f, dict) else None
            if ref and ref[0] == "tv":
                f["flix_follow"] = str(ref[1])
    return files


def directory(path, offline=False):
    """ruta que se pide a Kodi: las filas de listas de TMDB se convierten en un listado de Palantir. offline: sin red
    ni base de Palantir, con los ids guardados (menú KER0N3; flix_tmdblists.directory). Con fuentes propias: la ruta
    de Ker0n3 de la fila (k3_route) y, si no tiene y Palantir ya no está, ninguna (k3_orphan)"""
    k3 = k3_route(path)
    if k3:
        return k3
    if k3_orphan(path):
        return ""
    own = _own_list(path)
    if own:
        import flix_tmdblists
        return flix_tmdblists.directory(own, offline=offline)
    return path


def is_tmdb_row(path):
    """¿fila de lista de TMDB? (lee la base de Palantir al pedirla: espera si está ocupada, palantir_busy). Con
    fuentes propias no: sale del addon y no espera a nadie"""
    return bool(_own_list(path)) and not k3_route(path)


def list_files(directory_path, props, tmdb=False):
    """Files.GetDirectory; [] sin ruta (lista de TMDB sin títulos o sin red). tmdb: fila de lista de TMDB, fuera el
    elemento suelto que Palantir añade sin título («*» en rojo)"""
    if not directory_path:
        return []
    import flix_common
    if flix_common.is_fs(directory_path):
        return flix_common.list_fs(directory_path, props)   # carpeta del NAS, USB… (otros orígenes): fotos y vídeos
    if directory_path.startswith(flix_common.K3_ROOT) and "mpaa" not in props:
        props = list(props) + ["mpaa"]      # la edad viene en el propio título de Ker0n3 (flix_meta.complete la pone)
    # listados normales de películas y series: la skin los hace ella, sin lanzar Palantir (~2-4 s por fila en la
    # Shield). None = no es de esos, no está comprobado para esta versión de Palantir o algo no cuadra → a Palantir
    files = direct = None
    try:
        import flix_direct as direct
        files = direct.list_files(directory_path)
    except Exception as e:  # noqa: BLE001
        log("listado directo: %s" % e)
    if files is None:
        files = list_dir(directory_path, props)     # JSON-RPC común (DAT-20); respuesta que no es JSON: ValueError, como antes
        if direct is not None:
            direct.shadow(directory_path, files)    # con su respuesta en la mano se compara con la directa (sin coste de Palantir)
    return [f for f in files if clean(f.get("label") or "").strip("* ")] if tmdb else files


def _progress(files):
    """progreso real de Palantir (watched.db) en vez del que trae la caché (flix_progress.py)"""
    try:
        import flix_progress
        flix_progress.fix_files(files)
    except Exception as e:  # noqa: BLE001
        log("progreso: %s" % e)
    return files


def is_generic(f):
    a = f.get("art") or {}
    art = urllib.parse.unquote(a.get("poster") or a.get("thumb") or "")   # llega como image://special%3a%2f%2f…
    return not art or GENERIC_ART in art


def is_more(f):
    """último elemento "Más…/More…" de un listado (página siguiente). El nombre entero: «Más que rivales» es una serie"""
    return f.get("filetype") == "directory" and re.fullmatch(
        r"(m[aá]s|more|siguiente|next)[\s.…>]*", clean(f.get("label")).strip().lower()) is not None


FOLLOW_ACTION = "\"action\": 'play_mis_serieS'"
FOLLOW_TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')


def follow_tmdb(f):
    """tmdb de una serie de «Series en seguimiento» (cualquier página o sección); None si no lo es. Aquí y no en
    flix_progress para que las secciones lo miren sin cargar ese módulo"""
    if isinstance(f, dict) and f.get("flix_follow"):
        return str(f["flix_follow"])        # serie de la ruta siguiendo de Ker0n3 (tag_k3)
    if not isinstance(f, dict) or not str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/"):
        return None
    try:
        route = decode_route(f["file"])
    except Exception:  # noqa: BLE001
        return None
    m = FOLLOW_TMDB_RE.search(route) if FOLLOW_ACTION in route else None
    return m.group(1) if m else None


def head(files, n, more=True):
    """los n primeros de un listado y su «más…» al final aunque quede fuera del recorte (tarjeta «Ver más»);
    more=False lo quita (Top 10)"""
    out = [f for f in files[:n] if more or not is_more(f)]
    if more and len(files) > n and files and not any(map(is_more, files)):
        import flix_common
        if flix_common.is_fs(files[0].get("file")):
            # carpeta del NAS más larga que la fila: su «Ver más» abre la carpeta entera (flix_section.more_rows)
            return out + [{"label": "Más…", "file": flix_common.parent_of(files[0]["file"]), "filetype": "directory"}]
    return out + [f for f in files[n:] if is_more(f)][:1] if more else out


def is_search(label):
    l = label.lower().replace("í", "i")
    return "titulo" in l or "title" in l or l.startswith("buscar") or l.startswith("search")


def menu_path(var):
    """ruta del menú de una sección (variable p3… del skin o ruta de Palantir); '' si no hay"""
    if is_fs(var):
        return var                  # carpeta del NAS, USB… añadida como sección (otros orígenes)
    path = var if var.startswith("plugin://") else skin_var(var)
    return path if path.startswith("plugin://") else ""


def live_stale(var):
    """¿es un menú que cambia (LIVE_MENUS: Favoritos, Listas Trakt) con lo guardado caducado? Entonces la sección se
    pinta ya con lo guardado (section_rows con live_later) y después pide el menú a Palantir (force) y corrige las
    filas (revisión 29-oct APA-01: «Cargando Favoritos…» 11 s esperando el menú, con las filas en la caché)"""
    if var not in LIVE_MENUS or own_menu(var) is not None:
        return False                # menú propio: no hay menú de Palantir que volver a pedir
    path = menu_path(var)
    if not path:
        return False
    menu, fresh = peek(path, keep_headers=True)
    return bool(menu) and not fresh


def section_rows(var, stale_ok=False, live_later=False, force=False):
    """[{label, path, kind}] de la sección (en el orden del menú de Palantir). var: variable p3… del skin o ruta de
    Palantir (secciones añadidas en Ajustes → Secciones del menú). stale_ok: vale el menú guardado aunque esté
    caducado (cambia muy poco). Los de LIVE_MENUS caducados se piden otra vez, salvo con live_later (el que llama
    pinta lo guardado y luego pide el menú con force=True). force: el menú de Palantir, sin mirar lo guardado.
    Con fuentes propias (bloques 4 y 5): el menú propio (own_menu), sin pedir nada; una sección de Palantir sin
    equivalente no tiene filas"""
    own = own_menu(var)
    if own is not None:
        return own
    import flix_common
    if flix_common.fuentes_on() and from_palantir(var):
        return []
    path = menu_path(var)
    if not path:
        return []
    menu, fresh = peek(path, keep_headers=True) if stale_ok and not force else (None, False)
    if menu and not fresh and var in LIVE_MENUS and not live_later:
        menu = None                 # Favoritos: las cuentas (y qué categorías tienen algo) cambian
    asked = not menu
    if asked:
        menu, _ = fetch(path, keep_headers=True, force=force)
    if is_fs(path):
        return folder_rows(path, menu)
    out, group = [], ""
    groups = set()
    for f in menu:
        lab = clean(f.get("label"))
        if not lab:
            continue
        if lab.endswith(":"):
            group = "Series" if "serie" in lab.lower() else "Películas"
            groups.add(group)
            continue
        if is_search(lab) or f.get("filetype") != "directory":
            continue
        m = COUNT_RE.match(lab)
        if m:
            if m.group(2) == "0":
                continue            # categoría vacía: sin fila
            lab = m.group(1)
        act = action_of(f.get("file", ""))
        if act in SKIP_ACTIONS:
            continue                # «Añadir lista nueva...» de Trakt
        kind = "list" if act in ("listado_peliculaS", "listado_serieS", "listado_trakt") else "coll"
        out.append({"label": lab, "path": f["file"], "kind": kind, "group": group})
    # etiquetas repetidas (p. ej. "Por orden alfabético" en pelis y en series) llevan el grupo detrás
    names = [r["label"] for r in out]
    for r in out:
        if names.count(r["label"]) > 1 and r["group"]:
            r["label"] = "%s · %s" % (r["label"], r["group"])
    # una línea cuando se pide el menú a Palantir o si las filas han cambiado: la vista previa del menú lateral llama
    # aquí (dos veces) en cada parada del foco y apuntaba todas las filas cada vez (revisión 7-nov PY-15)
    line = "sección %s: %d filas (%s)" % (var, len(out), ", ".join("%s[%s]" % (r["label"], r["kind"]) for r in out))
    if asked or _SECTION_LOGGED.get(var) != line:
        _SECTION_LOGGED[var] = line
        log(line)
    return out


def folder_rows(path, menu):
    """sección hecha de una carpeta del NAS (Carlos, 13-nov: «NAS» con las fotos de la boda): una fila por subcarpeta,
    con sus fotos y vídeos, y delante otra con lo suelto de la propia carpeta si lo hay"""
    out = [{"label": f["label"], "path": f["file"], "kind": "list", "group": ""}
           for f in menu if f.get("filetype") == "directory" and f.get("file")]
    if any(f.get("filetype") != "directory" for f in menu):
        name = re.sub(r".*[/\\]", "", path.rstrip("/\\")) or path
        out.insert(0, {"label": name, "path": path, "kind": "list", "group": ""})
    return out


_SECTION_LOGGED = {}     # var -> última línea apuntada de section_rows (por intérprete)
