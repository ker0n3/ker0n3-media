"""Filas del Inicio con listas de TMDB (tendencias, populares, por plataforma en España, por género…) hechas de títulos de Palantir.

La fila se guarda con una ruta propia, flix://tmdb/<lista> (editor del Inicio: «Añadir fila» → «Listas de TMDB»).
Al pedirla (flix_rows.fetch, flix_home.live de la táctil) directory() la convierte en un listado de Palantir: su base
de contenido (script.module/settings.xml, SQLite) tiene la columna tmdb en pelis y series y sus rutas son consultas
SQL, así que se fabrica «estos tmdb, en el orden de TMDB» sobre las vistas generales v_pelis / v_series (todas las
categorías, solo lo que tiene enlaces). Lo que Palantir no tiene no sale (estrenos aún en cines, p. ej.).

Caché por aparato (tmdblists.json en addon_data de la skin): 6 h; error de red 10 min. Carlos, 23-oct."""
import json
import os
import re
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import TMDB_KEY, atomic_write, encode_route  # noqa: E402

PREFIX = "flix://tmdb/"
API = "https://api.themoviedb.org/3/"
TTL = 6 * 3600
ERR_TTL = 600
PAGES = 3                   # 60 títulos de TMDB: Palantir suele tener la mitad o más
TIMEOUT = 8
PROVIDERS = (("netflix", "Netflix", "8"), ("prime", "Prime Video", "119"), ("disney", "Disney+", "337"),
             ("max", "HBO Max", "1899"), ("apple", "Apple TV+", "350"), ("movistar", "Movistar Plus+", "2241|149"),
             ("skyshowtime", "SkyShowtime", "1773"), ("filmin", "Filmin", "63"))

# clave: (nombre en el editor, movie|tv, endpoint, parámetros extra)
LISTS = [
    ("tendencias-series-semana", "Tendencias de la semana · Series", "tv", "trending/tv/week", {}),
    ("tendencias-pelis-semana", "Tendencias de la semana · Películas", "movie", "trending/movie/week", {}),
    ("tendencias-series-hoy", "Tendencias de hoy · Series", "tv", "trending/tv/day", {}),
    ("tendencias-pelis-hoy", "Tendencias de hoy · Películas", "movie", "trending/movie/day", {}),
    ("populares-series", "Populares · Series", "tv", "tv/popular", {"region": "ES"}),
    ("populares-pelis", "Populares · Películas", "movie", "movie/popular", {"region": "ES"}),
    ("valoradas-series", "Mejor valoradas · Series", "tv", "tv/top_rated", {}),
    ("valoradas-pelis", "Mejor valoradas · Películas", "movie", "movie/top_rated", {}),
    ("emision-series", "Series en emisión", "tv", "tv/on_the_air", {}),
    ("cines-pelis", "En cines ahora", "movie", "movie/now_playing", {"region": "ES"}),
] + [
    ("%s-%s" % (key, k), "Populares en %s · %s" % (name, lab), kind, "discover/" + kind,
     {"watch_region": "ES", "with_watch_providers": pid, "sort_by": "popularity.desc"})
    for key, name, pid in PROVIDERS for k, lab, kind in (("series", "Series", "tv"), ("pelis", "Películas", "movie"))
]
# géneros de TMDB (ids de /genre/movie/list y /genre/tv/list; las series no tienen Suspense ni Terror). Populares
# del género con un mínimo de votos: sin él salían títulos desconocidos que Palantir no tiene (Carlos, 23-oct)
GENRES = {
    "movie": (("accion", "Acción", "28"), ("aventura", "Aventura", "12"), ("animacion", "Animación", "16"),
              ("comedia", "Comedia", "35"), ("crimen", "Crimen", "80"), ("documental", "Documental", "99"),
              ("drama", "Drama", "18"), ("familia", "Familia", "10751"), ("fantasia", "Fantasía", "14"),
              ("historia", "Historia", "36"), ("terror", "Terror", "27"), ("musica", "Música", "10402"),
              ("misterio", "Misterio", "9648"), ("romance", "Romance", "10749"),
              ("ciencia-ficcion", "Ciencia ficción", "878"), ("suspense", "Suspense", "53"),
              ("belica", "Bélica", "10752"), ("western", "Western", "37")),
    "tv": (("accion", "Acción y aventura", "10759"), ("animacion", "Animación", "16"), ("comedia", "Comedia", "35"),
           ("crimen", "Crimen", "80"), ("documental", "Documental", "99"), ("drama", "Drama", "18"),
           ("familia", "Familia", "10751"), ("infantil", "Infantil", "10762"), ("misterio", "Misterio", "9648"),
           ("ciencia-ficcion", "Ciencia ficción y fantasía", "10765"), ("belica", "Bélica y política", "10768"),
           ("western", "Western", "37")),       # Reality fuera: Palantir apenas tiene (6 de 60, 23-oct)
}
MIN_VOTES = {"movie": "200", "tv": "50"}
GENRE_LISTS = [
    ("genero-%s-%s" % (k, slug), "%s · %s" % (name, lab), kind, "discover/" + kind,
     {"with_genres": gid, "sort_by": "popularity.desc", "vote_count.gte": MIN_VOTES[kind]})
    for k, lab, kind in (("pelis", "Películas", "movie"), ("series", "Series", "tv")) for slug, name, gid in GENRES[kind]
]
LISTS += GENRE_LISTS
BY_KEY = {k: (label, kind, ep, extra) for k, label, kind, ep, extra in LISTS}
# apartados del editor («Añadir fila» → «Listas de TMDB…» → apartado → lista)
GROUPS = [
    ("Tendencias y populares", [x[0] for x in LISTS[:10]]),
    ("Por plataforma", [x[0] for x in LISTS[10:10 + 2 * len(PROVIDERS)]]),
    ("Por género · Películas", [x[0] for x in GENRE_LISTS if x[2] == "movie"]),
    ("Por género · Series", [x[0] for x in GENRE_LISTS if x[2] == "tv"]),
]

VIEWS = {   # columnas tal cual las piden las rutas de búsqueda de Palantir (flix_search.direct_route)
    "movie": ("listado_peliculaS", "movies", "v_pelis",
              "titulo,fecha,plot,poster,fondo,audio,calidad,tmdb,duration,mpaa,genero, trailer, clearlogo, rating, categoria"),
    "tv": ("listado_serieS", "tvshows", "v_series",
           "titulo,fecha,plot,poster,fondo,tmdb,audio,mpaa,genero, trailer, clearlogo, rating, categoria"),
}


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_tmdblists] %s" % msg, xbmc.LOGINFO)
    except ImportError:
        pass


def is_list(path):
    return str(path or "").startswith(PREFIX)


def key_of(path):
    """clave de la lista de una ruta flix://tmdb/<clave>[&reload=…]; '' si no es una"""
    if not is_list(path):
        return ""
    return re.split(r"[&?]", path[len(PREFIX):], maxsplit=1)[0]


def path_of(key):
    return PREFIX + key


def label_of(path):
    return BY_KEY.get(key_of(path), ("",))[0]


def route(kind, tmdb_ids, label=""):
    """ruta de Palantir con esos títulos, en ese orden (solo los que tenga en su base); '' sin ids"""
    ids = [int(i) for i in tmdb_ids if str(i).isdigit()]
    if not ids or kind not in VIEWS:
        return ""
    action, content, view, cols = VIEWS[kind]
    order = " ".join("WHEN %d THEN %d" % (t, n) for n, t in enumerate(ids))
    sql = "SELECT %s FROM %s WHERE tmdb IN (%s) ORDER BY CASE tmdb %s END;" % (
        cols, view, ",".join(str(i) for i in ids), order)
    label = label.replace("'", " ")
    return encode_route('{"action": \'%s\', "content": \'%s\', "fanart": \'\', "icon": \'\', "label": \'%s\', '
                        '"limitItemList": 53, "page": 0, "plot": \'\', "sql": "%s"}' % (action, content, label, sql))


def fetch_ids(key, opener=None):
    """ids de TMDB de la lista (PAGES páginas). Excepción = red."""
    import urllib.request
    opener = opener or urllib.request.urlopen
    label, kind, ep, extra = BY_KEY[key]
    out = []
    for page in range(1, PAGES + 1):
        q = dict(extra, api_key=TMDB_KEY, language="es-ES", page=page)
        req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q),
                                     headers={"User-Agent": "Ker0n3Media-skin"})
        with opener(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
        out += [x["id"] for x in data.get("results") or [] if x.get("id") and x["id"] not in out]
        if page >= (data.get("total_pages") or 1):
            break
    return out


def cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/tmdblists.json" % xbmc.getSkinDir())


def _load(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def ids_of(key, path=None, opener=None, now=time.time):
    """ids de la lista con caché (TTL; si TMDB no responde, lo último que hubo y se reintenta en ERR_TTL)"""
    path = path or cache_path()
    d, t = _load(path), now()
    hit = d.get(key)
    if isinstance(hit, list) and len(hit) == 3:
        ts, ids, ok = hit
        if t - ts < (TTL if ok else ERR_TTL):
            return ids
    else:
        ids = []
    try:
        ids, ok = fetch_ids(key, opener), True
    except Exception as e:  # noqa: BLE001
        log("TMDB no responde (%s): %s" % (key, e))
        ok = False
    d[key] = [t, ids, ok]
    try:
        atomic_write(path, json.dumps(d))
    except OSError as e:
        log("no guardo la caché: %s" % e)
    return ids


def directory(path, cache=None, opener=None, now=time.time):
    """ruta que hay que pedir a Kodi: la de Palantir si es una lista de TMDB (o '' si no hay títulos); si no, tal cual"""
    key = key_of(path)
    if not key:
        return path
    if key not in BY_KEY:
        log("lista desconocida: %s" % key)
        return ""
    label, kind = BY_KEY[key][:2]
    return route(kind, ids_of(key, cache, opener, now), label)
