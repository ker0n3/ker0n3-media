"""Secciones del menú (barra lateral TV, tarjetas táctiles) y filas de cada sección, por aparato (Carlos, 21-oct).
Lógica pura (sin xbmc): la usan flix_sections.py (editor y propiedades del menú), flix_section.py (TV) y
flix_home.py (táctil). Fichero: special://profile/addon_data/<skin>/sections.json
  {"sections": [{"key", "label", "on", "kind": "rows"|"list", "src": variable p3… o ruta, "icon",
                 "rows": {"order": [etiquetas], "off": [etiquetas]}}]}
Inicio no está aquí: siempre primero. Sin fichero = las 7 de siempre (y las ocultas con flix_hide_<clave>)."""

MAX_SECTIONS = 14       # huecos fijos de la barra de la TV (Home.xml, lista 9000)
TOUCH_MAX = 7           # tarjetas que caben en la fila táctil (no se desplaza)

DEFAULTS = [
    {"key": "peliculas", "label": "Películas", "kind": "rows", "src": "p3Peliculas", "icon": "flix/icons/peliculas.png"},
    {"key": "series", "label": "Series", "kind": "rows", "src": "p3Series", "icon": "flix/icons/series.png"},
    {"key": "anime", "label": "Anime", "kind": "rows", "src": "p3Anime", "icon": "flix/icons/anime.png"},
    {"key": "dibujos", "label": "Dibujos", "kind": "rows", "src": "p3Dibujos", "icon": "flix/icons/dibujos.png"},
    {"key": "documentales", "label": "Documentales", "kind": "rows", "src": "p3Documentales",
     "icon": "flix/icons/documentales.png"},
    {"key": "trakt", "label": "Trakt", "kind": "list", "src": "p3PathTrakt", "icon": "flix/icons/trakt.png"},
    {"key": "favoritos", "label": "Favoritos", "kind": "list", "src": "p3Favoritos", "icon": "flix/icons/favoritos.png"},
]
_DEF = {d["key"]: d for d in DEFAULTS}
# entradas del menú principal de Palantir que ya son secciones de serie, o que no se ofrecen
SAME = {"películas": "peliculas", "series": "series", "anime": "anime", "dibujos": "dibujos",
        "documentales": "documentales", "favoritos": "favoritos", "listas trakt.tv": "trakt"}
NEVER = ("buscar",)
ICONS = {"telenovelas": "heart-handshake", "música": "music", "nuestra selección": "award", "especial": "sparkles",
         "películas no finalizadas": "circle-play", "series en seguimiento": "eye"}


def icon_for(label):
    l = (label or "").strip().lower()
    name = next((v for k, v in ICONS.items() if l.startswith(k)), "folder")
    return "flix/icons/%s.png" % name


def new_section(label, path, kind):
    # la clave viaja en RunScript(...,<clave>): sin comas ni comillas
    key = "p3:%s" % label.replace(",", " ").replace('"', "'")
    return {"key": key, "label": label, "on": True, "kind": kind, "src": path, "icon": icon_for(label),
            "rows": {"order": [], "off": []}}


def _rows(r):
    r = r if isinstance(r, dict) else {}
    return {"order": [x for x in r.get("order") or [] if isinstance(x, str)],
            "off": [x for x in r.get("off") or [] if isinstance(x, str)]}


def default_conf(hidden):
    return {"sections": [dict(d, on=d["key"] not in hidden, rows={"order": [], "off": []}) for d in DEFAULTS]}


def normalize(raw):
    if not isinstance(raw, dict) or not isinstance(raw.get("sections"), list):
        return default_conf(set())
    out, seen = [], set()
    for s in raw["sections"]:
        if not isinstance(s, dict) or s.get("key") in seen:
            continue
        k = s.get("key")
        if k in _DEF:
            out.append(dict(_DEF[k], on=s.get("on", True) is not False, rows=_rows(s.get("rows"))))
        elif isinstance(k, str) and k.startswith("p3:") and s.get("src") and s.get("kind") in ("rows", "list"):
            lab = s.get("label") or k[3:]
            out.append({"key": k, "label": lab, "on": s.get("on", True) is not False, "kind": s["kind"],
                        "src": s["src"], "icon": icon_for(lab), "rows": _rows(s.get("rows"))})   # icono por nombre: sigue a la tabla
        else:
            continue
        seen.add(k)
    out += [dict(d, on=False, rows={"order": [], "off": []}) for d in DEFAULTS if d["key"] not in seen]
    return {"sections": out}


def active(conf):
    return [s for s in conf["sections"] if s["on"]][:MAX_SECTIONS]


def candidates(conf, root_items):
    have = {s["label"].lower() for s in conf["sections"]}
    out = []
    for it in root_items:
        l = it["label"].strip()
        low = l.lower()
        if not l or low in SAME or low in have or any(low.startswith(n) for n in NEVER):
            continue
        out.append({"label": l, "path": it["path"]})
    return out


def _ordered(labels, rconf):
    order = [l for l in rconf.get("order") or [] if l in labels]
    return order + [l for l in labels if l not in order]


def apply_rows(rows, rconf):
    by = {r["label"]: r for r in rows}
    off = set(rconf.get("off") or [])
    return [by[l] for l in _ordered(list(by), rconf) if l not in off]


def row_editor_items(rows, rconf):
    off = set(rconf.get("off") or [])
    return [(l, l not in off) for l in _ordered([r["label"] for r in rows], rconf)]
