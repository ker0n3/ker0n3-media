"""Secciones del menú: barra lateral de la TV (Home.xml, lista 9000: Inicio + 14 huecos fijos) y tarjetas de arriba de
la táctil (flix_home.py, las 7 primeras). Qué secciones salen, en qué orden y qué filas lleva cada una lo decide
flix_sections_conf (sections.json, por aparato); apply() lo copia a Window(home).Property(flix_sec<N>_*) y
flix_chip<N>, que es lo que pintan los huecos: el menú cambia al momento, sin recargar el skin.
Uso: RunScript(special://skin/scripts/flix_sections.py)              -> editor (Ajustes → Secciones del menú)
     RunScript(special://skin/scripts/flix_sections.py,apply)        -> rellena el menú (Home.xml si no lo está)
     RunScript(special://skin/scripts/flix_sections.py,open,<clave>) -> abre una sección de rejilla (Trakt, Favoritos…)"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_sections_conf  # noqa: E402

CONF_NAME = "sections.json"


def setting(key):
    """ajuste viejo (antes de sections.json) que ocultaba una sección de serie"""
    return "flix_hide_%s" % key


def hidden_now():
    import xbmc
    return {d["key"] for d in flix_sections_conf.DEFAULTS
            if xbmc.getCondVisibility("Skin.HasSetting(%s)" % setting(d["key"]))}


def conf_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/%s" % (xbmc.getSkinDir(), CONF_NAME))


def load_conf():
    import json
    try:
        with open(conf_path(), encoding="utf-8") as fh:
            raw = json.load(fh)
    except OSError:
        return flix_sections_conf.default_conf(hidden_now())     # sin fichero: lo de siempre (y flix_hide_<clave>)
    except ValueError as e:
        import xbmc
        xbmc.log("[flix_sections] %s ilegible (%s): secciones de serie" % (CONF_NAME, e), xbmc.LOGWARNING)
        return flix_sections_conf.default_conf(set())
    return flix_sections_conf.normalize(raw)


def save_conf(conf):
    import json
    path = conf_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(conf, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def menu_props(conf, resolve=None):
    """{propiedad: valor} del menú: huecos flix_sec<N>_* (TV) y flix_chip<N> (táctil, los TOUCH_MAX primeros)"""
    act = flix_sections_conf.active(conf)
    out = {}
    for n in range(1, flix_sections_conf.MAX_SECTIONS + 1):
        s = act[n - 1] if n <= len(act) else {}
        out.update({"flix_sec%d_label" % n: s.get("label", ""), "flix_sec%d_icon" % n: s.get("icon", ""),
                    "flix_sec%d_kind" % n: s.get("kind", ""), "flix_sec%d_key" % n: s.get("key", "")})
        out["flix_chip%d" % n] = s.get("label", "") if n <= flix_sections_conf.TOUCH_MAX else ""
    return out


def apply(conf=None):
    import xbmcgui
    conf = conf or load_conf()
    home = xbmcgui.Window(10000)
    for k, v in menu_props(conf).items():
        home.setProperty(k, v)
    home.setProperty("flix_sec_ok", "1")        # Home.xml: si falta (skin recién instalado) lo pide al cargar
    return flix_sections_conf.active(conf)


def chips_props():
    """táctil: tarjetas de arriba (flix_chip<N>) = las primeras secciones activas"""
    return apply()[:flix_sections_conf.TOUCH_MAX]


def section(key, conf=None):
    """sección por clave; también por variable p3… (accesos de antes: flix_section.py,p3Dibujos,Dibujos)"""
    secs = (conf or load_conf())["sections"]
    return next((s for s in secs if s["key"] == key), None) or next((s for s in secs if s["src"] == key), None)


def src_path(s):
    """ruta de Palantir de una sección: la guardada (añadidas) o la variable p3… del skin; con los $INFO[...] que
    llevan algunas (&reload=…) ya resueltos"""
    import xbmc
    src = s.get("src", "")
    if not src.startswith("plugin://"):
        import flix_rows
        src = flix_rows.skin_var(src)
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: xbmc.getInfoLabel(m.group(1)), src)


def open_list(key):
    """sección de rejilla (Trakt, Favoritos, Series en seguimiento…): su listado en la ventana Vídeos"""
    import xbmc
    import xbmcgui
    s = section(key)
    path = src_path(s) if s else ""
    if not path:
        xbmc.log("[flix_sections] sección %s sin ruta" % key, xbmc.LOGWARNING)
        return
    xbmcgui.Window(10000).setProperty("flix_section", s["label"])     # cabecera de la ventana Vídeos
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)


PALANTIR_ROOT = "plugin://plugin.video.palantir3/"
NO_ANSWER = "Palantir no responde ahora mismo"
LIST = 100
B_UP, B_DOWN, B_TOGGLE, B_SAVE, B_RESET, B_CANCEL, B_REMOVE, B_ADD, B_ROWS = 201, 202, 203, 204, 205, 206, 207, 208, 211
A_UP, A_DOWN, A_CONTEXT = 3, 4, (101, 117)
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)
HELP = {
    ("sections", False): "OK: coger la sección y moverla con arriba / abajo (OK otra vez para soltarla)[CR]"
                         "Mantener OK: activar o desactivar · Derecha: añadir secciones de Palantir y elegir sus filas",
    ("sections", True): "Toca una sección y usa los botones. «Añadir sección» trae otras del menú de Palantir; "
                        "«Editar filas» elige qué filas salen dentro. En el móvil se ven las 7 primeras activas.",
    ("rows", False): "Filas que salen al abrir la sección, en este orden.[CR]"
                     "OK: coger y mover con arriba / abajo · Mantener OK: activar o desactivar · Guardar vuelve a las secciones",
    ("rows", True): "Filas que salen al abrir la sección, en este orden. Toca una fila y usa los botones; "
                    "«Guardar» vuelve a las secciones.",
}


def kind_of(files):
    """al añadir una sección: "rows" si su menú son submenús (filas), "list" si lista títulos (Películas no
    finalizadas, Series en seguimiento); None si Palantir no ha dado nada"""
    import flix_home_conf
    folders, titles = flix_home_conf.classify(files)
    if not folders and not titles:
        return None
    return "list" if titles > len(folders) else "rows"


def rows_conf(items):
    """[(etiqueta, encendida)] del editor de filas -> {"order", "off"} de sections.json"""
    return {"order": [l for l, _ in items], "off": [l for l, on in items if not on]}


def count_text(n, touch):
    if touch and n > flix_sections_conf.TOUCH_MAX:
        return "%d de %d · en el móvil se ven %d" % (n, flix_sections_conf.MAX_SECTIONS, flix_sections_conf.TOUCH_MAX)
    return "%d de %d secciones" % (n, flix_sections_conf.MAX_SECTIONS)


def palantir_menu(path):
    """listado de un menú de Palantir (sin caché: al añadir se quiere lo de ahora)"""
    import flix_palantir_browse
    import flix_picker
    flix_picker.busy(True)
    try:
        return flix_palantir_browse.listing(path)
    finally:
        flix_picker.busy(False)


def edit():
    """Ajustes → Secciones del menú: secciones (orden, interruptor, añadir de Palantir, quitar las añadidas) y, con
    «Editar filas», las filas de una sección en la misma ventana. Guardar escribe sections.json y cambia el menú."""
    import copy
    import json
    import xbmc
    import xbmcgui
    import xbmcvfs
    import flix_picker
    import flix_rows

    touch = xbmc.getSkinDir().endswith(".touch")

    def notify(msg, ms=2500):
        xbmcgui.Dialog().notification("Secciones del menú", msg, xbmcgui.NOTIFICATION_INFO, ms)

    class EditWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.conf = copy.deepcopy(load_conf())
            self.initial = json.dumps(self.conf, sort_keys=True)
            self.mode = "sections"
            self.sec = None                  # sección cuyas filas se editan
            self.rows = []                   # [(etiqueta, encendida)] en modo filas
            self.rows_initial = []
            self.rows_all = []               # lo que lista Palantir para la sección (Restablecer)
            self.picked, self.pick_pos, self.saved = False, -1, False

        # lista que se edita: secciones (dicts con "on") o filas ([etiqueta, encendida])
        def items(self):
            return self.conf["sections"] if self.mode == "sections" else self.rows

        def is_on(self, k):
            it = self.items()[k]
            return it["on"] if self.mode == "sections" else it[1]

        def onInit(self):
            self.lst = self.getControl(LIST)
            self.refill(0)
            self.setFocusId(LIST)

        def texts(self, k):
            it = self.items()[k]
            if self.mode == "rows":
                return it[0], ""
            note = [x for x, c in (("añadida", it["key"].startswith("p3:")), ("rejilla", it["kind"] == "list")) if c]
            return it["label"], " · ".join(note)

        def refill(self, sel):
            """lista entera: solo al cambiar de nivel o de número de filas (añadir / quitar / restablecer)"""
            self.lst.reset()
            for k in range(len(self.items())):
                li = xbmcgui.ListItem(*self.texts(k))
                li.setProperty("hidden", "" if self.is_on(k) else "1")
                self.lst.addItem(li)
            sel = max(0, min(sel, len(self.items()) - 1))
            self.lst.selectItem(sel)
            self.header()
            self.mark(sel)          # selectItem llega a la lista después: getSelectedPosition aún daría la de antes

        def paint(self, *ks):
            """filas cambiadas, en el sitio: rehacer la lista con el mando en marcha se comía la pulsación siguiente
            (al mover con OK cogido, una de cada dos)"""
            for k in ks:
                li = self.lst.getListItem(k)
                lab, lab2 = self.texts(k)
                li.setLabel(lab)
                li.setLabel2(lab2)
                li.setProperty("hidden", "" if self.is_on(k) else "1")
            self.header()

        def header(self):
            if self.mode == "sections":
                self.setProperty("title", "Secciones del menú")
                self.setProperty("add_label", "Añadir sección")
                n = len([s for s in self.conf["sections"] if s["on"]])
                self.setProperty("count_label", count_text(n, touch))
            else:
                self.setProperty("title", "Filas de %s" % self.sec["label"])
                self.setProperty("add_label", "Añadir fila")
                self.setProperty("count_label", "%d de %d filas" % (len([r for r in self.rows if r[1]]), len(self.rows)))
            self.setProperty("help", HELP[(self.mode, touch)])

        def mark(self, k=None):
            """picked + qué botones valen para la fila elegida (Quitar: solo añadidas; Editar filas: solo con filas)"""
            self.setProperty("picked", "1" if self.picked else "")
            k = self.sel() if k is None else k
            s = self.conf["sections"][k] if self.mode == "sections" and 0 <= k < len(self.conf["sections"]) else None
            self.setProperty("can_remove", "1" if s and s["key"].startswith("p3:") else "")
            self.setProperty("can_rows", "1" if s and s["kind"] == "rows" else "")

        def sel(self):
            return self.lst.getSelectedPosition()

        def move(self, step):
            k, j = self.sel(), self.sel() + step
            its = self.items()
            if 0 <= k < len(its) and 0 <= j < len(its):
                its[k], its[j] = its[j], its[k]
                self.paint(k, j)
                self.lst.selectItem(j)
                self.mark(j)

        def toggle(self):
            k = self.sel()
            if not 0 <= k < len(self.items()):
                return
            if self.mode == "rows":
                lab, on = self.rows[k]
                self.rows[k] = (lab, not on)
            else:
                s = self.conf["sections"][k]
                if not s["on"] and len(flix_sections_conf.active(self.conf)) >= flix_sections_conf.MAX_SECTIONS:
                    notify("Caben %d secciones: desactiva otra antes" % flix_sections_conf.MAX_SECTIONS)
                    return
                s["on"] = not s["on"]
            self.paint(k)
            self.mark(k)

        def remove(self):
            k = self.sel()
            if self.mode != "sections" or not 0 <= k < len(self.conf["sections"]):
                return
            s = self.conf["sections"][k]
            if not s["key"].startswith("p3:"):
                notify("Las secciones de serie no se quitan: desactívala")
                return
            del self.conf["sections"][k]
            self.refill(k)

        def add_section(self):
            if len(flix_sections_conf.active(self.conf)) >= flix_sections_conf.MAX_SECTIONS:
                notify("Caben %d secciones: desactiva otra antes" % flix_sections_conf.MAX_SECTIONS)
                return
            import flix_home_conf
            root = palantir_menu(PALANTIR_ROOT)
            folders, _ = flix_home_conf.classify(root)
            if not folders:
                notify(NO_ANSWER)
                return
            cands = flix_sections_conf.candidates(self.conf, [{"label": f["label"], "path": f["file"]} for f in folders])
            if not cands:
                notify("Ya están todas las secciones de Palantir")
                return
            c = flix_picker.pick("Añadir sección", [x["label"] for x in cands], "Entradas del menú principal de Palantir")
            if c < 0:
                return
            kind = kind_of(palantir_menu(cands[c]["path"]))
            if kind is None:
                notify(NO_ANSWER)
                return
            at = max(0, self.sel()) + 1
            self.conf["sections"].insert(at, flix_sections_conf.new_section(cands[c]["label"], cands[c]["path"], kind))
            self.refill(at)
            notify("«%s» añadida%s" % (cands[c]["label"], " (rejilla de títulos)" if kind == "list" else ""))

        def add_row(self):
            off = [k for k, (_, on) in enumerate(self.rows) if not on]
            if not off:
                notify("Ya salen todas las filas de la sección")
                return
            c = flix_picker.pick("Añadir fila", [self.rows[k][0] for k in off], "Filas de la sección que no salen ahora")
            if c < 0:
                return
            k = off[c]
            self.rows[k] = (self.rows[k][0], True)
            self.paint(k)
            self.lst.selectItem(k)
            self.mark(k)

        def open_rows(self):
            k = self.sel()
            if self.mode != "sections" or not 0 <= k < len(self.conf["sections"]):
                return
            s = self.conf["sections"][k]
            if s["kind"] != "rows":
                notify("«%s» es una rejilla de títulos: no tiene filas" % s["label"])
                return
            flix_picker.busy(True)
            try:
                rows = flix_rows.section_rows(s["src"], stale_ok=True)
            finally:
                flix_picker.busy(False)
            if not rows:
                notify(NO_ANSWER)
                return
            self.sec, self.mode = s, "rows"
            self.rows_all = [r["label"] for r in rows]
            self.rows = flix_sections_conf.row_editor_items(rows, s["rows"])
            self.rows_initial = list(self.rows)
            self.picked = False
            self.refill(0)
            self.setFocusId(LIST)                        # «Editar filas» queda atenuado en este nivel

        def close_rows(self, keep):
            if keep:
                self.sec["rows"] = rows_conf(self.rows)
            back = self.conf["sections"].index(self.sec)
            self.mode, self.sec, self.picked = "sections", None, False
            self.refill(back)

        def reset(self):
            if self.mode == "rows":
                self.rows = [(l, True) for l in self.rows_all]
            else:
                self.conf = flix_sections_conf.default_conf(set())
            self.refill(0)

        def save(self):
            if self.mode == "rows":
                self.close_rows(True)                    # las filas se guardan con la sección (Guardar de arriba)
                return
            save_conf(self.conf)
            apply(self.conf)
            self.saved = True
            self.close()

        def leave(self):
            if self.mode == "rows":
                if self.rows != self.rows_initial and \
                        not xbmcgui.Dialog().yesno("Secciones del menú", "¿Descartar los cambios de estas filas?"):
                    return
                self.close_rows(False)
                return
            if json.dumps(self.conf, sort_keys=True) != self.initial and \
                    not xbmcgui.Dialog().yesno("Secciones del menú", "¿Salir sin guardar los cambios?"):
                return
            self.close()

        def onAction(self, action):
            aid = action.getId()
            if self.getFocusId() == LIST and self.picked and aid in (A_UP, A_DOWN):
                # Kodi ya ha movido la selección: lo cogido va a la nueva posición
                its = self.items()
                new, old = self.sel(), self.pick_pos
                if 0 <= old < len(its) and new != old:
                    its.insert(new, its.pop(old))
                    self.pick_pos = new
                    self.paint(*range(min(old, new), max(old, new) + 1))
                    self.mark(new)
                return
            if self.getFocusId() == LIST and aid in A_CONTEXT:
                self.toggle()                            # mantener OK: activar / desactivar
                return
            if aid in A_BACK:
                if self.picked:
                    self.picked = False
                    self.mark()
                    return
                self.leave()
                return
            super().onAction(action)
            if self.getFocusId() == LIST:
                self.mark()                              # la selección cambió: Quitar / Editar filas

        def onClick(self, cid):
            if cid == LIST:
                if touch:
                    self.mark()                          # táctil: tocar = seleccionar; botones al lado
                    return
                self.picked = not self.picked            # OK: coger / soltar
                self.pick_pos = self.sel()
                self.mark()
            elif cid == B_UP:
                self.move(-1)
            elif cid == B_DOWN:
                self.move(1)
            elif cid == B_TOGGLE:
                self.toggle()
            elif cid == B_ADD:
                self.add_section() if self.mode == "sections" else self.add_row()
            elif cid == B_REMOVE:
                self.remove()
            elif cid == B_ROWS:
                self.open_rows()
            elif cid == B_RESET:
                self.reset()
            elif cid == B_SAVE:
                self.save()
            elif cid == B_CANCEL:
                self.leave()

    w = EditWindow("FlixSectionsEdit.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    w.doModal()
    if w.saved:
        n = len(flix_sections_conf.active(w.conf))
        notify("Secciones guardadas" + (": en el móvil se ven las %d primeras" % flix_sections_conf.TOUCH_MAX
                                        if touch and n > flix_sections_conf.TOUCH_MAX else ""), 3500)
    del w


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "open":
        open_list(sys.argv[2])
    elif len(sys.argv) > 1 and sys.argv[1] == "apply":
        apply()
    else:
        edit()
