"""Filas del Inicio con listas de TMDB (tendencias, populares, por plataforma en España, por género…) hechas de títulos de Palantir.

La fila se guarda con una ruta propia, flix://tmdb/<lista> (editor del Inicio: «Añadir fila» → «Listas de TMDB»).
Al pedirla (flix_rows.fetch, flix_home.live de la táctil) directory() la convierte en un listado de Palantir: su base
de contenido (script.module/settings.xml, SQLite) tiene la columna tmdb en pelis y series y sus rutas son consultas
SQL, así que se fabrica «estos tmdb, en el orden de TMDB» sobre las vistas generales v_pelis / v_series (todas las
categorías, solo lo que tiene enlaces). Lo que Palantir no tiene no sale (estrenos aún en cines, p. ej.).

Caché por aparato (tmdblists.json en addon_data de la skin): 6 h; error de red 10 min. Carlos, 23-oct."""
import json
import os
import re
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import TMDB_KEY, encode_route  # noqa: E402

PREFIX = "flix://tmdb/"
API = "https://api.themoviedb.org/3/"
TTL = 6 * 3600
ERR_TTL = 600
PAGES = 3                   # 60 títulos de TMDB: Palantir suele tener la mitad o más
TIMEOUT = 8
PROVIDERS = (("netflix", "Netflix", "8"), ("prime", "Prime Video", "119"), ("disney", "Disney+", "337"),
             ("max", "HBO Max", "1899"), ("apple", "Apple TV+", "350"), ("movistar", "Movistar Plus+", "2241|149"),
             ("skyshowtime", "SkyShowtime", "1773"), ("filmin", "Filmin", "63"))

# clave: (nombre en el editor, movie|tv, endpoint, parámetros extra)
LISTS = [
    ("tendencias-series-semana", "Tendencias de la semana · Series", "tv", "trending/tv/week", {}),
    ("tendencias-pelis-semana", "Tendencias de la semana · Películas", "movie", "trending/movie/week", {}),
    ("tendencias-series-hoy", "Tendencias de hoy · Series", "tv", "trending/tv/day", {}),
    ("tendencias-pelis-hoy", "Tendencias de hoy · Películas", "movie", "trending/movie/day", {}),
    ("populares-series", "Populares · Series", "tv", "tv/popular", {"region": "ES"}),
    ("populares-pelis", "Populares · Películas", "movie", "movie/popular", {"region": "ES"}),
    ("valoradas-series", "Mejor valoradas · Series", "tv", "tv/top_rated", {}),
    ("valoradas-pelis", "Mejor valoradas · Películas", "movie", "movie/top_rated", {}),
    ("emision-series", "Series en emisión", "tv", "tv/on_the_air", {}),
    ("cines-pelis", "En cines ahora", "movie", "movie/now_playing", {"region": "ES"}),
] + [
    ("%s-%s" % (key, k), "Populares en %s · %s" % (name, lab), kind, "discover/" + kind,
     {"watch_region": "ES", "with_watch_providers": pid, "sort_by": "popularity.desc"})
    for key, name, pid in PROVIDERS for k, lab, kind in (("series", "Series", "tv"), ("pelis", "Películas", "movie"))
]
# géneros de TMDB (ids de /genre/movie/list y /genre/tv/list; las series no tienen Suspense ni Terror). Populares
# del género con un mínimo de votos: sin él salían títulos desconocidos que Palantir no tiene (Carlos, 23-oct)
GENRES = {
    "movie": (("accion", "Acción", "28"), ("aventura", "Aventura", "12"), ("animacion", "Animación", "16"),
              ("comedia", "Comedia", "35"), ("crimen", "Crimen", "80"), ("documental", "Documental", "99"),
              ("drama", "Drama", "18"), ("familia", "Familia", "10751"), ("fantasia", "Fantasía", "14"),
              ("historia", "Historia", "36"), ("terror", "Terror", "27"), ("musica", "Música", "10402"),
              ("misterio", "Misterio", "9648"), ("romance", "Romance", "10749"),
              ("ciencia-ficcion", "Ciencia ficción", "878"), ("suspense", "Suspense", "53"),
              ("belica", "Bélica", "10752"), ("western", "Western", "37")),
    "tv": (("accion", "Acción y aventura", "10759"), ("animacion", "Animación", "16"), ("comedia", "Comedia", "35"),
           ("crimen", "Crimen", "80"), ("documental", "Documental", "99"), ("drama", "Drama", "18"),
           ("familia", "Familia", "10751"), ("infantil", "Infantil", "10762"), ("misterio", "Misterio", "9648"),
           ("ciencia-ficcion", "Ciencia ficción y fantasía", "10765"), ("belica", "Bélica y política", "10768"),
           ("western", "Western", "37")),       # Reality fuera: Palantir apenas tiene (6 de 60, 23-oct)
}
MIN_VOTES = {"movie": "200", "tv": "50"}
GENRE_LISTS = [
    ("genero-%s-%s" % (k, slug), "%s · %s" % (name, lab), kind, "discover/" + kind,
     {"with_genres": gid, "sort_by": "popularity.desc", "vote_count.gte": MIN_VOTES[kind]})
    for k, lab, kind in (("pelis", "Películas", "movie"), ("series", "Series", "tv")) for slug, name, gid in GENRES[kind]
]
LISTS += GENRE_LISTS
# Niños y adolescentes (Carlos, 30-oct; catálogo de Palantir comprobado: de 60, entre 39 y 60 en todas). Edad en
# España: niños «A»/7; adolescentes 12, sin terror, thriller ni crimen. Las series infantiles, con el género Infantil
_KIDS_M = {"certification_country": "ES", "certification.lte": "7", "sort_by": "popularity.desc"}
_TEEN_M = {"certification_country": "ES", "certification": "12", "without_genres": "27,53,80",
           "sort_by": "popularity.desc"}
_KIDS_T = {"with_genres": "10762", "sort_by": "popularity.desc"}
_TEEN_T = {"certification_country": "ES", "certification": "12", "without_genres": "10762,80",
           "sort_by": "popularity.desc"}
_FAM = "16|10751"                                                     # animación o familia
_NEW = {"primary_release_date.gte": "%d-01-01" % (int(time.strftime("%Y")) - 2)}
_ES = {"watch_region": "ES"}


def _m(base, **kw):
    out = dict(base)
    out.update(kw)
    return out


KIDS_LISTS = [
    ("ninos-pelis-populares", "Niños · Películas populares", "movie", "discover/movie", _m(_KIDS_M, with_genres=_FAM)),
    ("ninos-pelis-valoradas", "Niños · Películas mejor valoradas", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, sort_by="vote_average.desc", **{"vote_count.gte": "500"})),
    ("ninos-pelis-novedades", "Niños · Películas nuevas", "movie", "discover/movie", _m(_KIDS_M, with_genres=_FAM, **_NEW)),
    ("ninos-pelis-clasicos", "Niños · Clásicos", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, **{"primary_release_date.lte": "2004-12-31", "vote_count.gte": "300"})),
    ("ninos-pelis-animacion", "Niños · Películas de animación", "movie", "discover/movie", _m(_KIDS_M, with_genres="16")),
    ("ninos-pelis-aventura", "Niños · Aventuras en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="12,10751")),
    ("ninos-pelis-comedia", "Niños · Comedias en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="35,10751")),
    ("ninos-pelis-fantasia", "Niños · Fantasía en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="14,10751")),
    ("ninos-pelis-disney", "Niños · Películas en Disney+", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="337", **_ES)),
    ("ninos-pelis-netflix", "Niños · Películas en Netflix", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="8", **_ES)),
    ("ninos-pelis-prime", "Niños · Películas en Prime Video", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="119", **_ES)),
    ("ninos-series-populares", "Niños · Series populares", "tv", "discover/tv", _m(_KIDS_T)),
    ("ninos-series-valoradas", "Niños · Series mejor valoradas", "tv", "discover/tv",
     _m(_KIDS_T, sort_by="vote_average.desc", **{"vote_count.gte": "50"})),
    ("ninos-series-animacion", "Niños · Series de animación", "tv", "discover/tv", _m(_KIDS_T, with_genres="10762,16")),
    ("ninos-series-disney", "Niños · Series en Disney+", "tv", "discover/tv", _m(_KIDS_T, with_watch_providers="337", **_ES)),
    ("ninos-series-netflix", "Niños · Series en Netflix", "tv", "discover/tv", _m(_KIDS_T, with_watch_providers="8", **_ES)),
    ("ninos-anime", "Niños · Anime", "tv", "discover/tv",
     {"with_genres": "16", "with_origin_country": "JP", "certification_country": "ES", "certification.lte": "7",
      "sort_by": "popularity.desc"}),
]
TEEN_LISTS = [
    ("teen-pelis-populares", "Adolescentes · Películas populares", "movie", "discover/movie", _m(_TEEN_M)),
    ("teen-pelis-valoradas", "Adolescentes · Películas mejor valoradas", "movie", "discover/movie",
     _m(_TEEN_M, sort_by="vote_average.desc", **{"vote_count.gte": "1000"})),
    ("teen-pelis-novedades", "Adolescentes · Películas nuevas", "movie", "discover/movie", _m(_TEEN_M, **_NEW)),
    ("teen-pelis-accion", "Adolescentes · Acción y aventura", "movie", "discover/movie", _m(_TEEN_M, with_genres="28|12")),
    ("teen-pelis-scifi", "Adolescentes · Ciencia ficción y fantasía", "movie", "discover/movie",
     _m(_TEEN_M, with_genres="878|14")),
    ("teen-pelis-comedia", "Adolescentes · Comedias", "movie", "discover/movie", _m(_TEEN_M, with_genres="35")),
    ("teen-pelis-netflix", "Adolescentes · Películas en Netflix", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="8", **_ES)),
    ("teen-pelis-disney", "Adolescentes · Películas en Disney+", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="337", **_ES)),
    ("teen-pelis-prime", "Adolescentes · Películas en Prime Video", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="119", **_ES)),
    ("teen-pelis-anime", "Adolescentes · Películas anime", "movie", "discover/movie",
     _m(_TEEN_M, with_genres="16", with_origin_country="JP")),
    ("teen-series-populares", "Adolescentes · Series populares", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10759|10765|16|35")),
    ("teen-series-scifi", "Adolescentes · Series de ciencia ficción y fantasía", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10765")),
    ("teen-series-comedia", "Adolescentes · Series de comedia", "tv", "discover/tv", _m(_TEEN_T, with_genres="35")),
    ("teen-series-accion", "Adolescentes · Series de acción y aventura", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10759")),
    ("teen-series-anime", "Adolescentes · Series anime", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="16", with_origin_country="JP")),
]
LISTS += KIDS_LISTS + TEEN_LISTS
# Sin Trakt (15-nov): lo que Palantir saca de Trakt (Top 10, más vistas del mes) sale de los ficheros públicos de
# tendencias de Simkl («ordenados por número de espectadores»; sin clave ni cuenta, no gastan cupo). El endpoint de
# TMDB de cada lista es la reserva si Simkl no responde. Van al final de LISTS y fuera de GROUPS: no son para el
# editor ni para las filas al azar, solo sustituyen a las de Palantir (trakt_equivalent)
SIMKL_CDN = "https://data.simkl.in/discover/trending/"
SIMKL_MAX = 60
SIMKL_LISTS = [
    ("top10-pelis", "Top 10 películas", "movie", "trending/movie/week", {}),
    ("top10-series", "Top 10 series", "tv", "trending/tv/week", {}),
    ("masvistas-pelis-mes", "Películas más vistas este mes", "movie", "trending/movie/week", {}),
    ("masvistas-series-mes", "Series más vistas este mes", "tv", "trending/tv/week", {}),
]
SIMKL = {"top10-pelis": "movies/week_100.json", "top10-series": "tv/week_100.json",
         "masvistas-pelis-mes": "movies/month_100.json", "masvistas-series-mes": "tv/month_100.json"}
# «Recomendadas» sin Trakt: recomendaciones de TMDB de lo último que se ha visto en este aparato (last_watched); el
# endpoint de la lista (populares) es lo que sale si aún no se ha visto nada
RECOMMENDED_LISTS = [
    ("recomendadas-pelis", "Películas recomendadas", "movie", "movie/popular", {"region": "ES"}),
    ("recomendadas-series", "Series recomendadas", "tv", "tv/popular", {"region": "ES"}),
]
RECOMMENDED = {"recomendadas-pelis": "movie", "recomendadas-series": "tv"}
RECOMMENDED_SEEDS = 3       # cuántos de los últimos vistos se usan
WATCHED_DB = None           # ruta de watched.db; None = la de Palantir (las pruebas ponen la suya)
# Sin Palantir, bloque 2 (16-nov): las filas de serie del Inicio que Palantir sacaba de su catálogo (Novedades, Nuevas
# series, Series actualizadas, Anime, Dibujos, Documentales). Fechas relativas a hoy: «{hoy}» y «{hoy-N}» (N días)
# se resuelven al pedir la lista (dated). Al final de LISTS y fuera de GROUPS, como las de Simkl: ni el editor ni el
# sorteo cambian
_NO_TV = "10763,10764,10766,10767"          # noticias, reality, telenovelas y tertulias
_POP = "popularity.desc"
_3Y = {"primary_release_date.gte": "{hoy-1095}", "primary_release_date.lte": "{hoy}", "sort_by": _POP}
OWN_LISTS = [
    ("novedades-pelis", "Novedades", "movie", "discover/movie",
     {"region": "ES", "with_release_type": "4|5", "release_date.gte": "{hoy-120}", "release_date.lte": "{hoy}",
      "sort_by": _POP, "vote_count.gte": "20"}),
    ("nuevas-series", "Nuevas series", "tv", "discover/tv",
     {"first_air_date.gte": "{hoy-180}", "first_air_date.lte": "{hoy}", "sort_by": _POP, "vote_count.gte": "10",
      "without_genres": _NO_TV}),
    ("actualizadas-series", "Series actualizadas", "tv", "discover/tv",
     {"air_date.gte": "{hoy-7}", "air_date.lte": "{hoy}", "sort_by": _POP, "vote_count.gte": "50",
      "without_genres": _NO_TV}),
    ("anime-pelis", "Anime", "movie", "discover/movie",
     _m(_3Y, with_genres="16", with_original_language="ja", **{"vote_count.gte": "20"})),
    ("anime-series", "Anime · Series", "tv", "discover/tv",
     {"with_genres": "16", "with_origin_country": "JP", "sort_by": _POP, "vote_count.gte": "20"}),
    ("dibujos-pelis", "Dibujos", "movie", "discover/movie", _m(_3Y, with_genres="16,10751", **{"vote_count.gte": "20"})),
    ("dibujos-series", "Dibujos · Series", "tv", "discover/tv",
     {"with_genres": "16,10762", "sort_by": _POP, "vote_count.gte": "20"}),
    ("documentales-pelis", "Documentales", "movie", "discover/movie", _m(_3Y, with_genres="99", **{"vote_count.gte": "10"})),
    ("documentales-series", "Documentales · Series", "tv", "discover/tv",
     {"with_genres": "99", "sort_by": _POP, "vote_count.gte": "10"}),
]
OWN = {x[0] for x in OWN_LISTS}
LISTS += SIMKL_LISTS + RECOMMENDED_LISTS + OWN_LISTS
BY_KEY = {k: (label, kind, ep, extra) for k, label, kind, ep, extra in LISTS}
# apartados del editor («Añadir fila» → «Listas de TMDB…» → apartado → lista)
GROUPS = [
    ("Tendencias y populares", [x[0] for x in LISTS[:10]]),
    ("Por plataforma", [x[0] for x in LISTS[10:10 + 2 * len(PROVIDERS)]]),
    ("Por género · Películas", [x[0] for x in GENRE_LISTS if x[2] == "movie"]),
    ("Por género · Series", [x[0] for x in GENRE_LISTS if x[2] == "tv"]),
    ("Niños", [x[0] for x in KIDS_LISTS]),
    ("Adolescentes", [x[0] for x in TEEN_LISTS]),
]

VIEWS = {   # columnas tal cual las piden las rutas de búsqueda de Palantir (flix_search.direct_route)
    "movie": ("listado_peliculaS", "movies", "v_pelis",
              "titulo,fecha,plot,poster,fondo,audio,calidad,tmdb,duration,mpaa,genero, trailer, clearlogo, rating, categoria"),
    "tv": ("listado_serieS", "tvshows", "v_series",
           "titulo,fecha,plot,poster,fondo,tmdb,audio,mpaa,genero, trailer, clearlogo, rating, categoria"),
}


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_tmdblists] %s" % msg, xbmc.LOGINFO)
    except ImportError:
        pass


def is_list(path):
    return str(path or "").startswith(PREFIX)


def key_of(path):
    """clave de la lista de una ruta flix://tmdb/<clave>[&reload=…]; '' si no es una"""
    if not is_list(path):
        return ""
    return re.split(r"[&?]", path[len(PREFIX):], maxsplit=1)[0]


def path_of(key):
    return PREFIX + key


def label_of(path):
    return BY_KEY.get(key_of(path), ("",))[0]


def simkl_on():
    """¿prueba sin Trakt activada en este aparato? (Skin.SetBool(flix_simkl); 15-nov)"""
    import xbmc
    return bool(xbmc.getCondVisibility("Skin.HasSetting(flix_simkl)"))


_TRAKT_WIDGETS = {"WidgetTop10Pelis": "top10-%s", "WidgetTop10Series": "top10-%s"}
_TRAKT_SPECIAL = {"mas_vista_mes": "masvistas-%s-mes", "mas_vistas": "populares-%s", "recomendadas": "recomendadas-%s"}
_TRAKT_KIND = {"listado_peliculaS": "pelis", "listado_serieS": "series"}


def trakt_equivalent(path):
    """lista propia (flix://tmdb/…) que sustituye a una ruta de Palantir que él resuelve con Trakt (Top 10, más
    vistas, recomendadas); '' si la ruta no es de esas. Las de pendientes (watchlist) no: van con Simkl aparte"""
    if not path or is_list(path):
        return ""
    import flix_direct
    item, _ = flix_direct.decode(path)
    kind = _TRAKT_KIND.get((item or {}).get("action"))
    if not kind:
        return ""
    pattern = _TRAKT_WIDGETS.get(item.get("nameWidget")) or _TRAKT_SPECIAL.get(item.get("especial"))
    return PREFIX + pattern % kind if pattern else ""


# Sin Palantir, bloque 2: lista propia de cada fila de serie del Inicio. Por el widget de Palantir, por su «especial»
# de Trakt (_TRAKT_SPECIAL) o por la lista de Trakt de «Lo mejor de…» (su list_id)
_OWN_WIDGETS = {"WidgetTop10Pelis": "top10-pelis", "WidgetTop10Series": "top10-series",
                "WidgetPeliculasNovedades": "novedades-pelis", "WidgetSeriesNuevas": "nuevas-series",
                "WidgetSeriesUltimasActualizadas": "actualizadas-series", "WidgetAnimeNovedades": "anime-pelis",
                "WidgetDibujosNovedades": "dibujos-pelis", "WidgetDocumentalesNovedades": "documentales-pelis"}
_OWN_TRAKT = {"best-movies-on-netflix": "netflix-pelis", "disney": "disney-pelis", "amazon-prime-video": "prime-pelis",
              "hbo-movies": "max-pelis", "netflix-tv-shows-series-2021-2025": "netflix-series",
              "apple-tv-shows-series-2021-2025": "apple-series"}
_OWN_VIEWS = {("pelis", "anime"): "anime-pelis", ("series", "anime"): "anime-series",
              ("pelis", "dibujo"): "dibujos-pelis", ("series", "dibujo"): "dibujos-series",
              ("pelis", "documental"): "documentales-pelis", ("series", "documental"): "documentales-series"}
_LIST_ID = re.compile(r'"list_id"\s*:\s*"([^"]+)"')
_GENRE_SQL = re.compile(r"genero\s+(?:REGEXP|LIKE)\s+[\"']%?([^\"'%]+)", re.I)
_VIEW_SQL = re.compile(r"v_(?:pelis|series)_(\w+)", re.I)
_NO_GUESS = re.compile(r"coleccion|INICIAL\s*\(|calidad\s+REGEXP|fecha\s+like|tmdb\s+in\s*\(|enlaces_", re.I)


def k3_equivalent(path):
    """clave de la lista propia que sustituye sin Palantir a esa fila: la de una lista de TMDB (flix://tmdb/<clave>)
    o la de una fila de serie del Inicio (Top 10, más vistas, recomendadas, Novedades…, «Lo mejor de…»); '' si no
    tiene (las personales van aparte: flix_rows.k3_personal)"""
    if not path:
        return ""
    if is_list(path):
        return key_of(path) if key_of(path) in BY_KEY else ""
    import flix_direct
    item, _ = flix_direct.decode(path)
    if not item:
        return ""
    if item.get("nameWidget") in _OWN_WIDGETS:
        return _OWN_WIDGETS[item["nameWidget"]]
    kind = _TRAKT_KIND.get(item.get("action"))
    if kind and item.get("especial") in _TRAKT_SPECIAL:
        return _TRAKT_SPECIAL[item["especial"]] % kind
    if item.get("action") == "listado_trakt":
        m = _LIST_ID.search(str(item.get("sql") or ""))
        return _OWN_TRAKT.get(m.group(1), "") if m else ""
    return ""


def _norm(s):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", str(s).lower()) if unicodedata.category(c) != "Mn").strip()


def _genre_slug(kind, name):
    """clave del género de TMDB que corresponde a un género de Palantir («Acción» → accion; en series «Acción y
    aventura»); '' si TMDB no lo tiene para ese tipo"""
    n = _norm(name)
    for slug, label, _gid in GENRES[kind]:
        lab = _norm(label)
        if n in (lab, slug.replace("-", " ")) or lab.startswith(n + " "):
            return slug
    return ""


def k3_guess(path):
    """para las filas que el usuario añadió al Inicio desde «Explorar Palantir…»: la lista propia que más se parece
    a ese listado de Palantir, mirando su consulta. Por género → genero-…; categoría Anime / Dibujo / Documental → la
    suya; listado general → populares. '' si no hay nada parecido (sagas, por año, por letra, por calidad, favoritos,
    lo de Trakt): esa fila no tiene sustituta"""
    import flix_direct
    item, _ = flix_direct.decode(path)
    kind = _TRAKT_KIND.get((item or {}).get("action"))
    if not kind or item.get("especial") or item.get("sub_categoria") or item.get("isWidget"):
        return ""
    sql = str(item.get("sql") or "")
    if not sql or _NO_GUESS.search(sql):
        return ""
    g = _GENRE_SQL.search(sql)
    if g:
        slug = _genre_slug("movie" if kind == "pelis" else "tv", g.group(1))
        return "genero-%s-%s" % (kind, slug) if slug else ""
    v = _VIEW_SQL.search(sql)
    return _OWN_VIEWS.get((kind, v.group(1).lower() if v else ""), "populares-%s" % kind)


def route(kind, tmdb_ids, label=""):
    """ruta de Palantir con esos títulos, en ese orden (solo los que tenga en su base); '' sin ids"""
    ids = [int(i) for i in tmdb_ids if str(i).isdigit()]
    if not ids or kind not in VIEWS:
        return ""
    action, content, view, cols = VIEWS[kind]
    order = " ".join("WHEN %d THEN %d" % (t, n) for n, t in enumerate(ids))
    sql = "SELECT %s FROM %s WHERE tmdb IN (%s) ORDER BY CASE tmdb %s END;" % (
        cols, view, ",".join(str(i) for i in ids), order)
    label = label.replace("'", " ")
    return encode_route('{"action": \'%s\', "content": \'%s\', "fanart": \'\', "icon": \'\', "label": \'%s\', '
                        '"limitItemList": 53, "page": 0, "plot": \'\', "sql": "%s"}' % (action, content, label, sql))


_DATE_RE = re.compile(r"\{hoy(?:-(\d+))?\}")


def dated(extra, today=None):
    """los parámetros de una lista con sus fechas relativas resueltas: «{hoy}» y «{hoy-N}» → AAAA-MM-DD"""
    import datetime
    today = today or datetime.date.today()

    def sub(m):
        return (today - datetime.timedelta(days=int(m.group(1) or 0))).isoformat()
    return {k: _DATE_RE.sub(sub, v) if isinstance(v, str) else v for k, v in (extra or {}).items()}


def _results(ep, opener, pages=2, extra=None):
    """resultados (tal cual los da TMDB) de un endpoint, en es-ES, hasta pages páginas y sin repetir id.
    Excepción = red"""
    import urllib.request
    out, seen = [], set()
    for page in range(1, pages + 1):
        q = dict(dated(extra), api_key=TMDB_KEY, language="es-ES", page=page)
        req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q),
                                     headers={"User-Agent": "Ker0n3Media-skin"})
        with opener(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
        for x in data.get("results") or []:
            if isinstance(x, dict) and x.get("id") and x["id"] not in seen:
                seen.add(x["id"])
                out.append(x)
        if page >= (data.get("total_pages") or 1):
            break
    return out


def _pages(ep, opener, pages=2, extra=None):
    """ids de un endpoint de TMDB (es-ES), hasta pages páginas. Excepción = red"""
    return [x["id"] for x in _results(ep, opener, pages, extra)]


def _watched_db():
    if WATCHED_DB:
        return WATCHED_DB
    import flix_common
    return flix_common.watched_path()


def last_watched(kind, db_path=None, n=RECOMMENDED_SEEDS):
    """los n títulos (película o serie) tocados más recientemente según watched.db de Palantir, el último primero.
    Sin base o ilegible: []"""
    import sqlite3
    db_path = db_path or _watched_db()
    if not os.path.exists(db_path):
        return []
    sql = ("SELECT tmdb_id FROM movies_watched ORDER BY lastPlayed DESC LIMIT ?" if kind == "movie" else
           "SELECT tmdb_id FROM episodes_watched GROUP BY tmdb_id ORDER BY MAX(lastPlayed) DESC LIMIT ?")
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=5)
        try:
            return [int(r[0]) for r in con.execute(sql, (n,))]
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("no leo lo último visto: %s" % e)
        return []


def _recommended(key, opener):
    """recomendaciones de TMDB de lo último visto, alternando una de cada título, sin repetir y sin lo ya visto ni
    los propios títulos de partida; sin nada visto (o sin resultados), el endpoint de la lista. Excepción = red"""
    label, kind, ep, extra = BY_KEY[key]
    db = _watched_db()
    seeds = last_watched(kind, db)
    pools = [_pages("%s/%d/recommendations" % (kind, s), opener, 1) for s in seeds]
    mixed = []
    for i in range(max([len(p) for p in pools] or [0])):
        for p in pools:
            if i < len(p) and p[i] not in mixed and p[i] not in seeds:
                mixed.append(p[i])
    seen = seen_ids(kind, mixed, db)
    mixed = [i for i in mixed if i not in seen]
    return mixed or _pages(ep, opener, PAGES, extra)


def _simkl_ids(path, opener):
    """ids de TMDB de un fichero de tendencias de Simkl, en su orden y sin repetidos. Excepción = red"""
    import urllib.request
    req = urllib.request.Request(SIMKL_CDN + path, headers={"User-Agent": "Ker0n3Media-skin"})
    with opener(req, timeout=TIMEOUT) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "[]")
    out = []
    for x in data if isinstance(data, list) else []:
        t = str(((x if isinstance(x, dict) else {}).get("ids") or {}).get("tmdb") or "")
        if t.isdigit() and int(t) not in out:
            out.append(int(t))
    return out[:SIMKL_MAX]


def fetch_ids(key, opener=None):
    """ids de TMDB de la lista (PAGES páginas). Las de Simkl, de su fichero; si no responde o viene sin títulos,
    de su endpoint de TMDB. Excepción = red."""
    import urllib.request
    opener = opener or urllib.request.urlopen
    label, kind, ep, extra = BY_KEY[key]
    if key in SIMKL:
        try:
            ids = _simkl_ids(SIMKL[key], opener)
            if ids:
                return ids
            log("Simkl sin títulos (%s): uso TMDB" % key)
        except Exception as e:  # noqa: BLE001
            log("Simkl no responde (%s): %s; uso TMDB" % (key, e))
    if key in RECOMMENDED:
        return _recommended(key, opener)
    return _pages(ep, opener, PAGES, extra)


def _entry(x, kind):
    """lo que una fila necesita de un resultado de lista de TMDB, sin más peticiones (las imágenes, como ruta de TMDB)"""
    date = str(x.get("release_date") or x.get("first_air_date") or "")
    return {"tmdb": int(x["id"]), "kind": kind, "title": x.get("title") or x.get("name") or "",
            "year": int(date[:4]) if date[:4].isdigit() else 0, "premiered": date, "plot": x.get("overview") or "",
            "poster": x.get("poster_path") or "", "fanart": x.get("backdrop_path") or "",
            "rating": float(x.get("vote_average") or 0)}


def fetch_entries(key, opener=None):
    """la lista para Ker0n3 (sin Palantir, bloque 2): [{tmdb, kind, título, año, sinopsis, carátula, fondo, nota}] en
    su orden. Las de Simkl y las recomendadas solo traen {tmdb, kind} (su ficha la pone el addon). Excepción = red"""
    import urllib.request
    opener = opener or urllib.request.urlopen
    label, kind, ep, extra = BY_KEY[key]
    if key in SIMKL or key in RECOMMENDED:
        return [{"tmdb": int(i), "kind": kind} for i in fetch_ids(key, opener)]
    return [_entry(x, kind) for x in _results(ep, opener, PAGES, extra)]


MIN_SIMILAR = 12            # «Ver similares»: con menos que tenga Palantir, se piden más páginas a TMDB
ANIMATION = 16              # género «Animación» (pelis y series)
KIDS = {"movie": 10751, "tv": 10762}            # «Familia» / «Kids»
MIN_VOTES = {"movie": 40, "tv": 15}             # por debajo, relleno desconocido (8-nov): fuera


def _get(ep, opener, extra=None):
    """JSON de un endpoint de TMDB (es-ES). Excepción = red"""
    import urllib.request
    q = dict(extra or {}, api_key=TMDB_KEY, language="es-ES")
    req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q), headers={"User-Agent": "Ker0n3Media-skin"})
    with opener(req, timeout=TIMEOUT) as r:
        data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    return data if isinstance(data, dict) else {}


def _year(x):
    d = str(x.get("release_date") or x.get("first_air_date") or "")
    return int(d[:4]) if d[:4].isdigit() else None


def _genres(x):
    return {g["id"] if isinstance(g, dict) else g for g in (x.get("genres") or x.get("genre_ids") or [])}


def score(src, cand, rank, kind):
    """parecido de un candidato al título (Carlos, 8-nov: «mejorar los similares»), con lo que TMDB ya da en la
    respuesta (sin más peticiones). rank: (lista, posición, largo) — recomendaciones pesan más que «parecidas».
    None = fuera: muy pocos votos o infantil con un original que no lo es"""
    if int(cand.get("vote_count") or 0) < MIN_VOTES[kind]:
        return None
    g, c = _genres(src), _genres(cand)
    kids = KIDS[kind]
    if kids in c and kids not in g:
        return None
    sc = 3.0 * (len(g & c) / len(g | c) if g | c else 0)
    if (ANIMATION in g) != (ANIMATION in c):
        sc -= 4.0                                   # dibujos con imagen real (y al revés): al final
    lang = src.get("original_language")
    if lang and cand.get("original_language") == lang:
        sc += 0.6 if lang == "en" else 1.5          # anime con anime, coreanas con coreanas…
    ys, yc = _year(src), _year(cand)
    if ys and yc:
        sc += 1.0 - min(abs(ys - yc), 30) / 30.0
    va = float(cand.get("vote_average") or 0)
    sc += max(-1.0, min(1.0, (va - 6.5) / 2.0))
    sc += min(1.0, len(str(int(cand.get("vote_count") or 0))) / 5.0) * 0.5     # ~log10: más votado, más fiable
    lst, pos, n = rank
    sc += (1.5 if lst == "rec" else 0.5) * (1.0 - pos / float(max(n, 1)))
    return sc


def rank_similar(kind, src, pools, saga=()):
    """ids ordenados: la saga primero (por fecha), luego por parecido (score). pools: [(«rec»|«sim», resultados)]"""
    me = src.get("id")
    best = {}
    for lst, res in pools:
        for pos, x in enumerate(res):
            i = x.get("id")
            if not i or i == me:
                continue
            sc = score(src, x, (lst, pos, len(res)), kind)
            if sc is not None and (i not in best or sc > best[i]):
                best[i] = sc
    saga_ids = [x["id"] for x in sorted(saga, key=lambda x: str(x.get("release_date") or "9999"))
                if x.get("id") and x["id"] != me]
    return saga_ids + [i for i, _ in sorted(best.items(), key=lambda kv: -kv[1]) if i not in saga_ids]


def seen_ids(kind, ids, db_path=None):
    """de esos ids, los que ya has visto según Palantir (película con playcount; serie completa o con todos sus
    capítulos vistos). Sin base o ilegible: ninguno"""
    if not ids:
        return set()
    try:
        import flix_common
        if db_path is None:
            db_path = flix_common.watched_path()
        marks = ",".join(str(int(i)) for i in ids)
        if kind == "movie":
            sql = "SELECT tmdb_id FROM movies_watched WHERE playcount > 0 AND tmdb_id IN (%s)" % marks
        else:
            sql = ("SELECT s.tmdb_id FROM shows_watched s WHERE s.tmdb_id IN (%s) AND (s.completa OR "
                   "(s.num_total_episodios > 0 AND s.num_total_episodios <= (SELECT COUNT(*) FROM episodes_watched e "
                   "WHERE e.tmdb_id = s.tmdb_id AND e.playcount > 0)))" % marks)
        rows = flix_common.watched_query(db_path, sql)
    except Exception as e:  # noqa: BLE001
        log("no leo lo visto: %s" % e)
        return set()
    return {int(r[0]) for r in rows or []}


def similar(kind, tmdb, opener=None, db=None, seen=None):
    """«Ver similares» del menú KER0N3 (Carlos, 31-oct; mejorados 8-nov): ids de TMDB parecidos a ese título que tiene
    Palantir. Una sola petición trae la ficha, sus recomendaciones (lo que vieron y valoraron quienes vieron ese) y sus
    parecidas (géneros y palabras clave); una película de una colección pide además la saga, que va primero. Se
    ordenan por parecido (rank_similar) y lo visto va al final. Si Palantir tiene menos de MIN_SIMILAR, una página más
    de cada lista. Base ilegible: todos (Palantir solo da los que tiene). Excepción = red"""
    import urllib.request
    if kind not in VIEWS or not str(tmdb).isdigit():
        return []
    opener = opener or urllib.request.urlopen
    db = db or content_db()
    base = "%s/%d" % (kind, int(tmdb))
    src = _get(base, opener, {"append_to_response": "recommendations,similar"})
    pools = [("rec", (src.get("recommendations") or {}).get("results") or []),
             ("sim", (src.get("similar") or {}).get("results") or [])]
    saga = []
    col = src.get("belongs_to_collection")
    if kind == "movie" and isinstance(col, dict) and col.get("id"):
        try:
            saga = _get("collection/%d" % int(col["id"]), opener).get("parts") or []
        except Exception as e:  # noqa: BLE001  (sin la saga, lo demás sirve)
            log("saga %s: %s" % (col.get("id"), e))

    def ranked():
        ids = rank_similar(kind, src, pools, saga)
        have = present(kind, ids, db)
        return ids if have is None else have
    got = ranked()
    if len(got) < MIN_SIMILAR:
        for lst, ep in (("rec", "recommendations"), ("sim", "similar")):
            if ((src.get(ep) or {}).get("total_pages") or 1) > 1:
                pools.append((lst, _get("%s/%s" % (base, ep), opener, {"page": 2}).get("results") or []))
        got = ranked()
    vistos = seen_ids(kind, got) if seen is None else set(seen)
    return [i for i in got if i not in vistos] + [i for i in got if i in vistos]


def cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/tmdblists.json" % xbmc.getSkinDir())


def _load(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def ids_of(key, path=None, opener=None, now=time.time):
    """ids de la lista con caché (TTL; si TMDB no responde, lo último que hubo y se reintenta en ERR_TTL)"""
    path = path or cache_path()
    d, t = _load(path), now()
    hit = d.get(key)
    if isinstance(hit, list) and len(hit) == 3:
        ts, ids, ok = hit
        if t - ts < (TTL if ok else ERR_TTL):
            return ids
    else:
        ids = []
    try:
        ids, ok = fetch_ids(key, opener), True
    except Exception as e:  # noqa: BLE001
        log("TMDB no responde (%s): %s" % (key, e))
        ok = False
    mine = {key: [t, ids, ok]}
    try:
        # con cerrojo y mezclando con el fichero: otro proceso (el Inicio, la táctil, las filas al azar) puede haber
        # guardado otra lista desde que se leyó (revisión 29-oct DAT-14)
        import flix_cache
        flix_cache.update_json(path, lambda disk: flix_cache.merge_newer(disk, mine, [key]))
    except OSError as e:
        log("no guardo la caché: %s" % e)
    return ids


def content_db():
    """base de contenido de Palantir (SQLite aunque se llame settings.xml)"""
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/script.module/settings.xml")


def palantir_busy(db=None):
    """¿Palantir está con su sincronización de arranque (flix_p3sync) o a mitad de instalar su contenido nuevo (la
    base sin sus vistas)? Entonces no se le lee la base ni se le piden listas: el 28-oct (móvil) su actualización se
    quedó 3 min parada con la skin leyendo la base a la vez y siguió al descargar la skin. Sin base: no está ocupado
    (decide Palantir, como siempre)"""
    import sqlite3
    import xbmcgui
    import flix_common
    if flix_common.fuentes_on():
        return False            # con fuentes propias las filas no leen su base: nada que esperar (bloque 2)
    if xbmcgui.Window(10000).getProperty("flix_p3sync_busy"):
        return True
    db = db or content_db()
    if not os.path.exists(db):
        return False
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=2)
        try:
            return not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'view' AND name = 'v_pelis'").fetchone()
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("base de Palantir ocupada: %s" % e)
        return True


def present(kind, ids, db):
    """los ids que Palantir tiene (con enlaces: sus vistas v_pelis / v_series), en el mismo orden; None si no se puede
    leer la base (entonces no se filtra y decide Palantir)"""
    import sqlite3
    if not ids or not os.path.exists(db):
        return None if not os.path.exists(db) else []
    if db == content_db():
        # con el modo directo activo, lo mismo mirando su índice: la vista de Palantir agrupa todos los enlaces en
        # cada consulta y era lo que más tardaba entre fila y fila (Shield, 12-nov)
        try:
            import flix_direct
            fast = flix_direct.present(kind, ids)
            if fast is not None:
                return [i for i in ids if int(i) in set(fast)]
        except Exception as e:  # noqa: BLE001
            log("índice: %s" % e)
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=5)
        try:
            have = {int(r[0]) for r in con.execute("SELECT tmdb FROM %s WHERE tmdb IN (%s)" % (
                VIEWS[kind][2], ",".join(str(int(i)) for i in ids)))}
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("no leo la base de Palantir: %s" % e)
        return None
    return [i for i in ids if int(i) in have]


def cached_ids(key, path=None):
    """ids guardados de la lista, aunque estén caducados; [] si no hay. Sin red"""
    hit = _load(path or cache_path()).get(key)
    return hit[1] if isinstance(hit, list) and len(hit) == 3 and isinstance(hit[1], list) else []


def directory(path, cache=None, opener=None, now=time.time, db=None, offline=False):
    """ruta que hay que pedir a Kodi: la de Palantir si es una lista de TMDB (o '' si no hay títulos); si no, tal cual.
    Solo con lo que Palantir tiene: si no tiene ninguno, '' y no se le pregunta (si no, saca «No se han encontrado
    resultados para su búsqueda», Shield 24-oct: «En cines ahora» en la precarga de las filas al azar).
    offline: para el menú KER0N3 (flix_ctx_src, dentro de onAction): los ids guardados aunque estén caducados, sin
    pedir nada a TMDB ni leer la base de Palantir (puede estar ocupada). La ruta da los mismos títulos: Palantir solo
    devuelve los que tiene, en el orden de TMDB (revisión 29-oct DAT-16)"""
    key = key_of(path)
    if not key:
        return path
    if key not in BY_KEY:
        log("lista desconocida: %s" % key)
        return ""
    label, kind = BY_KEY[key][:2]
    if offline:
        return route(kind, cached_ids(key, cache), label)
    ids = ids_of(key, cache, opener, now)
    have = present(kind, ids, db or content_db())
    if have is not None:
        if not have and ids:
            log("%s: Palantir no tiene ninguno de los %d títulos" % (key, len(ids)))
        ids = have
    return route(kind, ids, label)
