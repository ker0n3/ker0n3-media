"""Inicio TV (ventana FlixInicio.xml): mismo diseño de siempre, con la carga de las secciones.

Antes cada fila del Inicio era una lista de Kodi con la ruta de Palantir: una llamada a Palantir por fila (Palantir
atiende de una en una, 2-4 s cada una, arrancando su Python cada vez) y las filas lejanas no se pedían hasta acercarse.
Ahora (Carlos, 22-oct: «como las secciones, que van fenomenal»):
  - cada fila se pinta al momento con lo guardado (flix_rows: rows_cache2.json, la caché de las secciones), aunque
    esté caducado, y Palantir se pide por detrás, de una en una y en orden, solo para lo caducado o sin guardar;
  - pulsar una carátula abre el aviso o la ficha dentro de este mismo Python (sin RunScript: ~0,1 s menos por clic).
Las filas y su orden salen de home_order.json (Ajustes → Personalizar menú e Inicio): flix_home_order.py escribe el
trozo FLIX_ROWS de FlixInicio.xml y pone Window(home).Property(fi_reload) para que esta ventana se rehaga.
Recargas de una fila: Window(home).Property(flix_rl_<src>) (las ponen flix_menu, flix_p3sync…, como antes) y, tras
ver un vídeo, «Seguir viendo» y «Series en seguimiento». El progreso (▶/✓) se repinta cuando cambia watched.db.

Uso: RunScript(special://skin/scripts/flix_inicio.py)   (lo lanza Home.xml al cargar; si ya está abierto, lo trae)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import re
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_home_conf as hc  # noqa: E402
import flix_common  # noqa: E402
import flix_rows  # noqa: E402
import flix_menu_preview  # noqa: E402
import flix_age  # noqa: E402
import flix_wide  # noqa: E402
import flix_resync  # noqa: E402
import flix_hero  # noqa: E402
import flix_newep  # noqa: E402
from flix_section import A_BACK, LOADING, make_item, placeholder  # noqa: E402

HOME = xbmcgui.Window(10000)
SKIN = xbmcvfs.translatePath("special://skin/")
A_CONTEXT = (117,)              # ACTION_CONTEXT_MENU (mantener OK / tecla menú)
A_NAV = (1, 2, 3, 4)            # izquierda, derecha, arriba, abajo
# filas personales: cambian al ver algo (no al caducar) -> se vuelven a pedir al terminar un vídeo
PERSONAL = ("p3PathPeliculasNoFinalizadas", "p3PathSeriesSeguimiento")
FOLLOW_PATH = "$VAR[p3PathSeriesSeguimiento]"       # de aquí salen las tarjetas de capítulo a medias de «Seguir viendo»
VAR_FILES = ("Includes_Flix.xml", "Includes_Palantir3.xml", "Variables.xml")
TICK = 0.5
# filas de listas de TMDB con Palantir ocupado (flix_tmdblists.palantir_busy: sincronización de arranque o su
# contenido a medio instalar): se dejan para después, mirando cada BUSY_POLL s, y como mucho BUSY_WAIT s (una marca
# colgada no las deja sin pedir para siempre). Las demás filas no esperan (revisión 29-oct DAT-16)
BUSY_POLL, BUSY_WAIT = 2.0, 180
# marca de volver a las filas (flix_go_home) con el Inicio delante más de esto sin que onInit la atienda: colgada. Con
# ella puesta el menú se pinta cerrado (FlixMenuOpen) aunque tenga el foco: la vigilancia hace lo de onInit (go_rows)
GO_HOME_WAIT = 1.0
# Una sola recarga de las filas personales tras un vídeo (revisión 7-nov PY-02/PY-30). Al acabar, y en los segundos
# siguientes, llegan hasta 4 marcas para las mismas filas (fin del vídeo, flix_progress.reload_resume_row en varias
# pasadas, flix_p3sync.refresh_follow) y cada una pedía la fila a Palantir, que atiende de una en una: la ficha de serie
# y «Ver» esperaban detrás («capítulos en 8,3 s», Shield 5-nov). Ahora se abre una ventana de MERGE_WAIT s (Palantir
# escribe el progreso ~3 s después de parar y flix_progress lo ve en su pasada de los 6 s) en la que las marcas de las
# filas personales solo se apuntan; al cerrarse se pide cada fila UNA vez. Una marca al final la alarga MERGE_QUIET s,
# nunca más allá de MERGE_MAX. Lo mismo si llega una marca personal con flix_progress trabajando (menú «Marcar como
# vista»: 40 s de pasadas). Las demás filas (menú, p3sync al arrancar sin flix_progress) se piden al momento, como antes
MERGE_WAIT, MERGE_QUIET, MERGE_MAX = 8.0, 2.0, 12.0
# Con las filas personales hechas por la skin (flix_direct: milisegundos, sin Palantir) no hace falta esperar esa
# ventana para verlas al día: en cuanto en watched.db aparece algo visto MÁS RECIENTE (Palantir guarda el progreso unos
# segundos después de parar, tras mandarlo a Trakt), sin vídeo en marcha y con PERSONAL_QUIET s de calma, se recargan
# ya. Solo si aumenta: al empezar a reproducir algo a medias Palantir borra su fila y la reescribe al parar; repintar
# con el borrado sacaba la película de «Seguir viendo» un instante (Fire TV, 12-nov). Medido allí: la fila se ponía al
# día a los 12,9 s de parar. La recarga del cierre de la ventana sigue igual (show no repinta lo que no cambia). Sin
# modo directo, todo como antes
PERSONAL_QUIET = 0.6
PROGRESS_BUSY_MAX = 60      # s: la marca flix_progress_busy lleva la hora (flix_progress.main la da por vieja a los 60)


def log(msg):
    xbmc.log("[flix_inicio] %s" % msg, xbmc.LOGINFO)


# ---------- rutas de las filas ----------
def expand_vars(path, variables):
    """$VAR[...] (recursivo) de una ruta de fila"""
    for _ in range(5):
        new = re.sub(r"\$VAR\[([^\]]+)\]", lambda m: variables.get(m.group(1), ""), path)
        if new == path:
            break
        path = new
    return path


def resolve(path, variables, info=lambda k: ""):
    """$VAR[...] (recursivo) y $INFO[...] (en vivo) de una ruta de fila"""
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: info(m.group(1)), expand_vars(path, variables))


def reload_marks(row, variables):
    """marcas de Palantir que lleva la ruta de la fila (&reload=$INFO[Window(home).Property(P3Reload…)]): Palantir las
    cambia al rehacer esa lista (al bajar de Trakt lo visto o pausado en otro aparato). Las filas XML de Kodi de antes
    se volvían a pedir solas al cambiar; el Inicio de Python (1.5.43, 22-oct) solo las leía al pedir la fila y lo traído
    de Trakt no salía hasta parar un vídeo (Carlos, 2-nov: «en versiones iniciales esto funcionaba bien, incluso entre
    dispositivos»). Las añadidas (custom) no llevan"""
    if row.get("custom"):
        return ()
    return flix_common.p3_marks(expand_vars(row.get("path") or "", variables))


def row_url(row, variables, info):
    """ruta de Palantir de una fila; las añadidas llevan &reload= pegado a su flix_rl (como la fila de Kodi de antes)"""
    if row.get("custom"):
        if not row["path"].startswith(("plugin://", "flix://")):
            return row["path"]          # de otro origen (carpeta, biblioteca…): sin el &reload= de Palantir, que la rompe
        # (las de Palantir y las listas de TMDB, flix://tmdb/…, como siempre; con fuentes propias, la de Palantir
        # cambiada por la lista propia que más se parece: flix_rows.home_custom, bloque 2)
        return flix_rows.home_custom(row["path"]) + "&reload=1" + info("Window(home).Property(flix_rl_%s)" % src_of(row))
    return resolve(row["path"], variables, info)


def src_of(row):
    return row.get("src") or "FlixRowPath%d" % row["id"]


def visible_rows(defaults, conf):
    """filas que se ven, en su orden: dicts con id, label (el nombre propio si lo tiene), limit, kind"""
    out = []
    for r in hc.compose(defaults, conf):
        if r["hidden"]:
            continue
        out.append(dict(r, label=r.get("title") or r["label"], kind="list",
                        limit=hc.TOP10_ITEMS if r.get("top10") else conf["items"]))
    return out


def trailer_playing():
    """¿lo que suena es un tráiler (botón «Tráiler» o el automático de la ficha)? No cambia nada de lo visto: al acabar
    no se recargan las filas personales (antes, cada tráiler pedía «Seguir viendo» y «Series en seguimiento»)"""
    playing = xbmc.getInfoLabel("Player.Filenameandpath")
    # flix_tr_last: el automático reproduce la dirección directa (sin «youtube» en la ruta) y al pararlo quita
    # flix_tr_auto antes de que Kodi acabe de cerrar el vídeo; con los tráileres de las filas pasaba a cada parada
    return bool(HOME.getProperty("flix_trailer") or HOME.getProperty("flix_tr_auto")
                or "plugin.video.youtube" in playing or (playing and playing == HOME.getProperty("flix_tr_last")))


def progress_busy(now=None):
    """¿flix_progress está en marcha (sus pasadas tras un vídeo o un menú)? La marca lleva la hora"""
    try:
        return 0 <= (time.time() if now is None else now) - float(HOME.getProperty("flix_progress_busy") or "x") < PROGRESS_BUSY_MAX
    except ValueError:
        return False


def state_sig(files):
    """lo que se ve de una fila: títulos, en orden, con su ✓ y su ▶ (si cambia algo se repinta)"""
    out = []
    for f in files or []:
        r = f.get("resume") or {}
        out.append((f.get("file"), f.get("playcount") or 0, int(r.get("position") or 0)))
    return out


def merge_state():
    """ventana de recarga única: until = cuándo se cierra (None: cerrada), opened = cuándo se abrió, due = filas
    apuntadas, video = hubo un vídeo de verdad (no tráiler) en la reproducción en curso, repaint = ▶/✓ pendiente"""
    return {"until": None, "opened": None, "due": [], "video": False, "repaint": False}


def merge_open(merge, now):
    merge["until"], merge["opened"] = now + MERGE_WAIT, now


def personal_stat():
    """huella barata de watched.db (flix_direct.personal_stat); None si no se puede mirar"""
    try:
        import flix_direct
        return flix_direct.personal_stat()
    except Exception as e:  # noqa: BLE001
        log("lo visto: %s" % e)
        return None


def personal_last():
    """fecha más reciente de lo visto (flix_direct.personal_last); None si no se lee o si las filas personales no
    las hace ahora la skin (entonces no se adelanta nada)"""
    try:
        import flix_direct
        return flix_direct.personal_last() if flix_direct.personal_on() else None
    except Exception as e:  # noqa: BLE001
        log("lo visto: %s" % e)
        return None


def personal_watch():
    """estado de personal_changed: stat = última huella barata del fichero, last = fecha más reciente de lo visto,
    moved = desde cuándo hay algo más reciente sin recargar"""
    return {"stat": None, "last": None, "moved": None}


def personal_changed(st, now, playing):
    """¿hay algo visto más reciente y toca recargar ya las filas personales? (flix_direct.personal_changed, la misma
    regla que el Inicio táctil). Si el modo directo no se puede cargar, nunca"""
    try:
        import flix_direct
    except Exception as e:  # noqa: BLE001
        log("lo visto: %s" % e)
        return False
    return flix_direct.personal_changed(st, now, playing, personal_stat, personal_last, PERSONAL_QUIET)


class InicioWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows = kwargs.get("rows") or []
        self.token = kwargs.get("token") or ""
        self.variables = kwargs.get("variables") or {}
        self.by_id = {r["id"]: r for r in self.rows}
        self.shown = {}             # id -> files pintados (None = aún nada)
        self.sigs = {}              # id -> state_sig de lo pintado
        # id -> último flix_rl_<src> visto (aquí y no en load: watch() arranca a la vez y lo tomaba todo por recargas)
        self.rl = {r["id"]: HOME.getProperty("flix_rl_%s" % src_of(r)) for r in self.rows}
        self.queue = []             # filas que hay que pedir a Palantir (en orden)
        self.pending = {}           # id -> lo que llegó con el Inicio tapado: se pinta al volver (onInit)
        self.items = {}             # id -> ListItems pintados (los nuestros: ver sel_pos)
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.stop = False
        self.started = False
        self.reloaded = False
        self.played = False
        self.merge = merge_state()      # ventana de recarga única tras un vídeo (MERGE_WAIT)
        self.wsig = HOME.getProperty("flix_progress_wsig")
        self.flags = {}          # flix_common.expire_hide_flags
        self.in_flight = False      # el worker pidiendo a Palantir: la vista previa del menú no pide a la vez
        self.go_since = None        # desde cuándo ve la vigilancia flix_go_home con el Inicio delante
        # vista previa de las secciones en el menú lateral (Carlos, 30-oct): al acabar de pedir, el worker sigue
        self.preview = flix_menu_preview.Preview(self, self.wake.set, lambda: self.in_flight)

    # ---------- ciclo de vida ----------
    def onInit(self):
        if not self.started:
            # solo en la primera: una ventana de Python conserva su id mientras vive (recargar la skin relanza el Inicio, con
            # su propio onInit). Las siguientes llegan en el hilo de Kodi cuando ya hay otra delante (al pasar de una
            # sección a otra desde su menú el Inicio se activa un instante entre las dos) y getCurrentWindowId daría el id
            # de la otra: active() mentiría y la vista previa y el worker pintarían listas ocultas y pedirían a Palantir
            HOME.setProperty("fi_window", str(xbmcgui.getCurrentWindowId()))
            # una marca de «Inicio» de antes de este Inicio (sección abierta desde Home.xml, «Inicio» pulsado durante una
            # recarga) no es para él: sin quitarla, al volver de un vídeo o una ficha el foco saltaba a las filas
            HOME.clearProperty("flix_go_home")
            self.started = True
            threading.Thread(target=self.load, daemon=True).start()
            threading.Thread(target=self.watch, daemon=True).start()
            reopen_settings()
            return
        # «Inicio» en el menú de una sección: el foco a las filas ANTES de pintar nada. Pintar lo pendiente tarda (12
        # filas = 1,44 s medidos en el Fire TV de Carlos, 10-nov) y mientras el foco seguía en el menú, en la sección de
        # la que se venía y pintado cerrado: derecha u OK la volvían a abrir («no ponía el foco en las carátulas,
        # incluso volvía a Películas»)
        going = bool(HOME.getProperty("flix_go_home"))
        if going:
            self.go_rows()
        # de vuelta de otra ventana: lo que llegó mientras tanto. Tras recargar el skin Kodi vuelve a montar esta
        # ventana desde el XML (listas vacías): se repinta lo que había
        with self.lock:
            pending, self.pending = self.pending, {}
        for lid, (kind, a, b) in pending.items():
            if kind == "show":
                self.show(a, b)
            else:
                self.refill(lid, a, b)
        for r in self.rows:
            files = self.shown.get(r["id"])
            if files and xbmc.getInfoLabel("Container(%d).NumItems" % r["id"]) in ("", "0"):   # size(): copia Python
                self.sigs.pop(r["id"], None)
                self.show(r, files)
        self.refresh_stale()
        if going and self.focus_id() not in self.by_id:
            # las listas estaban vacías al llegar (skin recargada: Kodi no da el foco a una lista vacía) y ya no
            self.setFocusId(self.first_alive() or 5001)
        reopen_settings()

    def go_rows(self):
        """«Inicio» en el menú de una sección (flix_section la cierra y pone flix_go_home): de vuelta, «Inicio» marcado
        en el menú y el foco en la primera fila con títulos (o en el grupo de filas), no en el menú abierto en la sección
        con su vista previa (Carlos, 31-oct). Va después de lo que Kodi restaura al volver (foco y selección de antes).
        La marca se quita después de mover el foco: mientras está puesta el Inicio se pinta como con el foco en las filas
        (FlixMenuOpen y FlixMenuPreviewOn) y antes asomaba unos fotogramas el menú abierto en la sección de la que se
        venía («el foco pasa rápidamente por Anime», Carlos 31-oct). Aunque falle, se quita: el menú se vería cerrado"""
        try:
            try:
                self.getControl(9000).selectItem(0)
            except (RuntimeError, AttributeError):          # sin la lista del menú
                pass
            self.setFocusId(self.first_alive() or 5001)
        finally:
            HOME.clearProperty("flix_go_home")
            self.go_since = None

    def close_for_reload(self):
        self.reloaded = True
        self.stop = True
        self.wake.set()
        self.trailer_leave()
        self.close()

    # ---------- carga ----------
    def url(self, row):
        return row_url(row, self.variables, xbmc.getInfoLabel)

    def load(self):
        """1) lo guardado al momento, aunque esté caducado; 2) Palantir por detrás, en orden, solo lo que haga falta"""
        try:
            pending = []
            for r in self.rows:
                if self.stop or flix_common.quitting():
                    return
                files, fresh = flix_rows.peek(self.url(r))
                if files or self.is_resume(r):          # «Seguir viendo»: sin películas puede haber capítulos a medias
                    self.safe_show(r, files or [])
                else:
                    self.refill(r["id"], [placeholder(LOADING)])
                if not fresh:
                    pending.append(r)
            self.enqueue(pending)
            self.worker()
        except RuntimeError:
            if not self.stop:
                raise
            # Inicio cerrado mientras cargaba: Kodi ya destruyó la ventana

    def enqueue(self, rows, first=False):
        with self.lock:
            ids = [q["id"] for q in self.queue]
            new = [r for r in rows if r["id"] not in ids]
            self.queue = (new + self.queue) if first else (self.queue + new)
        self.wake.set()

    def tmdb_held(self, since):
        """¿las filas de listas de TMDB tienen que esperar? Solo si hay alguna en cola, Palantir está ocupado y no
        llevan ya BUSY_WAIT s esperando (since: desde cuándo, o None)"""
        with self.lock:
            tmdb = any(flix_rows.is_tmdb_row(self.url(r)) for r in self.queue)
        if not tmdb or (since is not None and time.time() - since > BUSY_WAIT):
            return False
        import flix_tmdblists
        return flix_tmdblists.palantir_busy()

    def worker(self):
        """pide a Palantir las filas en cola, de una en una (Palantir no atiende dos a la vez)"""
        k = 0
        held_since = None           # desde cuándo esperan las filas de TMDB (Palantir ocupado)
        # quitting(): Kodi cerrándose (lo ve el quit_monitor de watch): ni una petición más a Palantir (PY-01)
        while not self.stop and not flix_common.quitting():
            # la vista previa del menú pidiendo a Palantir: tampoco (atiende de una en una)
            if self.queue and (self.busy_elsewhere() or self.preview.busy()):
                # con una ficha, un aviso, otra pantalla o un vídeo delante, Palantir se deja libre: atiende una
                # llamada cada vez y el «Ver» del usuario esperaba detrás del refresco de las filas (auditoría
                # 22-oct C-05). Lo que quede se pide al volver al Inicio
                self.wake.wait(1)
                self.wake.clear()
                continue
            held = self.tmdb_held(held_since)
            if held and held_since is None:
                held_since = time.time()
                log("Palantir ocupado: las filas de listas de TMDB, después")
            elif not held:
                held_since = None
            with self.lock:
                row = next((r for r in self.queue if not (held and flix_rows.is_tmdb_row(self.url(r)))), None)
                if row is not None:
                    self.queue.remove(row)
                waiting = bool(self.queue)
            if row is None and waiting:
                flix_rows.flush(keep=True)      # solo quedan filas de TMDB esperando: lo pedido, guardado
                self.wake.wait(BUSY_POLL)
                self.wake.clear()
                continue
            if row is None:
                flix_rows.flush()
                self.wake.wait()
                self.wake.clear()
                continue
            # se avisa antes de mirar (la vista previa, igual): nunca piden los dos a la vez
            self.in_flight = True
            try:
                if self.preview.busy():         # la vista previa se adelantó: la fila vuelve a la cola y espera
                    self.enqueue([row], first=True)
                    continue
                if flix_common.quitting():
                    break
                try:
                    files, _ = flix_rows.fetch(self.url(row), force=True, save=False)
                except Exception as e:  # noqa: BLE001
                    log("fila %s: %s" % (row["label"], e))
                    files = None
                if self.stop:
                    break
                if files or (files is not None and self.is_resume(row)):
                    if self.safe_show(row, files):
                        log("fila %s: %d (Palantir)" % (row["label"], len(files)))
                elif not self.shown.get(row["id"]):
                    # sin nada que enseñar (p. ej. «Seguir viendo» vacío): la fila se oculta
                    self.refill(row["id"], [])
                k += 1
                if k % 4 == 0:
                    flix_rows.flush(keep=True)  # vienen más: sin releer el fichero si nadie lo ha tocado (DAT-02)
            finally:
                self.in_flight = False

    def busy_elsewhere(self):
        # HasActiveModalDialog: HasModalDialog no cuenta las fichas y avisos de Python (FlixMovie, FlixResume)
        return not self.active() or xbmc.getCondVisibility("System.HasActiveModalDialog | Player.HasMedia")

    def refresh_stale(self):
        """al volver al Inicio: lo caducado se vuelve a pedir por detrás (lo de antes sigue a la vista)"""
        stale = [r for r in self.rows if not flix_rows.is_fresh(self.url(r))]      # sin corregir el progreso
        if stale:
            self.enqueue(stale)

    # ---------- vigilancia: recargas pedidas, progreso, vídeo, configuración ----------
    def watch(self):
        # el Monitor que se entera del cierre de Kodi (System.OnQuit): a los RunScript sin addon no les llega
        # abortRequested y Kodi esperaba 5 s al Inicio y lo mataba («script didn't stop in 5 seconds», Shield 5-nov;
        # revisión 7-nov PY-01). Lo crea este hilo y espera en él: así le llega el anuncio (flix_common.quit_monitor)
        mon = flix_common.quit_monitor()
        # si tick() falla siempre, una línea por error distinto y no una cada TICK (revisión 29-oct ARR-12); tras
        # una vuelta buena, el mismo error se vuelve a apuntar
        last = None
        while not self.stop and not (mon.waitForAbort(TICK) or flix_common.quitting()):
            try:
                self.tick()
                last = None
            except RuntimeError:
                msg = "vigilancia: ventana no disponible"
                if not self.stop and msg != last:
                    log(msg)
                last = msg
            except Exception as e:  # noqa: BLE001
                msg = "vigilancia: %s" % e
                if msg != last:
                    log(msg)
                last = msg
        self.trailer_leave()            # la vigilancia se va: nadie pararía ya el tráiler de la fila
        if flix_common.quitting() and not self.stop:
            self.quit()

    def quit(self):
        """Kodi se cierra: el worker deja la cola, los hilos salen y la ventana se cierra (doModal vuelve y el script
        acaba solo, sin esperar a que Kodi lo mate)"""
        log("Kodi se cierra: me voy")
        self.stop = True
        self.wake.set()
        self.trailer_leave()
        try:
            self.close()
        except RuntimeError:            # Kodi ya destruyó la ventana
            pass

    # ---------- tráiler automático en las filas (flix_rowtrailer; Carlos, 11-nov) ----------
    def row_trailer(self):
        rt = self.__dict__.get("rowtrailer")
        if rt is None:
            import flix_rowtrailer          # aquí y no arriba: el arranque del Inicio no lo necesita
            rt = self.rowtrailer = flix_rowtrailer.RowTrailer(self, self.trailer_focus)
        return rt

    def trailer_focus(self):
        """(fila, ruta) del título enfocado con el Inicio delante y sin nada encima (ficha, menú, aviso); None si no"""
        if not self.active() or xbmc.getCondVisibility("System.HasActiveModalDialog"):
            return None
        lid = self.focus_id()
        if lid not in self.by_id:
            return None
        items, pos = self.items.get(lid) or [], self.sel_pos(lid)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open") or item.getProperty("more"):       # «Cargando…», «Ver más»
            return None
        return lid, item.getPath()

    def trailer_leave(self):
        rt = self.__dict__.get("rowtrailer")
        if rt is not None:
            rt.leave()

    def tick(self):
        if HOME.getProperty("fi_token") != self.token:
            # otro Inicio tomó el relevo (esta ventana se perdió en un cambio de skin): este se va
            log("Inicio relevado por otro: me cierro")
            self.stop = True
            self.wake.set()
            self.trailer_leave()
            self.close()
            return
        self.row_trailer().tick()
        mine = HOME.getProperty("fi_window") == str(xbmcgui.getCurrentWindowId())
        rev = HOME.getProperty(flix_age.REV)
        if rev != getattr(self, "age_rev", "") and self.active():
            self.age_rev = rev                      # llegaron edades de TMDB: a las carátulas ya pintadas, sin repintar
            for lid in list(self.items):
                flix_age.apply(self.items.get(lid))
        rev = HOME.getProperty(flix_wide.REV)
        if rev != getattr(self, "wide_rev", "") and self.active():
            self.wide_rev = rev                     # llegaron imágenes apaisadas de TMDB: a las tarjetas de «Seguir viendo»
            flix_wide.apply(self.items.get(flix_wide.ROW))
        if HOME.getProperty("flix_go_home") and mine:
            # «Inicio» de una sección que onInit no atendió (la atiende al momento: esto es solo por si acaso). Puesta, el
            # menú se pinta cerrado aunque tenga el foco: pasado GO_HOME_WAIT s con el Inicio delante, a las filas
            since = getattr(self, "go_since", None)
            if since is None:
                self.go_since = time.time()
            elif time.time() - since > GO_HOME_WAIT:
                log("marca de volver a las filas sin atender: a las filas")
                self.go_rows()
        else:
            self.go_since = None
        if HOME.getProperty("fi_reload") and mine and not dialog_open():
            # con Ajustes aún abierto encima (se entra al editor desde ahí) Kodi no deja volver a abrir el Inicio:
            # «Activate of window refused because there are active modal dialogs» y se quedaba en negro, sin
            # carátulas (Shield, Carlos 24-oct). Se rehace al cerrarlo
            HOME.clearProperty("fi_reload")
            log("filas nuevas (Personalizar Inicio): se rehace el Inicio")
            self.close_for_reload()
            return
        bumped = []
        for r in self.rows:
            v = HOME.getProperty("flix_rl_%s" % src_of(r))
            if v != self.rl.get(r["id"]):
                self.rl[r["id"]] = v
                bumped.append(r)
        seen = self.__dict__.setdefault("p3seen", {})      # Palantir rehízo su lista (reload_marks): id -> marcas
        known = self.__dict__.setdefault("p3marks", {})
        for r in self.rows:
            if r["id"] not in known:
                known[r["id"]] = reload_marks(r, getattr(self, "variables", {}))
            marks = known[r["id"]]
            if not marks:
                continue
            v = tuple(HOME.getProperty(m) for m in marks)
            if r["id"] in seen and seen[r["id"]] != v and r not in bumped:
                bumped.append(r)
            seen[r["id"]] = v                   # la 1.ª vez solo se apunta lo que hay
        bumped += [r for r in self.k3_bumped() if r not in bumped]
        now = time.time()
        merge = self.__dict__.setdefault("merge", merge_state())
        if xbmc.getCondVisibility("Player.HasVideo"):
            self.played = True
            merge["video"] = merge["video"] or not trailer_playing()      # un tráiler no cuenta
        elif self.played:
            self.played = False
            if merge["video"]:
                merge["video"] = False
                merge_open(merge, now)
                merge["due"] += [r for r in self.rows if src_of(r) in PERSONAL and r not in merge["due"]]
        # Trakt otra vez con Kodi ya abierto: tras un vídeo, al volver tras un rato sin uso y cada 15 min (flix_resync)
        # (con el vídeo delante el Inicio no es la ventana activa: se llama igual, para saber que se ha reproducido)
        flix_resync.tick(xbmc.getCondVisibility("Player.HasVideo") and not trailer_playing(), now)
        personal = [r for r in bumped if src_of(r) in PERSONAL]
        if personal and merge["until"] is None and progress_busy(now):
            merge_open(merge, now)
        if personal and merge["until"] is not None:
            # en la ventana: se apuntan y se piden juntas al cerrarse (una vez por fila)
            merge["due"] += [r for r in personal if r not in merge["due"]]
            merge["until"] = min(max(merge["until"], now + MERGE_QUIET), merge["opened"] + MERGE_MAX)
            bumped = [r for r in bumped if r not in personal]
        if bumped:
            log("recargo %s" % ", ".join(r["label"] for r in bumped))
            self.enqueue(bumped, first=True)
        flix_common.expire_hide_flags(self.__dict__.setdefault("flags", {}))
        wsig = HOME.getProperty("flix_progress_wsig")
        if wsig != self.wsig:               # watched.db cambió (flix_progress): ▶/✓ al día con lo guardado
            self.wsig = wsig
            # con un vídeo de verdad aún en marcha (o cerrándose: en un Fire TV Kodi tarda segundos en soltarlo y el
            # Inicio se entera después) tampoco: Palantir borra la fila de lo que se está viendo y la reescribe al
            # parar; repintar ahí sacaba la película de «Seguir viendo» hasta la recarga (Fire TV, 12-nov). Al parar se
            # abre la ventana y se repinta al cerrarse
            if merge["until"] is not None or (self.played and merge["video"]):
                merge["repaint"] = True     # hasta 4 cambios por vídeo: un repintado al cerrarse la ventana (PY-30)
            else:
                self.repaint()
        self.hero_tick(now)
        if personal_changed(self.__dict__.setdefault("pwatch", personal_watch()), now, self.played):
            rows = [r for r in self.rows if src_of(r) in PERSONAL]
            if rows:
                log("recargo %s (Palantir ha guardado algo visto)" % ", ".join(r["label"] for r in rows))
                self.enqueue(rows, first=True)
        if merge["until"] is not None and now >= merge["until"]:
            due, repaint = merge["due"], merge["repaint"]
            merge.update(until=None, opened=None, due=[], repaint=False)
            if due:
                log("recargo %s (tras el vídeo, de una vez)" % ", ".join(r["label"] for r in due))
                self.enqueue(due, first=True)
            if repaint:
                self.repaint()
        # vista previa del menú lateral. Apagada: solo cuesta mirar el ajuste. Con un vídeo o una ventana encima no
        # pide nada más (Palantir, libre)
        if not flix_menu_preview.enabled():
            self.preview.leave(hide=True)
        elif self.busy_elsewhere():
            self.preview.leave()
        else:
            self.preview.tick(time.time())

    def k3_bumped(self):
        """filas cuya lista de Ker0n3 acaba de repasar el servicio del addon (bloque 2): pone
        Window(home).Property(k3_list_rev_<clave>) cuando lo que la lista enseña cambia (títulos sin castellano fuera,
        fichas con logo y duración). La 1.ª vez solo se apunta lo que hay. La clave de cada fila se calcula una vez"""
        keys = self.__dict__.setdefault("k3keys", {})
        seen = self.__dict__.setdefault("k3seen", {})
        out = []
        for r in self.rows:
            if r["id"] not in keys:
                keys[r["id"]] = flix_rows.k3_list_key(self.url(r))
            if not keys[r["id"]]:
                continue
            v = HOME.getProperty("k3_list_rev_" + keys[r["id"]])
            if r["id"] in seen and seen[r["id"]] != v:
                out.append(r)
            elif r["id"] not in seen and flix_rows.k3_stale(self.url(r), HOME):
                # 1.ª mirada: el aviso llegó antes (Inicio cerrado, Kodi reiniciado: queda en disco) y la fila
                # guardada es anterior → también se vuelve a pedir, una vez
                out.append(r)
            seen[r["id"]] = v
        return out

    def k3_menu(self, lid):
        """pulsación larga en un título de Ker0n3: su menú (flix_k3menu: «Elegir resolución», «Ver ficha»). True si la
        carátula con foco es de Ker0n3, tenga menú o no: el de Palantir (flix_menu) no sabe qué hacer con ella"""
        items = (getattr(self, "items", None) or {}).get(lid) or []
        pos = self.sel_pos(lid) if items else 0
        item = items[pos] if pos < len(items) else None
        path = item.getPath() if item is not None else ""
        if not path.startswith(flix_common.K3_ROOT):
            return False
        if item.getProperty("open") and not item.getProperty("more"):
            import flix_k3menu
            flix_k3menu.menu(path, item.getLabel(), item.getArt("poster"), item.getArt("fanart"))
        return True

    def safe_show(self, row, files):
        """pinta una fila; si falla, lo apunta y se sigue con las demás: una excepción mataba el hilo en silencio y el
        resto se quedaba en «Cargando…» (revisión 7-nov PY-10). Con stop puesto (Kodi destruyó la ventana) no se apunta"""
        try:
            self.show(row, files)
            return True
        except Exception as e:  # noqa: BLE001
            if not self.stop:
                log("fila %s: no se pudo pintar (%s: %s)" % (row["label"], type(e).__name__, e))
            return False

    def repaint(self):
        """todas las filas otra vez desde lo guardado: el ▶/✓ al día (show no repinta las que no cambian)"""
        for r in self.rows:
            files, _ = flix_rows.peek(self.url(r))
            if files or self.is_resume(r):
                self.show(r, files or [])

    # ---------- pintar ----------
    def active(self):
        """¿el Inicio está delante? Solo entonces se tocan sus listas. Al actualizarse sola la skin, Kodi la recarga
        y destruye las ventanas: un hilo que pintaba una fila tocó una lista ya borrada y Kodi se cayó (SIGSEGV en
        xbmcgui::Control, Shield 22-oct). Tapado (otra ventana, recarga) se guarda y se pinta al volver.
        También la marca fi_token: tras una recarga el Inicio nuevo recibe el mismo id de ventana (13000) y el viejo,
        si aún vive, se creía delante (revisión 7-nov PY-18)"""
        return (HOME.getProperty("fi_window") == str(xbmcgui.getCurrentWindowId())
                and HOME.getProperty("fi_token") == self.token)

    def show(self, row, files):
        if not self.active():
            with self.lock:
                self.pending[row["id"]] = ("show", row, files)
            return
        if self.is_resume(row):
            import flix_progress
            if not flix_common.p3sync_busy():
                # «Seguir viendo»: fuera lo ya visto o sin progreso. Palantir no rehace la fila hasta que caduca y una
                # respuesta vacía se toma por fallo: la última peli terminada seguía ahí, con ✓, hasta 24 h (auditoría
                # 22-oct B-07). Como la táctil (flix_home.sync_progress)
                files = flix_progress.still_started(files)
            # y el capítulo a medias de cada serie, con su barra (Carlos, 11-nov); «Series en seguimiento» no cambia
            files = flix_progress.episode_cards(files, self.follow_files())
            if not files:
                self.sigs.pop(row["id"], None)
                self.shown.pop(row["id"], None)
                if self.items.get(row["id"]):
                    self.refill(row["id"], [])
                self.publish()
                return
        elif files and flix_rows.follow_tmdb(files[0]):
            import flix_progress
            files = flix_progress.ordered_follow(files)     # por lo visto de verdad, no por los sellos de Trakt
        got = files
        files = flix_rows.head(files, row["limit"], more=not row.get("top10"))   # «Ver más» al final
        if not row.get("top10") and not self.is_resume(row):
            # lista de Ker0n3: «Ver más» abre solo lo que la fila no enseña (flix_rows.k3_rest)
            files = flix_rows.k3_rest(flix_rows.k3_list_key(self.url(row)), got, files)
        sig = state_sig(files)
        lid = row["id"]
        flix_age.want(files)                        # edad de TMDB en segundo plano, solo las que falten (flix_age)
        if lid == flix_wide.ROW:
            flix_wide.want(files)                   # y la imagen apaisada de sus tarjetas (flix_wide)
        if self.sigs.get(lid) == sig and self.items.get(lid):
            flix_newep.update(self.items[lid])      # sin repintar: solo la etiqueta de capítulo nuevo, si cambió
            flix_newep.recheck(self.items[lid], lambda: self.items.get(lid))    # y, si caducó algo, refresco (puerta 10 min)
            return
        self.sigs[lid] = sig
        self.shown[lid] = files
        items = [make_item(f, row) for f in files]
        flix_newep.paint(items, files, lambda: self.items.get(lid))     # Series en seguimiento; en otras filas, nada
        if lid == flix_wide.ROW:
            flix_wide.decorate(items, files)        # «Quedan 42 min» y la apaisada que ya esté en caché
        self.refill(lid, items, self.sel_pos(lid))
        self.hero_fill(row, files)                  # carrusel del Top 10, si esta es su fila
        self.publish()
        if lid == hc.FOLLOW_ROW:
            self.reshow_resume()                    # sus tarjetas de capítulo a medias salen de esta lista

    def follow_files(self):
        """lo guardado de «Series en seguimiento» (sin red), esté o no esa fila en el Inicio; [] si no hay"""
        try:
            files, _ = flix_rows.peek(resolve(FOLLOW_PATH, self.variables, xbmc.getInfoLabel))
            return files or []
        except Exception as e:  # noqa: BLE001
            log("series en seguimiento guardadas: %s" % type(e).__name__)
            return []

    def reshow_resume(self):
        """«Seguir viendo» otra vez desde lo guardado (si no cambia nada, show no repinta)"""
        r = self.by_id.get(flix_wide.ROW)
        if r and self.is_resume(r):
            files, _ = flix_rows.peek(self.url(r))
            self.safe_show(r, files or [])

    def publish(self):
        """sus 3 primeras filas con títulos (las 2 que se ven y una de reserva; nombre que se ve y ruta de su caché) en
        Window(home): «Inicio» en el menú de una sección enseña con ellas la vista previa del Inicio, solo con lo
        guardado (flix_menu_preview.home_rows; Carlos, 31-oct). Solo se escribe lo que cambia"""
        top = [r for r in self.rows if self.shown.get(r["id"])][:flix_menu_preview.HOME_ROWS]
        flix_menu_preview.publish_home([(r["label"], self.url(r)) for r in top])

    # ---------- carrusel del Top 10 (flix_hero; Carlos, 12-nov) ----------
    def hero_fill(self, row, files):
        """los títulos del carrusel (lista 5100) con los de su fila de origen recién pintada; la primera vez, el foco
        arranca en él («arranca en el carrusel») si nadie lo ha movido aún de donde lo deja el Inicio al abrirse"""
        st = self.__dict__.setdefault("hero", {"sig": None, "focused": False, "at": 0.0, "on": None})
        if not flix_hero.enabled() or row["id"] != flix_hero.source(self.rows, self.shown):
            return
        picks = flix_hero.pick(files, flix_rows.is_more)
        sig = state_sig(picks)
        if sig == st["sig"] and self.items.get(flix_hero.HERO_ID):
            return
        st["sig"] = sig
        hero_row = dict(row, id=flix_hero.HERO_ID, top10=False)
        self.by_id[flix_hero.HERO_ID] = hero_row        # OK, menú y tráiler lo tratan como a una carátula de fila
        items = [make_item(f, hero_row) for f in picks]
        for k, li in enumerate(items):
            li.setProperty("hero_label", flix_hero.rank_label(row["id"], k))
        before = self.focus_id()
        self.refill(flix_hero.HERO_ID, items, self.sel_pos(flix_hero.HERO_ID))
        if items and not st["focused"]:
            st["focused"] = True
            # solo si aún no se ha tocado el mando y el foco sigue donde lo deja el Inicio al abrirse (ninguno, el grupo
            # de filas o una fila): ni en el menú lateral ni en los botones de arriba
            rows = before is None or before == 5001 or before in self.by_id
            if self.active() and not HOME.getProperty("flix_go_home") and rows and not self.__dict__.get("touched"):
                self.setFocusId(flix_hero.HERO_ID)
                st["at"] = time.time()

    def hero_tick(self, now):
        """desde la vigilancia: apagado en Ajustes se vacía (y el foco, a las filas), encendido se rellena, y con el
        foco en él y el mando quieto pasa al siguiente título"""
        st = self.__dict__.setdefault("hero", {"sig": None, "focused": False, "at": 0.0, "on": None})
        if not self.active():
            return
        on = flix_hero.enabled()
        if on != st["on"]:
            st["on"] = on
            if not on and self.items.get(flix_hero.HERO_ID):
                st["sig"] = None
                self.by_id.pop(flix_hero.HERO_ID, None)
                self.refill(flix_hero.HERO_ID, [])
            elif on and not self.items.get(flix_hero.HERO_ID):
                src = flix_hero.source(self.rows, self.shown)
                if src in self.by_id and self.shown.get(src):
                    st["focused"] = True                # encendido desde Ajustes: sin llevarse el foco
                    self.hero_fill(self.by_id[src], self.shown[src])
        items = self.items.get(flix_hero.HERO_ID) or []
        focused = bool(items) and self.focus_id() == flix_hero.HERO_ID
        if not focused:
            st["at"] = now
            return
        if flix_hero.due(focused, xbmc.getGlobalIdleTime(), now, st["at"], xbmc.getCondVisibility("Player.HasVideo")):
            st["at"] = now
            self.getControl(flix_hero.HERO_ID).selectItem(flix_hero.next_pos(self.sel_pos(flix_hero.HERO_ID), len(items)))

    def is_resume(self, row):
        if "resume" not in row:
            import flix_progress
            row["resume"] = flix_progress.is_resume_row(self.url(row))
        return row["resume"]

    def sel_pos(self, lid):
        """posición seleccionada de una fila (0 si vacía), preguntando a Kodi. NO con ControlList.getSelectedPosition
        ni getSelectedItem: tras recargar la skin (actualización automática) el objeto de Python sigue apuntando a
        la lista vieja, ya borrada, y Kodi se caía (SIGSEGV en ControlList::getSelectedPosition, 22-oct). reset,
        addItems, selectItem y setFocusId van por id y son seguros"""
        try:
            return max(0, int(xbmc.getInfoLabel("Container(%d).CurrentItem" % lid) or 0) - 1)
        except ValueError:
            return 0

    def focus_id(self):
        try:
            return self.getFocusId() or None
        except RuntimeError:                        # ningún control de la ventana tiene el foco
            return None

    def first_alive(self, skip=None):
        for r in self.rows:
            if r["id"] != skip and self.items.get(r["id"]):
                return r["id"]
        return None

    def refill(self, lid, items, pos=0):
        """vacía y rellena una fila sin perder el foco: Kodi suelta el de una lista vacía (fallo de la 1.5.38 en
        las secciones). Si la fila lo tenía o nadie lo tiene y es la primera con títulos, se le devuelve; si se queda
        vacía con el foco, pasa a la primera fila con títulos"""
        if not self.active():
            with self.lock:
                self.pending[lid] = ("refill", items, pos)
            return
        focus = self.focus_id()
        lst = self.getControl(lid)
        lst.reset()
        self.items[lid] = list(items)
        if items:
            lst.addItems(items)
            if pos > 0:
                lst.selectItem(min(pos, len(items) - 1))
            if focus == lid or (focus is None and self.first_alive() == lid):
                self.setFocusId(lid)
        elif focus == lid or focus is None:
            nxt = self.first_alive(skip=lid)
            if nxt:
                self.setFocusId(nxt)

    # ---------- mando ----------
    def onAction(self, action):
        self.touched = True             # ya se ha usado el mando: el carrusel no se lleva el foco (hero_fill)
        aid = action.getId()
        rt = self.__dict__.get("rowtrailer")
        if rt is not None:
            rt.key(aid)             # cualquier tecla para el tráiler de la fila, y hace lo suyo
        if aid in A_BACK:
            return                  # Atrás lo hace cada control (<onback>: filas -> menú -> buscar -> apagar)
        if aid in A_CONTEXT and self.focus_id() in self.by_id:
            if HOME.getProperty("flix_ctx_auto"):
                # es flix_menu abriendo por detrás el menú de Kodi para pulsar la opción de Palantir: a Kodi. Si se
                # abría otra vez el menú KER0N3, «Marcar como vista» no hacía nada (desde 1.5.43; Carlos, 23-oct)
                super().onAction(action)
                return
            if self.k3_menu(self.focus_id()):
                return
            # listado de Palantir de la fila: las filas son listas de Python y el menú de Kodi no va con ellas ->
            # flix_menu pulsa la opción desde una lista oculta con ese listado (FlixCtx.xml, como la táctil). Filas de
            # listas de TMDB: su listado de Palantir (flix://tmdb/ Kodi no lo abre: lista vacía -> «Palantir está
            # ocupado» al marcar como vista; hermana de Carlos, 24-oct). Sin red ni base de Palantir: los ids guardados
            # (aquí, dentro de onAction, el menú esperaba a TMDB con la lista caducada; revisión 29-oct DAT-16)
            HOME.setProperty("flix_ctx_src", flix_rows.directory(self.url(self.by_id[self.focus_id()]), offline=True))
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_menu.py)")    # carátula de flix_row
            return
        if aid in A_NAV and self.focus_id() is None:    # foco perdido: la tecla no iría a ningún sitio
            target = self.first_alive()
            self.setFocusId(target or 9000)
            return
        super().onAction(action)

    def onClick(self, control_id):
        if control_id not in self.by_id:
            return
        items, pos = self.items.get(control_id) or [], self.sel_pos(control_id)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open"):     # «Cargando…»
            return
        path, how = item.getPath(), item.getProperty("open")
        self.trailer_leave()        # el tráiler de la fila no sigue debajo de lo que se abre
        HOME.setProperty("flix_title", item.getProperty("P3Titulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid" and item.getProperty("more"):
            # «Ver más»: la página siguiente como sección de una fila suelta (ficha propia al pulsar), no la
            # cuadrícula de Kodi (Carlos, 7-nov; mismo camino que en la sección)
            import flix_section
            shown = self.shown.get(control_id) or []
            skip = [t for t in map(flix_rows.follow_tmdb, shown) if t]
            if skip:
                # Series en seguimiento: el «más…» del widget de Palantir es la lista entera desde el principio y sin
                # filtrar (Carlos, 8-nov). La misma lista de la fila (guardada) sin las que ya se ven en ella
                path = self.url(self.by_id[control_id])
            flix_section.open_more(self.by_id[control_id]["label"], "", path, menu=True, skip=skip)
        elif how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.by_id[control_id]["label"], item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        elif how == "kodi":                 # archivo de fuera de Palantir (otros orígenes): reproducirlo como Kodi
            flix_common.play_kodi(path)
        elif how == "picture":              # foto de una carpeta del NAS: pase de fotos desde ella
            flix_common.show_picture(path)
        elif how == "folder":               # subcarpeta del NAS: como sección, con su nombre
            import flix_section
            flix_section.open_folder(self.by_id[control_id]["label"], item.getLabel(), path)
        elif how == "resume":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s",seguir)' % path)
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def open_window(token=""):
    import flix_home_order
    flix_home_order.check()                 # FlixInicio.xml con las filas guardadas (tras actualizar el skin…)
    HOME.clearProperty("fi_reload")
    conf = flix_home_order.effective(flix_home_order.load_conf())     # modo modesto: sus 6 filas
    rows = visible_rows(flix_home_order.tv_default_blocks(), hc.normalize(conf))
    win = InicioWindow("FlixInicio.xml", SKIN, "Default", "1080i", rows=rows, token=token,
                       variables=flix_common.skin_vars(VAR_FILES))     # una lectura por proceso (DAT-19)
    win.doModal()
    win.stop = True
    win.wake.set()
    reloaded = win.reloaded
    del win
    return reloaded


def reopen_settings():
    """vuelta de «Ajustes de Kodi» abiertos desde los Ajustes de la skin (Settings.xml deja la marca al salir hacia
    atrás): el menú de Ajustes otra vez delante, ahora que el Inicio ya lo está"""
    if HOME.getProperty("flix_abrir_ajustes"):
        HOME.clearProperty("flix_abrir_ajustes")
        xbmc.executebuiltin("ActivateWindow(1196)")


def already_open():
    """¿hay un Inicio abierto? Lo trae delante. Si la marca está pero la ventana no aparece (Kodi la destruyó al
    cambiar de skin y volver: se quedaba la lanzadera con el menú y sin filas, Kodi limpio 22-oct), no lo hay"""
    if HOME.getProperty("fi_running") != "1":
        return False
    if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
        # recarga de la skin con una película en marcha: el Inicio sigue ahí debajo; traerlo delante cortaba la
        # película (onunload de VideoFullScreen). Al acabar el vídeo, el onload de Home lo vuelve a traer (A-05)
        return True
    wid = HOME.getProperty("fi_window")
    if wid:
        wait_dialogs()
        xbmc.executebuiltin("ActivateWindow(%s)" % wid)
        for _ in range(20):
            xbmc.sleep(100)
            if str(xbmcgui.getCurrentWindowId()) == wid:
                return True
    log("el Inicio abierto ya no está: abro otro")
    return False


def dialog_open():
    """¿algún diálogo encima? System.HasModalDialog solo cuenta los visibles: Ajustes (Custom_1196) detrás del editor
    no contaba y aun así Kodi rechazaba abrir el Inicio (Shield, 24-oct)"""
    return xbmcgui.getCurrentWindowDialogId() != 9999 or xbmc.getCondVisibility("System.HasModalDialog")


def wait_dialogs(secs=60):
    """con un diálogo modal abierto (Ajustes) Kodi rechaza abrir ventanas: «Activate of window refused»"""
    mon = xbmc.Monitor()
    end = time.time() + secs
    while time.time() < end and dialog_open():
        if mon.waitForAbort(0.2):
            return


def main():
    import flix_reload
    if flix_reload.holding(HOME):
        # el onload de Home al cerrarse este Inicio para recargar: una ventana abierta ahora tiraría Kodi al recargar
        log("recarga del skin en marcha: el Inicio lo abre la recarga")
        return
    if already_open():
        return
    flix_common.wait_intro()                # arranque: hasta que acaba la intro (capa sobre Home, flix_boot)
    token = "%f" % time.time()
    HOME.setProperty("fi_running", "1")
    HOME.setProperty("fi_token", token)          # el Inicio viejo, si sigue vivo, lo ve y se cierra (tick)
    try:
        while open_window(token):
            xbmc.sleep(300)                 # que los hilos de la ventana vieja vean stop y salgan
            wait_dialogs()
    finally:
        if HOME.getProperty("fi_token") == token:
            HOME.clearProperty("fi_running")
            HOME.clearProperty("fi_window")
            HOME.clearProperty("fi_token")


if __name__ == "__main__":
    main()
