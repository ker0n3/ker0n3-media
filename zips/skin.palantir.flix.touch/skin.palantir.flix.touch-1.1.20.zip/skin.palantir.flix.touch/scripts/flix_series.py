# -*- coding: utf-8 -*-
"""Abrir una serie de Palantir en su pantalla de temporadas (en vez de "reproducir siguiente capítulo").

RunScript(special://skin/scripts/flix_series.py, <ruta plugin:// del item>)
RunScript(special://skin/scripts/flix_series.py, ver)    -> botón «Ver / Continuar» de la pantalla de temporadas

La ruta de un item de serie lleva action 'play_mis_serieS' (Palantir: reproduce el siguiente capítulo).
Con action 'listado_temporadaS' y el mismo JSON, Palantir devuelve las temporadas en ~2 s.
Se guarda la ruta original en Window(home).Property(flix_series_play) para el botón "Continuar".
Serie a medias (▶): pop-up «Seguir viendo · TxEy / Desde el principio / Ver temporadas» en vez de las temporadas.
Serie sin empezar: «Ver» = T1 E1 (play_mis_serieS no sabe qué poner y no hacía nada; se salta los especiales).
"""
import base64
import json
import math
import re
import sqlite3
import sys
import time
import xbmc
import xbmcgui
import xbmcvfs
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import PLUGIN_ROOT, decode_route, encode_route  # noqa: E402,F401

HOME = xbmcgui.Window(10000)



def next_episode(tmdb_id):
    """('T1 E41', pct) según watched.db de Palantir: episodio a medias (progress>0) o último visto + 1. None si no empezada."""
    if not tmdb_id:
        return None
    db = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db")
    try:
        con = sqlite3.connect(db, timeout=3)
        rows = con.execute("SELECT season, episode, playcount, progress, lastPlayed FROM episodes_watched WHERE tmdb_id=? ORDER BY lastPlayed DESC", (tmdb_id,)).fetchall()
        con.close()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] watched.db: %s" % e, xbmc.LOGINFO)
        return None
    if not rows:
        return None
    s, e, playcount, progress, _ = rows[0]
    if progress and progress > 0 and not playcount:
        return ("T%d E%d" % (s, e), int(progress))
    return ("T%d E%d" % (s, e + 1), 0)


def route_field(j, name):
    m = re.search(r'"%s": \'([^\']*)\'' % name, j)
    return m.group(1) if m else ""


def art_url(v, size):
    """'/abc.jpg' (ruta de TMDB que guarda Palantir) -> URL completa; URL completa o vacío -> tal cual"""
    return "https://image.tmdb.org/t/p/%s%s" % (size, v) if v.startswith("/") else v


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    if not path.startswith(PLUGIN_ROOT):
        xbmc.log("[flix_series] ruta inválida: %r" % path, xbmc.LOGINFO)
        return
    try:
        j = decode_route(path)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] no decodifico: %s" % e, xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    if "'play_mis_serieS'" in j:
        play, seasons = path, encode_route(j.replace("'play_mis_serieS'", "'listado_temporadaS'"))
    elif "'listado_temporadaS'" in j:
        play, seasons = encode_route(j.replace("'listado_temporadaS'", "'play_mis_serieS'")), path
    else:
        xbmc.log("[flix_series] ruta sin acción de serie conocida; abro tal cual", xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    # fondo y logo para la pantalla de carga (MyVideoNav: flix_opening) desde la propia ruta: vale para todos los
    # caminos (Inicio TV/táctil, secciones, buscador). Rutas relativas de TMDB -> mismo tamaño que pide Palantir (w1280)
    HOME.setProperty("flix_open_fanart", art_url(route_field(j, "fanart"), "w1280"))
    HOME.setProperty("flix_open_logo", art_url(route_field(j, "clearlogo"), "w500"))
    m = re.search(r'"tvshowtitle": \'([^\']*)\'', j)
    tm = re.search(r'"tmdb": \'?(\d+)', j)
    nxt = next_episode(int(tm.group(1)) if tm else None)
    HOME.setProperty("flix_series_next", nxt[0] if nxt else "")
    HOME.setProperty("flix_series_pct", str(nxt[1]) if nxt and nxt[1] else "")
    HOME.setProperty("flix_series_play", play)
    HOME.setProperty("flix_series_folder", seasons)
    HOME.setProperty("flix_series_title", m.group(1) if m else "")
    title = m.group(1) if m else "?"
    HOME.setProperty("flix_section", title)   # cabecera de la ventana Vídeos (si no, sale la última sección: "Anime")
    if nxt and started(tm.group(1)):
        import flix_play
        sub = ("%s a medias  ·  %s %%" % (nxt[0], nxt[1])) if nxt[1] else "Siguiente: %s" % nxt[0]
        choice = flix_play.choose(title, sub, "Seguir viendo  ·  %s" % nxt[0], more="Ver temporadas", pct=nxt[1],
                                  fanart=HOME.getProperty("flix_open_fanart"))
        xbmc.log("[flix_series] %s a medias: opción %d" % (title, choice), xbmc.LOGINFO)
        if choice == 0:
            xbmc.executebuiltin('PlayMedia("%s")' % play)
            return
        if choice == 1:
            play_first(seasons, title)
            return
        if choice != 2:
            return
    xbmc.log("[flix_series] abro temporadas de %s" % title, xbmc.LOGINFO)
    open_checked(seasons, title)


def started(tmdb):
    """serie con ▶ (a medias y seguida; mismo criterio que el póster): vista entera u oculta = no"""
    try:
        import flix_progress
        return (flix_progress.truth_shows() or {}).get(str(tmdb)) == flix_progress.SHOW_STARTED
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] estado de la serie: %s" % e, xbmc.LOGINFO)
        return False


SPECIAL_RE = re.compile(r"especial|special|extra", re.I)


def list_dir(path, props):
    r = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
                                                   "params": {"directory": path, "media": "video", "properties": props}})))
    return (r.get("result") or {}).get("files") or []


def number(f, key, pattern):
    """temporada / capítulo de un elemento: propiedad de Kodi o, si Palantir no la da, el número de la etiqueta"""
    n = f.get(key)
    if isinstance(n, int) and n >= 0:
        return n
    m = re.search(pattern, f.get("title") or f.get("label") or "")
    return int(m.group(1)) if m else None


def pick_season(items):
    """1.ª temporada que no sea especial (temporada 0 / «Especiales»)"""
    ok = [(number(f, "season", r"(\d+)"), i, f) for i, f in enumerate(items)
          if f.get("filetype") != "file" and not SPECIAL_RE.search(f.get("label") or "")]
    ok = [x for x in ok if x[0] != 0]
    ok.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return ok[0][2] if ok else None


def pick_episode(items):
    """capítulo con el número más bajo (Palantir titula «1x01 Nombre»)"""
    eps = [(number(f, "episode", r"\d+x(\d+)"), i, f) for i, f in enumerate(items) if f.get("filetype") != "directory"]
    eps = [x for x in eps if x[0] != 0] or eps
    eps.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return eps[0][2] if eps else None


def play_first(seasons, title):
    """T1 E1 (sin especiales) desde el principio"""
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    ep = None
    try:
        items = list_dir(seasons, ["season", "episode", "title"])
        if any(f.get("filetype") == "file" for f in items):
            # serie de una temporada (Carrie): Palantir da los capítulos directamente. Ojo: «listar» un capítulo
            # lo REPRODUCE (abre el selector) y la lista falla
            ep = pick_episode(items)
        else:
            season = pick_season(items)
            if season:
                ep = pick_episode(list_dir(season["file"], ["season", "episode", "title"]))
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not ep:
        xbmc.log("[flix_series] no encuentro el 1.er capítulo de %s" % title, xbmc.LOGINFO)
        xbmcgui.Dialog().notification(title, "Palantir no responde ahora mismo. Prueba otra vez en un momento.",
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        return
    xbmc.log("[flix_series] %s desde el principio: %s" % (title, ep.get("label")), xbmc.LOGINFO)
    import flix_play
    flix_play.start(ep["file"])


def ver():
    """botón de la pantalla de temporadas: «Continuar · TxEy» = siguiente de Palantir; «Ver» (sin empezar) = T1 E1"""
    if HOME.getProperty("flix_series_next"):
        xbmc.executebuiltin('PlayMedia("%s")' % HOME.getProperty("flix_series_play"))
    else:
        play_first(HOME.getProperty("flix_series_folder"), HOME.getProperty("flix_series_title"))


def loaded_ok(path):
    n = xbmc.getInfoLabel("Container.NumItems")
    return xbmc.getInfoLabel("Container.FolderPath") == path and n.isdigit() and int(n) > 0


def wait_loaded(path, timeout=90):
    """True si la ventana Vídeos acaba mostrando 'path'. False si Palantir falla: entonces Kodi deja a la vista la
    ÚLTIMA carpeta que tuvo esa ventana (p. ej. un "Especial Halloween" de antes) -> hay que detectarlo."""
    t0 = time.time()
    idle_since = None
    while time.time() - t0 < timeout:
        busy = xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Container.IsUpdating")
        if loaded_ok(path) and not busy:
            xbmc.sleep(600)                         # al fallar, Kodi pone un instante la ruta pedida y vuelve atrás
            if loaded_ok(path):
                return True
            continue
        if xbmc.getCondVisibility("Window.IsActive(videos)") and not busy and time.time() - t0 > 2:
            idle_since = idle_since or time.time()
            if time.time() - idle_since > 3:        # ventana quieta 3 s con otra carpeta = falló la carga
                return False
        else:
            idle_since = None
        if not xbmc.getCondVisibility("Window.IsActive(videos)") and time.time() - t0 > 5:
            return True                             # el usuario se fue: nada que vigilar
        xbmc.sleep(200)
    return False


def open_checked(seasons, title, tries=2):
    """Abre las temporadas tapando la carpeta vieja (MyVideoNav: flix_opening) y reintenta una vez si Palantir
    falla (p. ej. ocupado sincronizando Trakt)."""
    HOME.setProperty("flix_opening", "1")
    try:
        for attempt in range(1, tries + 1):
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % seasons)
            if wait_loaded(seasons):
                return
            xbmc.log("[flix_series] Palantir no dio las temporadas de %s (intento %d)" % (title, attempt), xbmc.LOGINFO)
            if xbmc.getCondVisibility("Window.IsActive(videos)"):
                xbmc.executebuiltin("Action(Back)")     # fuera la carpeta vieja
                xbmc.sleep(800)
        xbmcgui.Dialog().notification(title, "Palantir no responde ahora mismo. Prueba otra vez en un momento.",
                                      xbmcgui.NOTIFICATION_INFO, 5000)
    finally:
        HOME.clearProperty("flix_opening")


if __name__ == "__main__":
    if sys.argv[1:2] == ["ver"]:
        ver()
    else:
        main()
