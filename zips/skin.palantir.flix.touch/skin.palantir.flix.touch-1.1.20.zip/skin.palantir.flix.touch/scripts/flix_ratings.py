"""Nota de Letterboxd o Metacritic en lugar de la de TMDB, vía MDBList con la clave PROPIA de cada aparato.

Carlos (20-oct): «el que no tenga API puesta sigue viendo lo de ahora». Sin clave (Skin.String flix_mdblist_key) o
con fuente TMDB (Skin.String flix_rating_src) este script ni arranca el bucle: las etiquetas usan la ★ que da
Palantir (variables FlixRating* de Includes_Flix.xml caen a ListItem.Rating).

Con clave y fuente letterboxd / metacritic, un bucle (lo lanza first_run.py, una vez por sesión) mira lo enfocado:
  ranura li  ListItem.FolderPath                        (filas del Inicio TV, secciones, listados, táctil)
  ranura c5  Container(5000).ListItem.FolderPath        (cabecera del Inicio táctil antiguo / listas)
  ranura fz  Window(home).Property(fhz_path)            (cabecera congelada del Inicio TV al subir al menú)
y deja en Window(home) flix_rt_<ranura> = «Letterboxd 2.9» y flix_rt_<ranura>_path = la ruta a la que corresponde
(el XML solo la usa si coincide con la del elemento: nunca enseña la nota de otro título). Sin nota de esa fuente
para el título -> vacío -> la ★ de TMDB, como siempre.

API: GET https://api.mdblist.com/tmdb/{movie|show}/{tmdb}?apikey=… (1000 consultas/día con clave gratuita). Se pide
solo lo que se queda enfocado DWELL s, en un hilo; caché por aparato (ratings.json) 7 días, «sin nota» 1 día; con
429 o pocas consultas restantes se deja de pedir hasta el reinicio del contador. La clave no sale nunca en el log.
Uso: RunScript(special://skin/scripts/flix_ratings.py)            bucle (first_run)
     RunScript(special://skin/scripts/flix_ratings.py,settings)   Ajustes → Puntuación"""
import ast
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import atomic_write, decode_route  # noqa: E402

API = "https://api.mdblist.com/tmdb/%s/%s?apikey=%s"
SOURCES = {"letterboxd": ("Letterboxd", "%.1f"), "metacritic": ("Metacritic", "%d")}
NAMES = {"tmdb": "TMDB", "letterboxd": "Letterboxd", "metacritic": "Metacritic"}
KIND = {"movies": "movie", "movie": "movie", "tvshows": "show", "tvshow": "show", "seasons": "show",
        "episodes": "show"}
TTL = 7 * 86400         # nota guardada
NEG_TTL = 86400         # «MDBList no tiene nota»: se vuelve a mirar al día siguiente
ERR_TTL = 600           # error de red: no insistir en 10 min
MAX_ENTRIES = 4000
LOW = 25                # consultas restantes por debajo de las cuales se para hasta el reinicio del contador
DWELL = 0.6             # s enfocado antes de pedir (no gastar consultas al pasar de largo)
STEP = 0.25
TIMEOUT = 8


def mask(key):
    return "••••" + key[-4:] if key else "Sin clave"


def target(path):
    """('movie'|'show', tmdb) de una ruta de Palantir; None si no es un título"""
    if not path or "palantir3" not in path or "?" not in path:
        return None
    try:
        info = ast.literal_eval(decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(info, dict):
        return None
    tmdb = str(info.get("tmdb") or "")
    kind = KIND.get(info.get("content") or "")
    if not kind or not tmdb.isdigit() or tmdb == "0":
        return None
    return kind, tmdb


def parse(data):
    """{'letterboxd': 2.9, 'metacritic': 44.0} con las fuentes que interesan y tienen valor"""
    out = {}
    for r in (data or {}).get("ratings") or []:
        src = r.get("source")
        if src in SOURCES and isinstance(r.get("value"), (int, float)) and r["value"] > 0:
            out[src] = float(r["value"])
    return out


def fmt(src, vals):
    """«Letterboxd 2.9» / «Metacritic 44»; '' si no hay nota de esa fuente (-> TMDB)"""
    if src not in SOURCES or not vals or vals.get(src) is None:
        return ""
    name, f = SOURCES[src]
    return "%s %s" % (name, f % vals[src])


class RateLimited(Exception):
    def __init__(self, until):
        Exception.__init__(self, "límite de MDBList")
        self.until = until


def fetch(kind, tmdb, key, opener=urllib.request.urlopen, now=time.time):
    """notas de MDBList ({} si no tiene ninguna de las nuestras). RateLimited si hay que parar."""
    req = urllib.request.Request(API % (kind, tmdb, key), headers={"User-Agent": "Ker0n3Media-skin"})
    try:
        with opener(req, timeout=TIMEOUT) as r:
            body, headers = r.read(), r.headers
    except urllib.error.HTTPError as e:
        if e.code == 429:
            raise RateLimited(_reset(e.headers, now)) from None
        if e.code == 404:
            return {}
        raise
    vals = parse(json.loads(body.decode("utf-8", "replace") or "{}"))
    try:
        remaining = int((headers or {}).get("x-ratelimit-remaining", "") or -1)
    except ValueError:
        remaining = -1
    if 0 <= remaining < LOW:
        raise _Partial(vals, _reset(headers, now))
    return vals


class _Partial(RateLimited):
    """quedan pocas consultas: se usa esta nota pero se para después"""
    def __init__(self, vals, until):
        RateLimited.__init__(self, until)
        self.vals = vals


def _reset(headers, now):
    try:
        until = float((headers or {}).get("x-ratelimit-reset", "") or 0)
    except ValueError:
        until = 0
    t = now()
    return until if t < until < t + 2 * 86400 else t + 6 * 3600


class Cache:
    """ratings.json: {"v": {"movie:123": [ts, {"letterboxd": 2.9, ...} | null]}, "until": ts_parar}"""

    def __init__(self, path, now=time.time):
        self.path, self.now, self.dirty = path, now, False
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        self.v = d.get("v") if isinstance(d.get("v"), dict) else {}
        self.until = float(d.get("until") or 0)

    def get(self, kind, tmdb):
        """(True, vals|None) si está fresca; (False, None) si hay que pedirla"""
        e = self.v.get("%s:%s" % (kind, tmdb))
        if not isinstance(e, list) or len(e) < 2:
            return False, None
        ts, vals = e[0], e[1]
        ttl = TTL if vals else (ERR_TTL if len(e) > 2 else NEG_TTL)
        if self.now() - ts > ttl:
            return False, None
        return True, (vals or None)

    def put(self, kind, tmdb, vals, error=False):
        e = [self.now(), vals if vals else ({} if not error else None)]
        if error:
            e.append("err")
        self.v["%s:%s" % (kind, tmdb)] = e
        if len(self.v) > MAX_ENTRIES:              # fuera las más viejas
            for k in sorted(self.v, key=lambda k: self.v[k][0])[:len(self.v) - MAX_ENTRIES]:
                del self.v[k]
        self.dirty = True

    def blocked(self):
        return self.now() < self.until

    def block(self, until):
        self.until, self.dirty = until, True

    def save(self):
        if self.dirty:
            atomic_write(self.path, json.dumps({"v": self.v, "until": self.until}, separators=(",", ":")))
            self.dirty = False


# ---------- dentro de Kodi ----------
def _kodi():
    import xbmc
    import xbmcgui
    import xbmcvfs
    return xbmc, xbmcgui, xbmcvfs


def settings_now():
    xbmc = _kodi()[0]
    key = xbmc.getInfoLabel("Skin.String(flix_mdblist_key)").strip()
    src = xbmc.getInfoLabel("Skin.String(flix_rating_src)").strip() or "tmdb"
    return (key if key not in ("", "-") else ""), src


def cache_path():
    xbmc, _, xbmcvfs = _kodi()
    return xbmcvfs.translatePath("special://profile/addon_data/%s/ratings.json" % xbmc.getSkinDir())


def log(msg):
    xbmc = _kodi()[0]
    xbmc.log("[flix_ratings] %s" % msg, xbmc.LOGINFO)


SLOTS = (("li", "ListItem.FolderPath"), ("c5", "Container(5000).ListItem.FolderPath"),
         ("fz", "Window(home).Property(fhz_path)"))


class Watcher:
    def __init__(self):
        xbmc, xbmcgui, _ = _kodi()
        self.xbmc, self.home = xbmc, xbmcgui.Window(10000)
        self.cache = Cache(cache_path())
        self.lock = threading.Lock()
        self.busy = set()
        self.seen = {}                  # ranura -> (ruta, desde cuándo)
        self.key, self.src = "", "tmdb"

    def clear(self):
        for s, _ in SLOTS:
            self.home.clearProperty("flix_rt_%s" % s)
            self.home.clearProperty("flix_rt_%s_path" % s)

    def show(self, slot, path, vals):
        self.home.setProperty("flix_rt_%s" % slot, fmt(self.src, vals))
        self.home.setProperty("flix_rt_%s_path" % slot, path)

    def worker(self, kind, tmdb):
        try:
            vals = fetch(kind, tmdb, self.key)
            with self.lock:
                self.cache.put(kind, tmdb, vals)
        except _Partial as e:
            with self.lock:
                self.cache.put(kind, tmdb, e.vals)
                self.cache.block(e.until)
            log("quedan pocas consultas de MDBList: paro hasta %s" % time.strftime("%H:%M", time.localtime(e.until)))
        except RateLimited as e:
            with self.lock:
                self.cache.block(e.until)
            log("límite de MDBList: paro hasta %s" % time.strftime("%H:%M", time.localtime(e.until)))
        except urllib.error.HTTPError as e:
            with self.lock:
                self.cache.put(kind, tmdb, None, error=True)
            log("MDBList %s/%s: HTTP %s%s" % (kind, tmdb, e.code, " (¿clave %s mal?)" % mask(self.key)
                                               if e.code in (401, 403) else ""))
        except Exception as e:  # noqa: BLE001
            with self.lock:
                self.cache.put(kind, tmdb, None, error=True)
            log("MDBList %s/%s: %s" % (kind, tmdb, str(e).replace(self.key, mask(self.key)) if self.key else e))
        finally:
            with self.lock:
                self.busy.discard((kind, tmdb))
                self.cache.save()

    def tick(self):
        now = time.time()
        for slot, label in SLOTS:
            path = self.xbmc.getInfoLabel(label)
            prev = self.seen.get(slot)
            if not prev or prev[0] != path:
                self.seen[slot] = (path, now)
                prev = self.seen[slot]
            t = target(path)
            if not t:
                continue
            with self.lock:
                hit, vals = self.cache.get(*t)
                blocked = self.cache.blocked()
                busy = t in self.busy
            if hit:
                if (self.home.getProperty("flix_rt_%s_path" % slot) != path
                        or self.home.getProperty("flix_rt_%s" % slot) != fmt(self.src, vals)):
                    self.show(slot, path, vals)
            elif not busy and not blocked and now - prev[1] >= DWELL:
                with self.lock:
                    self.busy.add(t)
                threading.Thread(target=self.worker, args=t, daemon=True).start()

    def run(self):
        mon = self.xbmc.Monitor()
        active = None
        while not mon.abortRequested():
            self.key, self.src = settings_now()
            on = bool(self.key) and self.src in SOURCES
            if on != active:
                log("nota de %s (clave %s)" % (NAMES[self.src], mask(self.key)) if on
                    else "sin clave de MDBList o fuente TMDB: la ★ de siempre")
                active = on
                self.clear()
            if on:
                self.tick()
            if mon.waitForAbort(STEP if on else 3):
                break


def wanted(path):
    """True si esta ruta debería llevar nota de MDBList (clave puesta, fuente no TMDB y es un título)"""
    key, src = settings_now()
    return bool(key) and src in SOURCES and target(path) is not None


def label_for(path, wait=0.0):
    """para scripts (ficha, Inicio táctil): «Letterboxd 2.9» si está activa y hay nota (de caché o, con wait > 0,
    pidiéndola como mucho wait s); '' si no -> el que llama pone la ★ de TMDB"""
    key, src = settings_now()
    t = target(path)
    if not key or src not in SOURCES or not t:
        return ""
    c = Cache(cache_path())
    hit, vals = c.get(*t)
    if hit:
        return fmt(src, vals)
    if wait <= 0 or c.blocked():
        return ""
    try:
        vals = fetch(*t, key)
        c.put(*t, vals)
    except _Partial as e:
        c.put(*t, e.vals)
        c.block(e.until)
        vals = e.vals
    except RateLimited as e:
        c.block(e.until)
        vals = None
    except Exception:  # noqa: BLE001
        c.put(*t, None, error=True)
        vals = None
    c.save()
    return fmt(src, vals)


def settings_dialog():
    """Ajustes → Puntuación: fuente y clave de MDBList"""
    xbmc, xbmcgui, _ = _kodi()
    key, src = settings_now()
    opts = [("tmdb", "TMDB (la de siempre)"), ("letterboxd", "Letterboxd (0-5)"), ("metacritic", "Metacritic (0-100)"),
            ("key", "Clave de MDBList: %s" % mask(key))]
    i = xbmcgui.Dialog().select("Puntuación", [o[1] for o in opts],
                                preselect=[o[0] for o in opts].index(src) if src in NAMES else 0)
    if i < 0:
        return
    choice = opts[i][0]
    if choice == "key" or (choice in SOURCES and not key):
        new = xbmcgui.Dialog().input("Clave de MDBList (mdblist.com → Preferences → API)").strip()
        if not new:
            if choice == "key":
                return
            xbmcgui.Dialog().notification("Puntuación", "Sin clave de MDBList: se queda TMDB", time=3000)
            return
        if not re.fullmatch(r"[A-Za-z0-9]{8,64}", new):
            xbmcgui.Dialog().notification("Puntuación", "Esa clave no parece válida", time=3000)
            return
        xbmc.executebuiltin("Skin.SetString(flix_mdblist_key,%s)" % new)
        if choice == "key":
            choice = src if src in SOURCES else "letterboxd"
    xbmc.executebuiltin("Skin.SetString(flix_rating_src,%s)" % choice)


def main(argv):
    if len(argv) > 1 and argv[1] == "settings":
        settings_dialog()
        return
    Watcher().run()


if __name__ == "__main__":
    main(sys.argv)
