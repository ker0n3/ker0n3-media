"""onload de DialogConfirm: si el diálogo es el progreso de AllDebrid/Real-Debrid, pone
Window(home).Property(flix_debrid)=true y el skin lo oculta y enseña la rueda de carga (DialogConfirm, FlixHideP3Debrid).
Hace falta un script: en las condiciones del skin Control.GetLabel(9) del propio diálogo no funciona (siempre falso),
aunque desde Python sí se lee. La propiedad la borra el onunload de DialogConfirm."""


def is_debrid(heading, text):
    return "debrid" in ("%s %s" % (heading, text)).lower()


def main():
    import xbmc
    for _ in range(30):                      # Palantir rellena el texto justo después de abrir: hasta ~1,5 s
        if not xbmc.getCondVisibility("Window.IsActive(progressdialog)"):
            return
        if is_debrid(xbmc.getInfoLabel("Control.GetLabel(1)"), xbmc.getInfoLabel("Control.GetLabel(9)")):
            xbmc.executebuiltin("SetProperty(flix_debrid,true,home)")
            return
        xbmc.sleep(50)


if __name__ == "__main__":
    main()
