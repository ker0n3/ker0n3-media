"""Actualizaciones automáticas: al arrancar, deja el aparato enganchado al repositorio Ker0n3 Media.

1. Si falta el addon repository.ker0n3media, lo instala desde la copia que trae el skin
   (resources/repository.ker0n3media) y lo activa.
2. Kodi NO actualiza solo lo que se instaló desde un zip (origen vacío), con ningún ajuste: si el skin no tiene
   origen, se le pone el del repositorio en Addons33.db (efecto al siguiente arranque).
3. Kodi solo revisa los repositorios una vez cada 24 h (no en cada arranque): si la última revisión del repositorio
   Ker0n3 Media tiene más de CHECK_HOURS, se pide a Kodi que los revise ya (UpdateAddonRepos) para que una versión
   nueva llegue en el siguiente arranque (la Shield no se actualizaba tras abrir Kodi 4 veces, 18-oct-2026).
Se ejecuta desde Startup.xml; no hace nada si ya está todo bien.
"""
import datetime
import glob
import json
import os
import shutil
import sqlite3

import xbmc
import xbmcvfs

REPO = "repository.ker0n3media"
CHECK_HOURS = 2
SKIN_ID = xbmc.getSkinDir()


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[flix_repo] %s" % msg, level)


def rpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def ensure_repo():
    dst = xbmcvfs.translatePath("special://home/addons/%s" % REPO)
    src = xbmcvfs.translatePath("special://skin/resources/%s" % REPO)
    if os.path.isdir(dst):
        det = rpc("Addons.GetAddonDetails", {"addonid": REPO, "properties": ["enabled"]})
        if (det.get("result") or {}).get("addon", {}).get("enabled") is False:
            return enable_repo(tries=3)          # copiado en un arranque anterior pero sin llegar a activarse
        return False
    if not os.path.isdir(src):
        return False
    shutil.copytree(src, dst)
    xbmc.executebuiltin("UpdateLocalAddons")
    return enable_repo()


def enable_repo(tries=20, wait_ms=500):
    """Kodi tarda en registrar el addon copiado: reintenta la activación y dice si de verdad quedó activo (PY-15)"""
    for _ in range(tries):
        if wait_ms:
            xbmc.sleep(wait_ms)
        if rpc("Addons.SetAddonEnabled", {"addonid": REPO, "enabled": True}).get("result") == "OK":
            log("repositorio instalado y activado")
            return True
    log("repositorio copiado pero no se pudo activar (se reintentará en el próximo arranque)", xbmc.LOGWARNING)
    return False


def ensure_origin():
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath("special://database/"), "Addons*.db")))
    if not dbs:
        return
    con = sqlite3.connect(dbs[-1], timeout=5)
    try:
        cur = con.execute("SELECT origin FROM installed WHERE addonID=?", (SKIN_ID,)).fetchone()
        if cur is not None and not cur[0]:
            con.execute("UPDATE installed SET origin=? WHERE addonID=?", (REPO, SKIN_ID))
            con.commit()
            log("%s enganchado al repositorio (antes: instalado desde zip)" % SKIN_ID)
    finally:
        con.close()


def addons_db():
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath("special://database/"), "Addons*.db")))
    return dbs[-1] if dbs else None


def maybe_check():
    db = addons_db()
    if not db:
        return
    con = sqlite3.connect(db, timeout=5)
    try:
        row = con.execute("SELECT lastcheck FROM repo WHERE addonID=?", (REPO,)).fetchone()
    finally:
        con.close()
    if row and row[0]:
        try:
            last = datetime.datetime.strptime(row[0][:19], "%Y-%m-%d %H:%M:%S")
            if datetime.datetime.now() - last < datetime.timedelta(hours=CHECK_HOURS):
                return
        except ValueError:
            pass
    xbmc.executebuiltin("UpdateAddonRepos")
    log("revisión de repositorios pedida (última: %s)" % (row[0] if row else "nunca"))


def main():
    try:
        ensure_repo()
        ensure_origin()
        maybe_check()
    except Exception as e:  # noqa: BLE001
        log("error: %s" % e, xbmc.LOGWARNING)


if __name__ == "__main__":
    main()
