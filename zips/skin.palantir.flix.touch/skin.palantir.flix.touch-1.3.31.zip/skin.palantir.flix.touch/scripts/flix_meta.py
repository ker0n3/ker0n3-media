# -*- coding: utf-8 -*-
"""Duración y edad del catálogo de Palantir para los títulos que llegan sin ellas (Carlos, 13-nov: en la cabecera del
Inicio «después del año debería ir la duración» y «la edad no siempre aparece»).

Las filas en directo (flix_direct) ya traen duración y edad; las que siguen saliendo de Palantir (Top 10, «Seguir
viendo», series en seguimiento) no: Palantir no manda ni la duración de su lista ni la edad (ListItem.Mpaa vacío), y
la edad de TMDB (flix_age) solo existe si TMDB tiene la calificación española. En su base de contenido cada película
lleva su duración en segundos y su edad («16», «APTA», «+18»…), y cada serie su edad.

Solo se consulta lo que falta, título a título, con una conexión de solo lectura por intérprete (≈1 ms por título).
Cualquier fallo (sin Palantir, otra estructura de su base) devuelve (0, '') y no cambia nada."""
import re
import sqlite3
import threading

TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')
SHOW_RE = re.compile(r'"content": \'(?:tvshows|seasons|episodes)\'|\'listado_temporadaS\'|\'play_mis_serieS\'')
_c = {"db": None, "sig": None}
_lock = threading.Lock()


def _conn():
    import flix_direct
    path = flix_direct.content_db()
    sig = flix_direct.content_sig(path)
    if not sig:
        return None
    if _c["sig"] != sig:                         # Palantir actualizó su catálogo: conexión nueva
        if _c["db"] is not None:
            try:
                _c["db"].close()
            except Exception:  # noqa: BLE001
                pass
        _c["db"] = sqlite3.connect(flix_direct.uri(path), uri=True, timeout=2, check_same_thread=False)
        _c["sig"] = sig
    return _c["db"]


def target(path):
    """('movie' | 'tv', tmdb) de una ruta de Palantir; None si no es un título"""
    import flix_common
    try:
        j = flix_common.decode_route(path or "")
    except Exception:  # noqa: BLE001
        return None
    m = TMDB_RE.search(j or "")
    if not m:
        return None
    return ("tv" if SHOW_RE.search(j) else "movie"), int(m.group(1))


def lookup(path):
    """(duración en segundos, edad TP/7/…/18) del catálogo; (0, '') si no se sabe"""
    t = target(path)
    if not t:
        return 0, ""
    import flix_age
    try:
        with _lock:
            db = _conn()
            if db is None:
                return 0, ""
            if t[0] == "movie":
                r = db.execute("SELECT duration, mpaa FROM pelis WHERE tmdb = ?", (t[1],)).fetchone()
            else:
                r = db.execute("SELECT 0, mpaa FROM series WHERE tmdb = ?", (t[1],)).fetchone()
    except Exception:  # noqa: BLE001
        return 0, ""
    if not r:
        return 0, ""
    try:
        dur = int(r[0] or 0)
    except (TypeError, ValueError):
        dur = 0
    return dur, flix_age.normalize(r[1] or "")


def complete(li, f):
    """pone en la carátula lo que le falte: la edad (de la fila si la trae; si no, del catálogo) y la duración de las
    películas. to_listitem solo lee «duration»; las filas de Palantir la mandan como «runtime» (Top 10: no salía).
    Nunca pisa lo que ya tiene"""
    try:
        has_dur = bool(f.get("duration"))           # la que ya puso to_listitem
        if li.getProperty("FlixAge") and has_dur:
            return
        import flix_age
        age = li.getProperty("FlixAge") or flix_age.normalize(f.get("mpaa") or "")
        dur = int(f.get("duration") or f.get("runtime") or 0)
        if not age or not dur:
            d2, a2 = lookup(f.get("file") or "")
            age, dur = age or a2, dur or d2
        if age and not li.getProperty("FlixAge"):
            li.setProperty("FlixAge", age)
        if dur and not has_dur:
            li.getVideoInfoTag().setDuration(dur)
    except Exception:  # noqa: BLE001
        pass
