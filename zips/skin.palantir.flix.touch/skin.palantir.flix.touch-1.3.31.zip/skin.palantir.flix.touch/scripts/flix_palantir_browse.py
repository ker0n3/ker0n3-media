"""Explorador de los menús reales de Palantir para añadir una fila al Inicio (editor flix_home_order.py).

browse() -> (nombre, ruta) o None. En cada carpeta, la primera opción es "Añadir «X» como fila (N títulos)" si la
carpeta lista títulos; el resto son sus subcarpetas. Atrás sube un nivel; arriba del todo cancela.
Qué carpetas se ofrecen lo decide flix_home_conf.classify (sin búsquedas, ajustes ni "Más…").
Palantir atiende de una en una (~3-4 s por carpeta): se muestra el aviso de carga mientras tanto.
"""
import os
import sys

import xbmc
import xbmcgui

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_home_conf as hc  # noqa: E402
import flix_picker  # noqa: E402

ROOT = "plugin://plugin.video.palantir3/"
HELP = "Abre un menú y elige «Añadir … como fila». Atrás sube un nivel."
# otros orígenes, como Arctic Fuse 3 (Carlos, 13-nov: «hacer lo mismo que hace Arctic Fuse»): lo que Kodi ya sabe listar
ORIGINS = (("Biblioteca de Kodi (películas, series, música…)", "library://video/"),
           ("Carpetas y discos (fuentes de Kodi: NAS, USB…)", "sources://video/"),
           ("Carpetas de fotos (fuentes de imágenes de Kodi)", "sources://pictures/"),  # PICTURE_SOURCES
           ("Otros complementos de vídeo", "addons://sources/video/"),
           ("Favoritos de Kodi", "favourites://"),
           ("Listas de reproducción", "special://videoplaylists/"))
PICTURE_SOURCES = "sources://pictures/"
ORIGINS_HELP = "Lo que tengas en Kodi fuera de Palantir: se añade como una fila más. Al pulsar, lo de Kodi: reproducir, ver la foto o abrir"


def log(msg):
    xbmc.log("[flix_palantir_browse] %s" % msg, xbmc.LOGINFO)


def listing(path):
    try:
        if path == PICTURE_SOURCES:
            # Kodi no deja pedir sources://pictures/ por JSON-RPC (sí sources://video/): sus fuentes, una a una
            got = flix_common.rpc("Files.GetSources", {"media": "pictures"})
            return [{"label": x.get("label", ""), "file": x.get("file", ""), "filetype": "directory"}
                    for x in (got.get("result") or {}).get("sources") or []]
        if flix_common.is_fs(path):
            return flix_common.list_fs(path, ["title"])   # carpeta del NAS, USB…: también fotos
        return flix_common.list_dir(path, ["title"])      # JSON-RPC común (revisión 29-oct DAT-20)
    except ValueError:
        return []                                          # respuesta que no es JSON: nada, como antes


def browse_external():
    """otros orígenes (biblioteca de Kodi, fuentes, complementos, favoritos, listas): elegir uno y explorarlo como el
    menú de Palantir. (nombre, ruta) o None"""
    k = flix_picker.pick("Otros orígenes", [o[0] for o in ORIGINS], ORIGINS_HELP)
    if k < 0:
        return None
    return browse(ORIGINS[k][0].split(" (")[0], ORIGINS[k][1])


def browse(root_label="Palantir", root=ROOT):
    stack = [(root_label, root)]
    seen = {}                                   # ruta -> listado (volver atrás no repite la llamada a Palantir)
    while stack:
        label, path = stack[-1]
        if path not in seen:
            flix_picker.busy(True)
            try:
                seen[path] = hc.classify(listing(path))
            finally:
                flix_picker.busy(False)
        folders, titles = seen[path]
        if root != ROOT and flix_common.is_fs(path):
            # carpeta del NAS: también vale si solo tiene subcarpetas (la fila las enseña y al pulsar se abren)
            n, what = titles + len(folders), "elemento"
        else:
            n, what = titles, "título"
        add = ["Añadir «%s» como fila (%d %s)" % (label, n, what if n == 1 else what + "s")] \
            if n and len(stack) > 1 else []
        labels = add + [f["label"] for f in folders]
        if not labels:
            xbmcgui.Dialog().notification(stack[0][0], "Aquí no hay nada que añadir", xbmcgui.NOTIFICATION_INFO, 2500)
            stack.pop()
            continue
        title = " › ".join(s[0] for s in stack[1:]) or "Explorar %s" % stack[0][0]
        k = flix_picker.pick(title, labels, HELP)
        if k < 0:
            stack.pop()
            continue
        if add and k == 0:
            name = xbmcgui.Dialog().input("Nombre de la fila", defaultt=label).strip()
            if name:
                log("fila añadida: %s" % name)
                return name, path
            continue
        f = folders[k - len(add)]
        stack.append((f["label"], f["file"]))
    return None
