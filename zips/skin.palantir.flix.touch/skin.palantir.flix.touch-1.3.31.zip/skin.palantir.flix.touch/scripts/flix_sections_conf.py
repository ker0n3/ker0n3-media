"""Secciones del menú (barra lateral TV, tarjetas táctiles) y filas de cada sección, por aparato (Carlos, 21-oct).
Lógica pura (sin xbmc): la usan flix_sections.py (editor y propiedades del menú), flix_section.py (TV) y
flix_home.py (táctil). Fichero: special://profile/addon_data/<skin>/sections.json
  {"sections": [{"key", "label", "on", "kind": "rows"|"list", "src": variable p3… o ruta, "icon",
                 "rows": {"order": [etiquetas], "off": [etiquetas]}}]}
  opcional: "name"/"name_for" (nombre propio), rows "names" {etiqueta: nombre}, "follow"/"gone" (Especial…)
Inicio no está aquí: siempre primero. Sin fichero = las 7 de siempre (y las ocultas con flix_hide_<clave>)."""

MAX_SECTIONS = 14       # huecos fijos de la barra de la TV (Home.xml, lista 9000)
TOUCH_MAX = 7           # tarjetas que caben en la fila táctil (no se desplaza)
MAX_SECTION_ROWS = 16   # filas de una sección (TV: huecos de flix_section.NROWS); las añadidas cuentan

DEFAULTS = [
    {"key": "peliculas", "label": "Películas", "kind": "rows", "src": "p3Peliculas", "icon": "flix/icons/peliculas.png"},
    {"key": "series", "label": "Series", "kind": "rows", "src": "p3Series", "icon": "flix/icons/series.png"},
    {"key": "anime", "label": "Anime", "kind": "rows", "src": "p3Anime", "icon": "flix/icons/anime.png"},
    {"key": "dibujos", "label": "Dibujos", "kind": "rows", "src": "p3Dibujos", "icon": "flix/icons/dibujos.png"},
    {"key": "documentales", "label": "Documentales", "kind": "rows", "src": "p3Documentales",
     "icon": "flix/icons/documentales.png"},
    # Trakt: en filas, una por lista (aparcada en 1.5.88-1.5.89 mientras era una rejilla que no se entendía)
    {"key": "trakt", "label": "Trakt", "kind": "rows", "src": "p3PathTrakt", "icon": "flix/icons/trakt.png"},
    {"key": "favoritos", "label": "Favoritos", "kind": "rows", "src": "p3Favoritos", "icon": "flix/icons/favoritos.png"},
]
_DEF = {d["key"]: d for d in DEFAULTS}
# entradas del menú principal de Palantir que ya son secciones de serie, o que no se ofrecen
SAME = {"películas": "peliculas", "series": "series", "anime": "anime", "dibujos": "dibujos",
        "documentales": "documentales", "favoritos": "favoritos", "listas trakt.tv": "trakt"}
NEVER = ("buscar",)
FOLLOW = "especial"     # sección que sigue a Palantir: la entrada del menú principal que empiece por esto


def follows(label):
    return (label or "").strip().lower().startswith(FOLLOW)


def shown(s):
    """nombre que se enseña: el propio si se puso para este nombre de Palantir; si no, el de Palantir"""
    return s["name"] if s.get("name") and s.get("name_for") == s["label"] else s["label"]
ICONS = {"telenovelas": "heart-handshake", "música": "music", "nuestra selección": "award", "especial": "sparkles",
         "películas no finalizadas": "circle-play", "series en seguimiento": "eye"}


# «Cambiar icono» de una sección (Carlos, 13-nov: «para que tengamos opciones para varios casos»): (lo que se lee,
# fichero en flix/icons). El elegido se guarda en "icon_own"; sin él, el de serie o el que toca por el nombre (icon_for)
ICON_CHOICES = (
    ("Carpeta", "folder"), ("Fotos", "image"), ("Vídeos caseros", "video"), ("NAS o disco", "hard-drive"),
    ("Películas", "peliculas"), ("Cine", "popcorn"), ("Rollo de película", "film"), ("Series", "series"),
    ("TV en directo", "radio"), ("Anime", "anime"), ("Dibujos", "dibujos"), ("Infantil", "baby"),
    ("Familia", "users"), ("Documentales", "documentales"), ("Deportes", "trophy"), ("Música", "music"),
    ("Conciertos", "mic-vocal"), ("Juegos", "gamepad-2"), ("Terror", "ghost"), ("Comedia", "laugh"),
    ("Ciencia ficción", "rocket"), ("Telenovelas", "heart-handshake"), ("Favoritos", "favoritos"),
    ("Tendencias", "flame"), ("Especial", "sparkles"), ("Premios", "award"), ("Destacado", "star"),
    ("En seguimiento", "eye"), ("Seguir viendo", "circle-play"), ("Historial", "history"),
    ("Mi lista", "bookmark"), ("Listas", "list-video"), ("Internet", "globe"), ("Trakt", "trakt"))
ICON_NAMES = {f for _, f in ICON_CHOICES}


def icon_file(name):
    return "flix/icons/%s.png" % name


def own_icon(s):
    """el icono elegido a mano, si es de la lista (si no, nada: se queda el de siempre)"""
    v = s.get("icon_own")
    return v if isinstance(v, str) and v in ICON_NAMES else ""


def icon_for(label):
    l = (label or "").strip().lower()
    name = next((v for k, v in ICONS.items() if l.startswith(k)), "folder")
    return "flix/icons/%s.png" % name


def new_section(label, path, kind):
    # la clave viaja en RunScript(...,<clave>): sin comas ni comillas
    key = "p3:%s" % label.replace(",", " ").replace('"', "'")
    return {"key": key, "label": label, "on": True, "kind": kind, "src": path, "icon": icon_for(label),
            "rows": {"order": [], "off": []}, "follow": follows(label), "gone": False}


def _rows(r):
    r = r if isinstance(r, dict) else {}
    out = {"order": [x for x in r.get("order") or [] if isinstance(x, str)],
           "off": [x for x in r.get("off") or [] if isinstance(x, str)]}
    names = r.get("names") if isinstance(r.get("names"), dict) else {}
    names = {k: v.strip() for k, v in names.items() if isinstance(k, str) and isinstance(v, str) and v.strip()}
    if names:
        out["names"] = names        # solo si hay: así lo de antes queda igual
    custom, seen = [], set()
    for c in r.get("custom") or []:
        if isinstance(c, dict) and isinstance(c.get("label"), str) and isinstance(c.get("path"), str) and \
                c["label"].strip() and c["path"] and c["label"] not in seen:
            seen.add(c["label"])
            custom.append({"label": c["label"], "path": c["path"]})
    if custom:
        out["custom"] = custom      # filas añadidas (listas de TMDB o menús de Palantir), Carlos 24-oct
    deleted = []
    for x in r.get("deleted") or []:
        if isinstance(x, str) and x not in deleted:
            deleted.append(x)
    if deleted:
        out["deleted"] = deleted    # filas de Palantir quitadas de la sección (se recuperan con «Añadir fila»)
    return out


def custom_rows(rconf, taken=()):
    """filas añadidas a la sección como las de Palantir ({label, path, kind, group}); si Palantir ya trae una fila con
    ese nombre, gana la suya"""
    out = []
    for c in rconf.get("custom") or []:
        if c["label"] in taken:
            continue
        p = c["path"]
        act = "" if p.startswith("flix://tmdb/") else _action(p)
        kind = "list" if p.startswith("flix://tmdb/") or act in ("listado_peliculaS", "listado_serieS") else "coll"
        out.append({"label": c["label"], "path": p, "kind": kind, "group": "", "custom": True})
    return out


def _action(path):
    import flix_home_conf
    return flix_home_conf.action_of(path)


def _name(s):
    """nombre propio guardado (y para qué nombre de Palantir se puso)"""
    if isinstance(s.get("name"), str) and s["name"].strip() and isinstance(s.get("name_for"), str):
        return {"name": s["name"].strip(), "name_for": s["name_for"]}
    return {}


def default_conf(hidden):
    return {"sections": [dict(d, on=d["key"] not in hidden, rows={"order": [], "off": []}) for d in DEFAULTS]}


def normalize(raw):
    if not isinstance(raw, dict) or not isinstance(raw.get("sections"), list):
        return default_conf(set())
    out, seen = [], set()
    for s in raw["sections"]:
        if not isinstance(s, dict) or s.get("key") in seen:
            continue
        k = s.get("key")
        if k in _DEF:
            sec = dict(_DEF[k], on=s.get("on", True) is not False, rows=_rows(s.get("rows")), **_name(s))
            if own_icon(s):
                sec.update(icon=icon_file(own_icon(s)), icon_own=own_icon(s))
            if s.get("deleted") is True:        # de serie eliminada (vuelve con «Añadir sección»), Carlos 24-oct
                sec.update(deleted=True, on=False)
            out.append(sec)
        elif isinstance(k, str) and k.startswith("p3:") and s.get("src") and s.get("kind") in ("rows", "list"):
            lab = s.get("label") or k[3:]
            fol = follows(lab)          # «Especial…»: también las guardadas antes de existir esto
            out.append(dict({"key": k, "label": lab, "on": s.get("on", True) is not False, "kind": s["kind"],
                             "src": s["src"], "icon": icon_for(lab), "rows": _rows(s.get("rows")),   # icono por nombre: sigue a la tabla
                             "follow": fol, "gone": fol and s.get("gone") is True}, **_name(s)))
            if own_icon(s):
                out[-1].update(icon=icon_file(own_icon(s)), icon_own=own_icon(s))     # elegido a mano: manda
        else:
            continue
        seen.add(k)
    out += [dict(d, on=False, rows={"order": [], "off": []}) for d in DEFAULTS if d["key"] not in seen]
    return {"sections": out}


def active(conf):
    return [s for s in conf["sections"] if s["on"] and not s.get("gone") and not s.get("deleted")][:MAX_SECTIONS]


def candidates(conf, root_items):
    have = {s["label"].lower() for s in conf["sections"]}
    following = any(s.get("follow") for s in conf["sections"])     # ya hay una que sigue al especial de Palantir
    out = []
    for it in root_items:
        l = it["label"].strip()
        low = l.lower()
        if not l or low in SAME or low in have or any(low.startswith(n) for n in NEVER) or (following and follows(l)):
            continue
        out.append({"label": l, "path": it["path"]})
    return out


def _ordered(labels, rconf):
    order = [l for l in rconf.get("order") or [] if l in labels]
    return order + [l for l in labels if l not in order]


def apply_rows(rows, rconf):
    gone = set(rconf.get("deleted") or [])
    rows = [r for r in rows if r["label"] not in gone]
    rows += custom_rows(rconf, {r["label"] for r in rows})
    by = {r["label"]: r for r in rows}
    off = set(rconf.get("off") or [])
    names = rconf.get("names") or {}
    return [dict(by[l], title=names[l]) if l in names else by[l] for l in _ordered(list(by), rconf) if l not in off]


def row_editor_items(rows, rconf):
    off, gone = set(rconf.get("off") or []), set(rconf.get("deleted") or [])
    labels = [r["label"] for r in rows if r["label"] not in gone]
    labels += [c["label"] for c in custom_rows(rconf, set(labels))]
    return [(l, l not in off) for l in _ordered(labels, rconf)]


def follow_update(conf, root_items):
    """root_items = [{"label", "path"}] del menú principal de Palantir (nombres ya limpios). Las secciones que siguen
    toman el nombre y la ruta de la primera entrada «Especial…»; si no hay ninguna, quedan gone (fuera del menú).
    Devuelve True si algo cambió."""
    cur = next((it for it in root_items if follows(it["label"])), None)
    changed = False
    for s in conf["sections"]:
        if not s.get("follow"):
            continue
        new = {"gone": True} if cur is None else {"label": cur["label"], "src": cur["path"], "gone": False,
                                                  "icon": icon_file(own_icon(s)) if own_icon(s) else icon_for(cur["label"])}
        if any(s.get(k) != v for k, v in new.items()):
            s.update(new)
            changed = True
    return changed
