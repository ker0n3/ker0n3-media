"""Sincronización de Palantir con Trakt al arrancar, sin frenar el Inicio.

Palantir no tiene servicio: lo que se marca en OTRO aparato (vista, progreso, dejar de seguir) solo baja de Trakt
cuando se abre SU MENÚ RAÍZ (plugin://plugin.video.palantir3/), que la skin original enseñaba en el Inicio. Nuestro
Inicio va directo a las filas y nunca lo abre: la Shield llevaba días sin traer nada de Trakt (Carlos, 20-oct:
Obsession vista en la Shield y no en el móvil, serie dejada de seguir que seguía). Probado en la Shield (20-oct):
listar la raíz trae lo marcado en el móvil en ~10 s; `RunScript(plugin.video.palantir3,None,&update=1)` no trae nada.
Y SOLO la 1.ª vez de cada sesión de Kodi (medido 20-oct en Shield y Fire TV: 2.ª raíz, raíz en pantalla, marcar
vista / no vista... nada vuelve a bajar de Trakt hasta reiniciar Kodi; la skin original tampoco lo pide más): por
eso se hace una sola vez, al arrancar (antes repetía cada 30 min y al acabar un vídeo sin traer nada).

Ahora se lista la raíz (sin enseñarla) DELAY s después del arranque y, cuando Palantir termina de escribir watched.db,
se ponen al día las filas: ✓ y progreso de películas (flix_progress.py) y, si cambiaron series seguidas o
capítulos vistos, la lista «Series en seguimiento» de la caché de Palantir se borra y se recarga esa fila.
Antes de listarla se marcan las pausas (mark_pauses) para que las pelis/capítulos a medias queden iguales que
en Trakt: Palantir por sí solo nunca borra lo quitado del progreso en otro aparato.
Lo llama first_run.py (una vez por sesión)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import sqlite3
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import flix_common  # noqa: E402

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath(flix_common.P3DATA_REL)
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
SEEN_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/p3sync_seen.json" % xbmc.getSkinDir())
ROOT = "plugin://plugin.video.palantir3/"
DELAY = 20          # s tras el arranque: el Inicio ya está pintado
WATCH = 120         # s como mucho esperando a que Palantir escriba (tarda ~10 s)
STEP = 5
PAUSE_TABLES = {"movies": "movies_watched", "episodes": "episodes_watched"}
BACKUP = WATCHED_DB + ".flixbak"   # foto antes de rehacer las pausas: la leen los demás mientras dura la sincronización
PAUSE_KEYS = {"movies_watched": ("tmdb_id",), "episodes_watched": ("tmdb_id", "season", "episode")}
_SAVED = {}                         # filas quitadas por prepare_pauses: se devuelven si Palantir no las rellena
# y en disco: si Kodi se cierra a mitad de la sincronización, _SAVED se pierde con el proceso y la foto BACKUP la borra
# el arranque siguiente → la Shield se quedó SIN NINGUNA peli ni capítulo a medias (Carlos, 12-nov: Palantir no
# bajaba de Trakt, «Error al sincronizar vistos: 'movies'», y Kodi se reinició durante la sincronización)
PENDING = WATCHED_DB + ".flixpausas"
# Palantir no avisa cuando Trakt le rechaza (autorización caducada): solo deja en el registro «Error al sincronizar
# vistos: 'movies'» y sigue. Los 3 aparatos de Carlos dejaron de sincronizar la misma noche (12-nov) y nadie se enteró
# hasta ver «Seguir viendo» distinto en cada uno. Volver a vincular Trakt en Palantir lo arregla
TRAKT_ERR = "[plugin.video.palantir3] Error al sincronizar vistos"
# Caso mudo (leído en el código de Palantir, 12-nov): si no consigue renovar su autorización se queda sin ella, y su
# sincronización sale sin escribir NADA en el registro (ni «Sincronizando…»). Con Trakt activado en sus ajustes y sin
# ese intento, tampoco sincroniza. No cuenta si Palantir tenía puesto su cerrojo de actualización (p3UpdateLock: con
# él su raíz sale sin hacer nada) ni si no hay conexión (sin red deja el mismo error que con la autorización rechazada)
TRAKT_TRY = "[plugin.video.palantir3] Sincronizando vistos con Trakt.tv"
# lo último que hace su sincronización son los favoritos: con esa línea ya no va a escribir más
TRAKT_END = ("[plugin.video.palantir3] ... favoritos", "[plugin.video.palantir3] Error al sincronizar favoritos")
P3_LOCK = "p3UpdateLock"
LOG_TAIL = 512 * 1024               # lo último del registro: la sincronización acaba de pasar
# Repetición con Kodi ya abierto (argumento «resync», la pide flix_resync desde el Inicio). Palantir solo sincroniza
# una vez por sesión por esta marca suya (flix_resync.py lo cuenta); se le borra y se repite el ciclo. Con alguien
# delante NO se sacan las pausas de la base ni un momento (si se pulsa una peli a medias justo entonces, empezaría de
# cero): se MARCAN cambiando la Z final de su lastPlayed por «z» (nadie interpreta esa letra: Palantir y la skin solo
# comparan y ordenan el texto), se quita la fecha para que Palantir vuelva a escribir TODAS las que tiene Trakt (con Z)
# y, al acabar, las que sigan marcadas son las que Trakt ya no tiene: esas se borran. Si Palantir no las rebaja, se
# desmarcan y no ha pasado nada. Un corte a mitad deja como mucho marcas, que se quitan en el arranque siguiente
P3_MARK = "P3syncToTrakt"
RUNNING = "flix_p3sync_running"     # = flix_resync.RUNNING
LAST = "flix_p3sync_last"           # = flix_resync.LAST: hora de la última sincronización acabada
WARNED = "flix_trakt_warned"        # el aviso de Trakt, una vez por sesión de Kodi (la repetición no insiste)
MARKED = "substr(lastPlayed, -1) = 'z'"      # con = y no LIKE: LIKE no distingue mayúsculas
MUTE_WAIT = 15                       # s tras listar la raíz: Palantir escribe «Sincronizando…» al momento, si lo intenta
_TRAKT = {"failed": False, "locked": False, "mute": False, "marked": False}


def log(msg):
    xbmc.log("[flix_p3sync] %s" % msg, xbmc.LOGINFO)


def file_sig():
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def shows_sig():
    """series seguidas (no ocultas) + capítulos vistos: si cambian, «Series en seguimiento» está vieja"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            shows = sorted(r[0] for r in db.execute("SELECT tmdb_id FROM shows_watched WHERE NOT ocultar"))
            eps = db.execute("SELECT COUNT(*), MAX(lastPlayed), SUM(progress) FROM episodes_watched").fetchone()
        finally:
            db.close()
        return repr((shows, eps))
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def resume_sig():
    """pelis a medias de watched.db (las de «Seguir viendo»: progress > 0, como Palantir): si cambian, la fila del
    Inicio está vieja. Con el playcount: una peli terminada puede quedarse con su % (Palantir pone playcount 1) y la
    fila cambia igual (revisión 7-nov PY-02)"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            rows = db.execute("SELECT tmdb_id, progress, playcount FROM movies_watched WHERE progress > 0 "
                              "ORDER BY tmdb_id").fetchall()
        finally:
            db.close()
        return repr(rows)
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def paused_at():
    """{'movies'|'episodes': fecha del último cambio de pausas en Trakt que ha bajado Palantir}"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            return {t: d for t, d in db.execute(
                "SELECT type, date FROM last_activities_trakt WHERE action = 'paused_at'") if t in PAUSE_TABLES}
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("watched.db pausas: %s" % e)
        return None


def load_seen():
    """firmas de watched.db que vio la última sincronización, también de sesiones anteriores: Palantir puede
    traer de Trakt ANTES de nuestra 1.ª consulta (al pedirle las filas caducadas al arrancar) y entonces la foto
    «antes» ya sale nueva y las filas guardadas se quedaban viejas (Carlos, 20-oct: Carrie dejada de seguir en la
    Shield seguía con ▶ en el móvil)"""
    try:
        with open(SEEN_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_seen():
    # atómico: con open('w') el fichero se vaciaba antes de escribir y, si Kodi cortaba el script (al cerrarse, al
    # recargar la skin), quedaba a medias (revisión 29-oct ARR-13/DAT-15)
    from flix_common import atomic_write
    try:
        atomic_write(SEEN_FILE, json.dumps({"file": file_sig(), "shows": shows_sig(), "resume": resume_sig()}))
    except OSError as e:
        log("no guardo %s: %s" % (SEEN_FILE, e))


def drop_palantir_cache(pattern, what):
    """borra de la caché de Palantir (cache.db) las listas cuyo id contiene `pattern`. Sin cache.db no hay nada que
    borrar: sqlite en escritura lo CREARÍA vacío (auditoría 22-oct B-03)"""
    if not os.path.exists(CACHE_DB):
        return
    try:
        db = sqlite3.connect(CACHE_DB, timeout=5)
        try:
            n = db.execute("DELETE FROM simplecache WHERE id LIKE ?", ("%" + pattern + "%",)).rowcount
            db.commit()
        finally:
            db.close()
        log("caché de %s borrada (%d)" % (what, n))
    except Exception as e:  # noqa: BLE001
        log("no borro la caché de %s: %s" % (what, e))


def mark_row(src, rid, sig):
    """pide al Inicio que vuelva a pedir una fila personal a Palantir (TV: Window(home).Property(flix_rl_<src>), que
    mira flix_inicio.tick; táctil: fh_refetch_row con el id de la fila). sig = lo que la fila enseñaría según
    watched.db (shows_sig / resume_sig): si es lo mismo que cuando se marcó la última vez, la fila saldría igual y
    no se marca. Tras un vídeo la marcaban 2-3 fuentes en pocos segundos (Seguir viendo borrada de cache.db,
    follow_check, capítulo visto, p3sync) y el Inicio la pedía otras tantas veces a Palantir, que atiende de una en
    una (kodi.log Shield 5-nov; revisión 7-nov PY-02). Sin sig (watched.db ilegible) se marca siempre. True si marcó"""
    if sig is not None and sig == HOME.getProperty("flix_rlsig_%s" % src):
        return False
    HOME.setProperty("flix_rlsig_%s" % src, sig or "")
    try:
        cur = int(HOME.getProperty("flix_rl_%s" % src) or 0)
    except ValueError:
        cur = 0
    # siempre distinta de la anterior: dos marcas en la misma décima de segundo salían iguales y el Inicio (que
    # compara el valor) no veía la segunda
    HOME.setProperty("flix_rl_%s" % src, str(max(int(time.time() * 10), cur + 1)))
    refetch_touch(rid)
    return True


def refresh_follow():
    drop_palantir_cache("SeriesSeguimiento", "Series en seguimiento")
    return mark_row("p3PathSeriesSeguimiento", "5102", shows_sig())      # fila TV + Inicio táctil


def refresh_resume():
    """«Seguir viendo» también: en una instalación limpia se pidió antes de que Palantir bajara nada de Trakt, y
    Palantir guarda esa lista (vacía) hasta 3 días: sin borrarla, recargar la fila devolvía lo mismo (B-03)"""
    drop_palantir_cache("PeliculasNoFinalizadas", "Seguir viendo")
    return mark_row("p3PathPeliculasNoFinalizadas", "5101", resume_sig())


def refetch_touch(rid):
    """Inicio táctil (flix_home.py): ids de fila a volver a pedir, separados por comas"""
    cur = [x for x in HOME.getProperty("fh_refetch_row").split(",") if x]
    if rid not in cur:
        HOME.setProperty("fh_refetch_row", ",".join(cur + [rid]))


STUCK = 60          # s: Palantir no suele tardar más de 15 en su raíz; más = se está actualizando (o atascado)
WINDOWS = ("progressdialog", "extendedprogressdialog", "okdialog", "yesnodialog", "busydialog", "contextmenu",
           "selectdialog", "notification", "home", "videos", "fullscreenvideo")


def screen_state():
    """qué hay en pantalla (para el registro): ventanas y diálogos activos, propiedades de la skin que tapan avisos"""
    act = [w for w in WINDOWS if xbmc.getCondVisibility("Window.IsActive(%s)" % w)]
    props = [p for p in ("flix_resolving", "flix_searching", "flix_playload", "flix_debrid", "flix_ctx_auto")
             if HOME.getProperty(p)]
    head = xbmc.getInfoLabel("Control.GetLabel(1)") if "progressdialog" in act else ""
    return "ventana %s, activas %s, modal %s, propiedades %s%s" % (
        xbmcgui.getCurrentWindowId(), act or "-", xbmc.getCondVisibility("System.HasActiveModalDialog"),
        props or "-", (", aviso «%s»" % head) if head else "")


def watch_stuck(done, start):
    """si Palantir tarda más de STUCK s en dar su raíz, cada minuto se apunta qué hay en pantalla: el 28-oct (móvil)
    su actualización de contenido se quedó parada 3 min y siguió al descargar la skin, y no se supo qué esperaba"""
    mon, logged = flix_common.quit_monitor(), 0         # se para al cerrarse Kodi (System.OnQuit, APA-03)
    while not done.is_set() and not flix_common.wait_quit(mon, 5):
        waited = time.time() - start
        if waited >= STUCK and waited - logged >= STUCK:
            logged = waited
            log("Palantir sigue sin terminar su raíz tras %d s: %s" % (waited, screen_state()))


def log_path():
    return xbmcvfs.translatePath("special://logpath/kodi.log")


def log_has(text, since=None, path=None):
    """¿hay en el registro de Kodi una línea con `text` (desde la hora `since`, o en toda la sesión)? Solo lee el final
    del fichero; cualquier fallo al leerlo = no se sabe = None"""
    try:
        with open(path or log_path(), "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - LOG_TAIL))
            tail = f.read().decode("utf-8", "replace")
    except OSError:
        return None
    for line in tail.splitlines():
        if text not in line:
            continue
        if since is None:
            return True
        try:
            when = time.mktime(time.strptime(line[:19], "%Y-%m-%d %H:%M:%S"))
        except ValueError:
            continue
        if when >= int(since) - 1:
            return True
    return False


def trakt_failed(since, path=None):
    """¿Palantir ha dejado en el registro «Error al sincronizar vistos» desde `since`? Sin poder leerlo, False"""
    return bool(log_has(TRAKT_ERR, since, path))


def trakt_done(since, path=None):
    """¿Palantir ha terminado su sincronización (vistos y favoritos) desde `since`?"""
    return any(log_has(t, since, path) for t in TRAKT_END)


def trakt_enabled():
    """¿Trakt activado en los ajustes de Palantir? (solo se lee). Sin Palantir o sin poder leerlo, False"""
    try:
        import xbmcaddon
        return xbmcaddon.Addon("plugin.video.palantir3").getSetting("trakt_enabled") == "true"
    except Exception:  # noqa: BLE001
        return False


def trakt_mute(path=None):
    """caso mudo: Trakt activado y Palantir ni ha intentado sincronizar en toda la sesión (el registro es de esta
    sesión). No se afirma si el registro no se pudo leer, si Palantir tenía su cerrojo de actualización o si su marca
    de «ya sincronicé» estaba puesta al pedírselo: con ella Palantir no sincroniza y tampoco escribe nada, y eso no es
    un fallo del vínculo (un aviso en falso manda a la gente a volver a vincular Trakt sin motivo)"""
    if _TRAKT["locked"] or _TRAKT.get("marked") or not trakt_enabled():
        return False
    return log_has(TRAKT_TRY, None, path) is False


def online():
    return bool(xbmc.getCondVisibility("System.InternetState"))


def p3_locked():
    return HOME.getProperty(P3_LOCK) == "true"


def warn_trakt(mute=False):
    """aviso en pantalla: sin él, «Seguir viendo» y lo visto se quedan sin traer de Trakt sin que nadie lo note. Sin
    conexión no se avisa: no es cosa del vínculo (el móvil fuera de casa daría el aviso en falso). Una vez por sesión
    de Kodi: las repeticiones (resync) no insisten"""
    why = "ni lo intenta: sin autorización" if mute else "Error al sincronizar vistos"
    if not online():
        log("Palantir no sincroniza con Trakt (%s), pero no hay conexión: sin aviso" % why)
        return
    if HOME.getProperty(WARNED):
        log("Palantir sigue sin sincronizar con Trakt (%s): ya avisé en esta sesión" % why)
        return
    HOME.setProperty(WARNED, "1")
    log("Palantir no sincroniza con Trakt (%s): aviso para volver a vincularlo" % why)
    try:
        xbmcgui.Dialog().notification("Trakt no sincroniza", "Vuelve a vincular Trakt en los ajustes de Palantir",
                                      xbmcvfs.translatePath("special://skin/resources/icon.png"), 12000)
    except Exception as e:  # noqa: BLE001
        log("aviso de Trakt: %s" % e)


def list_root(mon):
    """lista la raíz de Palantir (lo que le hace bajar de Trakt) y espera a que termine de escribir watched.db;
    True si escribió, False si no, None si Kodi se cierra. Si Palantir deja en el registro que Trakt ha fallado, no se
    espera más (False y _TRAKT["failed"]): las pausas quitadas se devuelven ya, no a los WATCH s (12-nov: la tele se
    apagaba a los 30 s de abrir Kodi y Android lo cerraba con las pausas fuera)"""
    _TRAKT["failed"] = _TRAKT["mute"] = False
    _TRAKT["locked"] = p3_locked()
    _TRAKT["marked"] = bool(HOME.getProperty(P3_MARK))      # Palantir no va a sincronizar: su silencio no dice nada
    start, last = time.time(), file_sig()
    done = threading.Event()
    threading.Thread(target=watch_stuck, args=(done, start), daemon=True).start()
    try:
        # la respuesta no se mira (JSON-RPC común, revisión 29-oct DAT-20)
        flix_common.rpc_send("Files.GetDirectory", {"directory": ROOT, "media": "video"})
    finally:
        done.set()
    _TRAKT["locked"] = _TRAKT["locked"] or p3_locked()
    listed = time.time()
    changed = False
    while time.time() - start < WATCH:
        if not changed and trakt_failed(start):
            _TRAKT["failed"] = True
            return False
        if not changed and time.time() - listed >= MUTE_WAIT and trakt_mute():
            _TRAKT["mute"] = True           # ni lo ha intentado: no va a escribir nada, no se esperan los WATCH s
            return False
        if not changed and trakt_done(start):
            # Palantir ya acabó y Trakt no traía nada nuevo: sin esperar los WATCH s con la marca de ocupado puesta
            # (lo que haya escrito hasta su última línea cuenta)
            return file_sig() != last
        if flix_common.wait_quit(mon, STEP):
            return None
        sig = file_sig()
        if sig != last:                 # sigue escribiendo: esperar a que pare
            last, changed = sig, True
            continue
        if changed:
            break                       # escribió y lleva STEP s quieto
    return changed


def backup_db(src, dst):
    """foto coherente de una base SQLite con su API de copia (coge el bloqueo: nunca medio fichero mientras Palantir
    escribe), escrita aparte y puesta de golpe. Antes shutil.copyfile sobre la base viva (auditoría 22-oct B-04)"""
    tmp = dst + ".tmp"
    src_db = sqlite3.connect("file:%s?mode=ro" % src, uri=True, timeout=10)
    try:
        dst_db = sqlite3.connect(tmp)
        try:
            src_db.backup(dst_db)
        finally:
            dst_db.close()
    finally:
        src_db.close()
    os.replace(tmp, dst)


def prepare_pauses():
    """YA NO SE LLAMA (14-nov: el arranque marca, mark_pauses; ver sync_once). Queda lo que hacía, porque una sesión
    de una versión anterior cortada a mitad deja PENDING escrito así y recover_pending lo tiene que devolver.
    Deja que Palantir rehaga las pelis/capítulos a medias IGUAL que en Trakt. Palantir, al bajar de Trakt, añade y
    actualiza pero NUNCA borra: lo que se quita del progreso en otro aparato se quedaba aquí para siempre (Carlos,
    20-oct: 4 pelis quitadas en la Shield seguían en «Seguir viendo» del móvil). Si se le borran las filas a medias y
    la fecha de pausas, en su 1.ª raíz de la sesión vuelve a bajar la lista ENTERA de Trakt (probado en la Shield
    20-oct: 63/63 pelis, mismos porcentajes). Se conservan las filas posteriores a la última fecha de pausas
    (progreso de este aparato que Palantir aún no haya subido, p. ej. sin conexión); las vistas (playcount > 0) no
    se tocan, ni los capítulos de series ocultas («No seguir esta serie»: al quedarse sin capítulos, un disparador de
    Palantir borra la serie con su marca y volvía a salir en Seguimiento en cada arranque, auditoría 22-oct B-02).
    Antes, foto en BACKUP y flix_p3sync_busy: mientras tanto los demás leen la foto (flix_common.watched_db) y la
    ficha no ofrece «Ver» desde el principio de una peli a medias (B-01). Devuelve los tipos preparados."""
    _SAVED.clear()
    if os.path.isfile(PENDING):
        recover_pending()               # lo de una sesión cortada, antes de quitar nada más
        if os.path.isfile(PENDING):
            log("pausas de la sesión anterior sin devolver: esta vez no las quito")
            return []
    pa = paused_at()
    kinds = [k for k in PAUSE_TABLES if (pa or {}).get(k)]
    if not kinds:
        return []                       # sin fecha de pausas: Palantir ya baja la lista entera
    try:
        backup_db(WATCHED_DB, BACKUP)
        HOME.setProperty("flix_p3sync_busy", str(time.time()))     # con la hora: caduca sola (p3sync_busy)
        db = sqlite3.connect(WATCHED_DB, timeout=10)
        try:
            wheres = {}
            for k in kinds:
                table = PAUSE_TABLES[k]
                where = "playcount = 0 AND progress > 0 AND (lastPlayed IS NULL OR lastPlayed <= ?)"
                if table == "episodes_watched":
                    where += " AND tmdb_id NOT IN (SELECT tmdb_id FROM shows_watched WHERE ocultar)"
                wheres[k] = where
                cur = db.execute("SELECT * FROM %s WHERE %s" % (table, where), (pa[k],))
                _SAVED[table] = ([c[0] for c in cur.description], cur.fetchall())
                _SAVED.setdefault("paused_at", []).append((k, pa[k]))
            save_pending(_SAVED)        # a disco ANTES de borrar: si falla, no se borra nada
            for k in kinds:
                table = PAUSE_TABLES[k]
                n = db.execute("DELETE FROM %s WHERE %s" % (table, wheres[k]), (pa[k],)).rowcount
                db.execute("DELETE FROM last_activities_trakt WHERE type = ? AND action = 'paused_at'", (k,))
                log("pausas %s: %d filas fuera, Palantir las vuelve a bajar de Trakt" % (k, n))
            db.commit()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("no preparo las pausas: %s" % e)
        _SAVED.clear()
        drop_pending()                  # no se borró nada (o se deshizo: sin commit)
        return []
    return kinds


def save_pending(saved):
    """las filas quitadas, en disco (escritas aparte y puestas de golpe)"""
    data = {"tables": {t: {"cols": list(v[0]), "rows": [list(r) for r in v[1]]}
                       for t, v in saved.items() if t in PAUSE_KEYS},
            "paused_at": [list(p) for p in saved.get("paused_at", [])]}
    tmp = PENDING + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, PENDING)


def load_pending():
    """lo guardado por save_pending con la forma de _SAVED; None si no hay o no se lee"""
    try:
        with open(PENDING) as f:
            data = json.load(f)
        saved = {t: (v["cols"], [tuple(r) for r in v["rows"]]) for t, v in data["tables"].items() if t in PAUSE_KEYS}
        saved["paused_at"] = [tuple(p) for p in data["paused_at"]]
        return saved
    except (OSError, ValueError, KeyError, TypeError) as e:
        if not isinstance(e, FileNotFoundError):
            log("pausas guardadas sin leer: %s" % e)
        return None


def drop_pending():
    try:
        os.remove(PENDING)
    except OSError:
        pass


def recover_pending():
    """sesión anterior cortada a mitad (Kodi cerrado, caída): de cada tipo cuya fecha de pausas siga sin estar (Palantir
    no lo rellenó), se devuelven las filas quitadas que falten y la fecha. Si Palantir sí lo rellenó, lo suyo vale
    (lo quitado en otro aparato no vuelve). Con watched.db sin leer, el fichero se queda para la próxima vez"""
    saved = load_pending()
    if saved is None:
        if os.path.isfile(PENDING):
            drop_pending()              # ilegible: no sirve para devolver nada
        return
    try:
        n = unmark()                    # repetición cortada: sus marcas fuera (las filas nunca salieron de la base)
        if n:
            log("sincronización anterior cortada: %d pausas desmarcadas" % n)
    except Exception as e:  # noqa: BLE001
        log("marcas sin quitar: %s" % e)
        return
    after = paused_at()
    if after is None:
        log("watched.db sin leer: las pausas guardadas esperan")
        return
    keep = {}
    for kind, date in saved.get("paused_at", []):
        table = PAUSE_TABLES.get(kind)
        if kind in after or table is None:
            continue
        if table in saved:
            keep[table] = saved[table]
        keep.setdefault("paused_at", []).append((kind, date))
    if keep:
        log("sesión anterior cortada: devuelvo sus pausas (%s)" % ", ".join(k for k, _ in keep["paused_at"]))
        try:
            restore_pauses(keep)
        except Exception as e:  # noqa: BLE001
            log("no devuelvo las pausas guardadas: %s" % e)
            return                      # se reintenta en el próximo arranque
    drop_pending()


def restore_pauses(saved=None):
    """devuelve las filas quitadas que Palantir no haya vuelto a escribir (filas, no el fichero: lo que sí bajó en
    esta sesión se queda) y la fecha de pausas, en una transacción. saved: las de una sesión cortada (recover_pending)"""
    src = _SAVED if saved is None else saved
    db = sqlite3.connect(WATCHED_DB, timeout=10)
    try:
        n = 0
        for table, keys in PAUSE_KEYS.items():
            if table not in src:
                continue
            cols, rows = src[table]
            idx = [cols.index(k) for k in keys]
            for row in rows:
                if db.execute("SELECT 1 FROM %s WHERE %s" % (table, " AND ".join("%s = ?" % k for k in keys)),
                              [row[i] for i in idx]).fetchone():
                    continue
                db.execute("INSERT INTO %s (%s) VALUES (%s)" % (table, ", ".join(cols), ", ".join("?" * len(cols))), row)
                n += 1
        for kind, date in src.get("paused_at", []):
            if not db.execute("SELECT 1 FROM last_activities_trakt WHERE type = ? AND action = 'paused_at'",
                              (kind,)).fetchone():
                db.execute("INSERT INTO last_activities_trakt (type, action, date) VALUES (?, 'paused_at', ?)",
                           (kind, date))
        db.commit()
        log("pausas devueltas: %d filas" % n)
    finally:
        db.close()


def unmark(db=None):
    """quita las marcas que queden (repetición cortada, o Palantir no rebajó las pausas); devuelve cuántas"""
    own = db is None
    db = db or sqlite3.connect(WATCHED_DB, timeout=10)
    try:
        n = 0
        for table in PAUSE_KEYS:
            n += db.execute("UPDATE %s SET lastPlayed = substr(lastPlayed, 1, length(lastPlayed) - 1) || 'Z' WHERE %s"
                            % (table, MARKED)).rowcount
        if own:
            db.commit()
        return n
    finally:
        if own:
            db.close()


def mark_pauses():
    """repetición: marca las pausas que Trakt debería tener (anteriores a su última fecha de pausas; las de este
    aparato aún sin subir y los capítulos de series ocultas, no) y quita esa fecha para que Palantir las rebaje todas.
    Devuelve los tipos preparados; [] si no hay fecha (Palantir ya baja la lista entera) o si algo falla (sin tocar)"""
    _SAVED.clear()
    if os.path.isfile(PENDING):
        recover_pending()
        if os.path.isfile(PENDING):
            log("pausas de una sincronización anterior sin devolver: esta vez no las marco")
            return []
    pa = paused_at()
    kinds = [k for k in PAUSE_TABLES if (pa or {}).get(k)]
    if not kinds:
        return []
    try:
        db = sqlite3.connect(WATCHED_DB, timeout=10)
        try:
            unmark(db)                  # restos de una repetición cortada
            for k in kinds:
                table = PAUSE_TABLES[k]
                where = "playcount = 0 AND progress > 0 AND lastPlayed <= ? AND substr(lastPlayed, -1) = 'Z'"
                if table == "episodes_watched":
                    where += " AND tmdb_id NOT IN (SELECT tmdb_id FROM shows_watched WHERE ocultar)"
                n = db.execute("UPDATE %s SET lastPlayed = substr(lastPlayed, 1, length(lastPlayed) - 1) || 'z' WHERE %s"
                               % (table, where), (pa[k],)).rowcount
                db.execute("DELETE FROM last_activities_trakt WHERE type = ? AND action = 'paused_at'", (k,))
                _SAVED.setdefault("paused_at", []).append((k, pa[k]))
                log("pausas %s: %d marcadas, Palantir las vuelve a bajar de Trakt" % (k, n))
            save_pending(_SAVED)        # la fecha, a disco antes de confirmar: un corte no la pierde
            db.commit()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("no marco las pausas: %s" % e)
        _SAVED.clear()
        drop_pending()
        return []
    return kinds


def settle_marks(kinds, mon=None):
    """tras la raíz: si Palantir rebajó las pausas, las que siguen marcadas ya no están en Trakt y se quitan; si no
    (sin conexión, Trakt caído), se desmarcan y vuelve la fecha. Devuelve cuántas quitó"""
    if mon is not None and not wait_quiet(mon):
        return 0
    after = paused_at()
    if after is None:
        log("watched.db sin leer (¿Palantir escribiendo?): las marcas se quitan en el próximo arranque")
        return 0
    gone = 0
    try:
        db = sqlite3.connect(WATCHED_DB, timeout=10)
        try:
            if all(k in after for k in kinds):
                for k in kinds:
                    gone += db.execute("DELETE FROM %s WHERE playcount = 0 AND progress > 0 AND %s"
                                       % (PAUSE_TABLES[k], MARKED)).rowcount
                unmark(db)              # por si queda alguna marca fuera de esa regla (vista entre medias)
                log("pausas iguales que en Trakt (%s)%s" % (", ".join(kinds), ": %d quitadas en otro aparato" % gone
                                                             if gone else ""))
            else:
                n = unmark(db)
                for kind, date in _SAVED.get("paused_at", []):
                    if kind not in after:
                        db.execute("INSERT INTO last_activities_trakt (type, action, date) VALUES (?, 'paused_at', ?)",
                                   (kind, date))
                log("Palantir no rellenó las pausas (¿sin conexión?): %d desmarcadas, como estaban" % n)
            db.commit()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("no cierro las marcas: %s (se quitan en el próximo arranque)" % e)
        return 0
    drop_pending()
    return gone


def wait_quiet(mon, quiet=4, step=0.5, limit=60):
    """espera a que watched.db lleve quiet comprobaciones seguidas (cada step s: 2 s) sin cambiar: Palantir escribe
    la sincronización de vistos en varias tandas y leerla / escribirla a mitad le daba «Error al sincronizar vistos:
    NoneType… fetchall» (Shield 5-nov; revisión 7-nov PY-04). False si Kodi se cierra. Como mucho limit
    comprobaciones (30 s)"""
    last, same = file_sig(), 0
    for _ in range(limit):
        if same >= quiet:
            return True
        if flix_common.quitting() or mon.waitForAbort(step):
            return False
        sig = file_sig()
        same = same + 1 if sig == last else 0
        last = sig
    log("watched.db sigue cambiando tras %d s: sigo" % (limit * step))
    return True


def check_pauses(kinds, mon=None):
    """YA NO SE LLAMA (14-nov, como prepare_pauses). Tras la raíz: si Palantir no rellenó las pausas (sin conexión, Trakt caído...) se devuelven las quitadas.
    Con mon, antes se espera a que watched.db se quede quieta (wait_quiet)"""
    if mon is not None and not wait_quiet(mon):
        return
    after = paused_at()
    if after is None:
        log("watched.db sin leer (¿Palantir escribiendo?): no toco las pausas")
        return
    if all(k in after for k in kinds):
        log("pausas iguales que en Trakt (%s)" % ", ".join(kinds))
        drop_pending()
        return
    log("Palantir no rellenó las pausas (¿sin conexión?): devuelvo las quitadas")
    try:
        restore_pauses()
    except Exception as e:  # noqa: BLE001
        log("no devuelvo las pausas: %s" % e)
        return                          # PENDING se queda: se devuelven en el próximo arranque (recover_pending)
    drop_pending()


def sync_once(mon, resync=False):
    """resync: repetición con Kodi ya abierto (flix_resync). En los dos casos las pausas se marcan, no salen de la base"""
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.palantir3)"):
        return
    # instalación limpia: watched.db no existe hasta que Palantir baja de Trakt en su 1.ª raíz. Antes aquí se salía y
    # las filas personales del Inicio, pedidas vacías, no se volvían a pedir (Carlos, 22-oct)
    # (0 bytes = lo creó vacío otro script antes que Palantir: también es la 1.ª vez, B-03)
    fresh = not os.path.exists(WATCHED_DB) or os.path.getsize(WATCHED_DB) == 0
    seen = load_seen()                  # sin fichero (1.ª vez): se refresca todo una vez
    log("repito la sincronización de Palantir" if resync else "lanzo la sincronización de Palantir")
    # mientras Palantir rebaja las pausas, watched.db está sin ellas: el Inicio táctil no debe quitar nada de
    # «Seguir viendo» (flix_home.sync_progress)
    try:
        os.remove(BACKUP)               # la foto de otra sesión no vale: hasta que haya una nueva, se lee watched.db
    except OSError:
        pass
    HOME.setProperty("flix_p3sync_busy", str(time.time()))
    _TRAKT["failed"] = _TRAKT["locked"] = _TRAKT["mute"] = _TRAKT["marked"] = False
    try:
        # nada sale de la base, tampoco en el arranque: se marcan (ver P3_MARK). Antes el arranque las BORRABA
        # (prepare_pauses) y, en las series cuya única fila era esa pausa, un disparador de Palantir borraba la serie
        # y la recreaba sin su marca «actualizada»: al acabar después un capítulo, Palantir daba a esas pausas la hora
        # del momento y capítulos dejados meses atrás salían los primeros en «Seguir viendo» (Shield, 13-nov)
        kinds = [] if fresh else mark_pauses()
        start = time.time()
        changed = list_root(mon)
        if changed is None:
            return                      # Kodi se cierra: lo quitado sigue en PENDING y se devuelve al próximo arranque
        if kinds:
            # Trakt falló o Palantir ni lo intentó: no va a escribir más, las pausas vuelven ya
            settle_marks(kinds, None if (_TRAKT["failed"] or _TRAKT["mute"]) else mon)
    finally:
        HOME.clearProperty("flix_p3sync_busy")
    if _TRAKT["failed"]:
        warn_trakt()
    elif _TRAKT["mute"] or trakt_mute():
        if trakt_mute():                # se vuelve a mirar: en un aparato lento Palantir puede haber empezado después
            warn_trakt(mute=True)
        else:
            log("Palantir tardó en empezar a sincronizar con Trakt (más de %d s): sin aviso" % MUTE_WAIT)
    if fresh and not (os.path.exists(WATCHED_DB) and os.path.getsize(WATCHED_DB)):
        log("Palantir sin datos de Trakt todavía")
        return
    if not changed and file_sig() == seen.get("file"):
        log("sin cambios de Trakt en %d s" % (time.time() - start))
        return
    log("watched.db cambió (%s): pongo al día las filas" % ("en %.0f s" % (time.time() - start) if changed
                                                            else "antes de consultar"))
    if fresh or shows_sig() != seen.get("shows"):
        refresh_follow()
    # el Inicio pinta «Seguir viendo» al arrancar con lo guardado y nadie la volvía a pedir: lo pausado en otro aparato
    # no salía hasta parar un vídeo (Fire TV, 2-nov: American Fiction ya en Palantir y no en la fila). Contra lo visto
    # la vez anterior, como las series: Palantir puede haberlo traído antes de nuestra consulta
    if fresh or resume_sig() != seen.get("resume"):
        refresh_resume()
    HOME.setProperty("fh_progress", "1")          # Inicio táctil: repinta ✓ y barras (flix_home.sync_progress)
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")
    save_seen()


P3SYNC_DONE = "flix_p3sync_done"    # = flix_sections.P3SYNC_DONE: la 1.ª raíz ya está listada (o no se pudo)


def running(now=None):
    """¿hay otra sincronización en marcha? La marca lleva la hora: si Kodi cortó el script, caduca sola"""
    try:
        return 0 <= (time.time() if now is None else now) - float(HOME.getProperty(RUNNING) or 0) < WATCH + 180
    except ValueError:
        return False


def main():
    # al cerrarse Kodi se para en menos de 1 s (Kodi no avisa por abortRequested a los RunScript sin addon: System.OnQuit, flix_common.quit_monitor; APA-03)
    mon = flix_common.quit_monitor()
    resync = sys.argv[1:2] == ["resync"]        # repetición con Kodi ya abierto (flix_resync)
    if resync and running():
        log("ya hay una sincronización en marcha: no repito")
        return
    HOME.setProperty(RUNNING, repr(time.time()))
    try:
        if resync:
            # sin su marca, Palantir vuelve a sincronizar al listar su raíz (flix_resync.py)
            HOME.clearProperty(P3_MARK)
            sync_once(mon, resync=True)
            return
        try:
            recover_pending()           # al momento: «Seguir viendo» no espera a los DELAY s
        except Exception as e:  # noqa: BLE001
            log("pausas guardadas: %s" % e)
        if flix_common.wait_quit(mon, DELAY):
            return
        try:
            sync_once(mon)
        finally:
            # aviso a flix_sections follow (secciones «Especial…»), que espera a esto para listar él la raíz (ARR-09)
            HOME.setProperty(P3SYNC_DONE, str(time.time()))
    finally:
        HOME.clearProperty(RUNNING)
        HOME.setProperty(LAST, repr(time.time()))       # flix_resync cuenta desde aquí


if __name__ == "__main__":
    main()
