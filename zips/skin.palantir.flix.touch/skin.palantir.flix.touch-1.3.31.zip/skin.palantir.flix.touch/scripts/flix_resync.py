# -*- coding: utf-8 -*-
"""Cuándo volver a sincronizar con Trakt con Kodi ya abierto (Carlos, 12-nov).

Palantir solo baja de Trakt UNA vez por sesión de Kodi: su Watched.syncToTrakt se apunta la hora en
Window(10000).Property(P3syncToTrakt) y la comprobación «no antes de 5 min» resta al revés, así que ya no repite
(leído en su código y probado en la Shield y el Fire TV de Eren: con Kodi abierto en los dos, lo cambiado en uno no
llegaba al otro; borrando la marca y pidiendo su raíz llegó en 9 s). flix_p3sync.py con el argumento «resync» borra
la marca y repite el ciclo del arranque; aquí solo se decide CUÁNDO, desde las vigilancias que ya existen (Inicio de
la TV y del móvil), sin procesos nuevos:

  - al volver de reproducir algo (es cuando se mira «Seguir viendo»);
  - al volver a usar Kodi tras un rato sin tocarlo (el móvil lo deja vivo en segundo plano durante horas);
  - cada PERIOD s con Kodi a la vista y alguien delante hace poco (dos teles encendidas a la vez).

Nunca durante una reproducción, nunca antes de MIN_GAP s de la anterior, ni con Palantir ocupado o sin conexión.
Cada sincronización son 1-3 s de Palantir por detrás; las filas solo se repintan si algo cambió."""
import time

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
LAST = "flix_p3sync_last"           # hora de la última sincronización (la pone flix_p3sync al acabar cada una)
RUNNING = "flix_p3sync_running"     # flix_p3sync en marcha (arranque o repetición)
MIN_GAP = 300                       # s como mínimo entre dos sincronizaciones
PERIOD = 900                        # s: la periódica
IDLE = 300                          # s sin tocar nada = «un rato sin uso»
IDLE_CAP = 1800                     # s sin tocar nada: ya no hay nadie, la periódica se para (móvil en el bolsillo)
EVERY = 2.0                         # s entre dos comprobaciones (la vigilancia llama cada 0,5 s)
_st = {"checked": 0.0, "played": False, "was_idle": False}


def log(msg):
    xbmc.log("[flix_resync] %s" % msg, xbmc.LOGINFO)


def decide(st, now, playing, idle, last):
    """motivo para sincronizar ahora o None. st: estado entre llamadas; idle: s sin tocar nada; last: hora de la
    última sincronización"""
    if playing:
        st["played"] = True
        return None
    reason = None
    if st["played"]:
        st["played"] = False
        reason = "tras reproducir"
    if idle >= IDLE:
        st["was_idle"] = True
    elif st["was_idle"]:
        st["was_idle"] = False
        reason = reason or "al volver tras un rato sin uso"
    if reason is None and now - last >= PERIOD and idle < IDLE_CAP:
        reason = "periódica"
    if reason and now - last < MIN_GAP:
        return None
    return reason


def blocked():
    """(motivo por el que ahora no se puede, s hasta volver a mirar) o ('', 0). Sin Palantir o sin Trakt activado no
    hay nada que repetir: se vuelve a mirar a la hora; lo pasajero (otra en marcha, sin red), a los 5 min"""
    try:
        going = 0 <= time.time() - float(HOME.getProperty(RUNNING) or 0) < 300     # con hora: caduca si Kodi lo cortó
    except ValueError:
        going = False
    if going or HOME.getProperty("flix_p3sync_busy"):
        return "sincronización en marcha", 300
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.palantir3)"):
        return "sin Palantir", 3600
    try:
        import xbmcaddon
        if xbmcaddon.Addon("plugin.video.palantir3").getSetting("trakt_enabled") != "true":
            return "Trakt no está activado en Palantir", 3600
    except Exception:  # noqa: BLE001
        return "sin Palantir", 3600
    if HOME.getProperty("p3UpdateLock") == "true":
        return "Palantir actualizando su contenido", 300
    if not xbmc.getCondVisibility("System.InternetState"):
        return "sin conexión", 300
    return "", 0


def tick(playing, now=None, st=None):
    """desde la vigilancia del Inicio, cada vuelta. playing: hay un vídeo de verdad (no un tráiler). True si lanzó"""
    st = _st if st is None else st
    now = time.time() if now is None else now
    if now - st["checked"] < EVERY:
        return False
    st["checked"] = now
    try:
        last = float(HOME.getProperty(LAST) or 0)
    except ValueError:
        last = 0.0
    if not last:
        return False                    # la del arranque aún no ha terminado (o Palantir no está): nada que repetir
    reason = decide(st, now, playing, xbmc.getGlobalIdleTime(), last)
    if not reason:
        return False
    why, wait = blocked()
    if why:
        log("tocaba sincronizar (%s) pero no ahora: %s" % (reason, why))
        st["checked"] = now + wait      # sin insistir cada 2 s
        return False
    HOME.setProperty(LAST, repr(now))   # ya apuntada: no se repite mientras el script arranca
    log("sincronizo con Trakt (%s)" % reason)
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_p3sync.py,resync)")
    return True
