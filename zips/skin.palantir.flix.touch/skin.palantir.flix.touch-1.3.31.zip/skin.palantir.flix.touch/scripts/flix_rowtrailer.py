# -*- coding: utf-8 -*-
"""Tráiler automático en las filas del Inicio y de las secciones (TV; Carlos, 11-nov: «si me detengo sobre una carátula
que también lo haga… poder elegir si quiero en ficha, en filas, o en ambas»).

Con Ajustes → «Tráiler automático» encendido y «dónde» en las filas o en ambas (flix_autotrailer.WHERE), al quedarse el
foco quieto QUIET s sobre una carátula se crea el mismo AutoTrailer de las fichas (flix_autotrailer: búsqueda, silencio,
teclas mientras carga, final, limpieza) con la ventana de las filas como dueña: su propiedad tr_on enciende el recuadro
de la cabecera (FlixRowTrailerBox, Includes_Flix.xml). Moverse, pulsar algo, abrir una ficha o un menú lo para.

Nada en el camino del foco: la ventana llama a tick() desde su vigilancia (cada 0,5 s) y a key() desde onAction. Apagado
(de serie) o en modo ligero, tick() solo mira el ajuste. Un intento por título: acabado o cortado su tráiler, no vuelve
a empezar hasta que se pasa por otra carátula (tampoco al volver de su ficha: nunca en bucle).

Lógica pura arriba (tests en tools/tests/test_rowtrailer.py); lo que toca Kodi, abajo."""
import ast
import threading
import time

import xbmc

import flix_autotrailer
import flix_common

QUIET = 1.0             # s con el foco quieto en la carátula antes de buscar su tráiler (pasar de largo no gasta nada)
DELAY = 1.0             # s más, mientras se busca la URL, antes de pedirlo (flix_autotrailer.AutoTrailer)
# la rueda de Kodi al abrir el vídeo (escondida: DialogBusy.xml con flix_tr_loading) es un diálogo modal: con ella la
# ventana dice que tiene algo encima, y el tráiler se paraba nada más arrancar y volvía a pedirse, en bucle (Fire TV
# de Carlos, 11-nov: «no va en filas»)
BUSY = "Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)"
KINDS = {"movies": "movie", "movie": "movie", "tvshows": "tv", "tvshow": "tv", "seasons": "tv", "episodes": "tv"}


def log(msg):
    xbmc.log("[flix_rowtrailer] %s" % msg, xbmc.LOGINFO)


def target(path):
    """(kind, tmdb, tráiler de Palantir) de la ruta de una carátula, para flix_trailer.resolve; None si no es un título"""
    if not path or "palantir3" not in path or "?" not in path:
        return None
    try:
        info = ast.literal_eval(flix_common.decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(info, dict):
        return None
    kind, tmdb = KINDS.get(info.get("content") or ""), str(info.get("tmdb") or "")
    if not kind or not tmdb.isdigit() or tmdb == "0":
        return None
    pal = info.get("trailer")
    return kind, tmdb, pal if isinstance(pal, str) else ""


def due(sig, tried, since, now, has_auto, has_media):
    """¿toca buscar el tráiler de la carátula enfocada? Foco en un título, quieto QUIET s, sin intento ya hecho en esta
    parada, sin otro en marcha y con el reproductor libre"""
    return bool(sig) and sig != tried and not has_auto and not has_media and now - since >= QUIET


# ---------- Kodi ----------
def enabled():
    """encendido, elegido en las filas y no en modo ligero (aparatos lentos: sin vídeo en la cabecera)"""
    return bool(flix_autotrailer.mode()) and flix_autotrailer.allowed("filas", flix_autotrailer.where()) \
        and not xbmc.getCondVisibility("Skin.HasSetting(flix_lite)")


def lookup(kind, tmdb, palantir, box):
    """las URL del tráiler (flix_trailer: TMDB y si no Palantir) a box['urls'], en un hilo"""
    def run():
        try:
            import flix_trailer
            if flix_trailer.available():
                box["urls"] = flix_trailer.resolve(kind, tmdb, palantir)
        except Exception as e:  # noqa: BLE001
            log("tráiler: %s" % type(e).__name__)
    threading.Thread(target=run, daemon=True, name="flix_rowtrailer").start()


class RowTrailer:
    """el tráiler automático de las filas de UNA ventana. win: el Inicio o la sección (propiedad tr_on);
    focused(): (id de la fila, ruta del título enfocado) con la ventana delante y sin nada encima, o None"""

    def __init__(self, win, focused):
        self.win, self.focused = win, focused
        self.sig, self.since, self.tried, self.auto = None, 0.0, None, None
        self.lock = threading.Lock()

    def tick(self, now=None):
        """desde la vigilancia de la ventana. Todo fallo se traga: las filas funcionan igual, sin tráiler"""
        try:
            self._tick(time.time() if now is None else now)
        except Exception as e:  # noqa: BLE001
            log("vigilancia: %s" % type(e).__name__)

    def _tick(self, now):
        if not enabled():
            if self.auto is not None or self.sig is not None:
                self.leave()
            return
        sig = self.focused()
        with self.lock:
            if sig is None and self.auto is not None and getattr(self.auto, "state", "") in ("loading", "playing") \
                    and xbmc.getCondVisibility(BUSY):
                return                          # la rueda de abrir NUESTRO tráiler no es «algo encima» (BUSY)
            if sig != self.sig:                 # otra carátula (o fuera de las filas): el de antes se para
                old, self.auto = self.auto, None
                self.sig, self.since = sig, now
            else:
                old = None
                if not due(sig, self.tried, self.since, now, self.auto is not None,
                           xbmc.getCondVisibility("Player.HasMedia")):
                    return
                self.tried = sig
                t = target(sig[1])
                if t:
                    box = {"urls": ""}
                    lookup(t[0], t[1], t[2], box)
                    self.auto = flix_autotrailer.AutoTrailer(self.win, lambda: box["urls"], delay=DELAY, place="filas")
                    self.auto.start()
        if old is not None:
            old.stop()

    def key(self, aid):
        """una tecla en la ventana (onAction): fuera el tráiler, al instante, y la tecla hace lo suyo; el rato quieto
        vuelve a contar"""
        if aid in flix_autotrailer.NOISE:
            return
        with self.lock:
            old, self.auto = self.auto, None
            self.since = time.time()
        if old is not None:
            old.stop()

    def leave(self):
        """se abre algo (ficha, serie, otra ventana) o la ventana se cierra: se para. El título intentado no se olvida:
        al volver de su ficha no empieza otra vez"""
        with self.lock:
            old, self.auto = self.auto, None
            self.sig = None
        if old is not None:
            old.stop()
