"""Geometría del Inicio táctil, una sola fuente (TCT-15): la usan scripts/flix_home.py (toques, arrastres y
desplazamiento de las filas) y tools/gen_touch_flixhome.py (FlixHome.xml). Sin Kodi: el generador la importa tal cual.
Coordenadas de la skin (alto 1080; ancho 1920…2520 según la pantalla, flix_screen.RES)."""

LEFT = 56              # x del primer póster, del título de cada fila y de la primera tarjeta de arriba
HEADER_H = 140         # cabecera fija (logo, buscar, ajustes): la lista 7000 empieza en y = HEADER_H
STEP = 60              # alto de cada elemento de la lista 7000
ROW_H = 540            # alto de una fila de pósters
PIECES = ROW_H // STEP  # trozos por fila (9): cada uno dibuja la fila entera (ver el generador)
HERO_H = PIECES * STEP  # el hero ocupa los mismos trozos que una fila (flix_home: Strip("hero") con PIECES)
POSTER_W = 286         # ancho de cada hueco de póster
TOP10_W, TOP10_PAD = 400, 124   # Top 10: hueco más ancho, con el número delante del póster
SLOTS_SET = 10         # huecos por juego (A/B) = pósters visibles + 1
OX_STEP = 10           # px por paso de la fracción de póster (arrastre lateral). Cada paso es una animación condicional
                       # en CADA trozo de la fila (9 por fila): 5 → 10 quita la mitad (revisión 7-nov TAC-01a); 10 px son
                       # 1,5 mm en el S24, no se nota
CHIP_W, CHIP_GAP, CHIPS_H = 280, 20, 120    # tarjetas de arriba (2 trozos de STEP)
CHIP_W_NARROW, CHIP_GAP_NARROW = 252, 12    # pantallas de 1920 de ancho: así caben las 7 tarjetas (Carlos, 21-oct)
# Zonas que flix_home.py atiende por la posición del dedo (la lista va en trozos de STEP): 48 dp = 144 como mínimo
# (TCT-01, flix_ui.TOUCH_MIN). Las tarjetas de arriba ocupan 2 trozos (120) y toman además los 24 px de arriba de lo
# que venga debajo; el título de una fila («ver todo») mide TITLE_TAP y toma los últimos TITLE_GAP px de la fila de
# encima, el hueco bajo sus pósters (que acaban en 84 + 396 = 480: 540 - 60); las flechas laterales ‹ › miden SIDE_TAP.
TOUCH_MIN = 144        # = flix_ui.TOUCH_MIN: 48 dp en un móvil de 360 dp (1080 × 48 / 360)
TITLE_TAP, TITLE_GAP = 84, 60
CHIPS_EXTRA = TOUCH_MIN - CHIPS_H
SIDE_TAP = TOUCH_MIN


# «Seguir viendo» en tarjetas apaisadas (Carlos, 12-nov, opción A de la simulación): misma altura de fila (9 trozos),
# tarjeta de 660x371 con la imagen de TMDB que ya trae el título (flix_wide, como la TV) → 3 a la vista y asoma la 4.ª
WIDE_ROW = 5101                     # = flix_home_conf.WIDE_ROW
WIDE_W = 682                        # hueco: 660 de tarjeta + 22 de separación (como los pósters: 264 + 22)
WIDE_CARD_W, WIDE_CARD_H = 660, 371
WIDE_SLOTS = 5                      # huecos por juego: los visibles (3 en 2338, 3 en 2520) + 1 que asoma + 1
WIDE_OX_STEP = 20                   # 34 animaciones por trozo (Top 10: 40, filas: 28); con 10 px serían 68


def item_w(kind):
    """ancho del hueco de la fila: kind = "row" / "top10" / "wide" (True/False = Top 10 o no, como antes)"""
    if kind is True or kind == "top10":
        return TOP10_W
    return WIDE_W if kind == "wide" else POSTER_W


def slots_of(kind):
    """huecos por juego (A/B) de la fila"""
    return WIDE_SLOTS if kind == "wide" else SLOTS_SET


def ox_step(kind):
    """px por paso de la fracción de hueco al arrastrar"""
    return WIDE_OX_STEP if kind == "wide" else OX_STEP
