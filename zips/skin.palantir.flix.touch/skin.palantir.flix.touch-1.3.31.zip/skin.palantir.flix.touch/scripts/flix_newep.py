"""Etiquetas «NUEVO» (capítulo) / «TEMP. 3» (temporada) en las carátulas de «Series en seguimiento» (Carlos, 3-nov).

Se compara el último capítulo emitido (TMDB: last_episode_to_air) con lo último que vio Carlos (watched.db). Solo sale
si se emitió DESPUÉS de la última vez que vio algo de esa serie: quien va atrasado con capítulos viejos no ve nada.
Lo emitido se guarda en addon_data/<skin>/new_episodes.json y se pregunta en un hilo (como mucho uno a la vez), nunca
al pintar la fila: pintar solo lee la caché. Éxito: no se repite hasta pasado un día; fallo de red: se conserva lo
guardado y se reintenta a los 10 min. Todo fallo se traga: sin etiqueta y la fila funciona como siempre. La clave de
TMDB no se escribe jamás en el log."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import threading
import time
import xbmc
import xbmcvfs

import flix_common  # noqa: E402
from flix_intro import FAILED, real_opener  # noqa: E402  (mismo opener(url, timeout): None = 404, FAILED = fallo)

TMDB_TV = "https://api.themoviedb.org/3/tv/%s?api_key=%s"      # lleva la clave: no va al log
TIMEOUT = 4
TTL_OK = 86400                   # una pregunta con éxito vale un día
TTL_FAIL = 600                   # fallo de red: se reintenta pasados 10 min
PAUSE = 0.1
MAX_FAILS = 3                   # fallos seguidos tras los que se deja de preguntar (sin red)
GATE = 600                      # como mucho una comprobación de caducidad cada 10 min con la fila quieta
MAX_CACHE = 300
NEW_EP, NEW_SEASON = "NUEVO", "TEMP. %d"       # caben en la esquina de la carátula
_RUN = threading.Lock()          # un solo refresco a la vez en este proceso
_last_check = None               # última comprobación de caducidad con la fila sin cambios


def log(msg):
    xbmc.log("[flix_newep] %s" % msg, xbmc.LOGINFO)


def cache_file():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/new_episodes.json" % xbmc.getSkinDir())


# --- decisión (puro) ---

def badge_for(last_air, watched, last_seen):
    """last_air {season, episode, date}; watched (temporada, capítulo) último visto; last_seen fecha de lo último visto"""
    try:
        if not last_air or not watched or not last_seen or not last_air.get("date"):
            return ""
        air = (int(last_air["season"]), int(last_air["episode"]))
        seen = (int(watched[0]), int(watched[1]))
        if air <= seen or str(last_air["date"])[:10] <= str(last_seen)[:10]:
            return ""
        return NEW_SEASON % air[0] if air[0] > seen[0] else NEW_EP
    except (TypeError, ValueError, KeyError, AttributeError):
        return ""


# --- caché ---

def _load():
    try:
        with open(cache_file(), encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def cached_air(tmdb):
    a = (_load().get(str(tmdb)) or {}).get("air")
    return a if isinstance(a, dict) else None


def _air(data):
    """last_episode_to_air de la respuesta de TMDB -> {season, episode, date}; None si no hay"""
    try:
        e = data["last_episode_to_air"]
        return {"season": int(e["season_number"]), "episode": int(e["episode_number"]), "date": str(e["air_date"] or "")}
    except (TypeError, KeyError, ValueError):
        return None


def stale(ids, now=time.time):
    """ids que toca preguntar: sin éxito del último día y sin fallo de los últimos 10 min"""
    cache, t = _load(), now()
    out = []
    for i in ids:
        c = cache.get(str(i)) or {}
        if t - c.get("t", -TTL_OK) >= TTL_OK and t - c.get("fail", -TTL_FAIL) >= TTL_FAIL:   # sin dato: toca
            out.append(str(i))
    return out


def refresh(tmdb_ids, opener=None, now=time.time, should_stop=None):
    """pregunta a TMDB por las series caducadas y guarda siempre lo obtenido, aunque pare antes. Para si should_stop()
    o tras 3 fallos seguidos (sin red): las no preguntadas no llevan sello nuevo"""
    opener = opener or real_opener
    try:
        todo = stale(tmdb_ids, now)
        if not todo:
            return
        cache, changed, fails = _load(), False, 0
        try:
            for n, i in enumerate(todo):
                if should_stop and should_stop():
                    break
                if n:
                    time.sleep(PAUSE)
                raw = opener(TMDB_TV % (i, flix_common.TMDB_KEY), TIMEOUT)
                c = dict(cache.get(i) or {})
                if raw is FAILED:
                    c["fail"] = now()
                    fails += 1
                else:
                    c.update(t=now(), air=_air(raw) if raw else None)
                    c.pop("fail", None)
                    fails = 0
                cache[i] = c
                changed = True
                if fails >= MAX_FAILS:
                    break
        finally:
            if changed:
                if len(cache) > MAX_CACHE:
                    keep = sorted(cache, key=lambda k: max(cache[k].get("t", 0), cache[k].get("fail", 0)))[-MAX_CACHE:]
                    cache = {k: cache[k] for k in keep}
                flix_common.atomic_write(cache_file(), json.dumps(cache))
    except Exception as e:  # noqa: BLE001
        log("refresco: %s" % type(e).__name__)


# --- etiquetas ---

def labels_for(ids):
    """{tmdb: etiqueta} de las series con etiqueta; lectura de la caché y de watched.db en lote. {} si algo falla"""
    try:
        ids = {str(i) for i in ids if i}
        cache = _load()
        ids = {i for i in ids if (cache.get(i) or {}).get("air")}
        if not ids:
            return {}
        import flix_progress
        dates = flix_progress.follow_dates()
        rows = flix_common.watched_query(flix_progress.WATCHED_DB, "SELECT tmdb_id, season, episode FROM episodes_watched")
        if not dates or not rows:
            return {}
        last = {}
        for t, s, e in rows:
            t = str(t)
            if t in ids and s is not None and e is not None:
                last[t] = max(last.get(t, (0, 0)), (int(s), int(e)))
        out = {}
        for i in ids:
            b = badge_for(cache[i]["air"], last.get(i), dates.get(i, ""))
            if b:
                out[i] = b
        return out
    except Exception as e:  # noqa: BLE001
        log("etiquetas: %s" % type(e).__name__)
        return {}


def label_for(tmdb):
    return labels_for([tmdb]).get(str(tmdb), "")


# --- en las filas ---

def update(items):
    """pone flix_new en los ListItems de una fila (los que llevan flix_tmdb) si cambió; no hace nada más"""
    try:
        ids = [(li, li.getProperty("flix_tmdb")) for li in items or []]
        ids = [(li, t) for li, t in ids if t]
        if not ids:
            return
        labels = labels_for([t for _, t in ids])
        for li, t in ids:
            if li.getProperty("flix_new") != labels.get(t, ""):
                li.setProperty("flix_new", labels.get(t, ""))
    except Exception as e:  # noqa: BLE001
        log("pintar: %s" % type(e).__name__)


def paint(items, files, live=None):
    """marca los ListItems de la fila con su serie y su etiqueta (solo lectura de caché) y, si algo caducó, pide
    TMDB en un hilo; al acabar repone las etiquetas en live() (los items que siguen en pantalla)"""
    try:
        import flix_rows
        ids = []
        for li, f in zip(items, files):
            t = flix_rows.follow_tmdb(f)
            if t:
                li.setProperty("flix_tmdb", str(t))
                ids.append(str(t))
        if not ids:
            return
        update(items)
        if stale(ids):
            kick(ids, live)
    except Exception as e:  # noqa: BLE001
        log("fila: %s" % type(e).__name__)


def row_labels(ids, done):
    """Inicio del móvil: sus carátulas son propiedades de una tira, no ListItems. {tmdb: etiqueta} de lo guardado y, si
    algo caducó, se pregunta a TMDB en un hilo y se llama a done() al acabar. Todo fallo se traga: sin etiquetas"""
    try:
        ids = [str(i) for i in ids if i]
        if ids and stale(ids):
            kick(ids, None, done)
        return labels_for(ids) if ids else {}
    except Exception as e:  # noqa: BLE001
        log("fila: %s" % type(e).__name__)
        return {}


def kick(ids, live, done=None):
    """lanza el refresco en un hilo si no hay otro; si el hilo no arranca, suelta el cerrojo. done(): al acabar (filas
    sin ListItems propios: Inicio del móvil)"""
    if not _RUN.acquire(blocking=False):
        return
    try:
        threading.Thread(target=_bg, args=(ids, live, done), daemon=True).start()
    except Exception as e:  # noqa: BLE001
        _RUN.release()
        log("hilo: %s" % type(e).__name__)


def due(last, now):
    """¿toca comprobar la caducidad? (puro) Nunca antes, o pasados GATE s; si el reloj fue hacia atrás, también"""
    return last is None or now < last or now - last >= GATE


def recheck(items, live, now=time.time):
    """fila sin cambios: con la puerta de 10 min, mira si algo caducó (días con el Inicio abierto) y refresca"""
    global _last_check
    try:
        t = now()
        if not due(_last_check, t):
            return
        _last_check = t
        ids = [li.getProperty("flix_tmdb") for li in items or []]
        ids = [i for i in ids if i]
        if ids and stale(ids):
            kick(ids, live)
    except Exception as e:  # noqa: BLE001
        log("recheck: %s" % type(e).__name__)


def _stop(mon=None):
    """¿Kodi se está cerrando? System.OnQuit visto por el quit_monitor del script (flix_common.quitting) o, con
    Monitor, abortRequested. Un Monitor por refresco, no uno por serie consultada (revisión 7-nov PY-20)"""
    try:
        return flix_common.quitting(mon)
    except Exception:  # noqa: BLE001
        return False


def _bg(ids, live, done=None):
    try:
        try:
            mon = xbmc.Monitor()
        except Exception:  # noqa: BLE001
            mon = None
        refresh(ids, should_stop=lambda: _stop(mon))
    finally:
        _RUN.release()
    try:
        if live:
            update(live())
        if done:
            done()
    except Exception as e:  # noqa: BLE001
        log("repintar: %s" % type(e).__name__)


# --- capítulos de una temporada según TMDB (ficha de serie: los que Palantir aún no tiene, flix_series.pending_rows) ---
# La base de la API se puede cambiar por entorno SOLO para el banco Xvfb (tools/xvfb/mock/tmdb_server.py): en los
# aparatos no está puesta. Caché aparte de new_episodes.json: tmdb_seasons.json, una entrada por «tmdb/temporada»
TMDB_API = os.environ.get("KER0N3_TMDB_BASE") or "https://api.themoviedb.org/3"
TMDB_SEASON = TMDB_API + "/tv/%s/season/%s?api_key=%s&language=es-ES"   # lleva la clave: no va al log
STILL = "https://image.tmdb.org/t/p/w300%s"
SEASON_TTL = 86400               # una temporada preguntada con éxito vale un día (las fechas no cambian a diario)
SEASON_FIELDS = ("n", "name", "date", "plot", "still")
MAX_SEASON_CACHE = 200
_SEASON_RUN = threading.Lock()   # una temporada a la vez por intérprete


def seasons_file():
    return xbmcvfs.translatePath("special://profile/addon_data/%s/tmdb_seasons.json" % xbmc.getSkinDir())


def _load_seasons():
    try:
        with open(seasons_file(), encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def cached_season(tmdb, season):
    """capítulos de la temporada según TMDB tal como estén APUNTADOS (tengan la edad que tengan: las fechas no
    caducan), sin preguntar a la red; None si no hay nada. Para lo que no puede esperar (el aviso de una serie)"""
    try:
        eps = (_load_seasons().get("%s/%s" % (int(tmdb), int(season))) or {}).get("eps")
        return eps if isinstance(eps, list) else None
    except (ValueError, TypeError, AttributeError):
        return None


def parse_season(data):
    """episodes de /tv/{id}/season/{n} -> [{n, name, date, plot, still}] ordenados por número; [] si no hay"""
    out = []
    try:
        for e in data.get("episodes") or []:
            n = e.get("episode_number")
            if not isinstance(n, int) or n < 1:
                continue
            still = e.get("still_path") or ""
            out.append({"n": n, "name": str(e.get("name") or ""), "date": str(e.get("air_date") or "")[:10],
                        "plot": str(e.get("overview") or ""), "still": STILL % still if still else ""})
    except (AttributeError, TypeError):
        return []
    return sorted(out, key=lambda x: x["n"])


def season_episodes(tmdb, season, opener=None, now=time.time, ttl=SEASON_TTL):
    """capítulos de la temporada según TMDB (parse_season): de la caché si tiene menos de un día; si no, se pregunta
    (y se guarda). Si la red falla se devuelve lo guardado aunque sea viejo (las fechas no caducan: quien pinta
    compara con hoy y con lo que tiene Palantir) o None si no hay nada. Sin 404 ni datos: []. Nunca lanza"""
    key = "%s/%s" % (tmdb, season)
    try:
        if not str(tmdb).isdigit() or not str(season).lstrip("-").isdigit() or int(season) < 0:
            return None
        cache, t = _load_seasons(), now()
        c = cache.get(key) or {}
        if isinstance(c.get("eps"), list) and 0 <= t - float(c.get("t") or 0) < ttl:
            return c["eps"]
        if t - float(c.get("fail") or 0) < TTL_FAIL:          # fallo reciente: sin volver a preguntar
            return c.get("eps") if isinstance(c.get("eps"), list) else None
        raw = (opener or real_opener)(TMDB_SEASON % (tmdb, season, flix_common.TMDB_KEY), TIMEOUT)
        with _SEASON_RUN:
            cache = _load_seasons()                     # otra temporada pudo guardarse mientras tanto
            c = dict(cache.get(key) or {})
            if raw is FAILED:
                c["fail"] = t
            else:
                c = {"t": t, "eps": parse_season(raw) if raw else []}
            cache[key] = c
            if len(cache) > MAX_SEASON_CACHE:
                keep = sorted(cache, key=lambda k: max(float(cache[k].get("t") or 0), float(cache[k].get("fail") or 0)))
                cache = {k: cache[k] for k in keep[-MAX_SEASON_CACHE:]}
            flix_common.atomic_write(seasons_file(), json.dumps(cache))
        return c.get("eps") if isinstance(c.get("eps"), list) else None
    except Exception as e:  # noqa: BLE001
        log("temporada %s: %s" % (key, type(e).__name__))
        return None
