"""Barra de reproducción ARRASTRABLE (OSD táctil).

El slider de Kodi no atiende arrastres táctiles (solo toques); la scrollbar sí (GESTURE_PAN mueve el
tirador bajo el dedo). VideoOSD.xml tiene una scrollbar (8801) ligada a una lista oculta (8800) de
1001 posiciones (0..1000 = por mil de la duración). Este script, mientras el OSD está abierto:
  - si el usuario no toca: coloca la lista en la posición de reproducción (Control.Move)
  - si la posición cambia sin que la haya movido el script = el dedo está arrastrando: publica
    Window(home).Property(ft_scrub_time) con el tiempo de destino
  - cuando deja de moverse QUIET s: salta ahí (Player.seekTime) y vuelve a sincronizar.
Kodi no le dice a este script (sin ventana) cuándo se levanta el dedo: el fin del gesto solo le llega a la ventana
y no hay InfoLabel para eso. Por eso se espera QUIET con el dedo quieto (revisión 29-oct TCT-26: con 0,5 s saltaba
aunque el dedo siguiera sobre la barra).
Vive lo que el vídeo, no lo que el OSD (revisión 7-nov TAC-04): antes cada apertura del OSD (VideoOSD.xml onload)
arrancaba un intérprete que moría al ocultarse y la barra saltaba hasta sincronizar. Con el OSD cerrado duerme
HIDDEN_NAP s por vuelta sin tocar nada; el onload sigue lanzándolo y el nuevo se va si la marca ft_scrub_running
(hora del último latido) es reciente. Sale al parar el vídeo o al cerrarse Kodi (flix_common.quit_monitor).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import time  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

import flix_common  # noqa: E402

HOME = xbmcgui.Window(10000)
STEPS = 1000
QUIET = 0.9         # s sin moverse para dar el arrastre por acabado (antes 0,5: TCT-26)
SEEK_HOLD = 1.5     # s tras el salto sin sincronizar la barra (Player.getTime aún da la hora de antes)
MOVE_HOLD = 0.4     # s tras un Control.Move del script: ese movimiento no es el dedo
HIDDEN_NAP = 0.5    # s por vuelta con el OSD cerrado (TAC-04)
BEAT = 1.0          # s entre latidos de ft_scrub_running
ALIVE = 4.0         # s: una marca más vieja es de un intérprete muerto (Kodi lo cortó) y no bloquea el siguiente


def fmt(sec):
    sec = max(0, int(sec))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def page():
    try:
        return int(xbmc.getInfoLabel("Container(8800).CurrentPage")) - 1
    except ValueError:
        return None


def alive(now):
    """¿hay otro flix_scrub vivo? (latido de hace menos de ALIVE s). El "1" de las versiones anteriores no bloquea"""
    stamp = HOME.getProperty("ft_scrub_running")
    if not stamp:
        return False
    try:
        return 0 <= now - float(stamp) < ALIVE
    except ValueError:
        return False


def main():
    now = time.time()
    if alive(now):
        return
    HOME.setProperty("ft_scrub_running", "%d" % now)
    beat = now
    mon, player = flix_common.quit_monitor(), xbmc.Player()
    # move_hold: no confundir con el dedo un Control.Move nuestro (asíncrono); seek_hold: no sincronizar tras el
    # salto. Antes era una sola espera y, durante 1,5 s después del salto, el dedo que seguía arrastrando no se veía
    last_set, dragging, last_change, move_hold, seek_hold = None, False, 0.0, 0.0, 0.0
    try:
        while not flix_common.quitting(mon) and player.isPlaying():
            now = time.time()
            if now - beat >= BEAT:
                beat = now
                HOME.setProperty("ft_scrub_running", "%d" % now)
            if not xbmc.getCondVisibility("Window.IsVisible(videoosd)"):
                # OSD cerrado: vivo pero quieto. Un arrastre a medias se suelta sin saltar; al reabrirse, la 1.ª vuelta
                # solo coloca la barra (last_set None: la diferencia no se toma por el dedo)
                if dragging:
                    dragging = False
                    HOME.clearProperty("ft_scrubbing")
                    HOME.clearProperty("ft_scrub_time")
                last_set = None
                mon.waitForAbort(HIDDEN_NAP)
                continue
            p = page()
            dur = player.getTotalTime() or 0
            if p is None or dur <= 0:
                mon.waitForAbort(0.1)
                continue
            if not dragging and last_set is not None and abs(p - last_set) > 1 and now > move_hold:
                dragging, last_change = True, now
                HOME.setProperty("ft_scrubbing", "1")
            if dragging:
                if p != last_set:
                    last_set, last_change = p, now
                    HOME.setProperty("ft_scrub_time", fmt(p * dur / STEPS))
                elif now - last_change > QUIET:
                    player.seekTime(p * dur / STEPS)
                    dragging, seek_hold = False, now + SEEK_HOLD
                    HOME.clearProperty("ft_scrubbing")
            elif now > move_hold and now > seek_hold:
                want = int(round(player.getTime() / dur * STEPS))
                if p != want:
                    xbmc.executebuiltin("Control.Move(8800,%d)" % (want - p))
                    move_hold = now + MOVE_HOLD  # el movimiento es asíncrono: no confundirlo con el dedo
                last_set = want
            mon.waitForAbort(0.1)
    finally:
        HOME.clearProperty("ft_scrubbing")
        HOME.clearProperty("ft_scrub_time")
        HOME.clearProperty("ft_scrub_running")


if __name__ == "__main__":
    main()
