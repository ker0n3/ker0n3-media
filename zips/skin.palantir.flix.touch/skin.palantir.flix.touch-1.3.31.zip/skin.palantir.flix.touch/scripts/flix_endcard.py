# -*- coding: utf-8 -*-
"""«Similares» al acabar una película (Carlos, 13-nov: «como YouTube cuando acaba un vídeo: 4 títulos similares a esa
película para pulsar uno y que lleve a su ficha»). Diseño elegido: A, una franja abajo sobre los créditos, en la TV y
en la táctil (FlixEndCard.xml).

Cuándo sale:
  - si se sabe en qué minuto empiezan los créditos (TheIntroDB, la misma fuente del aviso de «Siguiente capítulo»; la
    da para parte de las películas), al llegar a ellos, sin parar la película. Atrás (o la ✕ en la táctil) la quita y
    no vuelve a salir en esa película;
  - si no se sabe, cuando la película TERMINA SOLA: la misma franja, sobre el fondo de la película;
  - si se para a mano antes de los créditos, no sale. Parada con la franja ya a la vista, la franja se queda.

Va en un proceso APARTE del seguimiento de la reproducción (flix_autoplay.follow_playback, que lleva el aviso de
siguiente capítulo y todo lo que pasa al parar): aquel solo lo lanza, una vez, cuando a la película le quedan menos de
flix_autoplay.ENDCARD_LEAD s. Así nada de esto puede estorbar a lo que ya funciona, y un fallo aquí solo deja la
película sin franja.

Sin llamadas a Palantir con la película en marcha: los similares (flix_tmdblists.similar: TMDB filtrado por lo que
tiene Palantir, lo mismo del botón «Similares» de la ficha) se convierten en títulos con el listado directo de la skin
(flix_direct). Si el modo directo no está activo para esta versión de Palantir, se le piden a él solo cuando la
película ya ha terminado. Pulsar un título abre su ficha por el camino de siempre (flix_play.play, ficha).
Skin.HasSetting(flix_endcard_off) o el modo ligero lo apagan.

A DEMANDA (Carlos, 13-nov: «un botón en el reproductor para mostrar las similares por si me apetece, y salir dando
atrás, sin esperar a que acabe la película / serie»): el botón «Similares» del reproductor lanza este script con el
argumento `show`. Si ya hay una instancia siguiendo la película, solo le deja el recado (SHOW) y ella abre la franja;
si no, arranca una que la abre en cuanto tiene los títulos. Vale también para los capítulos (similares de la serie; ahí
no sale sola: al acabar va el aviso de «Siguiente capítulo»)."""
import os
import re
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcvfs  # noqa: E402

import flix_common  # noqa: E402

HOME = xbmcgui.Window(10000)
MOVIE_URL = "https://api.theintrodb.org/v2/media?tmdb_id=%d"
CARDS = 4                   # títulos de la franja
POOL = 12                   # similares que se miran para sacar CARDS con imagen
# créditos de una película: más largos que los de un capítulo (Del revés 2: 10 min y pico). Un «credits» que empieza
# antes del 75 % o a más de 20 min del final es un dato malo: no se usa
CREDITS_FRAC, CREDITS_WINDOW = 0.75, 1200
BACK = 5                    # s por detrás del inicio de los créditos (retroceso): la franja se quita y puede volver
SETTLE, SETTLE_MAX = 1.5, 10.0     # s de calma tras acabar la película antes de sacarla (y tope de espera)
IDLE_MAX = 180              # s con la franja a la vista tras acabar la película sin que nadie la toque
RUNNING = "flix_endcard"    # Window(home): hora de la última vuelta (una sola instancia por película)
SHOW = "flix_endcard_show"  # Window(home): el botón «Similares» del reproductor pide la franja a la instancia en marcha
BUSY = ("Window.IsActive(selectdialog) | Window.IsActive(progressdialog) | Window.IsActive(busydialog) | "
        "Window.IsActive(busydialognocancel)")
A_BACK = flix_common.A_BACK


def log(msg):
    xbmc.log("[flix_endcard] %s" % msg, xbmc.LOGINFO)


def enabled():
    return not xbmc.getCondVisibility("Skin.HasSetting(flix_endcard_off) | Skin.HasSetting(flix_lite)")


# ---------- créditos ----------
def credits_start(segs, total):
    """segundo en que empiezan los créditos de la película (primer tramo «credits») o None. Puro"""
    if not total or total <= 0:
        return None
    for s in segs or []:
        if isinstance(s, dict) and s.get("kind") == "credits":
            start = s.get("start")
            if not isinstance(start, (int, float)) or isinstance(start, bool):
                return None
            if start < CREDITS_FRAC * total or start >= total or total - start > CREDITS_WINDOW:
                return None
            return float(start)
    return None


def movie_segments(tmdb, opener=None):
    """tramos de la película según TheIntroDB ([] sin datos o si falla): una petición por película vista"""
    import flix_intro
    raw = (opener or flix_intro.real_opener)(MOVIE_URL % int(tmdb), flix_intro.TIMEOUT)
    if raw is flix_intro.FAILED or raw is None:
        return []
    return flix_intro.parse_theintrodb(raw)


# ---------- similares ----------
def name_of(f):
    label = flix_common.clean(f.get("title") or f.get("label") or "")
    return re.split(r"\s+\(\d{4}\)|\s+\[", label)[0].strip()


MORE_RE = re.compile(r"(m[aá]s|more|siguiente|next)[\s.…>]*")


def cards_of(files, skip="", kind="movie"):
    """hasta CARDS tarjetas {title, year, img, path} de un listado de Palantir: títulos con imagen, sin el que se está
    viendo ni la tarjeta «más...». kind 'movie': solo películas (las series son carpetas)"""
    out = []
    for f in files or []:
        art = f.get("art") or {}
        img = art.get("fanart") or art.get("landscape") or art.get("poster") or ""
        path = f.get("file") or ""
        folder = f.get("filetype") == "directory"
        if not path or not img or (folder and kind == "movie") or str((f.get("uniqueid") or {}).get("tmdb", "")) == str(skip):
            continue
        if folder and MORE_RE.fullmatch(flix_common.clean(f.get("label") or "").strip().lower()):
            continue
        out.append({"title": name_of(f), "year": str(f.get("year") or ""), "img": img, "path": path})
        if len(out) == CARDS:
            break
    return out


def similar_cards(tmdb, palantir=False, kind="movie"):
    """tarjetas de los similares que tiene Palantir. Con la película en marcha (palantir=False) solo por el listado
    directo de la skin; None si entonces no se puede (se intentará al acabar, ya preguntando a Palantir)"""
    import flix_tmdblists
    ids = flix_tmdblists.similar(kind, tmdb)
    if not ids:
        return []
    path = flix_tmdblists.route(kind, ids[:POOL], "Similares")
    if not path:
        return []
    import flix_direct
    files = flix_direct.list_files(path)
    if files is None:
        if not palantir:
            return None
        import flix_rows
        files = flix_rows.list_files(path, flix_rows.PROPS)
    return cards_of(files, tmdb, kind)


# ---------- la franja ----------
class EndCard(xbmcgui.WindowXMLDialog):
    """FlixEndCard.xml: botones 11-14 (uno por título) y 9 (✕, táctil). Todo por propiedades de la ventana"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.cards, self.title, self.fanart = kwargs.get("cards") or [], kwargs.get("title") or "", kwargs.get("fanart") or ""
        self.credits = bool(kwargs.get("credits"))      # ha salido sola sobre los créditos (no con el botón)
        self.choice, self.dismissed, self.closed = None, False, False

    def onInit(self):
        self.setProperty("ec_title", ("Similares a %s" % self.title) if self.title else "Similares")
        self.setProperty("ec_fanart", self.fanart)
        self.setProperty("ec_credits", "1" if self.credits else "")
        self.setProperty("ec_n", str(len(self.cards)))
        for i, c in enumerate(self.cards, 1):
            self.setProperty("ec%d_title" % i, c["title"])
            self.setProperty("ec%d_year" % i, c["year"])
            self.setProperty("ec%d_img" % i, c["img"])

    def onClick(self, cid):
        if 11 <= cid < 11 + len(self.cards):
            self.choice = cid - 11
            self.shut()
        elif cid == 9:
            self.dismissed = True
            self.shut()

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.dismissed = True
            self.shut()

    def shut(self):
        self.closed = True
        self.close()


def open_card(cards, title, fanart, credits=False):
    d = EndCard("FlixEndCard.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                cards=cards, title=title, fanart=fanart, credits=credits)
    d.show()
    return d


def settled(wait=None, now=time.time):
    """tras acabar la película: sin vídeo ni diálogos de Palantir (su selector reabierto, su progreso) durante SETTLE s.
    False si no se calma en SETTLE_MAX o si arranca otro vídeo"""
    wait = wait or (lambda s: xbmc.sleep(int(s * 1000)))
    start = calm = now()
    while now() - start < SETTLE_MAX:
        if xbmc.getCondVisibility("Player.HasMedia"):
            return False
        if xbmc.getCondVisibility(BUSY):
            calm = now()
        elif now() - calm >= SETTLE:
            return True
        wait(0.25)
    return False


def open_title(card, title_fanart=""):
    """la ficha del título pulsado, por el camino de siempre (como «Títulos de X» del panel ( i ): sin el aviso de
    reanudar, directo a la ficha)"""
    log("abro la ficha de %s" % card["title"])
    HOME.setProperty("flix_title", card["title"])
    HOME.setProperty("flix_fanart", card["img"])
    if card.get("kind") == "tv":
        xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s",ficha)' % card["path"])
        return
    import flix_play
    flix_play.play(card["path"], 0, 0, card["title"], card["img"], ficha=True)


def running(now=time.time):
    try:
        return 0 <= now() - float(HOME.getProperty(RUNNING) or 0) < 5
    except ValueError:
        return False


def notify(text):
    xbmcgui.Dialog().notification("KER0N3 MEDIA", text, xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)


def run(player=None, mon=None, opener=None, now=time.time, show=False):
    """show: lanzado por el botón «Similares» del reproductor (a demanda; también en capítulos)"""
    player, mon = player or xbmc.Player(), mon or flix_common.quit_monitor()
    tmdb = xbmc.getInfoLabel("VideoPlayer.UniqueID(tmdb)")
    kind = "tv" if xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or xbmc.getInfoLabel("VideoPlayer.Season").isdigit() else "movie"
    if not tmdb.isdigit() or (not show and (kind == "tv" or not enabled())):
        if show:
            notify("No hay similares para este vídeo")
        return
    if running(now):
        if show:
            HOME.setProperty(SHOW, str(now()))      # ya hay una instancia con este vídeo: que la abra ella
        return
    HOME.clearProperty(SHOW)
    HOME.setProperty(RUNNING, str(now()))
    playing = xbmc.getInfoLabel("Player.Filenameandpath")
    title = flix_common.clean((xbmc.getInfoLabel("VideoPlayer.TVShowTitle") if kind == "tv" else "")
                              or xbmc.getInfoLabel("VideoPlayer.Title") or xbmc.getInfoLabel("Player.Title"))
    title = re.split(r"\s+\(\d{4}\)|\s+\[", title)[0].strip()
    fanart = xbmc.getInfoLabel("Player.Art(fanart)") or HOME.getProperty("flix_fanart")
    st = {"segs": [], "cards": None, "done": False}

    def prepare():
        try:
            if kind == "movie":
                st["segs"] = movie_segments(tmdb, opener)
        except Exception as e:  # noqa: BLE001
            log("créditos sin mirar: %s" % type(e).__name__)
        try:
            cards = similar_cards(tmdb, kind=kind)
            for c in cards or []:
                c["kind"] = kind
            st["cards"] = cards
        except Exception as e:  # noqa: BLE001
            log("similares sin mirar: %s: %s" % (type(e).__name__, e))
        st["done"] = True
        log("%s: créditos %s, similares %s" % (tmdb, "con dato" if any(s.get("kind") == "credits" for s in st["segs"])
                                                else "sin dato", "pendientes" if st["cards"] is None else len(st["cards"])))
    threading.Thread(target=prepare, daemon=True, name="flix_endcard").start()

    card, dismissed, choice, last_rem = None, False, None, 9999.0
    asked = bool(show)                  # franja pedida con el botón y aún sin abrir (los títulos están llegando)
    auto = enabled()                    # sola (créditos / fin de la película): apagable; con el botón sale siempre
    try:
        while player.isPlayingVideo() and not flix_common.quitting(mon):
            if xbmc.getInfoLabel("Player.Filenameandpath") != playing:
                return                  # ya es otro vídeo
            HOME.setProperty(RUNNING, str(now()))
            try:
                total, cur = player.getTotalTime(), player.getTime()
            except RuntimeError:
                break
            last_rem = total - cur
            start = credits_start(st["segs"], total) if kind == "movie" else None
            if HOME.getProperty(SHOW):              # el botón «Similares», con esta instancia ya en marcha
                HOME.clearProperty(SHOW)
                asked = card is None
            if asked and card is None and st["done"]:
                asked = False
                if st["cards"]:
                    dismissed = True                # abierta a mano: al cerrarla no vuelve a salir sola
                    card = open_card(st["cards"], title, fanart)
                    log("franja a demanda (%s)" % kind)
                else:
                    notify("Palantir no tiene títulos parecidos a %s" % title if st["cards"] == [] else
                           "No se pueden buscar similares ahora")
            elif asked and card is not None:
                asked = False
            if kind == "tv" and card is None and not asked:
                return                              # capítulo: solo a demanda; cerrada la franja, nada más que hacer
            if card is not None and card.closed:
                choice, dismissed = card.choice, dismissed or card.dismissed
                card = None
                if choice is not None:
                    break
            elif card is None and auto and not dismissed and st["cards"] and start is not None and cur >= start:
                card = open_card(st["cards"], title, fanart, credits=True)
                log("franja sobre los créditos (faltan %.0f s)" % last_rem)
            elif card is not None and start is not None and cur < start - BACK:
                card.shut()             # retrocedió a antes de los créditos: se quita y volverá a salir
                card = None
            if mon.waitForAbort(0.5):
                return
        natural = last_rem < 6
        if choice is None and not flix_common.quitting(mon):
            if card is None and kind == "movie" and auto and natural and not dismissed and settled():
                cards = st["cards"]
                if cards is None:       # sin modo directo: ahora sí se le pregunta a Palantir, con la película ya acabada
                    try:
                        cards = similar_cards(tmdb, palantir=True)
                    except Exception as e:  # noqa: BLE001
                        log("similares al acabar: %s: %s" % (type(e).__name__, e))
                if cards and not xbmc.getCondVisibility("Player.HasMedia"):
                    card = open_card(cards, title, fanart)
                    log("franja al acabar la película")
            end = now() + IDLE_MAX
            while card is not None and not card.closed and now() < end and not flix_common.quitting(mon):
                if xbmc.getCondVisibility("Player.HasVideo") and xbmc.getInfoLabel("Player.Filenameandpath") != playing:
                    break               # ha empezado otro vídeo
                if mon.waitForAbort(0.25):
                    break
            if card is not None and card.closed:
                choice = card.choice
        picked = None
        if choice is not None and card is not None:
            picked = card.cards[choice]
        elif choice is not None and st["cards"]:
            picked = st["cards"][choice]
        if card is not None and not card.closed:
            card.shut()
        card = None
        if picked:
            if player.isPlayingVideo():
                player.stop()
                for _ in range(40):
                    if not xbmc.getCondVisibility("Player.HasMedia"):
                        break
                    xbmc.sleep(100)
                settled()
            open_title(picked)
    finally:
        if card is not None and not card.closed:
            try:
                card.shut()
            except RuntimeError:
                pass
        HOME.clearProperty(RUNNING)


if __name__ == "__main__":
    try:
        run(show=sys.argv[1:2] == ["show"])
    except Exception as e:  # noqa: BLE001
        log("sin franja: %s: %s" % (type(e).__name__, e))
