# -*- coding: utf-8 -*-
"""Ficha de serie «adelantada»: temporadas al instante y capítulos a la primera (Carlos, 12-nov: agilidad).

Abrir una serie de varias temporadas eran DOS llamadas a Palantir seguidas: la carpeta de la serie (sus temporadas) y,
solo con ella en la mano, los capítulos de la temporada que toca. Cada llamada cuesta lo mismo haya caché o no
(2,0-2,4 s en la Shield, 7-9 s en un Fire TV: arrancar su intérprete), así que los capítulos llegaban a los ~4,5 s en la
Shield y a los ~15 s en un Fire TV.

La carpeta de la serie no trae nada que no se pueda saber aquí (leído en su código, listado_temporadaS):
  - qué temporadas hay y cuántos capítulos tiene cada una: su base de contenido (enlaces_series), local, 3 ms;
  - cuántos capítulos hay vistos de cada una: watched.db, local;
  - nombre, sinopsis, cartel, fecha y capítulos según TMDB de cada temporada: lo único de red. Se APUNTA la primera
    vez que Palantir da la carpeta (`remember`) y vale para las siguientes;
  - la ruta de cada temporada: la del elemento de la serie con esos campos encima (`season_dict`).

Con eso, la segunda vez que se abre una serie la ficha pinta las temporadas en el acto, pide ya los capítulos de la
que toca (una sola llamada a Palantir hasta verlos) y la carpeta de la serie se le pide DESPUÉS, por detrás: cuando
llega, la ficha se queda con lo que diga Palantir (flix_series_sheet.step_seasons ya comparaba y repintaba en su
sitio). Los capítulos y su reproducción siguen siendo de Palantir tal cual.

NUNCA deja la ficha peor que antes: `predict()` devuelve None (y la ficha hace lo de siempre) si la serie no está
apuntada, si las temporadas de la base ya no son las apuntadas (temporada nueva: la primera vez la da Palantir), con
Palantir actualizando su contenido, sin poder leer lo visto o con Skin.HasSetting(flix_direct_off). Y si Palantir da
otras temporadas que las adelantadas tres veces seguidas (`check`), se apaga solo hasta que cambie la versión de
Palantir."""
import copy
import json
import sqlite3
import time

import xbmc
import xbmcvfs

import flix_common
import flix_direct

INDEX = xbmcvfs.translatePath("special://profile/addon_data/%s/flix_sheet_index.json" % xbmc.getSkinDir())
MAX_SERIES = 60                 # series apuntadas (las últimas abiertas)
DAYS = 60                       # una serie sin abrir en este tiempo se olvida
OFF = "_off"                    # clave del índice: {"v": versión de Palantir, "n": veces seguidas sin coincidir}
OFF_AFTER = 3                   # veces seguidas con otras temporadas que las de Palantir -> no se adelanta más con esa versión
# lo que listado_temporadaS le pone al elemento de la serie para hacer el de una temporada: siempre / solo si TMDB lo
# da (si no, se queda el de la serie) / los contadores de vistos, que se recalculan aquí
ALWAYS = ("label", "action", "page", "content", "p3TotalEpisodes", "season")
OPTIONAL = ("totalSeasons", "plot", "poster", "fecha", "totalEpisodes", "rating")
COUNTERS = ("watchedEpisodes", "unWatchedEpisodes", "playCount")
SEASON_KEYS = frozenset(ALWAYS + OPTIONAL + COUNTERS)
RAW = ("label", "s", "total", "year", "genre", "plot")     # lo que la ficha lee de cada temporada (window_seasons)
SEASONS_SQL = ("SELECT temporada, count(*) FROM (SELECT temporada, episodio FROM enlaces_series WHERE tmdb = ? "
               "GROUP BY temporada, episodio) GROUP BY temporada ORDER BY temporada")
_NONE = object()


def log(msg):
    xbmc.log("[flix_fastsheet] %s" % msg, xbmc.LOGINFO)


# ---------- la ruta de una temporada a partir de la de la serie ----------
def delta(series, season):
    """lo que cambia del elemento de la serie al de una de sus temporadas, para rehacerlo otro día sobre el elemento
    de la serie de ese día (misma serie abierta desde otra fila: su ruta es otra). None si no se sabe rehacer (a la
    temporada le falta algo que la serie lleva)"""
    if any(k not in season for k in series if k not in SEASON_KEYS):
        return None
    own = "totalEpisodes" in season and "unWatchedEpisodes" in season
    try:
        own = own and int(season["unWatchedEpisodes"]) == int(season["totalEpisodes"]) - int(season.get("watchedEpisodes") or 0)
    except (TypeError, ValueError):
        own = False
    d = {k: season[k] for k in ALWAYS if k in season}
    d.update((k, season[k]) for k in OPTIONAL if k in season and (season[k] != series.get(k, _NONE) or
                                                                  (k == "totalEpisodes" and own)))
    return {"set": d, "own": bool(own),
            "extra": {k: v for k, v in season.items() if k not in SEASON_KEYS and series.get(k, _NONE) != v}}


def season_dict(series, st, watched, p3total):
    """el elemento de la temporada como lo haría hoy Palantir: el de la serie + lo apuntado + lo visto y los capítulos
    que tiene AHORA (watchedEpisodes, unWatchedEpisodes, playCount y p3TotalEpisodes, como listado_temporadaS)"""
    d = copy.deepcopy(series)
    d.update(st["extra"])
    d.update(st["set"])
    d["p3TotalEpisodes"] = p3total
    d["watchedEpisodes"] = watched
    if st["own"]:
        d["unWatchedEpisodes"] = int(d["totalEpisodes"]) - int(watched)
    d["playCount"] = 1 if d.get("totalEpisodes") and d["totalEpisodes"] == watched else 0
    return d


def percent(d):
    """Property(WatchedEpisodePercent) que setInfoTag le pone a la temporada: '' sin capítulos según TMDB"""
    total = d.get("totalEpisodes")
    if not total:
        return ""
    return str(int(100 * (d["watchedEpisodes"] / total))) if d.get("watchedEpisodes") else "0"


# ---------- lo apuntado ----------
def load(path=None, now=None):
    try:
        with open(path or INDEX, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    now = time.time() if now is None else now
    return {k: v for k, v in data.items()
            if k == OFF or (isinstance(v, dict) and isinstance(v.get("seasons"), list) and
                            0 <= now - float(v.get("t") or 0) < DAYS * 86400)}


def save(data, path=None):
    keep = sorted((k for k in data if k != OFF), key=lambda k: data[k].get("t", 0))[-MAX_SERIES:]
    out = {k: data[k] for k in keep}
    if OFF in data:
        out[OFF] = data[OFF]
    try:
        flix_common.atomic_write(path or INDEX, json.dumps(out))
    except OSError as e:
        log("no guardo %s: %s" % (path or INDEX, e))


def palantir_version():
    return xbmc.getInfoLabel("System.AddonVersion(plugin.video.palantir3)")


def is_off(data):
    off = data.get(OFF)
    return isinstance(off, dict) and off.get("n", 0) >= OFF_AFTER and off.get("v") == palantir_version()


def entry_of(folder, items):
    """(tmdb, lo que se apunta de la serie) con la carpeta de temporadas que dio Palantir, o None si no vale para
    adelantarla: menos de dos temporadas, algo que no es una temporada («Ver más»), otra serie o sin lo leído"""
    series, _ = flix_direct.decode(folder)
    if not series or not series.get("tmdb") or len(items or []) < 2:
        return None
    seasons = []
    for it in items:
        s, _ = flix_direct.decode(it.get("path"))
        raw = it.get("raw")
        if not s or not raw or s.get("action") != "listado_episodioS" or str(s.get("tmdb")) != str(series["tmdb"]) or \
                not isinstance(s.get("season"), int):
            return None
        st = delta(series, s)
        if st is None:
            return None
        st["raw"] = {k: raw.get(k, "") for k in RAW}
        if st["raw"]["plot"] == s.get("plot"):
            st["raw"]["plot"] = None                        # la de la ruta: sin apuntarla dos veces
        seasons.append(st)
    if len({st["set"]["season"] for st in seasons}) != len(seasons):
        return None
    return str(series["tmdb"]), {"seasons": seasons}


def remember(folder, items, path=None, now=None):
    """apunta las temporadas que acaba de dar Palantir (cada vez que la ficha las lee de su carpeta)"""
    got = entry_of(folder, items)
    if not got:
        return False
    tmdb, entry = got
    now = time.time() if now is None else now
    data = load(path, now)
    old = data.get(tmdb) or {}
    if old.get("seasons") == entry["seasons"] and now - float(old.get("t") or 0) < 86400:
        return False                                        # lo mismo, apuntado hace menos de un día: sin reescribir
    entry["t"] = now
    data[tmdb] = entry
    save(data, path)
    return True


# ---------- adelantar ----------
def local_seasons(tmdb):
    """{temporada: capítulos} que Palantir tiene AHORA de la serie en su base de contenido (las mismas consultas de
    listado_temporadaS y getP3TotalEpisodesInSeasons, por su índice: 3 ms); None si no se puede leer ahora"""
    try:
        if flix_direct.busy():
            return None
        db = sqlite3.connect(flix_direct.uri(flix_direct.content_db()), uri=True, timeout=2)
        try:
            return dict(db.execute(SEASONS_SQL, (int(tmdb),)).fetchall())
        finally:
            db.close()
    except (sqlite3.Error, ValueError, TypeError) as e:
        log("temporadas de la base: %s" % e)
        return None


def build(series, entry, local, seen):
    """las temporadas como las leería la ficha de la carpeta de Palantir (flix_series.window_seasons), o None si lo
    apuntado no es lo que hay hoy en la base"""
    import flix_series
    seasons = entry["seasons"]
    if len(seasons) < 2 or [st["set"]["season"] for st in seasons] != sorted(local):
        return None
    out = []
    for st in seasons:
        n = st["set"]["season"]
        w = seen.get(n, 0)
        d = season_dict(series, st, w, local[n] if n > 0 else None)
        raw = st["raw"]
        plot = raw["plot"] if raw.get("plot") is not None else (d.get("plot") or "")
        it, _ = flix_series.season_item(raw["label"], raw["s"], raw["total"], raw["year"], percent(d),
                                        flix_direct.encode(d), plot, raw["genre"])
        it["seen"] = w
        out.append(it)
    return out


def predict(folder, path=None):
    """temporadas de la serie de esa carpeta (ruta listado_temporadaS) sin preguntar a Palantir, o None: entonces la
    ficha espera a su carpeta como siempre"""
    try:
        if xbmc.getCondVisibility("Skin.HasSetting(flix_direct_off)"):
            return None
        series, extra = flix_direct.decode(folder)
        if not series or extra or series.get("action") != "listado_temporadaS" or not series.get("tmdb") or \
                series.get("page"):
            return None
        data = load(path)
        entry = data.get(str(series["tmdb"]))
        if not entry or is_off(data):
            return None
        import flix_series
        seen = flix_series.seasons_seen(str(series["tmdb"]))
        local = local_seasons(series["tmdb"]) if seen is not None else None
        if not local:
            return None
        return build(series, entry, local, seen)
    except Exception as e:  # noqa: BLE001
        log("no adelanto la ficha: %s: %s" % (type(e).__name__, e))
        return None


def check(pred, items, path=None):
    """con la carpeta de Palantir ya en la mano: '' si las temporadas adelantadas eran las suyas, o en qué no. Si no
    eran las mismas temporadas OFF_AFTER veces seguidas, se deja de adelantar con esta versión de Palantir (algo ha
    cambiado en cómo las da)"""
    import flix_series
    mine, theirs = [flix_series.season_key(x["path"]) for x in pred], [flix_series.season_key(x["path"]) for x in items]
    data = load(path)
    if mine != theirs:
        off = data.get(OFF) if isinstance(data.get(OFF), dict) else {}
        n = off.get("n", 0) + 1 if off.get("v") == palantir_version() else 1
        data[OFF] = {"v": palantir_version(), "n": n}
        save(data, path)
        return "otras temporadas (%d adelantadas, %d de Palantir; van %d de %d seguidas para dejar de adelantar)" % (
            len(mine), len(theirs), n, OFF_AFTER)
    if OFF in data:
        del data[OFF]                                       # coincidió: las de antes fueron un cambio de catálogo a medias
        save(data, path)
    diff = []
    for a, b in zip(pred, items):
        if a["path"] != b["path"]:
            da, db = flix_direct.decode(a["path"])[0] or {}, flix_direct.decode(b["path"])[0] or {}
            diff += ["T%s.%s" % (a.get("season"), k) for k in sorted(set(da) | set(db)) if da.get(k, _NONE) != db.get(k, _NONE)]
        diff += ["T%s:%s" % (a.get("season"), k) for k in ("label", "total", "year", "pct", "plot", "genre", "seen",
                                                          "p3total", "tmdbtotal") if a.get(k) != b.get(k)]
    return ("distinto en " + ", ".join(diff[:12])) if diff else ""
