# -*- coding: utf-8 -*-

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import threading

import xbmc
import xbmcgui
import xbmcvfs

def set_date_format(rpc=None):
    """formato de fecha corta de Kodi = DD/MM/YYYY (locale.shortdateformat; «regional» depende del país)"""
    import json
    rpc = rpc or xbmc.executeJSONRPC
    rpc(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                    "params": {"setting": "locale.shortdateformat", "value": "DD/MM/YYYY"}}))


def es_tactil():
    xbmc.log("[first_run] Ejecutando es_tactil()", level=xbmc.LOGINFO)
    ret = False
    try:
        # Verificar si el sistema operativo es Android
        if xbmc.getCondVisibility('system.platform.android'):
            # aquí y no arriba: solo se usa la 1.ª vez y costaba en cada arranque (revisión 29-oct ARR-07)
            import subprocess
            # Ejecutar el comando getprop para Android
            chars = subprocess.check_output(["getprop", 'ro.build.characteristics'], text=True)
            if "phone" in chars or "tablet" in chars:
                ret = True
            else:
                result = subprocess.check_output(["getprop"], text=True)
                if "set_touch_timer_ms" in result:
                    ret = True
                else:
                    # sin volcar getprop entero (cientos de líneas en kodi.log) (revisión 29-oct ARR-12)
                    xbmc.log("[first_run] No se puede determinar es_touch: ro.build.characteristics=%r, getprop sin "
                             "set_touch_timer_ms (%d líneas)" % (chars.strip(), len(result.splitlines())),
                             level=xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"Error en es_tactil: {e}", level=xbmc.LOGERROR)

    if ret:
        xbmc.executebuiltin("Skin.SetBool(touchmode)")


# ---------- lo que hasta la 1.7.4 lanzaban los otros onload de Startup.xml (revisión 7-nov XML-08) ----------
REPO_DELAY = 45     # s: el repositorio (GitHub) cuando el Inicio y flix_p3sync (20 s) ya han pedido lo suyo
ONCE = "flix_once_%s"


def once(name):
    """una sola vez por sesión de Kodi. first_run encadena repositorio / especial / complementos; la táctil
    (touch/xml/Startup.xml) aún los lanza aparte con su RunScript: el segundo en llegar sale al momento"""
    home = xbmcgui.Window(10000)
    if home.getProperty(ONCE % name):
        return False
    home.setProperty(ONCE % name, "1")
    return True


def home_order_check():
    """reaplica el orden del Inicio si una actualización trajo FlixInicio.xml de serie (flix_home_order check)"""
    try:
        import flix_home_order
        if flix_home_order.check():
            flix_home_order.HOME.setProperty("fi_reload", "1")      # Inicio ya abierto: que se rehaga
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] orden del Inicio: %s" % e, xbmc.LOGWARNING)


def repo_wanted():
    """actualizaciones solas desde GitHub (repository.ker0n3media); fuera en aparatos manuales: Eren (flix_brand=eren)
    o Skin.SetBool(flix_norepo)"""
    return not xbmc.getCondVisibility("Skin.HasSetting(flix_norepo)") and \
        xbmc.getInfoLabel("Skin.String(flix_brand)") != "eren"


def run_repo():
    """el repositorio a los REPO_DELAY s (escalonado: antes caía con la intro); nada si Kodi se cierra mientras"""
    import flix_common
    if flix_common.wait_quit(flix_common.quit_monitor(), REPO_DELAY):
        return
    import flix_repo
    flix_repo.main()


def run_follow():
    import flix_sections
    flix_sections.follow()


def run_deps():
    import flix_deps
    flix_deps.main()


def run_ping():
    import flix_ping
    flix_ping.main()


def _bg(name, fn):
    """hilo daemon de este intérprete (Kodi lo espera antes de cerrarlo); un fallo se apunta y no toca a los demás"""
    def run():
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            xbmc.log("[first_run] %s: %s" % (name, e), xbmc.LOGWARNING)
    t = threading.Thread(target=run, name="first_run-" + name, daemon=True)
    t.start()
    return t


def run_boot_guard():
    """red de seguridad de la intro (Custom_1113_FlixIntro.xml): si el timer que quita flix_boot no llegara a saltar,
    la capa negra se quedaría puesta y el Inicio esperando: a los INTRO_MAX s se quita"""
    import flix_common
    if flix_common.wait_quit(flix_common.quit_monitor(), flix_common.INTRO_MAX):
        return
    home = xbmcgui.Window(10000)
    if home.getProperty(flix_common.BOOT):
        xbmc.log("[first_run] la intro no se cerró sola: la quito", xbmc.LOGWARNING)
        home.clearProperty(flix_common.BOOT)


def chain():
    """repositorio (si procede), secciones «Especial…» al día, complementos de los tráileres y aviso de uso, cada uno
    en su hilo: eran cuatro intérpretes más en los 4 s de la intro (XML-08) y el aviso de uso era un HTTP síncrono al
    final de first_run (PY-25). Cada uno sigue saliendo al momento si no tiene nada que hacer"""
    started = [_bg("intro", run_boot_guard)]
    if repo_wanted():
        started.append(_bg("repositorio", run_repo))
    started.append(_bg("especial", run_follow))
    started.append(_bg("complementos", run_deps))
    started.append(_bg("aviso de uso", run_ping))
    return started


def main():
    # (la propiedad video_exists de Estuary Palantir no la lee ninguna ventana: fuera, revisión 29-oct ARR-15)
    # caché de filas de antes de la 1.4.52 / 1.0.71 (rows_cache.json, rutas con progreso a None): se borra una vez por
    # arranque. Antes lo intentaba cada intérprete que importaba flix_rows (revisión 29-oct ARR-15)
    try:
        os.remove(xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache.json" % xbmc.getSkinDir()))
    except OSError:
        pass

    if not xbmc.getCondVisibility("Skin.HasSetting(noPrimeraVez)"):
        es_tactil()
        xbmc.executebuiltin("Skin.SetBool(noPrimeraVez)")
    # vista previa del menú lateral encendida de serie (Carlos, 8-nov): una sola vez por aparato; si alguien la apaga
    # después en Ajustes, se queda apagada (la marca flix_pv_defecto ya está puesta)
    if not xbmc.getCondVisibility("Skin.HasSetting(flix_pv_defecto)"):
        xbmc.executebuiltin("Skin.SetBool(flix_menu_preview)")
        xbmc.executebuiltin("Skin.SetBool(flix_pv_defecto)")






    # menú (barra lateral TV / tarjetas táctiles) desde sections.json: lo primero, antes de que salga el Inicio
    try:
        import flix_sections
        flix_sections.apply()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] secciones del menú: %s" % e, xbmc.LOGWARNING)
    # orden de las filas del Inicio: si la actualización trajo FlixInicio.xml de serie, se reescribe (antes, otro
    # RunScript del Startup.xml; flix_inicio lo vuelve a mirar al abrirse)
    home_order_check()
    # ajustes de Palantir que la skin necesita (sin colores en los textos): en cada arranque
    try:
        import flix_palantir_prefs
        flix_palantir_prefs.main()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] ajustes de Palantir: %s" % e, xbmc.LOGWARNING)
    # prioridad de reproducción: el modo viejo (4k / 1080) pasa al orden de calidades nuevo; resumen de Ajustes
    try:
        import flix_quality
        flix_quality.migrate()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] prioridad de reproducción: %s" % e, xbmc.LOGWARNING)
    # Palantir baja de Trakt lo marcado en otros aparatos al listar su raíz (20 s después, aparte: no frena el Inicio)
    if not xbmcgui.Window(10000).getProperty("flix_p3sync"):
        xbmcgui.Window(10000).setProperty("flix_p3sync", "1")
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_p3sync.py)")
    # fechas (estreno de capítulos…) en dd/mm/aaaa: Kodi usa la de su región y con la de EE. UU. salía mm/dd/aaaa
    # (Carlos, 24-oct). Una vez por aparato: si luego se cambia a mano en Ajustes de Kodi, se respeta
    if not xbmc.getInfoLabel("Skin.String(flix_datefmt)"):
        set_date_format()
        xbmc.executebuiltin("Skin.SetString(flix_datefmt,DD/MM/YYYY)")
    # nota de los títulos (Ajustes → Nota de los títulos, clave de MDBList). Los ajustes se crean con su valor
    # neutro (clave «-» = sin clave; orden del ajuste viejo flix_rating_src o el de serie) para que existan y se puedan
    # poner a distancia (Settings.SetSkinSettingValue solo cambia ajustes que ya existen). Sin clave el bucle solo
    # mira los ajustes cada 3 s.
    if not xbmc.getInfoLabel("Skin.String(flix_mdblist_key)"):
        xbmc.executebuiltin("Skin.SetString(flix_mdblist_key,-)")
    try:
        import flix_ratings
        flix_ratings.migrate()
        # el bucle de notas solo con clave: sin ella vivía toda la sesión mirando los ajustes (revisión 7-nov PY-09).
        # El editor lo lanza al poner la clave (save_settings); puesta a distancia, arranca en el siguiente Kodi
        flix_ratings.ensure_running()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] nota de los títulos: %s" % e, xbmc.LOGWARNING)
    # aviso semanal del grupo de Telegram para avisar de fallos (Carlos, 28-oct): espera solo a que el Inicio esté libre
    if not xbmcgui.Window(10000).getProperty("flix_telegram"):
        xbmcgui.Window(10000).setProperty("flix_telegram", "1")
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_telegram.py)")
    # buscador: si Palantir cambió su catálogo, su lista de títulos se prepara por detrás (no en la primera búsqueda)
    if not xbmcgui.Window(10000).getProperty("flix_titles_prewarm"):
        xbmcgui.Window(10000).setProperty("flix_titles_prewarm", "1")
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_titles_prewarm.py)")
    # tráiler automático: si Kodi se cerró con su silencio puesto, se quita (flix_autotrailer)
    try:
        import flix_autotrailer
        flix_autotrailer.recover()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] silencio del tráiler: %s" % e, xbmc.LOGWARNING)
    # Android: caché de Kodi (apk/) como grupo, para que Android la borre entera y no a medias (pantalla negra hasta
    # «Borrar caché»: móvil de Carlos y otros usuarios, 6-nov)
    try:
        import flix_cacheguard
        flix_cacheguard.main()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] caché de Kodi: %s" % e, xbmc.LOGWARNING)
    # TV: ↑ / ↓ con el vídeo abren los controles en vez de saltar por capítulos internos (flix_tv_keys; solo si falta)
    try:
        import flix_tv_keys
        flix_tv_keys.install()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] teclas del reproductor: %s" % e, xbmc.LOGWARNING)
    # repositorio, especial de Palantir, complementos de los tráileres y aviso de uso: en hilos de este intérprete
    chain()


if __name__ == "__main__":
    main()
