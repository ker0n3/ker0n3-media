# -*- coding: utf-8 -*-
"""Mejor audio disponible de cada título, para la cabecera del Inicio y la ficha (Carlos, 12-nov: «¿podríamos usar los
códecs como esto?», con una foto de la cabecera con «DTS»).

Palantir no da el audio en sus listados, pero en su base de contenido cada enlace lleva en `info` los códecs de su
pista de audio (AC3, EAC3, DTSHD-MA, TrueHD, Atmos…): flix_direct los resume por título al hacer su índice (columna
`sonido`) y aquí se lee de una vez. Solo el códec: los canales (5.1, 7.1) no están en la base y no se inventan (sí se
enseñan al reproducir, que es cuando Kodi los sabe).

Sin índice, o con el de antes de este cambio, no sale nada: la insignia es un extra."""
import re

RANK = ("atmos", "dtsx", "truehd", "dtshd", "dts", "ddplus", "dd", "aac")     # de mejor a peor; = flix/badges/…
TOKENS = {"ATMOS": "atmos", "DTS-X": "dtsx", "DTSX": "dtsx", "DTS:X": "dtsx", "TRUEHD": "truehd",
          "DTSHD-MA": "dtshd", "DTSHD-HRA": "dtshd", "DTS-HD": "dtshd", "DTSHD": "dtshd", "DTS": "dts", "DTS-ES": "dts",
          "EAC3": "ddplus", "DD+": "ddplus", "DDP": "ddplus", "AC3": "dd", "DD": "dd", "AAC": "aac", "ACC": "aac"}
TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')
SHOW_RE = re.compile(r'"content": \'(?:tvshows|seasons|episodes)\'|\'listado_temporadaS\'|\'play_mis_serieS\'')
_mem = {"sig": None, "map": None}


def best(infos):
    """el mejor códec de los `info` de los enlaces de un título (textos «AC3,DTS»); '' si no hay ninguno conocido"""
    found = set()
    for info in infos:
        for tok in re.split(r"[,\s/]+", (info or "").upper().strip("[] ")):
            key = TOKENS.get(tok)
            if key:
                found.add(key)
    return next((k for k in RANK if k in found), "")


def table():
    """{'movie': {tmdb: códec}, 'tv': {…}} del índice de flix_direct; se relee solo si el índice cambia. {} sin él"""
    import flix_direct
    try:
        sig = flix_direct.index_sig()
        if sig is None:
            return {}
        if _mem["sig"] != sig:
            _mem["map"], _mem["sig"] = flix_direct.audio_map(), sig
        return _mem["map"] or {}
    except Exception:  # noqa: BLE001
        return {}


def for_path(path):
    """códec del título de esa ruta de Palantir ('' si no se sabe)"""
    try:
        import flix_common
        j = flix_common.decode_route(path)
        m = TMDB_RE.search(j)
        if not m:
            return ""
        kind = "tv" if SHOW_RE.search(j) else "movie"
        return (table().get(kind) or {}).get(int(m.group(1)), "")
    except Exception:  # noqa: BLE001
        return ""
