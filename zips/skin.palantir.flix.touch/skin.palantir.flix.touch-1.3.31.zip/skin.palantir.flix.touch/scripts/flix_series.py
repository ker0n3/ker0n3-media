# -*- coding: utf-8 -*-
"""Abrir una serie de Palantir en su pantalla de temporadas (en vez de "reproducir siguiente capítulo").

RunScript(special://skin/scripts/flix_series.py, <ruta plugin:// del item>)
RunScript(special://skin/scripts/flix_series.py, ver)    -> botón «Ver / Continuar» de la pantalla de temporadas

La ruta de un item de serie lleva action 'play_mis_serieS' (Palantir: reproduce el siguiente capítulo).
Con action 'listado_temporadaS' y el mismo JSON, Palantir devuelve las temporadas en ~2 s.
Se guarda la ruta original en Window(home).Property(flix_series_play) para el botón "Continuar".
Serie a medias (▶): pop-up «Seguir viendo · TxEy / Desde el principio / Ver temporadas» en vez de las temporadas.
«Desde el principio»: el capítulo del aviso (a medias o el siguiente) desde el minuto 0; T1 E1 si no hay siguiente.
Serie sin empezar: «Ver» = T1 E1 (play_mis_serieS no sabe qué poner y no hacía nada; se salta los especiales).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_syspath  # noqa: E402,F401  (la stdlib y scripts/ delante de las carpetas de addons: ARR-02)

import json
import re
import time
import xbmc
import xbmcgui
import xbmcvfs

from flix_common import NO_ANSWER_RETRY, PLUGIN_ROOT, WATCHED_DB_REL, atomic_write, decode_route, encode_route  # noqa: E402,F401
from flix_common import list_dir as flix_common_list_dir  # noqa: E402

HOME = xbmcgui.Window(10000)
# capítulos que Palantir tiene de cada temporada ya vista («tmdb/temporada» -> números): «Seguir viendo» no pregunta
EPS_INDEX = xbmcvfs.translatePath("special://profile/addon_data/%s/flix_eps_index.json" % xbmc.getSkinDir())
EPS_INDEX_DAYS = 60
WATCHED = WATCHED_DB_REL      # de Palantir (solo lectura)



def watched_rows(sql, args):
    """filas de watched.db de Palantir (solo lectura, con la foto .flixbak mientras p3sync rehace las pausas: el
    acceso común de flix_common, con el timeout de 3 s de aquí); None si no existe o no se puede leer"""
    from flix_common import watched_query
    try:
        return watched_query(xbmcvfs.translatePath(WATCHED), sql, args, timeout=3)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] watched.db: %s" % e, xbmc.LOGINFO)
        return None


def next_episode(tmdb_id):
    """('T1 E41', pct) según watched.db de Palantir: episodio a medias (progress>0) o último visto + 1. None si no empezada."""
    if not tmdb_id:
        return None
    # empate en lastPlayed (temporada marcada vista de golpe en Trakt: todos con la misma hora) -> el capítulo más alto
    # (antes salía el primero, «Seguir T1 E2» con la T1 vista entera; Carlos, 28-oct)
    got = next_episode_info(tmdb_id)
    return got[:2] if got else None


def next_episode_info(tmdb_id):
    """como next_episode, con un tercer dato: los segundos en que hay que poner el capítulo a medias cuando Palantir no
    sabe que lo está (flix_common.current_episode: el visto anterior le llegó por Trakt con fecha posterior) y lo
    empezaría de cero; 0 en el caso normal (lo reanuda él)"""
    if not tmdb_id:
        return None
    rows = watched_rows("SELECT season, episode, progress, lastPlayed, runtime FROM episodes_watched WHERE tmdb_id=? "
                        "ORDER BY lastPlayed DESC, season DESC, episode DESC", (tmdb_id,))
    if not rows:
        return None
    from flix_common import current_episode
    row, late = current_episode(rows)
    s, e, progress = row[0], row[1], row[2]
    if progress and progress > 0:       # empezado aunque ya contara como visto (volver a verlo): ese es el a medias
        at = int(float(row[4] or 0) * float(progress) / 100) if late else 0
        return ("T%d E%d" % (s, e), int(progress), at)
    return ("T%d E%d" % (s, e + 1), 0, 0)


def roll_next(nxt, pct, items):
    """(siguiente, terminada). «T1 E7» cuando la temporada 1 tiene 6 -> «T2 E1» (next_episode solo suma 1: no sabe
    cuántos tiene cada temporada; la ventana sí: TotalEpisodes). Si era el último de la última temporada: ('', True)
    = serie vista entera, botón «Ver de nuevo» (T1 E1). Igual si no se sabe o está a medias"""
    m = re.match(r"T(\d+) E(\d+)$", nxt or "")
    if not m or pct:
        return nxt, False
    s, e = int(m.group(1)), int(m.group(2))
    by = {f.get("season"): f for f in items}
    if (by.get(s) or {}).get("p3"):
        return nxt, False               # temporadas propias de Palantir (Bleach): números sueltos, lo mira fix_next
    # los capítulos que tiene Palantir si son más que los de TMDB: Black Clover T2 tiene 61 en Palantir y 26 en TMDB
    # (tras el 2x26 saltaba al 3x01; Carlos, 25-oct). Si Palantir tiene menos (aún no los ha subido), los de TMDB
    total = max(num((by.get(s) or {}).get("total")), num((by.get(s) or {}).get("p3total")))
    if not e > total > 0:
        return nxt, False
    later = sorted(n for n in by if isinstance(n, int) and n > s)
    return ("T%d E1" % later[0], False) if later else ("", True)


GENERIC_EP = re.compile(r"^\s*(\d+x\d+\s+)?(Episodio|Episode|Capítulo)\s+\d+\s*$", re.I)


def fix_next(nxt, pct, eps):
    """el siguiente capítulo según lo que TIENE Palantir en esa temporada. eps = [(número, ruta)] de su lista.
    next_episode solo suma 1 al último visto: Bleach «Continuar · T2 E49» con la T2 de Palantir 1-43 y 65 -> Palantir
    «El episodio 2x49 no está disponible» (Carlos, 24-oct). None = vale como está; (etiqueta, ruta, '') = el
    siguiente que sí tiene; ('', '', 'TxEy') = al día (visto hasta TxEy, no tiene más)"""
    m = re.match(r"T(\d+) E(\d+)$", nxt or "")
    if not m or pct or not eps:
        return None
    s, e = int(m.group(1)), int(m.group(2))
    nums = {x[0]: x[1] for x in eps if isinstance(x[0], int) and x[0] > 0}
    if not nums or e in nums:
        return None
    # de relleno no: Palantir pone a veces un «2x65 Episodio 65» con la sinopsis de la serie (Bleach) que no es nada
    real = {x[0] for x in eps if isinstance(x[0], int) and not GENERIC_EP.match(x[2] if len(x) > 2 else "")}
    later = sorted(n for n in nums if n > e and n in real)
    if later:
        return "T%d E%d" % (s, later[0]), nums[later[0]], ""
    return "", "", "T%d E%d" % (s, e - 1)


def route_meta(path):
    """de la ruta de una temporada de Palantir: temporadas y capítulos según Palantir (p3) y según TMDB"""
    try:
        j = decode_route(path)
    except Exception:  # noqa: BLE001
        return {}
    out = {}
    for k in ("season", "totalEpisodes", "p3TotalEpisodes", "p3TotalSeasons", "totalSeasons"):
        m = re.search(r'"%s": (\d+)' % k, j)
        if m:
            out[k] = int(m.group(1))
    m = re.search(r'"tmdb": \'?(\d+)', j)
    if m:
        out["tmdb"] = m.group(1)
    return out


def total_seasons(j):
    """temporadas de la serie según su ruta (la mayor entre Palantir y TMDB); 0 si no constan"""
    vals = [int(m.group(1)) for k in ("totalSeasons", "p3TotalSeasons")
            for m in [re.search(r'"%s": (\d+)' % k, j)] if m]
    return max(vals, default=0)


def shown_next(nxt, tmdb, total):
    """texto de «Siguiente: …» del aviso. Slow Horses (26-oct): T1 vista entera y el aviso decía «T1 E7» aunque al
    elegir ya se ponía el T2 E1. Si el índice (EPS_INDEX) sabe que la temporada acaba antes y hay otra después, dice
    la de la siguiente; sin índice o a medias, tal cual (sin preguntar a Palantir antes del aviso)"""
    label, pct = nxt[0], nxt[1]
    m = re.match(r"T(\d+) E(\d+)$", label or "")
    if not m or pct or not tmdb:
        return label
    s, e = int(m.group(1)), int(m.group(2))
    known = known_eps("%s/%s" % (tmdb, s))
    if not known or e <= max(known) or s >= total:
        return label
    nxt_eps = known_eps("%s/%d" % (tmdb, s + 1))
    return "T%d E%d" % (s + 1, min(nxt_eps) if nxt_eps else 1)


def own_numbering(meta):
    """Palantir reparte la serie en MÁS temporadas que TMDB (Bleach: 16 frente a 2): sus datos de TMDB (capítulos,
    año, carátula) son de OTRA temporada o no hay. Con menos (aún no tiene la última) la numeración es la misma"""
    p3, tm = meta.get("p3TotalSeasons"), meta.get("totalSeasons")
    return bool(p3 and tm and p3 > tm)


def route_field(j, name):
    m = re.search(r'"%s": \'([^\']*)\'' % name, j)
    return m.group(1) if m else ""


def art_url(v, size):
    """'/abc.jpg' (ruta de TMDB que guarda Palantir) -> URL completa; URL completa o vacío -> tal cual"""
    return "https://image.tmdb.org/t/p/%s%s" % (size, v) if v.startswith("/") else v


def use_sheet():
    """ficha en ventana propia (flix_series_sheet, FlixSeries.xml): las dos skins (táctil fase 1, TV fase 2: 26-oct).
    Skin.SetBool(flix_series_vieja) vuelve a la de la ventana Vídeos (respaldo, sin opción en Ajustes)"""
    return not xbmc.getCondVisibility("Skin.HasSetting(flix_series_vieja)")


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    import flix_play
    if flix_play.opening_other():
        # 2.º OK antes de que salga el aviso del 1.º: dos «Seguir viendo» a la vez cerraban Kodi (test_doble_apertura)
        xbmc.log("[flix_series] ya se abre otro título: ignoro el clic (%s)" % path[:60], xbmc.LOGINFO)
        return
    mark = flix_play.launch_begin()
    try:
        # «ficha»: vuelta desde «Títulos de X» del panel ( i ) (flix_info.back_to): a las temporadas, sin preguntar
        # «seguir»: tarjeta del capítulo a medias de «Seguir viendo» del Inicio: lo reanuda sin el aviso
        open_series(path, lambda: flix_play.launch_end(mark), ficha=sys.argv[2:3] == ["ficha"],
                    direct=sys.argv[2:3] == ["seguir"])
    finally:
        flix_play.launch_end(mark)


def open_series(path, release, ficha=False, direct=False):
    """release(): suelta la marca de «abriendo» antes de la ficha (dura lo que quiera el usuario). ficha: sin el aviso
    «Seguir viendo», directo a las temporadas"""
    if not path.startswith(PLUGIN_ROOT):
        xbmc.log("[flix_series] ruta inválida: %r" % path, xbmc.LOGINFO)
        return
    try:
        j = decode_route(path)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] no decodifico: %s" % e, xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    m = re.search(r'"tvshowtitle": \'([^\']*)\'', j)
    # inicio de C2 sin depuración (revisión 29-oct DAT-22): hasta aquí solo se veía el aviso o «abro temporadas»
    xbmc.log("[flix_series] pulsada %s" % (m.group(1) if m else "?"), xbmc.LOGINFO)
    if "'play_mis_serieS'" in j:
        play, seasons = path, encode_route(j.replace("'play_mis_serieS'", "'listado_temporadaS'"))
    elif "'listado_temporadaS'" in j:
        play, seasons = encode_route(j.replace("'listado_temporadaS'", "'play_mis_serieS'")), path
    else:
        xbmc.log("[flix_series] ruta sin acción de serie conocida; abro tal cual", xbmc.LOGINFO)
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        return
    # fondo y logo para la pantalla de carga (MyVideoNav: flix_opening) desde la propia ruta: vale para todos los
    # caminos (Inicio TV/táctil, secciones, buscador). Rutas relativas de TMDB -> mismo tamaño que pide Palantir (w1280)
    HOME.setProperty("flix_open_fanart", art_url(route_field(j, "fanart"), "w1280"))
    HOME.setProperty("flix_open_logo", art_url(route_field(j, "clearlogo"), "w500"))
    tm = re.search(r'"tmdb": \'?(\d+)', j)
    nxt = next_episode(int(tm.group(1)) if tm else None)
    # capítulo a medias que Palantir empezaría de cero (ver next_episode_info): «TxEy|segundos» para reanudarlo aquí
    info = next_episode_info(int(tm.group(1))) if tm and nxt and nxt[1] else None
    late_at = info[2] if info and tuple(info[:2]) == tuple(nxt) else 0
    if late_at > 0:
        HOME.setProperty("flix_series_resume_at", "%s|%d" % (nxt[0], late_at))
    else:
        HOME.clearProperty("flix_series_resume_at")
    clear_eps()                               # sin capítulos de la serie anterior mientras carga esta
    fill_seasons([])                          # ni sus temporadas
    HOME.setProperty("flix_series_next", nxt[0] if nxt else "")
    HOME.clearProperty("flix_series_done")
    HOME.clearProperty("flix_series_hold")
    HOME.clearProperty("flix_series_upto")   # «Al día» y capítulo elegido por fix_next (de la serie anterior)
    HOME.clearProperty("flix_series_play_ep")
    HOME.setProperty("flix_series_pct", str(nxt[1]) if nxt and nxt[1] else "")
    HOME.setProperty("flix_series_play", play)
    set_rating(j, play)                       # después de flix_series_play: su hilo comprueba que sigue siendo esta
    HOME.setProperty("flix_series_folder", seasons)
    HOME.setProperty("flix_series_tmdb", tm.group(1) if tm else "")     # botón ( i ) (flix_info)
    try:
        import flix_common
        flix_common.favorite_prop("show", tm.group(1) if tm else "")   # corazón de la ficha: ¿ya está en favoritos?
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] favoritos: %s" % e, xbmc.LOGINFO)
    HOME.setProperty("flix_series_path", path)          # y para volver a esta ficha desde «Títulos de X»
    find_trailer(tm.group(1) if tm else "", route_field(j, "trailer"), seasons)
    HOME.setProperty("flix_series_title", m.group(1) if m else "")
    title = m.group(1) if m else "?"
    HOME.setProperty("flix_section", title)   # cabecera de la ventana Vídeos (si no, sale la última sección: "Anime")
    if nxt and not ficha and started(tm.group(1)):
        import flix_play
        sub = ("%s a medias  ·  %s %%" % (nxt[0], nxt[1])) if nxt[1] else \
            "Siguiente: %s" % shown_next(nxt, tm.group(1) if tm else None, total_seasons(j))
        if direct and nxt[1]:
            choice = 0          # sigue a medias: como «Seguir viendo» del aviso. Si ya no lo está, se pregunta como siempre
        elif not nxt[1] and tm and catalog_next(tm.group(1), nxt[0]) is False:
            # al día (Palantir no tiene el siguiente): el aviso lo dice de entrada y no ofrece reproducir (catalog_next)
            choice = flix_play.choose(title, uptodate_sub(tm.group(1), nxt[0]), "Ver temporadas", "Cerrar",
                                      mode="uptodate", fanart=HOME.getProperty("flix_open_fanart"))
            xbmc.log("[flix_series] %s al día (sin %s en la base de Palantir): opción %d" % (title, nxt[0], choice),
                     xbmc.LOGINFO)
            flix_play.release_pending()
            if choice != 0:
                return                  # «Cerrar» o Atrás
            m2 = re.match(r"T(\d+) E(\d+)$", nxt[0])
            apply_fix(("", "", "T%s E%d" % (m2.group(1), int(m2.group(2)) - 1)))     # botón «Al día · TxEy» de la ficha
            choice = 2                  # a sus temporadas
        else:
            choice = flix_play.choose(title, sub, "Seguir viendo", more="Ver temporadas", pct=nxt[1],  # TxEy en sub
                                      fanart=HOME.getProperty("flix_open_fanart"))
        xbmc.log("[flix_series] %s a medias: opción %d" % (title, choice), xbmc.LOGINFO)
        try:                    # la capa del pop-up (pending) se quita si no se llega a begin() (flix_play.release_pending)
            if choice == 0:
                fix = None if nxt[1] else next_available(seasons, nxt[0], tm.group(1) if tm else None)
                if fix and fix[1]:
                    xbmc.log("[flix_series] Palantir no tiene %s: pongo %s" % (nxt[0], fix[0]), xbmc.LOGINFO)
                    flix_play.start(fix[1])
                    return
                if not fix and late_at > 0:
                    resume_episode(seasons, nxt[0], title, late_at)     # a medias, pero Palantir no lo sabe
                    return
                if not fix:
                    flix_play.resume_series(play, HOME.getProperty("flix_open_fanart"))
                    return
                # al día: Palantir no tiene más (antes: «El episodio 2x49 de Bleach no está disponible»)
                apply_fix(fix)
                xbmcgui.Dialog().notification(title, "Al día: Palantir aún no tiene el capítulo siguiente al %s" % fix[2],
                                              xbmcgui.NOTIFICATION_INFO, 4000)
                choice = 2                                  # y a sus temporadas (botón «Al día · TxEy»)
            if choice == 1:
                # el capítulo que ofrece el aviso, a medias o el siguiente, desde el minuto 0 (antes T1 E1 de la
                # serie; Carlos, 6-nov). T1 E1 solo si no hay capítulo siguiente (al día o vista entera)
                fix = None if nxt[1] else next_available(seasons, nxt[0], tm.group(1) if tm else None)
                if fix and fix[1]:
                    xbmc.log("[flix_series] %s: %s desde el principio" % (title, fix[0]), xbmc.LOGINFO)
                    flix_play.start(fix[1])
                elif fix:
                    play_first(seasons, title)
                else:
                    restart_episode(seasons, nxt[0], title,
                                    fallback=None if nxt[1] else (lambda: play_first(seasons, title)))
                return
        finally:
            flix_play.release_pending()
        if choice != 2:
            return
    release()
    xbmc.log("[flix_series] abro temporadas de %s" % title, xbmc.LOGINFO)
    if use_sheet():
        import flix_series_sheet
        flix_series_sheet.open_sheet(seasons)
        return
    if open_checked(seasons, title) and xbmc.getCondVisibility("Container.Content(seasons)"):
        watch_seasons(seasons)


def tmdb_star(j):
    """«★ 7.1»: 1.ª nota de la ruta de Palantir («7.1/7.6» = TMDB/IMDb); '' si no hay"""
    m = re.search(r'"rating": \'([0-9.]+)', j)
    return "★ %s" % m.group(1) if m and m.group(1) not in ("0", "0.0") else ""


def set_rating(j, play):
    """nota de la serie en la línea de datos de la ficha (MyVideoNav: flix_series_rating). En la táctil no hay
    cursor que pase por los pósters para verla (Carlos, 21-oct). La ★ de TMDB al momento; con clave de MDBList,
    Metacritic -> IMDb en un hilo (de caché, ratings3.json entero, o pedida): el clic no la lee (revisión 7-nov
    PY-12). Devuelve el hilo"""
    HOME.setProperty("flix_series_rating", tmdb_star(j))

    def late():
        try:
            import flix_ratings
            r = flix_ratings.label_for(play, wait=flix_ratings.TIMEOUT)
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] nota: %s" % e, xbmc.LOGINFO)
            return
        if r and HOME.getProperty("flix_series_play") == play:
            HOME.setProperty("flix_series_rating", r)
    import threading
    t = threading.Thread(target=late, daemon=True)
    t.start()
    return t


def find_trailer(tmdb, palantir, seasons):
    """botón «Tráiler» de la serie (MyVideoNav 5251): URL en flix_series_trailer, buscada en un hilo (flix_trailer:
    TMDB y si no Palantir) mientras se abren las temporadas. Sin el addon YouTube ni se busca: sin botón."""
    HOME.clearProperty("flix_series_trailer")
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
        return

    def run():
        try:
            import flix_common
            import flix_trailer
            url = flix_trailer.resolve("tv", tmdb, palantir)
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] tráiler: %s" % e, xbmc.LOGINFO)
            return
        if flix_common.quitting():              # Kodi cerrándose: nada que poner
            return
        if url and HOME.getProperty("flix_series_folder") == seasons:     # sigue en esta serie
            HOME.setProperty("flix_series_trailer", url)
    import threading
    # daemon: el script no se queda hasta 6-12 s vivo esperando a TMDB tras abrir la ficha (revisión 7-nov PY-22)
    threading.Thread(target=run, daemon=True).start()


def started(tmdb):
    """serie con ▶ (a medias y seguida; mismo criterio que el póster): vista entera u oculta = no. Solo esa serie y
    sin cargar flix_progress (revisión 29-oct DAT-06: 45-128 ms de imports antes del aviso en proot)"""
    from flix_common import SHOW_STARTED, show_state
    try:
        return show_state(xbmcvfs.translatePath(WATCHED), tmdb) == SHOW_STARTED
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] estado de la serie: %s" % e, xbmc.LOGINFO)
        return False


SPECIAL_RE = re.compile(r"especial|special|extra", re.I)


def list_dir(path, props):
    # JSON-RPC común (revisión 29-oct DAT-20); respuesta que no es JSON: ValueError, como antes
    return flix_common_list_dir(path, props)


def number(f, key, pattern):
    """temporada / capítulo de un elemento: propiedad de Kodi o, si Palantir no la da, el número de la etiqueta"""
    n = f.get(key)
    if isinstance(n, int) and n >= 0:
        return n
    m = re.search(pattern, f.get("title") or f.get("label") or "")
    return int(m.group(1)) if m else None


def pick_season(items):
    """1.ª temporada que no sea especial (temporada 0 / «Especiales»)"""
    ok = [(number(f, "season", r"(\d+)"), i, f) for i, f in enumerate(items)
          if f.get("filetype") != "file" and not SPECIAL_RE.search(f.get("label") or "")]
    ok = [x for x in ok if x[0] != 0]
    ok.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return ok[0][2] if ok else None


def pick_episode(items):
    """capítulo con el número más bajo (Palantir titula «1x01 Nombre»)"""
    eps = [(number(f, "episode", r"\d+x(\d+)"), i, f) for i, f in enumerate(items) if f.get("filetype") != "directory"]
    eps = [x for x in eps if x[0] != 0] or eps
    eps.sort(key=lambda x: (x[0] is None, x[0] or 0, x[1]))
    return eps[0][2] if eps else None


def play_first(seasons, title):
    """T1 E1 (sin especiales) desde el principio"""
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    ep = None
    try:
        items = list_dir(seasons, ["season", "episode", "title"])
        if any(f.get("filetype") == "file" for f in items):
            # serie de una temporada (Carrie): Palantir da los capítulos directamente. Ojo: «listar» un capítulo
            # lo REPRODUCE (abre el selector) y la lista falla
            ep = pick_episode(items)
        else:
            season = pick_season(items)
            if season:
                ep = pick_episode(list_dir(season["file"], ["season", "episode", "title"]))
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not ep:
        xbmc.log("[flix_series] no encuentro el 1.er capítulo de %s" % title, xbmc.LOGINFO)
        xbmcgui.Dialog().notification(title, NO_ANSWER_RETRY,
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        return
    xbmc.log("[flix_series] %s desde el principio: %s" % (title, ep.get("label")), xbmc.LOGINFO)
    import flix_play
    flix_play.start(ep["file"])


def episode_file(seasons, label):
    """ruta del capítulo «TxEy» en la lista de Palantir (None si no lo tiene o no es TxEy)"""
    m = re.match(r"T(\d+) E(\d+)$", label or "")
    if not m:
        return None
    s, e = int(m.group(1)), int(m.group(2))
    items = list_dir(seasons, ["season", "episode", "title"])
    if any(f.get("filetype") == "file" for f in items):
        eps = items                     # serie de una temporada: Palantir da los capítulos directamente
    else:
        season = next((f for f in items if f.get("filetype") != "file"
                       and number(f, "season", r"(\d+)") == s), None)
        eps = list_dir(season["file"], ["season", "episode", "title"]) if season else []
    ep = next((f for f in eps if f.get("filetype") != "directory"
               and number(f, "episode", r"\d+x(\d+)") == e), None)
    return ep.get("file") if ep else None


def resume_episode(seasons, label, title, offset):
    """un capítulo concreto en su minuto (offset s): el a medias que Palantir empezaría de cero"""
    restart_episode(seasons, label, title, offset=offset)


def restart_episode(seasons, label, title, fallback=None, offset=0):
    """«Desde el principio»: el capítulo del aviso desde el minuto 0 (flix_play.start sin offset, como el «Desde el
    principio» de un capítulo en la pantalla de la serie). fallback: si Palantir no lo tiene (siguiente de una serie
    vista entera), en vez de avisar"""
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    path = None
    try:
        path = episode_file(seasons, label)
    except Exception as ex:  # noqa: BLE001
        xbmc.log("[flix_series] capítulo %s para empezarlo: %s" % (label, ex), xbmc.LOGINFO)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if not path:
        xbmc.log("[flix_series] no encuentro %s de %s para empezarlo" % (label, title), xbmc.LOGINFO)
        if fallback:
            fallback()
            return
        xbmcgui.Dialog().notification(title, NO_ANSWER_RETRY, xbmcgui.NOTIFICATION_INFO, 5000)
        return
    import flix_play
    if offset > 0:
        xbmc.log("[flix_series] %s: %s en su minuto (%d s; Palantir lo empezaría de cero)" % (title, label, offset), xbmc.LOGINFO)
        flix_play.start(path, offset)
        return
    xbmc.log("[flix_series] %s: %s desde el principio" % (title, label), xbmc.LOGINFO)
    flix_play.start(path)


WATCH_STEP = 0.15       # s entre miradas a la temporada enfocada
# carpeta que no existe (0 elementos): un hueco se vacía con ella antes de cargar otra temporada. Con la ruta vacía
# Kodi conservaba los capítulos viejos y Container.IsUpdating no se marca en estas listas
EMPTY_EPS = "special://skin/media/flix/sin-capitulos/"
EPS_FAIL = 20           # s sin capítulos tras pedir una temporada -> «No se pudieron cargar los capítulos»
DEBOUNCE = 0.4          # s quieto en una temporada antes de pedir sus capítulos (Palantir: ~2 s cada vez, sin caché)
EPS_SLOTS = 6           # listas de capítulos (MyVideoNav 7970-7975): las últimas temporadas vistas se quedan cargadas
EPS_FIRST_ID = 7970


def season_key(path):
    """lo que identifica una temporada en su ruta: Palantir mete en ella los contadores de vistos (watchedEpisodes,
    playCount...) y al marcar un capítulo la ruta cambia; con la ruta entera se tomaba por otra temporada y se
    vaciaban y volvían a pedir sus capítulos (Shield, 23-oct). Si no se lee, la ruta tal cual"""
    try:
        j = decode_route(path)
    except Exception:  # noqa: BLE001
        return path
    tm, se = re.search(r'"tmdb": \'?(\d+)', j), re.search(r'"season": (\d+)', j)
    return ("%s/%s" % (tm.group(1), se.group(1))) if tm and se else path


class EpsSlots:
    """Qué lista de capítulos se ve (Carlos, 21-oct: al volver a una temporada, sin esperar a Palantir otra vez).
    Cada hueco k es una lista de MyVideoNav con contenido Window(home).Property(flix_eps_c<k>); solo se ve la activa
    (flix_eps_slot) y las ocultas conservan sus capítulos sin pintar miniaturas. step() devuelve los cambios de
    propiedades; count(k) = elementos que tiene ya la lista k. Temporada nueva: tras DEBOUNCE quieto se coge el hueco
    libre o el usado hace más tiempo, se vacía (EMPTY_EPS, para no ver los de otra temporada) y se le pone la ruta."""

    def __init__(self, n=EPS_SLOTS):
        self.paths, self.used, self.ready = [None] * n, [0.0] * n, set()   # paths: season_key de cada hueco
        self.active, self.seen, self.since, self.job = None, None, 0.0, None

    def find(self, path):
        key = season_key(path)
        return next((k for k, p in enumerate(self.paths) if p == key and k in self.ready), None)

    def pick(self):
        free = [k for k, p in enumerate(self.paths) if p is None]
        return free[0] if free else min(range(len(self.paths)), key=lambda k: self.used[k])

    def _show(self, k, out):
        self.active = k
        out["flix_eps_slot"] = "" if k is None else str(k)
        out["flix_eps_id"] = str(EPS_FIRST_ID + k) if k is not None else str(SEASONS_LIST)
        out["flix_eps_failed"] = ""

    def stale_except(self, k):
        """tras ver un capítulo de la temporada a la vista (hueco k): esa se queda como está (sin vaciarla: el foco
        sigue en el capítulo) y ponerla al día es cosa de quien llama (la ventana Vídeos, con hide_keep, la refresca
        en su sitio con refresh_eps_in_place); las demás se vuelven a pedir cuando se enfoquen"""
        for i in range(len(self.paths)):
            if i != k:
                self.paths[i] = None
                self.ready.discard(i)
        return {}

    def hide_keep(self, k):
        """tras parar un capítulo lanzado desde el hueco k: todo oculto mientras Kodi recarga la carpeta (a la vista, Kodi
        refresca él solo las listas de Palantir y, a la vez que la carpeta, la recarga fallaba y saltaba a la raíz de
        Vídeos: banco 25-oct); k sigue cargado y vuelve al momento en cuanto se vea su temporada (seen=None)"""
        self.stale_except(k)
        self.seen, self.job = None, None
        out = {"flix_eps_loading": ""}
        self._show(None, out)
        return out

    def invalidate(self):
        """tras ver un capítulo (✓ nuevos): todo se vuelve a pedir; la enfocada, en seguida"""
        self.paths, self.ready, self.job, self.seen = [None] * len(self.paths), set(), None, None
        out = {"flix_eps_loading": ""}
        self._show(None, out)
        return out

    def step(self, focus, now, count, first=False):
        out = {}
        if season_key(focus) != self.seen:              # misma temporada con ✓ nuevos: no es otra
            self.seen, self.since = season_key(focus), now
            self.job = None
            out["flix_eps_loading"] = ""
            k = self.find(focus)
            if k is not None:                           # ya cargada: al momento
                self.used[k] = now
                self._show(k, out)
                return out
            if self.active is not None:
                self._show(None, out)                   # rueda hasta que se pida y llegue
        if not focus:
            return out
        if self.job is None and self.active is None and (first or now - self.since >= DEBOUNCE):
            k = self.pick()
            self.ready.discard(k)
            self.paths[k], self.used[k] = season_key(focus), now
            self.job = ["vaciar", k, now]
            out["flix_eps_c%d" % k] = EMPTY_EPS
            out["flix_eps_loading"] = str(k)
            self._show(k, out)
        elif self.job and self.job[0] == "vaciar" and count(self.job[1]) == 0:
            self.job = ["cargar", self.job[1], now]
            out["flix_eps_c%d" % self.job[1]] = focus
        elif self.job and self.job[0] == "cargar" and count(self.job[1]) > 0:
            out["log"] = "capítulos en %.1f s" % (now - self.job[2])
            self.ready.add(self.job[1])
            self.job = None
            out["flix_eps_loading"] = ""
        elif self.job and self.job[0] == "cargar" and now - self.job[2] > EPS_FAIL:
            self.paths[self.job[1]] = None
            self.job = None
            out["flix_eps_failed"] = "1"
        return out


def season_index(items, nxt):
    """posición en la lista de temporadas de la del siguiente capítulo («T2 E5» -> temporada 2); si no se sabe,
    la 1.ª que no es especial"""
    m = re.match(r"T(\d+) ", nxt or "")
    if m:
        for i, f in enumerate(items):
            if number(f, "season", r"(\d+)") == int(m.group(1)):
                return i
    first = pick_season(items)
    return items.index(first) if first is not None else 0


REFOCUS_SECS = 6        # s intentando devolver el foco al capítulo marcado (desde que acaba la recarga de la carpeta)
HOLD_MAX = 20           # s como mucho de retención de la pantalla de serie (flix_menu: flix_series_hold)
# un diálogo encima de la pantalla de serie. Nombrados uno a uno: System.HasModalDialog no ve los de Python (con
# FlixMenu abierto el vigilante seguía y vaciaba la lista de capítulos; Shield, 23-oct)
COVERED = ("System.HasModalDialog | Window.IsActive(contextmenu) | Window.IsActive(selectdialog) | "
           "Window.IsVisible(FlixMenu.xml) | Window.IsVisible(FlixResume.xml) | Window.IsVisible(FlixCtx.xml) | "
           "Window.IsVisible(FlixMovie.xml) | Window.IsVisible(FlixMessage.xml) | Window.IsVisible(FlixEditor.xml)")
SEASONS_LIST = 7952     # columna de temporadas (MyVideoNav vista 52: elementos fijos, su onclick manda)
EPS_IDS = {str(EPS_FIRST_ID + k) for k in range(EPS_SLOTS)}
LOADING = "Window.IsActive(busydialog) | Window.IsActive(selectdialog) | Window.IsActive(progressdialog)"
AFTER_STOP = 12         # s desde que había vídeo: la cuenta atrás y el selector del siguiente que abre Palantir solo
                        # al parar (progressdialog / selectdialog) no son un clic


BACK_PLAY_SECS = 30     # s tras parar en los que el foco vuelve al capítulo si la recarga se lo lleva
REFRESH_AFTER_STOP = 6  # s: si Kodi no recarga la carpeta tras el vídeo, los ✓ se refrescan igualmente


def back_to_episode(since_stop, idle):
    """¿devolver el foco al capítulo que se estaba viendo? Mientras nadie haya tocado el mando desde que se paró (la
    recarga de Kodi y la cuenta atrás de Palantir llegan a los ~2-9 s) y como mucho BACK_PLAY_SECS"""
    return since_stop < BACK_PLAY_SECS and idle + 1 >= since_stop


def reload_pending(pending, updating, now):
    """¿seguimos esperando a que Kodi recargue la carpeta tras un vídeo? (mientras, las listas de capítulos ocultas)"""
    if not pending:
        return False
    done = pending["updated"] and not updating
    return not done and now - pending["t"] <= REFRESH_AFTER_STOP


def follow_column(col_path, col_now, column_focused):
    """(temporada que manda en el panel, ¿hay que corregir la selección de la columna?). El panel sigue a la columna
    SOLO mientras la columna tiene el foco: con el foco en los capítulos, la recarga de Kodi tras un vídeo le cambiaba
    la selección y el panel saltaba a otra temporada (banco, 25-oct)"""
    if col_now and (column_focused or not col_path):
        return col_now, False
    return col_path, bool(col_now and col_path and season_key(col_now) != season_key(col_path))


def column_delta(col_path, current_item):
    """cuánto mover la selección de la columna (Control.Move) para volver a col_path; 0 si no se sabe"""
    want = season_key(col_path)
    idx = next((i for i in range(MAX_SEASONS) if season_key(HOME.getProperty("flix_s%d_path" % i) or "-") == want), None)
    return idx - (int(current_item) - 1) if idx is not None and current_item.isdigit() else 0


def episode_click(loading, last_focus, layer_on, since_stop, ids=EPS_IDS, pressed=False):
    """¿acaba de pulsarse un capítulo de la lista? Kodi lo reproduce él (no pasa por flix_play) y la pantalla de carga
    única no salía: carga en marcha, el foco estaba en una lista de capítulos, sin capa aún y sin un capítulo recién
    parado (Palantir abre el selector del siguiente a los ~8 s). ids: listas de capítulos (la ficha propia añade la
    7976 de las series de una temporada). pressed (flix_user_press): consta la pulsación, da igual el tiempo"""
    return bool(loading) and last_focus in ids and not layer_on and (pressed or since_stop > AFTER_STOP)
MAX_SEASONS = 40        # huecos fijos de la columna (Includes_Flix.xml FlixSeasonSlots) y tope de la ficha propia
SEASON_FIELDS = ("title", "sub", "watched", "progress", "path", "plot", "genre")


def num(v):
    return int(v) if str(v or "").isdigit() else 0


def episodes(n):
    return "1 capítulo" if n == 1 else "%d capítulos" % n


def season_sub(it):
    """«61 capítulos (TMDB: 26)»: los capítulos que TIENE Palantir y, si TMDB cuenta otros, los suyos (como Estuary
    Palantir: «61 Episodios en Palantir (Temporada:26)»; Black Clover T2, Carlos 25-oct). Sin diferencia, «170
    capítulos  ·  2017». También con numeración propia (Black Clover: 3 temporadas en Palantir y 2 en TMDB; Estuary lo
    enseña igual y Carlos lo quiere así): donde TMDB no tiene esa temporada no sale nada"""
    p3, tm = num(it.get("p3total")), num(it.get("tmdbtotal"))
    if p3 and tm and p3 != tm:
        return "%s (TMDB: %d)" % (episodes(p3), tm)        # sin el año: no cabe en el móvil
    n = p3 or tm or num(it.get("total"))
    return "  ·  ".join(x for x in (n and episodes(n), it.get("year", "")) if x)


def season_state(it):
    """'watched', 'progress' o '': capítulos vistos en watched.db frente al MAYOR de los totales (Palantir y TMDB).
    Dos casos reales:
     - Black Clover T2: Palantir 61 capítulos, TMDB 26. El porcentaje de Palantir (con los de TMDB) la daba vista
       con 26 de 61 -> vista solo con los 61.
     - «Tierra de mafiosos» T2 (26-oct): en emisión, Palantir 5, TMDB 10, vistos los 5 -> «En progreso» hasta que
       salga y se vea el último (antes salía el ✓ verde).
    Sin esos datos, el porcentaje de Palantir"""
    seen = it.get("seen")
    total = max(num(it.get("p3total")), num(it.get("tmdbtotal")))
    if seen is not None and total:
        return "watched" if seen >= total else "progress" if seen else ""
    pct = num(it.get("pct"))
    return "watched" if pct >= 100 else "progress" if pct else ""


def season_row(it):
    """{campo: valor} (SEASON_FIELDS) de una temporada para la columna 7952: la etiqueta («Temporada 3» o la de
    Palantir) y sus propiedades (sub, watched, progress, path, plot, genre). Una sola regla para los huecos fijos
    (season_props: flix_s<i>_*, FlixSeasonSlots) y los elementos que añade la ficha propia de TV (revisión 7-nov XML-06)"""
    n = it.get("season", -1)
    state = season_state(it)
    return {"title": "Temporada %d" % n if n > 0 else it.get("label", ""),
            "sub": season_sub(it),
            "watched": "1" if state == "watched" else "",
            "progress": "1" if state == "progress" else "",
            "path": it.get("path", ""),
            "plot": it.get("plot", ""),
            "genre": it.get("genre", "")}


def season_props(items):
    """{propiedad de Window(home): valor} para la columna 7952 a partir de las temporadas de la ventana Vídeos.
    Antes la columna pedía las temporadas otra vez a Palantir: no atiende dos llamadas a la vez (~2 s cada una en la
    Shield, 21-oct) y las temporadas tardaban el doble en salir"""
    out = {}
    for i in range(MAX_SEASONS):
        row = season_row(items[i]) if i < len(items) else dict.fromkeys(SEASON_FIELDS, "")
        out.update(("flix_s%d_%s" % (i, k), row[k]) for k in SEASON_FIELDS)
    return out


def db_sig(path):
    """huella de una base SQLite para no repetir la misma consulta: fecha y tamaño, también del -wal (como
    flix_progress.watched_sig), y el contador de cambios de la cabecera (bytes 24-27), que SQLite sube en cada
    escritura aunque el aparato guarde la hora del fichero por segundos y el tamaño no cambie. None si no se lee"""
    out = []
    for f in (path, path + "-wal"):
        try:
            st = os.stat(f)
            out.append((st.st_mtime_ns, st.st_size))
        except OSError:
            out.append(None)
    try:
        with open(path, "rb") as fh:
            out.append(fh.read(28)[24:])
    except OSError:
        return None
    return tuple(out)


_SEEN = [None, None]    # [(base, serie, huella), {temporada: vistos}] de la última consulta de seasons_seen


def seasons_seen(tmdb):
    """{temporada: capítulos vistos} de la serie en watched.db; None si no se puede saber.
    La ficha lo pide cada segundo (flix_series_sheet.step_seasons): con la misma huella de watched.db se repite lo de
    la vez anterior sin abrirla (revisión 29-oct DAT-07: 18 ms por consulta en proot). La huella se toma ANTES de leer:
    si Palantir guarda mientras, la vuelta siguiente lo ve (como flix_progress, 25-oct)"""
    if not tmdb:
        return None
    from flix_common import watched_db
    db = watched_db(xbmcvfs.translatePath(WATCHED))     # la foto .flixbak mientras flix_p3sync rehace las pausas
    key = (db, tmdb, db_sig(db))
    if key[2] is not None and _SEEN[0] == key:
        return dict(_SEEN[1])
    rows = watched_rows("SELECT season, COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND playcount>0 GROUP BY season",
                        (tmdb,))
    if rows is None:
        return None
    out = {s: c for s, c in rows}
    if key[2] is not None and watched_db(xbmcvfs.translatePath(WATCHED)) == db:    # leída la misma base
        _SEEN[:] = [key, dict(out)]
    return out


def route_season(path, season="", total=""):
    """(temporada, capítulos) de la ruta de Palantir de una temporada; lo que no venga, lo recibido"""
    try:
        j = decode_route(path)
    except Exception:  # noqa: BLE001
        return season, total
    se, te = re.search(r'"season": (\d+)', j), re.search(r'"totalEpisodes": (\d+)', j)
    return (season if season.lstrip("-").isdigit() or not se else se.group(1),
            total if total.isdigit() or not te else te.group(1))


def season_item(label, s, total, year, pct, path, plot, genre):
    """(temporada como la usa la ficha, tmdb de su ruta) con lo leído de su elemento en la carpeta de la serie. «raw»:
    lo leído tal cual, para apuntarlo y adelantar la ficha la próxima vez (flix_fastsheet)"""
    raw = {"label": label, "s": s, "total": total, "year": year, "genre": genre, "plot": plot}
    if not s.lstrip("-").isdigit() or not total.isdigit():
        # Palantir no siempre rellena Season/TotalEpisodes en el elemento (móvil: «Continuar · T1 E7» con la T1
        # de 6 vista entera, Carlos 24-oct); su ruta los lleva: "season": 1, "totalEpisodes": 6
        s, total = route_season(path, s, total)
    p3, tmdb_total = False, total
    meta = route_meta(path)
    if own_numbering(meta):
        # Bleach: «366 episodios» en la T1 (los 20 de Palantir) y las T3-T16 sin nada (TMDB no las tiene):
        # los capítulos que tiene Palantir y, donde TMDB no llega, sin su año (era el de la serie)
        p3 = True
        if meta.get("p3TotalEpisodes"):
            total = str(meta["p3TotalEpisodes"])
        if meta.get("season", 0) > meta["totalSeasons"]:
            year = ""
    return {"label": label, "season": int(s) if s.lstrip("-").isdigit() else -1,
            "total": total, "year": year, "p3": p3, "p3total": meta.get("p3TotalEpisodes", 0),
            "tmdbtotal": tmdb_total, "pct": pct, "path": path, "plot": plot, "genre": genre,
            "raw": raw}, meta.get("tmdb", "")


def window_seasons(cid=None):
    """temporadas ya cargadas (no se vuelve a llamar a Palantir): las de la ventana Vídeos o, con cid, las de esa lista
    (ficha propia, flix_series_sheet: lista 7976)"""
    c = "Container(%d)." % cid if cid else "Container."
    n = xbmc.getInfoLabel(c + "NumItems")
    out, tmdb = [], ""
    for i in range(min(int(n) if n.isdigit() else 0, MAX_SEASONS)):
        g = lambda k: xbmc.getInfoLabel("%sListItemAbsolute(%d).%s" % (c, i, k))  # noqa: E731
        if g("Label") == "..":
            continue
        it, t = season_item(g("Label"), g("Season"), g("Property(TotalEpisodes)"), g("Year"),
                            g("Property(WatchedEpisodePercent)"), g("FileNameAndPath"), g("Plot"), g("Genre"))
        tmdb = tmdb or t
        out.append(it)
    seen = seasons_seen(tmdb) if out else None
    for it in out:
        it["seen"] = None if seen is None else seen.get(it["season"], 0)
    return out


def fill_seasons(items):
    for k, v in season_props(items).items():
        HOME.setProperty(k, v)


def visible_seasons():
    """rellena la columna con las temporadas de la ventana y las devuelve (etiqueta, número, ruta)"""
    items = window_seasons()
    fill_seasons(items)
    return items


def eps_count(k):
    n = xbmc.getInfoLabel("Container(%d).NumItems" % (EPS_FIRST_ID + k))
    return int(n) if n.isdigit() else 0


def apply(out):
    for k, v in out.items():
        if k == "log":
            xbmc.log("[flix_series] %s" % v, xbmc.LOGINFO)
        elif v:
            HOME.setProperty(k, v)
        else:
            HOME.clearProperty(k)


def clear_eps():
    """sin capítulos de la serie anterior"""
    for k in range(EPS_SLOTS):
        HOME.clearProperty("flix_eps_c%d" % k)
    for k in ("flix_eps_slot", "flix_eps_loading", "flix_eps_failed", "flix_season_cur"):
        HOME.clearProperty(k)
    clear_pending_props()
    HOME.setProperty("flix_eps_id", str(SEASONS_LIST))


def refresh_eps_in_place(mon, hint="", wait=6):
    """tras marcar un capítulo (flix_menu): la lista de capítulos a la vista se vuelve a pedir EN SU SITIO (misma
    ruta + &reload=, como las filas del Inicio): Kodi no la vacía, Palantir la da con los ✓ al día y solo cambia ese
    icono. Antes se vaciaban todas («Cargando capítulos…») y no quedaba nada a la vista (Carlos, 23-oct). El foco se
    queda en el mismo capítulo: devuelve (lista, posición) y el vigilante lo enfoca cuando Kodi acaba de recargar la
    carpeta (si se hace aquí, la recarga lo vuelve a llevar a la columna de temporadas). hint = «lista,posición»
    que leyó flix_menu antes de abrir sus diálogos (aquí, recién cerrados, CurrentItem salía vacío)"""
    k = HOME.getProperty("flix_eps_slot")
    if not k.isdigit():
        return None
    cid = EPS_FIRST_ID + int(k)
    base = re.sub(r"&reload=\d+$", "", HOME.getProperty("flix_eps_c%s" % k))
    if not base or base == EMPTY_EPS:
        return None
    hcid, _, hpos = hint.partition(",")
    pos = hpos if hcid == str(cid) else xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
    pos = int(pos) - 1 if pos.isdigit() and int(pos) > 0 else None
    old = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, pos)) if pos is not None else ""
    xbmc.log("[flix_series] capítulos al día en su sitio (lista %d, posición %s)" % (cid, pos), xbmc.LOGINFO)
    HOME.setProperty("flix_eps_c%s" % k, "%s&reload=%d" % (base, int(time.time() * 1000)))
    end = time.time() + wait
    while pos is not None and time.time() < end and not mon.waitForAbort(0.15):
        now = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, pos))
        if now and now != old:                          # ya llegó la lista nueva
            break
    return (cid, pos) if pos is not None else None


def watch_seasons(folder):
    """Mientras la ventana Vídeos muestre las temporadas de esta serie: capítulos de la temporada enfocada en una de
    las listas EpsSlots. Sigue vivo durante la reproducción de un capítulo; termina al salir de la serie o al
    cerrarse Kodi (System.OnQuit: a los RunScript sin addon Kodi no les avisa por abortRequested; APA-03)"""
    import flix_common
    mon = flix_common.quit_monitor()
    items = visible_seasons()
    slots, away, sig_at, played = EpsSlots(), None, time.time(), False
    nxt, done = roll_next(HOME.getProperty("flix_series_next"), HOME.getProperty("flix_series_pct"), items)
    if nxt != HOME.getProperty("flix_series_next"):
        HOME.setProperty("flix_series_next", nxt)       # botón «Seguir viendo · TxEy» y temporada que se abre
    if done:
        HOME.setProperty("flix_series_done", "1")       # vista entera: «Ver de nuevo» (ver() -> T1 E1)
    if items:
        # al día (fix_next): la temporada donde se va, no la primera
        idx = season_index(items, HOME.getProperty("flix_series_next") or HOME.getProperty("flix_series_upto"))
        end = time.time() + 2                           # los huecos se ven un fotograma después de rellenarlos
        while time.time() < end and xbmc.getInfoLabel("Container(%d).NumItems" % SEASONS_LIST) != str(len(items)):
            mon.waitForAbort(0.05)
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (SEASONS_LIST, idx))
        # la temporada inicial, sin esperar al debounce: lo primero que se pide a Palantir tras las temporadas
        apply(slots.step(items[idx]["path"], time.time(), eps_count, first=True))
        xbmc.log("[flix_series] %d temporadas a la vista; pido capítulos de la %d.ª" % (len(items), idx + 1),
                 xbmc.LOGINFO)
    sig = [(x["pct"], x["path"], x["total"], x.get("seen")) for x in items]
    # la temporada del «Continuar»: cuando llegue su lista se mira si Palantir tiene ese capítulo (fix_next)
    check = season_key(items[season_index(items, HOME.getProperty("flix_series_next"))]["path"]) \
        if items and HOME.getProperty("flix_series_next") and not HOME.getProperty("flix_series_pct") else None
    refocus = None                                      # (lista, posición, hasta): capítulo marcado en flix_menu
    reloaded = False                                    # Kodi recargó la carpeta con la retención puesta
    noted = set()                                       # (hueco, temporada) ya apuntados en flix_eps_index.json
    last_focus, last_path, last_media = "", "", 0.0     # foco y ruta del capítulo antes de que salga un diálogo
    last_pos, play_from = "", None                      # posición en su lista y (lista, posición) del que se reproduce
    back_play = None                                    # (lista, posición, hora de parar): volver a ese capítulo
    back_try, back_ok = 0.0, 0.0                        # último intento de devolver el foco / desde cuándo está en él
    loading_from, last_loading = None, 0.0              # capítulo enfocado al EMPEZAR una carga (no en sus relevos)
    pending_refresh = None                              # ✓ del capítulo visto: refrescar cuando Kodi recargue la carpeta
    col_path, col_fixed = "", 0.0                       # temporada que manda en el panel (la de la columna al enfocarla)
    while not flix_common.quitting(mon):
        if xbmc.getCondVisibility("Player.HasMedia"):
            if not played:                              # empieza: de qué capítulo de la lista (para volver a él)
                play_from, loading_from = loading_from, None
                xbmc.log("[flix_series] vídeo en marcha desde %s" % (play_from,), xbmc.LOGINFO)
            played, last_media = True, time.time()      # tras parar: la cuenta atrás de Palantir no es un clic
        if xbmc.getCondVisibility("Window.IsActive(videos)"):
            if pending_refresh and xbmc.getCondVisibility("Container.IsUpdating"):
                pending_refresh["updated"] = True       # Kodi recarga la carpeta tras el vídeo (aunque haya diálogos)
            if xbmc.getCondVisibility(LOADING):
                if time.time() - last_loading > 3:      # empieza una carga, no un relevo entre diálogos (0,2-0,5 s)
                    loading_from = (last_focus, last_pos) if last_focus in EPS_IDS and last_pos.isdigit() else None
                last_loading = time.time()
                # con capa ya puesta (flix_play), o con una acción del menú en marcha (Palantir marcando: sus diálogos
                # también son «carga»), no es un clic en un capítulo
                busy = HOME.getProperty("flix_playload") or HOME.getProperty("flix_working") or HOME.getProperty("flix_ctx_auto")
                import flix_playload
                if episode_click(True, last_focus, bool(busy), time.time() - last_media,
                                 pressed=bool(HOME.getProperty(flix_playload.USER_PRESS))):
                    flix_playload.begin(HOME.getProperty("flix_open_fanart"), last_path, mark=False)
                    xbmc.log("[flix_series] capítulo pulsado en la lista: pantalla de carga", xbmc.LOGINFO)
            elif not xbmc.getCondVisibility("System.HasModalDialog"):
                last_focus = xbmc.getInfoLabel("System.CurrentControlId")
                if last_focus in EPS_IDS:
                    last_path = xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % last_focus)
                    last_pos = xbmc.getInfoLabel("Container(%s).CurrentItem" % last_focus)
            if xbmc.getCondVisibility(COVERED):
                # un diálogo encima (FlixMenu, FlixCtx, menú de Kodi): Container.* y las listas son las SUYAS -> la
                # columna se llenaba con sus elementos («Temporada 1» repetida, «Marcar como vista»), los capítulos se
                # iban y la carpeta «cambiaba» (este vigilante se terminaba). Nada hasta que se cierre (Shield, 23-oct)
                if flix_common.wait_quit(mon, WATCH_STEP):
                    break
                continue
            fp = xbmc.getInfoLabel("Container.FolderPath")
            if not fp or xbmc.getCondVisibility("Container.IsUpdating"):
                reloaded = reloaded or bool(HOME.getProperty("flix_series_hold"))
                if pending_refresh:
                    pending_refresh["updated"] = True
                if flix_common.wait_quit(mon, WATCH_STEP):  # Kodi recargando la carpeta (Palantir tras marcar)
                    break
                continue
            if fp != folder:
                break                                   # otra carpeta (Atrás, otra serie)
            away = None
            if xbmc.getCondVisibility("Control.HasFocus(52)") and not HOME.getProperty("flix_ctx_auto"):
                # la lista de temporadas de Kodi está fuera de pantalla: al cerrar un menú el foco vuelve a ella y el
                # mando se movía sin que se viera nada (Fire TV, 23-oct) -> a la columna visible
                xbmc.executebuiltin("SetFocus(%d)" % SEASONS_LIST)
            if played and not xbmc.getCondVisibility("Player.HasMedia"):
                played = False                          # tras ver un capítulo: capítulos guardados con ✓ viejos
                # durante el vídeo la columna no tiene selección y el panel se queda sin hueco a la vista (active None):
                # el hueco es el de la lista desde la que se lanzó
                k = int(play_from[0]) - EPS_FIRST_ID if play_from else None
                xbmc.log("[flix_series] vídeo parado: lanzado desde %s (hueco %s)" % (play_from, k), xbmc.LOGINFO)
                if k is not None and 0 <= k < EPS_SLOTS and slots.paths[k] and k in slots.ready:
                    # lanzado desde una lista de la ficha: sigue a la vista y el foco vuelve a ese capítulo (antes se
                    # vaciaban todas y el foco acababa en la columna de temporadas; ya en 1.5.69, banco 25-oct). Sus ✓
                    # se refrescan en su sitio DESPUÉS de que Kodi recargue la carpeta: las dos llamadas a la vez a
                    # Palantir hicieron fallar la recarga y Kodi saltó a la raíz de Vídeos (banco, 25-oct)
                    apply(slots.hide_keep(k))
                    pos = int(play_from[1]) - 1
                    back_play = (EPS_FIRST_ID + k, pos, time.time())
                    pending_refresh = {"hint": "%s,%s" % play_from, "t": time.time(), "updated": False, "k": k}
                else:
                    apply(slots.invalidate())
                play_from = None
            if pending_refresh and slots.active == pending_refresh["k"] and (
                    (pending_refresh["updated"] and not xbmc.getCondVisibility("Container.IsUpdating")) or
                    time.time() - pending_refresh["t"] > REFRESH_AFTER_STOP):
                # Kodi ya recargó la carpeta tras el vídeo (o no lo hizo) y la temporada vuelve a estar a la vista:
                # ahora sí, los ✓ del capítulo en su sitio
                refresh_eps_in_place(mon, pending_refresh["hint"], wait=0)
                pending_refresh = None
            elif pending_refresh and time.time() - pending_refresh["t"] > BACK_PLAY_SECS:
                pending_refresh = None                  # se fue a otra temporada: se pedirá al volver
            hint = HOME.getProperty("flix_eps_refresh")
            if hint:                                    # flix_menu marcó un capítulo: ✓ al día, en su sitio
                HOME.clearProperty("flix_eps_refresh")
                back = refresh_eps_in_place(mon, hint)
                refocus = (back + (None,)) if back else None
            hold = HOME.getProperty("flix_series_hold")
            age = time.time() - float(hold or 0)
            if hold and (age > HOLD_MAX or (not HOME.getProperty("flix_eps_refresh") and (reloaded or age > 3) and
                         xbmc.getCondVisibility("Container.Content(seasons) + !Container.IsUpdating"))):
                # suelta cuando Kodi ya recargó la carpeta (Palantir la refresca tras marcar: ~8 s en la Shield);
                # antes se soltaba al segundo, ANTES de que empezara, y todo se ocultaba mientras (Shield, 23-oct)
                HOME.clearProperty("flix_series_hold")  # la carpeta ya está otra vez (MyVideoNav: retención)
                hold, reloaded = "", False
            if refocus and not hold:                    # con la recarga en curso el foco aún se lo lleva Kodi
                rcid, rpos, until = refocus
                if until is None:
                    refocus = (rcid, rpos, time.time() + REFOCUS_SECS)
                elif time.time() > until or xbmc.getCondVisibility("Control.HasFocus(%d)" % rcid):
                    refocus = None
                elif xbmc.getCondVisibility("Control.HasFocus(%d) | Control.HasFocus(52)" % SEASONS_LIST):
                    xbmc.log("[flix_series] foco de vuelta al capítulo (lista %d, posición %d)" % (rcid, rpos),
                             xbmc.LOGINFO)
                    xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (rcid, rpos))
            if back_play:
                bcid, bpos, t_stop = back_play
                now = time.time()
                if not back_to_episode(now - t_stop, xbmc.getGlobalIdleTime()):
                    back_play = None
                elif xbmc.getCondVisibility("Control.HasFocus(%d)" % bcid):
                    back_ok = back_ok or now
                    if now - back_ok > 2:               # ya se quedó en el capítulo: no insistir más
                        back_play = None
                else:
                    back_ok = 0.0
                    if now - back_try > 0.5 and not xbmc.getCondVisibility("Container.IsUpdating") and \
                            not reload_pending(pending_refresh, False, now) and \
                            xbmc.getCondVisibility("Control.HasFocus(%d) | Control.HasFocus(52)" % SEASONS_LIST):
                        back_try = now                  # cada 0,5 s como mucho: la recarga se lo puede volver a llevar
                        xbmc.log("[flix_series] tras el vídeo, foco de vuelta al capítulo (lista %d, posición %d)"
                                 % (bcid, bpos), xbmc.LOGINFO)
                        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (bcid, bpos))
            if time.time() - sig_at > 1:                # Kodi recarga la carpeta tras ver un capítulo: ✓ al día
                sig_at = time.time()
                now = window_seasons()
                if [(x["pct"], x["path"], x["total"], x.get("seen")) for x in now] != sig and now:
                    sig = [(x["pct"], x["path"], x["total"], x.get("seen")) for x in now]
                    fill_seasons(now)
                    # al abrir, los capítulos por temporada pueden no estar aún: «T1 E7» con 6 se quedaba (móvil, 24-oct)
                    nxt, done = roll_next(HOME.getProperty("flix_series_next"), HOME.getProperty("flix_series_pct"), now)
                    if nxt != HOME.getProperty("flix_series_next") or done:
                        HOME.setProperty("flix_series_next", nxt)
                        if done:
                            HOME.setProperty("flix_series_done", "1")
            col_now = xbmc.getInfoLabel("Container(%d).ListItem.Property(path)" % SEASONS_LIST)
            # tras parar un capítulo (back_play), la recarga de Kodi lleva el foco a la columna y le cambia la selección:
            # manda la temporada del capítulo hasta que el foco vuelva a él o se toque el mando
            col_path, fix = follow_column(col_path, col_now, xbmc.getCondVisibility("Control.HasFocus(%d)" % SEASONS_LIST)
                                          and not back_play)
            if fix and time.time() - col_fixed > 1:
                # la recarga de Kodi (tras un vídeo) cambió la selección de la columna con el foco en los capítulos: se
                # devuelve a la temporada a la vista sin mover el foco (si no, el panel saltaba a otra temporada)
                col_fixed = time.time()
                delta = column_delta(col_path, xbmc.getInfoLabel("Container(%d).CurrentItem" % SEASONS_LIST))
                if delta:
                    xbmc.executebuiltin("Control.Move(%d,%d)" % (SEASONS_LIST, delta))
            cur = col_path
            if cur != HOME.getProperty("flix_season_cur"):
                # temporada resaltada en la columna (táctil FTSeasonRow): con un diálogo encima Container(7952) ya no
                # es la columna y TODAS salían resaltadas (Carlos, 23-oct); esta propiedad no cambia mientras
                HOME.setProperty("flix_season_cur", cur)
            if not reload_pending(pending_refresh, xbmc.getCondVisibility("Container.IsUpdating"), time.time()):
                apply(slots.step(cur, time.time(), eps_count))  # tras un vídeo, nada a la vista hasta que Kodi recargue
            k = slots.active
            if k is not None and k in slots.ready and (k, slots.paths[k]) not in noted:
                noted.add((k, slots.paths[k]))          # «Seguir viendo» de esta temporada ya no pregunta a Palantir
                remember_eps(slots.paths[k], [e[0] for e in episodes_of(EPS_FIRST_ID + k)])
            if check and k is not None and k in slots.ready and slots.paths[k] == check:
                check = None
                apply_fix(fix_next(HOME.getProperty("flix_series_next"), HOME.getProperty("flix_series_pct"),
                                   episodes_of(EPS_FIRST_ID + k)))
        elif not xbmc.getCondVisibility("Player.HasMedia | Window.IsActive(busydialog) | "
                                        "Window.IsActive(busydialognocancel) | Window.IsActive(selectdialog)"):
            away = away or time.time()
            if time.time() - away > 3:                  # ni en la serie ni viendo un capítulo
                break
        if mon.waitForAbort(WATCH_STEP):
            break
    HOME.clearProperty("flix_series_hold")          # fuera de la serie: nada de retener su pantalla
    xbmc.log("[flix_series] fin del vigilante de temporadas", xbmc.LOGINFO)


def known_eps(key):
    """capítulos apuntados de una temporada («tmdb/temporada»); vacío si no hay o el índice no se lee"""
    try:
        with open(EPS_INDEX, encoding="utf-8") as fh:
            return set(json.load(fh)[key]["eps"])
    except (OSError, ValueError, KeyError, TypeError):
        return set()


def load_index():
    """el índice entero ({clave: {"t": ..., ...}}) sin lo caducado (EPS_INDEX_DAYS) ni lo que no sea un diccionario"""
    try:
        with open(EPS_INDEX, encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    now = time.time()
    return {k: v for k, v in data.items()
            if isinstance(v, dict) and now - float(v.get("t") or 0) < EPS_INDEX_DAYS * 86400}


def save_index(data):
    try:
        atomic_write(EPS_INDEX, json.dumps(data))
    except OSError as e:
        xbmc.log("[flix_series] no guardo %s: %s" % (EPS_INDEX, e), xbmc.LOGINFO)


def remember_eps(key, eps):
    """apunta los capítulos que Palantir tiene de una temporada (los que no tenga no se apuntan: Bleach sigue
    preguntando). Tira lo de más de EPS_INDEX_DAYS al guardar"""
    eps = sorted({e for e in eps if isinstance(e, int) and e > 0})
    if not key or not eps:
        return
    data = load_index()
    old, now = data.get(key) or {}, time.time()
    try:
        if old.get("eps") == eps and 0 <= now - float(old.get("t") or 0) < 86400:
            return          # los mismos capítulos, apuntados hace menos de un día: sin reescribir (revisión 29-oct
                            # DAT-08a; la caducidad de EPS_INDEX_DAYS se desplaza como mucho un día)
    except (TypeError, ValueError):
        pass
    data[key] = {"t": now, "eps": eps}
    save_index(data)


def season_number(f):
    """número de una temporada de una lista (de Palantir: «file»; de la ficha: «path»); None si es un especial,
    un capítulo o no lo tiene"""
    if f.get("filetype") == "file" or SPECIAL_RE.search(f.get("label") or ""):
        return None
    n = f.get("season")
    if not isinstance(n, int):
        n = number(f, "season", r"(\d+)")
    return n if isinstance(n, int) and n > 0 else None


def remember_seasons(tmdb, items):
    """apunta la ruta de Palantir de cada temporada de la serie (clave «tmdb», aparte de las «tmdb/temporada»):
    Slow Horses (26-oct) tardaba 3 consultas (~6 s en la Shield) en pasar de la T1 acabada a la T2 solo para hallar
    su ruta; con ella apuntada basta listar la T2. Sin especiales (nunca son «la siguiente»)"""
    routes = {}
    for f in items or []:
        n, path = season_number(f), f.get("path") or f.get("file")
        if n and path and isinstance(path, str):
            routes.setdefault(str(n), path)
    if not tmdb or not routes:
        return
    data = load_index()
    if (data.get(tmdb) or {}).get("seasons") == routes:
        return                                           # nada nuevo: sin reescribir (la ficha lo llama cada vez)
    data[tmdb] = {"t": time.time(), "seasons": routes}
    save_index(data)


def known_seasons(tmdb):
    """{temporada: ruta} apuntada de la serie; vacío si no hay o la forma no es la esperada"""
    try:
        raw = load_index()[tmdb]["seasons"]
        return {int(k): v for k, v in raw.items() if isinstance(v, str) and v and int(k) > 0}
    except (KeyError, TypeError, ValueError, AttributeError):
        return {}


def next_season_fast(tmdb, s):
    """(«TxE1», ruta, '') de la siguiente temporada (> s) listando SOLO su ruta apuntada: 1 consulta; None si no hay
    ruta apuntada, falla (ruta caducada) o viene vacía → el llamador sigue por el camino completo"""
    seasons = known_seasons(tmdb)          # el índice una vez (antes, dos json.load seguidos: revisión 29-oct DAT-08b)
    later = sorted(n for n in seasons if n > s)
    if not later:
        return None
    try:
        eps = list_dir(seasons[later[0]], ["season", "episode", "title"])
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_series] ruta de temporada apuntada: %s" % e, xbmc.LOGINFO)
        return None
    return first_of_season(eps, later[0], tmdb)


def first_of_season(eps, s2, tmdb=None):
    """(«TxE1», ruta, '') del primer capítulo de una lista de capítulos de la temporada s2; None si no hay"""
    files = [(x.get("episode"), x.get("file", "")) for x in eps if x.get("filetype") == "file"
             and isinstance(x.get("episode"), int) and x.get("episode") > 0]
    if not files:
        return None
    if tmdb:
        remember_eps("%s/%s" % (tmdb, s2), [x[0] for x in files])
    first = min(files)
    return "T%d E%d" % (s2, first[0]), first[1], ""


# ---------- «al día» ANTES del aviso (Carlos, 14-nov) ----------
# El aviso de «Seguir viendo» ofrecía reproducir y, al pulsarlo, decía «Al día: Palantir aún no tiene el capítulo
# siguiente»: la comprobación (next_available) va después de elegir para no llamar a Palantir antes del aviso. Lo que
# sí se puede mirar antes, sin llamarle, es su base de contenido: local, milisegundos. Solo se afirma «al día» en el
# caso claro (la temporada llega justo hasta el capítulo anterior y no hay nada después); en cualquier otro, o si la
# base no se puede leer, None y todo sigue como antes. Sin importar flix_direct (40-150 ms más al abrir cada serie):
# la ruta y los cerrojos son los suyos (test_al_dia_antes_del_aviso.py lo comprueba)
CONTENT_DB = "special://profile/addon_data/script.module/settings.xml"      # = flix_direct.content_db()
P3_LOCKS = ("p3UpdateLock", "p3get_moriaLock")                              # = los de flix_direct.busy()
UPTODATE = "Al día  ·  Palantir no tiene más capítulos por ahora"      # vale también para una serie acabada


def content_path():
    return xbmcvfs.translatePath(CONTENT_DB)


def catalog_next(tmdb, label):
    """¿tiene Palantir el capítulo `label` («T1 E104») en su base de contenido? True = sí; False = no, y tampoco nada
    posterior: su temporada acaba justo en el anterior y no hay temporadas siguientes (al día); None = no se sabe o no
    es ese caso (hueco en la numeración, temporada siguiente, serie o temporada que la base no tiene, base ocupada)"""
    m = re.match(r"T(\d+) E(\d+)$", label or "")
    if not m or not str(tmdb or "").isdigit():
        return None
    s, e = int(m.group(1)), int(m.group(2))
    try:
        if any(HOME.getProperty(k) == "true" for k in P3_LOCKS):
            return None                 # Palantir actualizando su contenido: no se le lee la base
        import sqlite3
        # la ruta como URI de solo lectura, sin urllib (no se carga para abrir una serie: test_click_imports.py)
        ruta = content_path().replace("%", "%25").replace("?", "%3f").replace("#", "%23")
        db = sqlite3.connect("file:%s?mode=ro" % ruta, uri=True, timeout=1)
        try:
            rows = db.execute("SELECT DISTINCT temporada, episodio FROM enlaces_series WHERE tmdb = ? AND "
                              "temporada >= ?", (int(tmdb), s)).fetchall()
        finally:
            db.close()
        here = {int(ep) for t, ep in rows if int(t) == s}
        if e in here:
            return True
        if not here or any(int(t) > s for t, _ in rows) or max(here) != e - 1:
            return None
        return False
    except Exception as ex:  # noqa: BLE001  (base cambiada, bloqueada o ilegible: como antes)
        xbmc.log("[flix_series] base de contenido sin leer: %s" % ex, xbmc.LOGINFO)
        return None


def uptodate_sub(tmdb, label, today=None):
    """la línea del aviso cuando Palantir no tiene el capítulo siguiente. Con su fecha de emisión si TMDB la tiene
    APUNTADA (flix_newep.cached_season: sin ir a la red antes del aviso): «Al día · T1 E104 · Sale el 21 nov»"""
    try:
        m = re.match(r"T(\d+) E(\d+)$", label or "")
        import flix_newep
        eps = flix_newep.cached_season(tmdb, int(m.group(1))) if m else None
        date = next((str(x.get("date") or "") for x in eps or [] if x.get("n") == int(m.group(2))), "")
        if date_es(date, today or today_str()):
            return "Al día  ·  %s  ·  %s" % (label, pending_label(date, today or today_str()))
    except Exception as ex:  # noqa: BLE001
        xbmc.log("[flix_series] fecha del capítulo siguiente: %s" % ex, xbmc.LOGINFO)
    return UPTODATE


def next_available(seasons, nxt, tmdb=None):
    """fix_next desde la ventana «Seguir viendo» (sin pantalla de temporadas): pide a Palantir los capítulos de la
    temporada de nxt (~2-4 s, con la rueda) solo si no están apuntados en EPS_INDEX (Black Clover: ~5 s de rueda
    antes de empezar cada capítulo, Carlos 25-oct). None = vale como está o no se pudo saber"""
    m = re.match(r"T(\d+) E(\d+)$", nxt or "")
    if not m:
        return None
    key = "%s/%s" % (tmdb, m.group(1)) if tmdb else ""
    if key and int(m.group(2)) in known_eps(key):
        xbmc.log("[flix_series] %s apuntado: sin preguntar a Palantir" % nxt, xbmc.LOGINFO)
        return None
    s, e = int(m.group(1)), int(m.group(2))
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        ended = False
        if tmdb:
            known = known_eps(key)
            if known and e > max(known):
                # la temporada s acaba antes de e (Slow Horses: T1 de 6 y «T1 E7»): no hace falta listarla. Con la
                # ruta de la siguiente apuntada, una sola consulta; con ruta caducada se sigue como antes
                fast = next_season_fast(tmdb, s)
                if fast:
                    return fast
                ended = not any(n > s for n in known_seasons(tmdb))     # había ruta y falló: camino completo
        items = list_dir(seasons, ["season", "episode", "title"])
        later = None
        if any(f.get("filetype") == "file" for f in items):
            eps = items                                 # una temporada: Palantir da los capítulos directamente
            ended = False
        else:
            if tmdb:
                remember_seasons(tmdb, items)
            if ended and any((season_number(f) or 0) > s for f in items):
                # hay temporada después: la s ya se sabe acabada, no se lista. Sin ella (Bleach: el 49 aún no está
                # en Palantir, que sigue añadiendo capítulos) sí se pregunta, como antes
                return next_season_first(items, s, tmdb) or ("", "", "T%d E%d" % (s, e - 1))
            season = next((f for f in items if number(f, "season", r"(\d+)") == s), None)
            eps = list_dir(season["file"], ["season", "episode", "title"]) if season else []
            later = items
    except Exception as ex:  # noqa: BLE001
        xbmc.log("[flix_series] capítulos para «Seguir viendo»: %s" % ex, xbmc.LOGINFO)
        return None
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    files = [(f.get("episode"), f.get("file", ""), f.get("label", "")) for f in eps if f.get("filetype") == "file"]
    remember_eps(key, [f[0] for f in files])
    fix = fix_next(nxt, "", files)
    if fix and fix[2] and later:
        # temporada acabada: next_episode solo suma 1 («T1 E7» con 6 en la T1) y Slow Horses (26-oct) daba «Al día»
        # teniendo T2; se pasa al 1.er capítulo de la siguiente temporada que no sea especial
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")      # la rueda sigue mientras lista la siguiente
        try:
            return next_season_first(later, s, tmdb) or fix
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    return fix


def next_season_first(items, s, tmdb=None):
    """(«TxE1», ruta, '') del primer capítulo de la siguiente temporada (> s, sin especiales) de la lista de
    temporadas items; None si no hay o no tiene capítulos (sigue siendo «al día»)"""
    nums = sorted((number(f, "season", r"(\d+)"), i, f) for i, f in enumerate(items)
                  if f.get("filetype") != "file" and not SPECIAL_RE.search(f.get("label") or "")
                  and (number(f, "season", r"(\d+)") or 0) > s)
    for s2, _, f in nums[:1]:
        try:
            eps = list_dir(f["file"], ["season", "episode", "title"])
        except Exception as e:  # noqa: BLE001
            xbmc.log("[flix_series] temporada siguiente: %s" % e, xbmc.LOGINFO)
            return None
        return first_of_season(eps, s2, tmdb)
    return None


def episodes_of(cid):
    """[(número, ruta, título)] de una lista de capítulos ya cargada"""
    out = []
    n = xbmc.getInfoLabel("Container(%d).NumItems" % cid)
    for i in range(int(n) if n.isdigit() else 0):
        e = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Episode" % (cid, i))
        if e.isdigit():
            out.append((int(e), xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FileNameAndPath" % (cid, i)),
                        xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, i))))
    return out


def apply_fix(fix):
    if not fix:
        return
    label, path, upto = fix
    xbmc.log("[flix_series] Palantir no tiene %s: %s" % (HOME.getProperty("flix_series_next"),
                                                         label or "al día hasta %s" % upto), xbmc.LOGINFO)
    if upto:
        HOME.clearProperty("flix_series_next")
        HOME.setProperty("flix_series_upto", upto)     # botón «Al día · TxEy»
    else:
        HOME.setProperty("flix_series_next", label)
        HOME.setProperty("flix_series_play_ep", path)   # ver(): ese capítulo, no el que elegiría Palantir


def ver():
    """botón de la pantalla de temporadas: «Seguir viendo · TxEy» = siguiente de Palantir; «Ver» (sin empezar) = T1 E1"""
    if HOME.getProperty("flix_series_upto"):
        xbmcgui.Dialog().notification(HOME.getProperty("flix_series_title") or "Serie",
                                      "Al día: Palantir aún no tiene el capítulo siguiente al %s" %
                                      HOME.getProperty("flix_series_upto"), xbmcgui.NOTIFICATION_INFO, 4000)
        return
    if HOME.getProperty("flix_series_play_ep"):
        import flix_play
        flix_play.start(HOME.getProperty("flix_series_play_ep"))
        return
    late = HOME.getProperty("flix_series_resume_at").partition("|")
    if late[0] and late[0] == HOME.getProperty("flix_series_next") and late[2].isdigit() and int(late[2]) > 0:
        # a medias sin que Palantir lo sepa (next_episode_info): se pone aquí en su minuto. Solo mientras siga siendo
        # el capítulo que toca (al ver algo, flix_series_next cambia y esto deja de valer)
        resume_episode(HOME.getProperty("flix_series_folder"), late[0], HOME.getProperty("flix_series_title"), int(late[2]))
        return
    if HOME.getProperty("flix_series_next"):
        import flix_play
        flix_play.resume_series(HOME.getProperty("flix_series_play"), HOME.getProperty("flix_open_fanart"))
    else:
        play_first(HOME.getProperty("flix_series_folder"), HOME.getProperty("flix_series_title"))


def loaded_ok(path):
    n = xbmc.getInfoLabel("Container.NumItems")
    return xbmc.getInfoLabel("Container.FolderPath") == path and n.isdigit() and int(n) > 0


def wait_loaded(path, timeout=90):
    """True si la ventana Vídeos acaba mostrando 'path'. False si Palantir falla: entonces Kodi deja a la vista la
    ÚLTIMA carpeta que tuvo esa ventana (p. ej. un "Especial Halloween" de antes) -> hay que detectarlo."""
    t0 = time.time()
    idle_since = None
    while time.time() - t0 < timeout:
        busy = xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Container.IsUpdating")
        if loaded_ok(path) and not busy:
            xbmc.sleep(600)                         # al fallar, Kodi pone un instante la ruta pedida y vuelve atrás
            if loaded_ok(path):
                return True
            continue
        if xbmc.getCondVisibility("Window.IsActive(videos)") and not busy and time.time() - t0 > 2:
            idle_since = idle_since or time.time()
            if time.time() - idle_since > 3:        # ventana quieta 3 s con otra carpeta = falló la carga
                return False
        else:
            idle_since = None
        if not xbmc.getCondVisibility("Window.IsActive(videos)") and time.time() - t0 > 5:
            return True                             # el usuario se fue: nada que vigilar
        xbmc.sleep(200)
    return False


def open_checked(seasons, title, tries=2):
    """Abre las temporadas tapando la carpeta vieja (MyVideoNav: flix_opening) y reintenta una vez si Palantir
    falla (p. ej. ocupado sincronizando Trakt)."""
    HOME.setProperty("flix_opening", "1")
    try:
        for attempt in range(1, tries + 1):
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % seasons)
            if wait_loaded(seasons):
                return True
            xbmc.log("[flix_series] Palantir no dio las temporadas de %s (intento %d)" % (title, attempt), xbmc.LOGINFO)
            if xbmc.getCondVisibility("Window.IsActive(videos)"):
                xbmc.executebuiltin("Action(Back)")     # fuera la carpeta vieja
                xbmc.sleep(800)
        xbmcgui.Dialog().notification(title, NO_ANSWER_RETRY,
                                      xbmcgui.NOTIFICATION_INFO, 5000)
        return False
    finally:
        HOME.clearProperty("flix_opening")


# ---------- capítulos que Palantir aún no tiene (Carlos, 7-nov) ----------
# Debajo de los capítulos de la temporada, en la MISMA lista, salen atenuados y sin reproducir los que TMDB cuenta y
# Palantir no da: «Sale el 14 nov» si aún no se ha emitido, «Aún no disponible · emitido el 5 nov» si ya salió. Los
# datos los trae flix_newep.season_episodes (caché de un día) y la ficha propia (flix_series_sheet.step_pending) los
# pone en Window(home).Property(flix_pend<i>_*): cada lista de capítulos lleva, además del <content> de Palantir, un
# 2.º <content> con PEND_SLOTS elementos fijos (FlixPendingItems; Kodi 21 junta los dos, CMultiProvider) que solo se
# ven en la lista flix_pend_list. Así es una sola lista: se baja de los de Palantir a los pendientes sin cambiar de
# control (Carlos, 7-nov: «que salgan debajo de los otros», no como sección aparte). addItems a una lista con
# <content> no vale: Kodi los descarta al fotograma siguiente. ListItem.Property(flix_pending) = la frase: el XML
# atenúa la fila, no enseña barra ni ✓ y el clic solo avisa; sin Episode (episodes_of/remember_eps no los cuentan)
PENDING = "flix_pending"
PEND_SLOTS = 20         # elementos fijos por lista (FlixPendingItems, TV y táctil): más allá no se enseñan
PEND_FIELDS = ("label", "thumb", "when", "plot")
MONTHS = ("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")
PENDING_FUTURE = "Sale el %s"
PENDING_TODAY = "Aún no disponible  ·  sale hoy"
PENDING_AIRED = "Aún no disponible  ·  emitido el %s"
PENDING_NODATE = "Aún no ha salido  ·  sin fecha"


def today_str():
    return time.strftime("%Y-%m-%d")


def date_es(d, today):
    """«14 nov» (este año) o «14 nov 2027» (otro); '' si la fecha no es AAAA-MM-DD"""
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", d or "")
    if not m or not 1 <= int(m.group(2)) <= 12:
        return ""
    y, mo, da = m.group(1), MONTHS[int(m.group(2)) - 1], int(m.group(3))
    return "%d %s" % (da, mo) if y == (today or "")[:4] else "%d %s %s" % (da, mo, y)


def pending_label(date, today):
    """la frase del capítulo que Palantir no tiene, según su fecha de emisión (TMDB) frente a hoy"""
    d = date_es(date, today)
    if not d:
        return PENDING_NODATE
    if date > today:
        return PENDING_FUTURE % d
    if date == today:
        return PENDING_TODAY
    return PENDING_AIRED % d


def pending_episodes(tmdb_eps, have):
    """los de TMDB (flix_newep.parse_season) cuyo número no está entre los que tiene Palantir (have), por número"""
    have = {int(n) for n in have or () if str(n).isdigit() or isinstance(n, int)}
    return sorted((e for e in tmdb_eps or [] if isinstance(e.get("n"), int) and e["n"] not in have),
                  key=lambda e: e["n"])


def pending_rows(tmdb_eps, have, season, today=None, thumb=""):
    """[{label, plot, thumb, pending}] para la lista: etiqueta «2x09 Título» como la de Palantir (sin [COLOR]); la
    miniatura de TMDB o, sin ella (los futuros no tienen), la que se pase (el fanart de la serie, atenuado por el XML)"""
    today = today or today_str()
    out = []
    for e in pending_episodes(tmdb_eps, have):
        name = (e.get("name") or "").strip()
        out.append({"label": ("%sx%02d %s" % (season, e["n"], name)).strip(),
                    "plot": e.get("plot") or "",
                    "thumb": e.get("still") or thumb or "",
                    "pending": pending_label(e.get("date") or "", today)})
    return out


def pending_source(path, first_season=""):
    """(tmdb, temporada) de la lista de capítulos a la vista desde la ruta de su temporada (o la de la serie, en las de
    una temporada: la temporada es la del 1.er capítulo o la 1). ('', '') si no se sabe o Palantir numera a su manera
    (own_numbering: los datos de TMDB son de otra temporada)"""
    meta = route_meta(path)
    tmdb = meta.get("tmdb", "")
    if not tmdb or own_numbering(meta):
        return "", ""
    s = meta.get("season")
    if s is None:
        s = int(first_season) if str(first_season).isdigit() else 1
    return tmdb, str(s)


def pending_props(rows, cid, real):
    """{propiedad: valor} de Window(home) para los pendientes de la lista cid (pending_rows), hasta PEND_SLOTS; las de
    los huecos que sobran, vacías (ocultan el elemento). flix_pend_n / flix_pend_real: recuento para la cabecera"""
    out = {}
    rows = rows[:PEND_SLOTS]
    for i in range(PEND_SLOTS):
        r = rows[i] if i < len(rows) else None
        out["flix_pend%d_label" % i] = r["label"] if r else ""
        out["flix_pend%d_thumb" % i] = r["thumb"] if r else ""
        out["flix_pend%d_when" % i] = r["pending"] if r else ""
        out["flix_pend%d_plot" % i] = r["plot"] if r else ""
    out["flix_pend_list"] = str(cid) if rows else ""
    out["flix_pend_n"] = str(len(rows)) if rows else ""
    out["flix_pend_real"] = str(real) if rows else ""
    return out


def clear_pending_props():
    apply(pending_props([], 0, 0))


# al final: main() usa funciones de todo el fichero (clear_eps -> clear_pending_props)
if __name__ == "__main__":
    if sys.argv[1:2] == ["ver"]:
        ver()
    else:
        main()
