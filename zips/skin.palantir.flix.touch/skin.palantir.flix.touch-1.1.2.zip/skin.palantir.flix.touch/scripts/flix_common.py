"""Piezas comunes a los scripts del skin (sin xbmc: se prueban fuera de Kodi). Antes había 5 copias de COLOR_RE,
3 de decode_route y 2 de encode_route (auditoría PY-12)."""
import base64
import math
import os
import re
import tempfile

PLUGIN_ROOT = "plugin://plugin.video.palantir3/"
# etiquetas de formato de Kodi que Palantir mete en títulos y menús
COLOR_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)[^\]]*\]")


def clean(label):
    return COLOR_RE.sub("", label or "").strip()


def decode_route(url):
    """JSON (como texto) de una ruta de Palantir: base64 invertido y rotado ceil(len/4)."""
    blob = url.split("?", 1)[-1].split("&", 1)[0]
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    return base64.b64decode(b64).decode("utf-8", "replace")


def encode_route(text):
    rb = base64.b64encode(text.encode()).decode().rstrip("=")[::-1]
    n = len(rb)
    k = math.ceil(n / 4)
    return PLUGIN_ROOT + "?" + rb[n - k:] + rb[:n - k]


def atomic_write(path, text):
    """escribe en un temporal único del mismo directorio y lo cambia de golpe por el fichero"""
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + ".", suffix=".tmp", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
