"""Apunta en kodi.log cuándo abre Palantir el aviso de siguiente capítulo (onload de Custom_1111_Overlay.xml):
cuánto faltaba para el final del capítulo. Uso: RunScript(special://skin/scripts/flix_log.py,upnext)"""
import sys

import xbmc

what = sys.argv[1] if len(sys.argv) > 1 else "?"
info = {k: xbmc.getInfoLabel(k) for k in ("Player.Title", "Player.Time", "Player.Duration", "Player.TimeRemaining",
                                           "VideoPlayer.TVShowTitle", "VideoPlayer.Season", "VideoPlayer.Episode")}
xbmc.log("[flix_log] %s %s" % (what, info), xbmc.LOGINFO)
