"""Barra de reproducción ARRASTRABLE (OSD táctil).

El slider de Kodi no atiende arrastres táctiles (solo toques); la scrollbar sí (GESTURE_PAN mueve el
tirador bajo el dedo). VideoOSD.xml tiene una scrollbar (8801) ligada a una lista oculta (8800) de
1001 posiciones (0..1000 = por mil de la duración). Este script, mientras el OSD está abierto:
  - si el usuario no toca: coloca la lista en la posición de reproducción (Control.Move)
  - si la posición cambia sin que la haya movido el script = el dedo está arrastrando: publica
    Window(home).Property(ft_scrub_time) con el tiempo de destino
  - cuando deja de moverse 0,5 s: salta ahí (Player.seekTime) y vuelve a sincronizar.
"""
import time
import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
STEPS = 1000


def fmt(sec):
    sec = max(0, int(sec))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def page():
    try:
        return int(xbmc.getInfoLabel("Container(8800).CurrentPage")) - 1
    except ValueError:
        return None


def main():
    if HOME.getProperty("ft_scrub_running") == "1":
        return
    HOME.setProperty("ft_scrub_running", "1")
    mon, player = xbmc.Monitor(), xbmc.Player()
    last_set, dragging, last_change, hold_until = None, False, 0.0, 0.0
    try:
        while not mon.abortRequested() and xbmc.getCondVisibility("Window.IsVisible(videoosd)") and player.isPlaying():
            p = page()
            dur = player.getTotalTime() or 0
            if p is None or dur <= 0:
                mon.waitForAbort(0.1)
                continue
            now = time.time()
            if not dragging and last_set is not None and abs(p - last_set) > 1 and now > hold_until:
                dragging, last_change = True, now
                HOME.setProperty("ft_scrubbing", "1")
            if dragging:
                if p != last_set:
                    last_set, last_change = p, now
                    HOME.setProperty("ft_scrub_time", fmt(p * dur / STEPS))
                elif now - last_change > 0.5:
                    player.seekTime(p * dur / STEPS)
                    dragging, hold_until = False, now + 1.5
                    HOME.clearProperty("ft_scrubbing")
            elif now > hold_until:
                want = int(round(player.getTime() / dur * STEPS))
                if p != want:
                    xbmc.executebuiltin("Control.Move(8800,%d)" % (want - p))
                    hold_until = now + 0.4  # el movimiento es asíncrono: no confundirlo con el dedo
                last_set = want
            mon.waitForAbort(0.1)
    finally:
        HOME.clearProperty("ft_scrubbing")
        HOME.clearProperty("ft_scrub_time")
        HOME.clearProperty("ft_scrub_running")


if __name__ == "__main__":
    main()
