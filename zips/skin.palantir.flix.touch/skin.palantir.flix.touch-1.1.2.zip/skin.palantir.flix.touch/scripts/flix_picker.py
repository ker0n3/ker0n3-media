"""Lista para elegir una opción con el estilo Flix (ventana FlixPicker.xml, TV y táctil).

pick(título, [etiquetas], ayuda, posición inicial) -> índice elegido, o -1 con Atrás.
No usa Dialog().select: en esta skin DialogSelect.xml está rediseñado para el selector de versiones de Palantir.
"""
import xbmc
import xbmcgui
import xbmcvfs

LIST = 100
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)


class PickerWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = kwargs.get("title", "")
        self.labels = kwargs.get("labels", [])
        self.help = kwargs.get("help", "")
        self.select = kwargs.get("select", 0)
        self.choice = -1

    def onInit(self):
        self.setProperty("title", self.title)
        self.setProperty("help", self.help)
        lst = self.getControl(LIST)
        lst.reset()
        lst.addItems([xbmcgui.ListItem(lab) for lab in self.labels])
        if 0 < self.select < len(self.labels):
            lst.selectItem(self.select)
        self.setFocusId(LIST)

    def onClick(self, cid):
        if cid == LIST:
            self.choice = self.getControl(LIST).getSelectedPosition()
            self.close()

    def onAction(self, action):
        if action.getId() in A_BACK:
            self.choice = -1
            self.close()
            return
        super().onAction(action)


def pick(title, labels, help_text="", select=0):
    if not labels:
        return -1
    win = PickerWindow("FlixPicker.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                       title=title, labels=labels, help=help_text, select=select)
    win.doModal()
    choice = win.choice
    del win
    return choice


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")
