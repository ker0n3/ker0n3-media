"""Qué secciones salen en el menú lateral (TV, Home.xml lista 9000) y en las tarjetas de arriba (táctil, flix_home.py).
Cada aparato guarda lo suyo en Skin.Bool(flix_hide_<clave>). Inicio no se puede ocultar.
Uso: RunScript(special://skin/scripts/flix_sections.py)  -> editor (Ajustes de Flix, ventana FlixSections.xml):
una fila por sección con un interruptor; OK / toque lo cambia en el sitio, sin cerrar la ventana."""
import os
import sys

SECTIONS = [("peliculas", "Películas"), ("series", "Series"), ("anime", "Anime"), ("dibujos", "Dibujos"),
            ("documentales", "Documentales"), ("trakt", "Trakt"), ("favoritos", "Favoritos")]
_KEY = {label: key for key, label in SECTIONS}


def setting(key):
    return "flix_hide_%s" % key


def key_of(label):
    return _KEY.get(label)


def visible(items, hidden):
    """items con "label" (tarjetas de la táctil) sin las secciones ocultas, en el mismo orden"""
    return [it for it in items if key_of(it.get("label")) not in hidden]


def available(chip_labels):
    """secciones que se pueden elegir: todas en la TV (chip_labels None); en la táctil solo las que tienen tarjeta"""
    return [s for s in SECTIONS if chip_labels is None or s[1] in chip_labels]


def toggle_rows(hidden, sections=SECTIONS):
    """[(etiqueta, se_muestra)] en el orden del menú"""
    return [(label, key not in hidden) for key, label in sections]


def chip_labels():
    import json
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flix_home_chips.json")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return [c["label"] for c in json.load(fh)]


def hidden_now():
    import xbmc
    return {key for key, _ in SECTIONS if xbmc.getCondVisibility("Skin.HasSetting(%s)" % setting(key))}


def chips_props():
    """táctil: rellena Window(home).Property(flix_chipN) con las secciones visibles (las pinta FlixHome.xml).
    En la TV no hay tarjetas (no existe flix_home_chips.json) y no hace nada."""
    import json
    import xbmcgui
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flix_home_chips.json")
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        chips = json.load(fh)
    shown = visible(chips, hidden_now())
    home = xbmcgui.Window(10000)
    for i in range(1, len(chips) + 1):
        home.setProperty("flix_chip%d" % i, shown[i - 1]["label"] if i <= len(shown) else "")
    return shown


def edit():
    import xbmc
    import xbmcgui
    import xbmcvfs

    sections = available(chip_labels())

    class SectionsWindow(xbmcgui.WindowXMLDialog):
        def onInit(self):
            lst = self.getControl(100)
            lst.reset()
            for label, shown in toggle_rows(hidden_now(), sections):
                li = xbmcgui.ListItem(label)
                li.setProperty("on", "1" if shown else "")
                lst.addItem(li)
            self.setFocusId(100)

        def onClick(self, cid):
            if cid != 100:
                return
            lst = self.getControl(100)
            i = lst.getSelectedPosition()
            if not 0 <= i < len(sections):
                return
            xbmc.executebuiltin("Skin.ToggleSetting(%s)" % setting(sections[i][0]))
            li = lst.getListItem(i)
            li.setProperty("on", "" if li.getProperty("on") else "1")   # en el sitio: la bolita se desliza

        def onAction(self, action):
            if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
                self.close()
                return
            super().onAction(action)

    win = SectionsWindow("FlixSections.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    win.doModal()
    del win
    xbmc.sleep(100)                              # que Kodi aplique el último cambio antes de repintar las tarjetas
    chips_props()


if __name__ == "__main__":
    edit()
