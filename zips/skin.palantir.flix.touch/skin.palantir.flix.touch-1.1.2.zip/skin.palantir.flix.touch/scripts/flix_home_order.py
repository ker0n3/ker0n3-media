"""Filas del Inicio (versión TV y táctil): orden, ocultar, eliminar, añadir y elementos por fila.

RunScript(special://skin/scripts/flix_home_order.py,edit)   -> editor (ventana FlixHomeOrder.xml)
RunScript(special://skin/scripts/flix_home_order.py,check)  -> al arrancar: reaplica la configuración si una
                                                               actualización del skin trajo Home.xml de serie
Configuración en special://profile/addon_data/<skin>/home_order.json; formato y reglas en flix_home_conf.py
(lógica pura, con tests en tools/tests).

TV: las filas son includes FlixRow en xml/Home.xml (entre FLIX_ROWS_BEGIN y FLIX_ROWS_END) + variables de carga
diferida en xml/Includes_FlixRows.xml. Este script reescribe los dos (flix_home_conf.render_tv) y recarga el skin.
La copia de serie del trozo de filas se guarda en addon_data (home_rows_default.xml) para restaurar filas.
Táctil: flix_home.py lee la misma configuración y monta sus filas al cargar.
"""
import json
import os
import re
import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_home_conf as hc  # noqa: E402

HOME = xbmcgui.Window(10000)
SKIN_ID = xbmc.getSkinDir()
TOUCH = SKIN_ID.endswith(".touch")
SKIN = xbmcvfs.translatePath("special://skin/")
DATA = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
CONF = os.path.join(DATA, "home_order.json")
DEFAULT_ROWS = os.path.join(DATA, "home_rows_default.xml")
HOME_XML = os.path.join(SKIN, "xml", "Home.xml")
INC_XML = os.path.join(SKIN, "xml", "Includes_FlixRows.xml")
BEGIN, END = "<!-- FLIX_ROWS_BEGIN", "<!-- FLIX_ROWS_END -->"
SIG_RE = re.compile(r"[ \t]*<!-- FLIX_ORDER_SIG ([^ ]*) -->\n?")


def log(msg):
    xbmc.log("[flix_home_order] %s" % msg, xbmc.LOGINFO)


def atomic_write(path, text):
    tmp = "%s.tmp%d" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def load_conf():
    """configuración normalizada, o None si el usuario nunca la ha guardado"""
    try:
        with open(CONF, encoding="utf-8") as fh:
            return hc.normalize(json.load(fh))
    except (OSError, ValueError):
        return None


def save_conf(conf):
    os.makedirs(DATA, exist_ok=True)
    atomic_write(CONF, json.dumps(hc.normalize(conf)))


def ordered(rows, conf):
    """compatibilidad: rows = [(id, label, …)] -> en el orden guardado (las nuevas al final)"""
    if not conf:
        return list(rows)
    pos = {i: k for k, i in enumerate(conf["order"])}
    return sorted(rows, key=lambda r: pos.get(r[0], 1000 + rows.index(r)))


# ---------- TV: Home.xml ----------
def _region(text):
    a = text.index("-->", text.index(BEGIN)) + 4    # tras el comentario de la marca (ocupa 2 líneas)
    b = text.index(END)
    b = text.rindex("\n", 0, b) + 1
    return a, b


def tv_default_blocks():
    """filas de serie [{id, label, path, src, top10, extra}] en su orden"""
    with open(HOME_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    region = text[a:b]
    if not SIG_RE.search(region) or not os.path.exists(DEFAULT_ROWS):
        # Home.xml de serie (instalación o actualización): su trozo de filas es el nuevo "de serie"
        os.makedirs(DATA, exist_ok=True)
        atomic_write(DEFAULT_ROWS, SIG_RE.sub("", region))
    with open(DEFAULT_ROWS, encoding="utf-8") as fh:
        return hc.parse_tv_blocks(fh.read())


def tv_apply(conf):
    conf = hc.normalize(conf)
    rows = hc.compose(tv_default_blocks(), conf)
    if not any(not r["hidden"] for r in rows):
        return False
    region, inc = hc.render_tv(rows, conf["items"])
    with open(HOME_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    atomic_write(INC_XML, inc)
    atomic_write(HOME_XML, text[:a] + "\t\t\t\t<!-- FLIX_ORDER_SIG %s -->\n" % hc.signature(conf) + region + text[b:])
    log("Home.xml reescrito: %s (elementos %d)" % ([r["id"] for r in rows if not r["hidden"]], conf["items"]))
    return True


def tv_current_sig():
    with open(HOME_XML, encoding="utf-8") as fh:
        m = SIG_RE.search(fh.read())
    return m.group(1) if m else None


# ---------- táctil ----------
def touch_default_rows():
    with open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8") as fh:
        return json.load(fh)


def default_rows():
    """filas de serie como dicts con al menos id y label"""
    return touch_default_rows() if TOUCH else tv_default_blocks()


# ---------- arranque ----------
def check():
    """Startup (sin configuración guardada no hace nada) y Home "de fábrica" (onload del Includes_FlixRows.xml del
    zip): aplica la configuración, o la de serie, para que el Inicio quede escrito y la orden de fábrica desaparezca"""
    if TOUCH:
        return
    conf = load_conf()
    factory = False
    try:
        with open(INC_XML, encoding="utf-8") as fh:
            factory = "flix_home_order.py,check" in fh.read()
    except OSError:
        pass
    if not conf and not factory:
        return
    conf = conf or hc.normalize(None)
    try:
        if (factory or tv_current_sig() != hc.signature(conf)) and tv_apply(conf):
            xbmc.executebuiltin("ReloadSkin()")
    except Exception as e:  # noqa: BLE001
        log("check: %s" % e)


# ---------- editor ----------
LIST = 100
B_UP, B_DOWN, B_TOGGLE, B_SAVE, B_RESET, B_CANCEL, B_DELETE, B_ADD, B_ITEMS = 201, 202, 203, 204, 205, 206, 207, 208, 209
A_UP, A_DOWN, A_CONTEXT = 3, 4, (101, 117)
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)
EXPLORE = "Explorar Palantir…"


def notify(msg):
    xbmcgui.Dialog().notification("Inicio", msg, xbmcgui.NOTIFICATION_INFO, 2500)


class OrderWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.defaults = default_rows()
        conf = load_conf() or hc.normalize(None)
        self.rows = hc.compose(self.defaults, conf)
        self.items = conf["items"]
        self.initial = hc.signature(self.conf())
        self.picked = False
        self.pick_pos = -1
        self.saved = False

    # estado <-> configuración
    def conf(self):
        present = {r["id"] for r in self.rows}
        return hc.normalize({
            "order": [r["id"] for r in self.rows],
            "hidden": [r["id"] for r in self.rows if r["hidden"]],
            "deleted": [d["id"] for d in self.defaults if d["id"] not in present],
            "custom": [{"id": r["id"], "label": r["label"], "path": r["path"]} for r in self.rows if r["custom"]],
            "items": self.items,
        })

    def dirty(self):
        return hc.signature(self.conf()) != self.initial

    def onInit(self):
        self.lst = self.getControl(LIST)
        self.refill(0)
        self.setFocusId(LIST)

    def refill(self, sel):
        self.lst.reset()
        for r in self.rows:
            li = xbmcgui.ListItem(r["label"])
            li.setProperty("hidden", "1" if r["hidden"] else "")
            li.setProperty("custom", "1" if r["custom"] else "")
            self.lst.addItem(li)
        self.lst.selectItem(max(0, min(sel, len(self.rows) - 1)))
        self.setProperty("items_label", "Elementos por fila: %d" % self.items)
        self.setProperty("count_label", "%d de %d filas" % (len(self.rows), hc.MAX_ROWS))
        self.mark()

    def mark(self):
        self.setProperty("picked", "1" if self.picked else "")

    def sel(self):
        return self.lst.getSelectedPosition()

    def move(self, step):
        k = self.sel()
        j = k + step
        if 0 <= k < len(self.rows) and 0 <= j < len(self.rows):
            self.rows[k], self.rows[j] = self.rows[j], self.rows[k]
            self.refill(j)

    def visible_count(self):
        return len([r for r in self.rows if not r["hidden"]])

    def toggle(self):
        k = self.sel()
        if 0 <= k < len(self.rows):
            r = self.rows[k]
            if not r["hidden"] and self.visible_count() == 1:
                notify("Tiene que quedar al menos una fila visible")
                return
            r["hidden"] = not r["hidden"]
            self.refill(k)

    def delete(self):
        k = self.sel()
        if not 0 <= k < len(self.rows):
            return
        r = self.rows[k]
        if not r["hidden"] and self.visible_count() == 1:
            notify("Tiene que quedar al menos una fila visible")
            return
        if not xbmcgui.Dialog().yesno("Eliminar fila", "¿Quitar «%s» del Inicio?[CR]Podrás volver a añadirla con «Añadir fila»." % r["label"]):
            return
        del self.rows[k]
        self.refill(k)

    def add(self):
        if len(self.rows) >= hc.MAX_ROWS:
            notify("Máximo %d filas: elimina alguna para añadir otra" % hc.MAX_ROWS)
            return
        present = {r["id"] for r in self.rows}
        missing = [d for d in self.defaults if d["id"] not in present]
        import flix_picker
        k = flix_picker.pick("Añadir fila", [d["label"] for d in missing] + [EXPLORE],
                             "Filas de serie que no están en el Inicio, o cualquier menú de Palantir.")
        if k < 0:
            return
        if k < len(missing):
            new = dict(missing[k], custom=False, hidden=False)
        else:
            import flix_palantir_browse
            got = flix_palantir_browse.browse()
            if not got:
                return
            label, path = got
            used = {r["id"] for r in self.rows if r["custom"]}
            free = [i for i in hc.CUSTOM_IDS if i not in used]
            new = {"id": free[0], "label": label, "path": path, "custom": True, "hidden": False, "top10": False}
        at = max(0, self.sel()) + 1
        self.rows.insert(at, new)
        self.refill(at)
        notify("«%s» añadida" % new["label"])

    def cycle_items(self):
        self.items = hc.next_items(self.items)
        self.refill(self.sel())

    def leave(self):
        if self.dirty() and not xbmcgui.Dialog().yesno("Personalizar el Inicio", "¿Salir sin guardar los cambios?"):
            return
        self.close()

    def onAction(self, action):
        aid = action.getId()
        if self.getFocusId() == LIST and self.picked and aid in (A_UP, A_DOWN):
            # Kodi ya ha movido la selección de la lista: la fila cogida va a la nueva posición
            new, old = self.sel(), self.pick_pos
            if 0 <= old < len(self.rows) and new != old:
                self.rows.insert(new, self.rows.pop(old))
                self.pick_pos = new
                self.refill(new)
            return
        if self.getFocusId() == LIST and aid in A_CONTEXT:
            self.toggle()                                # mantener OK: mostrar / ocultar
            return
        if aid in A_BACK:
            if self.picked:
                self.picked = False
                self.mark()
                return
            self.leave()
            return
        super().onAction(action)

    def onClick(self, cid):
        if cid == LIST:
            if TOUCH:
                return                                   # táctil: tocar = seleccionar; botones al lado
            self.picked = not self.picked                # OK: coger / soltar la fila
            self.pick_pos = self.sel()
            self.mark()
        elif cid == B_UP:
            self.move(-1)
        elif cid == B_DOWN:
            self.move(1)
        elif cid == B_TOGGLE:
            self.toggle()
        elif cid == B_DELETE:
            self.delete()
        elif cid == B_ADD:
            self.add()
        elif cid == B_ITEMS:
            self.cycle_items()
        elif cid == B_RESET:
            self.rows = hc.compose(self.defaults, hc.normalize(None))
            self.items = hc.DEFAULT_ITEMS
            self.refill(0)
        elif cid == B_SAVE:
            save_conf(self.conf())
            self.saved = True
            self.close()
        elif cid == B_CANCEL:
            self.leave()


def edit():
    win = OrderWindow("FlixHomeOrder.xml", SKIN, "Default", "1080i")
    win.doModal()
    saved = win.saved
    del win
    if not saved:
        return
    if TOUCH:
        HOME.setProperty("fh_reorder", "1")             # flix_home.py lo aplica al momento (lo mira cada segundo)
        notify("Cambios aplicados")
        return
    conf = load_conf()
    if conf and tv_apply(conf):
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ReloadSkin()")


if __name__ == "__main__":
    (check if len(sys.argv) > 1 and sys.argv[1] == "check" else edit)()
