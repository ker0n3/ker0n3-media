"""Ajustes de Palantir que la skin necesita para verse bien; first_run.py los aplica en cada arranque.
conColor=false: Palantir no mete [COLOR] en etiquetas ni títulos. Con su valor de serie (true) los títulos de
capítulo salían amarillos y Kodi no deja quitar ese color desde la skin (móvil Carlos, 18-oct-2026)."""
PALANTIR = "plugin.video.palantir3"
PREFS = {"conColor": "false"}


def apply(addon):
    """addon = xbmcaddon.Addon(PALANTIR). Devuelve las claves cambiadas."""
    changed = []
    for k, v in PREFS.items():
        if addon.getSetting(k) != v:
            addon.setSetting(k, v)
            changed.append(k)
    return changed


def main():
    import xbmc
    import xbmcaddon
    try:
        changed = apply(xbmcaddon.Addon(PALANTIR))
    except Exception as e:  # noqa: BLE001  (Palantir no instalado / desactivado)
        xbmc.log("[flix_palantir_prefs] %s" % e, xbmc.LOGWARNING)
        return
    if changed:
        xbmc.log("[flix_palantir_prefs] ajustes de Palantir: %s" % ", ".join("%s=%s" % (k, PREFS[k]) for k in changed), xbmc.LOGINFO)
