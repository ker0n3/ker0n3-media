"""Construcción segura de builtins de Kodi. En los parámetros, una coma o un paréntesis sin comillas parte el valor
(«Love, Death & Robots» se guardaba como «Love»). Entre comillas, Kodi (CUtil::SplitParams) acepta \\" y \\\\."""


def quote(value):
    return '"%s"' % str(value).replace("\\", "\\\\").replace('"', '\\"')


def set_string(name, value):
    return "Skin.SetString(%s,%s)" % (name, quote(value) if value else "")
