"""Utilidades de caché sin Kodi (para poder probarlas con pytest): claves, frescura, limpieza, comparación de
listados y escritura atómica con temporal único (dos procesos a la vez no pueden dejar un JSON mezclado:
auditoría PY-NUEVO-01).
"""
import os
import re
import tempfile
import time

DAY = 86400


def key_of(path, keep_headers=False):
    """clave de caché de una ruta: sin el parámetro &reload= (cambia en cada sesión)"""
    return re.sub(r"&reload=[^&]*", "", path) + ("#h" if keep_headers else "")


def is_fresh(entry, now=None, ttl=1800):
    """entry = [marca de tiempo, items]"""
    if not entry:
        return False
    now = time.time() if now is None else now
    try:
        return now - float(entry[0]) < ttl
    except (TypeError, ValueError, IndexError):
        return False


def purge(cache, now=None, max_age=DAY):
    """quita del dict las entradas de más de max_age (o rotas); devuelve cuántas quitó"""
    now = time.time() if now is None else now
    old = []
    for k, v in cache.items():
        try:
            if now - float(v[0]) > max_age:
                old.append(k)
        except (TypeError, ValueError, IndexError, KeyError):
            old.append(k)
    for k in old:
        del cache[k]
    return len(old)


def same_items(a, b):
    """mismos títulos en el mismo orden (por ruta): si es así no hace falta repintar la fila"""
    return [f.get("file") for f in a or []] == [f.get("file") for f in b or []]


def atomic_write(path, text):
    """escribe en un temporal único del mismo directorio y lo cambia de golpe por el fichero"""
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + ".", suffix=".tmp", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
