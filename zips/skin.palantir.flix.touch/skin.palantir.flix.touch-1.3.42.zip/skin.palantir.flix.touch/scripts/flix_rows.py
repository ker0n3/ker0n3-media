"""Filas de las secciones y del Inicio (compartido TV / táctil): menú de cada sección y caché de filas.

section_rows(var) da las filas de una sección: su menú propio (flix_sections_own, por su variable own:…) o, si es
una carpeta del NAS / USB («Otros orígenes»), una fila por subcarpeta:
  kind "list" = listado de títulos -> fila de carátulas
  kind "coll" = tarjetas (sagas, géneros, años; carpetas) -> al pulsar una se abre su lista
Las filas son rutas del addon Ker0n3 (lista/<clave>, tarjetas/<grupo>, seguir, siguiendo, favoritos…); las listas
de TMDB de la configuración (flix://tmdb/<clave>) son la ruta lista/<clave> del addon (k3_route).
fetch() cachea en disco (CACHE_TTL / STATIC_TTL); peek() da lo guardado aunque esté caducado (las secciones lo
enseñan al momento y refrescan por detrás). Con save=False fetch() no escribe el fichero: el que llama hace flush()
cada pocas filas. flush() quita lo de más de un día y escribe de forma atómica.
"""
import json
import os
import re
import time
import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import COLOR_RE, clean, is_fs, list_dir  # noqa: E402,F401
import flix_cache  # noqa: E402

# tarjeta de una fila que aún no ha llegado / que no dio nada: la misma en la Sección de TV (flix_section) y en el
# Inicio y las secciones táctiles (flix_home; revisión 29-oct TCT-08)
LOADING, MISSING = "Cargando…", "No disponible"

CACHE_TTL = 1800            # filas personales (Seguir viendo, Series en seguimiento…): cambian al ver algo
STATIC_TTL = 6 * 3600       # las demás (Top 10, novedades, plataformas, géneros…): como mucho cambian a diario.
# cuánto se guarda una fila aunque esté caducada: se enseña al momento y se refresca por detrás. Era 1 día y con el
# Inicio «Aleatoria» (listas de TMDB) ya nadie refrescaba las filas de las secciones: entrar en Películas o Anime tras
# un día salía todo en «Cargando…» (Carlos, 24-oct). Son siempre las mismas rutas (se reemplazan, no se acumulan).
# Las listas de TMDB pesan mucho (5 de 8 MB en la Fire TV) y se sortean en cada arranque: siguen en 1 día
KEEP = 7 * 86400
KEEP_TMDB = 86400
TMDB_LIST = "flix://tmdb/"     # filas con listas de TMDB de la configuración (flix_tmdblists.py): lista/<clave> del addon
# filas de tarjetas de las secciones propias (sagas, géneros, años): ruta tarjetas/<grupo> del addon (= flix_sections_own.CARDS)
CARDS = "plugin://plugin.video.ker0n3/tarjetas/"
FAV_RE = re.compile(r"favorit", re.I)       # filas de favoritos (ruta favoritos/… del addon)


def ttl_of(path):
    """caducidad de la caché de una fila: las listas y las tarjetas del addon (el addon avisa si cambian), STATIC_TTL;
    lo demás (favoritos, seguir, siguiendo, otros orígenes), personal: CACHE_TTL"""
    return STATIC_TTL if str(path or "").startswith((TMDB_LIST, CARDS, K3_LIST)) else CACHE_TTL


# «2»: caché de la 1.4.52/1.0.71 en adelante; la vieja (rows_cache.json) la borra first_run al arrancar
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache2.json" % xbmc.getSkinDir())
PROPS = ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file", "plot", "duration"]


def log(msg):
    xbmc.log("[flix_rows] %s" % msg, xbmc.LOGINFO)


HOME = xbmcgui.Window(10000)
_cache = None
_dirty = set()      # claves que este proceso ha pedido y aún no ha guardado
# Lo que este proceso dejó en el fichero en su último guardado con más guardados detrás (flush(keep=True)), para no
# volver a leerlo entero si nadie lo ha cambiado (revisión 29-oct DAT-02; json.load de 33-126 ms con 8 MB y la Shield
# ya tiene 10 MB). {clave: (marca, texto JSON de la entrada)}: texto y no los objetos, porque _progress corrige en
# sitio las filas que se enseñan y el fichero tiene que salir igual, byte a byte, que releyéndolo.
_saved = None
_saved_sig = None   # huella del fichero justo después de ese guardado: (ruta, inodo, mtime en ns, tamaño)


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _file_sig():
    try:
        st = os.stat(CACHE_FILE)
    except OSError:
        return None
    return (CACHE_FILE, st.st_ino, st.st_mtime_ns, st.st_size)


def _sig_ok(before, after, nbytes):
    """¿la huella de después de escribir sirve para saber, la próxima vez, que nadie ha tocado el fichero? Todos los
    que escriben rows_cache2.json (flix_rows, expire, flix_progress.fix_rows_cache) lo hacen con el cerrojo y de forma
    atómica (fichero nuevo = inodo nuevo). Ante cualquier duda, no: el siguiente guardado lee el fichero como siempre.
      - tenía que haber fichero antes y el inodo tiene que haber cambiado (si no, el sistema no da inodos de verdad);
      - la hora tiene que tener fracción de segundo (por segundos, dos escrituras seguidas no se distinguirían);
      - el tamaño tiene que ser el de lo que acabamos de escribir."""
    return bool(before and after) and after[0] == before[0] and after[1] != before[1] and \
        after[2] % 1000000000 != 0 and after[3] == nbytes


def _dumps(parts):
    """json.dumps de un dict a partir de {clave: (marca, texto JSON de la entrada)}: el mismo texto, byte a byte
    (separadores ', ' y ': ' por defecto; claves y valores con el mismo codificador). Un solo join: ~10 MB se copian
    una vez"""
    out = ["{"]
    for k, (_s, t) in parts.items():
        out += (json.dumps(k), ": ", t, ", ")
    if len(out) > 1:
        out[-1] = "}"
    else:
        out.append("}")
    return "".join(out)


def _forget():
    global _saved, _saved_sig
    _saved = _saved_sig = None


def _cache_save(keep=False):
    """guarda lo pedido por este proceso MEZCLADO con el fichero (gana lo más nuevo), con cerrojo. Antes se volcaba
    la copia entera del proceso: el Inicio, que vive toda la sesión, pisaba lo que guardaban las secciones y
    flix_progress (auditoría 22-oct B-05 / REND-04), y reescribía ~2,6 MB aunque no hubiera nada nuevo (C-04).
    keep=True: vienen más guardados enseguida (cada 4 filas). Se recuerda lo escrito y, si en el siguiente la huella
    del fichero es la misma, no se vuelve a leer ni a volcar entero: se mezcla y se purga sobre lo recordado (DAT-02).
    Sin keep (el último del lote, fetch con save) la copia se suelta: pesa tanto como el fichero"""
    global _saved, _saved_sig
    if not _dirty:
        if not keep:
            _forget()
        return
    try:
        with flix_cache.file_lock(CACHE_FILE) as lock:
            locked = getattr(lock, "fh", None) is not None
            before = _file_sig()
            parts = _saved if locked and _saved is not None and before == _saved_sig else None
            _forget()
            keys = list(_dirty)
            if parts is None:
                # como siempre: el fichero entero
                try:
                    with open(CACHE_FILE, encoding="utf-8") as fh:
                        disk = json.load(fh)
                except (OSError, ValueError):
                    disk = {}
                if not isinstance(disk, dict):
                    disk = {}
                flix_cache.merge_newer(disk, _cache, keys)
                flix_cache.purge(disk, max_age=KEEP, ages=[(TMDB_LIST, KEEP_TMDB)])
                if keep and locked:
                    parts = {k: (v[0], json.dumps(v)) for k, v in disk.items()}   # tras purge: todas con v[0]
                    text = _dumps(parts)
                else:
                    text = json.dumps(disk)
            else:
                # nadie ha escrito desde nuestro último guardado: lo recordado ES el fichero
                disk = parts
                flix_cache.merge_newer(disk, _cache, keys)
                flix_cache.purge(disk, max_age=KEEP, ages=[(TMDB_LIST, KEEP_TMDB)])
                for k in keys:
                    v = disk.get(k)
                    if v is not None and not isinstance(v, tuple):
                        disk[k] = (v[0], json.dumps(v))
                text = _dumps(disk)
            flix_cache.atomic_write(CACHE_FILE, text)
            if keep and locked:
                after = _file_sig()
                if _sig_ok(before, after, len(text) if text.isascii() else len(text.encode("utf-8"))):
                    _saved, _saved_sig = parts, after
        _dirty.difference_update(keys)
        for k, v in disk.items():               # y lo nuevo de los demás, para el siguiente peek
            if flix_cache.stamp(v) > flix_cache.stamp(_cache.get(k)):
                _cache[k] = json.loads(v[1]) if isinstance(v, tuple) else v
    except OSError as e:
        _forget()
        log("no guardo caché: %s" % e)


flush = _cache_save

def expire(rx):
    """da por caducado lo guardado cuya ruta cumpla rx: se sigue enseñando al momento y se pide otra vez. Sobre el
    fichero y con cerrojo: merge_newer nunca deja «envejecer» una entrada. Cuántas"""
    def hit(key):
        return bool(rx.search(key[:-2] if key.endswith("#h") else key))

    # marca de hace algo más de STATIC_TTL: caducada con cualquier ttl, pero no para la purga (KEEP). Con 0, el siguiente
    # guardado de cualquier script la borraba y Favoritos abría sin nada que enseñar (30 s; Carlos, 30-oct)
    old = time.time() - STATIC_TTL - 1

    def age(v):
        try:
            v[0] = min(float(v[0]), old)
        except (TypeError, ValueError):
            v[0] = old
    n = 0
    try:
        with flix_cache.file_lock(CACHE_FILE):
            try:
                with open(CACHE_FILE, encoding="utf-8") as fh:
                    disk = json.load(fh)
            except (OSError, ValueError):
                disk = {}
            for k, v in disk.items():
                if isinstance(v, list) and v and hit(k):
                    age(v)
                    n += 1
            if n:
                flix_cache.atomic_write(CACHE_FILE, json.dumps(disk))
    except OSError as e:
        log("no caduco caché: %s" % e)
    for k, v in (_cache or {}).items():
        if isinstance(v, list) and v and hit(k):
            age(v)
    log("caducadas %d filas guardadas (%s)" % (n, rx.pattern))
    return n


def peek(path, keep_headers=False):
    """(items guardados o None, ¿frescos?) sin pedir nada"""
    hit = _cache_load().get(cache_key(path, keep_headers))
    if not hit:
        return None, False
    return _progress(hit[1]), hit_fresh(path, hit)


def is_fresh(path, keep_headers=False):
    """¿lo guardado de esa fila está fresco? Lo mismo que peek(path)[1] sin corregir el progreso de los títulos
    (refresh_stale del Inicio solo quiere saber qué filas volver a pedir; revisión 29-oct ARR-01)"""
    hit = _cache_load().get(cache_key(path, keep_headers))
    return hit_fresh(path, hit)


def k3_stale(path, home=None):
    """¿hay fila guardada y es anterior al último aviso del addon para su lista? (reloj del Inicio)"""
    hit = _cache_load().get(cache_key(path))
    return bool(hit) and k3_newer(path, hit[0], home)


def fetch(path, force=False, keep_headers=False, save=True):
    """(items, de_caché). Clave sin &reload=. Un fallo (0 items) no machaca una caché buena."""
    key = cache_key(path, keep_headers)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and hit_fresh(path, hit):
        return _progress(hit[1]), True
    files = list_files(directory(path), PROPS)
    files = [f for f in files if f.get("label") and (keep_headers or not clean(f["label"]).endswith(":"))]
    files = tag_k3(path, files)
    if files:          # vacío = fallo: ni machaca una caché buena ni se guarda (el reintento volvería a dar vacío)
        cache[key] = [time.time(), files]
        _dirty.add(key)
        if save:
            _cache_save()
    return _progress(files or (hit[1] if hit else [])), False


K3_LIST = "plugin://plugin.video.ker0n3/lista/"
K3_FOLLOW = "plugin://plugin.video.ker0n3/siguiendo"
_K3_MEMO = {}       # ruta sin &reload= -> ruta del addon


def k3_route(path):
    """ruta del addon de una fila de lista de TMDB de la configuración (flix://tmdb/<clave> → lista/<clave>); '' si
    no lo es o si la clave no existe"""
    path = str(path or "")
    if not path.startswith(TMDB_LIST):
        return ""
    memo = flix_cache.key_of(path)
    if memo not in _K3_MEMO:
        if len(_K3_MEMO) > 500:
            _K3_MEMO.clear()
        import flix_tmdblists
        key = flix_tmdblists.key_of(path)
        _K3_MEMO[memo] = K3_LIST + key if key in flix_tmdblists.BY_KEY else ""
    return _K3_MEMO[memo]


def k3_list_key(path):
    """clave de la lista de Ker0n3 de la fila ('' si no es una): el servicio del addon avisa por clave
    (Window(home).Property(k3_list_rev_<clave>)) cuando lo que enseña esa lista cambia"""
    path = str(path or "")
    if path.startswith(K3_LIST):
        # la propia ruta del addon (lista/<clave>, …/todo, …/resto/<n>: lo que abre «Ver más»)
        return re.split(r"[/?&]", path[len(K3_LIST):], maxsplit=1)[0]
    if path.startswith(CARDS):
        # fila de tarjetas (bloques 4 y 5): el addon avisa por grupo (cards.rev_key)
        return "tarjetas-" + re.split(r"[/?&]", path[len(CARDS):], maxsplit=1)[0]
    route = k3_route(path)
    return route[len(K3_LIST):] if route.startswith(K3_LIST) else ""


def k3_rest(key, files, shown):
    """«Ver más» de una fila de lista de Ker0n3 (clave key) = solo el resto (Carlos, 16-nov): la tarjeta lleva a
    lista/<clave>/resto/<n>, con n = los títulos que la fila enseña (shown, lo que dejó head: 8-30 según Ajustes), y
    solo sale si la lista (files, lo que dio la ruta: hasta 30 y su «Más…») tiene más que esos. Sin clave (fila del
    NAS, de favoritos…), shown tal cual"""
    if not key:
        return shown
    titles = [f for f in shown if not is_more(f)]
    more = [f for f in files if is_more(f)]
    if not more and sum(1 for f in files if not is_more(f)) <= len(titles):
        return titles
    card = dict(more[0]) if more else {"label": "Más…", "filetype": "directory"}
    card["file"] = "%s%s/resto/%d" % (K3_LIST, key, len(titles))
    return titles + [card]


# Aviso del addon «lo que enseña esta lista ha cambiado» (lists.signal): la propiedad k3_list_rev_<clave> de
# Window(10000) (décimas de segundo) y, para que sobreviva a un reinicio de Kodi y a que el Inicio no esté abierto,
# el fichero listas_rev.json del addon ({clave: hora}). 16-nov, S24: «En cines ahora» seguía con títulos descartados
# tras reiniciar, porque la fila guardada (6 h) era de ANTES del repaso y el aviso, solo en memoria, se había perdido
K3_REV_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/listas_rev.json")
K3_REV_EVERY = 3        # s: el fichero se relee como mucho cada tanto (lo mira el reloj del Inicio)
_K3_REV = {}


def k3_changed_at(key, home=None):
    """hora del último aviso del addon para esa lista (0 si ninguno): lo más nuevo de la propiedad y del fichero.
    Sin red; el fichero (pequeño) se lee como mucho cada K3_REV_EVERY s"""
    if not key:
        return 0
    try:
        prop = float((home or HOME).getProperty("k3_list_rev_" + key) or 0) / 10
    except (TypeError, ValueError):
        prop = 0
    now = time.monotonic()
    if "at" not in _K3_REV or now - _K3_REV["at"] >= K3_REV_EVERY:
        try:
            with open(K3_REV_FILE, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            data = {}
        _K3_REV["at"], _K3_REV["data"] = now, data if isinstance(data, dict) else {}
    try:
        disk = float(_K3_REV["data"].get(key) or 0)
    except (TypeError, ValueError):
        disk = 0
    return max(prop, disk)


def k3_newer(path, fetched_at, home=None):
    """¿el addon ha avisado de un cambio en la lista de esa fila DESPUÉS de fetched_at (cuándo se guardó la fila)?
    Entonces lo guardado ya no vale como fresco: se pinta y se vuelve a pedir"""
    key = k3_list_key(path)
    if not key:
        return False
    try:
        return float(fetched_at) < k3_changed_at(key, home)
    except (TypeError, ValueError):
        return False


def hit_fresh(path, hit, home=None):
    """¿fresca una entrada [hora, items] de la caché de filas? Dentro de su caducidad y no anterior al último aviso
    del addon para su lista. La usan la TV (peek / is_fresh / fetch) y el Inicio táctil (su caché aparte)"""
    return bool(hit) and flix_cache.is_fresh(hit, ttl=ttl_of(path)) and not k3_newer(path, hit[0], home)


K3_TRAKT_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.ker0n3/trakt_listas.json")


def k3_trakt_lists():
    """lo que dejó el servicio del addon sobre Trakt (trakt_lists.py): {"on": ¿en uso?, "lists": [{id, name, n}],
    "watchlist": {"pelis": n, "series": n}}. Sin fichero o ilegible: {"on": False}. Sin red"""
    try:
        with open(K3_TRAKT_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {"on": False}
    except (OSError, ValueError):
        return {"on": False}


def own_menu(var):
    """las filas del menú propio de la sección (flix_sections_own) por su variable (own:…); None si esa sección no
    tiene (Otros orígenes)"""
    import flix_sections_own as so
    v = so.own_var(str(var or ""))
    if not v:
        return None
    return so.rows_for(v, trakt=k3_trakt_lists() if v == so.TRAKT else None)


def cache_key(path, keep_headers=False):
    """clave de la caché de una fila: su ruta del addon (k3_route) sin &reload=. La usa también el Inicio táctil
    (flix_home.fetch / peek)"""
    return flix_cache.key_of(k3_route(path) or path, keep_headers)


def tag_k3(path, files):
    """«Series en seguimiento» (ruta siguiendo): cada serie lleva su tmdb en flix_follow (follow_tmdb: etiqueta
    «NUEVO», «Ver más» sin repetidas)"""
    if files and flix_cache.key_of(path) == K3_FOLLOW:
        import flix_common
        for f in files:
            ref = flix_common.k3_ref(f.get("file")) if isinstance(f, dict) else None
            if ref and ref[0] == "tv":
                f["flix_follow"] = str(ref[1])
    return files


def directory(path):
    """ruta que se pide a Kodi: la del addon (k3_route) o la propia ruta"""
    return k3_route(path) or path


def list_files(directory_path, props):
    """Files.GetDirectory; [] sin ruta"""
    if not directory_path:
        return []
    import flix_common
    if flix_common.is_fs(directory_path):
        return flix_common.list_fs(directory_path, props)   # carpeta del NAS, USB… (otros orígenes): fotos y vídeos
    if directory_path.startswith(flix_common.K3_ROOT) and "mpaa" not in props:
        props = list(props) + ["mpaa"]      # la edad viene en el propio título de Ker0n3 (flix_meta.complete la pone)
    return list_dir(directory_path, props)  # JSON-RPC común (DAT-20); respuesta que no es JSON: ValueError, como antes


def _progress(files):
    """✓ y progreso de la base de vistos en vez de lo que trae la caché (flix_progress.py)"""
    try:
        import flix_progress
        flix_progress.fix_files(files)
    except Exception as e:  # noqa: BLE001
        log("progreso: %s" % e)
    return files


def is_generic(f):
    """sin carátula (tarjeta de relleno)"""
    a = f.get("art") or {}
    return not (a.get("poster") or a.get("thumb"))


def is_more(f):
    """último elemento "Más…/More…" de un listado (página siguiente). El nombre entero: «Más que rivales» es una serie"""
    return f.get("filetype") == "directory" and re.fullmatch(
        r"(m[aá]s|more|siguiente|next)[\s.…>]*", clean(f.get("label")).strip().lower()) is not None


def follow_tmdb(f):
    """tmdb de una serie de «Series en seguimiento» (cualquier página o sección; tag_k3); None si no lo es. Aquí y no
    en flix_progress para que las secciones lo miren sin cargar ese módulo"""
    if isinstance(f, dict) and f.get("flix_follow"):
        return str(f["flix_follow"])
    return None


def head(files, n, more=True):
    """los n primeros de un listado y su «más…» al final aunque quede fuera del recorte (tarjeta «Ver más»);
    more=False lo quita (Top 10)"""
    out = [f for f in files[:n] if more or not is_more(f)]
    if more and len(files) > n and files and not any(map(is_more, files)):
        import flix_common
        if flix_common.is_fs(files[0].get("file")):
            # carpeta del NAS más larga que la fila: su «Ver más» abre la carpeta entera (flix_section.more_rows)
            return out + [{"label": "Más…", "file": flix_common.parent_of(files[0]["file"]), "filetype": "directory"}]
    return out + [f for f in files[n:] if is_more(f)][:1] if more else out


def is_search(label):
    l = label.lower().replace("í", "i")
    return "titulo" in l or "title" in l or l.startswith("buscar") or l.startswith("search")


def section_rows(var, **_kw):
    """[{label, path, kind, group}] de la sección: su menú propio (own_menu) o, si es una carpeta del NAS / USB
    (otros orígenes), una fila por subcarpeta. Sin nada, []"""
    own = own_menu(var)
    if own is not None:
        return own
    var = str(var or "")
    if not is_fs(var):
        return []
    menu, _ = fetch(var, keep_headers=True)
    return folder_rows(var, menu)


def folder_rows(path, menu):
    """sección hecha de una carpeta del NAS (Carlos, 13-nov: «NAS» con las fotos de la boda): una fila por subcarpeta,
    con sus fotos y vídeos, y delante otra con lo suelto de la propia carpeta si lo hay"""
    out = [{"label": f["label"], "path": f["file"], "kind": "list", "group": ""}
           for f in menu if f.get("filetype") == "directory" and f.get("file")]
    if any(f.get("filetype") != "directory" for f in menu):
        name = re.sub(r".*[/\\]", "", path.rstrip("/\\")) or path
        out.insert(0, {"label": name, "path": path, "kind": "list", "group": ""})
    return out

