"""Subtítulos externos en castellano cuando la versión original no trae ninguno dentro (16-nov).

Lo llama flix_src_subs (hilo aparte de la skin, o su RunScript desde el addon Ker0n3) DESPUÉS de mirar las pistas del
fichero: solo si no hay ninguna en español. Con castellano (audio o subtítulos dentro) aquí no se llega y no sale
ninguna petición.

Fuente única: el addon público de OpenSubtitles v3 de Stremio, sin clave ni cuenta:
    GET https://opensubtitles-v3.strem.io/subtitles/movie/<imdb>.json
    GET https://opensubtitles-v3.strem.io/subtitles/series/<imdb>:<temporada>:<capítulo>.json
    → {"subtitles": [{"id", "url", "lang" («spa», «eng», «pob»…), "SubEncoding", "subtitleFileName",
       "movieReleaseName", "releaseGroup"?, "releaseFormat"?, "fpsMilli"?, "m", "g", "season", "episode"}], …}
Visto el 16-nov con tt1375666 y tt0903747:1:1:
  * el español es siempre «spa»: la fuente NO distingue castellano de latino, ni marca forzados o para sordos. Solo
    queda el nombre del fichero («Latino», «Castellano», «Forced», «SDH»), que casi nunca lo dice.
  * «filename=…&videoSize=…» en la ruta se acepta y devuelve exactamente lo mismo; «videoHash» pide leer el fichero
    (dos trozos de 64 KB) y con uno cualquiera no mejora nada: no se manda ninguno. A la fuente solo viaja el id de
    IMDb (y temporada y capítulo). El nombre de la versión se usa AQUÍ, para ordenar.
  * el enlace de cada subtítulo ya viene convertido a UTF-8 por la fuente; por si acaso se normaliza igual.
Orden: lo que diga el nombre (castellano, sin más, latino, forzados/sordos), después lo que cuadre con la versión que
suena (mismo grupo, mismo origen —BluRay, WEB, TV—, mismos fotogramas; los de cámara al final) y, a igualdad, el orden
de la fuente.

El desfase es el punto flojo: la lista se guarda en Window(10000) mientras dure el vídeo y «Otro subtítulo» (botón de
los controles en TV; botón «Subtítulos» en táctil) carga el siguiente sin volver a preguntar.
    RunScript(special://skin/scripts/flix_src_extsubs.py,next | menu)
Todo fallo es mudo (una línea en el registro) y el vídeo sigue sin subtítulos, como antes. No borra nada fuera de sus
temporales (addon_data/<skin>/subtitulos/flix_sub_<n>_<i>.es.<srt|vtt|ass>: nombre fijo, nunca uno que venga de la red;
en special://temp Kodi para Android no los abre)."""
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

API = "https://opensubtitles-v3.strem.io/subtitles"
HOSTS = ("strem.io",)            # los subtítulos solo se bajan de la propia fuente, por https
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
TIMEOUT = 4                      # s por petición
BUDGET = 8                       # s en total (lista + subtítulos probados)
LIST_MAX = 2 * 1024 * 1024       # la lista entera (80-90 subtítulos) son ~30 KB
MAX_BYTES = 3 * 1024 * 1024      # un .srt de película son 50-150 KB; un .ass con estilos, algo más
MIN_CUES = 3
MAX_CANDS = 12
MAX_TRIES = 3                    # subtítulos que se intentan bajar de una vez
HEADING = "KER0N3 MEDIA"
PROP = "flix_extsubs"            # Window(10000): JSON {file, stamp, i, cands} mientras dure el vídeo
PROP_N = "flix_extsubs_n"        # «2 de 7» (vacío si no hay otro que probar): lo miran los botones de VideoOSD.xml
PROP_BUSY = "flix_extsubs_busy"
OWN_PLAYING = "flix_own_playing"     # = flix_src_play.OWN_PLAYING: qué se está viendo (lo deja mark_playing)
K3_PLAYING = "k3_playing"
SPANISH = ("spa", "es", "esp", "spn", "spl", "es-es")
_IMDB = re.compile(r"tt\d{5,10}\Z")
_TMP = re.compile(r"flix_sub_\d+_\d+\.es\.(?:srt|vtt|ass)\Z")
_CAST = re.compile(r"castellano|espa[ñn]a|\bspain\b|european|es[-_.]es\b", re.I)
_LAT = re.compile(r"latino|\blat\b|latam|es[-_.]?419|hispanoam|m[eé]xico", re.I)
_PARTIAL = re.compile(r"forced|forzad|hearing|sordos|(?<![A-Za-z])(?:HI|SDH)(?![A-Za-z])")
_PARTIAL_I = re.compile(r"forced|forzad|hearing|sordos|\bsdh\b", re.I)
_SOURCES = (("cam", ("cam", "camrip", "hdcam", "ts", "hdts", "telesync", "tc", "telecine")),
            ("bluray", ("bluray", "blu", "bdrip", "brrip", "bdremux", "remux", "uhd", "bd")),
            ("web", ("web", "webrip", "webdl", "amzn", "nf", "dsnp", "hmax", "atvp")),
            ("tv", ("hdtv", "pdtv", "dsr", "tvrip")),
            ("dvd", ("dvdrip", "dvd", "dvdscr")))
_SRT_CUE = re.compile(r"^\s*\d{1,2}:\d\d:\d\d[,.]\d{1,3}\s*-->\s*\d{1,2}:\d\d:\d\d[,.]\d{1,3}", re.M)
_VTT_CUE = re.compile(r"^\s*(?:\d{1,2}:)?\d\d:\d\d\.\d{3}\s*-->\s*(?:\d{1,2}:)?\d\d:\d\d\.\d{3}", re.M)
_ASS_CUE = re.compile(r"^Dialogue:\s*\d+,\d+:\d\d:\d\d\.\d\d,", re.M)
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
_C1 = re.compile(r"[\x7f-\x9f]")


# ---------- lo de fuera (red, reproductor, Kodi): los tests lo cambian entero ----------
class Env:
    def __init__(self):
        import xbmc
        import xbmcgui
        self.home, self.player = xbmcgui.Window(10000), xbmc.Player()

    def get(self, url, timeout, limit):
        """los bytes de url (como mucho limit + 1). El plazo de urllib es por operación de red (visto: 15 s con
        timeout=4 en un mal momento): aquí es TOTAL; la petición va en un hilo daemon que, si se pasa, se abandona"""
        box = {}

        def work():
            try:
                req = urllib.request.Request(url, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    box["data"] = r.read(limit + 1)
            except Exception as e:  # noqa: BLE001
                box["err"] = e
        th = threading.Thread(target=work, name="flix_src_extsubs_get", daemon=True)
        th.start()
        th.join(timeout)
        if "data" in box:
            return box["data"]
        raise box.get("err") or TimeoutError("plazo")

    def imdb_of(self, kind, tmdb):
        import flix_src_list
        return flix_src_list.imdb_of(kind, tmdb)        # guardado en disco desde que se buscaron las fuentes

    def alias(self, tmdb, imdb, season, episode):
        """numeración de IMDb si no es la de TMDB (anime largo: flix_src_epmap); None si es la misma"""
        try:
            import flix_src_epmap
            return flix_src_epmap.alias(tmdb, imdb, season, episode)
        except Exception:  # noqa: BLE001
            return None

    def tmpdir(self):
        """carpeta de los subtítulos bajados: addon_data de la skin, NO special://temp. Kodi en Android no abre un .srt
        de special://temp («OpenStream - Unable to create subtitle parser» y se queda en la pista inglesa); el mismo
        fichero en addon_data o en /sdcard sí (probado en el S24, Brooklyn Nine-Nine 4x03, 17-nov)"""
        import os
        import xbmc
        import xbmcvfs
        d = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s/" % xbmc.getSkinDir()), "subtitulos")
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            return xbmcvfs.translatePath("special://temp/")
        return d

    def notify(self, msg):
        import xbmcgui
        xbmcgui.Dialog().notification(HEADING, msg, xbmcgui.NOTIFICATION_INFO, 3000, False)

    def log(self, msg):
        try:
            import xbmc
            xbmc.log("[flix_src_extsubs] %s" % msg, xbmc.LOGINFO)
        except Exception:  # noqa: BLE001
            pass

    def now(self):
        return time.monotonic()

    def fps(self):
        import xbmc
        try:
            v = float((xbmc.getInfoLabel("Player.Process(VideoFps)") or "").replace(",", "."))
        except ValueError:
            return None
        return v if 10 < v < 130 else None

    def builtin(self, cmd):
        import xbmc
        xbmc.executebuiltin(cmd)

    def select(self, options):
        import xbmcgui
        return xbmcgui.Dialog().select("Subtítulos", options)


# ---------- qué se pide ----------
def _num(v):
    if isinstance(v, bool) or not isinstance(v, (int, str)):
        return None
    try:
        n = int(v)
    except ValueError:
        return None
    return n if 0 < n < 10000 and str(v).strip().isdigit() else None


def api_url(kind, imdb, season=None, episode=None):
    """dirección de la lista, o None si algo no tiene la forma debida (a la fuente solo va esto)"""
    if not isinstance(imdb, str) or not _IMDB.match(imdb):
        return None
    if kind == "movie":
        return "%s/movie/%s.json" % (API, imdb)
    s, e = _num(season), _num(episode)
    if kind == "tv" and s and e:
        return "%s/series/%s:%d:%d.json" % (API, imdb, s, e)
    return None


# ---------- cuál ----------
def _tokens(text):
    return [t for t in re.split(r"[^a-z0-9]+", (text or "").lower()) if t]


def _source(text):
    toks = set(_tokens(text))
    return next((name for name, words in _SOURCES if toks & set(words)), "")


def _group(text):
    m = re.search(r"-([A-Za-z0-9]{2,})\s*\Z", text or "")
    return m.group(1).lower() if m else ""


def _stem(name):
    return re.sub(r"\.(mkv|mp4|avi|m2ts|ts|mov|srt|ass|ssa|vtt|sub)\Z", "", (name or "").strip(), flags=re.I)


def _safe_url(url):
    if not isinstance(url, str) or len(url) > 500:
        return False
    try:
        u = urllib.parse.urlsplit(url)
    except ValueError:
        return False
    host = (u.hostname or "").lower()
    return u.scheme == "https" and any(host == h or host.endswith("." + h) for h in HOSTS)


def candidates(payload, release="", fps=None):
    """los subtítulos en español de la respuesta, ordenados: [{"id", "url", "name"}] (como mucho MAX_CANDS).
    release: nombre del fichero que suena (para casar grupo y origen); fps: fotogramas del vídeo"""
    subs = payload.get("subtitles") if isinstance(payload, dict) else None
    if not isinstance(subs, list):
        return []
    rel = _stem(release)
    rel_src, rel_group = _source(rel), _group(rel)
    out, seen = [], set()
    for pos, s in enumerate(subs):
        if not isinstance(s, dict) or str(s.get("lang") or "").strip().lower() not in SPANISH:
            continue
        url, sid = s.get("url"), str(s.get("id") or "")
        if not _safe_url(url) or not sid or sid in seen:
            continue
        seen.add(sid)
        names = [_stem(v) for v in (s.get("movieReleaseName"), s.get("subtitleFileName")) if isinstance(v, str)]
        text = " ".join(names)
        fmt = s.get("releaseFormat") if isinstance(s.get("releaseFormat"), str) else ""
        if _PARTIAL.search(text) or _PARTIAL_I.search(text):
            kind = 3            # forzados (solo carteles) o para sordos
        elif _LAT.search(text):
            kind = 2
        elif _CAST.search(text):
            kind = 0
        else:
            kind = 1
        src = _source(text + " " + fmt)
        group = (s.get("releaseGroup") if isinstance(s.get("releaseGroup"), str) else "").lower() or \
            next((g for g in map(_group, names) if g), "")
        score = 0
        if rel_group and group == rel_group:
            score += 4
        if rel_src and src == rel_src:
            score += 3
        if src == "cam" and rel_src != "cam":
            score -= 5          # hechos para una grabación de cine: otro montaje, otro ritmo
        try:
            sub_fps = float(s.get("fpsMilli")) / 1000.0
        except (TypeError, ValueError):
            sub_fps = 0
        if fps and sub_fps:
            score += 1 if abs(sub_fps - fps) < 0.1 else -3 if abs(sub_fps - fps) > 0.5 else 0
        name = _CTRL.sub(" ", names[0] if names else "")[:80]
        out.append(((kind, -score, pos), {"id": sid, "url": url, "name": name}))
    out.sort(key=lambda x: x[0])
    return [c for _, c in out[:MAX_CANDS]]



def reference(payload, release=""):
    """el subtítulo NO español que va a tiempo con lo que suena, para sincronizar el español (flix_src_subsync):
    misma procedencia que la versión que suena (BluRay, WEB, TV…; obligatorio) y, mejor, mismo grupo y en inglés.
    {"url", "name"} o None (sin procedencia conocida no hay referencia fiable)"""
    subs = payload.get("subtitles") if isinstance(payload, dict) else None
    rel = _stem(release)
    rel_src, rel_group = _source(rel), _group(rel)
    if not isinstance(subs, list) or not rel_src:
        return None
    best = None
    for pos, s in enumerate(subs):
        if not isinstance(s, dict):
            continue
        lang = str(s.get("lang") or "").strip().lower()
        if not lang or lang in SPANISH or not _safe_url(s.get("url")):
            continue
        names = [_stem(v) for v in (s.get("movieReleaseName"), s.get("subtitleFileName")) if isinstance(v, str)]
        text = " ".join(names)
        if _PARTIAL.search(text) or _PARTIAL_I.search(text):
            continue            # forzados o para sordos: otras frases
        fmt = s.get("releaseFormat") if isinstance(s.get("releaseFormat"), str) else ""
        if _source(text + " " + fmt) != rel_src:
            continue
        group = (s.get("releaseGroup") if isinstance(s.get("releaseGroup"), str) else "").lower() or \
            next((g for g in map(_group, names) if g), "")
        key = (0 if rel_group and group == rel_group else 1, 0 if lang == "eng" else 1, pos)
        if best is None or key < best[0]:
            best = (key, {"url": s["url"], "name": _CTRL.sub(" ", names[0] if names else "")[:80]})
    return best[1] if best else None


def synced(text, ref_text):
    """el español movido a los tiempos de la referencia, o None si no hace falta o no se fía (flix_src_subsync)"""
    import flix_src_subsync as sync
    try:
        p = sync.plan(sync.starts(ref_text), sync.starts(text))
        if not p:
            return None
        out = sync.shift(text, p[0], p[1])
        return (out, "casan %d → %d frases; %s%s" % (p[2], p[3], sync.tramos(p[1]),
                                                   "" if p[0] == 1.0 else ", otra velocidad")) if out else None
    except Exception:  # noqa: BLE001  (un fallo aquí deja el subtítulo como venía)
        return None

# ---------- el fichero ----------
def decode(raw):
    """(«srt» | «vtt» | «ass», texto en UTF-8 con saltos \\n) o None si no es un subtítulo de texto"""
    if not isinstance(raw, (bytes, bytearray)) or not raw.strip() or len(raw) > MAX_BYTES:
        return None
    raw = bytes(raw)
    text = None
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        try:
            text = raw.decode("utf-16")
        except UnicodeDecodeError:
            return None
    elif b"\x00" in raw:
        return None
    else:
        for enc in ("utf-8-sig", "cp1252"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            text = _C1.sub("", raw.decode("latin-1"))
    text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    if _CTRL.search(text):
        return None
    head = text[:600].lstrip().lower()
    if head.startswith(("<!doctype", "<html", "<?xml", "{", "#!")) or "<html" in head or "<script" in text.lower():
        return None
    if head.startswith("webvtt"):
        kind, cues = "vtt", len(_VTT_CUE.findall(text))
    elif "[script info]" in head or "[events]" in text.lower():
        kind, cues = "ass", len(_ASS_CUE.findall(text))
    else:
        kind, cues = "srt", len(_SRT_CUE.findall(text))
    if cues < MIN_CUES:
        return None
    return kind, text


def cleanup(tmp, keep=None):
    """borra los temporales de otras veces (solo los que tienen nuestro nombre)"""
    try:
        names = os.listdir(tmp)
    except OSError:
        return
    for name in names:
        if _TMP.match(name) and not (keep and name.startswith("flix_sub_%d_" % keep)):
            try:
                os.remove(os.path.join(tmp, name))
            except OSError:
                pass


# ---------- qué suena ----------
def _playing(env):
    try:
        return env.player.getPlayingFile() or ""
    except Exception:  # noqa: BLE001  (RuntimeError: no suena nada)
        return ""


def _same(a, b):
    return bool(a) and bool(b) and (a == b or a.startswith(b) or b.startswith(a))


def ident(env, playing):
    """(kind, tmdb, temporada, capítulo) de lo que suena según la marca de flix_src_play.mark_playing (la dejan la
    skin y el addon antes de reproducir); None si la marca no es de este vídeo"""
    for prop in (OWN_PLAYING, K3_PLAYING):
        try:
            d = json.loads(env.home.getProperty(prop) or "")
            if not isinstance(d, dict) or d.get("kind") not in ("movie", "tv") or not _same(d.get("file"), playing):
                continue
            tmdb = int(d["tmdb"])
            if d["kind"] == "movie":
                return ("movie", tmdb, None, None)
            return ("tv", tmdb, int(d["season"]), int(d["episode"]))
        except (ValueError, TypeError, KeyError):
            continue
    return None


def _release(playing):
    try:
        return urllib.parse.unquote(urllib.parse.urlsplit(playing).path.rsplit("/", 1)[-1])
    except ValueError:
        return ""


# ---------- estado (Window(10000)) ----------
def _clear(env):
    env.home.clearProperty(PROP)
    env.home.clearProperty(PROP_N)


def _state(env):
    try:
        st = json.loads(env.home.getProperty(PROP) or "")
    except ValueError:
        return None
    if not isinstance(st, dict) or not isinstance(st.get("file"), str) or not isinstance(st.get("cands"), list) \
            or isinstance(st.get("i"), bool) or not isinstance(st.get("i"), int) \
            or isinstance(st.get("stamp"), bool) or not isinstance(st.get("stamp"), int):
        return None
    if not st["cands"] or not all(isinstance(c, dict) and _safe_url(c.get("url")) for c in st["cands"]):
        return None
    return st


def _save(env, st):
    n = len(st["cands"])
    env.home.setProperty(PROP, json.dumps(st))
    if n > 1 and 0 <= st["i"] < n:
        env.home.setProperty(PROP_N, "%d de %d" % (st["i"] + 1, n))
    else:
        env.home.clearProperty(PROP_N)


_REF = {}                        # url -> texto de la referencia (una vez por RunScript)


def _worth_sync(text):
    """con pocas frases no se intenta (y no se baja la referencia)"""
    import flix_src_subsync as sync
    return len(sync.starts(text)) >= sync.MIN_CUES


def _ref_text(env, ref, deadline):
    url = ref.get("url") if isinstance(ref, dict) else None
    if not _safe_url(url):
        return None
    if url not in _REF:
        left = deadline - env.now()
        if left <= 0:
            return None
        try:
            got = decode(env.get(url, min(TIMEOUT, left), MAX_BYTES))
        except Exception as e:  # noqa: BLE001
            env.log("la referencia para sincronizar no baja (%s)" % type(e).__name__)
            got = None
        _REF[url] = got[1] if got and got[0] in ("srt", "vtt") else None
    return _REF[url]


def _load(env, st, order, deadline):
    """carga el primero de `order` (índices) que se pueda. (¿cargado?, por qué no)"""
    tmp, tries, why = env.tmpdir(), 0, "ninguno más que probar"
    for i in order:
        c = st["cands"][i]
        if c.get("bad"):
            continue
        path = c.get("path") if isinstance(c.get("path"), str) else ""
        if not (path and os.path.dirname(path) == os.path.normpath(tmp).rstrip(os.sep or "/")
                and _TMP.match(os.path.basename(path)) and os.path.isfile(path)):
            left = deadline - env.now()
            if left <= 0:
                why = "plazo de %d s agotado" % BUDGET
                break
            if tries >= MAX_TRIES:
                why = "%d seguidos no valen" % tries
                break
            tries += 1
            try:
                got = decode(env.get(c["url"], min(TIMEOUT, left), MAX_BYTES))
            except Exception as e:  # noqa: BLE001
                why = "no baja (%s)" % type(e).__name__
                continue
            if got is None:
                c["bad"], why = True, "lo bajado no es un subtítulo de texto"
                continue
            if got[0] in ("srt", "vtt") and st.get("ref") and _worth_sync(got[1]):
                ref = _ref_text(env, st["ref"], deadline)
                fix = synced(got[1], ref) if ref else None
                if fix:
                    got = (got[0], fix[0])
                    env.log("subtítulo %d sincronizado con %s: %s" % (i + 1, st["ref"].get("name") or "?", fix[1]))
            path = os.path.join(os.path.normpath(tmp), "flix_sub_%d_%d.es.%s" % (st["stamp"], i, got[0]))
            try:
                with open(path, "w", encoding="utf-8", newline="\n") as f:
                    f.write(got[1])
            except OSError as e:
                why = "no se puede guardar (%s)" % type(e).__name__
                break
            c["path"] = path
        if not _same(st["file"], _playing(env)):
            _clear(env)
            return False, "el vídeo ya es otro"
        env.player.setSubtitles(path)
        env.player.showSubtitles(True)
        st["i"] = i
        _save(env, st)
        n = len(st["cands"])
        env.notify("Subtítulos externos (%d de %d)" % (i + 1, n) if n > 1 else "Subtítulos externos")
        return True, ""
    return False, why


def auto(env=None):
    """busca fuera, elige y carga. True si quedó puesto un subtítulo. Nunca en el hilo de la interfaz"""
    env = env or Env()
    deadline = env.now() + BUDGET
    playing = _playing(env)
    who = ident(env, playing) if playing else None
    if not who:
        env.log("no sé qué título suena: no busco subtítulos fuera")
        return False
    _clear(env)
    kind, tmdb, season, episode = who
    try:
        imdb = env.imdb_of(kind, tmdb)
    except Exception:  # noqa: BLE001
        imdb = None
    al = env.alias(tmdb, imdb, season, episode) if kind == "tv" and imdb else None
    url = api_url(kind, imdb, al[0] if al else season, al[1] if al else episode)
    if not url:
        env.log("sin id de IMDb para %s/%s: no busco subtítulos fuera" % (kind, tmdb))
        return False
    cleanup(env.tmpdir())
    _REF.clear()                # vídeo nuevo: la referencia de otro no vale
    try:
        payload = json.loads(bytes(env.get(url, TIMEOUT, LIST_MAX)).decode("utf-8"))
    except Exception as e:  # noqa: BLE001
        env.log("la lista de subtítulos no llega (%s): sigo sin subtítulos" % type(e).__name__)
        return False
    cands = candidates(payload, release=_release(playing), fps=env.fps())
    if not cands:
        env.log("ningún subtítulo en español fuera para %s" % url.rsplit("/", 1)[-1])
        return False
    st = {"file": playing, "stamp": int(time.time()), "i": -1, "cands": cands}
    ref = reference(payload, release=_release(playing))
    if ref:
        st["ref"] = ref
    ok, why = _load(env, st, range(len(cands)), deadline)
    if ok:
        env.log("subtítulo externo %d de %d: %s" % (st["i"] + 1, len(cands), cands[st["i"]].get("name") or "?"))
    else:
        env.log("subtítulos externos: %s (%d candidatos): sigo sin subtítulos" % (why, len(cands)))
    return ok


def next_candidate(env=None):
    """«Otro subtítulo»: el siguiente de la lista guardada (da la vuelta), sin volver a preguntar a la fuente"""
    env = env or Env()
    st = _state(env)
    if not st:
        return False
    if not _same(st["file"], _playing(env)):
        _clear(env)             # lista de otro vídeo: fuera (y el botón con ella)
        return False
    n = len(st["cands"])
    if n < 2 or not 0 <= st["i"] < n:
        return False
    order = [(st["i"] + k) % n for k in range(1, n)]
    ok, why = _load(env, st, order, env.now() + BUDGET)
    if ok:
        env.log("subtítulo externo %d de %d: %s" % (st["i"] + 1, n, st["cands"][st["i"]].get("name") or "?"))
    elif env.home.getProperty(PROP):
        _save(env, st)          # recuerda los que no valen
        env.log("otro subtítulo: %s" % why)
    return ok


def menu(env=None):
    """táctil: el botón «Subtítulos» de siempre, con «Probar otro subtítulo» delante mientras haya lista"""
    env = env or Env()
    st = _state(env)
    if not st or len(st["cands"]) < 2 or not _same(st["file"], _playing(env)):
        env.builtin("ActivateWindow(osdsubtitlesettings)")
        return
    got = env.select(["Probar otro subtítulo (ahora %d de %d)" % (st["i"] + 1, len(st["cands"])),
                      "Ajustes de subtítulos"])
    if got == 0:
        next_candidate(env)
    elif got == 1:
        env.builtin("ActivateWindow(osdsubtitlesettings)")


def main(argv):
    """RunScript desde los controles del reproductor (hilo propio del script: la interfaz no espera)"""
    what = argv[1].strip().lower() if len(argv) > 1 else ""
    if what not in ("next", "menu"):
        return
    env = Env()
    try:
        busy = float(env.home.getProperty(PROP_BUSY) or 0)
    except ValueError:
        busy = 0
    if 0 <= time.time() - busy < BUDGET + 2:
        return                  # otra pulsación mientras baja el anterior
    env.home.setProperty(PROP_BUSY, str(time.time()))
    try:
        if what == "next":
            next_candidate(env)
        else:
            menu(env)
    except Exception as e:  # noqa: BLE001
        env.log("falló: %s" % type(e).__name__)
    finally:
        env.home.clearProperty(PROP_BUSY)


if __name__ == "__main__":
    main(sys.argv)
