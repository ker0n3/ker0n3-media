"""Piezas comunes a los scripts del skin (sin xbmc: se prueban fuera de Kodi). Antes había 5 copias de COLOR_RE,
3 de decode_route y 2 de encode_route (auditoría PY-12).
Lo carga el clic en una carátula (flix_play): cada RunScript es un intérprete nuevo y en la Shield cada import pesa
(tempfile 47 ms, base64 10 ms; test_click_imports.py) → aquí solo lo barato y lo demás dentro de su función."""
import binascii
import math
import os
import re

PLUGIN_ROOT = "plugin://plugin.video.palantir3/"
# Clave pública del scraper oficial de Kodi (metadata.themoviedb.org.python): búsqueda (títulos alternativos) y
# siguiente capítulo (qué hay ya emitido)
TMDB_KEY = "f090bb54758cabf231fb605d3e3e0468"
# etiquetas de formato de Kodi que Palantir mete en títulos y menús
COLOR_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)[^\]]*\]")


def clean(label):
    return COLOR_RE.sub("", label or "").strip()


def decode_route(url):
    """JSON (como texto) de una ruta de Palantir: base64 invertido y rotado ceil(len/4)."""
    blob = url.split("?", 1)[-1].split("&", 1)[0]
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    return binascii.a2b_base64(b64).decode("utf-8", "replace")


def encode_route(text):
    rb = binascii.b2a_base64(text.encode(), newline=False).decode().rstrip("=")[::-1]
    n = len(rb)
    k = math.ceil(n / 4)
    return PLUGIN_ROOT + "?" + rb[n - k:] + rb[:n - k]


def atomic_write(path, text):
    """escribe en un temporal único del mismo directorio y lo cambia de golpe por el fichero"""
    import tempfile
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + ".", suffix=".tmp", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def watched_movies(db_path):
    """watched.db de Palantir: {tmdb(str): (playcount, progress %, runtime s, lastPlayed)}; None si no existe.
    Aquí y no en flix_progress para que el clic en una carátula no cargue ese módulo (pickle, json, flix_rows…)."""
    if not os.path.exists(db_path):
        return None
    import sqlite3
    db = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=5)
    try:
        return {str(r[0]): (r[1], r[2], r[3], r[4]) for r in
                db.execute("SELECT tmdb_id, playcount, progress, runtime, lastPlayed FROM movies_watched")}
    finally:
        db.close()
