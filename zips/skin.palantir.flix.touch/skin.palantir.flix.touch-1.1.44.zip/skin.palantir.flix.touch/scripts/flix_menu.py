"""Menú KER0N3 MEDIA de un elemento de Palantir (mantener OK / botón ☰): película, capítulo, temporada o serie.

Solo lo que sirve y llega a Trakt: vista / no vista, quitar progreso (película y capítulo), temporada vista / no vista,
serie vista / no vista, dejar de seguir y (película y serie) valorar en Trakt. «Añadir a mi lista…» (40) está
definida pero aparcada. Esas acciones son de Palantir y solo existen dentro de su submenú
("Menú Palantir 3..." -> context.py, que recibe el elemento como sys.listitem y no expone ninguna ruta reutilizable).
Por eso este script, tras elegir, abre por detrás el menú contextual de Kodi (invisible: Window(home).Property
(flix_ctx_auto) pone DialogContextMenu.xml transparente y sin interceptar), entra en "Menú Palantir 3..." y pulsa la
opción de Palantir. Las de primer nivel con el mismo nombre son de Kodi y NO llegan a Palantir ni a Trakt: solo se
pulsa dentro del submenú (se reconoce por "Información sobre Palantir 3" / "Information about Palantir 3").
Textos en el idioma del aparato: los de Kodi con xbmc.getLocalizedString y los de Palantir con su propio addon
(Fire TV tiene Kodi en inglés).
Verificado 17-oct-2026 (Shield + resincronizar con Trakt; Fire TV): restablecer y marcar/desmarcar vista llegan a Trakt.
Uso: RunScript(special://skin/scripts/flix_menu.py[,<ruta>,<carátula>])  (lo lanza DialogContextMenu.xml)
"""
import ast
import os
import sqlite3
import sys
import json
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_play  # noqa: E402
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
SUBMENU_MARK = "Palantir 3"   # botón de primer nivel que abre el submenú de Palantir ("Menú Palantir 3...")
SUBMENU_SIGN = ("información sobre palantir", "information about palantir")   # solo dentro del submenú
WATCHED_DB = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db")


def _kodi(i):
    try:
        return xbmc.getLocalizedString(i).strip().lower()
    except Exception:  # noqa: BLE001
        return ""


def _pal(i):
    try:
        return xbmcaddon.Addon("plugin.video.palantir3").getLocalizedString(i).strip().lower()
    except Exception:  # noqa: BLE001
        return ""


# id -> (texto en el menú KER0N3, icono, textos de la opción de Palantir (exactos, sin mayúsculas), aviso al terminar)
ACTIONS = {
    10: ("Marcar como vista", "check", {_kodi(16103), "marcar como visto", "mark as watched"}, "Marcada como vista"),
    11: ("Marcar como no vista", "x", {_kodi(16104), "marcar como no visto", "mark as unwatched"},
         "Marcada como no vista"),
    12: ("Quitar progreso / dejar de seguir", "rewind", {_kodi(38209), "restablecer posición de reanudación", "reset resume position"},
         "Progreso quitado"),
    20: ("Marcar serie como vista", "check", {_pal(30080), "marcar serie como vista", "mark show as watched"},
         "Serie marcada como vista"),
    21: ("Marcar serie como no vista", "x", {_pal(30079), "marcar serie como no vista", "mark show as unwatched"},
         "Serie marcada como no vista"),
    22: ("Dejar de seguir la serie", "delete", {_pal(30091), "no seguir esta serie...", "do not follow this show..."},
         None),
    # abren el diálogo de Palantir (elegir lista / nota): el resultado lo avisa Palantir; llegan a Trakt
    40: ("Añadir a mi lista…", "plus", {_pal(30533), "añadir a lista trakt.tv personal...", "add to personal trakt.tv list..."},
         None),
    41: ("Valorar en Trakt", "star", {_pal(30035), "valorar en trakt.tv", "rate on trakt.tv"}, None),
    30: ("Marcar temporada como vista", "check", {_pal(30082), "marcar temporada como vista",
                                                    "mark season as watched"}, "Temporada marcada como vista"),
    31: ("Marcar temporada como no vista", "x", {_pal(30081), "marcar temporada como no vista",
                                                   "mark season as unwatched"}, "Temporada marcada como no vista"),
}


DIALOG_ACTIONS = (22, 40, 41)     # abren un diálogo de Palantir (22: «No seguir esta serie...» pregunta dónde)


def log(msg):
    xbmc.log("[flix_menu] %s" % msg, xbmc.LOGINFO)
    HOME.setProperty("flix_menu_log", msg[:500])     # legible por JSON-RPC (en Fire OS no se puede leer kodi.log)


class Menu(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.opts = kwargs.get("opts", [])
        self.choice = None

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        lst = self.getControl(9100)
        lst.reset()
        for act in self.opts:
            li = xbmcgui.ListItem(ACTIONS[act][0])
            li.setProperty("icon", ACTIONS[act][1])
            li.setProperty("act", str(act))
            lst.addItem(li)
        self.setFocusId(9100)

    def onClick(self, cid):
        if cid == 9100:
            item = self.getControl(9100).getSelectedItem()
            if item:
                self.choice = int(item.getProperty("act"))
                self.close()


def ctx_buttons():
    """{id: etiqueta} del menú contextual abierto"""
    out = {}
    for i in range(1000, 1040):
        lab = xbmc.getInfoLabel("Control.GetLabel(%d)" % i)
        if lab:
            out[i] = lab
    return out


def wait_for(pred, timeout):
    mon = xbmc.Monitor()
    end = time.time() + timeout
    while time.time() < end and not mon.abortRequested():
        if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            r = pred(ctx_buttons())
            if r:
                return r
        xbmc.sleep(150)
    return None


def press(cid):
    xbmc.executebuiltin("SetFocus(%d)" % cid)
    xbmc.sleep(120)
    xbmc.executebuiltin("Action(Select)")


DIALOGS = "Window.IsActive(contextmenu) | Window.IsActive(selectdialog) | Window.IsActive(yesnodialog) | " \
          "Window.IsActive(numericinput) | Window.IsActive(virtualkeyboard)"


def follow_dialog():
    """la opción pulsada abre un diálogo de Palantir (elegir lista, nota): se deja ver tal cual (flix_ctx_skip: el
    menú contextual que abre Palantir no se redirige al KER0N3 ni se vuelve transparente) hasta que se cierra"""
    mon = xbmc.Monitor()
    end = time.time() + 10
    while time.time() < end and not mon.abortRequested() and not xbmc.getCondVisibility(DIALOGS):
        xbmc.sleep(100)
    end = time.time() + 300
    while time.time() < end and not mon.abortRequested() and xbmc.getCondVisibility(DIALOGS):
        xbmc.sleep(200)
    HOME.clearProperty("flix_ctx_skip")


def run_palantir(words, dialog=False):
    """abre el menú de Kodi, entra en el de Palantir y pulsa la opción cuyo texto contiene todas las palabras.
    dialog=True: esa opción abre un diálogo de Palantir que el usuario tiene que ver (follow_dialog)"""
    HOME.setProperty("flix_ctx_auto", "1")
    try:
        if not focus_target():
            return False
        context_menu()
        sub = wait_for(lambda b: next((i for i, l in b.items() if SUBMENU_MARK in l), None), 6)
        if not sub:
            log("no aparece 'Menú Palantir 3'")
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        press(sub)

        def target(b):
            if not any(sig in l.lower() for l in b.values() for sig in SUBMENU_SIGN):
                return None              # aún es el menú de Kodi (mismas etiquetas, pero no llegan a Trakt)
            return next((i for i, l in b.items() if l.strip().lower() in words), -1)

        # Palantir puede tardar en abrir su submenú si sigue con la acción anterior (sincronizando con Trakt: hasta
        # ~17 s medidos en la Shield, 19-oct): antes se esperaba 12 s y salía «aún no está lista». Ahora hasta 30 s,
        # aviso a los 4 s y segunda pulsación a los 10 s si sigue el menú de Kodi.
        t0, warned, repressed, cid = time.time(), False, False, None
        while time.time() - t0 < 30:
            cid = wait_for(target, 1)
            if cid:
                break
            if not warned and time.time() - t0 > 4:
                warned = True
                xbmcgui.Dialog().notification("KER0N3 MEDIA", "Esperando a Palantir…",
                                              xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000, False)
            if not repressed and time.time() - t0 > 10:
                again = next((i for i, l in ctx_buttons().items() if SUBMENU_MARK in l), None)
                if again and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
                    repressed = True
                    log("Palantir no abre su submenú: segunda pulsación")
                    press(again)
        if not cid or cid < 0:
            log("Palantir no ofrece %s; opciones: %s" % (sorted(w for w in words if w), list(ctx_buttons().values())))
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        label = xbmc.getInfoLabel("Control.GetLabel(%d)" % cid)
        if dialog:
            HOME.setProperty("flix_ctx_skip", "1")
            press(cid)
            HOME.clearProperty("flix_ctx_auto")
            log("pulsado en Palantir: %s (diálogo de Palantir a la vista)" % label)
            xbmc.sleep(300)
            follow_dialog()
            return True
        press(cid)
        log("pulsado en Palantir: %s" % label)
        return True
    finally:
        if not dialog:
            xbmc.sleep(400)
        HOME.clearProperty("flix_ctx_auto")


def context_menu():
    """Action(ContextMenu) por detrás. En el Inicio táctil esa acción le llega TAMBIÉN a flix_home.py, a veces muchos
    segundos después (ventana ocupada repintando tras sincronizar con Trakt): se anota para que no la tome por un
    «mantener pulsado» y abra el menú de la carátula que haya bajo el dedo (Sunset Limited / Batman, móvil 20-oct)"""
    if CTX["list"]:
        try:
            sent = json.loads(HOME.getProperty("flix_ctx_sent") or "[]")
        except ValueError:
            sent = []
        HOME.setProperty("flix_ctx_sent", json.dumps(sent + [time.time()]))
    xbmc.executebuiltin("Action(ContextMenu)")


CTX = {"list": None, "path": ""}     # táctil: lista oculta (7990 de FlixHome.xml) donde está el título


def route_key(path):
    """(tipo, tmdb, temporada, capítulo) de una ruta de Palantir; None si no se puede leer"""
    try:
        info = ast.literal_eval(flix_rows.decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(info, dict) or not info.get("tmdb"):
        return None
    return (info.get("content"), str(info["tmdb"]), info.get("season"), info.get("episode"))


def focus_target():
    """Inicio táctil: el título no es un elemento de Kodi. Se espera a que la lista oculta cargue la fila, se coloca
    en el título y entonces Action(ContextMenu) abre el menú de Kodi de ESE elemento (como en la TV). Sin lista: nada"""
    lid, path = CTX["list"], CTX["path"]
    if not lid:
        return True
    mon, end = xbmc.Monitor(), time.time() + 25
    n = 0
    while time.time() < end and not mon.abortRequested():
        v = xbmc.getInfoLabel("Container(%s).NumItems" % lid)
        if v.isdigit() and int(v) > 0 and not xbmc.getCondVisibility("Container(%s).IsUpdating" % lid):
            n = int(v)
            break
        xbmc.sleep(150)
    paths = [xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).FileNameAndPath" % (lid, i)) for i in range(n)]
    idx = paths.index(path) if path in paths else -1
    if idx < 0:
        # la ruta lleva el estado (vista, %): tras marcar la película Palantir da otra y el Inicio táctil aún tiene
        # la vieja -> «no encuentro el título» al desmarcarla (Prácticamente magia 2, 20-oct). Se busca por TMDB
        want = route_key(path)
        idx = next((i for i, p in enumerate(paths) if want and route_key(p) == want), -1)
    if idx < 0:
        log("lista oculta %s: no encuentro el título (%d elementos)" % (lid, n))
        return False
    xbmc.executebuiltin("SetFocus(%s,%d,absolute)" % (lid, idx))
    end = time.time() + 3
    while time.time() < end and xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % lid) != paths[idx]:
        xbmc.sleep(100)
    return True


def run_kodi(words):
    """pulsa una opción del menú contextual de KODI (primer nivel, sin entrar en el de Palantir). Para «Quitar
    progreso»: Palantir borra su progreso y el de Trakt, pero el «Reanudar desde…» propio de Kodi (marcador local)
    seguía ahí y volvía a preguntar al reproducir (Shield, 19-oct)."""
    HOME.setProperty("flix_ctx_auto", "1")
    try:
        if not focus_target():
            return False
        context_menu()
        cid = wait_for(lambda b: next((i for i, l in b.items() if l.strip().lower() in words), None), 6)
        if not cid:
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        press(cid)
        log("pulsado en Kodi: %s" % xbmc.getInfoLabel("Control.GetLabel(%d)" % cid))
        return True
    finally:
        xbmc.sleep(400)
        HOME.clearProperty("flix_ctx_auto")


# ---------- estado real (watched.db de Palantir) ----------
def db_query(sql, args=()):
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            return db.execute(sql, args).fetchall()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def state_of(kind, info):
    """(firma comparable, props del menú, opciones)"""
    tmdb = str(info.get("tmdb") or "")
    if kind in ("movie", "episode"):
        if kind == "movie":
            rows = db_query("SELECT playcount, progress, runtime FROM movies_watched WHERE tmdb_id=?", (tmdb,))
        else:
            rows = db_query("SELECT playcount, progress, runtime FROM episodes_watched WHERE tmdb_id=? AND season=? "
                            "AND episode=?", (tmdb, info.get("season"), info.get("episode")))
        row = rows[0] if rows else None
        watched = int(row[0] or 0) if row else 0
        total = float(row[2] or 0) if row else 0.0
        total = total or float(info.get("duration") or 0)
        position = total * float(row[1] or 0) / 100 if row else 0.0
        started = position > 30 and (not total or position < total - 60)
        if started:
            sub = "Empezada  ·  %s de %s" % (flix_play.fmt(position), flix_play.fmt(total)) if total else "Empezada"
        else:
            sub = "Vista" if watched else "Sin empezar"
        if kind == "episode":
            sub = "T%s · E%s  ·  %s" % (info.get("season"), info.get("episode"), sub)
        opts = [11] if watched and not started else [10]
        if started:
            opts.append(12)
        if kind == "movie":
            opts += [41]          # 40 «Añadir a mi lista…» aparcado (Carlos, 19-oct): de momento solo la nota
        state = "started" if started else "watched" if watched else "new"
        props = {"fm_state": state, "fm_sub": sub,
                 "fm_pct": str(int(100 * position / total)) if started and total else "0"}
        return (watched, round(position)), props, opts
    if kind == "season":
        rows = db_query("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND season=? AND playcount>0",
                        (tmdb, info.get("season")))
        seen = rows[0][0] if rows else 0
        total = int(info.get("totalEpisodes") or 0)
        done = bool(total) and seen >= total
        props = {"fm_state": "watched" if done else "new",
                 "fm_sub": "Temporada %s  ·  %d de %d capítulos vistos" % (info.get("season"), seen, total)}
        return (seen,), props, [31] if done else [30]
    # serie
    rows = db_query("SELECT completa, num_total_episodios FROM shows_watched WHERE tmdb_id=?", (tmdb,))
    seen_rows = db_query("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND playcount>0", (tmdb,))
    seen = seen_rows[0][0] if seen_rows else 0
    done = bool(rows and rows[0][0])
    total = int(rows[0][1] or 0) if rows else 0
    sub = "%d de %d capítulos vistos" % (seen, total) if total else ("%d capítulos vistos" % seen if seen else "Sin empezar")
    props = {"fm_state": "watched" if done else "new", "fm_sub": sub}
    # «Dejar de seguir» solo si está en «Series en seguimiento»: sin fila (sin empezar) u oculta = nada que dejar
    following = follow_state(info) == (True, False)
    return (done, seen), props, ([21] if done else [20]) + ([22] if following else []) + [41]


def kind_of(info):
    return {"movies": "movie", "episodes": "episode", "seasons": "season", "tvshows": "show"}.get(info.get("content"))


def wait_applied(kind, info, before, timeout=30):
    """Palantir guarda el cambio unos segundos después (arranca su submenú y habla con Trakt; en Fire TV más):
    se espera a verlo en watched.db y entonces se ponen al día las filas / la lista (sin reiniciar Kodi)"""
    mon, start = xbmc.Monitor(), time.time()
    while time.time() - start < timeout and not mon.abortRequested():
        if state_of(kind, info)[0] != before:
            log("aplicado en %.1f s" % (time.time() - start))
            break
        xbmc.sleep(500)
    else:
        log("no veo el cambio en watched.db tras %d s" % timeout)
    HOME.setProperty("fh_progress", "1")             # Inicio táctil: repinta barras / ✓ (flix_home.py)
    if xbmcgui.getCurrentWindowId() == 10000:
        # las pasadas las hace flix_progress con su bloqueo (si ya está en marcha, repite al acabar): antes se
        # llamaba a one_pass() aquí en paralelo y dos procesos escribían la misma caché (auditoría PY-06/NUEVO-01)
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")
    else:
        xbmc.executebuiltin("Container.Refresh")     # temporadas / capítulos: Palantir vuelve a dar la lista


def follow_state(info):
    """(sigue en la tabla, oculta) de la serie en watched.db de Palantir"""
    rows = db_query("SELECT ocultar FROM shows_watched WHERE tmdb_id=?", (str(info.get("tmdb") or ""),))
    return (bool(rows), bool(rows and rows[0][0]))


def after_unfollow(info, before):
    """«No seguir esta serie…»: Palantir la marca (aquí = ocultar, en ningún dispositivo = también en Trakt) pero
    la fila «Series en seguimiento» sale de SU caché: se espera al cambio, se borra esa lista de cache.db y se
    recarga la fila (Carlos, 19-oct: «sigue ahí», a diferencia de las películas)"""
    mon, start = xbmc.Monitor(), time.time()
    while time.time() - start < 30 and not mon.abortRequested() and follow_state(info) == before:
        xbmc.sleep(500)
    changed = follow_state(info) != before
    log("dejar de seguir: %s en %.1f s" % ("aplicado" if changed else "sin cambio en watched.db", time.time() - start))
    if not changed:
        return False
    try:
        db = sqlite3.connect(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/cache.db"),
                             timeout=5)
        try:
            n = db.execute("DELETE FROM simplecache WHERE id LIKE '%SeriesSeguimiento%'").rowcount
            db.commit()
        finally:
            db.close()
        log("caché de Series en seguimiento borrada (%d)" % n)
    except Exception as e:  # noqa: BLE001
        log("no borro la caché de Series en seguimiento: %s" % e)
    HOME.setProperty("flix_rl_p3PathSeriesSeguimiento", str(int(time.time() * 10)))   # recarga esa fila
    HOME.setProperty("fh_refetch_row", "5102")        # Inicio táctil (flix_home.py): vuelve a pedir esa fila
    return True


def native_menus():
    """menú contextual de siempre UNA vez (series, o lo que no es una película de Palantir). Si en él se entra en
    "Menú Palantir 3..." el permiso dura también para ese submenú; al cerrarse, el siguiente vuelve a ser el KER0N3.
    (Antes duraba hasta 5 s con todo cerrado: reabrir enseguida volvía a dar el de Kodi una y otra vez.)"""
    HOME.setProperty("flix_ctx_skip", "1")
    mon = xbmc.Monitor()

    def wait_open(timeout):
        end = time.time() + timeout
        while time.time() < end and not mon.abortRequested():
            if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
                return True
            xbmc.sleep(100)
        return False

    def wait_closed():
        """espera a que se cierre; devuelve la última opción con foco"""
        last = ""
        while not mon.abortRequested() and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            cid = xbmc.getInfoLabel("System.CurrentControlId")
            if cid:
                last = xbmc.getInfoLabel("Control.GetLabel(%s)" % cid) or last
            xbmc.sleep(100)
        return last

    try:
        if not focus_target():
            return False
        context_menu()
        if not wait_open(4):
            return
        last = wait_closed()
        if SUBMENU_MARK in last and wait_open(10):     # entró en el submenú de Palantir
            wait_closed()
    finally:
        HOME.clearProperty("flix_ctx_skip")


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    art = sys.argv[2] if len(sys.argv) > 2 else ""
    label = sys.argv[3] if len(sys.argv) > 3 else ""
    if len(sys.argv) > 4 and sys.argv[4].isdigit():    # Inicio táctil: lista oculta con la fila (flix_home.py)
        CTX["list"], CTX["path"] = sys.argv[4], path
    if CTX["list"]:
        HOME.setProperty("flix_menu_busy", "1")      # flix_home.py no toma nuestro Action(ContextMenu) por un toque
        try:
            return run_menu(path, art, label)
        finally:
            # el Action(ContextMenu) le llega a flix_home.py con retraso: 2,5 s más de margen (marca con la hora)
            HOME.setProperty("flix_menu_busy", "t%f" % time.time())
            xbmc.executebuiltin("SetFocus(7000)")    # foco de vuelta a las filas (no en la lista oculta)
    return run_menu(path, art, label)


def run_menu(path, art, label):
    if not path:
        # Inicio: el menú contextual no ve la carátula con foco -> la de la fila que lo tiene (flix_row)
        row = HOME.getProperty("flix_row")
        if row:
            c = "Container(%s).ListItem." % row
            path = xbmc.getInfoLabel(c + "FileNameAndPath")
            art = xbmc.getInfoLabel(c + "Art(poster)") or xbmc.getInfoLabel(c + "Art(tvshow.poster)")
            label = xbmc.getInfoLabel(c + "Label")
    info = {}
    if path.startswith("plugin://plugin.video.palantir3/"):
        try:
            info = ast.literal_eval(flix_rows.decode_route(path))
        except Exception:  # noqa: BLE001
            info = {}
    kind = kind_of(info) if isinstance(info, dict) else None
    if not kind:
        native_menus()      # menús de Palantir, carpetas...: el de siempre
        return
    before, props, opts = state_of(kind, info)
    if kind == "episode":
        name = flix_play.COLOR_RE.sub("", label).strip()
        if name:
            props["fm_sub"] = "%s  ·  %s" % (name, props["fm_sub"].split("  ·  ", 1)[-1])
    if kind == "episode":
        title = info.get("tvshowtitle") or ""
    elif kind == "season":
        title = info.get("tvshowtitle") or ""
    else:
        title = info.get("title") or info.get("tvshowtitle") or flix_play.COLOR_RE.sub("", info.get("label") or "")
    # capítulos: la ruta no trae carátula -> la de la serie (la pone flix_series.py al abrirla)
    poster = flix_play._img(info.get("poster")) or art or HOME.getProperty("flix_poster")
    props.update({"fm_title": title.strip(), "fm_poster": poster,
                  "fm_fanart": flix_play._img(info.get("fanart"))})
    w = Menu("FlixMenu.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props, opts=opts)
    w.doModal()
    choice = w.choice
    del w
    if choice not in ACTIONS:
        return
    xbmc.sleep(250)                          # que el foco vuelva a la carátula antes de abrir menús
    follow_before = follow_state(info) if choice == 22 else None
    ok = run_palantir(ACTIONS[choice][2], dialog=choice in DIALOG_ACTIONS)
    if ok and choice == 22:
        if after_unfollow(info, follow_before):
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "Serie quitada de Series en seguimiento",
                                          xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)
        return
    if ok and choice == 12:
        xbmc.sleep(500)
        run_kodi(ACTIONS[12][2])        # también el «Reanudar desde…» de Kodi (si no hay, no pasa nada)
    done = ACTIONS[choice][3]
    if ok and done:
        wait_applied(kind, info, before)
    if done or not ok:
        xbmcgui.Dialog().notification("KER0N3 MEDIA", done if ok else "Palantir está ocupado (sincronizando con Trakt). Inténtalo en unos segundos",
                                      xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)


if __name__ == "__main__":
    main()
