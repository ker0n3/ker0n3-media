"""Editor único: fuentes de cada nivel (Ajustes → «Personalizar menú e Inicio» y «Nota de los títulos»).
Todas con el mismo contrato, que usa flix_editor.py:
  title() · help(touch) · load() -> elementos (flix_editor_core.item) · save(elementos) (al momento)
  count(elementos, touch) · buttons(elementos, touch) -> [(acción, texto)]
  press(acción, elementos, k, ui) -> (elementos, posición) o None · check_toggle(elementos, k, ui) -> bool
  child(elemento) -> fuente o None · reset() -> elementos · decorate(elementos) · on_exit()
Lo que toca Kodi va en los *Store (en tests, falsos); ui = diálogos (notify, confirm, pick, browse, ask_key, busy)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_editor_core as core  # noqa: E402
import flix_home_conf as hc  # noqa: E402
import flix_sections  # noqa: E402
import flix_sections_conf as sc  # noqa: E402

NO_ANSWER = flix_sections.NO_ANSWER
NO_ROWS = "Palantir no ha dado filas para esta sección ahora"
EXPLORE = "Explorar Palantir…"
INICIO_ICON = "flix/icons/inicio.png"
MOVING_HELP = "Arriba / abajo: mover · OK: soltar"


class Source:
    toggle_labels = ("Ocultar", "Mostrar")
    remove_label = "Quitar"
    can_rename = False
    HELP = ("", "")          # (TV, táctil)

    def help(self, touch):
        return self.HELP[1 if touch else 0]

    def decorate(self, items):
        return items

    def check_toggle(self, items, k, ui):
        return True

    def child(self, it):
        return None

    def press(self, action, items, k, ui):
        return None

    def on_exit(self):
        pass

    def rename(self, items, k, new):
        """nombre que se ve; vacío = el de Palantir (orig)"""
        items[k]["label"] = new or items[k]["orig"]
        return items


# ---------- menú (sections.json) ----------
class SectionsStore:
    """sections.json, el menú y Palantir (lo que toca Kodi de las secciones)"""

    def load(self):
        return flix_sections.load_conf()

    def save(self, conf):
        flix_sections.save_conf(conf)

    def apply(self, conf):
        flix_sections.apply(conf)

    def menu(self, path):
        return flix_sections.palantir_menu(path)

    def section_rows(self, src):
        import flix_rows
        return flix_rows.section_rows(src, stale_ok=True)


class MenuSource(Source):
    level = "menu"
    can_rename = True
    HELP = ("OK: opciones de la sección (editar filas, mover, cambiar nombre, ocultar, quitar) · Atrás: salir[CR]"
            "Inicio va siempre primero: OK en Inicio abre sus filas.",
            "Las flechas ordenan, el interruptor enseña u oculta, «Filas» elige qué sale dentro y tocar el nombre lo cambia. "
            "En el móvil se ven las 7 primeras activas.")

    def __init__(self, store=None):
        self.store = store or SectionsStore()
        self._home = None

    def title(self):
        return "Personalizar menú e Inicio"

    def items_of(self, conf):
        out = [core.item("inicio", "Inicio", icon=INICIO_ICON, fixed=True, kids=True)]
        for s in conf["sections"]:
            added = s["key"].startswith("p3:")
            notes = (("sin especial ahora", bool(s.get("gone"))), ("añadida", added), ("rejilla", s["kind"] == "list"))
            note = " · ".join(x for x, c in notes if c)
            out.append(core.item(s["key"], sc.shown(s), on=s["on"], icon=s.get("icon", ""), removable=added,
                                 kids=s["kind"] == "rows", note=note, raw=s, orig=s["label"]))
        return out

    def load(self):
        return self.items_of(self.store.load())

    def conf_of(self, items):
        out = []
        for it in items:
            if it["fixed"]:
                continue
            s = {k: v for k, v in it["raw"].items() if k not in ("name", "name_for")}
            s["on"] = it["on"]
            if it["label"] != it["orig"]:
                s.update(name=it["label"], name_for=it["orig"])
            out.append(s)
        return {"sections": out}

    def save(self, items):
        conf = self.conf_of(items)
        self.store.save(conf)
        self.store.apply(conf)

    def count(self, items, touch):
        return flix_sections.count_text(len(sc.active(self.conf_of(items))), touch)    # sin las «Especial» escondidas

    def buttons(self, items, touch):
        return [("add", "Añadir sección"), ("reset", "Restablecer")]

    def check_toggle(self, items, k, ui):
        if not items[k]["on"] and core.active_count(items) >= sc.MAX_SECTIONS:
            ui.notify("Caben %d secciones: desactiva otra antes" % sc.MAX_SECTIONS)
            return False
        return True

    def child(self, it):
        if it["id"] == "inicio":
            self._home = self._home or HomeRowsSource()      # una sola: al salir, una sola recarga del Inicio
            return self._home
        if it["kids"]:
            return SectionRowsSource(it["id"], it["label"], it["raw"]["src"], self.store)
        return None

    def reset(self):
        return self.items_of(sc.default_conf(set()))

    def press(self, action, items, k, ui):
        if action == "add":
            return self.add(items, k, ui)
        if action == "remove":
            it = items[k]
            if not it["removable"] or not ui.confirm(
                    "¿Quitar «%s» del menú?[CR]Podrás volver a añadirla con «Añadir sección»." % it["label"]):
                return None
            del items[k]
            return items, min(k, len(items) - 1)
        return None

    def add(self, items, k, ui):
        if core.active_count(items) >= sc.MAX_SECTIONS:
            ui.notify("Caben %d secciones: desactiva otra antes" % sc.MAX_SECTIONS)
            return None
        folders, _ = hc.classify(self.store.menu(flix_sections.PALANTIR_ROOT))
        if not folders:
            ui.notify(NO_ANSWER)
            return None
        cands = sc.candidates(self.conf_of(items), [{"label": f["label"], "path": f["file"]} for f in folders])
        if not cands:
            ui.notify("Ya están todas las secciones de Palantir")
            return None
        c = ui.pick("Añadir sección", [x["label"] for x in cands], "Entradas del menú principal de Palantir")
        if c < 0:
            return None
        kind = flix_sections.kind_of(self.store.menu(cands[c]["path"]))
        if kind is None:
            ui.notify(NO_ANSWER)
            return None
        new = sc.new_section(cands[c]["label"], cands[c]["path"], kind)
        at = max(k, 0) + 1
        items[at:at] = self.items_of({"sections": [new]})[1:]
        ui.notify("«%s» añadida%s" % (new["label"], " (rejilla de títulos)" if kind == "list" else ""))
        return items, at


# ---------- filas de una sección (sections.json, "rows") ----------
class SectionRowsSource(Source):
    level = "rows"
    can_rename = True
    HELP = ("Filas que salen al abrir la sección, en este orden.[CR]OK: mover, cambiar nombre u ocultar · Atrás: volver al menú",
            "Filas que salen al abrir la sección, en este orden. Las flechas ordenan, el interruptor enseña u oculta y tocar el nombre lo cambia.")

    def __init__(self, key, label, src, store):
        self.key, self.label, self.src, self.store = key, label, src, store
        self.labels = []

    def title(self):
        return "Filas de %s" % self.label

    def load(self):
        rows = self.store.section_rows(self.src)
        self.labels = [r["label"] for r in rows]
        sec = flix_sections.section(self.key, self.store.load()) or {"rows": {}}
        names = (sec.get("rows") or {}).get("names") or {}
        return [core.item(l, names.get(l, l), on=on, orig=l) for l, on in sc.row_editor_items(rows, sec["rows"])]

    def save(self, items):
        conf = self.store.load()
        for s in conf["sections"]:
            if s["key"] == self.key:
                s["rows"] = flix_sections.rows_conf([(it["id"], it["on"]) for it in items])
                names = {it["id"]: it["label"] for it in items if it["label"] != it["orig"]}
                if names:
                    s["rows"]["names"] = names
        self.store.save(conf)

    def count(self, items, touch):
        return "%d de %d filas" % (core.active_count(items), len(items))

    def buttons(self, items, touch):
        return [("reset", "Restablecer")]

    def reset(self):
        return [core.item(l, l) for l in self.labels]


# ---------- filas del Inicio (home_order.json) ----------
class HomeStore:
    """home_order.json y el Inicio (lo que toca Kodi de las filas del Inicio)"""

    def defaults(self):
        import flix_home_order
        return flix_home_order.default_rows()

    def load(self):
        import flix_home_order
        return flix_home_order.load_conf() or hc.normalize(None)

    def save(self, conf):
        import flix_home_order
        flix_home_order.save_conf(conf)

    def apply(self):
        import flix_home_order
        flix_home_order.apply_saved()


class HomeRowsSource(Source):
    level = "home"
    can_rename = True
    remove_label = "Eliminar"
    HELP = ("OK: opciones de la fila (mover, cambiar nombre, ocultar, eliminar) · Atrás: volver al menú",
            "Las flechas ordenan, el interruptor enseña u oculta, tocar el nombre lo cambia y la papelera la quita.")

    def __init__(self, store=None):
        self.store = store or HomeStore()
        self.defaults, self.items_n, self.initial = [], hc.DEFAULT_ITEMS, None

    def title(self):
        return "Filas del Inicio"

    def items_of(self, conf):
        self.items_n = conf["items"]
        return [core.item(r["id"], r.get("title") or r["label"], on=not r["hidden"], removable=True,
                          note="añadida" if r["custom"] else "", raw=r, orig=r["label"])
                for r in hc.compose(self.defaults, conf)]

    def load(self):
        self.defaults = self.store.defaults()
        conf = self.store.load()
        if self.initial is None:
            self.initial = hc.signature(conf)               # al salir: recargar el Inicio solo si cambió
        return self.items_of(conf)

    def conf_of(self, items):
        present = {it["id"] for it in items}
        return hc.normalize({
            "order": [it["id"] for it in items],
            "hidden": [it["id"] for it in items if not it["on"]],
            "deleted": [d["id"] for d in self.defaults if d["id"] not in present],
            "custom": [{"id": it["id"], "label": it["orig"], "path": it["raw"]["path"]}
                       for it in items if it["raw"]["custom"]],
            "names": {str(it["id"]): it["label"] for it in items if it["label"] != it["orig"]},
            "items": self.items_n,
        })

    def save(self, items):
        self.store.save(self.conf_of(items))

    def count(self, items, touch):
        return "%d de %d filas" % (len(items), hc.MAX_ROWS)

    def buttons(self, items, touch):
        return [("add", "Añadir fila"), ("items", "Títulos por fila: %d" % self.items_n), ("reset", "Restablecer")]

    def visible(self, items):
        return len([it for it in items if it["on"]])

    def check_toggle(self, items, k, ui):
        if items[k]["on"] and self.visible(items) == 1:
            ui.notify("Tiene que quedar al menos una fila visible")
            return False
        return True

    def reset(self):
        return self.items_of(hc.normalize(None))

    def press(self, action, items, k, ui):
        if action == "items":
            self.items_n = hc.next_items(self.items_n)
            return items, k
        if action == "remove":
            it = items[k]
            if it["on"] and self.visible(items) == 1:
                ui.notify("Tiene que quedar al menos una fila visible")
                return None
            if not ui.confirm("¿Quitar «%s» del Inicio?[CR]Podrás volver a añadirla con «Añadir fila»." % it["label"]):
                return None
            del items[k]
            return items, min(k, len(items) - 1)
        if action == "add":
            return self.add(items, k, ui)
        return None

    def add(self, items, k, ui):
        if len(items) >= hc.MAX_ROWS:
            ui.notify("Máximo %d filas: elimina alguna para añadir otra" % hc.MAX_ROWS)
            return None
        present = {it["id"] for it in items}
        missing = [d for d in self.defaults if d["id"] not in present]
        c = ui.pick("Añadir fila", [d["label"] for d in missing] + [EXPLORE],
                    "Filas de serie que no están en el Inicio, o cualquier menú de Palantir.")
        if c < 0:
            return None
        if c < len(missing):
            raw = dict(missing[c], custom=False, hidden=False)
        else:
            got = ui.browse()
            if not got:
                return None
            used = {it["id"] for it in items if it["raw"]["custom"]}
            free = [i for i in hc.CUSTOM_IDS if i not in used]
            raw = {"id": free[0], "label": got[0], "path": got[1], "custom": True, "hidden": False, "top10": False}
        at = max(k, 0) + 1
        items.insert(at, core.item(raw["id"], raw["label"], removable=True,
                                   note="añadida" if raw["custom"] else "", raw=raw))
        ui.notify("«%s» añadida" % raw["label"])
        return items, at

    def on_exit(self):
        if self.initial is not None and hc.signature(self.store.load()) != self.initial:
            self.store.apply()


# ---------- nota de los títulos (Skin.String) ----------
class RatingsStore:
    """ajustes de la skin de «Nota de los títulos» (flix_ratings)"""

    def read_key(self):
        import flix_ratings
        return flix_ratings.read_key()

    def read_order(self, key):
        import flix_ratings
        return flix_ratings.read_order(key)

    def save(self, key, order):
        import flix_ratings
        flix_ratings.save_settings(key, order)


class RatingsSource(Source):
    level = "ratings"
    toggle_labels = ("Desactivar", "Activar")
    HELP = ("Cada título enseña la nota de la primera fuente encendida que la tenga. TMDB es la predefinida: lo que "
            "quede debajo no se usa.[CR]OK: mover, activar o desactivar · Derecha: clave de MDBList",
            "Cada título enseña la nota de la primera fuente encendida que la tenga. TMDB es la predefinida: lo que "
            "quede debajo no se usa.")

    def __init__(self, store=None):
        self.store = store or RatingsStore()
        self.key = ""

    def title(self):
        return "Nota de los títulos"

    def items_of(self, order):
        import flix_ratings as fr
        return self.decorate([core.item(k, fr.LABEL[k], on=on) for k, on in order])

    def load(self):
        self.key = self.store.read_key()
        return self.items_of(self.store.read_order(self.key))

    @staticmethod
    def order(items):
        return [(it["id"], it["on"]) for it in items]

    def decorate(self, items):
        import flix_ratings as fr
        order = self.order(items)
        for it in items:
            it["note"] = fr.row_note(order, it["id"], self.key)
        return items

    def save(self, items):
        self.store.save(self.key, self.order(items))

    def count(self, items, touch):
        import flix_ratings as fr
        return fr.summary(self.order(items), self.key)

    def buttons(self, items, touch):
        import flix_ratings as fr
        return [("key", ("Clave: %s" if touch else "Clave de MDBList: %s") % fr.mask(self.key)),
                ("reset", "Restablecer")]

    def check_toggle(self, items, k, ui):
        import flix_ratings as fr
        if items[k]["id"] == fr.TMDB:
            ui.notify("TMDB no se puede apagar: es la predefinida")
            return False
        if not items[k]["on"] and not self.key:
            new = ui.ask_key("")
            if not new:
                return False
            self.key = new
        return True

    def press(self, action, items, k, ui):
        if action == "key":
            new = ui.ask_key(self.key)
            if new is None:
                return None
            self.key = new
            return items, k
        return None

    def reset(self):
        import flix_ratings as fr
        return self.items_of(list(fr.DEFAULT))
