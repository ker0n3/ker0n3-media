"""Aviso diario de uso (estadísticas de Carlos en el Worker de Cloudflare, /_stats): una vez al día, al arrancar,
manda id aleatorio del aparato + skin (tv / tactil) + versión. Va por la conexión de Kodi (xbmcvfs), así el Worker
sabe la plataforma por su User-Agent (Shield, Fire TV, Android…). Anónimo: el id lo genera la skin al azar y el
Worker solo guarda un hash; no se guarda la IP. El repositorio NO pasa por Cloudflare (va directo a GitHub): si el
Worker está caído o bloqueado (partidos), no pasa nada; ese día no se cuenta.
Lo llama first_run.py."""
import datetime
import os
import uuid

URL = "https://ker0n3-media.ker0n3.workers.dev/ping"


def ping_url(device, touch, version):
    return "%s?d=%s&s=%s&v=%s" % (URL, device, "tactil" if touch else "tv", version)


def device_id(folder):
    """id aleatorio del aparato, guardado en addon_data de la skin (sobrevive a actualizaciones)"""
    path = os.path.join(folder, "device_id")
    try:
        with open(path, encoding="utf-8") as fh:
            d = fh.read().strip()
        if len(d) == 32 and all(c in "0123456789abcdef" for c in d):
            return d
    except OSError:
        pass
    d = uuid.uuid4().hex
    try:
        os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(d)
    except OSError:
        pass
    return d


def main():
    import xbmc
    import xbmcaddon
    import xbmcvfs
    today = datetime.date.today().isoformat()
    if xbmc.getInfoLabel("Skin.String(flix_ping_day)") == today:
        return
    skin = xbmc.getSkinDir()
    xbmc.executebuiltin("Skin.SetString(flix_ping_day,%s)" % today)     # como mucho un intento al día
    try:
        version = xbmcaddon.Addon(skin).getAddonInfo("version")
        folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % skin)
        f = xbmcvfs.File(ping_url(device_id(folder), skin.endswith(".touch"), version))
        f.read()
        f.close()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_ping] %s" % e, xbmc.LOGINFO)
