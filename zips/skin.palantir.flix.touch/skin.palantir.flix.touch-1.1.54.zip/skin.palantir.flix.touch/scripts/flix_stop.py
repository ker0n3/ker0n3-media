"""Parada diferida al salir del vídeo (VideoFullScreen.xml: onunload -> AlarmClock de 1 s -> este script).

Para solo si de verdad se ha salido de la reproducción. Al recargar la skin (actualización automática) Kodi descarga y
vuelve a cargar la pantalla del vídeo: el onunload salta igual y la película se cortaba (auditoría 22-oct A-05)."""
import xbmc

if xbmc.getCondVisibility("Player.HasMedia") and \
        not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd)"):
    xbmc.executebuiltin("PlayerControl(Stop)")
