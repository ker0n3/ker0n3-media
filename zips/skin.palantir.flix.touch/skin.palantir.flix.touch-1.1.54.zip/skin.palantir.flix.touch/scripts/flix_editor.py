"""Editor único: Ajustes → «Personalizar menú e Inicio» (secciones del menú, filas del Inicio y filas de cada sección)
y «Nota de los títulos». Una ventana (FlixEditor.xml de tools/gen_editor.py) con una pila de niveles; cada nivel es
una fuente de flix_editor_sources y la lista se maneja con flix_editor_core (lógica pura, con tests).
TV: OK = menú corto de la fila (Editar filas · Mover · Cambiar nombre · Ocultar/Mostrar · Quitar); en «Mover», arriba/abajo llevan la
fila y OK o Atrás la sueltan. Nada usa mantener OK (mandos viejos, CEC). Táctil: flechas, interruptor, papelera y
«Filas» en cada fila (huecos fijos), un toque por acción. Cada cambio se guarda al momento; Restablecer solo toca la
lista abierta. Al cerrar, cada fuente visitada hace lo suyo (el Inicio de la TV se rehace y recarga si cambió).
Uso: RunScript(special://skin/scripts/flix_editor.py,menu)  ·  RunScript(special://skin/scripts/flix_editor.py,ratings)"""
import os
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_editor_core as core  # noqa: E402
import flix_editor_sources as sources  # noqa: E402

A_UP, A_DOWN = 3, 4
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)


def log(msg):
    import xbmc
    xbmc.log("[flix_editor] %s" % msg, xbmc.LOGINFO)


class UI:
    """diálogos que piden las fuentes"""

    def __init__(self, title):
        self.title = title

    def notify(self, msg, ms=2500):
        import xbmcgui
        xbmcgui.Dialog().notification(self.title, msg, xbmcgui.NOTIFICATION_INFO, ms)

    def confirm(self, msg):
        import xbmcgui
        return xbmcgui.Dialog().yesno(self.title, msg)

    def pick(self, title, labels, help_text=""):
        import flix_picker
        return flix_picker.pick(title, labels, help_text)

    def busy(self, on):
        import flix_picker
        flix_picker.busy(on)

    def browse(self):
        import flix_palantir_browse
        return flix_palantir_browse.browse()

    def input(self, title, default):
        import xbmcgui
        return xbmcgui.Dialog().input(title, defaultt=default)

    def ask_key(self, key):
        import xbmcgui
        import flix_ratings
        return flix_ratings.ask_key(xbmcgui, key)


def run(kind):
    import xbmc
    import xbmcgui
    import xbmcvfs

    touch = xbmc.getSkinDir().endswith(".touch")
    root = sources.RatingsSource() if kind == "ratings" else sources.MenuSource()
    ui = UI(root.title())

    class EditorWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.source, self.items, self.pos = root, root.load(), 0
            self.stack, self.visited = [], [root]          # niveles de arriba [(fuente, posición)] / fuentes abiertas
            self.moving, self.opts, self.lst, self.buttons = False, [], None, []

        def onInit(self):
            if not touch:
                self.lst = self.getControl(core.LIST)
            self.refill(0)

        # ---------- pintar ----------
        def header(self):
            s = self.source
            self.setProperty("title", s.title())
            self.setProperty("help", sources.MOVING_HELP if self.moving else s.help(touch))
            self.setProperty("count", s.count(self.items, touch))
            self.setProperty("moving", "1" if self.moving else "")
            self.buttons = s.buttons(self.items, touch)
            for n in range(len(core.BTN_IDS)):
                self.setProperty("b%d" % (n + 1), self.buttons[n][1] if n < len(self.buttons) else "")

        def list_item(self, it, li=None):
            li = li or xbmcgui.ListItem()
            li.setLabel(it["label"])
            li.setLabel2(core.note_of(it))
            li.setArt({"icon": it["icon"] or ("" if it["fixed"] else core.GRIP)})
            li.setProperty("off", "" if it["on"] else "1")
            li.setProperty("tg", "" if it["fixed"] else "1")
            li.setProperty("kids", "1" if it["kids"] else "")
            return li

        def paint_touch(self):
            sep = core.separator_index(self.items, sources.sc.TOUCH_MAX) if self.source.level == "menu" else None
            for k, v in core.slot_props(self.items, core.SLOTS, sep, self.source.can_rename).items():
                self.setProperty(k, v)

        def focus_slot(self, k):
            """táctil: foco en un botón visible del hueco k (el grouplist se desplaza hasta él)"""
            if 0 <= k < len(self.items):
                xbmc.sleep(30)                             # que la visibilidad de los huecos se ponga al día
                self.setFocusId(core.SLOT0 + 10 * k + (5 if self.items[k]["fixed"] else 1))

        def refill(self, pos):
            """lista entera: al cambiar de nivel o de número de elementos"""
            self.pos = max(0, min(pos, len(self.items) - 1))
            self.header()
            if touch:
                if len(self.items) > core.SLOTS:
                    ui.notify("En el editor caben las %d primeras" % core.SLOTS)
                self.paint_touch()
                self.focus_slot(self.pos)
                return
            self.lst.reset()
            self.lst.addItems([self.list_item(it) for it in self.items])
            self.lst.selectItem(self.pos)
            self.setFocusId(core.LIST)

        def paint(self):
            """mismos elementos, en el sitio: rehacer la lista con el mando en marcha se come la pulsación siguiente"""
            self.header()
            if touch:
                self.paint_touch()
                return
            for k, it in enumerate(self.items):
                self.list_item(it, self.lst.getListItem(k))

        # ---------- cambios (se guardan al momento) ----------
        def commit(self, pos=None, full=False):
            self.source.decorate(self.items)
            try:
                self.source.save(self.items)
            except OSError as e:
                log("no se pudo guardar: %s" % e)
                ui.notify("No se pudo guardar")
            if full:
                self.refill(self.pos if pos is None else pos)
            else:
                self.paint()

        def step(self, d):
            j = core.move(self.items, self.pos, d)
            if j == self.pos:
                return
            self.pos = j
            self.commit()
            if touch:
                self.focus_slot(j)
                self.setProperty("hl", str(j))             # la fila se ilumina un momento en su sitio nuevo
                threading.Timer(0.7, lambda: self.setProperty("hl", "")).start()
            else:
                self.lst.selectItem(j)                     # asíncrono: la posición buena es self.pos

        def toggle(self, k):
            if self.items[k]["fixed"] or not self.source.check_toggle(self.items, k, ui):
                return
            core.toggle(self.items, k)
            self.pos = k
            self.commit()

        def rename(self, k):
            """teclado de Kodi con el nombre actual; vacío = el de Palantir (Kodi también da vacío con Atrás:
            por eso se pregunta antes de volver al original)"""
            it = self.items[k]
            new = (ui.input("Nombre (vacío = el de Palantir)", it["label"]) or "").strip()
            if not new and (it["label"] == it["orig"] or
                            not ui.confirm("¿Volver al nombre de Palantir?[CR]«%s»" % it["orig"])):
                return
            if new == it["label"]:
                return
            self.items = self.source.rename(self.items, k, new)
            self.pos = k
            self.commit()

        def press(self, action, k):
            if action == "reset":
                if ui.confirm("¿Volver a como viene de serie?[CR]Solo esta lista."):
                    self.items = self.source.reset()
                    self.commit(0, full=True)
                return
            before = len(self.items)
            got = self.source.press(action, self.items, k, ui)
            if got:
                self.items, pos = got
                self.commit(pos, full=len(self.items) != before)

        # ---------- niveles ----------
        def open(self, k):
            child = self.source.child(self.items[k])
            if not child:
                return
            ui.busy(True)
            try:
                items = child.load()
            except Exception as e:  # noqa: BLE001
                log("%s: %s" % (child.title(), e))
                items = None
            finally:
                ui.busy(False)
            if items is None:
                ui.notify(sources.NO_ANSWER)
                return
            if not items:
                ui.notify(sources.NO_ROWS)
                return
            self.stack.append((self.source, k))
            self.source, self.items, self.moving = child, items, False
            if child not in self.visited:
                self.visited.append(child)
            self.refill(0)

        def back(self):
            if self.opts:
                self.close_menu()
                return
            if self.moving:
                self.moving = False
                self.paint()
                return
            if not self.stack:
                self.close()
                return
            parent, k = self.stack.pop()
            self.source, self.moving = parent, False
            self.items = parent.load()                     # lo de abajo pudo cambiar los ficheros
            self.refill(k)

        # ---------- TV: menú corto ----------
        def show_menu(self, k):
            self.pos = k
            self.opts = core.options(self.items[k], self.source.toggle_labels, self.source.remove_label, self.source.can_rename)
            if not self.opts:
                return
            menu = self.getControl(core.MENU)
            menu.reset()
            menu.addItems([xbmcgui.ListItem(lab) for _, lab in self.opts])
            h = len(self.opts) * core.TV_H + 24
            self.getControl(core.MENU_BG).setHeight(h)
            row = int(xbmc.getInfoLabel("Container(%d).Position" % core.LIST) or 0)
            self.getControl(core.MENU_GROUP).setPosition(core.MENU_X, min(core.TV_TOP + row * core.TV_H, 1040 - h))
            self.setProperty("menu", "1")
            self.setFocusId(core.MENU)

        def close_menu(self):
            self.opts = []
            self.setProperty("menu", "")
            self.setFocusId(core.LIST)

        def choose(self, action):
            k = self.pos
            if action == "open":
                self.open(k)
            elif action == "move":
                self.moving = True
                self.paint()
            elif action == "toggle":
                self.toggle(k)
            elif action == "rename":
                self.rename(k)
            elif action == "remove":
                self.press("remove", k)

        # ---------- eventos ----------
        def onAction(self, action):
            aid = action.getId()
            if aid in A_BACK:
                self.back()
                return
            if self.moving and not touch:
                if aid in (A_UP, A_DOWN):
                    self.step(-1 if aid == A_UP else 1)
                return                                     # moviendo: izquierda / derecha no hacen nada
            super().onAction(action)

        def onClick(self, cid):
            if cid == core.LIST:
                k = self.lst.getSelectedPosition()
                if self.moving:
                    self.moving = False                    # OK: soltar
                    self.paint()
                    return
                if self.items[k]["fixed"] and self.items[k]["kids"]:
                    self.open(k)                           # Inicio: directo a sus filas
                else:
                    self.show_menu(k)
            elif cid == core.MENU:
                action = self.opts[self.getControl(core.MENU).getSelectedPosition()][0]
                self.close_menu()
                self.choose(action)
            elif cid in core.BTN_IDS:
                n = core.BTN_IDS.index(cid)
                if n < len(self.buttons):
                    self.press(self.buttons[n][0], self.pos if touch else max(0, self.lst.getSelectedPosition()))
            elif cid >= core.SLOT0:
                k, b = divmod(cid - core.SLOT0, 10)
                if k >= len(self.items):
                    return
                self.pos = k
                if b in (1, 2):
                    self.step(-1 if b == 1 else 1)
                elif b == 3:
                    self.toggle(k)
                elif b == 4:
                    self.press("remove", k)
                elif b == 5:
                    self.open(k)
                elif b == 6:
                    self.rename(k)

    w = EditorWindow("FlixEditor.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    w.doModal()
    visited = list(w.visited)
    del w
    for s in visited:
        try:
            s.on_exit()
        except Exception as e:  # noqa: BLE001
            log("al salir de %s: %s" % (s.title(), e))


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "menu")
