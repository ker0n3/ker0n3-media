"""Secciones de Palantir desplegadas en filas (compartido TV / táctil).

section_rows(var) lee el menú de una sección (rutas fijas p3Peliculas… de Includes_Palantir3.xml) y lo
convierte en filas:
  kind "list" = listado de títulos (action listado_peliculaS / listado_serieS) -> fila de carátulas
  kind "coll" = submenú (sagas, especiales, calidad, géneros, alfabético…) -> fila de tarjetas; al abrir
               una tarjeta se ve su rejilla de carátulas (vista 51)
Las cabeceras ("Películas de Dibujos:") agrupan; "Buscar por título" se omite (ya está el buscador).
fetch() cachea en disco 30 min: cada llamada a Palantir consulta además la API de GitHub (60/h por IP).
peek() da lo guardado aunque esté caducado (las secciones lo enseñan al momento y refrescan por detrás).
Con save=False fetch() no escribe el fichero: el que llama hace flush() cada pocas filas (antes se reescribían
~2,6 MB tras cada fila). flush() quita lo de más de un día y escribe de forma atómica.
"""
import base64
import json
import math
import os
import re
import time
import urllib.parse
import sys

import xbmc
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import COLOR_RE, clean, decode_route  # noqa: E402,F401
import flix_cache  # noqa: E402

CACHE_TTL = 1800            # filas personales (Seguir viendo, Series en seguimiento…): cambian al ver algo
STATIC_TTL = 6 * 3600       # las demás (Top 10, novedades, plataformas, géneros…): como mucho cambian a diario.
# Cada fila pedida a Palantir es una consulta a la API de GitHub (60/h por IP, compartida por todos los aparatos de
# casa): antes se pedían las ~18 cada 30 min (auditoría 22-oct C-07, aprobado por Carlos)
PERSONAL_RE = re.compile(r"no_finalizadas|Mis_|Seguimiento|watchlist|favorit|historial", re.I)


def ttl_of(path):
    """caducidad de la caché de una fila según sea personal o no (CACHE_TTL / STATIC_TTL)"""
    if not path.startswith("plugin://plugin.video.palantir3/?"):
        return CACHE_TTL
    try:
        route = decode_route(path.split("&")[0])
    except Exception:  # noqa: BLE001
        return CACHE_TTL
    return CACHE_TTL if PERSONAL_RE.search(route or "") else STATIC_TTL
# «2»: las rutas guardadas antes de la 1.4.52/1.0.71 pueden llevar progreso a None (flix_progress) y Palantir revienta
# al reproducirlas -> caché nueva; la vieja se borra
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache2.json" % xbmc.getSkinDir())
try:
    os.remove(CACHE_FILE.replace("rows_cache2.json", "rows_cache.json"))
except OSError:
    pass
GENERIC_ART = "plugin.video.palantir3/resources/media"   # icono genérico de Palantir (calidad, letras, "Más…")
SECTION_VARS = {"Películas": "p3Peliculas", "Series": "p3Series", "Anime": "p3Anime",
                "Dibujos": "p3Dibujos", "Documentales": "p3Documentales"}
PROPS = ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file", "plot", "duration"]


def log(msg):
    xbmc.log("[flix_rows] %s" % msg, xbmc.LOGINFO)




def action_of(path):
    try:
        m = re.search(r'"action": \'?([^\',}]+)', decode_route(path))
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


def skin_var(name):
    try:
        with xbmcvfs.File("special://skin/xml/Includes_Palantir3.xml") as fh:
            text = fh.read()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_rows] no leo Includes_Palantir3.xml: %s" % e, xbmc.LOGWARNING)
        return ""
    m = re.search(r'<variable name="%s">(.*?)</variable>' % re.escape(name), text, re.S)
    vals = re.findall(r"<value[^>]*>(.*?)</value>", m.group(1), re.S) if m else []
    return vals[-1].strip().replace("&amp;", "&") if vals else ""


_cache = None
_dirty = set()      # claves que este proceso ha pedido a Palantir y aún no ha guardado


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cache_save():
    """guarda lo pedido por este proceso MEZCLADO con el fichero (gana lo más nuevo), con cerrojo. Antes se volcaba
    la copia entera del proceso: el Inicio, que vive toda la sesión, pisaba lo que guardaban las secciones y
    flix_progress (auditoría 22-oct B-05 / REND-04), y reescribía ~2,6 MB aunque no hubiera nada nuevo (C-04)"""
    if not _dirty:
        return
    try:
        with flix_cache.file_lock(CACHE_FILE):
            try:
                with open(CACHE_FILE, encoding="utf-8") as fh:
                    disk = json.load(fh)
            except (OSError, ValueError):
                disk = {}
            if not isinstance(disk, dict):
                disk = {}
            keys = list(_dirty)
            flix_cache.merge_newer(disk, _cache, keys)
            flix_cache.purge(disk)
            flix_cache.atomic_write(CACHE_FILE, json.dumps(disk))
        _dirty.difference_update(keys)
        for k, v in disk.items():               # y lo nuevo de los demás, para el siguiente peek
            if flix_cache.stamp(v) > flix_cache.stamp(_cache.get(k)):
                _cache[k] = v
    except OSError as e:
        log("no guardo caché: %s" % e)


flush = _cache_save


def peek(path, keep_headers=False):
    """(items guardados o None, ¿frescos?) sin llamar a Palantir"""
    hit = _cache_load().get(flix_cache.key_of(path, keep_headers))
    if not hit:
        return None, False
    return _progress(hit[1]), flix_cache.is_fresh(hit, ttl=ttl_of(path))


def fetch(path, force=False, keep_headers=False, save=True):
    """(items, de_caché). Clave sin &reload=. Un fallo de Palantir (0 items) no machaca una caché buena."""
    key = flix_cache.key_of(path, keep_headers)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and time.time() - hit[0] < ttl_of(path):
        return _progress(hit[1]), True
    raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": path, "media": "video", "properties": PROPS}}))
    files = ((json.loads(raw).get("result") or {}).get("files")) or []
    files = [f for f in files if f.get("label") and (keep_headers or not clean(f["label"]).endswith(":"))]
    if files:          # vacío = fallo de Palantir: ni machaca una caché buena ni se guarda (el reintento volvería a dar vacío)
        cache[key] = [time.time(), files]
        _dirty.add(key)
        if save:
            _cache_save()
    return _progress(files or (hit[1] if hit else [])), False


def _progress(files):
    """progreso real de Palantir (watched.db) en vez del que trae la caché (flix_progress.py)"""
    try:
        import flix_progress
        flix_progress.fix_files(files)
    except Exception as e:  # noqa: BLE001
        log("progreso: %s" % e)
    return files


def is_generic(f):
    a = f.get("art") or {}
    art = urllib.parse.unquote(a.get("poster") or a.get("thumb") or "")   # llega como image://special%3a%2f%2f…
    return not art or GENERIC_ART in art


def is_more(f):
    """último elemento "Más…/More…" de un listado (página siguiente)"""
    return f.get("filetype") == "directory" and re.match(r"^(m[aá]s|more|siguiente|next)\b", clean(f.get("label")).lower()) is not None


FOLLOW_ACTION = "\"action\": 'play_mis_serieS'"
FOLLOW_TMDB_RE = re.compile(r'"tmdb": \'?(\d+)')


def follow_tmdb(f):
    """tmdb de una serie de «Series en seguimiento» (cualquier página o sección); None si no lo es. Aquí y no en
    flix_progress para que las secciones lo miren sin cargar ese módulo"""
    if not isinstance(f, dict) or not str(f.get("file", "")).startswith("plugin://plugin.video.palantir3/"):
        return None
    try:
        route = decode_route(f["file"])
    except Exception:  # noqa: BLE001
        return None
    m = FOLLOW_TMDB_RE.search(route) if FOLLOW_ACTION in route else None
    return m.group(1) if m else None


def head(files, n, more=True):
    """los n primeros de un listado y su «más…» al final aunque quede fuera del recorte (tarjeta «Ver más»);
    more=False lo quita (Top 10)"""
    out = [f for f in files[:n] if more or not is_more(f)]
    return out + [f for f in files[n:] if is_more(f)][:1] if more else out


def is_search(label):
    l = label.lower().replace("í", "i")
    return "titulo" in l or "title" in l or l.startswith("buscar") or l.startswith("search")


def section_rows(var, stale_ok=False):
    """[{label, path, kind}] de la sección (en el orden del menú de Palantir). var: variable p3… del skin o ruta de
    Palantir (secciones añadidas en Ajustes → Secciones del menú). stale_ok: vale el menú guardado aunque esté
    caducado (cambia muy poco)."""
    path = var if var.startswith("plugin://") else skin_var(var)
    if not path.startswith("plugin://"):
        return []
    menu = peek(path, keep_headers=True)[0] if stale_ok else None
    if not menu:
        menu, _ = fetch(path, keep_headers=True)
    out, group = [], ""
    groups = set()
    for f in menu:
        lab = clean(f.get("label"))
        if not lab:
            continue
        if lab.endswith(":"):
            group = "Series" if "serie" in lab.lower() else "Películas"
            groups.add(group)
            continue
        if is_search(lab) or f.get("filetype") != "directory":
            continue
        act = action_of(f.get("file", ""))
        kind = "list" if act in ("listado_peliculaS", "listado_serieS") else "coll"
        out.append({"label": lab, "path": f["file"], "kind": kind, "group": group})
    # etiquetas repetidas (p. ej. "Por orden alfabético" en pelis y en series) llevan el grupo detrás
    names = [r["label"] for r in out]
    for r in out:
        if names.count(r["label"]) > 1 and r["group"]:
            r["label"] = "%s · %s" % (r["label"], r["group"])
    log("sección %s: %d filas (%s)" % (var, len(out), ", ".join("%s[%s]" % (r["label"], r["kind"]) for r in out)))
    return out
