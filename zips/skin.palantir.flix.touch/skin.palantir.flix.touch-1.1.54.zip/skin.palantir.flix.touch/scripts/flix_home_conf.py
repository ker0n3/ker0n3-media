"""Configuración del Inicio (TV y táctil): lógica pura, sin Kodi, para poder probarla con pytest.

home_order.json (addon_data/<skin>/):
  {"order": [ids], "hidden": [ids], "deleted": [ids],
   "custom": [{"id": 5130, "label": "Acción", "path": "plugin://…"}], "items": 15}
  opcional "names": {"<id>": nombre que se ve} (Ajustes → Cambiar nombre)
Lo que falte toma el valor por defecto (los ficheros antiguos solo tenían order y hidden).

Filas de serie: ids 5101-5118. Filas añadidas por el usuario: 5130-5147. Máximo 18 filas en total (ocultas incluidas).
"""
import hashlib
import json
import re

MAX_ROWS = 18
CUSTOM_IDS = range(5130, 5148)
ITEM_CHOICES = (8, 10, 15, 20, 30)
DEFAULT_ITEMS = 15
FOLLOW_ROW = 5102     # «Series en seguimiento»: sus series llevan ▶ (Palantir no da capítulos vistos)
TOP10_ITEMS = 10
INITIAL_NEAR = 5      # filas que se cargan al abrir el Inicio
# ruta de una fila aún lejana: carpeta del skin sin vídeos (0 elementos al instante). NUNCA vacía: un contenedor
# de Kodi con ruta vacía no vuelve a cargar cuando la ruta cambia después (pasó con la previsualización de secciones)
IDLE_PATH = "special://skin/media/flix/icons/"
AHEAD = 3             # filas que se marcan por debajo de la que tiene el foco


# ---------- configuración ----------
def _ints(seq):
    out = []
    for v in seq or []:
        try:
            out.append(int(v))
        except (TypeError, ValueError):
            pass
    return out


def normalize(raw):
    raw = raw if isinstance(raw, dict) else {}
    custom = []
    seen = set()
    for d in raw.get("custom") or []:
        try:
            i = int(d["id"])
            label, path = str(d["label"]), str(d["path"])
        except (KeyError, TypeError, ValueError):
            continue
        if i in CUSTOM_IDS and i not in seen and path:
            seen.add(i)
            custom.append({"id": i, "label": label, "path": path})
    items = raw.get("items", DEFAULT_ITEMS)
    names = {}
    for k, v in (raw.get("names") if isinstance(raw.get("names"), dict) else {}).items():
        try:
            i = int(k)
        except (TypeError, ValueError):
            continue
        if isinstance(v, str) and v.strip():
            names[str(i)] = v.strip()
    out = {
        "order": _ints(raw.get("order")),
        "hidden": _ints(raw.get("hidden")),
        "deleted": _ints(raw.get("deleted")),
        "custom": custom,
        "items": items if items in ITEM_CHOICES else DEFAULT_ITEMS,
    }
    if names:
        out["names"] = names        # solo si hay: la firma de las configuraciones de antes no cambia
    return out


def compose(defaults, conf):
    """filas del Inicio en el orden guardado: de serie no eliminadas + añadidas. Cada una = copia de su dict con
    "custom" y "hidden". Las que no estén en "order" (filas de serie nuevas tras una actualización) van al final."""
    rows = [dict(d, custom=False) for d in defaults if d["id"] not in conf["deleted"]]
    rows += [dict(d, custom=True) for d in conf["custom"]]
    pos = {i: k for k, i in enumerate(conf["order"])}
    rows = [r for _, r in sorted(enumerate(rows), key=lambda kr: (pos.get(kr[1]["id"], 1000 + kr[0])))]
    names = conf.get("names") or {}
    for r in rows:
        r["hidden"] = r["id"] in conf["hidden"]
        if str(r["id"]) in names:
            r["title"] = names[str(r["id"])]    # nombre que se ve; "label" sigue siendo el de siempre
    return rows


def addable_defaults(defaults, conf):
    return [d for d in defaults if d["id"] in conf["deleted"]]


def count_rows(conf, defaults):
    return len([d for d in defaults if d["id"] not in conf["deleted"]]) + len(conf["custom"])


def can_add(conf, defaults):
    return count_rows(conf, defaults) < MAX_ROWS


def add_custom(conf, defaults, label, path):
    """añade una fila de Palantir; devuelve su id. ValueError si ya hay 18 filas o no quedan ids libres."""
    if not can_add(conf, defaults):
        raise ValueError("máximo %d filas" % MAX_ROWS)
    used = {d["id"] for d in conf["custom"]}
    free = [i for i in CUSTOM_IDS if i not in used]
    if not free:
        raise ValueError("sin ids libres")
    i = free[0]
    conf["custom"].append({"id": i, "label": label, "path": path})
    return i


def restore(conf, row_id):
    conf["deleted"] = [i for i in conf["deleted"] if i != row_id]


def delete(conf, row_id):
    conf["order"] = [i for i in conf["order"] if i != row_id]
    conf["hidden"] = [i for i in conf["hidden"] if i != row_id]
    if any(d["id"] == row_id for d in conf["custom"]):
        conf["custom"] = [d for d in conf["custom"] if d["id"] != row_id]
    elif row_id not in conf["deleted"]:
        conf["deleted"].append(row_id)


def next_items(n):
    if n not in ITEM_CHOICES:
        return DEFAULT_ITEMS
    return ITEM_CHOICES[(ITEM_CHOICES.index(n) + 1) % len(ITEM_CHOICES)]


def signature(conf):
    """firma corta y estable de la configuración (va en un comentario de Home.xml)"""
    blob = json.dumps(normalize(conf), sort_keys=True, ensure_ascii=True)
    return hashlib.sha1(blob.encode("ascii")).hexdigest()[:16]


# ---------- TV: filas de Home.xml + Includes_FlixRows.xml ----------
BLOCK_RE = re.compile(r'[ \t]*<include content="FlixRow(?:Static)?">.*?</include>\n?', re.S)
PARAM_RE = re.compile(r'<param name="(\w+)" value="([^"]*)"')
EXTRA = ("itemw", "px", "fx")


def parse_tv_blocks(region_xml):
    """filas de serie del trozo de Home.xml (formato antiguo con path=$VAR[FlixPath…] o nuevo con src=…)"""
    out = []
    for blk in BLOCK_RE.findall(region_xml):
        p = dict(PARAM_RE.findall(blk))
        src = p.get("src") or re.search(r"\$VAR\[(\w+)\]", p.get("path", "")).group(1)
        out.append({
            "id": int(p["list_id"]),
            "label": p["label"].replace("&quot;", '"').replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&"),
            "path": "$VAR[%s]" % src,
            "src": src,
            "top10": p.get("top10") == "true",
            "extra": {k: p[k] for k in EXTRA if k in p},
        })
    return out


NAV_SLOTS = 4


def _alive(i):
    return "[Integer.IsGreater(Container(%d).NumItems,0) | Container(%d).IsUpdating]" % (i, i)


def _dead(i):
    return "[Integer.IsEqual(Container(%d).NumItems,0) + !Container(%d).IsUpdating]" % (i, i)


TOP_BUTTON = 9301     # Inicio TV: botón Buscar arriba a la derecha (arriba desde la primera fila)
AWAKE_UP, AWAKE_DOWN = 1, 2   # filas con el diseño completo de carátula: la enfocada, 1 por encima y 2 por debajo
AWAKE_START = 3               # antes de enfocar ninguna fila: las 3 primeras


def awake_cond(ids, k):
    """condición «fila k despierta» (parámetro awake del FlixRow). Kodi procesa en cada fotograma TODAS las filas del
    grouplist del Inicio aunque no se vean (16 filas: ~45 % de CPU en reposo en Shield y Fire TV, 21-oct); las
    dormidas usan una carátula sola (FlixRowLayouts) y siguen visibles, enfocables y con sus títulos cargados"""
    near = ids[max(0, k - AWAKE_DOWN):k + AWAKE_UP + 1]
    conds = ["String.IsEqual(Window(home).Property(flix_row),%d)" % i for i in near]
    if k < AWAKE_START:
        conds.append("String.IsEmpty(Window(home).Property(flix_row))")
    return "[" + " | ".join(conds) + "]"


def _nav(prefix, cands, fallback=None):
    """params <prefix>1..4 (destinos) y <prefix>c1..4 (condiciones excluyentes): ir a la primera fila viva;
    si no queda ninguna por encima/debajo, a fallback (solo con hueco libre: hasta 3 vecinas)"""
    out = []
    for j in range(NAV_SLOTS):
        if j < len(cands):
            cond = " + ".join([_alive(cands[j])] + [_dead(c) for c in cands[:j]])
            out += [("%s%d" % (prefix, j + 1), cands[j]), ("%sc%d" % (prefix, j + 1), cond)]
        elif j == len(cands) and fallback is not None:
            cond = " + ".join(_dead(c) for c in cands) or "true"
            out += [("%s%d" % (prefix, j + 1), fallback), ("%sc%d" % (prefix, j + 1), cond)]
        else:
            out += [("%s%d" % (prefix, j + 1), "noop"), ("%sc%d" % (prefix, j + 1), "false")]
    return out


def _attr(v):
    # a mano y no xml.sax.saxutils.escape: ese import arrastra urllib.request, http, ssl, email y tempfile (~0,3 s en
    # cada apertura del Inicio y del editor; auditoría 22-oct C-03)
    return str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def render_tv(rows, items):
    """rows = compose(...) -> trozo de filas de xml/FlixInicio.xml (Inicio TV = ventana Python flix_inicio.py, que
    rellena cada fila desde la caché y pide a Palantir por detrás, como las secciones). Solo las filas visibles.
    path/src/limit no los usa el include: flix_inicio.py y parse_tv_blocks los leen de aquí."""
    vis = [r for r in rows if not r.get("hidden")]
    ids = [r["id"] for r in vis]
    blocks = []
    for k, r in enumerate(vis):
        src = r.get("src") or "FlixRowPath%d" % r["id"]
        path = r["path"] if r.get("src") else _attr(r["path"])
        params = [("list_id", r["id"]), ("label", _attr(r.get("title") or r["label"])), ("path", path),
                  ("src", src), ("top10", "true" if r.get("top10") else "false")]
        params += [(k2, v) for k2, v in (r.get("extra") or {}).items()]
        if r["id"] == FOLLOW_ROW and "follow" not in (r.get("extra") or {}):
            params += [("follow", "true")]     # ▶ en las series de «Series en seguimiento» (todas empezadas)
        params += [("limit", TOP10_ITEMS if r.get("top10") else items), ("back", 9000)]
        params += _nav("d", ids[k + 1:k + 1 + NAV_SLOTS])
        params += _nav("u", ids[max(0, k - NAV_SLOTS):k][::-1], TOP_BUTTON)
        params += [("awake", awake_cond(ids, k))]
        blocks.append('\t\t\t\t<include content="FlixRowStatic">\n' +
                      "".join('\t\t\t\t\t<param name="%s" value="%s" />\n' % (n, v) for n, v in params) +
                      "\t\t\t\t</include>\n")
    return "".join(blocks)


# ---------- explorador de Palantir: qué carpetas se pueden abrir y cuántos títulos hay ----------
TAG_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)[^\]]*\]")
# acciones/etiquetas que no son listados: abren el teclado, ajustes o diálogos de Palantir
SKIP_RE = re.compile(r"buscar|search|ajuste|config|setting|herramient|cuenta|account|login",
                     re.I)
MORE_RE = re.compile(r"^(m[aá]s|more|siguiente|next)\b", re.I)


def clean_label(label):
    return TAG_RE.sub("", label or "").strip()


def action_of(path):
    """acción de una ruta de Palantir (su JSON va en base64 invertido y rotado ceil(len/4))"""
    import base64
    import math
    blob = (path or "").split("?", 1)[-1].split("&", 1)[0]
    if not blob or blob.startswith("plugin://"):
        return ""
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    try:
        text = base64.b64decode(b64).decode("utf-8", "replace")
    except ValueError:
        return ""
    m = re.search(r'"action": \'?([^\',}]+)', text)
    return m.group(1) if m else ""


def classify(files):
    """listado de Files.GetDirectory -> (carpetas que se pueden explorar [{label, file}], nº de títulos).
    Títulos = películas, series o episodios (lo que pintaría una fila). Fuera: cabeceras ("…:"), "Más…",
    búsquedas, ajustes y similares (abrirían el teclado o un diálogo de Palantir)."""
    folders, titles = [], 0
    for f in files:
        lab = clean_label(f.get("label"))
        typ = f.get("type") or "unknown"
        if not lab or lab.endswith(":"):
            continue
        if typ in ("movie", "tvshow", "episode", "season") or f.get("filetype") == "file":
            titles += 1
            continue
        if MORE_RE.match(lab) or SKIP_RE.search(lab) or SKIP_RE.search(action_of(f.get("file"))):
            continue
        folders.append({"label": lab, "file": f.get("file", "")})
    return folders, titles
