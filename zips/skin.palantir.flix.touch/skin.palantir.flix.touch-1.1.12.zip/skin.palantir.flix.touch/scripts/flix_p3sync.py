"""Sincronización de Palantir con Trakt al arrancar, sin frenar el Inicio.

Palantir no tiene servicio: lo que se marca en OTRO aparato (vista, progreso, dejar de seguir) solo baja de Trakt
cuando se abre SU MENÚ RAÍZ (plugin://plugin.video.palantir3/), que la skin original enseñaba en el Inicio. Nuestro
Inicio va directo a las filas y nunca lo abre: la Shield llevaba días sin traer nada de Trakt (Carlos, 20-oct:
Obsession vista en la Shield y no en el móvil, serie dejada de seguir que seguía). Probado en la Shield (20-oct):
listar la raíz trae lo marcado en el móvil en ~10 s; `RunScript(plugin.video.palantir3,None,&update=1)` no trae nada.

Ahora se lista la raíz (sin enseñarla) DELAY s después del arranque y, cuando Palantir termina de escribir watched.db,
se ponen al día las filas: ✓ y progreso de películas (flix_progress.py) y, si cambiaron series seguidas o
capítulos vistos, la lista «Series en seguimiento» de la caché de Palantir se borra y se recarga esa fila.
Después sigue vivo toda la sesión y repite al acabar un vídeo y cada EVERY s, siempre sin vídeo y con el mando
quieto IDLE s (si se está navegando por Palantir, la consulta le haría esperar: Palantir atiende de una en una).
Lo llama first_run.py (una vez por sesión)."""
import json
import os
import sqlite3
import sys
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/")
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
ROOT = "plugin://plugin.video.palantir3/"
DELAY = 20          # s tras el arranque: el Inicio ya está pintado
WATCH = 120         # s como mucho esperando a que Palantir escriba (tarda ~10 s)
STEP = 5
EVERY = 1800        # s entre sincronizaciones con Kodi abierto (Carlos, 20-oct: «cada 30 min»)
IDLE = 30           # s sin tocar el mando antes de consultar a Palantir


def log(msg):
    xbmc.log("[flix_p3sync] %s" % msg, xbmc.LOGINFO)


def file_sig():
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def shows_sig():
    """series seguidas (no ocultas) + capítulos vistos: si cambian, «Series en seguimiento» está vieja"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            shows = sorted(r[0] for r in db.execute("SELECT tmdb_id FROM shows_watched WHERE NOT ocultar"))
            eps = db.execute("SELECT COUNT(*), MAX(lastPlayed), SUM(progress) FROM episodes_watched").fetchone()
        finally:
            db.close()
        return repr((shows, eps))
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def refresh_follow():
    try:
        db = sqlite3.connect(CACHE_DB, timeout=5)
        try:
            n = db.execute("DELETE FROM simplecache WHERE id LIKE '%SeriesSeguimiento%'").rowcount
            db.commit()
        finally:
            db.close()
        log("caché de Series en seguimiento borrada (%d)" % n)
    except Exception as e:  # noqa: BLE001
        log("no borro la caché de Series en seguimiento: %s" % e)
    HOME.setProperty("flix_rl_p3PathSeriesSeguimiento", str(int(time.time() * 10)))   # fila TV
    HOME.setProperty("fh_refetch_row", "5102")                                       # Inicio táctil


def sync_once(mon):
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.palantir3)") or not os.path.exists(WATCHED_DB):
        return
    before_file, before_shows = file_sig(), shows_sig()
    log("lanzo la sincronización de Palantir")
    start, last = time.time(), before_file
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
                                    "params": {"directory": ROOT, "media": "video"}}))
    changed = False
    while time.time() - start < WATCH:
        if mon.waitForAbort(STEP):
            return
        sig = file_sig()
        if sig != last:                 # sigue escribiendo: esperar a que pare
            last, changed = sig, True
            continue
        if changed:
            break                       # escribió y lleva STEP s quieto
    if not changed:
        log("sin cambios de Trakt en %d s" % (time.time() - start))
        return
    log("watched.db cambió en %.0f s: pongo al día las filas" % (time.time() - start))
    if shows_sig() != before_shows:
        refresh_follow()
    HOME.setProperty("fh_progress", "1")          # Inicio táctil: repinta ✓ y barras (flix_home.sync_progress)
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")


def quiet():
    return not xbmc.getCondVisibility("Player.HasVideo") and xbmc.getCondVisibility("System.IdleTime(%d)" % IDLE)


def main():
    mon = xbmc.Monitor()
    if mon.waitForAbort(DELAY):
        return
    sync_once(mon)
    last, playing, pending = time.time(), False, False
    while not mon.waitForAbort(STEP):
        now_playing = xbmc.getCondVisibility("Player.HasVideo")
        if playing and not now_playing:
            pending = True              # acaba de terminar un vídeo: lo visto en otro aparato, en cuanto esté quieto
        playing = now_playing
        if (pending or time.time() - last >= EVERY) and quiet():
            log("sincronización %s" % ("tras el vídeo" if pending else "periódica"))
            sync_once(mon)
            last, pending = time.time(), False


if __name__ == "__main__":
    main()
