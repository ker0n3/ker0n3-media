"""Home TÁCTIL de Ker0n3 Flix (ventana FlixHome.xml), con INERCIA y paso lateral por filas.

Por qué un script (código de Kodi 21):
  - La inercia solo existe en listas/paneles (responden a GESTURE_NOTIFY); un grouplist no la tiene.
    => toda la Home es UNA lista vertical (7000) y cada elemento es una fila.
  - Un elemento de lista no puede contener otra lista, así que los pósters de cada fila son
    propiedades del elemento (p0..p8) y este script decide qué enseñar.
  - WindowXML.onAction recibe TODAS las acciones con coordenadas (getAmount1/2): toque (100) =>
    qué póster se ha tocado; swipe izq/der (511/521) => qué fila pasar de página. El arrastre vertical
    lo hace la lista sola, con inercia, empiece donde empiece el dedo.
Geometría compartida con tools/gen_touch_flixhome.py.
"""
import json
import os
import re
import threading
import time

import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_rows  # noqa: E402  (secciones en filas, compartido con la TV)
import flix_cache  # noqa: E402
import flix_sections  # noqa: E402

HOME = xbmcgui.Window(10000)
SKIN = xbmcvfs.translatePath("special://skin/")
ROWS = json.load(open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8"))


def show_chips():
    """tarjetas de arriba = primeras secciones activas (sections.json) -> Window(home).Property(flix_chipN)"""
    flix_sections.chips_props()


def chip_at(i):
    """tarjeta i (0..) tal como se ve ahora (lo que haya puesto flix_sections.apply, también tras editar en Ajustes):
    (etiqueta, clave, rows|list)"""
    if not 0 <= i < flix_sections.flix_sections_conf.TOUCH_MAX:
        return None, None, None
    n = i + 1
    lab = HOME.getProperty("flix_chip%d" % n)
    return (lab, HOME.getProperty("flix_sec%d_key" % n), HOME.getProperty("flix_sec%d_kind" % n)) if lab else (None, None, None)
CHIP_W, CHIP_GAP, CHIPS_H = 280, 20, 120   # = tools/gen_touch_flixhome.py
CHIP_W_NARROW, CHIP_GAP_NARROW = 252, 12   # pantallas de 1920 de ancho: así caben las 7 tarjetas
LEFT, ROW_H, SLOTS, HEADER_H = 56, 540, 9, 140  # la lista empieza en y=HEADER_H
STEP = 60                  # alto de cada elemento de la lista (FlixHome.xml)
PIECES = ROW_H // STEP     # trozos por fila: cada uno dibuja la fila entera (ver generador)
RES = [(1920, 1080), (1920, 1200), (2160, 1080), (2338, 1080), (2400, 1080), (2520, 1080)]
CACHE_TTL = 1800   # 30 min: cada llamada a Palantir consulta la API de GitHub (60/h por IP, compartido con la Shield)
# «2»: rutas de antes de la 1.0.71 con progreso a None (flix_progress) -> Palantir revienta; la vieja se borra
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/skin.palantir.flix.touch/home_cache2.json")
try:
    os.remove(CACHE_FILE.replace("home_cache2.json", "home_cache.json"))
except OSError:
    pass
# búsqueda (flix_search.py táctil): las filas de resultados llegan aquí mientras Palantir responde
SEARCH_FILE = xbmcvfs.translatePath("special://temp/flix_search_rows.json")
COLOR_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE)[^\]]*\]")
A_CLICK, A_SELECT, A_MOVE = 100, 7, 107
A_SWIPE_L, A_SWIPE_R = 511, 521
A_BEGIN, A_PAN, A_ABORT, A_END = 501, 504, 505, 599
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)
A_CONTEXT = (101, 117)
DLG_CTX_QUIET = 3.0      # s tras cerrar un pop-up (FlixResume) sin atender pulsaciones largas
LONG_REPEAT = 1.5        # s: una 2.ª pulsación larga seguida es la misma (Kodi manda 101 y 117)
# Kodi manda cada pulsación larga dos veces: 101 con las coordenadas del dedo y 117 sin ellas, en cualquier orden. La
# que llega sin coordenadas espera un poco a la otra: si se atendía primero usaba un toque anterior (menú de otra
# carátula, o de ninguna) y la buena se descartaba por repetida (móvil Carlos, 22-oct: «a la 1.ª no sale, a la 2.ª sí»)
CTX_WAIT = 0.35


def ctx_after_dialog(closed, last_long, now):
    """¿hay que ignorar esta pulsación larga? closed = flix_dlg_closed (hora como texto), last_long = la anterior"""
    try:
        if closed and now - float(closed) < DLG_CTX_QUIET:
            return True
    except ValueError:
        pass
    return bool(last_long) and now - last_long < LONG_REPEAT


def log(msg):
    xbmc.log("[flix_home] %s" % msg, xbmc.LOGINFO)


def clean(s):
    return COLOR_RE.sub("", s or "").strip()


def skin_res():
    sw, sh = xbmcgui.getScreenWidth(), xbmcgui.getScreenHeight()
    w, h = min(RES, key=lambda r: abs(r[0] / r[1] - sw / sh))
    return w, h, sw, sh


SKIN_W, SKIN_H, SCR_W, SCR_H = skin_res()


def chip_geom(skin_w):
    """(ancho, hueco) de las tarjetas de arriba: las 7 tienen que caber sin desplazar la fila"""
    if LEFT + 7 * (CHIP_W + CHIP_GAP) - CHIP_GAP > skin_w - 16:
        return CHIP_W_NARROW, CHIP_GAP_NARROW
    return CHIP_W, CHIP_GAP


CHIP_GEOM = chip_geom(SKIN_W)
HOME.setProperty("fh_narrow", "1" if CHIP_GEOM[0] == CHIP_W_NARROW else "")   # FlixHome.xml: tamaño de tarjeta


def live(path):
    """resuelve en vivo los $INFO[...] que llevan algunas rutas (p. ej. &reload=$INFO[Window(home).Property(P3Reload…)])"""
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: xbmc.getInfoLabel(m.group(1)), path)


_cache = None
_cache_lock = threading.Lock()


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cache_save():
    # con el lock: otro hilo de carga puede estar añadiendo filas (antes: «dictionary changed size» y el hilo moría)
    if not flix_cache.save_json(CACHE_FILE, _cache, _cache_lock):
        log("no guardo caché")


def fetch(path, force=False):
    """filas de Palantir con caché en disco (sobrevive a reinicios de Kodi). Clave = ruta sin el
    parámetro &reload= (cambia en cada sesión y no debe invalidar la caché)."""
    key = re.sub(r"&reload=[^&]*", "", path)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and time.time() - hit[0] < flix_rows.ttl_of(path):     # 30 min personales / 6 h (C-07)
        return flix_rows._progress(hit[1]), True
    raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": live(path), "media": "video",
        "properties": ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file"]}}))
    files = ((json.loads(raw).get("result") or {}).get("files")) or []
    files = [f for f in files if f.get("label") and not clean(f["label"]).endswith(":")]
    if files:                 # vacío = fallo de Palantir: no machaca una caché buena ni se guarda
        with _cache_lock:
            cache[key] = [time.time(), files]
        _cache_save()
    return flix_rows._progress(files or (hit[1] if hit else [])), False


def peek(path):
    """(filas guardadas o None, ¿frescas?) SIN llamar a Palantir, aunque estén caducadas: al abrir el Inicio tras
    más de CACHE_TTL se pintan ya y se refrescan por detrás (antes: tarjetas vacías 2-20 s por fila)"""
    hit = _cache_load().get(re.sub(r"&reload=[^&]*", "", path))
    if not hit or not hit[1]:
        return None, False
    return flix_rows._progress(hit[1]), time.time() - hit[0] < flix_rows.ttl_of(path)


def poster_of(f):
    a = f.get("art") or {}
    return a.get("poster") or a.get("thumb") or a.get("tvshow.poster") or ""


_anim_n = [0]


def anim_name(step):
    """valor para ListItem.Property(anim): L1/L2 (entra por la derecha) R1/R2 (por la izquierda);
    alternar el número re-dispara la animación Conditional"""
    _anim_n[0] += 1
    return ("L" if step > 0 else "R") + str(_anim_n[0] % 2 + 1)


def pct_of(f):
    """'' si no hay barra: antes devolvía "0" con duración conocida y posición 0, y watched_of lo tomaba por «a
    medias» -> vista sin ✓ hasta reiniciar Kodi (Proyecto Salvación, móvil 23-oct)"""
    r = f.get("resume") or {}
    pct = int(100 * float(r.get("position") or 0) / float(r["total"])) if r.get("total") else 0
    return str(pct) if pct > 0 else ""


SHOW_STARTED = 99   # serie a medias (flix_progress.SHOW_STARTED)


def watched_of(f):
    """'1' = ya vista (película o serie entera según Palantir) y sin progreso a medias: ✓ en el póster"""
    pc = int(f.get("playcount") or 0)
    return "1" if pc > 0 and pc != SHOW_STARTED and not pct_of(f) else ""


class Strip:
    """una fila de la Home (o el hero) = PIECES elementos de la lista con las mismas propiedades"""

    def __init__(self, kind, label, pieces=PIECES):
        self.kind = kind
        self.lis = []
        self.vals = {}
        self.height = pieces * STEP
        for j in range(pieces):
            # offscreen=True: setProperty no espera al hilo de dibujo de Kodi (con GUI lock cada llamada
            # tarda ~1 fotograma; 9 trozos x varias propiedades = trompicones al arrastrar)
            li = xbmcgui.ListItem(label, offscreen=True)
            li.setProperty("type", kind)
            li.setProperty("j", str(j))
            li.setProperty("w", str(SKIN_W))
            self.lis.append(li)

    def set(self, key, value):
        if self.vals.get(key) == value:
            return
        self.vals[key] = value
        for li in self.lis:
            li.setProperty(key, value)

    def relabel(self, label):
        """título de la fila (Ajustes → Cambiar nombre con el Inicio ya pintado)"""
        for li in self.lis:
            li.setLabel(label)


OX_STEP = 5         # px por paso de la fracción de póster (FlixHome.xml)
SNAP_EDGE = 0.2     # al soltar: encaja a carátula entera solo si la fracción del borde es < 20 % o > 80 %
SLOTS_SET = 10      # huecos por juego (FlixHome.xml SLOTS)


class Row:
    """fila de pósters con desplazamiento continuo. pos = posición en pósters (2.4 = 3.er póster a la
    izquierda y 0.4 desplazado). Dos juegos de huecos (a/b) en FlixHome.xml: el visible muestra los
    pósters desde 'start'; al cruzar un póster se rellena el otro juego (ListItem offscreen: no espera al
    dibujado) y se cambia juego + fracción con UNA propiedad (fh_o) -> sin saltos ni esperas"""

    def __init__(self, d):
        self.id, self.label, self.path, self.top10 = d["id"], d["label"], d["path"], d["top10"]
        self.title = d.get("title") or d["label"]     # nombre que se ve (Ajustes → Cambiar nombre); label = el interno
        self.kind = d.get("kind", "list")       # sección: "coll" = submenú (tarjetas que abren su rejilla)
        self.limit = d.get("limit")             # Inicio: elementos por fila elegidos en el editor (secciones: todos)
        self.items, self.pos, self.start, self.ox, self.buf, self.strip = [], 0.0, 0, 0, "a", None
        self._arrows = None
        self.win = None             # ventana mientras se arrastra (estado en Window.Property(fh_o))
        self._o = None
        self._painted = {"a": None, "b": None}

    @property
    def itemw(self):
        return 400 if self.top10 else 286

    @property
    def visible(self):
        return max(1, int((SKIN_W - LEFT) // self.itemw))

    @property
    def max_pos(self):
        return float(max(0, len(self.items) - self.visible))

    def set_items(self, files):
        if files and flix_rows.follow_tmdb(files[0]):
            import flix_progress
            files = flix_progress.ordered_follow(files)     # Series en seguimiento: por lo visto de verdad
        self.items = files[:10] if self.top10 else (files[:self.limit] if self.limit else files)
        self.pos = min(self.pos, self.max_pos)

    def fill(self, buf, start):
        st = self.strip
        for k in range(SLOTS_SET):
            i = start + k
            if i < len(self.items):
                f = self.items[i]
                more = flix_rows.is_more(f)
                text = more or (self.kind == "coll" and flix_rows.is_generic(f))   # tarjeta de texto
                st.set("%sp%d" % (buf, k), "" if text else poster_of(f))
                st.set("%st%d" % (buf, k), "Ver más" if more else (clean(f.get("label")) or " "))
                st.set("%spc%d" % (buf, k), pct_of(f))
                st.set("%sw%d" % (buf, k), watched_of(f))
                # series: ▶ en «Series en seguimiento» y en las que llevas a medias (flix_progress: playcount
                # SHOW_STARTED, calculado de watched.db: Palantir no da el estado de las series)
                st.set("%sip%d" % (buf, k), "1" if f.get("type") == "tvshow" and (
                    self.id == 5102 or int(f.get("playcount") or 0) == SHOW_STARTED) else "")
                st.set("%sn%d" % (buf, k), str(i + 1) if self.top10 else "")
            else:
                for p in ("p", "t", "pc", "n", "w", "ip"):
                    st.set("%s%s%d" % (buf, p, k), "")
        self._painted[buf] = start

    def paint(self):
        """(re)pinta con los datos actuales (carga / refresco)"""
        self.start = int(self.pos)
        self.fill(self.buf, self.start)
        self._painted[self.other] = None
        self._arrows = None
        self.publish(force=True)

    @property
    def other(self):
        return "b" if self.buf == "a" else "a"

    def set_pos(self, pos):
        self.pos = max(0.0, min(float(pos), self.max_pos))
        start = int(self.pos)
        ox = int(round((self.pos - start) * self.itemw / OX_STEP))
        if ox * OX_STEP >= self.itemw:
            start, ox = start + 1, 0
        if start != self.start:
            nb = self.other
            if self._painted[nb] != start:
                self.fill(nb, start)              # el juego oculto: no se ve mientras se rellena
            self.buf, self.start = nb, start
        self.ox = ox
        self.publish()

    def publish(self, force=False):
        if self.win is not None:                  # arrastrando: juego + fracción en UNA propiedad
            o = "%s%02d" % (self.buf.upper(), self.ox)
            if o != self._o:
                self._o = o
                self.win.setProperty("fh_o", o)
        else:
            self.strip.set("buf", self.buf)
            self.strip.set("ox", str(self.ox) if self.ox else "")
        arrows = (self.pos > 0.05, self.pos < self.max_pos - 0.05)
        if force or arrows != self._arrows:
            self._arrows = arrows
            self.strip.set("prev", "1" if arrows[0] else "")
            self.strip.set("next", "1" if arrows[1] else "")

    def begin_drag(self, win):
        if self.win is None:
            self.win = win
            self._o = None
            self.publish()                        # primero la propiedad de ventana…
            self.strip.set("drag", "1")           # …luego la fila pasa a leerla

    def end_drag(self):
        if self.win is not None:
            win, self.win = self.win, None
            self.publish(force=True)              # estado final en la propia fila…
            self.strip.set("drag", "")            # …deja de leer la de ventana…
            win.setProperty("fh_o", "")

    def index_at(self, sx):
        return int((sx - LEFT) / self.itemw + self.pos)


class Animator(threading.Thread):
    """aplica el movimiento lateral a ~60 fps: sigue al dedo (drag) o desliza con frenada (glide).
    Los eventos del dedo solo guardan la posición deseada; así no se encolan repintados."""

    def __init__(self, win):
        super().__init__(daemon=True)
        self.win = win
        self.row = None
        self.drag_pos = None        # posición pedida por el dedo
        self.glide = None           # (inicio, destino, t0, duración)
        self.cv = threading.Condition()

    def _switch(self, row):
        if self.row is not None and self.row is not row:
            self.row.end_drag()
        row.begin_drag(self.win)

    def drag(self, row, pos):
        with self.cv:
            self._switch(row)
            self.row, self.glide, self.drag_pos = row, None, pos
            self.cv.notify()

    def stop_row(self, row):
        with self.cv:
            if self.row is row:
                self.glide = None

    def glide_to(self, row, target, dur=0.35):
        with self.cv:
            self._switch(row)
            self.row, self.drag_pos = row, None
            self.glide = (row.pos, max(0.0, min(float(target), row.max_pos)), time.time(), dur)
            self.cv.notify()

    def run(self):
        try:
            self._run()
        except Exception:  # noqa: BLE001
            import traceback
            log("animador caído: %s" % traceback.format_exc())

    def _run(self):
        while not self.win.stop:
            with self.cv:
                if self.drag_pos is None and self.glide is None:
                    self.cv.wait(0.5)
                    idle = True
                else:
                    idle = False
            if idle:
                if not self.win.section:
                    self.win.sync_chips()   # barato: Strip.set no toca nada si no cambió
                continue
            with self.cv:
                row, dp, gl = self.row, self.drag_pos, self.glide
                self.drag_pos = None
            if dp is not None:
                row.set_pos(dp)
            elif gl is not None:
                a, b, t0, dur = gl
                t = min(1.0, (time.time() - t0) / dur)
                row.set_pos(a + (b - a) * (1 - (1 - t) ** 3))
                if t >= 1.0:
                    with self.cv:
                        if self.glide is gl:
                            self.glide = None
                            row.end_drag()        # guarda la posición en la fila
            time.sleep(1 / 60)


class FlixHome(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.section = kwargs.get("section")    # (variable p3… o ruta, título) = sección desplegada en filas
        self.rconf = kwargs.get("rconf") or {}  # filas elegidas de la sección (flix_sections_conf.apply_rows)
        # resultados del buscador táctil: misma ventana que una sección (atrás + título), filas de SEARCH_FILE
        self.search = kwargs.get("search", False)
        self.token = kwargs.get("token", "")     # solo el Inicio: fh_token de main()
        self.inited = False
        self.flags = {}          # flix_common.expire_hide_flags
        self.rows = [] if self.section else self.home_rows()
        self.shown = []          # orden en la lista: "hero" o Row (cada uno ocupa PIECES elementos)
        # el hueco del hero existe desde el principio (vacío hasta que llegan datos): crearlo más tarde obligaba a
        # rehacer la lista entera y la devolvía arriba aunque el usuario ya estuviera bajando
        # (las secciones no llevan hero: Carlos no lo quiere ahí)
        self.hero_items, self.hero_i = [], 0
        self.hero = None if kwargs.get("section") else Strip("hero", "hero")
        self.chips = Strip("chips", "chips", CHIPS_H // STEP)
        self.last_touch = 0.0
        self.mouse = (0.0, 0.0)
        self.loaded_at = 0.0
        self.win_id = 0          # id de esta ventana (onInit): el hilo de carga solo consulta con ella activa
        self._cur_row = 0
        self.lock = threading.RLock()
        self.rating_busy = set()  # rutas cuya nota (flix_ratings) se está pidiendo
        self.stop = False
        self.g = None            # gesto en curso
        self.anim = Animator(self)
        self.anim.start()
        self.fling_id = 0

    def sync_chips(self):
        """copia las etiquetas de Window(home).Property(flix_chipN) al elemento de tarjetas (el animador lo repite en
        reposo: así se ve el cambio al salir de Ajustes → Secciones del menú sin reabrir el Inicio)"""
        for i in range(1, flix_sections.flix_sections_conf.TOUCH_MAX + 1):
            self.chips.set("c%d" % i, HOME.getProperty("flix_chip%d" % i))

    @staticmethod
    def home_rows():
        """filas del Inicio elegidas en el editor (flix_home_order.py): orden, ocultas, eliminadas, añadidas y
        elementos por fila (flix_home_conf)"""
        try:
            import flix_home_conf as hc
            import flix_home_order as fho
            conf = fho.load_conf() or hc.normalize(None)
            return [Row(dict(r, top10=r.get("top10", False), kind=r.get("kind", "list"), limit=conf["items"]))
                    for r in hc.compose(ROWS, conf) if not r["hidden"]]
        except Exception as e:  # noqa: BLE001
            log("orden del Inicio: %s" % e)
            return [Row(dict(d, limit=15)) for d in ROWS]

    def apply_reorder(self):
        """orden cambiado en Ajustes (flix_home_order.py pone fh_reorder): se aplica al momento"""
        if self.section or HOME.getProperty("fh_reorder") != "1":
            return
        HOME.clearProperty("fh_reorder")
        with self.lock:
            old = {r.id: r for r in self.rows}
            rows = []
            for r in self.home_rows():
                o = old.get(r.id)
                if o is not None and o.title != r.title:     # renombrada en el editor: la fila ya pintada también
                    o.title = r.title
                    if o.strip is not None:
                        o.strip.relabel(r.title)
                rows.append(o or r)
            self.rows = rows
            for row in self.rows:                   # filas añadidas: su hueco ya, en su sitio
                if row.strip is None:
                    row.strip = Strip("top10" if row.top10 else "row", row.title)
                    row.paint()
            if self.shown:
                # cambio pedido en el editor: lista entera en el orden guardado. Sin esto, tras tocar la pantalla
                # order() manda las filas nuevas al final (evita saltos al cargar) y la añadida "no aparecía"
                self.shown = []
                touched, self.last_touch = self.last_touch, 0.0
                self.rebuild()
                self.last_touch = touched
        threading.Thread(target=self.load_all, daemon=True).start()   # filas que estaban ocultas
        log("orden del Inicio aplicado")

    # ---------- ciclo de vida ----------
    def onInit(self):
        self.inited = True
        log("DIAG onInit (filas mostradas %d, pos %s)" % (len(self.shown), xbmc.getInfoLabel("Container(7000).Position")))
        # id de ESTA ventana (Python: 13000+). Al volver de un vídeo onInit llega con Home (10000) activa: guardar ese
        # id hacía que Home.xml «volviera» al Inicio activándose a sí misma -> pantalla negra (móvil, 19-oct)
        wid = xbmcgui.getCurrentWindowId()
        if wid >= 13000:
            self.win_id = wid
        if self.section:
            self.setProperty("fh_mode", "section")
            self.setProperty("fh_title", self.section[1])
        elif self.win_id:
            HOME.setProperty("fh_window", str(self.win_id))
        self.restore_after_reload()
        show_chips()                 # al volver de Ajustes se ven ya las secciones elegidas
        self.sync_chips()
        self.lst = self.getControl(7000)
        self.apply_reorder()
        threading.Thread(target=self.sync_progress, daemon=True).start()
        if not self.shown:
            threading.Thread(target=self.load_all, daemon=True).start()
            threading.Thread(target=self.hero_timer, daemon=True).start()
        elif time.time() - self.loaded_at > CACHE_TTL:
            threading.Thread(target=self.load_all, kwargs={"refresh": True}, daemon=True).start()
        elif HOME.getProperty("fh_played") == "1":
            HOME.clearProperty("fh_played")
            threading.Thread(target=self.load_all, kwargs={"refresh": True, "only_progress": True}, daemon=True).start()

    def sync_progress(self):
        """progreso real de Palantir (flix_progress.py): corrige su caché y repinta las barras de las filas ya
        mostradas sin volver a pedirlas (al volver de un vídeo o de limpiar progreso / marcar como vista)"""
        import flix_progress
        for wait in (0, 3, 8):
            if wait and xbmc.Monitor().waitForAbort(wait):
                return
            if self.stop:
                return
            if flix_common.p3sync_busy() and xbmc.Monitor().waitForAbort(15):
                return     # Palantir rebajando las pausas de Trakt (watched.db sin ellas un momento)
            W = flix_progress.truth_cached(max_age=0)
            if W is None:
                continue   # sin watched.db no se toca nada ({} = sin películas, las series sí: B-06)
            try:
                flix_progress.fix_palantir_cache(W)
            except Exception as e:  # noqa: BLE001
                log("progreso caché Palantir: %s" % e)
            with self.lock:
                for row in self.rows:
                    # las carátulas de la fila están en row.items (Strip no tiene items: antes no repintaba nunca,
                    # auditoría PY-01)
                    if row.strip is None or not row.items:
                        continue
                    changed = flix_progress.fix_files(row.items, W)
                    ordered = flix_progress.ordered_follow(row.items)
                    if ordered is not row.items:            # Series en seguimiento: orden al día tras sincronizar
                        row.items, changed = ordered, True
                    if flix_progress.is_resume_row(row.path) and not flix_common.p3sync_busy():
                        keep = flix_progress.still_started(row.items)
                        if len(keep) != len(row.items):
                            log("fila %s: fuera %d que ya no están a medias" % (row.label, len(row.items) - len(keep)))
                            row.set_items(keep)
                            changed = True
                    if changed:
                        log("fila %s: ✓/progreso al día" % row.label)
                        row.paint()

    def load_all(self, refresh=False, only_progress=False):
        if self.search:
            self.load_search()
            return
        if self.section and not self.rows:
            self.rows = [Row({"id": 6100 + i, "label": r["label"], "title": r.get("title"), "path": r["path"], "top10": False, "kind": r["kind"]})
                         for i, r in enumerate(flix_sections.flix_sections_conf.apply_rows(flix_rows.section_rows(self.section[0], stale_ok=True), self.rconf))]
        # TODAS las filas se crean de golpe (vacías, con su título) y la lista se monta UNA vez: luego solo se
        # rellenan sus carátulas (propiedades). Añadir elementos a la lista mientras el usuario baja la recolocaba
        # (vuelta arriba) y redibujaba el hero (parpadeo).
        with self.lock:
            fresh = False
            for row in self.rows:
                if row.strip is None:
                    row.strip = Strip("top10" if row.top10 else "row", row.title)
                    row.paint()
                    fresh = True
            if fresh and (not self.shown or any(r not in self.shown for r in self.rows)):
                self.rebuild()
        fresh_rows = set()
        if not self.section and not only_progress and not refresh:
            # Inicio: lo guardado al momento aunque esté caducado; luego solo se pide a Palantir lo caducado
            painted = 0
            for row in list(self.rows):
                files, fresh = peek(row.path)
                if files:
                    with self.lock:
                        row.set_items(files)
                        self.hero_from(row, files)
                        row.paint()
                    painted += 1
                    if fresh:
                        fresh_rows.add(row.id)
            log("Inicio: %d filas pintadas con lo guardado (%d caducadas: se refrescan)" % (painted, painted - len(fresh_rows)))
        if self.section and not only_progress:
            # sección: lo guardado al momento aunque esté caducado; luego solo se pide lo caducado (auditoría REND-02)
            for row in list(self.rows):
                files, fresh = flix_rows.peek(row.path)
                if files:
                    with self.lock:
                        row.set_items(files)
                        row.paint()
                if fresh and not refresh:
                    fresh_rows.add(row.id)
        for idx, row in enumerate(list(self.rows)):
            if self.stop:
                return
            if row.id in fresh_rows:
                continue
            if only_progress and "Seguir" not in row.label and "seguimiento" not in row.label:
                continue
            # carga diferida (solo Inicio): las filas lejanas esperan a que el usuario se acerque; las que tienen
            # caché fresca se pintan ya (no cuestan llamadas a Palantir). Al refrescar, las lejanas se dejan.
            if not self.section and not only_progress and not self.cache_fresh(row.path):
                if refresh and idx >= self.near_limit():
                    continue
                while idx >= self.near_limit():
                    if self.stop or xbmc.Monitor().waitForAbort(0.3):
                        return
            try:
                files, cached = (flix_rows.fetch(row.path, force=True, save=False) if self.section
                                 else fetch(row.path, force=only_progress))
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row.label, e))
                continue
            log("fila %s: %d%s" % (row.label, len(files), " (caché)" if cached else ""))
            if self.section and files and flix_cache.same_items(row.items, files[:len(row.items)]) and \
                    len(row.items) == len(files[:row.limit] if row.limit else files):
                continue                                # sección refrescada sin cambios: no se repinta
            if not self.section and not refresh and not only_progress and files and flix_cache.same_items(row.items, files[:len(row.items)]) and \
                    len(row.items) == len(files[:10] if row.top10 else (files[:row.limit] if row.limit else files)):
                continue                                # ya pintada con lo guardado y no ha cambiado: sin repintar
            with self.lock:
                row.set_items(files)
                self.hero_from(row, files)
                row.paint()
        if self.section:
            flix_rows.flush()
        self.loaded_at = time.time()

    def load_search(self):
        """resultados del buscador: flix_search.py escribe SEARCH_FILE cada vez que una sección de Palantir responde
        (filas nuevas o más títulos en una fila) y lo marca como terminado al final. Las filas se añaden al final de
        la lista según llegan (append_or_rebuild: sin volver arriba)."""
        if getattr(self, "_search_started", False):
            return                      # onInit lo vuelve a pedir al volver de una ficha o un vídeo
        self._search_started = True
        by_label, mtime, gen = {}, None, None
        mon = xbmc.Monitor()
        while not self.stop:
            try:
                st = os.stat(SEARCH_FILE).st_mtime_ns
            except OSError:
                st = None
            if st is not None and st != mtime:
                mtime = st
                try:
                    with open(SEARCH_FILE, encoding="utf-8") as fh:
                        data = json.load(fh)
                except (OSError, ValueError):
                    data = None             # a medio escribir: el siguiente vistazo
                if data is not None:
                    if gen is None:
                        gen = data.get("gen")
                    if data.get("gen") != gen:
                        return              # otra búsqueda: esta ventana ya no la enseña
                    for r in data.get("rows") or []:
                        files = flix_rows._progress(r.get("files") or [])
                        row = by_label.get(r["label"])
                        with self.lock:
                            if row is None:
                                row = Row({"id": 6100 + len(by_label), "label": r["label"], "path": r.get("path") or "",
                                           "top10": False, "kind": "list"})
                                by_label[r["label"]] = row
                                self.rows.append(row)
                                row.strip = Strip("row", row.title)
                                row.strip.set("nochev", "1")    # título sin › (no hay «ver todo»)
                                row.set_items(files)
                                row.paint()
                                order = [x["label"] for x in data.get("rows") or []]
                                after = [x for x in self.rows if x.label in by_label and x is not row
                                         and order.index(x.label) > order.index(row.label)] if row.label in order else []
                                if after and self.shown and after[0] in self.shown:
                                    self.rows.remove(row)
                                    self.rows.insert(self.rows.index(after[0]), row)
                                    self.insert_before(row, after[0])     # título exacto: arriba nada más llegar
                                else:
                                    self.append_or_rebuild(row)
                            elif len(files) != len(row.items):
                                row.set_items(files)
                                row.paint()
                    if data.get("done"):
                        # flix_search.py sube al final la fila con el título exacto («up» -> Películas de dibujos)
                        order = [r["label"] for r in data.get("rows") or []]
                        with self.lock:
                            mine = [r for r in self.rows if r.label in by_label]
                            if [r.label for r in mine] != [k for k in order if k in by_label]:
                                log("búsqueda: filas reordenadas (título exacto arriba)")
                                rest = [r for r in self.rows if r.label not in by_label]
                                self.rows = rest + sorted(mine, key=lambda r: order.index(r.label))
                                self.rebuild()
                        break
            if mon.waitForAbort(0.3):
                return
        log("búsqueda: %d filas" % len(by_label))
        self.loaded_at = time.time()

    def hero_from(self, row, files):
        """el hero sale de Top 10 películas (o de la primera fila de carátulas si esa está oculta)"""
        hero_src = 5105 if any(r.id == 5105 for r in self.rows) else None
        if self.hero is not None and files and (row.id == hero_src or (hero_src is None and row.kind == "list" and not self.hero_items)):
            self.set_hero([f for f in files if not flix_rows.is_more(f)][:10])

    def near_limit(self):
        """filas que se pueden cargar ya: las 5 primeras y hasta 3 por debajo de la que se está viendo"""
        import flix_home_conf as hc
        return max(hc.INITIAL_NEAR, self.current_row() + hc.AHEAD + 1)

    def current_row(self):
        """índice en self.rows de la fila seleccionada en la lista vertical (hero/chips = 0).
        Se llama desde el hilo de carga: NUNCA tocar controles (self.lst) desde aquí. Si Kodi destruye la ventana
        (recarga de la skin al actualizarse) mientras un hilo usa un control, Kodi entero se cae (pasó en 1.0.40-41).
        Por eso: InfoLabel de Kodi y solo con esta ventana activa; si no, el último valor conocido."""
        if self.stop or not self.win_id or xbmcgui.getCurrentWindowId() != self.win_id:
            return self._cur_row
        try:
            pos = int(xbmc.getInfoLabel("Container(7000).CurrentItem") or 0) - 1
        except ValueError:
            return self._cur_row
        if pos < 0:
            return self._cur_row
        self._sel = pos                         # para repintar tras recargar la skin (restore_after_reload)
        n, row = 0, len(self.rows)
        for t in list(self.shown):
            n += len(self.strip_of(t).lis)
            if pos < n:
                row = self.rows.index(t) if t in self.rows else 0
                break
        self._cur_row = row
        return row

    @staticmethod
    def cache_fresh(path):
        key = re.sub(r"&reload=[^&]*", "", path)
        hit = _cache_load().get(key)
        return bool(hit) and time.time() - hit[0] < flix_rows.ttl_of(path)

    def order(self):
        if self.shown and self.last_touch:          # orden ya mostrado + filas nuevas al final
            return self.shown + [r for r in self.rows if r.strip is not None and r not in self.shown]
        chips = [] if self.section else ["chips"]
        return chips + (["hero"] if self.hero is not None else []) + [r for r in self.rows if r.strip is not None]

    def strip_of(self, t):
        return self.chips if t == "chips" else self.hero if t == "hero" else t.strip

    def append_or_rebuild(self, row):
        """añade una fila nueva. Rehacer la lista la devuelve arriba del todo, así que si el usuario ya ha
        tocado la pantalla la fila se añade al final aunque no le toque ese orden"""
        # las filas llegan en orden y el hero existe desde el principio: con la lista ya creada, SIEMPRE al final
        # (rehacerla la devolvía arriba mientras el usuario bajaba, en el Inicio y en las secciones)
        if self.shown:
            before = xbmc.getInfoLabel("Container(7000).Position") + "/" + xbmc.getInfoLabel("Container(7000).CurrentItem")
            self.shown = self.shown + [row]
            self.lst.addItems(row.strip.lis)
            log("DIAG añadida fila %s (pos antes %s, después %s/%s)" % (row.label, before,
                xbmc.getInfoLabel("Container(7000).Position"), xbmc.getInfoLabel("Container(7000).CurrentItem")))
        else:
            self.rebuild()

    def sel_pos(self):
        """posición seleccionada en la lista vertical, preguntando a Kodi (-1 si no se sabe). NUNCA
        ControlList.getSelectedPosition: tras recargar la skin (actualización automática) el objeto de Python apunta
        a la lista vieja, ya borrada, y Kodi se cae (SIGSEGV, auditoría 22-oct A-09). Solo con esta ventana activa
        (las secciones táctiles usan el mismo id 7000); si no, la última conocida"""
        wid = getattr(self, "win_id", 0)
        if wid and xbmcgui.getCurrentWindowId() == wid:
            try:
                pos = int(xbmc.getInfoLabel("Container(7000).CurrentItem") or 0) - 1
            except ValueError:
                pos = -1
            if pos >= 0:
                self._sel = pos
                return pos
        return getattr(self, "_sel", -1)

    def insert_before(self, row, other):
        """mete una fila delante de otra ya mostrada sin mover lo que se está viendo (el seleccionado se corre
        tantas posiciones como ocupa la nueva si estaba por debajo). ControlList no tiene insertar: se rehace."""
        pos = self.sel_pos()
        k = self.shown.index(other)
        start = sum(len(self.strip_of(t).lis) for t in self.shown[:k])
        self.shown = self.shown[:k] + [row] + self.shown[k:]
        self.lst.reset()
        items = []
        for t in self.shown:
            items += self.strip_of(t).lis
        self.lst.addItems(items)
        if pos >= 0:
            self.lst.selectItem(min(pos + (len(row.strip.lis) if pos >= start else 0), len(items) - 1))
        log("búsqueda: fila %s delante de %s (pos %d)" % (row.label, other.label, pos))

    def restore_after_reload(self):
        """Kodi recarga la skin (p. ej. al actualizarla) y vuelve a montar esta ventana desde el XML con la lista vacía,
        llamando otra vez a onInit (antes: «Cargando…» hasta reiniciar Kodi). Se repinta EN LA MISMA ventana con los
        mismos elementos (reset/addItems/selectItem van por id). Antes se cerraba y se abría otro Inicio: una tecla en
        ese hueco cerraba Kodi y, con un diálogo delante, el Inicio se perdía (auditoría 22-oct A-03/A-04). Lo que
        cerraba Kodi al re-meter los elementos (19-oct) era getSelectedPosition sobre la lista vieja (A-09)."""
        # Container(7000).NumItems = lo que hay de verdad en pantalla (ControlList.size() es la copia de Python y
        # sigue llena tras la recarga). SOLO "0": al volver de un vídeo onInit llega con la ventana del vídeo aún
        # activa y da "" (no existe ese contenedor ahí); tomarlo por recarga cerraba y relanzaba el Inicio tras CADA
        # vídeo, dos veces -> con varios Atrás, menú de apagado y pantalla negra «Cargando» (móvil, 19-oct)
        if self.shown and xbmc.getInfoLabel("Container(7000).NumItems") == "0":
            with self.lock:
                pos = getattr(self, "_sel", -1)
                items = []
                for t in self.shown:
                    items += self.strip_of(t).lis
                log("ventana montada de nuevo (skin recargada): repinto %d elementos (pos %d)" % (len(items), pos))
                self.lst = self.getControl(7000)
                self.lst.reset()
                self.lst.addItems(items)
                if pos >= 0:
                    self.lst.selectItem(min(pos, len(items) - 1))
            return True
        return False

    def rebuild(self):
        pos = self.sel_pos()
        import traceback
        log("DIAG rebuild (pos %d, filas %d) desde %s" % (pos, len(self.shown), " < ".join(
            "%s:%d" % (f.name, f.lineno) for f in traceback.extract_stack()[-4:-1])))
        self.lst.reset()
        self.shown = self.order()
        items = []
        for t in self.shown:
            items += self.strip_of(t).lis
        self.lst.addItems(items)
        if pos >= 0:
            self.lst.selectItem(min(pos, len(items) - 1))

    # ---------- hero ----------
    def set_hero(self, items):
        self.hero_items = items
        self.paint_hero()

    def paint_hero(self, step=0):
        if not self.hero_items:
            return
        self.hero_i %= len(self.hero_items)
        f = self.hero_items[self.hero_i]
        a = f.get("art") or {}
        h = self.hero
        h.set("fanart", a.get("fanart") or a.get("landscape") or "")
        h.set("logo", a.get("clearlogo") or "")
        h.set("title", clean(f.get("label")))
        meta = [str(f["year"])] if f.get("year") else []
        if f.get("runtime"):
            meta.append("%d min" % (int(f["runtime"]) // 60))
        rt = self.rating_of(f.get("file") or "")
        if rt:
            meta.append(rt)
        elif f.get("rating"):
            meta.append("★ %.1f" % float(f["rating"]))
        h.set("meta", "  ·  ".join(meta))
        h.set("genre", " / ".join(f.get("genre") or []))
        h.set("rank", "" if self.section else str(self.hero_i + 1))   # distintivo TOP 10 solo en el Inicio
        for k in range(10):
            h.set("dot%d" % k, "" if k >= len(self.hero_items) else ("on" if k == self.hero_i else "off"))


    def rating_of(self, path):
        """nota de Metacritic/IMDb (flix_ratings, clave de MDBList en Ajustes) o '' -> la ★ de TMDB. Si no está
        guardada se pide en un hilo y se repinta la cabecera si sigue en ese título"""
        try:
            import flix_ratings
            rt = flix_ratings.label_for(path)
            if rt or not flix_ratings.wanted(path) or path in self.rating_busy:
                return rt
        except Exception as e:  # noqa: BLE001
            log("nota: %s" % e)
            return ""
        self.rating_busy.add(path)

        def late():
            try:
                if flix_ratings.label_for(path, wait=flix_ratings.TIMEOUT):
                    with self.lock:
                        if self.hero_items and (self.hero_items[self.hero_i % len(self.hero_items)].get("file") == path):
                            self.paint_hero()
            finally:
                self.rating_busy.discard(path)
        threading.Thread(target=late, daemon=True).start()
        return ""

    def hero_step(self, step):
        with self.lock:
            if self.hero_items:
                self.hero_i += step
                self.paint_hero(step)

    def refetch_row(self, rid):
        """vuelve a pedir una fila a Palantir saltándose la caché (p. ej. Series en seguimiento tras dejar de seguir)"""
        for row in list(self.rows):
            if str(row.id) == rid:
                try:
                    files, _ = fetch(row.path, force=True)
                except Exception as e:  # noqa: BLE001
                    log("fila %s: %s" % (row.label, e))
                    return
                with self.lock:
                    row.set_items(files)
                    row.paint()
                log("fila %s recargada (%d)" % (row.label, len(files)))

    def hero_timer(self):
        mon = xbmc.Monitor()
        while not mon.abortRequested() and not self.stop:
            mon.waitForAbort(1)
            if getattr(self, "token", "") and HOME.getProperty("fh_token") != self.token:
                log("hay otro Inicio: este se retira")   # quedó tapado o sin verse y main() abrió otro
                self.stop = True
                self.close()
                return
            self.apply_reorder()
            if not self.section:
                flix_common.expire_hide_flags(self.flags)
            if HOME.getProperty("fh_progress") == "1":     # menú contextual cerrado: limpiar progreso / vista
                HOME.clearProperty("fh_progress")
                threading.Thread(target=self.sync_progress, daemon=True).start()
            refetch = HOME.getProperty("fh_refetch_row")       # flix_menu.py / flix_p3sync.py: ids separados por comas
            if refetch:
                HOME.clearProperty("fh_refetch_row")
                for rid in [x for x in refetch.split(",") if x]:
                    threading.Thread(target=self.refetch_row, args=(rid,), daemon=True).start()
            if self.hero_items and self.g is None and time.time() - self.last_touch > 10 and int(time.time()) % 8 == 0 \
                    and xbmc.getCondVisibility("Window.IsActive(%s)" % HOME.getProperty("fh_window")):
                self.hero_step(1)

    # ---------- geometría ----------
    def to_skin(self, x, y):
        return x * SKIN_W / SCR_W, y * SKIN_H / SCR_H

    def strip_at(self, sy):
        """(fila/hero, y dentro de la fila) bajo la coordenada sy (skin), con la lista en reposo"""
        try:
            pos = int(xbmc.getInfoLabel("Container(7000).Position"))
            cur = int(xbmc.getInfoLabel("Container(7000).CurrentItem")) - 1
        except ValueError:
            return None, 0
        y = (sy - HEADER_H) + (cur - pos) * STEP     # y dentro del contenido de la lista
        if y < 0:
            return None, 0
        top = 0
        for t in self.shown:
            h = self.strip_of(t).height
            if y < top + h:
                return t, y - top
            top += h
        return None, 0

    # ---------- acciones ----------
    def onAction(self, action):
        aid = action.getId()
        x, y = action.getAmount1(), action.getAmount2()
        if aid == A_MOVE:
            self.mouse = (x, y)
            return
        if aid in A_BACK:
            if self.section:
                self.stop = True
                self.close()
            else:
                xbmc.executebuiltin("ActivateWindow(shutdownmenu)")
            return
        if aid in A_CONTEXT:
            coords = x > 1 or y > 1             # el dedo de verdad (101); sin ellas: 117 o el de flix_menu.py
            if not coords and self.ours_ctx():
                return
            busy = HOME.getProperty("flix_menu_busy")     # "1" = flix_menu.py en marcha; "t<hora>" = acaba de terminar
            if ctx_after_dialog(HOME.getProperty("flix_dlg_closed"), getattr(self, "last_long", 0), time.time()):
                log("pulsación larga ignorada (tras cerrar un pop-up o repetida)")
                return
            if HOME.getProperty("flix_ctx_auto") or busy == "1" or (not coords and busy.startswith("t") and
                                                                    time.time() - float(busy[1:] or 0) < 2.5):
                # el Action(ContextMenu) que manda flix_menu.py por detrás (lista oculta 7990) también llega aquí:
                # NO es una pulsación larga. Antes abría el menú de la carátula bajo el dedo (otra película) y se
                # marcó como vista la que no era (móvil, 19-oct). Ese nunca trae coordenadas: el margen de 2,5 s
                # tras cerrar un menú solo vale para los que llegan sin ellas (22-oct: mantener pulsada otra carátula
                # nada más cerrar un menú no hacía nada)
                return
            # mantener pulsado: menú KER0N3 de la carátula bajo el dedo
            if x <= 1 and y <= 1:
                stamp = time.time()
                self.ctx_wait = stamp
                threading.Timer(CTX_WAIT, self.ctx_fallback, args=(stamp,)).start()
                return
            self.handle_long(x, y)
            return
        if aid == A_BEGIN:
            self.gesture_begin(x, y)
            return
        if aid == A_PAN:
            self.gesture_move(x, y)
            return
        if aid in (A_END, A_ABORT):
            self.gesture_end()
            return
        if aid in (A_CLICK, A_SWIPE_L, A_SWIPE_R):
            if x <= 1 and y <= 1:        # acción sin coordenadas (pruebas por JSON-RPC): última posición del ratón
                x, y = self.mouse
            sx, sy = self.to_skin(x, y)
            self.last_touch = time.time()
            if sy < HEADER_H:
                return
            target, ry = self.strip_at(sy)
            if target is None:
                return
            if aid == A_CLICK:
                self.tap(target, sx, ry)
            elif time.time() - getattr(self, "last_hdrag", 0) > 0.6:   # swipe sin arrastre lateral previo
                self.swipe(target, 1 if aid == A_SWIPE_L else -1)
        elif aid == A_SELECT:
            pos, t = self.sel_pos(), None
            for cand in self.shown:
                n = len(self.strip_of(cand).lis)
                if pos < n:
                    t = cand
                    break
                pos -= n
            if t is not None and t != "chips":
                self.open(self.hero_items[self.hero_i] if t == "hero" and self.hero_items else (t.items[int(t.pos)] if t != "hero" and t.items else None),
                          t if t != "hero" else None)

    def onClick(self, control_id):
        pass                             # los toques se resuelven en onAction (con coordenadas)

    # ---------- arrastre lateral continuo ----------
    def gesture_begin(self, x, y):
        self.last_touch = time.time()
        self.press_xy = (x, y)                                # mantener pulsado: dónde empezó el toque
        sx, sy = self.to_skin(x, y)
        target, _ = self.strip_at(sy) if sy >= HEADER_H else (None, 0)
        if isinstance(target, Row):
            self.anim.stop_row(target)                        # el dedo detiene el deslizamiento
        self.g = {"x0": sx, "y0": sy, "t": target, "mode": None, "hist": [(time.time(), sx)],
                  "base": target.pos if isinstance(target, Row) else 0.0}

    def gesture_move(self, x, y):
        g = self.g
        if not g or g["t"] is None:
            return
        sx, sy = self.to_skin(x, y)
        dx, dy = sx - g["x0"], sy - g["y0"]
        if g["mode"] is None:
            if abs(dx) > 20 and abs(dx) > 1.2 * abs(dy):
                g["mode"] = "h"
                g["x0"], dx = sx, 0.0
            elif abs(dy) > 20:
                g["mode"] = "v"
        if g["mode"] != "h":
            return
        now = time.time()
        g["hist"].append((now, sx))
        while len(g["hist"]) > 2 and now - g["hist"][0][0] > 0.12:   # velocidad de los últimos 120 ms
            g["hist"].pop(0)
        self.last_hdrag = now
        t = g["t"]
        if t == "hero":
            g["hero_dx"] = dx
            return
        self.anim.drag(t, g["base"] - dx / t.itemw)

    def gesture_end(self):
        g, self.g = self.g, None
        if not g or g.get("mode") != "h" or g["t"] is None:
            return
        self.last_hdrag = time.time()
        h = g["hist"]
        v = 0.0
        if len(h) >= 2 and h[-1][0] - h[0][0] > 0.01:
            v = (h[-1][1] - h[0][1]) / (h[-1][0] - h[0][0])      # px/s (skin)
        t = g["t"]
        if t == "hero":
            dx = g.get("hero_dx", 0)
            if abs(dx) > 120 or abs(v) > 600:
                self.hero_step(1 if (dx or v) < 0 else -1)
            return
        # inercia: recorre v*0,35 s y frena. Encaje suave (petición de Carlos, 18-oct): solo se recoloca a carátula
        # entera si la del borde queda casi fuera (<20 % o >80 % de una carátula); si no, se queda donde cae.
        # El encaje siempre a la más cercana recolocaba casi en cada gesto y se veía un parpadeo.
        target = max(0.0, min(t.pos - (v * 0.35) / t.itemw, t.max_pos))
        frac = target - int(target)
        if frac < SNAP_EDGE:
            target = float(int(target))
        elif frac > 1 - SNAP_EDGE:
            target = float(int(target) + 1)
        dur = 0.25 + min(0.5, abs(v) / 6000)
        self.anim.glide_to(t, target, dur)

    def swipe(self, target, step):
        if target == "chips":
            return
        if target == "hero":
            self.hero_step(step)
        else:
            self.anim.glide_to(target, round(target.pos) + step * target.visible, 0.45)

    @staticmethod
    def ours_ctx():
        """¿este Action(ContextMenu) es uno de los que mandó flix_menu.py (flix_ctx_sent)? Se descuenta. Llegan aquí
        con retraso si la ventana está ocupada: con solo el margen de 2,5 s se abría el menú de otra película"""
        try:
            sent = [t for t in json.loads(HOME.getProperty("flix_ctx_sent") or "[]") if time.time() - t < 60]
        except ValueError:
            sent = []
        if not sent:
            HOME.clearProperty("flix_ctx_sent")
            return False
        HOME.setProperty("flix_ctx_sent", json.dumps(sent[1:]))
        log("ContextMenu de flix_menu.py (no es pulsación larga)")
        return True

    def handle_long(self, x, y):
        self.g = None
        self.last_long = time.time()
        self.long_press(*self.to_skin(x, y))

    def ctx_fallback(self, stamp):
        """no llegó la pulsación con coordenadas (tecla de menú de un teclado o mando): la del último toque"""
        if getattr(self, "ctx_wait", 0) != stamp or getattr(self, "last_long", 0) >= stamp:
            return
        x, y = getattr(self, "press_xy", None) or self.mouse
        self.handle_long(x, y)

    def long_press(self, sx, sy):
        """menú KER0N3 (flix_menu.py) del título bajo el dedo. Sus acciones son las del submenú de Palantir, que
        necesita un elemento de Kodi con foco: la fila se carga en la lista oculta 7990 (FlixHome.xml) y
        flix_menu.py se coloca en el título antes de abrir por detrás el menú de Kodi (lista «ctx 7990»)"""
        if sy < HEADER_H:
            return
        target, _ = self.strip_at(sy)
        if target in (None, "chips"):
            log("pulsación larga sin carátula debajo (%.0f, %.0f): %s" % (sx, sy, target))
            return
        if target == "hero":
            row = next((r for r in self.rows if r.id == 5105 and r.items), None) or \
                next((r for r in self.rows if r.kind == "list" and r.items), None)
            f = self.hero_items[self.hero_i % len(self.hero_items)] if self.hero_items else None
        else:
            row = target
            k = row.index_at(sx)
            f = row.items[k] if 0 <= k < len(row.items) else None
        path = (f or {}).get("file", "")
        if not row or not row.path or not path.startswith("plugin://plugin.video.palantir3/") or flix_rows.is_more(f):
            log("pulsación larga sin menú (%.0f, %.0f): fila %s, título %s" % (sx, sy, getattr(row, "label", None),
                                                                            clean((f or {}).get("label"))))
            return                      # (fila de resultados sin ruta listable: sin menú)
        HOME.setProperty("flix_ctx_path", live(row.path))
        log("menú de %s (fila %s)" % (clean(f.get("label")), row.label))
        xbmc.executebuiltin('RunScript(special://skin/scripts/flix_menu.py,"%s","%s","%s",7990)'
                            % (path, poster_of(f), clean(f.get("label")).replace('"', "'")))

    def tap(self, target, sx, ry):
        if target == "chips":
            cw, cg = CHIP_GEOM
            i = int((sx - LEFT) // (cw + cg))
            lab, key, kind = chip_at(i) if i >= 0 else (None, None, None)
            if lab and (sx - LEFT) - i * (cw + cg) <= cw:
                HOME.setProperty("flix_section", lab)
                if kind == "rows":                      # sección desplegada en filas (se carga al entrar)
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,sec,%s)" % key)
                elif kind == "list":                    # rejilla de carátulas (Trakt, Favoritos…)
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_sections.py,open,%s)" % key)
            return
        if target == "hero":
            if self.hero_items:
                self.open(self.hero_items[self.hero_i % len(self.hero_items)])
            return
        row = target
        if ry < 80 and self.search:      # título de una fila de resultados: no hay «ver todo»
            return
        if ry < 80:                      # título de la fila = ver todo
            HOME.setProperty("flix_section", row.title)
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % live(row.path))
            return
        if row.pos > 0.05 and sx < LEFT + 50:
            self.swipe(row, -1)
            return
        if row.pos < row.max_pos - 0.05 and sx > SKIN_W - 110:
            self.swipe(row, 1)
            return
        k = row.index_at(sx)
        if 0 <= k < len(row.items):
            self.open(row.items[k], row)

    def open(self, f, row=None):
        if not f:
            return
        path = f.get("file", "")
        if flix_rows.is_more(f) or (row is not None and row.kind == "coll"):
            # submenú de sección / página siguiente: su rejilla de carátulas
            title = self.section[1] if self.section else row.title if row else ""
            HOME.setProperty("flix_section", "%s · %s" % (title, "Más" if flix_rows.is_more(f) else clean(f.get("label"))))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
            return
        a = f.get("art") or {}
        HOME.setProperty("flix_title", clean(f.get("label")))
        HOME.setProperty("flix_poster", poster_of(f))
        HOME.setProperty("flix_fanart", a.get("fanart") or "")
        HOME.setProperty("flix_meta", str(f.get("year") or ""))
        log("abrir %s (%s/%s)" % (clean(f.get("label")), f.get("type"), f.get("filetype")))
        HOME.setProperty("fh_played", "1")
        if f.get("type") == "tvshow" or (f.get("filetype") == "directory" and "palantir3" in path):
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        elif f.get("filetype") == "directory":
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        else:
            import flix_play
            flix_play.play(path, *flix_play.resume_of(f), title=clean(f.get("label")), fanart=a.get("fanart") or "")


def wait_no_modal(limit=60.0):
    """con un diálogo modal delante (menú de apagado, rueda de carga, aviso de Palantir) Kodi rechaza abrir el Inicio
    («Activate of window 13000 refused because there are active modal dialogs») y doModal se queda esperando para
    siempre: se espera a que se cierre (auditoría 22-oct A-04)"""
    end = time.time() + limit
    while xbmc.getCondVisibility("System.HasModalDialog") and time.time() < end:
        xbmc.sleep(200)


def already_open():
    """¿hay un Inicio abierto? Lo trae delante. Si la marca está pero la ventana no aparece (destruida, o se quedó
    sin verse), no lo hay: igual que el Inicio de la TV (1.5.44)"""
    if HOME.getProperty("fh_running") != "1":
        return False
    if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
        return True     # recarga con una película en marcha: traer el Inicio delante la cortaba (A-05)
    wid = HOME.getProperty("fh_window")
    if wid:
        xbmc.executebuiltin("ActivateWindow(%s)" % wid)
        for _ in range(20):
            xbmc.sleep(100)
            if str(xbmcgui.getCurrentWindowId()) == wid:
                return True
    log("el Inicio abierto ya no está: abro otro")
    return False


def close_if_unseen(win, wait=6.0):
    """si Kodi no llega a enseñar la ventana (onInit) en unos segundos, se cierra: doModal volvería solo al cerrar Kodi"""
    end = time.time() + wait
    while time.time() < end and not win.inited:
        xbmc.sleep(200)
    if not win.inited:
        log("el Inicio no se ha visto en %d s: lo cierro" % wait)
        win.close()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "search":           # resultados del buscador (flix_search.py táctil)
        win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", search=True,
                       section=("search", HOME.getProperty("flix_search_title")))
        win.doModal()
        win.stop = True
        del win
        return
    if len(sys.argv) > 2 and sys.argv[1] == "sec":             # sección: RunScript(flix_home.py,sec,<clave>)
        s = flix_sections.section(sys.argv[2]) or flix_sections.section("peliculas")
        win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", section=(s["src"], flix_sections.flix_sections_conf.shown(s)),
                       rconf=s.get("rows") or {})
        win.doModal()
        win.stop = True
        del win
        return
    if len(sys.argv) > 2 and sys.argv[1].startswith("p3"):     # accesos de antes: RunScript(flix_home.py,p3Dibujos,Dibujos)
        win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", section=(sys.argv[1], sys.argv[2]))
        win.doModal()
        win.stop = True
        del win
        return
    wait_no_modal()
    if already_open():
        return
    token = "%f" % time.time()
    HOME.setProperty("fh_running", "1")
    HOME.setProperty("fh_token", token)      # un Inicio viejo que siga vivo lo ve y se retira (hero_timer)
    try:
        for _ in range(3):
            win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", token=token)
            threading.Thread(target=close_if_unseen, args=(win,), daemon=True).start()
            win.doModal()
            win.stop = True
            seen = getattr(win, "inited", True)
            del win
            if seen or HOME.getProperty("fh_token") != token:
                break
            log("el Inicio no llegó a verse (diálogo delante): lo vuelvo a abrir")
            wait_no_modal()
    finally:
        if HOME.getProperty("fh_token") == token:
            HOME.clearProperty("fh_running")
            HOME.clearProperty("fh_window")
            HOME.clearProperty("fh_token")


if __name__ == "__main__":
    main()
