"""Inicio TV (ventana FlixInicio.xml): mismo diseño de siempre, con la carga de las secciones.

Antes cada fila del Inicio era una lista de Kodi con la ruta de Palantir: una llamada a Palantir por fila (Palantir
atiende de una en una, 2-4 s cada una, arrancando su Python cada vez) y las filas lejanas no se pedían hasta acercarse.
Ahora (Carlos, 22-oct: «como las secciones, que van fenomenal»):
  - cada fila se pinta al momento con lo guardado (flix_rows: rows_cache2.json, la caché de las secciones), aunque
    esté caducado, y Palantir se pide por detrás, de una en una y en orden, solo para lo caducado o sin guardar;
  - pulsar una carátula abre el aviso o la ficha dentro de este mismo Python (sin RunScript: ~0,1 s menos por clic).
Las filas y su orden salen de home_order.json (Ajustes → Personalizar menú e Inicio): flix_home_order.py escribe el
trozo FLIX_ROWS de FlixInicio.xml y pone Window(home).Property(fi_reload) para que esta ventana se rehaga.
Recargas de una fila: Window(home).Property(flix_rl_<src>) (las ponen flix_menu, flix_p3sync…, como antes) y, tras
ver un vídeo, «Seguir viendo» y «Series en seguimiento». El progreso (▶/✓) se repinta cuando cambia watched.db.

Uso: RunScript(special://skin/scripts/flix_inicio.py)   (lo lanza Home.xml al cargar; si ya está abierto, lo trae)
"""
import html
import os
import re
import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_home_conf as hc  # noqa: E402
import flix_rows  # noqa: E402
from flix_section import A_BACK, LOADING, make_item, placeholder  # noqa: E402

HOME = xbmcgui.Window(10000)
SKIN = xbmcvfs.translatePath("special://skin/")
A_CONTEXT = (117,)              # ACTION_CONTEXT_MENU (mantener OK / tecla menú)
A_NAV = (1, 2, 3, 4)            # izquierda, derecha, arriba, abajo
# filas personales: cambian al ver algo (no al caducar) -> se vuelven a pedir al terminar un vídeo
PERSONAL = ("p3PathPeliculasNoFinalizadas", "p3PathSeriesSeguimiento")
VAR_FILES = ("Includes_Flix.xml", "Includes_Palantir3.xml", "Variables.xml")
TICK = 0.5


def log(msg):
    xbmc.log("[flix_inicio] %s" % msg, xbmc.LOGINFO)


# ---------- rutas de las filas ----------
def skin_vars(texts):
    """{nombre: último <value>} de las variables del skin (el por defecto, como en tools/gen_touch_home.py)"""
    out = {}
    for t in texts:
        for name, body in re.findall(r'<variable name="([^"]+)">(.*?)</variable>', t, re.S):
            vals = re.findall(r"<value[^>]*>(.*?)</value>", body, re.S)
            if vals:
                out[name] = html.unescape(vals[-1].strip())
    return out


def resolve(path, variables, info=lambda k: ""):
    """$VAR[...] (recursivo) y $INFO[...] (en vivo) de una ruta de fila"""
    for _ in range(5):
        new = re.sub(r"\$VAR\[([^\]]+)\]", lambda m: variables.get(m.group(1), ""), path)
        if new == path:
            break
        path = new
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: info(m.group(1)), path)


def row_url(row, variables, info):
    """ruta de Palantir de una fila; las añadidas llevan &reload= pegado a su flix_rl (como la fila de Kodi de antes)"""
    if row.get("custom"):
        return row["path"] + "&reload=1" + info("Window(home).Property(flix_rl_%s)" % src_of(row))
    return resolve(row["path"], variables, info)


def src_of(row):
    return row.get("src") or "FlixRowPath%d" % row["id"]


def visible_rows(defaults, conf):
    """filas que se ven, en su orden: dicts con id, label (el nombre propio si lo tiene), limit, kind"""
    out = []
    for r in hc.compose(defaults, conf):
        if r["hidden"]:
            continue
        out.append(dict(r, label=r.get("title") or r["label"], kind="list",
                        limit=hc.TOP10_ITEMS if r.get("top10") else conf["items"]))
    return out


def state_sig(files):
    """lo que se ve de una fila: títulos, en orden, con su ✓ y su ▶ (si cambia algo se repinta)"""
    out = []
    for f in files or []:
        r = f.get("resume") or {}
        out.append((f.get("file"), f.get("playcount") or 0, int(r.get("position") or 0)))
    return out


class InicioWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows = kwargs.get("rows") or []
        self.token = kwargs.get("token") or ""
        self.variables = kwargs.get("variables") or {}
        self.by_id = {r["id"]: r for r in self.rows}
        self.shown = {}             # id -> files pintados (None = aún nada)
        self.sigs = {}              # id -> state_sig de lo pintado
        # id -> último flix_rl_<src> visto (aquí y no en load: watch() arranca a la vez y lo tomaba todo por recargas)
        self.rl = {r["id"]: HOME.getProperty("flix_rl_%s" % src_of(r)) for r in self.rows}
        self.queue = []             # filas que hay que pedir a Palantir (en orden)
        self.pending = {}           # id -> lo que llegó con el Inicio tapado: se pinta al volver (onInit)
        self.items = {}             # id -> ListItems pintados (los nuestros: ver sel_pos)
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.stop = False
        self.started = False
        self.reloaded = False
        self.played = False
        self.wsig = HOME.getProperty("flix_progress_wsig")

    # ---------- ciclo de vida ----------
    def onInit(self):
        HOME.setProperty("fi_window", str(xbmcgui.getCurrentWindowId()))
        if not self.started:
            self.started = True
            threading.Thread(target=self.load, daemon=True).start()
            threading.Thread(target=self.watch, daemon=True).start()
            return
        # de vuelta de otra ventana: lo que llegó mientras tanto. Tras recargar el skin Kodi vuelve a montar esta
        # ventana desde el XML (listas vacías): se repinta lo que había
        with self.lock:
            pending, self.pending = self.pending, {}
        for lid, (kind, a, b) in pending.items():
            if kind == "show":
                self.show(a, b)
            else:
                self.refill(lid, a, b)
        for r in self.rows:
            files = self.shown.get(r["id"])
            if files and xbmc.getInfoLabel("Container(%d).NumItems" % r["id"]) in ("", "0"):   # size(): copia Python
                self.sigs.pop(r["id"], None)
                self.show(r, files)
        self.refresh_stale()

    def close_for_reload(self):
        self.reloaded = True
        self.stop = True
        self.wake.set()
        self.close()

    # ---------- carga ----------
    def url(self, row):
        return row_url(row, self.variables, xbmc.getInfoLabel)

    def load(self):
        """1) lo guardado al momento, aunque esté caducado; 2) Palantir por detrás, en orden, solo lo que haga falta"""
        try:
            pending = []
            for r in self.rows:
                if self.stop:
                    return
                files, fresh = flix_rows.peek(self.url(r))
                if files:
                    self.show(r, files)
                else:
                    self.refill(r["id"], [placeholder(LOADING)])
                if not fresh:
                    pending.append(r)
            self.enqueue(pending)
            self.worker()
        except RuntimeError:
            if not self.stop:
                raise
            # Inicio cerrado mientras cargaba: Kodi ya destruyó la ventana

    def enqueue(self, rows, first=False):
        with self.lock:
            ids = [q["id"] for q in self.queue]
            new = [r for r in rows if r["id"] not in ids]
            self.queue = (new + self.queue) if first else (self.queue + new)
        self.wake.set()

    def worker(self):
        """pide a Palantir las filas en cola, de una en una (Palantir no atiende dos a la vez)"""
        k = 0
        while not self.stop:
            with self.lock:
                row = self.queue.pop(0) if self.queue else None
            if row is None:
                flix_rows.flush()
                self.wake.wait()
                self.wake.clear()
                continue
            try:
                files, _ = flix_rows.fetch(self.url(row), force=True, save=False)
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row["label"], e))
                files = None
            if self.stop:
                break
            if files:
                self.show(row, files)
                log("fila %s: %d (Palantir)" % (row["label"], len(files)))
            elif not self.shown.get(row["id"]):
                self.refill(row["id"], [])      # sin nada que enseñar (p. ej. «Seguir viendo» vacío): la fila se oculta
            k += 1
            if k % 4 == 0:
                flix_rows.flush()

    def refresh_stale(self):
        """al volver al Inicio: lo caducado se vuelve a pedir por detrás (lo de antes sigue a la vista)"""
        stale = [r for r in self.rows if not flix_rows.peek(self.url(r))[1]]
        if stale:
            self.enqueue(stale)

    # ---------- vigilancia: recargas pedidas, progreso, vídeo, configuración ----------
    def watch(self):
        mon = xbmc.Monitor()
        while not self.stop and not mon.waitForAbort(TICK):
            try:
                self.tick()
            except RuntimeError:
                if not self.stop:
                    log("vigilancia: ventana no disponible")
            except Exception as e:  # noqa: BLE001
                log("vigilancia: %s" % e)

    def tick(self):
        if HOME.getProperty("fi_token") != self.token:
            # otro Inicio tomó el relevo (esta ventana se perdió en un cambio de skin): este se va
            log("Inicio relevado por otro: me cierro")
            self.stop = True
            self.wake.set()
            self.close()
            return
        mine = HOME.getProperty("fi_window") == str(xbmcgui.getCurrentWindowId())
        if HOME.getProperty("fi_reload") and mine:
            HOME.clearProperty("fi_reload")
            log("filas nuevas (Personalizar Inicio): se rehace el Inicio")
            self.close_for_reload()
            return
        bumped = []
        for r in self.rows:
            v = HOME.getProperty("flix_rl_%s" % src_of(r))
            if v != self.rl.get(r["id"]):
                self.rl[r["id"]] = v
                bumped.append(r)
        if xbmc.getCondVisibility("Player.HasVideo"):
            self.played = True
        elif self.played:
            self.played = False
            bumped += [r for r in self.rows if src_of(r) in PERSONAL and r not in bumped]
        if bumped:
            log("recargo %s" % ", ".join(r["label"] for r in bumped))
            self.enqueue(bumped, first=True)
        wsig = HOME.getProperty("flix_progress_wsig")
        if wsig != self.wsig:               # watched.db cambió (flix_progress): ▶/✓ al día con lo guardado
            self.wsig = wsig
            for r in self.rows:
                files, _ = flix_rows.peek(self.url(r))
                if files:
                    self.show(r, files)

    # ---------- pintar ----------
    def active(self):
        """¿el Inicio está delante? Solo entonces se tocan sus listas. Al actualizarse sola la skin, Kodi la recarga
        y destruye las ventanas: un hilo que pintaba una fila tocó una lista ya borrada y Kodi se cayó (SIGSEGV en
        xbmcgui::Control, Shield 22-oct). Tapado (otra ventana, recarga) se guarda y se pinta al volver"""
        return HOME.getProperty("fi_window") == str(xbmcgui.getCurrentWindowId())

    def show(self, row, files):
        if not self.active():
            with self.lock:
                self.pending[row["id"]] = ("show", row, files)
            return
        files = files[:row["limit"]]
        sig = state_sig(files)
        if self.sigs.get(row["id"]) == sig and self.items.get(row["id"]):
            return
        self.sigs[row["id"]] = sig
        self.shown[row["id"]] = files
        self.refill(row["id"], [make_item(f, row) for f in files], self.sel_pos(row["id"]))

    def sel_pos(self, lid):
        """posición seleccionada de una fila (0 si vacía), preguntando a Kodi. NO con ControlList.getSelectedPosition
        ni getSelectedItem: tras recargar la skin (actualización automática) el objeto de Python sigue apuntando a
        la lista vieja, ya borrada, y Kodi se caía (SIGSEGV en ControlList::getSelectedPosition, 22-oct). reset,
        addItems, selectItem y setFocusId van por id y son seguros"""
        try:
            return max(0, int(xbmc.getInfoLabel("Container(%d).CurrentItem" % lid) or 0) - 1)
        except ValueError:
            return 0

    def focus_id(self):
        try:
            return self.getFocusId() or None
        except RuntimeError:                        # ningún control de la ventana tiene el foco
            return None

    def first_alive(self, skip=None):
        for r in self.rows:
            if r["id"] != skip and self.items.get(r["id"]):
                return r["id"]
        return None

    def refill(self, lid, items, pos=0):
        """vacía y rellena una fila sin perder el foco: Kodi suelta el de una lista vacía (fallo de la 1.5.38 en
        las secciones). Si la fila lo tenía o nadie lo tiene y es la primera con títulos, se le devuelve; si se queda
        vacía con el foco, pasa a la primera fila con títulos"""
        if not self.active():
            with self.lock:
                self.pending[lid] = ("refill", items, pos)
            return
        focus = self.focus_id()
        lst = self.getControl(lid)
        lst.reset()
        self.items[lid] = list(items)
        if items:
            lst.addItems(items)
            if pos > 0:
                lst.selectItem(min(pos, len(items) - 1))
            if focus == lid or (focus is None and self.first_alive() == lid):
                self.setFocusId(lid)
        elif focus == lid or focus is None:
            nxt = self.first_alive(skip=lid)
            if nxt:
                self.setFocusId(nxt)

    # ---------- mando ----------
    def onAction(self, action):
        aid = action.getId()
        if aid in A_BACK:
            return                  # Atrás lo hace cada control (<onback>: filas -> menú -> ajustes -> apagar)
        if aid in A_CONTEXT and self.focus_id() in self.by_id:
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_menu.py)")    # carátula de flix_row
            return
        if aid in A_NAV and self.focus_id() is None:    # foco perdido: la tecla no iría a ningún sitio
            target = self.first_alive()
            self.setFocusId(target or 9000)
            return
        super().onAction(action)

    def onClick(self, control_id):
        if control_id not in self.by_id:
            return
        items, pos = self.items.get(control_id) or [], self.sel_pos(control_id)
        item = items[pos] if pos < len(items) else None
        if not item or not item.getProperty("open"):     # «Cargando…»
            return
        path, how = item.getPath(), item.getProperty("open")
        HOME.setProperty("flix_title", item.getProperty("P3Titulo") or item.getLabel())
        HOME.setProperty("flix_poster", item.getArt("poster"))
        HOME.setProperty("flix_fanart", item.getArt("fanart"))
        if how == "grid":
            HOME.setProperty("flix_section", "%s · %s" % (self.by_id[control_id]["label"], item.getLabel()))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        elif how == "series":
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        else:
            import flix_play
            tag = item.getVideoInfoTag()
            flix_play.play(path, tag.getResumeTime(), tag.getResumeTimeTotal(), item.getLabel(), item.getArt("fanart"))


def read_skin(name):
    try:
        with xbmcvfs.File("special://skin/xml/%s" % name) as fh:
            return fh.read()
    except Exception:  # noqa: BLE001
        return ""


def open_window(token=""):
    import flix_home_order
    flix_home_order.check()                 # FlixInicio.xml con las filas guardadas (tras actualizar el skin…)
    HOME.clearProperty("fi_reload")
    conf = flix_home_order.load_conf() or hc.normalize(None)
    rows = visible_rows(flix_home_order.tv_default_blocks(), hc.normalize(conf))
    win = InicioWindow("FlixInicio.xml", SKIN, "Default", "1080i", rows=rows, token=token,
                       variables=skin_vars(read_skin(n) for n in VAR_FILES))
    win.doModal()
    win.stop = True
    win.wake.set()
    reloaded = win.reloaded
    del win
    return reloaded


def already_open():
    """¿hay un Inicio abierto? Lo trae delante. Si la marca está pero la ventana no aparece (Kodi la destruyó al
    cambiar de skin y volver: se quedaba la lanzadera con el menú y sin filas, Kodi limpio 22-oct), no lo hay"""
    if HOME.getProperty("fi_running") != "1":
        return False
    wid = HOME.getProperty("fi_window")
    if wid:
        xbmc.executebuiltin("ActivateWindow(%s)" % wid)
        for _ in range(20):
            xbmc.sleep(100)
            if str(xbmcgui.getCurrentWindowId()) == wid:
                return True
    log("el Inicio abierto ya no está: abro otro")
    return False


def main():
    if already_open():
        return
    token = "%f" % time.time()
    HOME.setProperty("fi_running", "1")
    HOME.setProperty("fi_token", token)          # el Inicio viejo, si sigue vivo, lo ve y se cierra (tick)
    try:
        while open_window(token):
            xbmc.sleep(300)                 # que los hilos de la ventana vieja vean stop y salgan
    finally:
        if HOME.getProperty("fi_token") == token:
            HOME.clearProperty("fi_running")
            HOME.clearProperty("fi_window")
            HOME.clearProperty("fi_token")


if __name__ == "__main__":
    main()
