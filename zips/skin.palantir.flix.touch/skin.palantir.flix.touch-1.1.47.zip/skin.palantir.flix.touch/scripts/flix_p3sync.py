"""Sincronización de Palantir con Trakt al arrancar, sin frenar el Inicio.

Palantir no tiene servicio: lo que se marca en OTRO aparato (vista, progreso, dejar de seguir) solo baja de Trakt
cuando se abre SU MENÚ RAÍZ (plugin://plugin.video.palantir3/), que la skin original enseñaba en el Inicio. Nuestro
Inicio va directo a las filas y nunca lo abre: la Shield llevaba días sin traer nada de Trakt (Carlos, 20-oct:
Obsession vista en la Shield y no en el móvil, serie dejada de seguir que seguía). Probado en la Shield (20-oct):
listar la raíz trae lo marcado en el móvil en ~10 s; `RunScript(plugin.video.palantir3,None,&update=1)` no trae nada.
Y SOLO la 1.ª vez de cada sesión de Kodi (medido 20-oct en Shield y Fire TV: 2.ª raíz, raíz en pantalla, marcar
vista / no vista... nada vuelve a bajar de Trakt hasta reiniciar Kodi; la skin original tampoco lo pide más): por
eso se hace una sola vez, al arrancar (antes repetía cada 30 min y al acabar un vídeo sin traer nada).

Ahora se lista la raíz (sin enseñarla) DELAY s después del arranque y, cuando Palantir termina de escribir watched.db,
se ponen al día las filas: ✓ y progreso de películas (flix_progress.py) y, si cambiaron series seguidas o
capítulos vistos, la lista «Series en seguimiento» de la caché de Palantir se borra y se recarga esa fila.
Antes de listarla se preparan las pausas (prepare_pauses) para que las pelis/capítulos a medias queden iguales que
en Trakt: Palantir por sí solo nunca borra lo quitado del progreso en otro aparato.
Lo llama first_run.py (una vez por sesión)."""
import json
import os
import shutil
import sqlite3
import sys
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HOME = xbmcgui.Window(10000)
P3DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/")
WATCHED_DB = os.path.join(P3DATA, "watched.db")
CACHE_DB = os.path.join(P3DATA, "cache.db")
SEEN_FILE = xbmcvfs.translatePath("special://profile/addon_data/%s/p3sync_seen.json" % xbmc.getSkinDir())
ROOT = "plugin://plugin.video.palantir3/"
DELAY = 20          # s tras el arranque: el Inicio ya está pintado
WATCH = 120         # s como mucho esperando a que Palantir escriba (tarda ~10 s)
STEP = 5
PAUSE_TABLES = {"movies": "movies_watched", "episodes": "episodes_watched"}
BACKUP = WATCHED_DB + ".flixbak"   # copia antes de rehacer las pausas (se restaura si Palantir no las rellena)


def log(msg):
    xbmc.log("[flix_p3sync] %s" % msg, xbmc.LOGINFO)


def file_sig():
    out = []
    for f in (WATCHED_DB, WATCHED_DB + "-wal"):
        try:
            st = os.stat(f)
            out.append("%d:%d" % (st.st_mtime_ns, st.st_size))
        except OSError:
            out.append("-")
    return "|".join(out)


def shows_sig():
    """series seguidas (no ocultas) + capítulos vistos: si cambian, «Series en seguimiento» está vieja"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            shows = sorted(r[0] for r in db.execute("SELECT tmdb_id FROM shows_watched WHERE NOT ocultar"))
            eps = db.execute("SELECT COUNT(*), MAX(lastPlayed), SUM(progress) FROM episodes_watched").fetchone()
        finally:
            db.close()
        return repr((shows, eps))
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def paused_at():
    """{'movies'|'episodes': fecha del último cambio de pausas en Trakt que ha bajado Palantir}"""
    try:
        db = sqlite3.connect("file:%s?mode=ro" % WATCHED_DB, uri=True, timeout=5)
        try:
            return {t: d for t, d in db.execute(
                "SELECT type, date FROM last_activities_trakt WHERE action = 'paused_at'") if t in PAUSE_TABLES}
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("watched.db pausas: %s" % e)
        return None


def load_seen():
    """firmas de watched.db que vio la última sincronización, también de sesiones anteriores: Palantir puede
    traer de Trakt ANTES de nuestra 1.ª consulta (al pedirle las filas caducadas al arrancar) y entonces la foto
    «antes» ya sale nueva y las filas guardadas se quedaban viejas (Carlos, 20-oct: Carrie dejada de seguir en la
    Shield seguía con ▶ en el móvil)"""
    try:
        with open(SEEN_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_seen():
    try:
        os.makedirs(os.path.dirname(SEEN_FILE), exist_ok=True)
        with open(SEEN_FILE, "w") as f:
            json.dump({"file": file_sig(), "shows": shows_sig()}, f)
    except OSError as e:
        log("no guardo %s: %s" % (SEEN_FILE, e))


def refresh_follow():
    try:
        db = sqlite3.connect(CACHE_DB, timeout=5)
        try:
            n = db.execute("DELETE FROM simplecache WHERE id LIKE '%SeriesSeguimiento%'").rowcount
            db.commit()
        finally:
            db.close()
        log("caché de Series en seguimiento borrada (%d)" % n)
    except Exception as e:  # noqa: BLE001
        log("no borro la caché de Series en seguimiento: %s" % e)
    HOME.setProperty("flix_rl_p3PathSeriesSeguimiento", str(int(time.time() * 10)))   # fila TV
    refetch_touch("5102")                                                            # Inicio táctil


def refresh_resume():
    """«Seguir viendo» también: en una instalación limpia se pidió antes de que Palantir bajara nada de Trakt"""
    HOME.setProperty("flix_rl_p3PathPeliculasNoFinalizadas", str(int(time.time() * 10)))  # fila TV
    refetch_touch("5101")


def refetch_touch(rid):
    """Inicio táctil (flix_home.py): ids de fila a volver a pedir, separados por comas"""
    cur = [x for x in HOME.getProperty("fh_refetch_row").split(",") if x]
    if rid not in cur:
        HOME.setProperty("fh_refetch_row", ",".join(cur + [rid]))


def list_root(mon):
    """lista la raíz de Palantir (lo que le hace bajar de Trakt) y espera a que termine de escribir watched.db;
    True si escribió, False si no, None si Kodi se cierra"""
    start, last = time.time(), file_sig()
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
                                    "params": {"directory": ROOT, "media": "video"}}))
    changed = False
    while time.time() - start < WATCH:
        if mon.waitForAbort(STEP):
            return None
        sig = file_sig()
        if sig != last:                 # sigue escribiendo: esperar a que pare
            last, changed = sig, True
            continue
        if changed:
            break                       # escribió y lleva STEP s quieto
    return changed


def prepare_pauses():
    """deja que Palantir rehaga las pelis/capítulos a medias IGUAL que en Trakt. Palantir, al bajar de Trakt, añade y
    actualiza pero NUNCA borra: lo que se quita del progreso en otro aparato se quedaba aquí para siempre (Carlos,
    20-oct: 4 pelis quitadas en la Shield seguían en «Seguir viendo» del móvil). Si se le borran las filas a medias y
    la fecha de pausas, en su 1.ª raíz de la sesión vuelve a bajar la lista ENTERA de Trakt (probado en la Shield
    20-oct: 63/63 pelis, mismos porcentajes). Se conservan las filas posteriores a la última fecha de pausas
    (progreso de este aparato que Palantir aún no haya subido, p. ej. sin conexión); las vistas (playcount > 0) no
    se tocan. Copia antes en BACKUP. Devuelve los tipos preparados ([] si no había nada que preparar)."""
    pa = paused_at()
    kinds = [k for k in PAUSE_TABLES if (pa or {}).get(k)]
    if not kinds:
        return []                       # sin fecha de pausas: Palantir ya baja la lista entera
    try:
        shutil.copyfile(WATCHED_DB, BACKUP)
        db = sqlite3.connect(WATCHED_DB, timeout=10)
        try:
            for k in kinds:
                n = db.execute("DELETE FROM %s WHERE playcount = 0 AND progress > 0 AND "
                               "(lastPlayed IS NULL OR lastPlayed <= ?)" % PAUSE_TABLES[k], (pa[k],)).rowcount
                db.execute("DELETE FROM last_activities_trakt WHERE type = ? AND action = 'paused_at'", (k,))
                log("pausas %s: %d filas fuera, Palantir las vuelve a bajar de Trakt" % (k, n))
            db.commit()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("no preparo las pausas: %s" % e)
        return []
    return kinds


def check_pauses(kinds):
    """tras la raíz: si Palantir no rellenó las pausas (sin conexión, Trakt caído...) se restaura la copia"""
    after = paused_at()
    if after is not None and all(k in after for k in kinds):
        log("pausas iguales que en Trakt (%s)" % ", ".join(kinds))
        return
    log("Palantir no rellenó las pausas (¿sin conexión?): restauro la copia")
    try:
        shutil.copyfile(BACKUP, WATCHED_DB)
    except OSError as e:
        log("no restauro %s: %s" % (BACKUP, e))


def sync_once(mon):
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.palantir3)"):
        return
    # instalación limpia: watched.db no existe hasta que Palantir baja de Trakt en su 1.ª raíz. Antes aquí se salía y
    # las filas personales del Inicio, pedidas vacías, no se volvían a pedir (Carlos, 22-oct)
    fresh = not os.path.exists(WATCHED_DB)
    seen = load_seen()                  # sin fichero (1.ª vez): se refresca todo una vez
    log("lanzo la sincronización de Palantir")
    # mientras Palantir rebaja las pausas, watched.db está sin ellas: el Inicio táctil no debe quitar nada de
    # «Seguir viendo» (flix_home.sync_progress)
    HOME.setProperty("flix_p3sync_busy", "1")
    try:
        kinds = [] if fresh else prepare_pauses()
        start = time.time()
        changed = list_root(mon)
        if changed is None:
            return                      # Kodi se cierra: sin fecha de pausas, Palantir las rebaja al próximo arranque
        if kinds:
            check_pauses(kinds)
    finally:
        HOME.clearProperty("flix_p3sync_busy")
    if fresh and not os.path.exists(WATCHED_DB):
        log("Palantir sin datos de Trakt todavía")
        return
    if not changed and file_sig() == seen.get("file"):
        log("sin cambios de Trakt en %d s" % (time.time() - start))
        return
    log("watched.db cambió (%s): pongo al día las filas" % ("en %.0f s" % (time.time() - start) if changed
                                                            else "antes de consultar"))
    if fresh or shows_sig() != seen.get("shows"):
        refresh_follow()
    if fresh:
        refresh_resume()
    HOME.setProperty("fh_progress", "1")          # Inicio táctil: repinta ✓ y barras (flix_home.sync_progress)
    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")
    save_seen()


def main():
    mon = xbmc.Monitor()
    if mon.waitForAbort(DELAY):
        return
    sync_once(mon)


if __name__ == "__main__":
    main()
