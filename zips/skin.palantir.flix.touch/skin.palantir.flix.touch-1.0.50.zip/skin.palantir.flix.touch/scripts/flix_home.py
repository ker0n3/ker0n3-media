"""Home TÁCTIL de Ker0n3 Flix (ventana FlixHome.xml), con INERCIA y paso lateral por filas.

Por qué un script (código de Kodi 21):
  - La inercia solo existe en listas/paneles (responden a GESTURE_NOTIFY); un grouplist no la tiene.
    => toda la Home es UNA lista vertical (7000) y cada elemento es una fila.
  - Un elemento de lista no puede contener otra lista, así que los pósters de cada fila son
    propiedades del elemento (p0..p8) y este script decide qué enseñar.
  - WindowXML.onAction recibe TODAS las acciones con coordenadas (getAmount1/2): toque (100) =>
    qué póster se ha tocado; swipe izq/der (511/521) => qué fila pasar de página. El arrastre vertical
    lo hace la lista sola, con inercia, empiece donde empiece el dedo.
Geometría compartida con tools/gen_touch_flixhome.py.
"""
import json
import os
import re
import threading
import time

import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_rows  # noqa: E402  (secciones en filas, compartido con la TV)
import flix_cache  # noqa: E402

HOME = xbmcgui.Window(10000)
SKIN = xbmcvfs.translatePath("special://skin/")
ROWS = json.load(open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8"))
CHIPS = json.load(open(os.path.join(SKIN, "scripts", "flix_home_chips.json"), encoding="utf-8"))
CHIP_W, CHIP_GAP, CHIPS_H = 280, 20, 120   # = tools/gen_touch_flixhome.py
LEFT, ROW_H, SLOTS, HEADER_H = 56, 540, 9, 140  # la lista empieza en y=HEADER_H
STEP = 60                  # alto de cada elemento de la lista (FlixHome.xml)
PIECES = ROW_H // STEP     # trozos por fila: cada uno dibuja la fila entera (ver generador)
RES = [(1920, 1080), (1920, 1200), (2160, 1080), (2338, 1080), (2400, 1080), (2520, 1080)]
CACHE_TTL = 1800   # 30 min: cada llamada a Palantir consulta la API de GitHub (60/h por IP, compartido con la Shield)
CACHE_FILE = xbmcvfs.translatePath("special://profile/addon_data/skin.palantir.flix.touch/home_cache.json")
COLOR_RE = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE)[^\]]*\]")
A_CLICK, A_SELECT, A_MOVE = 100, 7, 107
A_SWIPE_L, A_SWIPE_R = 511, 521
A_BEGIN, A_PAN, A_ABORT, A_END = 501, 504, 505, 599
A_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)
A_CONTEXT = (101, 117)


def log(msg):
    xbmc.log("[flix_home] %s" % msg, xbmc.LOGINFO)


def clean(s):
    return COLOR_RE.sub("", s or "").strip()


def skin_res():
    sw, sh = xbmcgui.getScreenWidth(), xbmcgui.getScreenHeight()
    w, h = min(RES, key=lambda r: abs(r[0] / r[1] - sw / sh))
    return w, h, sw, sh


SKIN_W, SKIN_H, SCR_W, SCR_H = skin_res()


def live(path):
    """resuelve en vivo los $INFO[...] que llevan algunas rutas (p. ej. &reload=$INFO[Window(home).Property(P3Reload…)])"""
    return re.sub(r"\$INFO\[([^\]]+)\]", lambda m: xbmc.getInfoLabel(m.group(1)), path)


_cache = None
_cache_lock = threading.Lock()


def _cache_load():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as fh:
                _cache = json.load(fh)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cache_save():
    # con el lock: otro hilo de carga puede estar añadiendo filas (antes: «dictionary changed size» y el hilo moría)
    if not flix_cache.save_json(CACHE_FILE, _cache, _cache_lock):
        log("no guardo caché")


def fetch(path, force=False):
    """filas de Palantir con caché en disco (sobrevive a reinicios de Kodi). Clave = ruta sin el
    parámetro &reload= (cambia en cada sesión y no debe invalidar la caché)."""
    key = re.sub(r"&reload=[^&]*", "", path)
    cache = _cache_load()
    hit = cache.get(key)
    if hit and not force and time.time() - hit[0] < CACHE_TTL:
        return flix_rows._progress(hit[1]), True
    raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": live(path), "media": "video",
        "properties": ["title", "art", "year", "genre", "rating", "runtime", "resume", "playcount", "file"]}}))
    files = ((json.loads(raw).get("result") or {}).get("files")) or []
    files = [f for f in files if f.get("label") and not clean(f["label"]).endswith(":")]
    if files:                 # vacío = fallo de Palantir: no machaca una caché buena ni se guarda
        with _cache_lock:
            cache[key] = [time.time(), files]
        _cache_save()
    return flix_rows._progress(files or (hit[1] if hit else [])), False


def poster_of(f):
    a = f.get("art") or {}
    return a.get("poster") or a.get("thumb") or a.get("tvshow.poster") or ""


_anim_n = [0]


def anim_name(step):
    """valor para ListItem.Property(anim): L1/L2 (entra por la derecha) R1/R2 (por la izquierda);
    alternar el número re-dispara la animación Conditional"""
    _anim_n[0] += 1
    return ("L" if step > 0 else "R") + str(_anim_n[0] % 2 + 1)


def pct_of(f):
    r = f.get("resume") or {}
    if r.get("total"):
        return str(int(100 * r.get("position", 0) / r["total"]))
    return ""


class Strip:
    """una fila de la Home (o el hero) = PIECES elementos de la lista con las mismas propiedades"""

    def __init__(self, kind, label, pieces=PIECES):
        self.kind = kind
        self.lis = []
        self.vals = {}
        self.height = pieces * STEP
        for j in range(pieces):
            # offscreen=True: setProperty no espera al hilo de dibujo de Kodi (con GUI lock cada llamada
            # tarda ~1 fotograma; 9 trozos x varias propiedades = trompicones al arrastrar)
            li = xbmcgui.ListItem(label, offscreen=True)
            li.setProperty("type", kind)
            li.setProperty("j", str(j))
            li.setProperty("w", str(SKIN_W))
            self.lis.append(li)

    def set(self, key, value):
        if self.vals.get(key) == value:
            return
        self.vals[key] = value
        for li in self.lis:
            li.setProperty(key, value)


OX_STEP = 5         # px por paso de la fracción de póster (FlixHome.xml)
SNAP_EDGE = 0.2     # al soltar: encaja a carátula entera solo si la fracción del borde es < 20 % o > 80 %
SLOTS_SET = 10      # huecos por juego (FlixHome.xml SLOTS)


class Row:
    """fila de pósters con desplazamiento continuo. pos = posición en pósters (2.4 = 3.er póster a la
    izquierda y 0.4 desplazado). Dos juegos de huecos (a/b) en FlixHome.xml: el visible muestra los
    pósters desde 'start'; al cruzar un póster se rellena el otro juego (ListItem offscreen: no espera al
    dibujado) y se cambia juego + fracción con UNA propiedad (fh_o) -> sin saltos ni esperas"""

    def __init__(self, d):
        self.id, self.label, self.path, self.top10 = d["id"], d["label"], d["path"], d["top10"]
        self.kind = d.get("kind", "list")       # sección: "coll" = submenú (tarjetas que abren su rejilla)
        self.limit = d.get("limit")             # Inicio: elementos por fila elegidos en el editor (secciones: todos)
        self.items, self.pos, self.start, self.ox, self.buf, self.strip = [], 0.0, 0, 0, "a", None
        self._arrows = None
        self.win = None             # ventana mientras se arrastra (estado en Window.Property(fh_o))
        self._o = None
        self._painted = {"a": None, "b": None}

    @property
    def itemw(self):
        return 400 if self.top10 else 286

    @property
    def visible(self):
        return max(1, int((SKIN_W - LEFT) // self.itemw))

    @property
    def max_pos(self):
        return float(max(0, len(self.items) - self.visible))

    def set_items(self, files):
        self.items = files[:10] if self.top10 else (files[:self.limit] if self.limit else files)
        self.pos = min(self.pos, self.max_pos)

    def fill(self, buf, start):
        st = self.strip
        for k in range(SLOTS_SET):
            i = start + k
            if i < len(self.items):
                f = self.items[i]
                more = flix_rows.is_more(f)
                text = more or (self.kind == "coll" and flix_rows.is_generic(f))   # tarjeta de texto
                st.set("%sp%d" % (buf, k), "" if text else poster_of(f))
                st.set("%st%d" % (buf, k), "Ver más" if more else (clean(f.get("label")) or " "))
                st.set("%spc%d" % (buf, k), pct_of(f))
                st.set("%sn%d" % (buf, k), str(i + 1) if self.top10 else "")
            else:
                for p in ("p", "t", "pc", "n"):
                    st.set("%s%s%d" % (buf, p, k), "")
        self._painted[buf] = start

    def paint(self):
        """(re)pinta con los datos actuales (carga / refresco)"""
        self.start = int(self.pos)
        self.fill(self.buf, self.start)
        self._painted[self.other] = None
        self._arrows = None
        self.publish(force=True)

    @property
    def other(self):
        return "b" if self.buf == "a" else "a"

    def set_pos(self, pos):
        self.pos = max(0.0, min(float(pos), self.max_pos))
        start = int(self.pos)
        ox = int(round((self.pos - start) * self.itemw / OX_STEP))
        if ox * OX_STEP >= self.itemw:
            start, ox = start + 1, 0
        if start != self.start:
            nb = self.other
            if self._painted[nb] != start:
                self.fill(nb, start)              # el juego oculto: no se ve mientras se rellena
            self.buf, self.start = nb, start
        self.ox = ox
        self.publish()

    def publish(self, force=False):
        if self.win is not None:                  # arrastrando: juego + fracción en UNA propiedad
            o = "%s%02d" % (self.buf.upper(), self.ox)
            if o != self._o:
                self._o = o
                self.win.setProperty("fh_o", o)
        else:
            self.strip.set("buf", self.buf)
            self.strip.set("ox", str(self.ox) if self.ox else "")
        arrows = (self.pos > 0.05, self.pos < self.max_pos - 0.05)
        if force or arrows != self._arrows:
            self._arrows = arrows
            self.strip.set("prev", "1" if arrows[0] else "")
            self.strip.set("next", "1" if arrows[1] else "")

    def begin_drag(self, win):
        if self.win is None:
            self.win = win
            self._o = None
            self.publish()                        # primero la propiedad de ventana…
            self.strip.set("drag", "1")           # …luego la fila pasa a leerla

    def end_drag(self):
        if self.win is not None:
            win, self.win = self.win, None
            self.publish(force=True)              # estado final en la propia fila…
            self.strip.set("drag", "")            # …deja de leer la de ventana…
            win.setProperty("fh_o", "")

    def index_at(self, sx):
        return int((sx - LEFT) / self.itemw + self.pos)


class Animator(threading.Thread):
    """aplica el movimiento lateral a ~60 fps: sigue al dedo (drag) o desliza con frenada (glide).
    Los eventos del dedo solo guardan la posición deseada; así no se encolan repintados."""

    def __init__(self, win):
        super().__init__(daemon=True)
        self.win = win
        self.row = None
        self.drag_pos = None        # posición pedida por el dedo
        self.glide = None           # (inicio, destino, t0, duración)
        self.cv = threading.Condition()

    def _switch(self, row):
        if self.row is not None and self.row is not row:
            self.row.end_drag()
        row.begin_drag(self.win)

    def drag(self, row, pos):
        with self.cv:
            self._switch(row)
            self.row, self.glide, self.drag_pos = row, None, pos
            self.cv.notify()

    def stop_row(self, row):
        with self.cv:
            if self.row is row:
                self.glide = None

    def glide_to(self, row, target, dur=0.35):
        with self.cv:
            self._switch(row)
            self.row, self.drag_pos = row, None
            self.glide = (row.pos, max(0.0, min(float(target), row.max_pos)), time.time(), dur)
            self.cv.notify()

    def run(self):
        try:
            self._run()
        except Exception:  # noqa: BLE001
            import traceback
            log("animador caído: %s" % traceback.format_exc())

    def _run(self):
        while not self.win.stop:
            with self.cv:
                if self.drag_pos is None and self.glide is None:
                    self.cv.wait(0.5)
                    continue
                row, dp, gl = self.row, self.drag_pos, self.glide
                self.drag_pos = None
            if dp is not None:
                row.set_pos(dp)
            elif gl is not None:
                a, b, t0, dur = gl
                t = min(1.0, (time.time() - t0) / dur)
                row.set_pos(a + (b - a) * (1 - (1 - t) ** 3))
                if t >= 1.0:
                    with self.cv:
                        if self.glide is gl:
                            self.glide = None
                            row.end_drag()        # guarda la posición en la fila
            time.sleep(1 / 60)


class FlixHome(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.section = kwargs.get("section")    # (variable p3…, título) = sección desplegada en filas
        self.rows = [] if self.section else self.home_rows()
        self.shown = []          # orden en la lista: "hero" o Row (cada uno ocupa PIECES elementos)
        # el hueco del hero existe desde el principio (vacío hasta que llegan datos): crearlo más tarde obligaba a
        # rehacer la lista entera y la devolvía arriba aunque el usuario ya estuviera bajando
        # (las secciones no llevan hero: Carlos no lo quiere ahí)
        self.hero_items, self.hero_i = [], 0
        self.hero = None if kwargs.get("section") else Strip("hero", "hero")
        self.chips = Strip("chips", "chips", CHIPS_H // STEP)
        self.last_touch = 0.0
        self.mouse = (0.0, 0.0)
        self.loaded_at = 0.0
        self.win_id = 0          # id de esta ventana (onInit): el hilo de carga solo consulta con ella activa
        self._cur_row = 0
        self.lock = threading.RLock()
        self.stop = False
        self.g = None            # gesto en curso
        self.anim = Animator(self)
        self.anim.start()
        self.fling_id = 0

    @staticmethod
    def home_rows():
        """filas del Inicio elegidas en el editor (flix_home_order.py): orden, ocultas, eliminadas, añadidas y
        elementos por fila (flix_home_conf)"""
        try:
            import flix_home_conf as hc
            import flix_home_order as fho
            conf = fho.load_conf() or hc.normalize(None)
            return [Row(dict(r, top10=r.get("top10", False), kind=r.get("kind", "list"), limit=conf["items"]))
                    for r in hc.compose(ROWS, conf) if not r["hidden"]]
        except Exception as e:  # noqa: BLE001
            log("orden del Inicio: %s" % e)
            return [Row(dict(d, limit=15)) for d in ROWS]

    def apply_reorder(self):
        """orden cambiado en Ajustes (flix_home_order.py pone fh_reorder): se aplica al momento"""
        if self.section or HOME.getProperty("fh_reorder") != "1":
            return
        HOME.clearProperty("fh_reorder")
        with self.lock:
            old = {r.id: r for r in self.rows}
            self.rows = [old.get(r.id, r) for r in self.home_rows()]
            for row in self.rows:                   # filas añadidas: su hueco ya, en su sitio
                if row.strip is None:
                    row.strip = Strip("top10" if row.top10 else "row", row.label)
                    row.paint()
            if self.shown:
                # cambio pedido en el editor: lista entera en el orden guardado. Sin esto, tras tocar la pantalla
                # order() manda las filas nuevas al final (evita saltos al cargar) y la añadida "no aparecía"
                self.shown = []
                touched, self.last_touch = self.last_touch, 0.0
                self.rebuild()
                self.last_touch = touched
        threading.Thread(target=self.load_all, daemon=True).start()   # filas que estaban ocultas
        log("orden del Inicio aplicado")

    # ---------- ciclo de vida ----------
    def onInit(self):
        log("DIAG onInit (filas mostradas %d, pos %s)" % (len(self.shown), xbmc.getInfoLabel("Container(7000).Position")))
        if self.section:
            self.setProperty("fh_mode", "section")
            self.setProperty("fh_title", self.section[1])
        else:
            HOME.setProperty("fh_window", str(xbmcgui.getCurrentWindowId()))
        self.lst = self.getControl(7000)
        self.win_id = xbmcgui.getCurrentWindowId()
        self.apply_reorder()
        threading.Thread(target=self.sync_progress, daemon=True).start()
        if not self.shown:
            threading.Thread(target=self.load_all, daemon=True).start()
            threading.Thread(target=self.hero_timer, daemon=True).start()
        elif time.time() - self.loaded_at > CACHE_TTL:
            threading.Thread(target=self.load_all, kwargs={"refresh": True}, daemon=True).start()
        elif HOME.getProperty("fh_played") == "1":
            HOME.clearProperty("fh_played")
            threading.Thread(target=self.load_all, kwargs={"refresh": True, "only_progress": True}, daemon=True).start()

    def sync_progress(self):
        """progreso real de Palantir (flix_progress.py): corrige su caché y repinta las barras de las filas ya
        mostradas sin volver a pedirlas (al volver de un vídeo o de limpiar progreso / marcar como vista)"""
        import flix_progress
        for wait in (0, 3, 8):
            if wait and xbmc.Monitor().waitForAbort(wait):
                return
            if self.stop:
                return
            W = flix_progress.truth_cached(max_age=0)
            if not W:
                continue   # sin watched.db no se toca nada (vacía = borraría todo el progreso)
            try:
                flix_progress.fix_palantir_cache(W)
            except Exception as e:  # noqa: BLE001
                log("progreso caché Palantir: %s" % e)
            with self.lock:
                for row in self.rows:
                    # las carátulas de la fila están en row.items (Strip no tiene items: antes no repintaba nunca,
                    # auditoría PY-01)
                    if row.strip is not None and row.items and flix_progress.fix_files(row.items, W):
                        row.paint()

    def load_all(self, refresh=False, only_progress=False):
        if self.section and not self.rows:
            self.rows = [Row({"id": 6100 + i, "label": r["label"], "path": r["path"], "top10": False, "kind": r["kind"]})
                         for i, r in enumerate(flix_rows.section_rows(self.section[0], stale_ok=True))]
        # TODAS las filas se crean de golpe (vacías, con su título) y la lista se monta UNA vez: luego solo se
        # rellenan sus carátulas (propiedades). Añadir elementos a la lista mientras el usuario baja la recolocaba
        # (vuelta arriba) y redibujaba el hero (parpadeo).
        with self.lock:
            fresh = False
            for row in self.rows:
                if row.strip is None:
                    row.strip = Strip("top10" if row.top10 else "row", row.label)
                    row.paint()
                    fresh = True
            if fresh and (not self.shown or any(r not in self.shown for r in self.rows)):
                self.rebuild()
        fresh_rows = set()
        if self.section and not only_progress:
            # sección: lo guardado al momento aunque esté caducado; luego solo se pide lo caducado (auditoría REND-02)
            for row in list(self.rows):
                files, fresh = flix_rows.peek(row.path)
                if files:
                    with self.lock:
                        row.set_items(files)
                        row.paint()
                if fresh and not refresh:
                    fresh_rows.add(row.id)
        for idx, row in enumerate(list(self.rows)):
            if self.stop:
                return
            if row.id in fresh_rows:
                continue
            if only_progress and "Seguir" not in row.label and "seguimiento" not in row.label:
                continue
            # carga diferida (solo Inicio): las filas lejanas esperan a que el usuario se acerque; las que tienen
            # caché fresca se pintan ya (no cuestan llamadas a Palantir). Al refrescar, las lejanas se dejan.
            if not self.section and not only_progress and not self.cache_fresh(row.path):
                if refresh and idx >= self.near_limit():
                    continue
                while idx >= self.near_limit():
                    if self.stop or xbmc.Monitor().waitForAbort(0.3):
                        return
            try:
                files, cached = (flix_rows.fetch(row.path, force=True, save=False) if self.section
                                 else fetch(row.path, force=only_progress))
            except Exception as e:  # noqa: BLE001
                log("fila %s: %s" % (row.label, e))
                continue
            log("fila %s: %d%s" % (row.label, len(files), " (caché)" if cached else ""))
            if self.section and files and flix_cache.same_items(row.items, files[:len(row.items)]) and \
                    len(row.items) == len(files[:row.limit] if row.limit else files):
                continue                                # sección refrescada sin cambios: no se repinta
            with self.lock:
                row.set_items(files)
                hero_src = 5105 if any(r.id == 5105 for r in self.rows) else None   # Top 10 películas (si no está oculta)
                if self.hero is not None and files and (row.id == hero_src or (hero_src is None and row.kind == "list" and not self.hero_items)):
                    self.set_hero([f for f in files if not flix_rows.is_more(f)][:10])
                row.paint()
        if self.section:
            flix_rows.flush()
        self.loaded_at = time.time()

    def near_limit(self):
        """filas que se pueden cargar ya: las 5 primeras y hasta 3 por debajo de la que se está viendo"""
        import flix_home_conf as hc
        return max(hc.INITIAL_NEAR, self.current_row() + hc.AHEAD + 1)

    def current_row(self):
        """índice en self.rows de la fila seleccionada en la lista vertical (hero/chips = 0).
        Se llama desde el hilo de carga: NUNCA tocar controles (self.lst) desde aquí. Si Kodi destruye la ventana
        (recarga de la skin al actualizarse) mientras un hilo usa un control, Kodi entero se cae (pasó en 1.0.40-41).
        Por eso: InfoLabel de Kodi y solo con esta ventana activa; si no, el último valor conocido."""
        if self.stop or not self.win_id or xbmcgui.getCurrentWindowId() != self.win_id:
            return self._cur_row
        try:
            pos = int(xbmc.getInfoLabel("Container(7000).CurrentItem") or 0) - 1
        except ValueError:
            return self._cur_row
        if pos < 0:
            return self._cur_row
        n, row = 0, len(self.rows)
        for t in list(self.shown):
            n += len(self.strip_of(t).lis)
            if pos < n:
                row = self.rows.index(t) if t in self.rows else 0
                break
        self._cur_row = row
        return row

    @staticmethod
    def cache_fresh(path):
        key = re.sub(r"&reload=[^&]*", "", path)
        hit = _cache_load().get(key)
        return bool(hit) and time.time() - hit[0] < CACHE_TTL

    def order(self):
        if self.shown and self.last_touch:          # orden ya mostrado + filas nuevas al final
            return self.shown + [r for r in self.rows if r.strip is not None and r not in self.shown]
        chips = [] if self.section else ["chips"]
        return chips + (["hero"] if self.hero is not None else []) + [r for r in self.rows if r.strip is not None]

    def strip_of(self, t):
        return self.chips if t == "chips" else self.hero if t == "hero" else t.strip

    def append_or_rebuild(self, row):
        """añade una fila nueva. Rehacer la lista la devuelve arriba del todo, así que si el usuario ya ha
        tocado la pantalla la fila se añade al final aunque no le toque ese orden"""
        # las filas llegan en orden y el hero existe desde el principio: con la lista ya creada, SIEMPRE al final
        # (rehacerla la devolvía arriba mientras el usuario bajaba, en el Inicio y en las secciones)
        if self.shown:
            before = xbmc.getInfoLabel("Container(7000).Position") + "/" + xbmc.getInfoLabel("Container(7000).CurrentItem")
            self.shown = self.shown + [row]
            self.lst.addItems(row.strip.lis)
            log("DIAG añadida fila %s (pos antes %s, después %s/%s)" % (row.label, before,
                xbmc.getInfoLabel("Container(7000).Position"), xbmc.getInfoLabel("Container(7000).CurrentItem")))
        else:
            self.rebuild()

    def rebuild(self):
        pos = self.lst.getSelectedPosition()
        import traceback
        log("DIAG rebuild (pos %d, filas %d) desde %s" % (pos, len(self.shown), " < ".join(
            "%s:%d" % (f.name, f.lineno) for f in traceback.extract_stack()[-4:-1])))
        self.lst.reset()
        self.shown = self.order()
        items = []
        for t in self.shown:
            items += self.strip_of(t).lis
        self.lst.addItems(items)
        if pos >= 0:
            self.lst.selectItem(min(pos, len(items) - 1))

    # ---------- hero ----------
    def set_hero(self, items):
        self.hero_items = items
        self.paint_hero()

    def paint_hero(self, step=0):
        if not self.hero_items:
            return
        self.hero_i %= len(self.hero_items)
        f = self.hero_items[self.hero_i]
        a = f.get("art") or {}
        h = self.hero
        h.set("fanart", a.get("fanart") or a.get("landscape") or "")
        h.set("logo", a.get("clearlogo") or "")
        h.set("title", clean(f.get("label")))
        meta = [str(f["year"])] if f.get("year") else []
        if f.get("runtime"):
            meta.append("%d min" % (int(f["runtime"]) // 60))
        if f.get("rating"):
            meta.append("★ %.1f" % float(f["rating"]))
        h.set("meta", "  ·  ".join(meta))
        h.set("genre", " / ".join(f.get("genre") or []))
        h.set("rank", "" if self.section else str(self.hero_i + 1))   # distintivo TOP 10 solo en el Inicio
        for k in range(10):
            h.set("dot%d" % k, "" if k >= len(self.hero_items) else ("on" if k == self.hero_i else "off"))


    def hero_step(self, step):
        with self.lock:
            if self.hero_items:
                self.hero_i += step
                self.paint_hero(step)

    def hero_timer(self):
        mon = xbmc.Monitor()
        while not mon.abortRequested() and not self.stop:
            mon.waitForAbort(1)
            self.apply_reorder()
            if HOME.getProperty("fh_progress") == "1":     # menú contextual cerrado: limpiar progreso / vista
                HOME.clearProperty("fh_progress")
                threading.Thread(target=self.sync_progress, daemon=True).start()
            if self.hero_items and self.g is None and time.time() - self.last_touch > 10 and int(time.time()) % 8 == 0 \
                    and xbmc.getCondVisibility("Window.IsActive(%s)" % HOME.getProperty("fh_window")):
                self.hero_step(1)

    # ---------- geometría ----------
    def to_skin(self, x, y):
        return x * SKIN_W / SCR_W, y * SKIN_H / SCR_H

    def strip_at(self, sy):
        """(fila/hero, y dentro de la fila) bajo la coordenada sy (skin), con la lista en reposo"""
        try:
            pos = int(xbmc.getInfoLabel("Container(7000).Position"))
            cur = int(xbmc.getInfoLabel("Container(7000).CurrentItem")) - 1
        except ValueError:
            return None, 0
        y = (sy - HEADER_H) + (cur - pos) * STEP     # y dentro del contenido de la lista
        if y < 0:
            return None, 0
        top = 0
        for t in self.shown:
            h = self.strip_of(t).height
            if y < top + h:
                return t, y - top
            top += h
        return None, 0

    # ---------- acciones ----------
    def onAction(self, action):
        aid = action.getId()
        x, y = action.getAmount1(), action.getAmount2()
        if aid == A_MOVE:
            self.mouse = (x, y)
            return
        if aid in A_BACK:
            if self.section:
                self.stop = True
                self.close()
            else:
                xbmc.executebuiltin("ActivateWindow(shutdownmenu)")
            return
        if aid == A_BEGIN:
            self.gesture_begin(x, y)
            return
        if aid == A_PAN:
            self.gesture_move(x, y)
            return
        if aid in (A_END, A_ABORT):
            self.gesture_end()
            return
        if aid in (A_CLICK, A_SWIPE_L, A_SWIPE_R):
            if x <= 1 and y <= 1:        # acción sin coordenadas (pruebas por JSON-RPC): última posición del ratón
                x, y = self.mouse
            sx, sy = self.to_skin(x, y)
            self.last_touch = time.time()
            if sy < HEADER_H:
                return
            target, ry = self.strip_at(sy)
            if target is None:
                return
            if aid == A_CLICK:
                self.tap(target, sx, ry)
            elif time.time() - getattr(self, "last_hdrag", 0) > 0.6:   # swipe sin arrastre lateral previo
                self.swipe(target, 1 if aid == A_SWIPE_L else -1)
        elif aid == A_SELECT:
            pos, t = self.lst.getSelectedPosition(), None
            for cand in self.shown:
                n = len(self.strip_of(cand).lis)
                if pos < n:
                    t = cand
                    break
                pos -= n
            if t is not None and t != "chips":
                self.open(self.hero_items[self.hero_i] if t == "hero" and self.hero_items else (t.items[int(t.pos)] if t != "hero" and t.items else None),
                          t if t != "hero" else None)

    def onClick(self, control_id):
        pass                             # los toques se resuelven en onAction (con coordenadas)

    # ---------- arrastre lateral continuo ----------
    def gesture_begin(self, x, y):
        self.last_touch = time.time()
        sx, sy = self.to_skin(x, y)
        target, _ = self.strip_at(sy) if sy >= HEADER_H else (None, 0)
        if isinstance(target, Row):
            self.anim.stop_row(target)                        # el dedo detiene el deslizamiento
        self.g = {"x0": sx, "y0": sy, "t": target, "mode": None, "hist": [(time.time(), sx)],
                  "base": target.pos if isinstance(target, Row) else 0.0}

    def gesture_move(self, x, y):
        g = self.g
        if not g or g["t"] is None:
            return
        sx, sy = self.to_skin(x, y)
        dx, dy = sx - g["x0"], sy - g["y0"]
        if g["mode"] is None:
            if abs(dx) > 20 and abs(dx) > 1.2 * abs(dy):
                g["mode"] = "h"
                g["x0"], dx = sx, 0.0
            elif abs(dy) > 20:
                g["mode"] = "v"
        if g["mode"] != "h":
            return
        now = time.time()
        g["hist"].append((now, sx))
        while len(g["hist"]) > 2 and now - g["hist"][0][0] > 0.12:   # velocidad de los últimos 120 ms
            g["hist"].pop(0)
        self.last_hdrag = now
        t = g["t"]
        if t == "hero":
            g["hero_dx"] = dx
            return
        self.anim.drag(t, g["base"] - dx / t.itemw)

    def gesture_end(self):
        g, self.g = self.g, None
        if not g or g.get("mode") != "h" or g["t"] is None:
            return
        self.last_hdrag = time.time()
        h = g["hist"]
        v = 0.0
        if len(h) >= 2 and h[-1][0] - h[0][0] > 0.01:
            v = (h[-1][1] - h[0][1]) / (h[-1][0] - h[0][0])      # px/s (skin)
        t = g["t"]
        if t == "hero":
            dx = g.get("hero_dx", 0)
            if abs(dx) > 120 or abs(v) > 600:
                self.hero_step(1 if (dx or v) < 0 else -1)
            return
        # inercia: recorre v*0,35 s y frena. Encaje suave (petición de Carlos, 18-oct): solo se recoloca a carátula
        # entera si la del borde queda casi fuera (<20 % o >80 % de una carátula); si no, se queda donde cae.
        # El encaje siempre a la más cercana recolocaba casi en cada gesto y se veía un parpadeo.
        target = max(0.0, min(t.pos - (v * 0.35) / t.itemw, t.max_pos))
        frac = target - int(target)
        if frac < SNAP_EDGE:
            target = float(int(target))
        elif frac > 1 - SNAP_EDGE:
            target = float(int(target) + 1)
        dur = 0.25 + min(0.5, abs(v) / 6000)
        self.anim.glide_to(t, target, dur)

    def swipe(self, target, step):
        if target == "chips":
            return
        if target == "hero":
            self.hero_step(step)
        else:
            self.anim.glide_to(target, round(target.pos) + step * target.visible, 0.45)

    def tap(self, target, sx, ry):
        if target == "chips":
            i = int((sx - LEFT) // (CHIP_W + CHIP_GAP))
            if 0 <= i < len(CHIPS) and (sx - LEFT) - i * (CHIP_W + CHIP_GAP) <= CHIP_W:
                lab = CHIPS[i]["label"]
                HOME.setProperty("flix_section", lab)
                if lab in flix_rows.SECTION_VARS:       # sección desplegada en filas (se carga al entrar)
                    xbmc.executebuiltin("RunScript(special://skin/scripts/flix_home.py,%s,%s)" % (flix_rows.SECTION_VARS[lab], lab))
                else:
                    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % live(CHIPS[i]["path"]))
            return
        if target == "hero":
            if self.hero_items:
                self.open(self.hero_items[self.hero_i % len(self.hero_items)])
            return
        row = target
        if ry < 80:                      # título de la fila = ver todo
            HOME.setProperty("flix_section", row.label)
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % live(row.path))
            return
        if row.pos > 0.05 and sx < LEFT + 50:
            self.swipe(row, -1)
            return
        if row.pos < row.max_pos - 0.05 and sx > SKIN_W - 110:
            self.swipe(row, 1)
            return
        k = row.index_at(sx)
        if 0 <= k < len(row.items):
            self.open(row.items[k], row)

    def open(self, f, row=None):
        if not f:
            return
        path = f.get("file", "")
        if flix_rows.is_more(f) or (row is not None and row.kind == "coll"):
            # submenú de sección / página siguiente: su rejilla de carátulas
            title = self.section[1] if self.section else row.label if row else ""
            HOME.setProperty("flix_section", "%s · %s" % (title, "Más" if flix_rows.is_more(f) else clean(f.get("label"))))
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
            return
        a = f.get("art") or {}
        HOME.setProperty("flix_title", clean(f.get("label")))
        HOME.setProperty("flix_poster", poster_of(f))
        HOME.setProperty("flix_fanart", a.get("fanart") or "")
        HOME.setProperty("flix_meta", str(f.get("year") or ""))
        log("abrir %s (%s/%s)" % (clean(f.get("label")), f.get("type"), f.get("filetype")))
        HOME.setProperty("fh_played", "1")
        if f.get("type") == "tvshow" or (f.get("filetype") == "directory" and "palantir3" in path):
            xbmc.executebuiltin('RunScript(special://skin/scripts/flix_series.py,"%s")' % path)
        elif f.get("filetype") == "directory":
            xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
        else:
            import flix_play
            flix_play.play(path, *flix_play.resume_of(f), title=clean(f.get("label")), fanart=a.get("fanart") or "")


def main():
    if len(sys.argv) > 2 and sys.argv[1].startswith("p3"):     # sección: RunScript(flix_home.py,p3Dibujos,Dibujos)
        win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i", section=(sys.argv[1], sys.argv[2]))
        win.doModal()
        win.stop = True
        del win
        return
    if HOME.getProperty("fh_running") == "1":
        wid = HOME.getProperty("fh_window")
        if wid:
            xbmc.executebuiltin("ActivateWindow(%s)" % wid)
        return
    HOME.setProperty("fh_running", "1")
    try:
        win = FlixHome("FlixHome.xml", SKIN, "Default", "1080i")
        win.doModal()
        win.stop = True
        del win
    finally:
        HOME.clearProperty("fh_running")
        HOME.clearProperty("fh_window")


if __name__ == "__main__":
    main()
