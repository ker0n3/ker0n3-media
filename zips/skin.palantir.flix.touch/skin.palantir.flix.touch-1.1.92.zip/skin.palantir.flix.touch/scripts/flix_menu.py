"""Menú KER0N3 MEDIA de un elemento de Palantir (mantener OK / botón ☰): película, capítulo, temporada o serie.

Solo lo que sirve y llega a Trakt: vista / no vista, quitar progreso (película y capítulo), temporada vista / no vista,
serie vista / no vista, dejar de seguir y (película y serie) valorar en Trakt. «Añadir a mi lista…» (40) está
definida pero aparcada. Esas acciones son de Palantir y solo existen dentro de su submenú
("Menú Palantir 3..." -> context.py, que recibe el elemento como sys.listitem y no expone ninguna ruta reutilizable).
Por eso este script, tras elegir, abre por detrás el menú contextual de Kodi (invisible: Window(home).Property
(flix_ctx_auto) pone DialogContextMenu.xml transparente y sin interceptar), entra en "Menú Palantir 3..." y pulsa la
opción de Palantir. Las de primer nivel con el mismo nombre son de Kodi y NO llegan a Palantir ni a Trakt: solo se
pulsa dentro del submenú (se reconoce por "Información sobre Palantir 3" / "Information about Palantir 3").
Textos en el idioma del aparato: los de Kodi con xbmc.getLocalizedString y los de Palantir con su propio addon
(Fire TV tiene Kodi en inglés).
Verificado 17-oct-2026 (Shield + resincronizar con Trakt; Fire TV): restablecer y marcar/desmarcar vista llegan a Trakt.
Uso: RunScript(special://skin/scripts/flix_menu.py[,<ruta>,<carátula>])  (lo lanza DialogContextMenu.xml)
"""
import ast
import os
import sqlite3
import sys
import json
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_common  # noqa: E402
import flix_play  # noqa: E402
import flix_rows  # noqa: E402

HOME = xbmcgui.Window(10000)
SUBMENU_MARK = "Palantir 3"   # botón de primer nivel que abre el submenú de Palantir ("Menú Palantir 3...")
SUBMENU_SIGN = ("información sobre palantir", "information about palantir")   # solo dentro del submenú
WATCHED_DB = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/watched.db")


def _kodi(i):
    try:
        return xbmc.getLocalizedString(i).strip().lower()
    except Exception:  # noqa: BLE001
        return ""


def _pal(i):
    try:
        return xbmcaddon.Addon("plugin.video.palantir3").getLocalizedString(i).strip().lower()
    except Exception:  # noqa: BLE001
        return ""


# id -> (texto en el menú KER0N3, icono, textos de la opción de Palantir (exactos, sin mayúsculas), aviso al terminar)
ACTIONS = {
    10: ("Marcar como vista", "check", {_kodi(16103), "marcar como visto", "mark as watched"}, "Marcada como vista"),
    11: ("Marcar como no vista", "x", {_kodi(16104), "marcar como no visto", "mark as unwatched"},
         "Marcada como no vista"),
    12: ("Quitar progreso / dejar de seguir", "rewind", {_kodi(38209), "restablecer posición de reanudación", "reset resume position"},
         "Progreso quitado"),
    20: ("Marcar serie como vista", "check", {_pal(30080), "marcar serie como vista", "mark show as watched"},
         "Serie marcada como vista"),
    21: ("Marcar serie como no vista", "x", {_pal(30079), "marcar serie como no vista", "mark show as unwatched"},
         "Serie marcada como no vista"),
    22: ("Dejar de seguir la serie", "delete", {_pal(30091), "no seguir esta serie...", "do not follow this show..."},
         None),
    # abren el diálogo de Palantir (elegir lista / nota): el resultado lo avisa Palantir; llegan a Trakt
    40: ("Añadir a mi lista…", "plus", {_pal(30533), "añadir a lista trakt.tv personal...", "add to personal trakt.tv list..."},
         None),
    41: ("Valorar en Trakt", "star", {_pal(30035), "valorar en trakt.tv", "rate on trakt.tv"}, None),
    # de la skin: esta vez el selector de versiones de Palantir aunque la reproducción automática esté puesta
    # (Carlos, 22-oct: en este menú y no en la ficha). flix_autoplay.pick_once la gasta al abrirse el selector
    50: ("Elegir resolución", "sliders-horizontal", None, None),
    30: ("Marcar temporada como vista", "check", {_pal(30082), "marcar temporada como vista",
                                                    "mark season as watched"}, "Temporada marcada como vista"),
    31: ("Marcar temporada como no vista", "x", {_pal(30081), "marcar temporada como no vista",
                                                   "mark season as unwatched"}, "Temporada marcada como no vista"),
}


# capítulo: en masculino (Carlos, 23-oct); la película y la serie siguen «vista»
EPISODE_LABELS = {10: "Marcar como visto", 11: "Marcar como no visto"}
EPISODE_DONE = {10: "Marcado como visto", 11: "Marcado como no visto"}

DIALOG_ACTIONS = (22, 40, 41)     # abren un diálogo de Palantir (22: «No seguir esta serie...» pregunta dónde)

# rueda mientras Palantir hace la opción (Custom_1197_FlixWorking.xml): tarda unos segundos en confirmar y no se
# sabía si estaba en ello (Carlos, 24-oct)
WORKING = {10: "Marcando como vista…", 11: "Marcando como no vista…", 12: "Quitando progreso…",
           20: "Marcando serie como vista…", 21: "Marcando serie como no vista…", 22: "Dejando de seguir la serie…",
           40: "Abriendo tus listas…", 41: "Abriendo la valoración…",
           30: "Marcando temporada como vista…", 31: "Marcando temporada como no vista…"}
EPISODE_WORKING = {10: "Marcando como visto…", 11: "Marcando como no visto…"}


def log(msg):
    xbmc.log("[flix_menu] %s" % msg, xbmc.LOGINFO)
    HOME.setProperty("flix_menu_log", msg[:500])     # legible por JSON-RPC (en Fire OS no se puede leer kodi.log)


class Menu(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.opts = kwargs.get("opts", [])
        self.labels = kwargs.get("labels", {})     # textos propios de esta vez (capítulos: masculino)
        self.choice = None

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        lst = self.getControl(9100)
        lst.reset()
        for act in self.opts:
            li = xbmcgui.ListItem(self.labels.get(act) or ACTIONS[act][0])
            li.setProperty("icon", ACTIONS[act][1])
            li.setProperty("act", str(act))
            lst.addItem(li)
        # la lista aún no es enfocable en este instante («Control 9100 can't focus»): el 1.er OK no hacía nada y había
        # que pulsar dos veces (Shield, 23-oct) -> reintentar hasta que la tenga
        for _ in range(12):
            self.setFocusId(9100)
            if xbmc.getCondVisibility("Control.HasFocus(9100)"):
                break
            xbmc.sleep(40)

    def onClick(self, cid):
        if cid == 9100:
            item = self.getControl(9100).getSelectedItem()
            if item:
                self.choice = int(item.getProperty("act"))
                self.close()


def ctx_buttons():
    """{id: etiqueta} del menú contextual abierto"""
    out = {}
    for i in range(1000, 1040):
        lab = xbmc.getInfoLabel("Control.GetLabel(%d)" % i)
        if lab:
            out[i] = lab
    return out


def wait_for(pred, timeout):
    mon = xbmc.Monitor()
    end = time.time() + timeout
    while time.time() < end and not mon.abortRequested():
        if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            r = pred(ctx_buttons())
            if r:
                return r
        xbmc.sleep(150)
    return None


def press(cid):
    xbmc.executebuiltin("SetFocus(%d)" % cid)
    xbmc.sleep(120)
    xbmc.executebuiltin("Action(Select)")


DIALOGS = "Window.IsActive(contextmenu) | Window.IsActive(selectdialog) | Window.IsActive(yesnodialog) | " \
          "Window.IsActive(numericinput) | Window.IsActive(virtualkeyboard)"


def follow_dialog():
    """la opción pulsada abre un diálogo de Palantir (elegir lista, nota): se deja ver tal cual (flix_ctx_skip: el
    menú contextual que abre Palantir no se redirige al KER0N3 ni se vuelve transparente) hasta que se cierra"""
    mon = xbmc.Monitor()
    end = time.time() + 10
    while time.time() < end and not mon.abortRequested() and not xbmc.getCondVisibility(DIALOGS):
        xbmc.sleep(100)
    end = time.time() + 300
    while time.time() < end and not mon.abortRequested() and xbmc.getCondVisibility(DIALOGS):
        xbmc.sleep(200)
    HOME.clearProperty("flix_ctx_skip")


FAIL = {"why": ""}       # por qué falló run_palantir: «opcion» = Palantir no ofrece esa opción (lista sin poner al día)


def run_palantir(words, dialog=False):
    """abre el menú de Kodi, entra en el de Palantir y pulsa la opción cuyo texto contiene todas las palabras.
    dialog=True: esa opción abre un diálogo de Palantir que el usuario tiene que ver (follow_dialog)"""
    FAIL["why"] = ""
    HOME.setProperty("flix_ctx_auto", "1")
    try:
        if not focus_target():
            return False
        context_menu()
        sub = wait_for(lambda b: next((i for i, l in b.items() if SUBMENU_MARK in l), None), 6)
        if not sub:
            log("no aparece 'Menú Palantir 3'")
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        press(sub)

        def target(b):
            if not any(sig in l.lower() for l in b.values() for sig in SUBMENU_SIGN):
                return None              # aún es el menú de Kodi (mismas etiquetas, pero no llegan a Trakt)
            return next((i for i, l in b.items() if l.strip().lower() in words), -1)

        # Palantir puede tardar en abrir su submenú si sigue con la acción anterior (sincronizando con Trakt: hasta
        # ~17 s medidos en la Shield, 19-oct): antes se esperaba 12 s y salía «aún no está lista». Ahora hasta 30 s,
        # aviso a los 4 s y segunda pulsación a los 10 s si sigue el menú de Kodi.
        t0, warned, repressed, cid = time.time(), False, False, None
        while time.time() - t0 < 30:
            cid = wait_for(target, 1)
            if cid:
                break
            if not warned and time.time() - t0 > 4:
                warned = True
                if not HOME.getProperty("flix_working"):     # con la rueda (Custom_1197) ya se ve que está en ello
                    xbmcgui.Dialog().notification("KER0N3 MEDIA", "Esperando a Palantir…",
                                                  xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000,
                                                  False)
            if not repressed and time.time() - t0 > 10:
                again = next((i for i, l in ctx_buttons().items() if SUBMENU_MARK in l), None)
                if again and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
                    repressed = True
                    log("Palantir no abre su submenú: segunda pulsación")
                    press(again)
        if not cid or cid < 0:
            if cid == -1:
                FAIL["why"] = "opcion"          # su submenú está, pero con la lista sin poner al día
            log("Palantir no ofrece %s; opciones: %s" % (sorted(w for w in words if w), list(ctx_buttons().values())))
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        label = xbmc.getInfoLabel("Control.GetLabel(%d)" % cid)
        if dialog:
            HOME.setProperty("flix_ctx_skip", "1")
            press(cid)
            HOME.clearProperty("flix_ctx_auto")
            log("pulsado en Palantir: %s (diálogo de Palantir a la vista)" % label)
            xbmc.sleep(300)
            follow_dialog()
            return True
        press(cid)
        log("pulsado en Palantir: %s" % label)
        return True
    finally:
        if not dialog:
            xbmc.sleep(400)
        HOME.clearProperty("flix_ctx_auto")


def context_menu():
    """Action(ContextMenu) por detrás. En el Inicio táctil esa acción le llega TAMBIÉN a flix_home.py, a veces muchos
    segundos después (ventana ocupada repintando tras sincronizar con Trakt): se anota para que no la tome por un
    «mantener pulsado» y abra el menú de la carátula que haya bajo el dedo (Sunset Limited / Batman, móvil 20-oct)"""
    if CTX["list"]:
        try:
            sent = json.loads(HOME.getProperty("flix_ctx_sent") or "[]")
        except ValueError:
            sent = []
        HOME.setProperty("flix_ctx_sent", json.dumps(sent + [time.time()]))
    xbmc.executebuiltin("Action(ContextMenu)")


CTX = {"list": None, "path": ""}     # táctil: lista oculta (7990 de FlixHome.xml) donde está el título
INICIO = {"src": "", "path": ""}     # Inicio TV: listado de la fila (flix_inicio.py: flix_ctx_src) y carátula
EP = {"cid": "", "path": ""}         # pantalla de serie: lista enfocada y capítulo/temporada del menú (focused_episode)
SEASONS_COLUMN = "7952"              # columna de temporadas (elementos fijos con su ruta en Property(path))
SHEET_SERIES = "7976"                # ficha propia (flix_series_sheet): carpeta de la serie, con sus temporadas


def sheet_open():
    """¿está abierta la ficha de serie en ventana propia (táctil, flix_series_sheet)?"""
    return bool(HOME.getProperty("flix_sheet"))


def on_series():
    """¿estamos en la pantalla de una serie (ventana Vídeos o ficha propia)?"""
    return xbmc.getCondVisibility("Window.IsActive(videos)") or sheet_open()


def seasons_list():
    """lista donde están las temporadas de verdad: el menú de Kodi va a la seleccionada en ella"""
    return SHEET_SERIES if sheet_open() else KODI_SEASONS


KODI_SEASONS = "52"                  # lista de temporadas de Kodi (fuera de pantalla): su menú va a la seleccionada


def route_key(path):
    """(tipo, tmdb, temporada, capítulo) de una ruta de Palantir; None si no se puede leer"""
    try:
        info = ast.literal_eval(flix_rows.decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(info, dict) or not info.get("tmdb"):
        return None
    return (info.get("content"), str(info["tmdb"]), info.get("season"), info.get("episode"))


CTX_WIN = {"w": None}


def open_episode_ctx():
    """capítulo: FlixCtx.xml (lista oculta 7990 con los capítulos de su temporada) y CTX apuntando a él: así el
    Action(ContextMenu) de focus_target()/run_palantir abre el menú de Kodi del CAPÍTULO (en la ventana Vídeos iría a
    la temporada). Se cierra en close_episode_ctx()"""
    src = HOME.getProperty("flix_eps_c%d" % (int(EP["cid"]) - EPS_LISTS[0]))
    if not src:
        log("lista %s sin capítulos cargados: no hago nada" % EP["cid"])
        return False
    return open_ctx(src, EP["path"])


def open_ctx(src, path):
    """FlixCtx.xml con el listado de Palantir src y CTX en el elemento path (capítulo de la serie, carátula de una fila
    del Inicio TV: listas de Python sin menú de Kodi). Se cierra en close_episode_ctx()"""
    if CTX_WIN["w"] is not None:
        return True
    HOME.setProperty("flix_ctx_src", src)
    w = xbmcgui.WindowXMLDialog("FlixCtx.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    w.show()
    CTX_WIN["w"] = w
    end = time.time() + 3
    while time.time() < end and not xbmc.getCondVisibility("Window.IsVisible(FlixCtx.xml)"):
        xbmc.sleep(50)
    CTX["list"], CTX["path"] = "7990", path
    return True


def prefetch_ctx():
    """abre YA la lista oculta (FlixCtx) para que Palantir la vaya dando mientras se elige en nuestro menú: tarda
    ~2,5 s en dar una fila o una temporada (medido en la Fire TV, 24-oct, igual para 1 título que para 53) y antes se
    pedía DESPUÉS de elegir: «No seguir esta serie» tardaba ~5 s en preguntar (Carlos). True si la ha abierto"""
    if CTX_WIN["w"] is not None or EP["cid"] == SEASONS_COLUMN:
        return False
    if EP["cid"]:
        return open_episode_ctx()
    if INICIO["src"]:
        return open_ctx(INICIO["src"], INICIO["path"])
    return False


def release_ctx():
    """cierra la lista oculta en cuanto lo de Palantir ha terminado. Antes seguía abierta mientras se esperaba el
    resultado (hasta 30 s si se cancelaba la pregunta de «No seguir esta serie») y se quedaba con el foco: en el
    Inicio no había carátula seleccionada hasta pulsar Atrás otra vez (Fire TV, Carlos 24-oct)"""
    inicio = CTX_WIN["w"] is not None and INICIO["src"] and not EP["cid"]
    close_episode_ctx()
    row = HOME.getProperty("flix_row")
    if inicio and row:
        xbmc.executebuiltin("SetFocus(%s)" % row)


def close_episode_ctx():
    w, CTX_WIN["w"] = CTX_WIN["w"], None
    if w is not None:
        w.close()
        del w
    CTX["list"], CTX["path"] = None, ""
    HOME.clearProperty("flix_ctx_src")


def focus_episode():
    """foco de vuelta al capítulo del menú antes de abrir el de Kodi: al cerrar FlixMenu el foco puede volver a la lista
    oculta de temporadas y la acción caería en la TEMPORADA. Si no se consigue, no se hace nada"""
    cid, path = EP["cid"], EP["path"]
    if cid == SEASONS_COLUMN:           # temporada: el menú de Kodi va a la seleccionada en su lista oculta
        cid = seasons_list()
    want = route_key(path)              # la ruta lleva el estado (vista, %): cambia si la lista se refresca
    end = time.time() + 4
    while time.time() < end:
        if not xbmc.getCondVisibility("Control.HasFocus(%s)" % cid):
            xbmc.executebuiltin("SetFocus(%s)" % cid)
        elif route_key(xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % cid)) == want:
            return True
        else:                           # la lista se movió: buscar el capítulo en ella
            n = xbmc.getInfoLabel("Container(%s).NumItems" % cid)
            for i in range(int(n) if n.isdigit() else 0):
                if route_key(xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).FileNameAndPath" % (cid, i))) == want:
                    xbmc.executebuiltin("SetFocus(%s,%d,absolute)" % (cid, i))
                    break
        xbmc.sleep(120)
    log("no recupero el foco del capítulo (lista %s, %s): no hago nada" % (cid, want))
    return False


def focus_target():
    """Inicio táctil: el título no es un elemento de Kodi. Se espera a que la lista oculta cargue la fila, se coloca
    en el título y entonces Action(ContextMenu) abre el menú de Kodi de ESE elemento (como en la TV). Sin lista: nada"""
    if EP["cid"]:
        # Palantir hace que Kodi recargue la carpeta de la serie al marcar: mientras, la pantalla se veía vacía
        # («0 temporadas»). flix_series.py suelta la retención cuando vuelve a estar cargada (MyVideoNav.xml)
        HOME.setProperty("flix_series_hold", str(time.time()))
    if EP["cid"] == SEASONS_COLUMN:
        return focus_episode()          # temporada: se selecciona en la lista de Kodi
    if EP["cid"] and not open_episode_ctx():
        return False
    if INICIO["src"] and not open_ctx(INICIO["src"], INICIO["path"]):
        return False
    lid, path = CTX["list"], CTX["path"]
    if not lid:
        return True
    mon, end = xbmc.Monitor(), time.time() + 25
    n = 0
    while time.time() < end and not mon.abortRequested():
        v = xbmc.getInfoLabel("Container(%s).NumItems" % lid)
        if v.isdigit() and int(v) > 0 and not xbmc.getCondVisibility("Container(%s).IsUpdating" % lid):
            n = int(v)
            break
        xbmc.sleep(150)
    paths = [xbmc.getInfoLabel("Container(%s).ListItemAbsolute(%d).FileNameAndPath" % (lid, i)) for i in range(n)]
    idx = paths.index(path) if path in paths else -1
    if idx < 0:
        # la ruta lleva el estado (vista, %): tras marcar la película Palantir da otra y el Inicio táctil aún tiene
        # la vieja -> «no encuentro el título» al desmarcarla (Prácticamente magia 2, 20-oct). Se busca por TMDB
        want = route_key(path)
        idx = next((i for i, p in enumerate(paths) if want and route_key(p) == want), -1)
    if idx < 0:
        log("lista oculta %s: no encuentro el título (%d elementos)" % (lid, n))
        return False
    xbmc.executebuiltin("SetFocus(%s,%d,absolute)" % (lid, idx))
    end = time.time() + 3
    while time.time() < end and xbmc.getInfoLabel("Container(%s).ListItem.FileNameAndPath" % lid) != paths[idx]:
        xbmc.sleep(100)
    return True


def run_kodi(words):
    """pulsa una opción del menú contextual de KODI (primer nivel, sin entrar en el de Palantir). Para «Quitar
    progreso»: Palantir borra su progreso y el de Trakt, pero el «Reanudar desde…» propio de Kodi (marcador local)
    seguía ahí y volvía a preguntar al reproducir (Shield, 19-oct)."""
    HOME.setProperty("flix_ctx_auto", "1")
    try:
        if not focus_target():
            return False
        context_menu()
        cid = wait_for(lambda b: next((i for i, l in b.items() if l.strip().lower() in words), None), 6)
        if not cid:
            xbmc.executebuiltin("Dialog.Close(contextmenu,true)")
            return False
        press(cid)
        log("pulsado en Kodi: %s" % xbmc.getInfoLabel("Control.GetLabel(%d)" % cid))
        return True
    finally:
        xbmc.sleep(400)
        HOME.clearProperty("flix_ctx_auto")


# ---------- estado real (watched.db de Palantir) ----------
def db_query(sql, args=()):
    try:
        from flix_common import watched_db
        db = sqlite3.connect("file:%s?mode=ro" % watched_db(WATCHED_DB), uri=True, timeout=5)
        try:
            return db.execute(sql, args).fetchall()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        log("watched.db: %s" % e)
        return None


def state_of(kind, info):
    """(firma comparable, props del menú, opciones)"""
    tmdb = str(info.get("tmdb") or "")
    if kind in ("movie", "episode"):
        if kind == "movie":
            rows = db_query("SELECT playcount, progress, runtime FROM movies_watched WHERE tmdb_id=?", (tmdb,))
        else:
            rows = db_query("SELECT playcount, progress, runtime FROM episodes_watched WHERE tmdb_id=? AND season=? "
                            "AND episode=?", (tmdb, info.get("season"), info.get("episode")))
        row = rows[0] if rows else None
        watched = int(row[0] or 0) if row else 0
        total = float(row[2] or 0) if row else 0.0
        total = total or float(info.get("duration") or 0)
        position = total * float(row[1] or 0) / 100 if row else 0.0
        started = position > 30 and (not total or position < total - 60)
        if started:
            sub = "Empezada  ·  %s de %s" % (flix_play.fmt(position), flix_play.fmt(total)) if total else "Empezada"
        else:
            sub = "Vista" if watched else "Sin empezar"
        if kind == "episode":
            sub = "T%s · E%s  ·  %s" % (info.get("season"), info.get("episode"), sub)
        opts = [11] if watched and not started else [10]
        if started:
            opts.append(12)
        if xbmc.getInfoLabel("Skin.String(flix_autoplay)") != "off":
            opts.insert(1, 50)          # junto a «Ver»: sin automática el selector ya sale siempre
        if kind == "movie":
            opts += [41]          # 40 «Añadir a mi lista…» aparcado (Carlos, 19-oct): de momento solo la nota
        state = "started" if started else "watched" if watched else "new"
        props = {"fm_state": state, "fm_sub": sub,
                 "fm_pct": str(int(100 * position / total)) if started and total else "0"}
        return (watched, round(position)), props, opts
    if kind == "season":
        rows = db_query("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND season=? AND playcount>0",
                        (tmdb, info.get("season")))
        seen = rows[0][0] if rows else 0
        # la opción debe ser la que Palantir ofrece, y Palantir decide con la cuenta de TMDB (su % también: Black Clover
        # T2 con 26 de 61 salía vista). Así que primero totalEpisodes (TMDB) y solo si falta, la de Palantir:
        #  - «Tierra de mafiosos» T2 en emisión (26-oct): Palantir 5 capítulos, TMDB 10, visto 5 -> con p3 primero
        #    ofrecíamos «no vista» y su submenú solo trae «vista» (FAIL «opcion» siempre)
        #  - Black Clover T3 (25-oct): sin dato de TMDB -> vale la de Palantir (p3TotalEpisodes)
        total = int(info.get("totalEpisodes") or info.get("p3TotalEpisodes") or 0)
        done = bool(total) and seen >= total
        sub = "Temporada %s  ·  %d de %d capítulos vistos" % (info.get("season"), seen, total)
        # en emisión con todo lo emitido visto (MobLand T2, 26-oct: 5 de 10): no hay nada que marcar; Palantir no
        # cambiaba nada y nuestra espera giraba 30 s. Sin opción de temporada, y el texto lo dice
        p3, tm = int(info.get("p3TotalEpisodes") or 0), int(info.get("totalEpisodes") or 0)
        if p3 > 0 and tm > p3 and seen >= p3:
            return (seen,), {"fm_state": "new", "fm_sub": sub + "  ·  faltan por salir"}, []
        props = {"fm_state": "watched" if done else "new", "fm_sub": sub}
        return (seen,), props, [31] if done else [30]
    # serie
    rows = db_query("SELECT completa, num_total_episodios FROM shows_watched WHERE tmdb_id=?", (tmdb,))
    seen_rows = db_query("SELECT COUNT(*) FROM episodes_watched WHERE tmdb_id=? AND playcount>0", (tmdb,))
    seen = seen_rows[0][0] if seen_rows else 0
    done = bool(rows and rows[0][0])
    total = int(rows[0][1] or 0) if rows else 0
    sub = "%d de %d capítulos vistos" % (seen, total) if total else ("%d capítulos vistos" % seen if seen else "Sin empezar")
    props = {"fm_state": "watched" if done else "new", "fm_sub": sub}
    # «Dejar de seguir» solo si está en «Series en seguimiento»: sin fila (sin empezar) u oculta = nada que dejar
    following = follow_state(info) == (True, False)
    return (done, seen), props, ([21] if done else [20]) + ([22] if following else []) + [41]


def route_info(path):
    """dict del elemento de Palantir que va dentro de su ruta; None si no se lee"""
    try:
        info = ast.literal_eval(flix_rows.decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    return info if isinstance(info, dict) else None


SEASON_SLOTS = 40       # huecos de la columna de temporadas (flix_series.MAX_SEASONS)


def season_of(info):
    """la temporada de un capítulo en la columna de la ficha (flix_s<k>_path): {path, info, before, opts} o None.
    Kodi no abre menú contextual sobre esa columna (huecos fijos, sin proveedor de Kodi: la pulsación larga se pierde,
    banco 25-oct) y pedirla como lista de Kodi costaría otra llamada a Palantir (~2-3 s) al abrir cada serie: la opción
    de marcar la temporada va en el menú de sus capítulos (Carlos, 25-oct: en Estuary Palantir está en la temporada)"""
    want = (str(info.get("tmdb") or ""), str(info.get("season", "")))
    for k in range(SEASON_SLOTS):
        path = HOME.getProperty("flix_s%d_path" % k)
        if not path:
            continue
        sinfo = route_info(path)
        if sinfo and kind_of(sinfo) == "season" and (str(sinfo.get("tmdb") or ""), str(sinfo.get("season", ""))) == want:
            before, _, opts = state_of("season", sinfo)
            if not opts:
                return None         # en emisión y al día: nada que marcar, sin entrada en el menú del capítulo
            return {"path": path, "info": sinfo, "before": before, "opts": opts}
    return None


def season_labels(n):
    return {30: "Marcar temporada %s como vista" % n, 31: "Marcar temporada %s como no vista" % n}


def kind_of(info):
    return {"movies": "movie", "episodes": "episode", "seasons": "season", "tvshows": "show"}.get(info.get("content"))


def wait_applied(kind, info, before, timeout=30):
    """Palantir guarda el cambio unos segundos después (arranca su submenú y habla con Trakt; en Fire TV más):
    se espera a verlo en watched.db y entonces se ponen al día las filas / la lista (sin reiniciar Kodi)"""
    mon, start = xbmc.Monitor(), time.time()
    while time.time() - start < timeout and not mon.abortRequested():
        if state_of(kind, info)[0] != before:
            log("aplicado en %.1f s" % (time.time() - start))
            break
        xbmc.sleep(500)
    else:
        log("no veo el cambio en watched.db tras %d s" % timeout)
    HOME.setProperty("fh_progress", "1")             # Inicio táctil: repinta barras / ✓ (flix_home.py)
    if xbmcgui.getCurrentWindowId() == 10000:
        # las pasadas las hace flix_progress con su bloqueo (si ya está en marcha, repite al acabar): antes se
        # llamaba a one_pass() aquí en paralelo y dos procesos escribían la misma caché (auditoría PY-06/NUEVO-01)
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")
    elif not sheet_open():
        xbmc.executebuiltin("Container.Refresh")     # temporadas / capítulos: Palantir vuelve a dar la lista
    # ficha propia (flix_series_sheet): ella pide otra vez capítulos y temporadas al ver flix_eps_refresh


def follow_state(info):
    """(sigue en la tabla, oculta) de la serie en watched.db de Palantir"""
    rows = db_query("SELECT ocultar FROM shows_watched WHERE tmdb_id=?", (str(info.get("tmdb") or ""),))
    return (bool(rows), bool(rows and rows[0][0]))


def after_unfollow(info, before):
    """«No seguir esta serie…»: Palantir la marca (aquí = ocultar, en ningún dispositivo = también en Trakt) pero
    la fila «Series en seguimiento» sale de SU caché: se espera al cambio, se borra esa lista de cache.db y se
    recarga la fila (Carlos, 19-oct: «sigue ahí», a diferencia de las películas)"""
    mon, start = xbmc.Monitor(), time.time()
    while time.time() - start < 30 and not mon.abortRequested() and follow_state(info) == before:
        xbmc.sleep(500)
    changed = follow_state(info) != before
    log("dejar de seguir: %s en %.1f s" % ("aplicado" if changed else "sin cambio en watched.db", time.time() - start))
    if not changed:
        return False
    try:
        db = sqlite3.connect(xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/cache.db"),
                             timeout=5)
        try:
            n = db.execute("DELETE FROM simplecache WHERE id LIKE '%SeriesSeguimiento%'").rowcount
            db.commit()
        finally:
            db.close()
        log("caché de Series en seguimiento borrada (%d)" % n)
    except Exception as e:  # noqa: BLE001
        log("no borro la caché de Series en seguimiento: %s" % e)
    HOME.setProperty("flix_rl_p3PathSeriesSeguimiento", str(int(time.time() * 10)))   # recarga esa fila
    HOME.setProperty("fh_refetch_row", "5102")        # Inicio táctil (flix_home.py): vuelve a pedir esa fila
    return True


def native_menus():
    """menú contextual de siempre UNA vez (series, o lo que no es una película de Palantir). Si en él se entra en
    "Menú Palantir 3..." el permiso dura también para ese submenú; al cerrarse, el siguiente vuelve a ser el KER0N3.
    (Antes duraba hasta 5 s con todo cerrado: reabrir enseguida volvía a dar el de Kodi una y otra vez.)"""
    HOME.setProperty("flix_ctx_skip", "1")
    mon = xbmc.Monitor()

    def wait_open(timeout):
        end = time.time() + timeout
        while time.time() < end and not mon.abortRequested():
            if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
                return True
            xbmc.sleep(100)
        return False

    def wait_closed():
        """espera a que se cierre; devuelve la última opción con foco"""
        last = ""
        while not mon.abortRequested() and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            cid = xbmc.getInfoLabel("System.CurrentControlId")
            if cid:
                last = xbmc.getInfoLabel("Control.GetLabel(%s)" % cid) or last
            xbmc.sleep(100)
        return last

    try:
        if not focus_target():
            return False
        context_menu()
        if not wait_open(4):
            return
        last = wait_closed()
        if SUBMENU_MARK in last and wait_open(10):     # entró en el submenú de Palantir
            wait_closed()
    finally:
        HOME.clearProperty("flix_ctx_skip")


EPS_LISTS = range(7970, 7977)       # listas de capítulos de la pantalla de serie (7970-7975) y 7976: la de una serie de una temporada en la ficha propia


def wait_ctx_closed(limit=2.0):
    """DialogContextMenu.xml lo cierra en su onload, pero este script puede arrancar antes de que se vaya"""
    end = time.time() + limit
    while time.time() < end and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
        xbmc.sleep(50)


def focused_episode():
    """(ruta, carátula, etiqueta) de lo enfocado en la pantalla de serie: el capítulo (listas de capítulos) o la
    temporada (columna 7952); None fuera de ahí. La ventana Vídeos da a ListItem.* (y al menú de
    DialogContextMenu.xml) la temporada SELECCIONADA en su lista oculta, esté donde esté el foco: salía el menú de esa
    temporada al pulsar un capítulo (Carlos, 23-oct, Slow Horses). Dejar de seguir: desde la carátula de la serie"""
    if not on_series():
        return None
    cid = xbmc.getInfoLabel("System.CurrentControlId")
    c = "Container(%s).ListItem." % cid
    if cid == SEASONS_COLUMN:
        path = xbmc.getInfoLabel(c + "Property(path)")
        return (path, "", xbmc.getInfoLabel(c + "Label")) if path else None
    if not cid.isdigit() or int(cid) not in EPS_LISTS:
        return None
    path = xbmc.getInfoLabel(c + "FileNameAndPath")
    return (path, xbmc.getInfoLabel(c + "Art(thumb)"), xbmc.getInfoLabel(c + "Label")) if path else None


def _main():
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    art = sys.argv[2] if len(sys.argv) > 2 else ""
    label = sys.argv[3] if len(sys.argv) > 3 else ""
    if len(sys.argv) <= 4:
        wait_ctx_closed()
        ep = focused_episode()
        if ep:
            cid = xbmc.getInfoLabel("System.CurrentControlId")
            pos = xbmc.getInfoLabel("Container(%s).CurrentItem" % cid)  # ahora: con un diálogo encima no se lee
            EP["cid"], EP["path"] = cid, ep[0]
            try:
                return run_menu(*ep)
            finally:
                close_episode_ctx()
                HOME.setProperty("flix_eps_refresh", "%s,%s" % (cid, pos))  # flix_series: ✓ al día y el foco
                if on_series():
                    xbmc.executebuiltin("SetFocus(%s)" % cid)    # de vuelta al capítulo (no a la lista oculta 52)
    if len(sys.argv) > 4 and sys.argv[4].isdigit():    # Inicio táctil: lista oculta con la fila (flix_home.py)
        CTX["list"], CTX["path"] = sys.argv[4], path
    if CTX["list"]:
        HOME.setProperty("flix_menu_busy", "1")      # flix_home.py no toma nuestro Action(ContextMenu) por un toque
        try:
            return run_menu(path, art, label)
        finally:
            # el Action(ContextMenu) le llega a flix_home.py con retraso: 2,5 s más de margen (marca con la hora)
            HOME.setProperty("flix_menu_busy", "t%f" % time.time())
            xbmc.executebuiltin("SetFocus(7000)")    # foco de vuelta a las filas (no en la lista oculta)
    try:
        return run_menu(path, art, label)
    finally:
        close_episode_ctx()             # FlixCtx del Inicio TV, si se abrió


def run_menu(path, art, label):
    if not path:
        # Inicio: el menú contextual no ve la carátula con foco -> la de la fila que lo tiene (flix_row)
        row = HOME.getProperty("flix_row")
        if row:
            c = "Container(%s).ListItem." % row
            path = xbmc.getInfoLabel(c + "FileNameAndPath")
            art = xbmc.getInfoLabel(c + "Art(poster)") or xbmc.getInfoLabel(c + "Art(tvshow.poster)")
            label = xbmc.getInfoLabel(c + "Label")
            if HOME.getProperty("flix_ctx_src") and xbmc.getCondVisibility("!Window.IsActive(videos)"):
                INICIO["src"], INICIO["path"] = HOME.getProperty("flix_ctx_src"), path
    info = {}
    if path.startswith("plugin://plugin.video.palantir3/"):
        try:
            info = ast.literal_eval(flix_rows.decode_route(path))
        except Exception:  # noqa: BLE001
            info = {}
    kind = kind_of(info) if isinstance(info, dict) else None
    if not kind:
        native_menus()      # menús de Palantir, carpetas...: el de siempre
        return
    before, props, opts = state_of(kind, info)
    if kind == "season" and not opts:
        # un diálogo sin opciones saldría vacío y sin foco: mejor un aviso (MobLand T2 en emisión, 26-oct)
        xbmcgui.Dialog().notification("KER0N3 MEDIA", "Ya has visto todos los capítulos que han salido",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        return
    if kind == "episode":
        name = flix_play.COLOR_RE.sub("", label).strip()
        if name:
            props["fm_sub"] = "%s  ·  %s" % (name, props["fm_sub"].split("  ·  ", 1)[-1])
    if kind == "episode":
        title = info.get("tvshowtitle") or ""
    elif kind == "season":
        title = info.get("tvshowtitle") or ""
    else:
        title = info.get("title") or info.get("tvshowtitle") or flix_play.COLOR_RE.sub("", info.get("label") or "")
    # capítulos: la ruta no trae carátula -> la de la serie (la pone flix_series.py al abrirla)
    poster = flix_play._img(info.get("poster")) or art or HOME.getProperty("flix_poster")
    props.update({"fm_title": title.strip(), "fm_poster": poster,
                  "fm_fanart": flix_play._img(info.get("fanart"))})
    labels = EPISODE_LABELS if kind == "episode" else {}
    season = season_of(info) if kind == "episode" and EP["cid"] else None   # capítulo de la ficha de la serie
    if season:
        opts = opts + season["opts"]
        labels = dict(labels)
        labels.update(season_labels(info.get("season")))
    prefetched = prefetch_ctx()               # la lista oculta carga mientras se elige
    w = Menu("FlixMenu.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props, opts=opts,
             labels=labels)
    w.doModal()
    choice = w.choice
    del w
    if prefetched and (choice not in ACTIONS or choice == 50):
        close_episode_ctx()                   # nada de Palantir: fuera antes de seguir (selector, Atrás…)
    if choice not in ACTIONS:
        return
    if season and choice in season["opts"]:
        # la temporada del capítulo: fuera la lista oculta de sus capítulos (FlixCtx) y la acción a la temporada
        # seleccionada en la lista oculta de Kodi (focus_episode), como si se hubiera pulsado en la columna
        close_episode_ctx()
        EP["cid"], EP["path"] = SEASONS_COLUMN, season["path"]
        kind, info, before = "season", season["info"], season["before"]
        log("menú del capítulo: %s de la temporada %s" % (ACTIONS[choice][0], info.get("season")))
    xbmc.sleep(250)                          # que el foco vuelva a la carátula antes de abrir menús
    if choice == 50:
        HOME.setProperty("flix_pick_once", str(time.time()))
        # cabecera del selector (título, póster y fondo): la de esta película, no la del último clic
        HOME.setProperty("flix_title", props.get("fm_title") or "")
        HOME.setProperty("flix_poster", props.get("fm_poster") or "")
        HOME.setProperty("flix_fanart", props.get("fm_fanart") or "")
        started = props.get("fm_state") == "started"
        log("elegir resolución: %s" % path[:80])
        flix_play.start(path, before[1] if started else 0)    # empezada: reanuda donde iba
        return
    follow_before = follow_state(info) if choice == 22 else None
    HOME.setProperty("flix_working", (EPISODE_WORKING.get(choice) if kind == "episode" else None)
                     or WORKING.get(choice, "Un momento…"))
    try:
        try:
            ok = run_palantir(ACTIONS[choice][2], dialog=choice in DIALOG_ACTIONS)
            if ok and choice == 12:
                xbmc.sleep(500)
                run_kodi(ACTIONS[12][2])    # también el «Reanudar desde…» de Kodi (si no hay, no pasa nada)
        finally:
            release_ctx()                   # lo de Palantir ya está hecho (o falló): lista oculta fuera, foco a su sitio
        unfollowed = ok and choice == 22 and after_unfollow(info, follow_before)
        done = EPISODE_DONE.get(choice) if kind == "episode" else None
        done = done or ACTIONS[choice][3]
        if ok and done:
            wait_applied(kind, info, before)
    finally:
        HOME.clearProperty("flix_working")     # rueda fuera antes del aviso del resultado
    if ok and choice == 22:
        if unfollowed:
            xbmcgui.Dialog().notification("KER0N3 MEDIA", "Serie quitada de Series en seguimiento",
                                          xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)
        return
    if not ok and FAIL["why"] == "opcion":
        # Palantir decide sus opciones con su copia de la lista (Top 10, filas): si aún dice lo contrario, se corrige
        # ya y el siguiente intento va bien. Antes salía «Palantir está ocupado», que no era (Spider-Man, 25-oct)
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_progress.py,menu)")
        refresh_home_list()
        xbmcgui.Dialog().notification("KER0N3 MEDIA", "Palantir tenía esta lista sin poner al día. Ya está; vuelve a intentarlo",
                                      xbmcvfs.translatePath("special://skin/resources/icon.png"), 4000)
        return
    if done or not ok:
        xbmcgui.Dialog().notification("KER0N3 MEDIA", done if ok else "Palantir está ocupado (sincronizando con Trakt). Inténtalo en unos segundos",
                                      xbmcvfs.translatePath("special://skin/resources/icon.png"), 3000)


def refresh_home_list():
    """Inicio táctil: fuerza la recarga de la lista oculta 7990 (flix_ctx_path) para que «vuelve a intentarlo» sirva.
    Sin esto Palantir seguía con su copia de antes de marcar y fallaba igual en cada intento («Tenzing», 26-oct).
    La TV abre un FlixCtx nuevo cada vez (sin copia vieja) y no tiene flix_ctx_path: no se toca. True si recarga"""
    cur = HOME.getProperty("flix_ctx_path")
    if not cur or CTX_WIN["w"] is not None or not CTX["list"]:
        return False
    new, _ = flix_common.ctx_path(cur, "", "", cur, int(time.time() * 1000))
    HOME.setProperty("flix_ctx_path", new)
    HOME.clearProperty("flix_ctx_sig")          # el siguiente toque largo vuelve a cargarla
    return True


def main():
    # la ficha de serie propia (flix_series_sheet) no abre otro menú mientras este corre (ni con sus Action(ContextMenu))
    HOME.setProperty("flix_menu_run", "1")
    try:
        return _main()
    finally:
        HOME.clearProperty("flix_menu_run")


if __name__ == "__main__":
    main()
