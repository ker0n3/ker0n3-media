"""Reproducir una película de Palantir preguntando si reanudar (como hace Kodi en sus listas).

Desde las filas del skin la película se abría con PlayMedia(ruta): Kodi crea un elemento nuevo sin la posición
de reanudación que Palantir pone en la carátula y empezaba siempre desde el principio sin preguntar.

Uso desde XML: RunScript(special://skin/scripts/flix_play.py,<ruta>,<porcentaje visto>,<duración en s>)
Uso desde Python: flix_play.play(ruta, posicion_s, total_s)
Reanudar = xbmc.Player().play(ruta, ListItem con StartOffset) (Kodi conserva el desplazamiento al resolver
la ruta del plugin); desde el inicio = PlayMedia(ruta,noresume) (sin el «Reanudar desde…» propio de Kodi).
"""
import re
import threading
import sys

import xbmc
import xbmcgui
import xbmcvfs
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import COLOR_RE  # noqa: E402,F401



class ResumeDialog(xbmcgui.WindowXMLDialog):
    """FlixResume.xml (tools/gen_resume_dialog.py): 10 = Seguir viendo, 11 = Desde el principio, 14 = Ver ficha;
    Atrás = nada"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.choice = -1

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        try:
            self.getControl(30).setPercent(float(self.props.get("fr_pct") or 0))
        except (RuntimeError, ValueError):
            pass

    def onClick(self, cid):
        if cid in (10, 11, 14):           # 14 y no 12: Kodi escribe «N objetos» en el id 12 de las ventanas Python
            self.choice = {10: 0, 11: 1, 14: 2}[cid]
            self.close()


def fmt(secs):
    secs = int(secs)
    return "%d:%02d:%02d" % (secs // 3600, secs % 3600 // 60, secs % 60)


def choose(title, sub, btn10, btn11="Desde el principio", more="", pct=0, fanart=""):
    """pop-up FlixResume: 0 = seguir viendo, 1 = desde el principio, 2 = ver ficha (solo con more), -1 = Atrás"""
    props = {"fr_title": COLOR_RE.sub("", title or "").strip(), "fr_sub": sub, "fr_btn10": btn10, "fr_btn11": btn11,
             "fr_more": more, "fr_pct": str(int(pct)), "fr_fanart": fanart or ""}
    w = ResumeDialog("FlixResume.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props)
    w.doModal()
    choice = w.choice
    del w
    return choice


def ask(position, total, title="", fanart=""):
    sub = "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else "")
    return choose(title, sub, "Reanudar  ·  %s" % fmt(position), "Desde el inicio",
                  pct=100 * position / total if total else 0, fanart=fanart)


def start(path, offset=0):
    """reproduce la ruta de Palantir; offset > 0 = reanudar ahí (StartOffset se conserva al resolver el plugin)"""
    if offset > 0:
        li = xbmcgui.ListItem(path=path)
        li.setProperty("StartOffset", str(int(offset)))
        xbmc.log("[flix_play] reanudar en %s: %s" % (fmt(offset), path[:80]), xbmc.LOGINFO)
        xbmc.Player().play(path, li)
    else:
        # noresume: la ficha ya decidió (progreso de Palantir/Trakt). Sin esto Kodi preguntaba «Reanudar desde…» con
        # su PROPIO marcador local (otro progreso, distinto en cada aparato: «Resume from 00:18:52», móvil 19-oct)
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % path)


def play(path, position=0, total=0, title="", fanart=""):
    position, total = float(position or 0), float(total or 0)
    if not xbmc.getCondVisibility("Skin.HasSetting(flix_nosheet)"):
        # TV y táctil: pulsar una película abre su ficha (info + Ver / Seguir viendo / Desde el principio)
        return sheet(path, position, total, title, fanart)
    if position > 30 and (not total or position < total - 60):
        choice = ask(position, total, title, fanart)
        if choice < 0:
            return
        if choice == 0:
            start(path, position)
            return
    start(path)


# ---------- ficha de película (TV: xml/FlixMovie.xml, táctil: touch/xml/FlixMovie.xml) ----------
TMDB_IMG = "https://image.tmdb.org/t/p/original"


def _img(v):
    v = v or ""
    return TMDB_IMG + v if v.startswith("/") else v


def route_info(path):
    """el elemento entero de Palantir va dentro de su ruta (JSON con comillas de Python)"""
    try:
        import ast
        import flix_rows
        text = flix_rows.decode_route(path)
        return ast.literal_eval(text)
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_play] ruta de Palantir ilegible (%s): %s" % (e, path[:80]), xbmc.LOGWARNING)
        return {}


class MovieSheet(xbmcgui.WindowXMLDialog):
    """FlixMovie.xml: 10 = Ver / Seguir viendo, 11 = Desde el principio, 90 = volver"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})
        self.choice = -1

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        try:
            self.getControl(30).setPercent(float(self.props.get("fm_pct") or 0))
        except (RuntimeError, ValueError):
            pass
        self.setFocusId(10)

    def onClick(self, cid):
        if cid in (10, 11):
            self.choice = cid - 10
            self.close()
        elif cid == 90:
            self.close()


def sheet(path, position, total, title, fanart):
    import sys as _s
    import os as _o
    _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
    info = route_info(path)
    label = info.get("label") or title or ""
    clean_label = COLOR_RE.sub("", label)
    parts = re.findall(r"\[([^\]]*)\]", clean_label)
    name = info.get("title") or re.split(r"\s+\(\d{4}\)|\s+\[", clean_label)[0].strip()
    watched = 0
    # progreso real (watched.db de Palantir), no el que trae la carátula
    try:
        import flix_progress
        W = flix_progress.truth_cached(max_age=0) or {}
        row = W.get(str(info.get("tmdb") or ""))
        if row:
            watched = int(row[0] or 0)
            total = float(row[2] or 0) or total or float(info.get("duration") or 0)
            position = total * float(row[1] or 0) / 100
        elif W:
            position = 0.0
    except Exception as e:  # noqa: BLE001
        xbmc.log("[flix_play] progreso: %s" % e, xbmc.LOGWARNING)
    total = total or float(info.get("duration") or 0)
    started = position > 30 and (not total or position < total - 60)
    if started:
        # empezada: pop-up en vez de la ficha (la ficha queda como 3.ª opción)
        choice = choose(name, "Te quedaste en %s%s" % (fmt(position), " de " + fmt(total) if total else ""),
                        "Seguir viendo  ·  %s" % fmt(position), more="Ver ficha",
                        pct=100 * position / total if total else 0, fanart=fanart or _img(info.get("fanart")))
        if choice == 0:
            return start(path, position)
        if choice == 1:
            return start(path)
        if choice != 2:
            return
    quality = parts[-1] if len(parts) >= 2 else ""
    up = quality.upper()
    q = "4K · DV" if "4K" in up and "DV" in up else next(
        (v for k, v in (("4K", "4K"), ("DV", "DV"), ("HDR", "HDR"), ("1080", "1080p"), ("720", "720p")) if k in up), "")
    year = (info.get("fecha") or "")[:4]
    mins = int(float(info.get("duration") or total or 0) // 60)
    rating = str(info.get("rating") or "").split("/")[0]

    def meta_with(rt):              # rt: «Metacritic 82» (flix_ratings) o '' -> la ★ de TMDB de siempre
        return "  ·  ".join(x for x in (year, "%d min" % mins if mins else "", q,
                                         rt or ("★ %s" % rating if rating and rating not in ("0", "0.0") else ""),
                                         parts[0].strip() if len(parts) >= 2 else "") if x and x.strip())
    try:
        import flix_ratings
        rt = flix_ratings.label_for(path)
    except Exception as e:  # noqa: BLE001
        flix_ratings, rt = None, ""
        xbmc.log("[flix_play] nota: %s" % e, xbmc.LOGWARNING)
    meta = meta_with(rt)
    genre = info.get("genre") or []
    props = {
        "fm_title": name,
        "fm_logo": _img(info.get("clearlogo")),
        "fm_fanart": fanart or _img(info.get("fanart")),
        "fm_meta": meta,
        "fm_genre": " / ".join(genre) if isinstance(genre, list) else str(genre),
        "fm_plot": COLOR_RE.sub("", info.get("plot") or ""),
        "fm_state": "started" if started else "watched" if watched else "new",
        "fm_pos": fmt(position) if started else "",
        "fm_total": fmt(total) if total else "",
        "fm_pct": str(int(100 * position / total)) if started and total else "0",
        "fm_btn": ("Seguir viendo  ·  %s" % fmt(position)) if started else "Ver de nuevo" if watched else "Ver",
    }
    w = MovieSheet("FlixMovie.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i", props=props)
    if flix_ratings and not rt and flix_ratings.wanted(path):      # sin nota guardada: se pide sin esperar
        def late():
            r = flix_ratings.label_for(path, wait=flix_ratings.TIMEOUT)
            if r:
                w.setProperty("fm_meta", meta_with(r))
        threading.Thread(target=late, daemon=True).start()
    w.doModal()
    choice = w.choice
    del w
    if choice == 0:
        start(path, position if started else 0)
    elif choice == 1:
        start(path)


def resume_of(f):
    """(posición, total) de un elemento JSON-RPC (propiedad resume)"""
    r = f.get("resume") or {}
    return r.get("position") or 0, r.get("total") or 0


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    title = sys.argv[4] if len(sys.argv) > 4 else ""
    fanart = sys.argv[5] if len(sys.argv) > 5 else ""
    try:
        pct = float(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] else 0.0
        dur = float(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3] else 0.0
    except ValueError:
        pct, dur = 0.0, 0.0
    # desde el XML solo hay porcentaje entero: se redondea hacia atrás (reanuda como mucho ~1 % antes)
    pos = max(0.0, (pct - 1) * dur / 100.0) if pct > 0 and dur > 0 else 0.0
    play(path, pos, dur, title, fanart)
