# -*- coding: utf-8 -*-
"""Carrusel del Top 10 en el Inicio de la TV (Carlos, 12-nov: «el carrusel con el Top 10 que tenemos en la versión
móvil, para la TV; que venga activado de serie» y «arranca en el carrusel»).

En la TV la cabecera del Inicio ya enseña el título que tiene el foco (fondo, logo, datos). El carrusel es una lista
más, la 5100, encima de la primera fila: sus elementos son los del Top 10 de películas y solo pinta un botón «Ver ahora»
y los puntos; con el foco en ella la cabecera hace de escaparate, izquierda/derecha cambian de título, OK lo abre como
cualquier carátula y abajo se va a las filas. Con el mando quieto pasa sola al siguiente cada EVERY s.

Aquí, lo que no toca la ventana (de dónde sale, el texto «N.º 3 en películas hoy», cuándo gira y el ajuste de
«Personalizar menú e Inicio»); flix_inicio.py la rellena y la mueve. Apagado o en modo ligero la lista se queda vacía y
el Inicio es el de siempre (la navegación de las filas solo pasa por ella si tiene títulos: $EXP[FlixHeroOn])."""
import xbmc

HERO_ID = 5100
OFF = "flix_tv_hero_off"        # Skin.Bool: apagado. De serie (sin el ajuste), encendido
EVERY = 12                      # s con el mando quieto entre un título y el siguiente (como la táctil)
MAX = 10
TOP_MOVIES, TOP_SHOWS = 5105, 5106
PERSONAL = (5101, 5102)         # «Seguir viendo» y «Series en seguimiento»: no son un escaparate


def enabled():
    return not xbmc.getCondVisibility("Skin.HasSetting(%s)" % OFF) and \
        not xbmc.getCondVisibility("Skin.HasSetting(flix_lite)")


def label(on=None):
    """texto de la fila del ajuste (Ajustes → Personalizar menú e Inicio); on: el valor ya conocido"""
    if on is None:
        on = not xbmc.getCondVisibility("Skin.HasSetting(%s)" % OFF)
    return "Carrusel del Top 10 al abrir el Inicio: %s" % ("Sí" if on else "No")


def toggle():
    """enciende o apaga el carrusel y devuelve el valor nuevo; el builtin va por la cola de Kodi: se espera (acotado)
    a que se vea, como flix_menu_preview.toggle"""
    on = bool(xbmc.getCondVisibility("Skin.HasSetting(%s)" % OFF))      # apagado ahora -> se enciende
    xbmc.executebuiltin("Skin.%s(%s)" % ("Reset" if on else "SetBool", OFF))
    for _ in range(40):
        if bool(xbmc.getCondVisibility("Skin.HasSetting(%s)" % OFF)) != on:
            break
        xbmc.sleep(50)
    return on


def source(rows, shown):
    """id de la fila de la que sale el carrusel: Top 10 de películas; si no está en el Inicio, el de series; si
    tampoco, la primera fila de carátulas con títulos que no sea personal. None si no hay ninguna"""
    ids = [r["id"] for r in rows]
    for i in (TOP_MOVIES, TOP_SHOWS):
        if i in ids:
            return i
    return next((i for i in ids if i not in PERSONAL and shown.get(i)), None)


def pick(files, is_more):
    """los títulos del carrusel: los MAX primeros, sin la tarjeta «Ver más»"""
    return [f for f in files or [] if not is_more(f)][:MAX]


def rank_label(row_id, k):
    """«N.º 3 en películas hoy» (k desde 0); vacío si la fila no es un Top 10"""
    what = {TOP_MOVIES: "películas", TOP_SHOWS: "series"}.get(row_id)
    return "N.º %d en %s hoy" % (k + 1, what) if what else ""


def due(focused, idle, now, last, playing):
    """¿toca pasar al siguiente? Solo con el foco en el carrusel, sin vídeo (tráiler) y EVERY s sin tocar el mando
    ni girar"""
    return bool(focused) and not playing and idle >= EVERY and now - last >= EVERY


def next_pos(pos, n):
    return (pos + 1) % n if n > 0 else 0
