"""Configuración del Inicio (TV y táctil): lógica pura, sin Kodi, para poder probarla con pytest.

home_order.json (addon_data/<skin>/):
  {"order": [ids], "hidden": [ids], "deleted": [ids],
   "custom": [{"id": 5130, "label": "Acción", "path": "plugin://…"}], "items": 15}
  opcional "names": {"<id>": nombre que se ve} (Ajustes → Cambiar nombre)
opcional "random": {"on", "n", "groups", "current", "order"} (Filas al azar: 4 fijas + listas de TMDB sorteadas,
  flix_random_rows.py; spec docs/superpowers/specs/2026-10-24-filas-al-azar-design.md)
Lo que falte toma el valor por defecto (los ficheros antiguos solo tenían order y hidden).

Filas de serie: ids 5101-5118. Filas añadidas por el usuario: 5130-5147. Máximo 18 filas en total (ocultas incluidas).
"""
import hashlib
import json
import re

# etiquetas de formato: la expresión común (era una copia, TAG_RE; revisión 29-oct ARR-14). flix_common no importa
# Kodi: tools/gen_home_rows.py sigue pudiendo importar este módulo
from flix_common import COLOR_RE

MAX_ROWS = 18
CUSTOM_IDS = range(5130, 5148)
ITEM_CHOICES = (8, 10, 15, 20, 30)
DEFAULT_ITEMS = 15
FOLLOW_ROW = 5102     # «Series en seguimiento»: sus series llevan ▶ (Palantir no da capítulos vistos)
TOP10_ITEMS = 10
INITIAL_NEAR = 5      # filas que se cargan al abrir el Inicio
# ruta de una fila aún lejana: carpeta del skin sin vídeos (0 elementos al instante). NUNCA vacía: un contenedor
# de Kodi con ruta vacía no vuelve a cargar cuando la ruta cambia después (pasó con la previsualización de secciones)
IDLE_PATH = "special://skin/media/flix/icons/"
AHEAD = 3             # filas que se marcan por debajo de la que tiene el foco
# Filas al azar: siempre arriba Seguir viendo, Series en seguimiento, Top 10 películas y Top 10 series; debajo listas
# de TMDB sorteadas (claves de flix_tmdblists) con ids propios
FIXED_ROWS = (5101, 5102, 5105, 5106)
# de serie fuera del Inicio (se pueden añadir): las 2 de Tendencias (Carlos, 24-oct). Solo sin configuración guardada
DEFAULT_DELETED = (5117, 5118)
RANDOM_IDS = range(5150, 5164)
RANDOM_N = (4, 6, 8, 10, 14)
RANDOM_DEFAULT_N = 8
RANDOM_GROUPS = 6     # apartados de flix_tmdblists.GROUPS (los 2 últimos, Niños y Adolescentes, 30-oct)
STANDARD_GROUPS = (0, 1, 2, 3)      # de serie en Estándar: Niños y Adolescentes desmarcados (no cambia nada a nadie)
# tipo del Inicio aleatorio (Carlos, 30-oct): Niños y Adolescentes sortean solo su apartado y sin los Top 10 de serie
TIPOS = ("estandar", "ninos", "adolescentes")
TIPO_GROUP = {"ninos": 4, "adolescentes": 5}
TOP10_ROWS = (5105, 5106)
TMDB_PREFIX = "flix://tmdb/"


# ---------- configuración ----------
def _ints(seq):
    out = []
    for v in seq or []:
        try:
            out.append(int(v))
        except (TypeError, ValueError):
            pass
    return out


def normalize(raw):
    raw = raw if isinstance(raw, dict) else {}
    custom = []
    seen = set()
    for d in raw.get("custom") or []:
        try:
            i = int(d["id"])
            label, path = str(d["label"]), str(d["path"])
        except (KeyError, TypeError, ValueError):
            continue
        if i in CUSTOM_IDS and i not in seen and path:
            seen.add(i)
            custom.append({"id": i, "label": label, "path": path})
    items = raw.get("items", DEFAULT_ITEMS)
    names = {}
    for k, v in (raw.get("names") if isinstance(raw.get("names"), dict) else {}).items():
        try:
            i = int(k)
        except (TypeError, ValueError):
            continue
        if isinstance(v, str) and v.strip():
            names[str(i)] = v.strip()
    out = {
        "order": _ints(raw.get("order")),
        "hidden": _ints(raw.get("hidden")),
        # sin nada guardado: lo de serie; un fichero antiguo sin "deleted" sigue sin eliminadas
        "deleted": _ints(raw.get("deleted")) if raw else list(DEFAULT_DELETED),
        "custom": custom,
        "items": items if items in ITEM_CHOICES else DEFAULT_ITEMS,
    }
    if names:
        out["names"] = names        # solo si hay: la firma de las configuraciones de antes no cambia
    if isinstance(raw.get("random"), dict):
        out["random"] = normalize_random(raw["random"])     # igual: solo si existe
    return out


def normalize_random(raw):
    raw = raw if isinstance(raw, dict) else {}
    n = raw.get("n", RANDOM_DEFAULT_N)
    groups = sorted({g for g in _ints(raw.get("groups")) if 0 <= g < RANDOM_GROUPS}) or list(STANDARD_GROUPS)
    current = []
    for k in raw.get("current") or []:
        if isinstance(k, str) and k and k not in current:
            current.append(k)
    order = []          # fijas que salen, en su orden (se pueden quitar; sin "order" = las 4)
    for i in _ints(raw.get("order")) if "order" in raw else list(FIXED_ROWS):
        if i in FIXED_ROWS and i not in order:
            order.append(i)
    out = {"on": bool(raw.get("on")), "n": n if n in RANDOM_N else RANDOM_DEFAULT_N, "groups": groups,
           "current": current[:len(RANDOM_IDS)], "order": order,
           "tipo": raw.get("tipo") if raw.get("tipo") in TIPOS else "estandar"}
    if "order_estandar" in raw:         # las fijas de Estándar mientras se usa Niños o Adolescentes (set_tipo)
        out["order_estandar"] = [i for i in dict.fromkeys(_ints(raw.get("order_estandar"))) if i in FIXED_ROWS]
    return out


# Modo ligero (Ajustes, Skin.HasSetting(flix_lite)): Inicio de 6 filas y 10 títulos; lo guardado no
# se toca (vuelve al apagarlo). Medido en el banco: ~50 MB menos de RAM que 16 filas × 15 (Carlos, 24-oct)
LITE_ROWS = (5101, 5102, 5105, 5106, 5103, 5104)
LITE_ITEMS = 10


def lite_conf(conf):
    """la configuración que se usa con el modo modesto (las 6 filas, en este orden, con sus nombres propios)"""
    return normalize({"order": list(LITE_ROWS), "hidden": [], "custom": [], "items": LITE_ITEMS,
                      "deleted": [i for i in range(5101, 5119) if i not in LITE_ROWS],
                      "names": conf.get("names") or {}})


def random_conf(conf):
    """apartado random normalizado (apagado y de serie si la configuración no lo trae)"""
    return conf.get("random") or normalize_random(None)


def random_on(conf):
    return bool((conf.get("random") or {}).get("on"))


def next_random_n(n):
    if n not in RANDOM_N:
        return RANDOM_DEFAULT_N
    return RANDOM_N[(RANDOM_N.index(n) + 1) % len(RANDOM_N)]


def draw_groups(r):
    """apartados de los que se sortea: en Estándar, los marcados; en Niños y Adolescentes, solo el suyo"""
    t = r.get("tipo", "estandar")
    return [TIPO_GROUP[t]] if t in TIPO_GROUP else list(r["groups"])


def set_tipo(r, tipo):
    """cambia el tipo del Inicio aleatorio (r normalizado; se cambia en el sitio y se devuelve). Al salir de Estándar
    se guardan sus fijas y se quitan los Top 10 (se pueden volver a añadir con «Añadir fija»); al volver, se reponen.
    Lo sorteado era de otro tipo: se vacía y quien llama sortea otra vez"""
    old = r.get("tipo", "estandar")
    if tipo not in TIPOS or tipo == old:
        return r
    if old == "estandar":
        r["order_estandar"] = list(r["order"])
        r["order"] = [i for i in r["order"] if i not in TOP10_ROWS]
    elif tipo == "estandar":
        r["order"] = list(r.get("order_estandar") or FIXED_ROWS)
        r.pop("order_estandar", None)
    r["tipo"], r["current"] = tipo, []
    return r


def _named(rows, conf):
    names = conf.get("names") or {}
    for r in rows:
        if str(r["id"]) in names:
            r["title"] = names[str(r["id"])]    # nombre que se ve; "label" sigue siendo el de siempre
    return rows


def fixed_rows(defaults, conf):
    """Filas al azar: las fijas elegidas (random.order) que traiga el Inicio de serie, en su orden, nunca ocultas"""
    pos = {i: k for k, i in enumerate(random_conf(conf)["order"])}
    rows = [dict(d, custom=False, hidden=False) for d in defaults if d["id"] in pos]
    return _named(sorted(rows, key=lambda r: pos.get(r["id"], len(pos))), conf)


def random_rows(keys, label_of=None):
    """filas de las listas sorteadas (claves desconocidas fuera: actualización que quitó una lista)"""
    if label_of is None:
        import flix_tmdblists
        label_of = lambda k: flix_tmdblists.BY_KEY.get(k, ("",))[0]   # noqa: E731
    out = []
    for k in keys:
        label = label_of(k)
        if label and len(out) < len(RANDOM_IDS):
            out.append({"id": RANDOM_IDS[len(out)], "label": label, "path": TMDB_PREFIX + k, "custom": True,
                        "random": True, "hidden": False})
    return out


def compose(defaults, conf, label_of=None):
    """filas del Inicio en el orden guardado: de serie no eliminadas + añadidas. Cada una = copia de su dict con
    "custom" y "hidden". Las que no estén en "order" (filas de serie nuevas tras una actualización) van al final.
    Con Filas al azar: las 4 fijas + las listas sorteadas (random.current); lo demás se guarda pero no sale."""
    if random_on(conf):
        return fixed_rows(defaults, conf) + random_rows(conf["random"]["current"], label_of)
    rows = [dict(d, custom=False) for d in defaults if d["id"] not in conf["deleted"]]
    rows += [dict(d, custom=True) for d in conf["custom"]]
    pos = {i: k for k, i in enumerate(conf["order"])}
    rows = [r for _, r in sorted(enumerate(rows), key=lambda kr: (pos.get(kr[1]["id"], 1000 + kr[0])))]
    for r in rows:
        r["hidden"] = r["id"] in conf["hidden"]
    return _named(rows, conf)


def restore(conf, row_id):
    conf["deleted"] = [i for i in conf["deleted"] if i != row_id]


def delete(conf, row_id):
    conf["order"] = [i for i in conf["order"] if i != row_id]
    conf["hidden"] = [i for i in conf["hidden"] if i != row_id]
    if any(d["id"] == row_id for d in conf["custom"]):
        conf["custom"] = [d for d in conf["custom"] if d["id"] != row_id]
    elif row_id not in conf["deleted"]:
        conf["deleted"].append(row_id)


def next_items(n):
    if n not in ITEM_CHOICES:
        return DEFAULT_ITEMS
    return ITEM_CHOICES[(ITEM_CHOICES.index(n) + 1) % len(ITEM_CHOICES)]


def signature(conf):
    """firma corta y estable de la configuración (va en un comentario de Home.xml)"""
    blob = json.dumps(normalize(conf), sort_keys=True, ensure_ascii=True)
    return hashlib.sha1(blob.encode("ascii")).hexdigest()[:16]


# ---------- TV: filas de Home.xml + Includes_FlixRows.xml ----------
BLOCK_RE = re.compile(r'[ \t]*<include content="FlixRow(?:Static)?">.*?</include>\n?', re.S)
PARAM_RE = re.compile(r'<param name="(\w+)" value="([^"]*)"')
EXTRA = ("itemw", "px", "fx")


def parse_tv_blocks(region_xml):
    """filas de serie del trozo de Home.xml (formato antiguo con path=$VAR[FlixPath…] o nuevo con src=…)"""
    out = []
    for blk in BLOCK_RE.findall(region_xml):
        p = dict(PARAM_RE.findall(blk))
        src = p.get("src") or re.search(r"\$VAR\[(\w+)\]", p.get("path", "")).group(1)
        out.append({
            "id": int(p["list_id"]),
            "label": p["label"].replace("&quot;", '"').replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&"),
            "path": "$VAR[%s]" % src,
            "src": src,
            "top10": p.get("top10") == "true",
            "extra": {k: p[k] for k in EXTRA if k in p},
        })
    return out


NAV_SLOTS = 4


def _alive(i):
    return "[Integer.IsGreater(Container(%d).NumItems,0) | Container(%d).IsUpdating]" % (i, i)


def _dead(i):
    return "[Integer.IsEqual(Container(%d).NumItems,0) + !Container(%d).IsUpdating]" % (i, i)


TOP_BUTTON = 9301     # Inicio TV: botón Buscar arriba a la derecha (arriba desde la primera fila)
AWAKE_UP, AWAKE_DOWN = 1, 2   # filas con el diseño completo de carátula: la enfocada, 1 por encima y 2 por debajo
AWAKE_START = 3               # antes de enfocar ninguna fila: las 3 primeras


def awake_cond(ids, k):
    """condición «fila k despierta» (parámetro awake del FlixRow). Kodi procesa en cada fotograma TODAS las filas del
    grouplist del Inicio aunque no se vean (16 filas: ~45 % de CPU en reposo en Shield y Fire TV, 21-oct); las
    dormidas usan una carátula sola (FlixRowLayouts) y siguen visibles, enfocables y con sus títulos cargados"""
    near = ids[max(0, k - AWAKE_DOWN):k + AWAKE_UP + 1]
    conds = ["String.IsEqual(Window(home).Property(flix_row),%d)" % i for i in near]
    if k < AWAKE_START:
        conds.append("String.IsEmpty(Window(home).Property(flix_row))")
    return "[" + " | ".join(conds) + "]"


def _nav(prefix, cands, fallback=None):
    """params <prefix>1..4 (destinos) y <prefix>c1..4 (condiciones excluyentes): ir a la primera fila viva;
    si no queda ninguna por encima/debajo, a fallback (solo con hueco libre: hasta 3 vecinas)"""
    out = []
    for j in range(NAV_SLOTS):
        if j < len(cands):
            cond = " + ".join([_alive(cands[j])] + [_dead(c) for c in cands[:j]])
            out += [("%s%d" % (prefix, j + 1), cands[j]), ("%sc%d" % (prefix, j + 1), cond)]
        elif j == len(cands) and fallback is not None:
            cond = " + ".join(_dead(c) for c in cands) or "true"
            out += [("%s%d" % (prefix, j + 1), fallback), ("%sc%d" % (prefix, j + 1), cond)]
        else:
            out += [("%s%d" % (prefix, j + 1), "noop"), ("%sc%d" % (prefix, j + 1), "false")]
    return out


def _attr(v):
    # a mano y no xml.sax.saxutils.escape: ese import arrastra urllib.request, http, ssl, email y tempfile (~0,3 s en
    # cada apertura del Inicio y del editor; auditoría 22-oct C-03)
    return str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def render_tv(rows, items):
    """rows = compose(...) -> trozo de filas de xml/FlixInicio.xml (Inicio TV = ventana Python flix_inicio.py, que
    rellena cada fila desde la caché y pide a Palantir por detrás, como las secciones). Solo las filas visibles.
    path/src/limit no los usa el include: flix_inicio.py y parse_tv_blocks los leen de aquí."""
    vis = [r for r in rows if not r.get("hidden")]
    ids = [r["id"] for r in vis]
    blocks = []
    for k, r in enumerate(vis):
        src = r.get("src") or "FlixRowPath%d" % r["id"]
        path = r["path"] if r.get("src") else _attr(r["path"])
        params = [("list_id", r["id"]), ("label", _attr(r.get("title") or r["label"])), ("path", path),
                  ("src", src), ("top10", "true" if r.get("top10") else "false")]
        params += [(k2, v) for k2, v in (r.get("extra") or {}).items()]
        if r["id"] == FOLLOW_ROW and "follow" not in (r.get("extra") or {}):
            params += [("follow", "true")]     # ▶ en las series de «Series en seguimiento» (todas empezadas)
        params += [("limit", TOP10_ITEMS if r.get("top10") else items), ("back", 9000)]
        params += _nav("d", ids[k + 1:k + 1 + NAV_SLOTS])
        params += _nav("u", ids[max(0, k - NAV_SLOTS):k][::-1], TOP_BUTTON)
        params += [("awake", awake_cond(ids, k))]
        blocks.append('\t\t\t\t<include content="FlixRowStatic">\n' +
                      "".join('\t\t\t\t\t<param name="%s" value="%s" />\n' % (n, v) for n, v in params) +
                      "\t\t\t\t</include>\n")
    return "".join(blocks)


# ---------- explorador de Palantir: qué carpetas se pueden abrir y cuántos títulos hay ----------
# acciones/etiquetas que no son listados: abren el teclado, ajustes o diálogos de Palantir
SKIP_RE = re.compile(r"buscar|search|ajuste|config|setting|herramient|cuenta|account|login",
                     re.I)
MORE_RE = re.compile(r"^(m[aá]s|more|siguiente|next)\b", re.I)


def clean_label(label):
    return COLOR_RE.sub("", label or "").strip()


def action_of(path):
    """acción de una ruta de Palantir (su JSON va en base64 invertido y rotado ceil(len/4))"""
    import base64
    import math
    blob = (path or "").split("?", 1)[-1].split("&", 1)[0]
    if not blob or blob.startswith("plugin://"):
        return ""
    k = math.ceil(len(blob) / 4)
    b64 = (blob[k:] + blob[:k])[::-1]
    b64 += "=" * (-len(b64) % 4)
    try:
        text = base64.b64decode(b64).decode("utf-8", "replace")
    except ValueError:
        return ""
    m = re.search(r'"action": \'?([^\',}]+)', text)
    return m.group(1) if m else ""


def classify(files):
    """listado de Files.GetDirectory -> (carpetas que se pueden explorar [{label, file}], nº de títulos).
    Títulos = películas, series o episodios (lo que pintaría una fila). Fuera: cabeceras ("…:"), "Más…",
    búsquedas, ajustes y similares (abrirían el teclado o un diálogo de Palantir)."""
    folders, titles = [], 0
    for f in files:
        lab = clean_label(f.get("label"))
        typ = f.get("type") or "unknown"
        if not lab or lab.endswith(":"):
            continue
        if typ in ("movie", "tvshow", "episode", "season") or f.get("filetype") == "file":
            titles += 1
            continue
        if MORE_RE.match(lab) or SKIP_RE.search(lab) or SKIP_RE.search(action_of(f.get("file"))):
            continue
        folders.append({"label": lab, "file": f.get("file", "")})
    return folders, titles
