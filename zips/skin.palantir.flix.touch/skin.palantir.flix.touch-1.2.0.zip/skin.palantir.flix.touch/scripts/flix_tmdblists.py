"""Filas del Inicio con listas de TMDB (tendencias, populares, por plataforma en España, por género…) hechas de títulos de Palantir.

La fila se guarda con una ruta propia, flix://tmdb/<lista> (editor del Inicio: «Añadir fila» → «Listas de TMDB»).
Al pedirla (flix_rows.fetch, flix_home.live de la táctil) directory() la convierte en un listado de Palantir: su base
de contenido (script.module/settings.xml, SQLite) tiene la columna tmdb en pelis y series y sus rutas son consultas
SQL, así que se fabrica «estos tmdb, en el orden de TMDB» sobre las vistas generales v_pelis / v_series (todas las
categorías, solo lo que tiene enlaces). Lo que Palantir no tiene no sale (estrenos aún en cines, p. ej.).

Caché por aparato (tmdblists.json en addon_data de la skin): 6 h; error de red 10 min. Carlos, 23-oct."""
import json
import os
import re
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import TMDB_KEY, encode_route  # noqa: E402

PREFIX = "flix://tmdb/"
API = "https://api.themoviedb.org/3/"
TTL = 6 * 3600
ERR_TTL = 600
PAGES = 3                   # 60 títulos de TMDB: Palantir suele tener la mitad o más
TIMEOUT = 8
PROVIDERS = (("netflix", "Netflix", "8"), ("prime", "Prime Video", "119"), ("disney", "Disney+", "337"),
             ("max", "HBO Max", "1899"), ("apple", "Apple TV+", "350"), ("movistar", "Movistar Plus+", "2241|149"),
             ("skyshowtime", "SkyShowtime", "1773"), ("filmin", "Filmin", "63"))

# clave: (nombre en el editor, movie|tv, endpoint, parámetros extra)
LISTS = [
    ("tendencias-series-semana", "Tendencias de la semana · Series", "tv", "trending/tv/week", {}),
    ("tendencias-pelis-semana", "Tendencias de la semana · Películas", "movie", "trending/movie/week", {}),
    ("tendencias-series-hoy", "Tendencias de hoy · Series", "tv", "trending/tv/day", {}),
    ("tendencias-pelis-hoy", "Tendencias de hoy · Películas", "movie", "trending/movie/day", {}),
    ("populares-series", "Populares · Series", "tv", "tv/popular", {"region": "ES"}),
    ("populares-pelis", "Populares · Películas", "movie", "movie/popular", {"region": "ES"}),
    ("valoradas-series", "Mejor valoradas · Series", "tv", "tv/top_rated", {}),
    ("valoradas-pelis", "Mejor valoradas · Películas", "movie", "movie/top_rated", {}),
    ("emision-series", "Series en emisión", "tv", "tv/on_the_air", {}),
    ("cines-pelis", "En cines ahora", "movie", "movie/now_playing", {"region": "ES"}),
] + [
    ("%s-%s" % (key, k), "Populares en %s · %s" % (name, lab), kind, "discover/" + kind,
     {"watch_region": "ES", "with_watch_providers": pid, "sort_by": "popularity.desc"})
    for key, name, pid in PROVIDERS for k, lab, kind in (("series", "Series", "tv"), ("pelis", "Películas", "movie"))
]
# géneros de TMDB (ids de /genre/movie/list y /genre/tv/list; las series no tienen Suspense ni Terror). Populares
# del género con un mínimo de votos: sin él salían títulos desconocidos que Palantir no tiene (Carlos, 23-oct)
GENRES = {
    "movie": (("accion", "Acción", "28"), ("aventura", "Aventura", "12"), ("animacion", "Animación", "16"),
              ("comedia", "Comedia", "35"), ("crimen", "Crimen", "80"), ("documental", "Documental", "99"),
              ("drama", "Drama", "18"), ("familia", "Familia", "10751"), ("fantasia", "Fantasía", "14"),
              ("historia", "Historia", "36"), ("terror", "Terror", "27"), ("musica", "Música", "10402"),
              ("misterio", "Misterio", "9648"), ("romance", "Romance", "10749"),
              ("ciencia-ficcion", "Ciencia ficción", "878"), ("suspense", "Suspense", "53"),
              ("belica", "Bélica", "10752"), ("western", "Western", "37")),
    "tv": (("accion", "Acción y aventura", "10759"), ("animacion", "Animación", "16"), ("comedia", "Comedia", "35"),
           ("crimen", "Crimen", "80"), ("documental", "Documental", "99"), ("drama", "Drama", "18"),
           ("familia", "Familia", "10751"), ("infantil", "Infantil", "10762"), ("misterio", "Misterio", "9648"),
           ("ciencia-ficcion", "Ciencia ficción y fantasía", "10765"), ("belica", "Bélica y política", "10768"),
           ("western", "Western", "37")),       # Reality fuera: Palantir apenas tiene (6 de 60, 23-oct)
}
MIN_VOTES = {"movie": "200", "tv": "50"}
GENRE_LISTS = [
    ("genero-%s-%s" % (k, slug), "%s · %s" % (name, lab), kind, "discover/" + kind,
     {"with_genres": gid, "sort_by": "popularity.desc", "vote_count.gte": MIN_VOTES[kind]})
    for k, lab, kind in (("pelis", "Películas", "movie"), ("series", "Series", "tv")) for slug, name, gid in GENRES[kind]
]
LISTS += GENRE_LISTS
# Niños y adolescentes (Carlos, 30-oct; catálogo de Palantir comprobado: de 60, entre 39 y 60 en todas). Edad en
# España: niños «A»/7; adolescentes 12, sin terror, thriller ni crimen. Las series infantiles, con el género Infantil
_KIDS_M = {"certification_country": "ES", "certification.lte": "7", "sort_by": "popularity.desc"}
_TEEN_M = {"certification_country": "ES", "certification": "12", "without_genres": "27,53,80",
           "sort_by": "popularity.desc"}
_KIDS_T = {"with_genres": "10762", "sort_by": "popularity.desc"}
_TEEN_T = {"certification_country": "ES", "certification": "12", "without_genres": "10762,80",
           "sort_by": "popularity.desc"}
_FAM = "16|10751"                                                     # animación o familia
_NEW = {"primary_release_date.gte": "%d-01-01" % (int(time.strftime("%Y")) - 2)}
_ES = {"watch_region": "ES"}


def _m(base, **kw):
    out = dict(base)
    out.update(kw)
    return out


KIDS_LISTS = [
    ("ninos-pelis-populares", "Niños · Películas populares", "movie", "discover/movie", _m(_KIDS_M, with_genres=_FAM)),
    ("ninos-pelis-valoradas", "Niños · Películas mejor valoradas", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, sort_by="vote_average.desc", **{"vote_count.gte": "500"})),
    ("ninos-pelis-novedades", "Niños · Películas nuevas", "movie", "discover/movie", _m(_KIDS_M, with_genres=_FAM, **_NEW)),
    ("ninos-pelis-clasicos", "Niños · Clásicos", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, **{"primary_release_date.lte": "2004-12-31", "vote_count.gte": "300"})),
    ("ninos-pelis-animacion", "Niños · Películas de animación", "movie", "discover/movie", _m(_KIDS_M, with_genres="16")),
    ("ninos-pelis-aventura", "Niños · Aventuras en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="12,10751")),
    ("ninos-pelis-comedia", "Niños · Comedias en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="35,10751")),
    ("ninos-pelis-fantasia", "Niños · Fantasía en familia", "movie", "discover/movie", _m(_KIDS_M, with_genres="14,10751")),
    ("ninos-pelis-disney", "Niños · Películas en Disney+", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="337", **_ES)),
    ("ninos-pelis-netflix", "Niños · Películas en Netflix", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="8", **_ES)),
    ("ninos-pelis-prime", "Niños · Películas en Prime Video", "movie", "discover/movie",
     _m(_KIDS_M, with_genres=_FAM, with_watch_providers="119", **_ES)),
    ("ninos-series-populares", "Niños · Series populares", "tv", "discover/tv", _m(_KIDS_T)),
    ("ninos-series-valoradas", "Niños · Series mejor valoradas", "tv", "discover/tv",
     _m(_KIDS_T, sort_by="vote_average.desc", **{"vote_count.gte": "50"})),
    ("ninos-series-animacion", "Niños · Series de animación", "tv", "discover/tv", _m(_KIDS_T, with_genres="10762,16")),
    ("ninos-series-disney", "Niños · Series en Disney+", "tv", "discover/tv", _m(_KIDS_T, with_watch_providers="337", **_ES)),
    ("ninos-series-netflix", "Niños · Series en Netflix", "tv", "discover/tv", _m(_KIDS_T, with_watch_providers="8", **_ES)),
    ("ninos-anime", "Niños · Anime", "tv", "discover/tv",
     {"with_genres": "16", "with_origin_country": "JP", "certification_country": "ES", "certification.lte": "7",
      "sort_by": "popularity.desc"}),
]
TEEN_LISTS = [
    ("teen-pelis-populares", "Adolescentes · Películas populares", "movie", "discover/movie", _m(_TEEN_M)),
    ("teen-pelis-valoradas", "Adolescentes · Películas mejor valoradas", "movie", "discover/movie",
     _m(_TEEN_M, sort_by="vote_average.desc", **{"vote_count.gte": "1000"})),
    ("teen-pelis-novedades", "Adolescentes · Películas nuevas", "movie", "discover/movie", _m(_TEEN_M, **_NEW)),
    ("teen-pelis-accion", "Adolescentes · Acción y aventura", "movie", "discover/movie", _m(_TEEN_M, with_genres="28|12")),
    ("teen-pelis-scifi", "Adolescentes · Ciencia ficción y fantasía", "movie", "discover/movie",
     _m(_TEEN_M, with_genres="878|14")),
    ("teen-pelis-comedia", "Adolescentes · Comedias", "movie", "discover/movie", _m(_TEEN_M, with_genres="35")),
    ("teen-pelis-netflix", "Adolescentes · Películas en Netflix", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="8", **_ES)),
    ("teen-pelis-disney", "Adolescentes · Películas en Disney+", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="337", **_ES)),
    ("teen-pelis-prime", "Adolescentes · Películas en Prime Video", "movie", "discover/movie",
     _m(_TEEN_M, with_watch_providers="119", **_ES)),
    ("teen-pelis-anime", "Adolescentes · Películas anime", "movie", "discover/movie",
     _m(_TEEN_M, with_genres="16", with_origin_country="JP")),
    ("teen-series-populares", "Adolescentes · Series populares", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10759|10765|16|35")),
    ("teen-series-scifi", "Adolescentes · Series de ciencia ficción y fantasía", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10765")),
    ("teen-series-comedia", "Adolescentes · Series de comedia", "tv", "discover/tv", _m(_TEEN_T, with_genres="35")),
    ("teen-series-accion", "Adolescentes · Series de acción y aventura", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="10759")),
    ("teen-series-anime", "Adolescentes · Series anime", "tv", "discover/tv",
     _m(_TEEN_T, with_genres="16", with_origin_country="JP")),
]
LISTS += KIDS_LISTS + TEEN_LISTS
BY_KEY = {k: (label, kind, ep, extra) for k, label, kind, ep, extra in LISTS}
# apartados del editor («Añadir fila» → «Listas de TMDB…» → apartado → lista)
GROUPS = [
    ("Tendencias y populares", [x[0] for x in LISTS[:10]]),
    ("Por plataforma", [x[0] for x in LISTS[10:10 + 2 * len(PROVIDERS)]]),
    ("Por género · Películas", [x[0] for x in GENRE_LISTS if x[2] == "movie"]),
    ("Por género · Series", [x[0] for x in GENRE_LISTS if x[2] == "tv"]),
    ("Niños", [x[0] for x in KIDS_LISTS]),
    ("Adolescentes", [x[0] for x in TEEN_LISTS]),
]

VIEWS = {   # columnas tal cual las piden las rutas de búsqueda de Palantir (flix_search.direct_route)
    "movie": ("listado_peliculaS", "movies", "v_pelis",
              "titulo,fecha,plot,poster,fondo,audio,calidad,tmdb,duration,mpaa,genero, trailer, clearlogo, rating, categoria"),
    "tv": ("listado_serieS", "tvshows", "v_series",
           "titulo,fecha,plot,poster,fondo,tmdb,audio,mpaa,genero, trailer, clearlogo, rating, categoria"),
}


def log(msg):
    try:
        import xbmc
        xbmc.log("[flix_tmdblists] %s" % msg, xbmc.LOGINFO)
    except ImportError:
        pass


def is_list(path):
    return str(path or "").startswith(PREFIX)


def key_of(path):
    """clave de la lista de una ruta flix://tmdb/<clave>[&reload=…]; '' si no es una"""
    if not is_list(path):
        return ""
    return re.split(r"[&?]", path[len(PREFIX):], maxsplit=1)[0]


def path_of(key):
    return PREFIX + key


def label_of(path):
    return BY_KEY.get(key_of(path), ("",))[0]


def route(kind, tmdb_ids, label=""):
    """ruta de Palantir con esos títulos, en ese orden (solo los que tenga en su base); '' sin ids"""
    ids = [int(i) for i in tmdb_ids if str(i).isdigit()]
    if not ids or kind not in VIEWS:
        return ""
    action, content, view, cols = VIEWS[kind]
    order = " ".join("WHEN %d THEN %d" % (t, n) for n, t in enumerate(ids))
    sql = "SELECT %s FROM %s WHERE tmdb IN (%s) ORDER BY CASE tmdb %s END;" % (
        cols, view, ",".join(str(i) for i in ids), order)
    label = label.replace("'", " ")
    return encode_route('{"action": \'%s\', "content": \'%s\', "fanart": \'\', "icon": \'\', "label": \'%s\', '
                        '"limitItemList": 53, "page": 0, "plot": \'\', "sql": "%s"}' % (action, content, label, sql))


def fetch_ids(key, opener=None):
    """ids de TMDB de la lista (PAGES páginas). Excepción = red."""
    import urllib.request
    opener = opener or urllib.request.urlopen
    label, kind, ep, extra = BY_KEY[key]
    out = []
    for page in range(1, PAGES + 1):
        q = dict(extra, api_key=TMDB_KEY, language="es-ES", page=page)
        req = urllib.request.Request(API + ep + "?" + urllib.parse.urlencode(q),
                                     headers={"User-Agent": "Ker0n3Media-skin"})
        with opener(req, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
        out += [x["id"] for x in data.get("results") or [] if x.get("id") and x["id"] not in out]
        if page >= (data.get("total_pages") or 1):
            break
    return out


def cache_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/tmdblists.json" % xbmc.getSkinDir())


def _load(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def ids_of(key, path=None, opener=None, now=time.time):
    """ids de la lista con caché (TTL; si TMDB no responde, lo último que hubo y se reintenta en ERR_TTL)"""
    path = path or cache_path()
    d, t = _load(path), now()
    hit = d.get(key)
    if isinstance(hit, list) and len(hit) == 3:
        ts, ids, ok = hit
        if t - ts < (TTL if ok else ERR_TTL):
            return ids
    else:
        ids = []
    try:
        ids, ok = fetch_ids(key, opener), True
    except Exception as e:  # noqa: BLE001
        log("TMDB no responde (%s): %s" % (key, e))
        ok = False
    mine = {key: [t, ids, ok]}
    try:
        # con cerrojo y mezclando con el fichero: otro proceso (el Inicio, la táctil, las filas al azar) puede haber
        # guardado otra lista desde que se leyó (revisión 29-oct DAT-14)
        import flix_cache
        flix_cache.update_json(path, lambda disk: flix_cache.merge_newer(disk, mine, [key]))
    except OSError as e:
        log("no guardo la caché: %s" % e)
    return ids


def content_db():
    """base de contenido de Palantir (SQLite aunque se llame settings.xml)"""
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/script.module/settings.xml")


def palantir_busy(db=None):
    """¿Palantir está con su sincronización de arranque (flix_p3sync) o a mitad de instalar su contenido nuevo (la
    base sin sus vistas)? Entonces no se le lee la base ni se le piden listas: el 28-oct (móvil) su actualización se
    quedó 3 min parada con la skin leyendo la base a la vez y siguió al descargar la skin. Sin base: no está ocupado
    (decide Palantir, como siempre)"""
    import sqlite3
    import xbmcgui
    if xbmcgui.Window(10000).getProperty("flix_p3sync_busy"):
        return True
    db = db or content_db()
    if not os.path.exists(db):
        return False
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=2)
        try:
            return not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'view' AND name = 'v_pelis'").fetchone()
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("base de Palantir ocupada: %s" % e)
        return True


def present(kind, ids, db):
    """los ids que Palantir tiene (con enlaces: sus vistas v_pelis / v_series), en el mismo orden; None si no se puede
    leer la base (entonces no se filtra y decide Palantir)"""
    import sqlite3
    if not ids or not os.path.exists(db):
        return None if not os.path.exists(db) else []
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=5)
        try:
            have = {int(r[0]) for r in con.execute("SELECT tmdb FROM %s WHERE tmdb IN (%s)" % (
                VIEWS[kind][2], ",".join(str(int(i)) for i in ids)))}
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        log("no leo la base de Palantir: %s" % e)
        return None
    return [i for i in ids if int(i) in have]


def cached_ids(key, path=None):
    """ids guardados de la lista, aunque estén caducados; [] si no hay. Sin red"""
    hit = _load(path or cache_path()).get(key)
    return hit[1] if isinstance(hit, list) and len(hit) == 3 and isinstance(hit[1], list) else []


def directory(path, cache=None, opener=None, now=time.time, db=None, offline=False):
    """ruta que hay que pedir a Kodi: la de Palantir si es una lista de TMDB (o '' si no hay títulos); si no, tal cual.
    Solo con lo que Palantir tiene: si no tiene ninguno, '' y no se le pregunta (si no, saca «No se han encontrado
    resultados para su búsqueda», Shield 24-oct: «En cines ahora» en la precarga de las filas al azar).
    offline: para el menú KER0N3 (flix_ctx_src, dentro de onAction): los ids guardados aunque estén caducados, sin
    pedir nada a TMDB ni leer la base de Palantir (puede estar ocupada). La ruta da los mismos títulos: Palantir solo
    devuelve los que tiene, en el orden de TMDB (revisión 29-oct DAT-16)"""
    key = key_of(path)
    if not key:
        return path
    if key not in BY_KEY:
        log("lista desconocida: %s" % key)
        return ""
    label, kind = BY_KEY[key][:2]
    if offline:
        return route(kind, cached_ids(key, cache), label)
    ids = ids_of(key, cache, opener, now)
    have = present(kind, ids, db or content_db())
    if have is not None:
        if not have and ids:
            log("%s: Palantir no tiene ninguno de los %d títulos" % (key, len(ids)))
        ids = have
    return route(kind, ids, label)
