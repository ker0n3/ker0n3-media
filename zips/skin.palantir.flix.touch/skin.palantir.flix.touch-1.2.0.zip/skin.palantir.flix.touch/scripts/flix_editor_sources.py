"""Editor único: fuentes de cada nivel (Ajustes → «Personalizar menú e Inicio» y «Nota de los títulos»).
Todas con el mismo contrato, que usa flix_editor.py:
  title() · help(touch) · load() -> elementos (flix_editor_core.item) · save(elementos) (al momento)
  count(elementos, touch) · buttons(elementos, touch) -> [(acción, texto)]
  press(acción, elementos, k, ui) -> (elementos, posición) o None · check_toggle(elementos, k, ui) -> bool
  child(elemento) -> fuente o None · reset() -> elementos · decorate(elementos) · on_exit()
Lo que toca Kodi va en los *Store (en tests, falsos); ui = diálogos (notify, confirm, pick, browse, ask_key, busy)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_editor_core as core  # noqa: E402
import flix_home_conf as hc  # noqa: E402
import flix_sections  # noqa: E402
import flix_sections_conf as sc  # noqa: E402

NO_ANSWER = flix_sections.NO_ANSWER
NO_ROWS = "Palantir no ha dado filas para esta sección ahora"
EXPLORE = "Explorar Palantir…"
TMDB_LISTS = "Listas de TMDB…"      # tendencias, populares, por plataforma, por género (flix_tmdblists.py)
INICIO_ICON = "flix/icons/inicio.png"
SHUFFLE_ICON = "flix/icons/shuffle.png"        # «Inicio» → Aleatoria
CUSTOM_ICON = "flix/icons/sliders-horizontal.png"  # «Inicio» → Personalizada
MOVING_HELP = "Arriba / abajo: mover · OK: soltar"


def plural(n, one, many):
    """«1 fija» / «4 fijas» (TV-27: concordancia con el número)"""
    return "%d %s" % (n, one if n == 1 else many)


class Source:
    toggle_labels = ("Ocultar", "Mostrar")
    remove_label = "Quitar"
    can_rename = False
    HELP = ("", "")          # (TV, táctil)

    def help(self, touch):
        return self.HELP[1 if touch else 0]

    def decorate(self, items):
        return items

    def check_toggle(self, items, k, ui):
        return True

    def child(self, it):
        return None

    def press(self, action, items, k, ui):
        return None

    def on_exit(self):
        pass

    def relist(self, it):
        """True si al cambiar el interruptor de it hay que volver a cargar la lista (cambian las filas que hay)"""
        return False

    def rename(self, items, k, new):
        """nombre que se ve; vacío = el de Palantir (orig)"""
        items[k]["label"] = new or items[k]["orig"]
        return items


# ---------- menú (sections.json) ----------
class SectionsStore:
    """sections.json, el menú y Palantir (lo que toca Kodi de las secciones)"""

    def load(self):
        return flix_sections.load_conf()

    def save(self, conf):
        flix_sections.save_conf(conf)

    def apply(self, conf):
        flix_sections.apply(conf)

    def menu(self, path):
        return flix_sections.palantir_menu(path)

    def section_rows(self, src):
        import flix_rows
        return flix_rows.section_rows(src, stale_ok=True)


class MenuSource(Source):
    level = "menu"
    can_rename = True
    HELP = ("OK: opciones de la sección (editar filas, mover, cambiar nombre, ocultar, quitar) · Atrás: salir[CR]"
            "Inicio va siempre primero: OK en Inicio abre sus filas.",
            "Las flechas ordenan, el interruptor enseña u oculta, «Filas» elige qué sale dentro y tocar el nombre lo cambia. "
            "En el móvil se ven las 7 primeras activas.")

    def __init__(self, store=None):
        self.store = store or SectionsStore()
        self._home, self.deleted = None, []

    def title(self):
        return "Personalizar menú e Inicio"

    def items_of(self, conf):
        out = [core.item("inicio", "Inicio", icon=INICIO_ICON, fixed=True, kids=True)]
        self.deleted = [s for s in conf["sections"] if s.get("deleted")]     # de serie eliminadas: no se enseñan
        for s in conf["sections"]:
            if s.get("deleted"):
                continue
            added = s["key"].startswith("p3:")
            notes = (("sin especial ahora", bool(s.get("gone"))), ("añadida", added), ("rejilla", s["kind"] == "list"))
            note = " · ".join(x for x, c in notes if c)
            out.append(core.item(s["key"], sc.shown(s), on=s["on"], icon=s.get("icon", ""), removable=True,
                                 kids=s["kind"] == "rows", note=note, raw=s, orig=s["label"]))
        return out

    def load(self):
        return self.items_of(self.store.load())

    def conf_of(self, items):
        out = []
        for it in items:
            if it["fixed"]:
                continue
            s = {k: v for k, v in it["raw"].items() if k not in ("name", "name_for")}
            s["on"] = it["on"]
            if it["label"] != it["orig"]:
                s.update(name=it["label"], name_for=it["orig"])
            s.pop("deleted", None)
            out.append(s)
        present = {s["key"] for s in out}
        out += [dict(s, deleted=True, on=False) for s in self.deleted if s["key"] not in present]
        return {"sections": out}

    def save(self, items):
        conf = self.conf_of(items)
        self.store.save(conf)
        self.store.apply(conf)

    def count(self, items, touch):
        return flix_sections.count_text(len(sc.active(self.conf_of(items))), touch)    # sin las «Especial» escondidas

    def buttons(self, items, touch):
        return [("add", "Añadir sección"), ("reset", "Restablecer")]

    def check_toggle(self, items, k, ui):
        if not items[k]["on"] and core.active_count(items) >= sc.MAX_SECTIONS:
            ui.notify("Caben %d secciones: desactiva otra antes" % sc.MAX_SECTIONS)
            return False
        return True

    def child(self, it):
        if it["id"] == "inicio":
            self._home = self._home or InicioModeSource()    # una sola: al salir, una sola recarga del Inicio
            return self._home
        if it["kids"]:
            return SectionRowsSource(it["id"], it["label"], it["raw"]["src"], self.store)
        return None

    def reset(self):
        return self.items_of(sc.default_conf(set()))

    def press(self, action, items, k, ui):
        if action == "add":
            return self.add(items, k, ui)
        if action == "remove":
            it = items[k]
            if not it["removable"] or not ui.confirm(
                    "¿Quitar «%s» del menú?[CR]Podrás volver a añadirla con «Añadir sección»." % it["label"]):
                return None
            if not it["id"].startswith("p3:"):      # de serie: se recuerda como eliminada (si no, volvería apagada)
                self.deleted = [s for s in self.deleted if s["key"] != it["id"]] + [it["raw"]]
            del items[k]
            return items, min(k, len(items) - 1)
        return None

    def add(self, items, k, ui):
        if core.active_count(items) >= sc.MAX_SECTIONS:
            ui.notify("Caben %d secciones: desactiva otra antes" % sc.MAX_SECTIONS)
            return None
        gone = list(self.deleted)               # de serie eliminadas: primero, se recuperan tal cual
        folders, _ = hc.classify(self.store.menu(flix_sections.PALANTIR_ROOT))
        if not folders and not gone:
            ui.notify(NO_ANSWER)
            return None
        cands = sc.candidates(self.conf_of(items), [{"label": f["label"], "path": f["file"]} for f in folders])
        if not cands and not gone:
            ui.notify("Ya están todas las secciones de Palantir")
            return None
        c = ui.pick("Añadir sección", [sc.shown(s) for s in gone] + [x["label"] for x in cands],
                    "Secciones que quitaste y entradas del menú principal de Palantir")
        if c < 0:
            return None
        at = max(k, 0) + 1
        if c < len(gone):
            s = dict(gone[c], on=True)
            s.pop("deleted", None)
            self.deleted = [d for d in self.deleted if d["key"] != s["key"]]
            items[at:at] = self.items_of({"sections": [s]})[1:]
            self.deleted = [d for d in gone if d["key"] != s["key"]]      # items_of lo ha vaciado
            ui.notify("«%s» añadida" % sc.shown(s))
            return items, at
        c -= len(gone)
        kind = flix_sections.kind_of(self.store.menu(cands[c]["path"]))
        if kind is None:
            ui.notify(NO_ANSWER)
            return None
        new = sc.new_section(cands[c]["label"], cands[c]["path"], kind)
        keep = self.deleted
        items[at:at] = self.items_of({"sections": [new]})[1:]
        self.deleted = keep
        ui.notify("«%s» añadida%s" % (new["label"], " (rejilla de títulos)" if kind == "list" else ""))
        return items, at


# ---------- filas de una sección (sections.json, "rows") ----------
class SectionRowsSource(Source):
    level = "rows"
    can_rename = True
    HELP = ("Filas que salen al abrir la sección, en este orden.[CR]OK: mover, cambiar nombre, ocultar o eliminar · Atrás: volver al menú",
            "Filas que salen al abrir la sección, en este orden. Las flechas ordenan, el interruptor enseña u oculta, tocar el nombre lo cambia y la papelera la quita.")

    def __init__(self, key, label, src, store):
        self.key, self.label, self.src, self.store = key, label, src, store
        self.labels = []

    def title(self):
        return "Filas de %s" % self.label

    remove_label = "Eliminar"

    def load(self):
        rows = self.store.section_rows(self.src)
        if not rows:
            # Palantir no responde: con solo las añadidas, al guardar se perdían el orden, las ocultas, los nombres y las
            # eliminadas de las de Palantir (auditoría 24-oct). Sin filas = el editor avisa y no abre el nivel
            self.labels = []
            return []
        self.labels = [r["label"] for r in rows]
        sec = flix_sections.section(self.key, self.store.load()) or {"rows": {}}
        names = (sec.get("rows") or {}).get("names") or {}
        # las de Palantir quitadas no cuentan como nombre ocupado: una añadida con su nombre no se pierde
        live = set(self.labels) - set(sec["rows"].get("deleted") or [])
        custom = {c["label"]: c["path"] for c in sc.custom_rows(sec["rows"], live)}
        return [self.row_item(l, names.get(l, l), on, custom.get(l)) for l, on in sc.row_editor_items(rows, sec["rows"])]

    @staticmethod
    def row_item(label, shown, on=True, path=None):
        """fila del editor; path = fila añadida (lista de TMDB o menú de Palantir)"""
        return core.item(label, shown, on=on, orig=label, removable=True,
                         note="añadida" if path is not None else "", raw={"custom": path is not None, "path": path or ""})

    def save(self, items):
        conf = self.store.load()
        for s in conf["sections"]:
            if s["key"] == self.key:
                s["rows"] = flix_sections.rows_conf([(it["id"], it["on"]) for it in items])
                names = {it["id"]: it["label"] for it in items if it["label"] != it["orig"]}
                if names:
                    s["rows"]["names"] = names
                custom = [{"label": it["id"], "path": it["raw"]["path"]} for it in items if it["raw"]["custom"]]
                if custom:
                    s["rows"]["custom"] = custom
                present = {it["id"] for it in items if not it["raw"]["custom"]}
                deleted = [l for l in self.labels if l not in present]
                if deleted:
                    s["rows"]["deleted"] = deleted
        self.store.save(conf)

    def press(self, action, items, k, ui):
        if action == "remove":
            if len(items) == 1:
                ui.notify("Tiene que quedar al menos una fila")
                return None
            if not ui.confirm("¿Quitar «%s» de la sección?[CR]Podrás volver a añadirla con «Añadir fila»." % items[k]["label"]):
                return None
            del items[k]
            return items, min(k, len(items) - 1)
        if action != "add":
            return None
        if len(items) >= sc.MAX_SECTION_ROWS:
            ui.notify("Caben %d filas: quita u oculta alguna antes" % sc.MAX_SECTION_ROWS)
            return None
        present = {it["id"] for it in items}
        missing = [l for l in self.labels if l not in present]      # de Palantir, eliminadas antes
        c = ui.pick("Añadir fila", missing + [TMDB_LISTS, EXPLORE],
                    "Filas de la sección que quitaste, listas de TMDB (tendencias, populares, por plataforma, por "
                    "género) hechas con lo que tiene Palantir, o cualquier menú de Palantir.")
        if c < 0:
            return None
        at = max(k, 0) + 1
        if c < len(missing):
            items.insert(at, self.row_item(missing[c], missing[c]))
            ui.notify("«%s» añadida" % missing[c])
            return items, at
        got = HomeRowsSource.pick_tmdb(items, ui) if c == len(missing) else ui.browse()
        if not got:
            return None
        if got[0] in present or got[0] in self.labels:
            ui.notify("Ya hay una fila «%s» en la sección" % got[0])
            return None
        items.insert(at, self.row_item(got[0], got[0], path=got[1]))
        ui.notify("«%s» añadida" % got[0])
        return items, at

    def count(self, items, touch):
        return "%d de %d %s" % (core.active_count(items), len(items), "fila" if len(items) == 1 else "filas")

    def buttons(self, items, touch):
        return [("add", "Añadir fila"), ("reset", "Restablecer")]

    def reset(self):
        return [self.row_item(l, l) for l in self.labels]


# ---------- filas del Inicio (home_order.json) ----------
class HomeStore:
    """home_order.json y el Inicio (lo que toca Kodi de las filas del Inicio)"""

    def defaults(self):
        import flix_home_order
        return flix_home_order.default_rows()

    def load(self):
        import flix_home_order
        return flix_home_order.load_conf() or hc.normalize(None)

    def save(self, conf):
        import flix_home_order
        flix_home_order.save_conf(conf)

    def apply(self):
        import flix_home_order
        flix_home_order.apply_saved()

    def prepare(self):
        """Filas al azar cambiadas: el sorteo preparado ya no vale; preparar otro por detrás"""
        import flix_random_rows as rr
        path = rr.state_path()
        st = rr.load_state(path)
        st.update(next=[], ready=False)
        rr.save_state(path, st)
        rr.request_prepare()


class HomeRowsSource(Source):
    """«Inicio» → «Personalizada»: las filas del Inicio a mano (se guardan aunque esté en uso «Aleatoria»)"""
    level = "home"
    can_rename = True
    remove_label = "Eliminar"
    HELP = ("OK: opciones de la fila (mover, cambiar nombre, ocultar, eliminar) · Atrás: volver",
            "Las flechas ordenan, el interruptor enseña u oculta, tocar el nombre lo cambia y la papelera la quita.")

    def __init__(self, store=None):
        self.store = store or HomeStore()
        self.defaults, self.items_n, self.initial = [], hc.DEFAULT_ITEMS, None

    def title(self):
        return "Inicio personalizado"

    def items_of(self, conf):
        self.items_n = conf["items"]
        return [core.item(r["id"], r.get("title") or r["label"], on=not r["hidden"], removable=True,
                          note="añadida" if r["custom"] else "", raw=r, orig=r["label"])
                for r in hc.compose(self.defaults, manual(conf))]

    def load(self):
        self.defaults = self.store.defaults()
        conf = self.store.load()
        if self.initial is None:
            self.initial = hc.signature(conf)               # al salir: recargar el Inicio solo si cambió
        return self.items_of(conf)

    def conf_of(self, items):
        present = {it["id"] for it in items}
        out = {
            "order": [it["id"] for it in items],
            "hidden": [it["id"] for it in items if not it["on"]],
            "deleted": [d["id"] for d in self.defaults if d["id"] not in present],
            "custom": [{"id": it["id"], "label": it["orig"], "path": it["raw"]["path"]}
                       for it in items if it["raw"]["custom"]],
            "names": {str(it["id"]): it["label"] for it in items if it["label"] != it["orig"]},
            "items": self.items_n,
        }
        saved = self.store.load()
        if "random" in saved:
            out["random"] = saved["random"]     # el modo y los ajustes de «Aleatoria» no se tocan desde aquí
            present = {str(it["id"]) for it in items}
            fixed = {k: v for k, v in (saved.get("names") or {}).items()
                     if int(k) in hc.FIXED_ROWS and k not in present}     # las de la lista: manda la lista
            out["names"] = dict(fixed, **out["names"])
        return hc.normalize(out)

    def save(self, items):
        self.store.save(self.conf_of(items))

    def count(self, items, touch):
        return "%d de %d filas" % (len(items), hc.MAX_ROWS)

    def buttons(self, items, touch):
        return [("add", "Añadir fila"), ("items", "Títulos por fila: %d" % self.items_n), ("reset", "Restablecer")]

    def visible(self, items):
        return len([it for it in items if it["on"]])

    def check_toggle(self, items, k, ui):
        if items[k]["on"] and self.visible(items) == 1:
            ui.notify("Tiene que quedar al menos una fila visible")
            return False
        return True

    def reset(self):
        return self.items_of(hc.normalize(None))

    def press(self, action, items, k, ui):
        if action == "items":
            self.items_n = hc.next_items(self.items_n)
            return items, k
        if action == "remove":
            it = items[k]
            if it["on"] and self.visible(items) == 1:
                ui.notify("Tiene que quedar al menos una fila visible")
                return None
            if not ui.confirm("¿Quitar «%s» del Inicio?[CR]Podrás volver a añadirla con «Añadir fila»." % it["label"]):
                return None
            del items[k]
            return items, min(k, len(items) - 1)
        if action == "add":
            return self.add(items, k, ui)
        return None

    def add(self, items, k, ui):
        if len(items) >= hc.MAX_ROWS:
            ui.notify("Máximo %d filas: elimina alguna para añadir otra" % hc.MAX_ROWS)
            return None
        present = {it["id"] for it in items}
        missing = [d for d in self.defaults if d["id"] not in present]
        c = ui.pick("Añadir fila", [d["label"] for d in missing] + [TMDB_LISTS, EXPLORE],
                    "Filas de serie que no están en el Inicio, listas de TMDB (tendencias, populares, por "
                    "plataforma, por género) hechas con lo que tiene Palantir, o cualquier menú de Palantir.")
        if c < 0:
            return None
        if c < len(missing):
            raw = dict(missing[c], custom=False, hidden=False)
        else:
            if c == len(missing):
                got = self.pick_tmdb(items, ui)
            else:
                got = ui.browse()
            if not got:
                return None
            used = {it["id"] for it in items if it["raw"]["custom"]}
            free = [i for i in hc.CUSTOM_IDS if i not in used]
            raw = {"id": free[0], "label": got[0], "path": got[1], "custom": True, "hidden": False, "top10": False}
        at = max(k, 0) + 1
        items.insert(at, core.item(raw["id"], raw["label"], removable=True,
                                   note="añadida" if raw["custom"] else "", raw=raw))
        ui.notify("«%s» añadida" % raw["label"])
        return items, at

    @staticmethod
    def pick_tmdb(items, ui):
        """(nombre, ruta flix://tmdb/…) de la lista de TMDB elegida; None si se cancela. Las ya añadidas no salen"""
        import flix_tmdblists as tl
        present = {it["raw"].get("path") for it in items if it["raw"].get("custom")}
        groups = [(name, [(tl.BY_KEY[k][0], tl.path_of(k)) for k in keys if tl.path_of(k) not in present])
                  for name, keys in tl.GROUPS]
        groups = [g for g in groups if g[1]]
        if not groups:
            ui.notify("Ya están todas las listas de TMDB")
            return None
        while True:
            g = ui.pick(TMDB_LISTS.rstrip("…"), [name for name, _ in groups],
                        "Ordenadas como en TMDB. Solo salen los títulos que tenga Palantir.")
            if g < 0:
                return None
            lists = groups[g][1]
            c = ui.pick(groups[g][0], [lab for lab, _ in lists], "Solo salen los títulos que tenga Palantir.")
            if c >= 0:
                return lists[c]             # Atrás en la lista: de vuelta a los apartados

    def on_exit(self):
        if self.initial is not None and hc.signature(self.store.load()) != self.initial:
            self.store.apply()


# ---------- filas al azar (home_order.json → random; flix_random_rows.py) ----------
class RandomSource(Source):
    """«Inicio» → «Aleatoria»: la fila «Tipo», las filas fijas (ordenar, eliminar, «Añadir fija») y, debajo, los
    apartados de listas de TMDB que entran en el sorteo (en Niños y Adolescentes, una línea «Listas: las N de …»),
    cuántas filas y «Sortear ya». La ventana solo tiene 3 botones: el «Tipo» es la primera fila de la lista"""
    level = "random"
    remove_label = "Eliminar"
    toggle_labels = ("Sacar del sorteo", "Meter en el sorteo")
    HELP = ("«Tipo»: Estándar, Niños o Adolescentes · arriba las fijas (OK: mover o eliminar); debajo, apartados de "
            "listas de TMDB que cambian al arrancar Kodi (OK: meter o sacar)",
            "Toca «Tipo» para elegir Estándar, Niños o Adolescentes. Arriba las filas fijas: las flechas ordenan y la "
            "papelera quita. Debajo, apartados de listas de TMDB que cambian cada vez que arranca Kodi.")
    HELP_EDAD = ("Arriba las fijas (OK: mover o eliminar); debajo, listas de TMDB de su edad que cambian al arrancar "
                 "Kodi · OK en «Tipo»: cambiarlo",
                 "Arriba las filas fijas: las flechas ordenan y la papelera quita. Debajo, listas de TMDB de su edad "
                 "que cambian cada vez que arranca Kodi.")
    TIPO_NAMES = {"estandar": "Estándar", "ninos": "Niños", "adolescentes": "Adolescentes"}
    TIPO_HELP = ("Estándar: Seguir viendo, Series en seguimiento, los dos Top 10 y los apartados que marques. "
                 "Niños y Adolescentes: sin Top 10 de serie y solo listas de su edad")

    def __init__(self, store, rng=None):
        self.store, self.rng, self.r, self.defaults = store, rng, hc.normalize_random(None), []

    def tipo(self):
        return self.r.get("tipo", "estandar")

    def title(self):
        return "Inicio aleatorio"

    def help(self, touch):
        return (self.HELP if self.tipo() == "estandar" else self.HELP_EDAD)[1 if touch else 0]

    def load(self):
        import flix_tmdblists as tl
        conf = self.store.load()
        self.defaults = self.store.defaults()
        self.r = hc.random_conf(conf)
        out = [core.item("tipo", "Tipo: %s" % self.TIPO_NAMES[self.tipo()], locked=True, nomove=True, norename=True,
                         note="cambiar", act="tipo", raw={"fixed": False, "kind": "tipo"})]
        out += [core.item(f["id"], f.get("title") or f["label"], removable=True, locked=True, note="fija",
                          raw={"fixed": True}, orig=f["label"]) for f in hc.fixed_rows(self.defaults, conf)]
        if self.tipo() != "estandar":           # Niños y Adolescentes: sin apartados que elegir
            name, keys = tl.GROUPS[hc.TIPO_GROUP[self.tipo()]]
            return out + [core.item("listas", "Listas: las %d de %s" % (len(keys), name), locked=True, nomove=True,
                                    norename=True, raw={"fixed": False, "kind": "info"})]
        return out + [core.item(g, name, on=g in self.r["groups"], nomove=True,
                                note=plural(len(keys), "lista", "listas"),
                                raw={"fixed": False, "kind": "grupo"}) for g, (name, keys) in enumerate(tl.GROUPS)]

    @staticmethod
    def fixed(items):
        return [it for it in items if it["raw"]["fixed"]]

    @staticmethod
    def groups(items):
        """los apartados del sorteo (ni las fijas ni las filas «Tipo» y «Listas»)"""
        return [it for it in items if it["raw"].get("kind") == "grupo"]

    def marked(self, items):
        return [it["id"] for it in self.groups(items) if it["on"]]

    def missing(self, items):
        have = {it["id"] for it in self.fixed(items)}
        return [d for d in self.defaults if d["id"] in hc.FIXED_ROWS and d["id"] not in have]

    def save(self, items):
        conf = self.store.load()
        conf["random"] = dict(self.r, order=[it["id"] for it in self.fixed(items)])
        if self.tipo() == "estandar":           # en Niños y Adolescentes los apartados de Estándar se guardan tal cual
            conf["random"]["groups"] = self.marked(items)
        self.store.save(conf)
        self.store.prepare()                # lo preparado era para los ajustes de antes

    def check_toggle(self, items, k, ui):
        if items[k]["raw"].get("kind") != "grupo":
            return False
        if items[k]["on"] and len(self.marked(items)) == 1:
            ui.notify("Tiene que quedar al menos uno")
            return False
        return True

    def count(self, items, touch):
        return "%s + %d al azar" % (plural(len(self.fixed(items)), "fija", "fijas"), self.r["n"])

    def buttons(self, items, touch):
        out = [("n", "Filas al azar: %d" % self.r["n"]), ("draw", "Sortear ya")]
        return out + [("addfixed", "Añadir fija")] if self.missing(items) else out

    def press(self, action, items, k, ui):
        import flix_random_rows as rr
        if action == "tipo":
            c = ui.pick("Tipo de Inicio", [self.TIPO_NAMES[t] for t in hc.TIPOS], self.TIPO_HELP)
            if c < 0 or hc.TIPOS[c] == self.tipo():
                return None
            if self.tipo() == "estandar":       # lo marcado antes de salir de Estándar
                self.r["groups"] = self.marked(items) or self.r["groups"]
            self.r["order"] = [it["id"] for it in self.fixed(items)]
            hc.set_tipo(self.r, hc.TIPOS[c])
            self.r["current"] = rr.draw(hc.draw_groups(self.r), self.r["n"], rng=self.rng)
            conf = self.store.load()
            conf["random"] = dict(self.r)
            self.store.save(conf)
            self.store.prepare()
            return self.load(), 0
        if action == "n":
            if self.tipo() == "estandar":
                groups = hc.draw_groups(dict(self.r, groups=self.marked(items)))
            else:
                groups = hc.draw_groups(self.r)
            self.r["n"] = hc.next_random_n(self.r["n"])
            if self.r["current"]:
                self.r["current"] = rr.resize(self.r["current"], groups, self.r["n"], rng=self.rng)
            return items, k
        if action == "draw":
            if not self.r["on"]:
                ui.notify("Antes elige «Aleatoria» en «Inicio»")
                return None
            ui.notify("Las filas de la próxima vez se están preparando")
            return items, k
        if action == "remove":
            if not items[k]["raw"]["fixed"]:
                return None
            if not ui.confirm("¿Quitar «%s» de las fijas?[CR]Podrás volver a ponerla con «Añadir fija»." % items[k]["label"]):
                return None
            del items[k]
            return items, min(k, len(self.fixed(items)))
        if action == "addfixed":
            missing = self.missing(items)
            c = ui.pick("Añadir fija", [d.get("title") or d["label"] for d in missing], "Filas que van siempre arriba.")
            if c < 0:
                return None
            at = 1 + len(self.fixed(items))             # al final de las fijas: debajo del «Tipo», encima de lo demás
            d = missing[c]
            items.insert(at, core.item(d["id"], d.get("title") or d["label"], removable=True, locked=True,
                                       note="fija", raw={"fixed": True}, orig=d["label"]))
            return items, at
        return None


# ---------- «Inicio»: dos modos (Carlos, 24-oct) ----------
def manual(conf):
    """la configuración sin el modo aleatorio: las filas de «Personalizada»"""
    return {k: v for k, v in conf.items() if k != "random"}


class InicioModeSource(Source):
    """Ajustes → «Personalizar menú e Inicio» → «Inicio»: Aleatoria (4 fijas + listas de TMDB al azar) o
    Personalizada (las filas a mano). Elegir = interruptor de la que no está en uso; «›» = sus ajustes."""
    level = "inicio"
    HELP = ("OK: usar este modo o ver sus ajustes · Atrás: volver al menú",
            "El interruptor elige el modo y «Filas ›» abre sus ajustes.")

    def __init__(self, store=None, rng=None):
        self.store, self.rng = store or HomeStore(), rng
        self.initial, self.conf, self.kids = None, hc.normalize(None), {}

    def title(self):
        return "Inicio"

    def load(self):
        self.defaults = self.store.defaults()
        self.conf = self.store.load()
        if self.initial is None:
            self.initial = hc.signature(self.conf)
        on, r = hc.random_on(self.conf), hc.random_conf(self.conf)
        n = len([x for x in hc.compose(self.defaults, manual(self.conf)) if not x["hidden"]])
        nfix = len(r["order"])
        mode = dict(kids=True, nomove=True, norename=True, open_label="Ajustes")
        # interruptor en las dos (Carlos, 24-oct): apagar la que está en uso = usar la otra
        return [core.item("aleatoria", "Aleatoria", on=on, icon=SHUFFLE_ICON, tlabels=("Usar Personalizada", "Usar esta"),
                          note=("En uso · " if on else "") + "%s + %d al azar" % (plural(nfix, "fija", "fijas"), r["n"]),
                          **mode),
                core.item("personalizada", "Personalizada", on=not on, icon=CUSTOM_ICON,
                          tlabels=("Usar Aleatoria", "Usar esta"),
                          note="En uso · filas a tu gusto" if not on else "Filas a tu gusto", **mode)]

    def relist(self, it):
        return True                 # se elige una: la otra deja de estar en uso

    def save(self, items):
        import flix_random_rows as rr
        prev = hc.random_on(self.conf)
        by = {it["id"]: it["on"] for it in items}
        if (by["aleatoria"], by["personalizada"]) == (prev, not prev):
            return                          # nada cambió
        on = not prev                       # se tocó cualquiera de los dos interruptores: la otra pasa a estar en uso
        conf = self.store.load()
        r = dict(hc.random_conf(conf), on=on)
        if on and not r["current"]:         # 1.ª vez: estas se cargan en directo («Cargando…»)
            r["current"] = rr.draw(hc.draw_groups(r), r["n"], rng=self.rng)
        conf["random"] = r
        self.store.save(conf)
        self.store.prepare()                # lo preparado ya no vale
        self.conf = conf

    def child(self, it):
        if it["id"] not in self.kids:
            self.kids[it["id"]] = RandomSource(self.store, self.rng) if it["id"] == "aleatoria" \
                else HomeRowsSource(self.store)
        return self.kids[it["id"]]

    def count(self, items, touch):
        return ""

    def buttons(self, items, touch):
        return []

    def on_exit(self):
        if self.initial is not None and hc.signature(self.store.load()) != self.initial:
            self.store.apply()


# ---------- prioridad de reproducción (flix_quality: Skin.String) ----------
class QualityStore:
    def load(self):
        import flix_quality
        return flix_quality.load()

    def save(self, conf):
        import flix_quality
        flix_quality.save(conf)


class QualitySource(Source):
    """Ajustes → «Prioridad de reproducción» en el editor único (Carlos, 24-oct: el diálogo viejo FlixQuality se
    había quedado con el diseño de las primeras versiones). Mismos ajustes que antes (flix_quality.load/save)."""
    level = "quality"
    toggle_labels = ("Desactivar", "Activar")
    HELP = ("Al pulsar un título se reproduce solo la primera calidad encendida que haya, en este orden.[CR]"
            "OK: mover, activar o desactivar",
            "Al pulsar un título se reproduce solo la primera calidad encendida que haya, en este orden. Las flechas "
            "ordenan y el interruptor activa o desactiva.")

    def __init__(self, store=None):
        self.store, self.conf = store or QualityStore(), None

    def title(self):
        return "Prioridad de reproducción"

    @staticmethod
    def items_of(order):
        import flix_quality as fq
        return [core.item(k, fq.LABEL[k], on=on) for k, on in order]

    def load(self):
        self.conf = self.store.load()
        return self.items_of(self.conf.order)

    def save(self, items):
        self.conf.order = [(it["id"], it["on"]) for it in items]
        self.store.save(self.conf)

    def count(self, items, touch):
        import flix_quality as fq
        if not self.conf.auto:
            return "Reproducción automática apagada"
        return fq.summary([(it["id"], it["on"]) for it in items])

    def buttons(self, items, touch):
        yes = lambda v: "Sí" if v else "No"   # noqa: E731
        return [("auto", ("Automática: %s" if touch else "Reproducción automática: %s") % yes(self.conf.auto)),
                ("remux", "Remux: %s" % yes(self.conf.remux)), ("reset", "Restablecer")]

    def press(self, action, items, k, ui):
        if action == "auto":
            self.conf.auto = not self.conf.auto
            return items, k
        if action == "remux":
            self.conf.remux = not self.conf.remux
            return items, k
        return None

    def reset(self):
        import flix_quality as fq
        self.conf.auto, self.conf.remux = True, False
        return self.items_of(fq.DEFAULT)


# ---------- nota de los títulos (Skin.String) ----------
class RatingsStore:
    """ajustes de la skin de «Nota de los títulos» (flix_ratings)"""

    def read_key(self):
        import flix_ratings
        return flix_ratings.read_key()

    def read_order(self, key):
        import flix_ratings
        return flix_ratings.read_order(key)

    def save(self, key, order):
        import flix_ratings
        flix_ratings.save_settings(key, order)


class RatingsSource(Source):
    level = "ratings"
    toggle_labels = ("Desactivar", "Activar")
    HELP = ("Cada título enseña la nota de la primera fuente encendida que la tenga. TMDB es la predefinida: lo que "
            "quede debajo no se usa.[CR]OK: mover, activar o desactivar · Derecha: clave de MDBList",
            "Cada título enseña la nota de la primera fuente encendida que la tenga. TMDB es la predefinida: lo que "
            "quede debajo no se usa.")

    def __init__(self, store=None):
        self.store = store or RatingsStore()
        self.key = ""

    def title(self):
        return "Nota de los títulos"

    def items_of(self, order):
        import flix_ratings as fr
        return self.decorate([core.item(k, fr.LABEL[k], on=on) for k, on in order])

    def load(self):
        self.key = self.store.read_key()
        return self.items_of(self.store.read_order(self.key))

    @staticmethod
    def order(items):
        return [(it["id"], it["on"]) for it in items]

    def decorate(self, items):
        import flix_ratings as fr
        order = self.order(items)
        for it in items:
            it["note"] = fr.row_note(order, it["id"], self.key)
        return items

    def save(self, items):
        self.store.save(self.key, self.order(items))

    def count(self, items, touch):
        import flix_ratings as fr
        return fr.summary(self.order(items), self.key)

    def buttons(self, items, touch):
        import flix_ratings as fr
        return [("key", ("Clave: %s" if touch else "Clave de MDBList: %s") % fr.mask(self.key)),
                ("reset", "Restablecer")]

    def check_toggle(self, items, k, ui):
        import flix_ratings as fr
        if items[k]["id"] == fr.TMDB:
            ui.notify("TMDB no se puede apagar: es la predefinida")
            return False
        if not items[k]["on"] and not self.key:
            new = ui.ask_key("")
            if not new:
                return False
            self.key = new
        return True

    def press(self, action, items, k, ui):
        if action == "key":
            new = ui.ask_key(self.key)
            if new is None:
                return None
            self.key = new
            return items, k
        return None

    def reset(self):
        import flix_ratings as fr
        return self.items_of(list(fr.DEFAULT))
