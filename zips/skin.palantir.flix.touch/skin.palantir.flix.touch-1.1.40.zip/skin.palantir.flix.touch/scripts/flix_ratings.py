"""Nota de cada título (Metacritic, IMDb, Rotten Tomatoes o Letterboxd) en lugar de la ★ de TMDB, vía MDBList con la
clave PROPIA de cada aparato. Carlos (21-oct): lista ordenable con interruptor por fuente (Ajustes → Nota de los
títulos); por título se enseña la 1.ª fuente encendida que tenga nota. TMDB (la ★ que da Palantir) la tienen todos y no
se puede apagar: las fuentes que queden debajo no se llegan a usar.

Carlos (20-oct): «el que no tenga API puesta sigue viendo lo de ahora». Sin clave (Skin.String flix_mdblist_key) o
con TMDB la 1.ª encendida (Skin.String flix_rating_order) este script ni arranca el bucle: las etiquetas usan la ★ que
da Palantir (variables FlixRating* de Includes_Flix.xml caen a ListItem.Rating).

Con clave y alguna fuente antes de TMDB, un bucle (lo lanza first_run.py, una vez por sesión) mira lo enfocado:
  ranura li  ListItem.FolderPath                        (filas del Inicio TV, secciones, listados, táctil)
  ranura c5  Container(5000).ListItem.FolderPath        (cabecera del Inicio táctil antiguo / listas)
  ranura fz  Window(home).Property(fhz_path)            (cabecera congelada del Inicio TV al subir al menú)
y deja en Window(home) flix_rt_<ranura> = «Metacritic 82» / «IMDb 8.4» y flix_rt_<ranura>_path = la ruta a la que corresponde
(el XML solo la usa si coincide con la del elemento: nunca enseña la nota de otro título). Sin nota de esas fuentes
para el título -> vacío -> la ★ de TMDB, como siempre. Además precarga en segundo plano los primeros títulos de cada
fila (prefetch): así casi nunca se ve el cambio de la ★ a la nota.

API: GET https://api.mdblist.com/tmdb/{movie|show}/{tmdb}?apikey=… (1000 consultas/día con clave gratuita). Se pide
solo lo que se queda enfocado DWELL s, en un hilo; caché por aparato (ratings3.json) 7 días, «sin nota» 1 día; con
429 o pocas consultas restantes se deja de pedir hasta el reinicio del contador. La caché guarda TODAS las fuentes de
cada título: cambiar el orden no vuelve a pedir nada. La clave no sale nunca en el log.

Guardado por aparato en los ajustes del skin:
  Skin.String(flix_mdblist_key)      clave («-» = sin clave)
  Skin.String(flix_rating_order)     "metacritic|imdb|tmdb|-tomatoes|-letterboxd" (orden; "-" = apagada; sin comas:
                                     Skin.SetString corta el valor en la primera coma)
  Skin.String(flix_rating_summary)   resumen para la pantalla de Ajustes ("Metacritic → IMDb → TMDB")
  Skin.String(flix_rating_src)       el de antes (tmdb / mdb / letterboxd / metacritic): solo para migrar
Uso: RunScript(special://skin/scripts/flix_ratings.py)            bucle (first_run)
     RunScript(special://skin/scripts/flix_ratings.py,settings)   editor único (flix_editor.py,ratings)"""
import ast
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import atomic_write, decode_route  # noqa: E402

API = "https://api.mdblist.com/tmdb/%s/%s?apikey=%s"
TMDB = "tmdb"                           # la ★ de Palantir (ListItem.Rating): no viene de MDBList
# fuente de MDBList ("source" de su lista "ratings") -> (nombre, formato). Letterboxd 0-5; Rotten Tomatoes y Metacritic 0-100
SOURCES = {"metacritic": ("Metacritic", "%d"), "imdb": ("IMDb", "%.1f"), "tomatoes": ("Rotten Tomatoes", "%d%%"),
           "letterboxd": ("Letterboxd", "%.1f")}
KEYS = ("metacritic", "imdb", TMDB, "tomatoes", "letterboxd")
LABEL = {k: (SOURCES[k][0] if k in SOURCES else "TMDB") for k in KEYS}
DEFAULT = [("metacritic", True), ("imdb", True), (TMDB, True), ("tomatoes", False), ("letterboxd", False)]
TMDB_ONLY = [(k, k == TMDB) for k, _ in DEFAULT]
KEY_RE = r"[A-Za-z0-9]{8,64}"
KIND = {"movies": "movie", "movie": "movie", "tvshows": "show", "tvshow": "show", "seasons": "show",
        "episodes": "show"}
TTL = 7 * 86400         # nota guardada
NEG_TTL = 86400         # «MDBList no tiene nota»: se vuelve a mirar al día siguiente
ERR_TTL = 600           # error de red: no insistir en 10 min
MAX_ENTRIES = 4000
LOW = 25                # consultas restantes por debajo de las cuales se para hasta el reinicio del contador
DWELL = 0.6             # s enfocado antes de pedir (no gastar consultas al pasar de largo)
STEP = 0.25
TIMEOUT = 8


def mask(key):
    return "••••" + key[-4:] if key else "Sin poner"


def parse_order(text):
    """'metacritic|-imdb|tmdb|…' -> [(fuente, encendida)] con todas (las que falten, al final y apagadas); TMDB
    siempre encendida (es la última red: la tienen todos los títulos)"""
    out, seen = [], set()
    for part in (text or "").replace(",", "|").split("|"):
        part = part.strip().lower()
        k = part.lstrip("-")
        if k in LABEL and k not in seen:
            out.append((k, k == TMDB or not part.startswith("-")))
            seen.add(k)
    if TMDB not in seen:
        return list(DEFAULT)
    return out + [(k, False) for k in KEYS if k not in seen]


def dump_order(order):
    return "|".join(("" if on else "-") + k for k, on in order)


def legacy_order(src, key):
    """orden equivalente al ajuste de antes (Skin.String flix_rating_src): «tmdb» con clave puesta = solo TMDB; el
    resto (mdb, letterboxd, metacritic, o sin clave: se veía TMDB porque no había clave) = el orden de serie"""
    src = (src or "").strip().lower()
    return list(TMDB_ONLY) if key and src in ("", TMDB) else list(DEFAULT)


def chain(order):
    """fuentes de MDBList que se miran, en orden: las encendidas antes de TMDB. () = la ★ de TMDB de siempre"""
    out = []
    for k, on in order:
        if k == TMDB:
            break
        if on:
            out.append(k)
    return tuple(out)


def summary(order, key):
    """«Metacritic → IMDb → TMDB» (lo que se mira de verdad) o «TMDB (sin clave de MDBList)»"""
    if not key:
        return "TMDB (sin clave de MDBList)"
    return " → ".join([LABEL[k] for k in chain(order)] + ["TMDB"])


def target(path):
    """('movie'|'show', tmdb) de una ruta de Palantir; None si no es un título"""
    if not path or "palantir3" not in path or "?" not in path:
        return None
    try:
        info = ast.literal_eval(decode_route(path))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(info, dict):
        return None
    tmdb = str(info.get("tmdb") or "")
    kind = KIND.get(info.get("content") or "")
    if not kind or not tmdb.isdigit() or tmdb == "0":
        return None
    return kind, tmdb


def parse(data):
    """{'metacritic': 44.0, 'imdb': 6.1, 'tomatoes': 36.0, 'letterboxd': 2.9} con TODAS las fuentes que tienen valor
    (la caché las guarda todas: cambiar el orden no pide nada)"""
    out = {}
    for r in (data or {}).get("ratings") or []:
        src = r.get("source")
        if src in SOURCES and isinstance(r.get("value"), (int, float)) and r["value"] > 0:
            out[src] = float(r["value"])
    return out


def fmt(srcs, vals):
    """«Metacritic 44» o, sin ella, la siguiente de srcs (chain()) que tenga nota; '' si ninguna (-> la ★ de TMDB)"""
    for k in srcs or ():
        if k in SOURCES and (vals or {}).get(k) is not None:
            name, f = SOURCES[k]
            return "%s %s" % (name, f % vals[k])
    return ""


class RateLimited(Exception):
    def __init__(self, until):
        Exception.__init__(self, "límite de MDBList")
        self.until = until


def fetch(kind, tmdb, key, opener=urllib.request.urlopen, now=time.time):
    """notas de MDBList ({} si no tiene ninguna de las nuestras). RateLimited si hay que parar."""
    req = urllib.request.Request(API % (kind, tmdb, key), headers={"User-Agent": "Ker0n3Media-skin"})
    try:
        with opener(req, timeout=TIMEOUT) as r:
            body, headers = r.read(), r.headers
    except urllib.error.HTTPError as e:
        if e.code == 429:
            raise RateLimited(_reset(e.headers, now)) from None
        if e.code == 404:
            return {}
        raise
    vals = parse(json.loads(body.decode("utf-8", "replace") or "{}"))
    try:
        remaining = int((headers or {}).get("x-ratelimit-remaining", "") or -1)
    except ValueError:
        remaining = -1
    if 0 <= remaining < LOW:
        raise _Partial(vals, _reset(headers, now))
    return vals


class _Partial(RateLimited):
    """quedan pocas consultas: se usa esta nota pero se para después"""
    def __init__(self, vals, until):
        RateLimited.__init__(self, until)
        self.vals = vals


def _reset(headers, now):
    try:
        until = float((headers or {}).get("x-ratelimit-reset", "") or 0)
    except ValueError:
        until = 0
    t = now()
    return until if t < until < t + 2 * 86400 else t + 6 * 3600


class Cache:
    """ratings2.json: {"v": {"movie:123": [ts, {"metacritic": 44, "imdb": 6.1} | null]}, "until": ts_parar}"""

    def __init__(self, path, now=time.time):
        self.path, self.now, self.dirty = path, now, False
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        self.v = d.get("v") if isinstance(d.get("v"), dict) else {}
        self.until = float(d.get("until") or 0)

    def get(self, kind, tmdb):
        """(True, vals|None) si está fresca; (False, None) si hay que pedirla"""
        e = self.v.get("%s:%s" % (kind, tmdb))
        if not isinstance(e, list) or len(e) < 2:
            return False, None
        ts, vals = e[0], e[1]
        ttl = TTL if vals else (ERR_TTL if len(e) > 2 else NEG_TTL)
        if self.now() - ts > ttl:
            return False, None
        return True, (vals or None)

    def put(self, kind, tmdb, vals, error=False):
        e = [self.now(), vals if vals else ({} if not error else None)]
        if error:
            e.append("err")
        self.v["%s:%s" % (kind, tmdb)] = e
        if len(self.v) > MAX_ENTRIES:              # fuera las más viejas
            for k in sorted(self.v, key=lambda k: self.v[k][0])[:len(self.v) - MAX_ENTRIES]:
                del self.v[k]
        self.dirty = True

    def blocked(self):
        return self.now() < self.until

    def block(self, until):
        self.until, self.dirty = until, True

    def save(self):
        if self.dirty:
            atomic_write(self.path, json.dumps({"v": self.v, "until": self.until}, separators=(",", ":")))
            self.dirty = False


# ---------- dentro de Kodi ----------
def _kodi():
    import xbmc
    import xbmcgui
    import xbmcvfs
    return xbmc, xbmcgui, xbmcvfs


def read_key():
    key = _kodi()[0].getInfoLabel("Skin.String(flix_mdblist_key)").strip()
    return key if key not in ("", "-") else ""


def read_order(key=None):
    """orden guardado; si aún no hay (aparato de antes), el equivalente al ajuste viejo flix_rating_src"""
    xbmc = _kodi()[0]
    text = xbmc.getInfoLabel("Skin.String(flix_rating_order)").strip()
    if text:
        return parse_order(text)
    return legacy_order(xbmc.getInfoLabel("Skin.String(flix_rating_src)"), read_key() if key is None else key)


def settings_now():
    """(clave, fuentes de MDBList a mirar en orden); sin clave -> ('', ()) = la ★ de TMDB de siempre"""
    key = read_key()
    return key, (chain(read_order(key)) if key else ())


def save_settings(key, order):
    xbmc = _kodi()[0]
    xbmc.executebuiltin("Skin.SetString(flix_mdblist_key,%s)" % (key or "-"))
    xbmc.executebuiltin("Skin.SetString(flix_rating_order,%s)" % dump_order(order))
    xbmc.executebuiltin("Skin.SetString(flix_rating_summary,%s)" % summary(order, key))


def migrate():
    """al arrancar (first_run): orden del ajuste viejo -> flix_rating_order, una vez; y resumen siempre al día. Así
    los ajustes existen y se pueden poner a distancia (Settings.SetSkinSettingValue solo cambia los que existen)"""
    xbmc = _kodi()[0]
    key, order = read_key(), read_order()
    if (not xbmc.getInfoLabel("Skin.String(flix_rating_order)")
            or xbmc.getInfoLabel("Skin.String(flix_rating_summary)") != summary(order, key)):
        save_settings(key, order)


def cache_path():
    xbmc, _, xbmcvfs = _kodi()
    # ratings3: las de antes (ratings.json, ratings2.json) no guardaban Rotten Tomatoes ni Letterboxd
    return xbmcvfs.translatePath("special://profile/addon_data/%s/ratings3.json" % xbmc.getSkinDir())


def log(msg):
    xbmc = _kodi()[0]
    xbmc.log("[flix_ratings] %s" % msg, xbmc.LOGINFO)


SLOTS = (("li", "ListItem.FolderPath"), ("c5", "Container(5000).ListItem.FolderPath"),
         ("fz", "Window(home).Property(fhz_path)"))


class Watcher:
    def __init__(self):
        xbmc, xbmcgui, _ = _kodi()
        self.xbmc, self.home = xbmc, xbmcgui.Window(10000)
        self.cache = Cache(cache_path())
        self.lock = threading.Lock()
        self.busy = set()
        self.seen = {}                  # ranura -> (ruta, desde cuándo)
        self.key, self.srcs = "", ()

    def clear(self):
        for s, _ in SLOTS:
            self.home.clearProperty("flix_rt_%s" % s)
            self.home.clearProperty("flix_rt_%s_path" % s)

    def show(self, slot, path, vals):
        self.home.setProperty("flix_rt_%s" % slot, fmt(self.srcs, vals))
        self.home.setProperty("flix_rt_%s_path" % slot, path)

    def worker(self, kind, tmdb):
        try:
            vals = fetch(kind, tmdb, self.key)
            with self.lock:
                self.cache.put(kind, tmdb, vals)
        except _Partial as e:
            with self.lock:
                self.cache.put(kind, tmdb, e.vals)
                self.cache.block(e.until)
            log("quedan pocas consultas de MDBList: paro hasta %s" % time.strftime("%H:%M", time.localtime(e.until)))
        except RateLimited as e:
            with self.lock:
                self.cache.block(e.until)
            log("límite de MDBList: paro hasta %s" % time.strftime("%H:%M", time.localtime(e.until)))
        except urllib.error.HTTPError as e:
            with self.lock:
                self.cache.put(kind, tmdb, None, error=True)
            log("MDBList %s/%s: HTTP %s%s" % (kind, tmdb, e.code, " (¿clave %s mal?)" % mask(self.key)
                                               if e.code in (401, 403) else ""))
        except Exception as e:  # noqa: BLE001
            with self.lock:
                self.cache.put(kind, tmdb, None, error=True)
            log("MDBList %s/%s: %s" % (kind, tmdb, str(e).replace(self.key, mask(self.key)) if self.key else e))
        finally:
            with self.lock:
                self.busy.discard((kind, tmdb))
                self.cache.save()

    def tick(self):
        now = time.time()
        for slot, label in SLOTS:
            path = self.xbmc.getInfoLabel(label)
            prev = self.seen.get(slot)
            if not prev or prev[0] != path:
                self.seen[slot] = (path, now)
                prev = self.seen[slot]
            t = target(path)
            if not t:
                continue
            with self.lock:
                hit, vals = self.cache.get(*t)
                blocked = self.cache.blocked()
                busy = t in self.busy
            if hit:
                if (self.home.getProperty("flix_rt_%s_path" % slot) != path
                        or self.home.getProperty("flix_rt_%s" % slot) != fmt(self.srcs, vals)):
                    self.show(slot, path, vals)
            elif not busy and not blocked and now - prev[1] >= DWELL:
                with self.lock:
                    self.busy.add(t)
                threading.Thread(target=self.worker, args=t, daemon=True).start()

    def prefetch(self):
        """notas de los primeros PREFETCH_ROW títulos de cada fila, de una en una y con tope por pasada"""
        n = 0
        for kind, tmdb in prefetch_targets(self.xbmc):
            with self.lock:
                hit, _ = self.cache.get(kind, tmdb)
                skip = hit or (kind, tmdb) in self.busy or self.cache.blocked()
                if not skip:
                    self.busy.add((kind, tmdb))
            if skip:
                continue
            if n >= PREFETCH_MAX:
                with self.lock:
                    self.busy.discard((kind, tmdb))
                break
            self.worker(kind, tmdb)
            n += 1
            time.sleep(PREFETCH_PAUSE)
        if n:
            log("precarga: %d notas pedidas" % n)

    def run(self):
        mon = self.xbmc.Monitor()
        active = None
        next_pre = time.time() + PREFETCH_DELAY
        while not mon.abortRequested():
            self.key, self.srcs = settings_now()
            on = bool(self.key) and bool(self.srcs)
            if self.srcs != active:                          # al cambiar el orden: fuera las notas puestas
                log("nota de %s (clave %s)" % (" → ".join([LABEL[k] for k in self.srcs] + ["TMDB"]), mask(self.key))
                    if on else "sin clave de MDBList o TMDB la primera: la ★ de siempre")
                active = self.srcs
                self.clear()
            if on:
                self.tick()
                if time.time() >= next_pre:
                    next_pre = time.time() + PREFETCH_EVERY
                    threading.Thread(target=self.prefetch, daemon=True).start()
            if mon.waitForAbort(STEP if on else 3):
                break


PREFETCH_DELAY = 25     # s tras arrancar (que cargue el Inicio)
PREFETCH_EVERY = 1800   # y cada media hora (filas renovadas)
PREFETCH_ROW = 10       # títulos por fila
PREFETCH_MAX = 150      # consultas como mucho por pasada (MDBList gratis: 1000/día)
PREFETCH_PAUSE = 0.3
HOME_ROWS = list(range(5101, 5119)) + list(range(5130, 5148))   # filas del Inicio TV (flix_home_conf)


def prefetch_targets(xbmc, rows_file=None):
    """títulos de las filas: Inicio TV (contenedores de Kodi, si está a la vista) y filas guardadas por la táctil y
    las secciones (rows_cache2.json)"""
    out, seen = [], set()

    def add(path):
        t = target(path)
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    if xbmc.getCondVisibility("Window.IsVisible(home)"):
        for rid in HOME_ROWS:
            for i in range(PREFETCH_ROW):
                p = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).FolderPath" % (rid, i))
                if not p:
                    break
                add(p)
    try:
        if rows_file is None:
            import xbmcvfs
            rows_file = xbmcvfs.translatePath("special://profile/addon_data/%s/rows_cache2.json" % xbmc.getSkinDir())
        with open(rows_file, encoding="utf-8") as f:
            rows = json.load(f)
        for entry in rows.values():
            files = entry[1] if isinstance(entry, list) and len(entry) == 2 and isinstance(entry[1], list) else []
            for f in files[:PREFETCH_ROW]:
                if isinstance(f, dict):
                    add(f.get("file", ""))
    except (OSError, ValueError):
        pass
    return out


def wanted(path):
    """True si esta ruta debería llevar nota de MDBList (clave puesta, alguna fuente antes de TMDB y es un título)"""
    key, srcs = settings_now()
    return bool(key) and bool(srcs) and target(path) is not None


def label_for(path, wait=0.0):
    """para scripts (ficha, Inicio táctil): «Metacritic 82» / «IMDb 8.4» si está activa y hay nota (de caché o, con wait > 0,
    pidiéndola como mucho wait s); '' si no -> el que llama pone la ★ de TMDB"""
    key, srcs = settings_now()
    t = target(path)
    if not key or not srcs or not t:
        return ""
    c = Cache(cache_path())
    hit, vals = c.get(*t)
    if hit:
        return fmt(srcs, vals)
    if wait <= 0 or c.blocked():
        return ""
    try:
        vals = fetch(*t, key)
        c.put(*t, vals)
    except _Partial as e:
        c.put(*t, e.vals)
        c.block(e.until)
        vals = e.vals
    except RateLimited as e:
        c.block(e.until)
        vals = None
    except Exception:  # noqa: BLE001
        c.put(*t, None, error=True)
        vals = None
    c.save()
    return fmt(srcs, vals)


# ---------- editor único (flix_editor.py): avisos de cada fuente y clave ----------


def row_note(order, k, key):
    """aviso a la derecha de cada fuente: TMDB es la predefinida; las de debajo de TMDB no se usan; sin clave no hay
    MDBList"""
    if k == TMDB:
        return "Predefinida"
    if [x for x, _ in order].index(k) > [x for x, _ in order].index(TMDB):
        return "Debajo de TMDB: no se usa"
    if not key:
        return "Necesita clave de MDBList"
    return ""


def ask_key(xbmcgui, key):
    """teclado para la clave; '' la borra. None = cancelado o no válida"""
    new = xbmcgui.Dialog().input("Clave de MDBList (mdblist.com → Preferences → API). Vacía = quitarla",
                                 key).strip()
    if new and not re.fullmatch(KEY_RE, new):
        xbmcgui.Dialog().notification("Nota de los títulos", "Esa clave no parece válida", time=3000)
        return None
    return new


def main(argv):
    if len(argv) > 1 and argv[1] == "settings":
        import flix_editor
        flix_editor.run("ratings")          # acceso viejo (Ajustes de antes)
        return
    Watcher().run()


if __name__ == "__main__":
    main(sys.argv)
