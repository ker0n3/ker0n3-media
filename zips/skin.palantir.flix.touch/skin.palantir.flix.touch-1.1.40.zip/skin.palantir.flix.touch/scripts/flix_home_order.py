"""Filas del Inicio (versión TV y táctil): orden, ocultar, eliminar, añadir y elementos por fila.

RunScript(special://skin/scripts/flix_home_order.py,edit)   -> editor único (flix_editor.py,menu)
RunScript(special://skin/scripts/flix_home_order.py,check)  -> al arrancar: reaplica la configuración si una
                                                               actualización del skin trajo Home.xml de serie
Configuración en special://profile/addon_data/<skin>/home_order.json; formato y reglas en flix_home_conf.py
(lógica pura, con tests en tools/tests).

TV: las filas son includes FlixRow en xml/Home.xml (entre FLIX_ROWS_BEGIN y FLIX_ROWS_END) + variables de carga
diferida en xml/Includes_FlixRows.xml. Este script reescribe los dos (flix_home_conf.render_tv) y recarga el skin.
La copia de serie del trozo de filas se guarda en addon_data (home_rows_default.xml) para restaurar filas.
Táctil: flix_home.py lee la misma configuración y monta sus filas al cargar.
"""
import json
import os
import re
import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flix_home_conf as hc  # noqa: E402

HOME = xbmcgui.Window(10000)
SKIN_ID = xbmc.getSkinDir()
TOUCH = SKIN_ID.endswith(".touch")
SKIN = xbmcvfs.translatePath("special://skin/")
DATA = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
CONF = os.path.join(DATA, "home_order.json")
DEFAULT_ROWS = os.path.join(DATA, "home_rows_default.xml")
HOME_XML = os.path.join(SKIN, "xml", "Home.xml")
INC_XML = os.path.join(SKIN, "xml", "Includes_FlixRows.xml")
BEGIN, END = "<!-- FLIX_ROWS_BEGIN", "<!-- FLIX_ROWS_END -->"
SIG_RE = re.compile(r"[ \t]*<!-- FLIX_ORDER_SIG ([^ ]*) -->\n?")


def log(msg):
    xbmc.log("[flix_home_order] %s" % msg, xbmc.LOGINFO)


def atomic_write(path, text):
    tmp = "%s.tmp%d" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def load_conf():
    """configuración normalizada, o None si el usuario nunca la ha guardado"""
    try:
        with open(CONF, encoding="utf-8") as fh:
            return hc.normalize(json.load(fh))
    except (OSError, ValueError):
        return None


def save_conf(conf):
    os.makedirs(DATA, exist_ok=True)
    atomic_write(CONF, json.dumps(hc.normalize(conf)))


def ordered(rows, conf):
    """compatibilidad: rows = [(id, label, …)] -> en el orden guardado (las nuevas al final)"""
    if not conf:
        return list(rows)
    pos = {i: k for k, i in enumerate(conf["order"])}
    return sorted(rows, key=lambda r: pos.get(r[0], 1000 + rows.index(r)))


# ---------- TV: Home.xml ----------
def _region(text):
    a = text.index("-->", text.index(BEGIN)) + 4    # tras el comentario de la marca (ocupa 2 líneas)
    b = text.index(END)
    b = text.rindex("\n", 0, b) + 1
    return a, b


def tv_default_blocks():
    """filas de serie [{id, label, path, src, top10, extra}] en su orden"""
    with open(HOME_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    region = text[a:b]
    if not SIG_RE.search(region) or not os.path.exists(DEFAULT_ROWS):
        # Home.xml de serie (instalación o actualización): su trozo de filas es el nuevo "de serie"
        os.makedirs(DATA, exist_ok=True)
        atomic_write(DEFAULT_ROWS, SIG_RE.sub("", region))
    with open(DEFAULT_ROWS, encoding="utf-8") as fh:
        return hc.parse_tv_blocks(fh.read())


def tv_apply(conf):
    conf = hc.normalize(conf)
    rows = hc.compose(tv_default_blocks(), conf)
    if not any(not r["hidden"] for r in rows):
        return False
    region, inc = hc.render_tv(rows, conf["items"])
    with open(HOME_XML, encoding="utf-8") as fh:
        text = fh.read()
    a, b = _region(text)
    atomic_write(INC_XML, inc)
    atomic_write(HOME_XML, text[:a] + "\t\t\t\t<!-- FLIX_ORDER_SIG %s -->\n" % hc.signature(conf) + region + text[b:])
    log("Home.xml reescrito: %s (elementos %d)" % ([r["id"] for r in rows if not r["hidden"]], conf["items"]))
    return True


def tv_current_sig():
    with open(HOME_XML, encoding="utf-8") as fh:
        m = SIG_RE.search(fh.read())
    return m.group(1) if m else None


# ---------- táctil ----------
def touch_default_rows():
    with open(os.path.join(SKIN, "scripts", "flix_home_rows.json"), encoding="utf-8") as fh:
        return json.load(fh)


def default_rows():
    """filas de serie como dicts con al menos id y label"""
    return touch_default_rows() if TOUCH else tv_default_blocks()


# ---------- arranque ----------
def check():
    """Startup (sin configuración guardada no hace nada) y Home "de fábrica" (onload del Includes_FlixRows.xml del
    zip): aplica la configuración, o la de serie, para que el Inicio quede escrito y la orden de fábrica desaparezca"""
    if TOUCH:
        return
    conf = load_conf()
    factory = False
    try:
        with open(INC_XML, encoding="utf-8") as fh:
            factory = "flix_home_order.py,check" in fh.read()
    except OSError:
        pass
    if not conf and not factory:
        return
    conf = conf or hc.normalize(None)
    try:
        if (factory or tv_current_sig() != hc.signature(conf)) and tv_apply(conf):
            xbmc.executebuiltin("ReloadSkin()")
    except Exception as e:  # noqa: BLE001
        log("check: %s" % e)


def apply_saved():
    """tras cambiar las filas del Inicio: el táctil las monta al momento; la TV reescribe Home.xml y recarga el skin"""
    if TOUCH:
        HOME.setProperty("fh_reorder", "1")             # flix_home.py lo aplica al momento (lo mira cada segundo)
        return
    conf = load_conf()
    if conf and tv_apply(conf):
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ReloadSkin()")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        check()
    else:
        import flix_editor
        flix_editor.run("menu")          # acceso viejo (flix_home_order.py,edit)
