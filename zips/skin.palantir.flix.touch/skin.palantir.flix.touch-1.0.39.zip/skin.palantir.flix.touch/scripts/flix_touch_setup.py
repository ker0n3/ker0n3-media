"""Ker0n3 Flix táctil: instala el keymap de gestos y lo recarga.

Por qué: en Kodi el arrastre lo coge la lista que hay bajo el dedo; una fila horizontal de pósters
ignora el movimiento vertical, así que en la Home no se podía bajar/subir arrastrando sobre los
pósters. Kodi sí detecta los "swipes" (gesto rápido <0,5 s y >1,3 cm) y permite mapearlos por
ventana. Aquí:
  Home:            nada (desde v5 la Home se arrastra en continuo: filas = listas desactivadas)
  FullScreenVideo: swipe arriba/abajo SIN acción (Kodi por defecto salta capítulo/10 min por error),
                   izquierda/derecha = -10 s / +10 s, pulsación larga = mostrar controles
                   (por defecto saca de la reproducción a la Home).
Se versiona con Skin.String(flix_touch_keymap); subir KEYMAP_VERSION si cambia el contenido.
"""
import xbmc
import xbmcvfs

KEYMAP_VERSION = "5"
KEYMAP = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Generado por la skin Ker0n3 Flix táctil (scripts/flix_touch_setup.py). Se reescribe al cambiar de versión. -->
<keymap>
  <FullScreenVideo>
    <touch>
      <swipe direction="up">noop</swipe>
      <swipe direction="down">noop</swipe>
      <swipe direction="left">Seek(-10)</swipe>
      <swipe direction="right">Seek(10)</swipe>
      <longpress>OSD</longpress>
    </touch>
  </FullScreenVideo>
</keymap>
"""


def main():
    folder = "special://profile/keymaps/"
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    path = folder + "flix_touch.xml"
    with xbmcvfs.File(path, "w") as fh:
        fh.write(KEYMAP)
    xbmc.executebuiltin("Action(reloadkeymaps)")
    # fechas dd/mm/aaaa aunque Kodi esté en inglés (pedido por Carlos 16-oct)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Settings.SetSettingValue","params":{"setting":"locale.shortdateformat","value":"DD/MM/YYYY"}}')
    # sin ".." en los listados: hay botón Atrás en pantalla
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Settings.SetSettingValue","params":{"setting":"filelists.showparentdiritems","value":false}}')
    xbmc.executebuiltin("Skin.SetString(flix_touch_keymap,%s)" % KEYMAP_VERSION)
    xbmc.log("[flix_touch] keymap v%s instalado en %s" % (KEYMAP_VERSION, xbmcvfs.translatePath(path)), xbmc.LOGINFO)


if __name__ == "__main__":
    main()
