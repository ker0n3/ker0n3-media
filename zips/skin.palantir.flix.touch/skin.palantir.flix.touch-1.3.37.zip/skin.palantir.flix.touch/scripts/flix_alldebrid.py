"""AllDebrid para la skin (fuentes propias, parte 1; 15-nov). La clave solo viaja a api.alldebrid.com, en la cabecera.

Nunca borra nada de la cuenta: se sube el magnet (/magnet/upload devuelve ready), se listan sus ficheros y se abre
el enlace del capítulo (/link/unlock), y ya. /v4/magnet/status está retirado (DISCONTINUED) y /magnet/instant da 404;
no se usan. El enlace abierto admite Range (saltos)."""
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://api.alldebrid.com/v4"
BASE_PIN = "https://api.alldebrid.com/v4.1"        # solo /pin/get (el de /v4/ está retirado)
AGENT = "ker0n3skin"
UA = "Mozilla/5.0 (Ker0n3Media-skin)"
VIDEO = re.compile(r"\.(mkv|mp4|avi|m2ts|ts|mov)$", re.I)
SAMPLE = re.compile(r"\bsample\b|\btrailer\b", re.I)


class ADError(Exception):
    def __init__(self, kind, msg=""):
        Exception.__init__(self, "%s %s" % (kind, msg))
        self.kind = kind


def key_path():
    import xbmc
    import xbmcvfs
    return xbmcvfs.translatePath("special://profile/addon_data/%s/alldebrid.json" % xbmc.getSkinDir())


def load_key(path=None):
    try:
        with open(path or key_path(), encoding="utf-8") as f:
            return ((json.load(f) or {}).get("apikey") or "").strip()
    except (OSError, ValueError, AttributeError, TypeError):
        return ""


def save_key(key, path=None):
    path = path or key_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"apikey": key}, f)
    os.replace(tmp, path)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """la API no redirige: si lo hiciera, urllib reenviaría la cabecera Authorization (la clave) al otro sitio"""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ADError("otro", "redirección %s a otro sitio" % code)


def _open(req, timeout):
    return urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout)


def _call(method, path, params=None, data=None, opener=None, public=False, base=None):
    """public: los puntos del código de vinculación (/pin/*), que van sin clave (todavía no la hay)"""
    headers = {"User-Agent": UA}
    if not public:
        key = load_key()
        if not key:
            raise ADError("sin_clave", "no hay clave guardada")
        headers["Authorization"] = "Bearer " + key
    q = urllib.parse.urlencode(dict({"agent": AGENT}, **(params or {})), doseq=True)
    body = urllib.parse.urlencode(data, doseq=True).encode() if data else None
    req = urllib.request.Request("%s%s?%s" % (base or BASE, path, q), data=body, method=method, headers=headers)
    try:
        with (opener or _open)(req, timeout=15) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        # 401/403: la clave no vale o no tiene permiso; el resto de códigos HTTP son «otro»
        raise ADError("sin_clave" if e.code in (401, 403) else "otro", "HTTP %s %s" % (e.code, path))
    except (urllib.error.URLError, OSError) as e:
        raise ADError("sin_red", "%s %s" % (path, e))
    try:
        d = json.loads(raw.decode() or "{}")
    except ValueError:
        raise ADError("otro", "respuesta no JSON %s" % path)
    if not isinstance(d, dict):
        raise ADError("otro", "respuesta inesperada %s" % path)
    if d.get("status") != "success":
        code = ((d.get("error") or {}).get("code") or "")
        kind = ("sin_clave" if code.startswith("AUTH") else "no_premium" if "PREMIUM" in code
                else "caducado" if code.startswith("PIN_") else "otro")
        raise ADError(kind, "%s %s" % (path, code))
    data = d.get("data")
    return data if isinstance(data, dict) else {}


# ---- vincular con código (Ajustes → Cuentas; 16-nov). Documentación (docs.alldebrid.com, 16-nov): /v4.1/pin/get por
# GET (el de /v4/ está retirado) y /v4/pin/check por POST con check y pin en el cuerpo; los dos públicos, sin clave
def pin_get(opener=None):
    """código nuevo: {pin, check, expires_in, user_url}. El código se escribe en alldebrid.com/pin"""
    d = _call("GET", "/pin/get", opener=opener, public=True, base=BASE_PIN)
    if not d.get("pin") or not d.get("check"):
        raise ADError("otro", "/pin/get sin código")
    return d


def pin_check(check, pin, opener=None):
    """la clave si el código ya se ha escrito en la web; si no, "". ADError «caducado» si el código ya no vale"""
    d = _call("POST", "/pin/check", data={"check": check, "pin": pin}, opener=opener, public=True)
    return ((d.get("apikey") or "").strip() if d.get("activated") else "")


def user(opener=None):
    """la cuenta de la clave guardada: {username, isPremium, premiumUntil…}; sirve para comprobar que la clave vale"""
    u = _call("GET", "/user", opener=opener).get("user")
    return u if isinstance(u, dict) else {}


def forget_key(path=None):
    """desvincular: borra la clave de ESTE aparato y nada más (en la cuenta de AllDebrid no se toca nada)"""
    try:
        os.remove(path or key_path())
    except OSError:
        pass


def upload(hashes, opener=None):
    d = _call("POST", "/magnet/upload", data={"magnets[]": list(hashes)}, opener=opener)
    out = {}
    for m in d.get("magnets") or []:
        h = (m.get("hash") or m.get("magnet") or "").lower()
        if h and m.get("id"):
            out[h] = (m["id"], bool(m.get("ready")))
    return out


def _flat(nodes):
    out = []
    for f in nodes or []:
        if "e" in f:
            out += _flat(f["e"])
        elif VIDEO.search(f.get("n", "")) and not SAMPLE.search(f.get("n", "")):
            out.append(f)
    return out


PACK_SHARE = 0.3    # película: otro vídeo de más del 30 % del mayor = pack de varias películas (no extras)


def _size_of(f):
    return f.get("s") or 0


_ANY_TAG = re.compile(r"(?<![a-z0-9])s\d{1,2}[\s._-]*e\d{1,4}(?!\d)|\b\d{1,2}x\d{2,3}(?!\d)", re.I)


def _absolute_ok(name, episode):
    """nombre de anime con numeración absoluta: sin ningún SxxEyy/TxCC (si lo lleva y no es este capítulo, es otro)
    y con el número del capítulo como capítulo («- 20», «E20», «Ep 20», «Episode 20»)"""
    if _ANY_TAG.search(name):
        return False
    return bool(re.search(r"(?:\s-\s*|(?<![a-z])(?:e|ep|episode|episodio|cap)\.?\s*)0*%d(?!\d)" % episode, name, re.I))


def pick_file(files, season, episode, filename=""):
    """el vídeo del capítulo (SxxEyy, TxCC, «Cap.TCC») o, en películas, el mayor. filename: el fichero que dice la
    versión (Torrentio/Peerflix), que manda si está. None si un pack no tiene el capítulo o si es un pack de
    películas sin ese nombre (no se sabe cuál es: mejor descartarlo que poner otra película)"""
    flat = _flat(files)
    if season is not None:
        if episode is None:
            return None
        tag = re.compile(r"(?<![a-z0-9])s0?%d[\s._-]*e0?%d(?!\d)|\b%dx0?%d(?!\d)|(?<![a-z0-9])cap\.?\s*%d%02d(?!\d)" % (
            season, episode, season, episode, season, episode), re.I)
        tagged = [f for f in flat if tag.search(f.get("n", ""))]
        if not tagged and filename and _absolute_ok(filename, episode):
            # anime (Nyaa, 17-nov): «Frieren - 20» sin SxxEyy. Torrentio ya eligió el fichero de ESTE capítulo
            # (filename): vale si está en el torrent tal cual
            tagged = [f for f in flat if f.get("n", "").lower() == filename.lower()]
        flat = tagged
    if not flat:
        return None
    if filename:
        named = [f for f in flat if f.get("n", "").lower() == filename.lower()]
        if named:
            return max(named, key=_size_of)
    big = max(flat, key=_size_of)
    if season is None and len([f for f in flat if _size_of(f) > PACK_SHARE * _size_of(big)]) > 1:
        return None
    return big


def video_link(magnet_id, season=None, episode=None, opener=None, filename=""):
    d = _call("GET", "/magnet/files", {"id[]": [magnet_id]}, opener=opener)
    files = []
    for m in d.get("magnets") or []:
        files += m.get("files") or []
    f = pick_file(files, season, episode, filename)
    if not f or not f.get("l"):
        return None
    return (_call("GET", "/link/unlock", {"link": f["l"]}, opener=opener).get("link")) or None
