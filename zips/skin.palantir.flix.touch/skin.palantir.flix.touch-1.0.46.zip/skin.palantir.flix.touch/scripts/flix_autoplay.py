"""Selector de versiones de Palantir (DialogSelect, lista id 3): reproducción automática y reintentos invisibles.

Lo lanza el <onload> de DialogSelect.xml SIEMPRE (también con el autoplay apagado), con el selector oculto
(Window(home).Property(flix_autoplay_busy)) hasta que este script decide.

Skin.String(flix_autoplay): "4k" = 4K -> DV -> 4K HDR -> DV HDR -> 1080p (HDR10 y HDR10+ cuentan igual),
"1080" = 1080p, otro = manual (se muestra el selector). Dentro de cada nivel, primero las versiones con Esp.

Palantir reabre el selector en tres casos y aquí se distinguen:
  * el enlace FALLA (AllDebrid "link not available"...): Palantir saca un aviso (okdialog / notificación).
    Mientras se resuelve un enlace, Window(home).Property(flix_resolving)=true oculta esos avisos y este script los
    cierra; al reabrirse el selector se prueba el SIGUIENTE enlace (primero los aptos del modo, luego el resto,
    remux al final) sin enseñar nada.
  * la reproducción llegó a arrancar y se paró: se cierra el selector (no se vuelven a enseñar las fuentes).
  * el usuario pulsó Atrás mientras cargaba (reabre sin aviso de error): también se cierra el selector.
Estado en Window(home).Property(flix_autoplay_state) = "titulo|estado|idx,idx" con estado trying / failed / played.
"""
import re
import threading
import time
import xbmc
import xbmcgui
import xbmcvfs
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flix_common import COLOR_RE, clean  # noqa: E402,F401

HOME = xbmcgui.Window(10000)
TIERS_BY_MODE = {"4k": ("4k", "dv", "4khdr", "dvhdr", "1080"), "1080": ("1080",)}
ERROR_WINDOWS = ("okdialog", "notification")
HANDOFF = [False]       # el selector se reabrió y otra instancia sigue: esta no toca flix_resolving
UPNEXT_SECS = 40        # el aviso "Siguiente capítulo" sale a 40 s del final (solo capítulos de más de 3 min)
AFTER_STOP_SECS = 25    # Palantir abre el selector del siguiente capítulo ~8 s después de acabar/parar
EPISODE_RE = re.compile(r"(\d+)x(\d+)")
FOLLOW_STALE = 15       # s: la marca flix_following se renueva cada ~5 s mientras alguien sigue la reproducción


def follower_active(mark, now):
    """¿hay ya un script siguiendo la reproducción? (marca = hora de la última renovación)"""
    try:
        return now - float(mark) < FOLLOW_STALE
    except (TypeError, ValueError):
        return False


def player_header(show, season, episode, title):
    """cabecera estilo selector ('Serie: 1x03 Título') a partir del reproductor, para el modo follow"""
    if show and season and episode:
        return "%s: %sx%02d %s" % (show, season, int(episode), title) if episode.isdigit() else "%s: %sx%s %s" % (show, season, episode, title)
    return title


class UpNext(xbmcgui.WindowXMLDialog):
    """Aviso propio "Siguiente capítulo" (Custom_1111_Overlay.xml, mismos ids que el de Palantir).
    Siguiente = saltar al final (Palantir abre el siguiente al acabar). Cancelar / Atrás = al acabar o parar,
    quedarse en el menú. Si no se toca, al acabar el capítulo sigue el siguiente."""

    def onInit(self):
        title = xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or HOME.getProperty("flix_series_title") or xbmc.getInfoLabel("Player.Title")
        m = EPISODE_RE.search(xbmc.getInfoLabel("Player.Title"))
        self.getControl(200001).setLabel(title)
        self.getControl(200003).setLabel("T%d · E%d" % (int(m.group(1)), int(m.group(2)) + 1) if m else "")
        art = xbmc.getInfoLabel("Player.Art(fanart)") or HOME.getProperty("flix_fanart") or xbmc.getInfoLabel("Player.Art(thumb)")
        self.getControl(200000).setImage(art)
        self.tick(UPNEXT_SECS)

    def tick(self, remaining):
        try:
            self.getControl(200002).setText("Empieza en %d s" % max(0, int(remaining)))
            self.getControl(200007).setPercent(max(0.0, min(100.0, 100.0 * remaining / UPNEXT_SECS)))
        except RuntimeError:
            pass

    def onClick(self, cid):
        if cid == 200006:
            HOME.setProperty("flix_upnext_choice", "next")
            self.close()
            xbmc.executebuiltin("RunScript(special://skin/scripts/flix_next.py)")
        elif cid == 200005:
            HOME.setProperty("flix_upnext_choice", "stay")
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            HOME.setProperty("flix_upnext_choice", "stay")
            self.close()


def series_of(header):
    """'Palantir · South Park: 28x02 La mujer…' -> 'palantir · south park' ('' si no es un capítulo)"""
    m = EPISODE_RE.search(header or "")
    return header[:m.start()].rstrip(" :-·").strip().lower() if m else ""


def is_episode():
    return bool(xbmc.getInfoLabel("VideoPlayer.Episode")) or EPISODE_RE.search(xbmc.getInfoLabel("Player.Title")) is not None


def follow_playback(header):
    """Durante la reproducción: aviso "Siguiente capítulo" a UPNEXT_SECS del final y, al parar, decide si el
    selector del siguiente capítulo que abrirá Palantir se deja (go) o se cierra (stay)."""
    player, mon = xbmc.Player(), xbmc.Monitor()
    HOME.clearProperty("flix_upnext_choice")
    episode, popup, last_rem = is_episode(), None, 9999.0
    renewed = 0.0
    while player.isPlaying() and not mon.abortRequested():
        if time.time() - renewed > 5:
            renewed = time.time()
            HOME.setProperty("flix_following", str(renewed))
        try:
            total, cur = player.getTotalTime(), player.getTime()
            last_rem = total - cur
        except RuntimeError:
            break
        if episode and popup is None and total > 180 and 0 < last_rem <= UPNEXT_SECS \
                and not HOME.getProperty("flix_upnext_choice"):
            popup = UpNext("Custom_1111_Overlay.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
            popup.show()
            log("aviso siguiente capítulo (%s, faltan %.0f s)" % (header, last_rem))
        elif popup is not None:
            popup.tick(last_rem)
        mon.waitForAbort(0.5)
    HOME.clearProperty("flix_following")
    if popup is not None:
        try:
            popup.close()
        except RuntimeError:
            pass
    # Palantir reabre el selector justo al parar: solo esa reapertura inmediata se cierra (ver decide)
    HOME.setProperty("flix_autoplay_stop", str(int(time.time())))
    choice = HOME.getProperty("flix_upnext_choice")
    natural = last_rem < 6                          # acabó solo (o "Siguiente" saltó al final)
    go = episode and (choice == "next" or (natural and choice != "stay"))
    if episode:     # solo los capítulos: Palantir abre el siguiente de la MISMA serie
        HOME.setProperty("flix_after_stop", "%d|%s|%s" % (time.time(), "go" if go else "stay", header))
    else:
        HOME.clearProperty("flix_after_stop")
    log("fin de %r: faltaban %.0f s, elección %r -> %s" % (header, last_rem, choice, "siguiente capítulo" if go else "quedarse en el menú"))
    handle_countdown(go, header)


def handle_countdown(go, header=""):
    """Al acabar un capítulo Palantir enseña su cuenta atrás ("Starting Serie (2x3) in 5 seconds", progressdialog).
    Nunca se pinta (flix_resolving oculta el progreso en DialogConfirm). Si hay que seguir, se deja correr; si no,
    se cancela (Atrás sobre el diálogo) y no llega a abrirse el siguiente.
    Si había que seguir y Palantir no abre el selector del siguiente (no hay más capítulos: solo saca un aviso, que
    aquí se oculta), sale el aviso propio "No hay más capítulos" en vez de quedarse cargando."""
    HOME.setProperty("flix_resolving", "true")
    mon = xbmc.Monitor()
    t0, seen_progress, progress_end, nomore = time.time(), False, 0.0, False
    try:
        while time.time() - t0 < 25:
            if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                HANDOFF[0] = True
                return                                  # el selector del siguiente ya está: su instancia manda
            if go and xbmc.Player().isPlayingVideo():
                return                                  # sin selector: Palantir ya reproduce el siguiente
            prog = xbmc.getCondVisibility("Window.IsActive(progressdialog)")
            if not go and prog:
                xbmc.executebuiltin("Action(Back)")     # cancelar la cuenta atrás de Palantir
                log("cuenta atrás de Palantir cancelada (me quedo en el menú)")
                mon.waitForAbort(0.8)
                return
            if go:
                if prog:
                    seen_progress, progress_end = True, 0.0
                elif seen_progress and not progress_end:
                    progress_end = time.time()
                if close_errors():
                    nomore = True                       # aviso de Palantir (sin más capítulos / sin enlaces)
                    break
                if progress_end and time.time() - progress_end > 8:
                    nomore = True                       # acabó su cuenta atrás y no abrió nada
                    break
                if not seen_progress and time.time() - t0 > 12:
                    nomore = True                       # ni siquiera empezó cuenta atrás
                    break
            elif time.time() - t0 > 12:
                return
            if mon.waitForAbort(0.2):
                return
        nomore = nomore or go
    finally:
        if not HANDOFF[0] and not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
            HOME.clearProperty("flix_resolving")
    if go and nomore and not HANDOFF[0]:
        log("%s: no llega el siguiente capítulo -> aviso" % header)
        show_message(HOME.getProperty("flix_series_title") or series_of(header).title(),
                     "No hay más capítulos disponibles por ahora", HOME.getProperty("flix_fanart"))


class MessageDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.props = kwargs.get("props", {})

    def onInit(self):
        for k, v in self.props.items():
            self.setProperty(k, v)
        threading.Timer(8, self.close).start()          # se cierra solo


def show_message(title, text, fanart=""):
    w = MessageDialog("FlixMessage.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i",
                      props={"fm_title": title or "", "fm_text": text, "fm_fanart": fanart or ""})
    w.doModal()
    del w


def log(msg):
    xbmc.log("[flix_autoplay] %s" % msg, xbmc.LOGINFO)



def quality(label):
    m = re.search(r"\((.+?)\)\s*\[", label)
    return (m.group(1) if m else "").strip()


def tier(q):
    """4k = 4K sin HDR, dv = Dolby Vision sin HDR, 4khdr / dvhdr = con HDR10 o HDR10+, 1080. None = remux u otros."""
    if "(R)" in q:
        return None
    u = q.upper()
    hdr = "HDR" in u
    if u.startswith("4K"):
        return "4khdr" if hdr else "4k"
    if u.startswith("DV"):
        return "dvhdr" if hdr else "dv"
    if u.startswith("1080"):
        return "1080"
    return None


def langs(label):
    m = re.search(r"\)\s*\[([^\]]*)\]", label)
    return m.group(1) if m else ""


def is_remux(label):
    return "(R)" in quality(label)


def preferred(items, mode):
    """Índices aptos del modo en orden de preferencia (nivel, y dentro de cada nivel primero los Esp)."""
    by_tier = {}
    for i, l in enumerate(items):
        t = tier(quality(l))
        if t:
            by_tier.setdefault(t, []).append(i)
    out = []
    for t in TIERS_BY_MODE.get(mode, ()):
        idxs = by_tier.get(t, [])
        out += [i for i in idxs if "Esp" in langs(items[i])] + [i for i in idxs if "Esp" not in langs(items[i])]
    return out


def fallback_order(items, mode, first=None):
    """Orden completo de reintentos: aptos del modo, luego el resto (desde el elegido a mano si lo hay), remux al final."""
    n = len(items)
    rest = list(range(first + 1, n)) + list(range(0, first)) if first is not None else list(range(n))
    out = preferred(items, mode)
    out += [i for i in rest if i not in out and not is_remux(items[i])]
    out += [i for i in rest if i not in out]
    return out


def read_state(header):
    state = HOME.getProperty("flix_autoplay_state")
    if not state.startswith(header + "|"):
        return None, []
    parts = state[len(header) + 1:].split("|")
    status = parts[0]
    tried = [int(x) for x in (parts[1] if len(parts) > 1 else "").split(",") if x.isdigit()]
    return status, tried


def write_state(header, status, tried):
    HOME.setProperty("flix_autoplay_state", "%s|%s|%s" % (header, status, ",".join(str(i) for i in tried)))


def close_selector():
    """Cierra el selector sin que se llegue a ver (sigue oculto por flix_autoplay_busy)."""
    xbmc.executebuiltin("Dialog.Close(selectdialog,true)")


def close_errors():
    seen = False
    for w in ERROR_WINDOWS:
        if xbmc.getCondVisibility("Window.IsActive(%s)" % w):
            xbmc.executebuiltin("Dialog.Close(%s,true)" % w)
            seen = True
    return seen


def watch(header, tried):
    """Tras elegir un enlace: espera a que reproduzca, falle (aviso de error) o se reabra el selector."""
    HOME.setProperty("flix_resolving", "true")
    try:
        player = xbmc.Player()
        for _ in range(30):  # el selector tarda en cerrarse (animación): no confundirlo con una reapertura
            if not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                break
            xbmc.sleep(50)
        for _ in range(900):  # hasta 90 s resolviendo el enlace
            if close_errors():
                write_state(header, "failed", tried)
                log("enlace %d falló (aviso ocultado)" % tried[-1])
            if player.isPlayingVideo():
                write_state(header, "played", tried)
                log("reproduciendo enlace %d" % tried[-1])
                HOME.clearProperty("flix_resolving")
                follow_playback(header)
                return
            if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
                close_errors()
                HANDOFF[0] = True
                return  # reapertura: la nueva instancia del script decide
            xbmc.sleep(100)
        HOME.clearProperty("flix_autoplay_state")  # nada en 90 s: estado caducado
    finally:
        # los avisos que Kodi/Palantir saquen justo después del fallo también se ocultan un momento
        for _ in range(10):
            if close_errors():
                status, t = read_state(header)
                if status == "trying":
                    write_state(header, "failed", t)
            xbmc.sleep(100)
        if not HANDOFF[0] and not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
            HOME.clearProperty("flix_resolving")     # con relevo / selector abierto, la propiedad es de la otra instancia


def play(header, items, idx, tried):
    tried.append(idx)
    write_state(header, "trying", tried)
    HOME.setProperty("flix_resolving", "true")      # antes de elegir: el progreso de AllDebrid no llega a verse
    HOME.setProperty("flix_following", str(time.time()))   # este script seguirá la reproducción
    log("%s -> %d %r (intento %d)" % (header, idx, items[idx], len(tried)))
    xbmc.executebuiltin("SetFocus(3,%d,absolute)" % idx)
    xbmc.sleep(120)
    xbmc.executebuiltin("Action(Select)")
    watch(header, tried)


def manual(header, items):
    """Autoplay apagado: se enseña el selector y se vigila qué enlace elige el usuario para reintentar si falla."""
    HOME.clearProperty("flix_autoplay_busy")
    last = 0
    while xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
        cur = xbmc.getInfoLabel("Container(3).CurrentItem")
        if cur.isdigit() and int(cur) > 0:
            last = int(cur) - 1
        xbmc.sleep(80)
    # Atrás en el selector = Palantir no carga nada: si en 3 s no hay carga ni reproducción, no se vigila
    for _ in range(30):
        if xbmc.getCondVisibility("Window.IsActive(progressdialog) | Window.IsActive(busydialog) | "
                                  "Window.IsActive(busydialognocancel) | Player.HasMedia | Window.IsActive(okdialog)"):
            break
        xbmc.sleep(100)
    else:
        return
    tried = [last]
    write_state(header, "trying", tried)
    log("%s: elegido a mano %d %r" % (header, last, items[last]))
    watch(header, tried)


def decide():
    items = []
    for _ in range(40):  # el diálogo rellena la lista justo después de onload
        n = xbmc.getInfoLabel("Container(3).NumItems")
        if n.isdigit() and int(n) > 0:
            items = [xbmc.getInfoLabel("Container(3).ListItem(%d).Label" % i) for i in range(int(n))]
            break
        xbmc.sleep(50)
    if not items or not items[0].startswith("Ver en"):
        return
    mode = xbmc.getInfoLabel("Skin.String(flix_autoplay)").strip().lower()
    header = clean(xbmc.getInfoLabel("Control.GetLabel(1)"))
    status, tried = read_state(header)
    if close_errors() and status == "trying":
        status = "failed"

    if status == "played":
        try:
            stopped = int(HOME.getProperty("flix_autoplay_stop") or 0)
        except ValueError:
            stopped = 0
        if time.time() - stopped > 8:
            status = None  # se vuelve a abrir el mismo título más tarde: es una apertura nueva
    if status in ("played", "trying"):
        # played = paró la reproducción; trying sin aviso de error = Atrás mientras cargaba
        HOME.clearProperty("flix_autoplay_state")
        log("%s: reabierto tras %s -> cierro el selector" % (header, "reproducir" if status == "played" else "cancelar"))
        close_selector()
        return

    if status == "failed":
        first = tried[0] if tried and mode not in TIERS_BY_MODE else None
        for idx in fallback_order(items, mode, first):
            if idx not in tried:
                play(header, items, idx, tried)
                return
        HOME.clearProperty("flix_autoplay_state")
        log("%s: ningún enlace funciona (probados %s)" % (header, tried))
        close_selector()
        xbmcgui.Dialog().notification(header or "Ker0n3 Media", "Ningún enlace disponible ahora mismo", xbmcgui.NOTIFICATION_INFO, 4000)
        return

    # primera apertura para este título. Si llega justo después de parar un capítulo, es Palantir abriendo el
    # SIGUIENTE por su cuenta: solo se deja si se pidió (Siguiente / aviso sin cancelar al acabar)
    after = HOME.getProperty("flix_after_stop").split("|")
    HOME.clearProperty("flix_after_stop")
    if len(after) >= 3 and after[0].isdigit() and time.time() - int(after[0]) < AFTER_STOP_SECS and after[2] != header \
            and series_of(header) and series_of(header) == series_of(after[2]):
        if after[1] == "stay":
            log("%s: Palantir abre el siguiente tras salir de %r -> me quedo en el menú" % (header, after[2]))
            close_selector()
            return
        log("%s: siguiente capítulo pedido" % header)
    HOME.clearProperty("flix_autoplay_state")
    HOME.clearProperty("flix_autoplay_stop")
    if mode in TIERS_BY_MODE:
        order = preferred(items, mode)
        if order:
            play(header, items, order[0], [])
            return
        log("%s: sin versiones aptas para %s, selector manual" % (header, mode))
    manual(header, items)


def follow():
    """RunScript(flix_autoplay.py,follow) desde el onload de VideoFullScreen: sigue la reproducción (aviso de
    siguiente capítulo y qué hacer al acabar) cuando NO ha pasado por el selector (Palantir con reproducción
    automática, p. ej. Fire TV Eren). Si el autoplay ya la sigue (marca reciente), no hace nada."""
    if follower_active(HOME.getProperty("flix_following"), time.time()):
        return
    HOME.setProperty("flix_following", str(time.time()))
    player = xbmc.Player()
    for _ in range(20):
        if player.isPlayingVideo():
            break
        xbmc.sleep(100)
    else:
        HOME.clearProperty("flix_following")
        return
    header = player_header(xbmc.getInfoLabel("VideoPlayer.TVShowTitle"), xbmc.getInfoLabel("VideoPlayer.Season"),
                           xbmc.getInfoLabel("VideoPlayer.Episode"), clean(xbmc.getInfoLabel("Player.Title")))
    log("sigo la reproducción sin selector: %s" % header)
    follow_playback(header)


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "follow":
        follow()
        return
    try:
        decide()
    finally:
        HOME.clearProperty("flix_autoplay_busy")  # muestra el selector si sigue abierto y no se ha elegido nada
        if not HANDOFF[0] and not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
            HOME.clearProperty("flix_resolving")  # puesta por el onunload del selector (cancelar / cerrado sin cargar)


if __name__ == "__main__":     # RunScript lo ejecuta como __main__; importado (tests) no hace nada
    main()
