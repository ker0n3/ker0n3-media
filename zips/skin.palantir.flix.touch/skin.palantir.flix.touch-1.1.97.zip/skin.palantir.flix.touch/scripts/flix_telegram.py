"""Aviso semanal del grupo de Telegram para avisar de fallos (Carlos, 28-oct): una vez por semana y aparato, con el
Inicio a la vista, sin vídeo ni diálogos encima. Ventana FlixTelegram.xml (tools/gen_telegram_dialog.py) con el QR del
grupo (segno, en scripts/vendor) y el enlace; en la táctil, «Abrir Telegram» abre el enlace en el móvil.
Sin registro (instalación nueva o primera vez tras actualizar la skin): sale ya, y luego cada semana (Carlos).
Lo lanza first_run.py (una vez por sesión)."""
import json
import os
import sys
import time

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor"))

URL = "https://t.me/skinker0n3media"
SHOWN_URL = "t.me/skinker0n3media"
EVERY = 7 * 86400
START_DELAY = 5         # s tras arrancar (Carlos: al arrancar la skin); si el Inicio aún no está libre, se espera (idle)
WAIT_IDLE = 600         # s como mucho esperando a que no haya vídeo ni diálogos; si no, en el próximo arranque
STATE = "special://profile/addon_data/%s/telegram.json"
OPEN = 11               # botón «Abrir Telegram» (solo táctil)
HOME = xbmcgui.Window(10000)


def log(msg):
    xbmc.log("[flix_telegram] %s" % msg, xbmc.LOGINFO)


def state_path():
    return xbmcvfs.translatePath(STATE % xbmc.getSkinDir())


def load(path):
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def save(path, last):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"last": last}, fh)
        os.replace(tmp, path)
    except OSError as e:
        log("no guardo %s: %s" % (path, e))


def due(state, now):
    """¿toca el aviso? Sin estado (instalación nueva, primera vez tras actualizar o fichero roto): sí"""
    last = state.get("last") if state else None
    return not isinstance(last, (int, float)) or now - last >= EVERY


def idle():
    """Inicio a la vista (TV: FlixInicio.xml; táctil: su ventana, fh_window) y nada encima: ni vídeo ni diálogos"""
    inicio = xbmc.getCondVisibility("Window.IsVisible(FlixInicio.xml)")
    wid = HOME.getProperty("fh_window")
    if wid and not inicio:
        inicio = xbmc.getCondVisibility("Window.IsActive(%s)" % wid)
    return bool(inicio) and not xbmc.getCondVisibility("Player.HasMedia | System.HasActiveModalDialog")


def make_qr():
    path = xbmcvfs.translatePath("special://temp/flix_telegram_qr.png")
    if not os.path.exists(path):
        import segno
        segno.make(URL, error="m").save(path, scale=12, border=2, dark="#000000", light="#ffffff")
    return path


def open_telegram():
    """el enlace en el móvil: Android elige Telegram (o el navegador si no está instalado)"""
    xbmc.executebuiltin("StartAndroidActivity(,android.intent.action.VIEW,,%s)" % URL)


class TelegramDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        self.setProperty("tg_qr", self.qr)
        self.setProperty("tg_url", SHOWN_URL)

    def onClick(self, cid):
        if cid == OPEN:
            open_telegram()
            log("abierto el grupo en Telegram")
        self.close()


def main():
    path = state_path()
    if not due(load(path), time.time()):
        return
    mon = xbmc.Monitor()
    if mon.waitForAbort(START_DELAY):
        return
    end = time.time() + WAIT_IDLE
    while not idle():
        if time.time() > end or mon.waitForAbort(2):
            log("no lo enseño: el Inicio no ha estado libre")
            return
    save(path, time.time())         # antes de enseñarlo: si Kodi se cierra con él abierto no vuelve a salir hasta dentro de 7 días
    w = TelegramDialog("FlixTelegram.xml", xbmcvfs.translatePath("special://skin/"), "Default", "1080i")
    w.qr = make_qr()
    log("aviso del grupo de Telegram")
    w.doModal()
    del w


if __name__ == "__main__":
    main()
