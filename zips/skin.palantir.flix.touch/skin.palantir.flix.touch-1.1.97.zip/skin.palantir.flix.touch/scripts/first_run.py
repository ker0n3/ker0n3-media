# -*- coding: utf-8 -*-

import subprocess
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os

def set_date_format(rpc=None):
    """formato de fecha corta de Kodi = DD/MM/YYYY (locale.shortdateformat; «regional» depende del país)"""
    import json
    rpc = rpc or xbmc.executeJSONRPC
    rpc(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                    "params": {"setting": "locale.shortdateformat", "value": "DD/MM/YYYY"}}))


def es_tactil():
    xbmc.log("[Skin.Estuary.Palantir] Ejecutando es_tactil()", level=xbmc.LOGINFO)
    ret = False
    try:
        # Verificar si el sistema operativo es Android
        if xbmc.getCondVisibility('system.platform.android'):
            # Ejecutar el comando getprop para Android
            result = subprocess.check_output(["getprop", 'ro.build.characteristics'], text=True)
            if "phone" in result  or "tablet" in result:
                #xbmc.log("La caracteristica define {result}.", level=xbmc.LOGINFO)
                ret = True
            else:
                result = subprocess.check_output(["getprop"], text=True)
                if "set_touch_timer_ms" in result:
                    #xbmc.log("Existe el ajuste set_touch_timer.", level=xbmc.LOGINFO)
                    ret = True
                else:
                    xbmc.log(f"No se puede determinar es_touch: {result}.", level=xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"Error en es_tactil: {e}", level=xbmc.LOGERROR)

    if ret:
        xbmc.executebuiltin("Skin.SetBool(touchmode)")


if __name__ == "__main__":
    #xbmc.log("[Skin.Estuary.Palantir] Ejecutando script inicial", level=xbmc.LOGINFO)
    if xbmcvfs.exists("special://profile/addon_data/skin.palantir.flix.touch/video_especial.mp4"):
        xbmcgui.Window(12999).setProperty('video_exists', 'true')

    if not xbmc.getCondVisibility("Skin.HasSetting(noPrimeraVez)"):
        es_tactil()
        xbmc.executebuiltin("Skin.SetBool(noPrimeraVez)")






    import sys as _sys
    _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    # menú (barra lateral TV / tarjetas táctiles) desde sections.json: lo primero, antes de que salga el Inicio
    try:
        import flix_sections
        flix_sections.apply()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] secciones del menú: %s" % e, xbmc.LOGWARNING)
    # ajustes de Palantir que la skin necesita (sin colores en los textos): en cada arranque
    try:
        import flix_palantir_prefs
        flix_palantir_prefs.main()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] ajustes de Palantir: %s" % e, xbmc.LOGWARNING)
    # prioridad de reproducción: el modo viejo (4k / 1080) pasa al orden de calidades nuevo; resumen de Ajustes
    try:
        import flix_quality
        flix_quality.migrate()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] prioridad de reproducción: %s" % e, xbmc.LOGWARNING)
    # Palantir baja de Trakt lo marcado en otros aparatos al listar su raíz (20 s después, aparte: no frena el Inicio)
    if not xbmcgui.Window(10000).getProperty("flix_p3sync"):
        xbmcgui.Window(10000).setProperty("flix_p3sync", "1")
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_p3sync.py)")
    # fechas (estreno de capítulos…) en dd/mm/aaaa: Kodi usa la de su región y con la de EE. UU. salía mm/dd/aaaa
    # (Carlos, 24-oct). Una vez por aparato: si luego se cambia a mano en Ajustes de Kodi, se respeta
    if not xbmc.getInfoLabel("Skin.String(flix_datefmt)"):
        set_date_format()
        xbmc.executebuiltin("Skin.SetString(flix_datefmt,DD/MM/YYYY)")
    # nota de los títulos (Ajustes → Nota de los títulos, clave de MDBList). Los ajustes se crean con su valor
    # neutro (clave «-» = sin clave; orden del ajuste viejo flix_rating_src o el de serie) para que existan y se puedan
    # poner a distancia (Settings.SetSkinSettingValue solo cambia ajustes que ya existen). Sin clave el bucle solo
    # mira los ajustes cada 3 s.
    if not xbmc.getInfoLabel("Skin.String(flix_mdblist_key)"):
        xbmc.executebuiltin("Skin.SetString(flix_mdblist_key,-)")
    try:
        import flix_ratings
        flix_ratings.migrate()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] nota de los títulos: %s" % e, xbmc.LOGWARNING)
    if not xbmcgui.Window(10000).getProperty("flix_ratings"):
        xbmcgui.Window(10000).setProperty("flix_ratings", "1")
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_ratings.py)")
    # aviso semanal del grupo de Telegram para avisar de fallos (Carlos, 28-oct): espera solo a que el Inicio esté libre
    if not xbmcgui.Window(10000).getProperty("flix_telegram"):
        xbmcgui.Window(10000).setProperty("flix_telegram", "1")
        xbmc.executebuiltin("RunScript(special://skin/scripts/flix_telegram.py)")
    # aviso diario de uso (Worker de Cloudflare): lo último, para no retrasar nada; si falla, se ignora
    try:
        import flix_ping
        flix_ping.main()
    except Exception as e:  # noqa: BLE001
        xbmc.log("[first_run] aviso de uso: %s" % e, xbmc.LOGWARNING)
